"""Lectura del benchmark observado de consumo, sin modificar las bases."""
from __future__ import annotations

from datetime import date, datetime
from functools import lru_cache
import math
from pathlib import Path
import unicodedata

from openpyxl import load_workbook


_PARENT = Path(__file__).resolve().parents[2]
WORKBOOK = next((q for q in (
    _PARENT / 'IASPE' / 'Scraper' / 'Cartera_consumo_mercado' / 'output' / 'Cartera_consumo_banca_multiple.xlsx',
    _PARENT / 'Scraper' / 'Cartera_consumo_mercado' / 'output' / 'Cartera_consumo_banca_multiple.xlsx',
) if q.is_file()), _PARENT / 'IASPE' / 'Scraper' / 'Cartera_consumo_mercado' / 'output' / 'Cartera_consumo_banca_multiple.xlsx')
SOURCE_URL = 'https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c=B-2389'
COMPONENTS = (
    ('tarjetas', 'Saldo bruto de tarjetas de crédito de consumo', '05', 1, 4),
    ('prestamos', 'Préstamos de consumo no revolventes', '06', 2, 5),
    ('cartera', 'Cartera de consumo comparable', '07', 3, 6),
)


def _text(value):
    text = unicodedata.normalize('NFKD', str(value or '')).lower()
    return ' '.join(''.join(c for c in text if not unicodedata.combining(c)).split())


def _number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) else None


def _month(value):
    if isinstance(value, (date, datetime)):
        return value.strftime('%Y-%m')
    text = str(value or '').strip()[:7]
    datetime.strptime(text, '%Y-%m')
    return text


@lru_cache(maxsize=2)
def _read(path, modified_ns, size):
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        sheet = workbook['Mensual']
        values = iter(sheet.values)
        headings = [_text(value) for value in next(values)]
        required = ('mes', 'tarjetas de credito de consumo', 'prestamos de consumo no revolventes',
                    'cartera de consumo', 'tarjetas de credito de consumo',
                    'prestamos de consumo no revolventes', 'cartera de consumo')
        if len(headings) < 8 or any(term not in headings[i] for i, term in enumerate(required)):
            raise ValueError('El benchmark no tiene las columnas esperadas de consumo.')
        if any('s/ millones' not in headings[i] for i in range(1, 7)):
            raise ValueError('La unidad de los saldos del benchmark debe ser S/ millones.')
        series = {key: {'id': key, 'name': name, 'modelId': model_id, 'rows': []}
                  for key, name, model_id, _, _ in COMPONENTS}
        dates = set()
        for source in values:
            if not source or source[0] is None:
                continue
            month = _month(source[0])
            if month in dates:
                raise ValueError(f'El benchmark contiene un mes duplicado: {month}.')
            dates.add(month)
            row = [_number(value) for value in source]
            for total, first, second in ((3, 1, 2), (6, 4, 5)):
                if all(row[i] is not None for i in (total, first, second)):
                    if not math.isclose(row[total], row[first] + row[second], rel_tol=1e-10, abs_tol=1e-6):
                        raise ValueError(f'Los componentes de la cartera no concilian en {month}.')
            for key, _, _, market_col, falabella_col in COMPONENTS:
                market, falabella = row[market_col], row[falabella_col]
                if market is None or falabella is None:
                    continue
                series[key]['rows'].append({'date': month, 'falabella': falabella, 'market': market,
                                            'share': 100 * falabella / market if market else None})
        for component in series.values():
            component['rows'].sort(key=lambda item: item['date'])
            if not component['rows']:
                raise ValueError(f'No hay datos observados comparables para {component["name"]}.')
            component['from'] = component['rows'][0]['date']
            component['to'] = component['rows'][-1]['date']
        return {
            'source': {
                'name': 'SBS · Estructura de créditos directos por tipo y modalidad',
                'url': SOURCE_URL,
                'unit': 'S/ millones',
                'workbook': str(path),
                'sheet': 'Mensual',
                'marketIncludesFalabella': True,
                'definition': 'Tarjetas de crédito del segmento consumo y préstamos de consumo no revolventes. La cartera comparable es la suma de ambas modalidades; la banca múltiple incluye a Banco Falabella.',
                'coverageNote': 'Esta comparación utiliza tarjetas de consumo SBS en ambos lados. El modelo de saldo conserva las tarjetas totales de Falabella; su historia presenta pequeñas diferencias frente a consumo antes de 2023.',
                'classificationNote': 'Desde enero de 2021, la SBS clasifica como préstamos los financiamientos no revolventes independientes de la línea de tarjeta. Este cambio de cobertura afecta la lectura de cada modalidad por separado.',
            },
            'components': list(series.values()),
        }
    finally:
        workbook.close()


def load_benchmark():
    """Devuelve exclusivamente cifras observadas del Excel procesado existente."""
    stat = WORKBOOK.stat()
    return _read(WORKBOOK, stat.st_mtime_ns, stat.st_size)
