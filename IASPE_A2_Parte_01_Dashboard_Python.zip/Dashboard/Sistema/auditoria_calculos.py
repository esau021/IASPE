"""Auditoría numérica del escenario IASPE, sin modificar las proyecciones.

Se contrastan variaciones respecto del escenario aprobado. Esto preserva los
residuos SBS preexistentes y evita imputar correcciones contables ficticias.
"""
from __future__ import annotations

import math
import json
from pathlib import Path

# Relaciones de consolidación que ejecutan los motores. Los modelos 22
# (cuentas por cobrar interbancarias) y 12 (gastos por intereses) NO son
# intercambiables: el margen 23 requiere 12 y gastos FSD, además del ROF.
CONSOLIDACIONES = {
    '08': [('08_mn', 1), ('08_me', 1)],
    '09': [('09_plazo', 1), ('09_cts', 1)],
    '10': [('08', 1), ('09', 1), ('10_restringidos', 1), ('10_otras', 1)],
    '12': [('12_obligaciones', 1), ('12_entidades', 1),
           ('12_adeudos', 1), ('12_otras', 1)],
    '16': [('16_creditos', 1), ('16_inversiones', 1),
           ('16_disponible', 1), ('16_interbancarios', 1)],
    '17': [('17_caja', 1), ('17_bancos', 1),
           ('17_canje', 1), ('17_otros', 1)],
    '18': [('18_diversos', 1), ('18_otros_ing', 1),
           ('18_gastos_div', -1), ('18_otros_gastos', -1)],
    '19': [('19_personal', 1), ('19_directorio', 1),
           ('19_terceros', 1), ('19_impuestos', 1)],
    '20': [('20_consorcios', 1), ('20_asociadas', 1),
           ('20_tc', 1), ('20_derivados', 1),
           ('20_inversiones', 1), ('20_otros', 1)],
    '21': [('21_venta', 1), ('21_asociadas', 1), ('21_otras', 1)],
    # Modelo 23: M16 + ingresos financieros por M20 - intereses M12
    # - primas FSD M18 - otros gastos financieros de M20.
    # Los componentes M20 relevantes de la línea de ingresos son los tres
    # siguientes: cambios de consorcios, tipo de cambio y derivados.
    '23': [('16', 1), ('20_consorcios', 1), ('20_tc', 1),
           ('20_derivados', 1), ('12', -1), ('18_fsd', -1)],
    # Utilidad antes de impuestos = M23 - M25 + M18 - M19
    # - M26 - M27 + M24 + venta de cartera (último sin cambios externos).
    '28': [('23', .27), ('25', -.27), ('18', .27), ('19', -.27),
           ('26', -.27), ('27', -.27), ('24', .27)],
    '29': [('23', .73), ('25', -.73), ('18', .73), ('19', -.73),
           ('26', -.73), ('27', -.73), ('24', .73)],
}


def verificar(anterior, posterior, observaciones=None):
    observaciones = observaciones or {}
    antes = {m['id']: m for m in anterior['models']}
    despues = {m['id']: m for m in posterior['models']}
    findings = []
    checks = 0

    def issue(level, mid, detail):
        findings.append({'severity': level, 'id': mid, 'message': detail})

    missing = sorted(set(antes) - set(despues))
    if missing:
        issue('error', 'catalogo', 'Modelos desaparecidos: ' + ', '.join(missing))
    mains = [key for key in despues if len(key) == 2 and key.isdigit()]
    checks += 1
    if len(mains) != 49:
        issue('error', 'catalogo', f'Hay {len(mains)} modelos principales, se esperan 49.')

    for key, model in despues.items():
        years = set()
        for row in model.get('annual', []):
            checks += 1
            year = row.get('year')
            if year in years:
                issue('error', key, f'Año {year} duplicado.')
            years.add(year)
            try:
                number = float(row['value'])
            except (ValueError, TypeError, KeyError):
                number = float('nan')
            if not math.isfinite(number):
                issue('error', key, f'Importe no finito en {year}.')
            if year is not None and int(year) >= 2027 and row.get('status') == 'observed':
                issue('error', key, f'Un año proyectado, {year}, aparece como observado.')
        if key in antes:
            missing_years = {r['year'] for r in antes[key].get('annual', [])} - years
            if missing_years:
                issue('error', key, f'Se perdieron los años {sorted(missing_years)}.')
        for coefficient in model.get('coefficients', []) or []:
            if isinstance(coefficient, dict) and coefficient.get('value') is not None:
                checks += 1
                try:
                    valid = math.isfinite(float(coefficient['value']))
                except (ValueError, TypeError):
                    valid = False
                if not valid:
                    issue('error', key, 'Coeficiente no numérico o no finito.')

    def values(mapping, key):
        return {int(row['year']): float(row['value'])
                for row in mapping.get(key, {}).get('annual', [])
                if row.get('value') is not None}

    old = {key: values(antes, key) for key in antes}
    new = {key: values(despues, key) for key in despues}

    def delta(key, year):
        if year not in old.get(key, {}) or year not in new.get(key, {}):
            return None
        return new[key][year] - old[key][year]

    # Las identidades se verifican en DIFERENCIAS contra el estado anterior.
    # Si existe una observación SBS directa del total, se respeta y no se
    # fuerza a sumar componentes observados de fechas distintas.
    for year in range(2026, 2031):
        for parent, components in CONSOLIDACIONES.items():
            change = delta(parent, year)
            parts = [(delta(k, year), sign) for k, sign in components]
            if change is None or any(v is None for v, _ in parts):
                continue
            expected = sum(v * sign for v, sign in parts)
            checks += 1
            # Si el nuevo escenario ya concilia exactamente sus componentes,
            # no imputar como error el residuo que existía en el libro BASE.
            if year in new.get(parent, {}) and all(year in new.get(k,{}) for k,_ in components):
                reconciled=sum(new[k][year]*sign for k,sign in components)
                if abs(new[parent][year]-reconciled)<0.08:
                    continue
            direct = observaciones.get('sbs_contable', {}).get(parent, {}).get(str(year))
            if isinstance(direct, dict) and direct.get('status') == 'observed':
                continue
            if abs(change - expected) > 0.08:
                issue('error', parent,
                      f'{year}: transmisión inconsistente, total {change:.4f} '
                      f'vs. componentes {expected:.4f} MM.')

    # Conciliación ABSOLUTA del P&L: verificar no solo los DELTAS.
    # M29 puede conservar una UAI antigua si M19 fue actualizado sin
    # retransmitir sus gastos administrativos a utilidad e impuesto.
    try:
        pnl_base = json.loads((Path(__file__).resolve().parent / 'data' /
                               'eeff_sbs_base_2025_2030.json').read_text(encoding='utf-8'))
        for year in range(2025, 2031):
            names = ('23','25','18','19','26','27','24','28','29')
            if not all(year in new.get(k,{}) for k in names):
                issue('error','29',f'{year}: faltan componentes para conciliación P&L.')
                continue
            sale = pnl_base.get('years',{}).get(str(year),{}).get('(+/−) Venta de cartera')
            if not isinstance(sale,(int,float)):
                issue('error','29',f'{year}: falta la línea venta de cartera del P&L original.')
                continue
            uai = (new['23'][year]-new['25'][year]+new['18'][year]+sale
                   -new['19'][year]-new['26'][year]-new['27'][year]+new['24'][year])
            checks += 1
            if abs(uai-new['28'][year]-new['29'][year])>0.0001:
                issue('error','29',f'{year}: UAI {uai:.6f} no concilia con impuesto '
                      f'{new["28"][year]:.6f} y neto {new["29"][year]:.6f}.')
    except (OSError, ValueError) as exc:
        issue('error','29',f'No se pudo ejecutar auditoría absoluta del P&L: {exc}')

    # M46: el resultado neto que queda en patrimonio debe coincidir con M29.
    # Esta igualdad también valida la transmisión bajo escenarios estresados.
    for year in range(2026,2031):
        if year in new.get('46',{}) and year in new.get('29',{}):
            checks += 1
            if abs(new['46'][year]-new['29'][year])>0.00001:
                issue('error','46',f'{year}: resultado patrimonial M46 no concilia con utilidad neta M29.')

    # M47: no se admite un cuadre oculto ni una identidad no conciliada.
    for year in range(2025,2029):
        val=lambda k:new.get(k,{}).get(year)
        checks+=1
        if any(val(k) is None for k in ('47','47_pasivo','47_patrimonio','47_control','17','47_disponible')):
            issue('error','47',f'{year}: falta un componente del estado de situación financiera.')
            continue
        if abs(val('47')-val('47_pasivo')-val('47_patrimonio'))>1e-5 or abs(val('47_control'))>1e-5:
            issue('error','47',f'{year}: el balance no concilia.')
        if abs(val('17')-val('47_disponible'))>1e-5:
            issue('error','17',f'{year}: disponible M17 difiere del balance M47.')
        if val('47_bancos') < 0:
            issue('error','47',f'{year}: saldo de bancos negativo después de conciliar.')

    # Modelo 30: promedio móvil aprobado de líneas no utilizadas por tarjeta.
    for year in (2027, 2028, 2029, 2030):
        if not all(y in new.get('30', {}) and y in new.get('04', {})
                   for y in range(year-3, year+1)):
            continue
        count = new['04'][year]
        ratios = [new['30'][y]/new['04'][y]
                  for y in range(year-3, year) if new['04'][y] > 0]
        if count <= 0 or len(ratios) != 3:
            issue('error', '30', f'{year}: no hay tres cocientes válidos.')
            continue
        expected = round(count * sum(ratios)/3, 2)
        checks += 1
        modified = any(abs(delta(k, y) or 0) > 0.001
                       for k in ('04', '30') for y in range(2026, year+1))
        if modified and abs(expected-new['30'][year]) > 0.12:
            issue('error', '30',
                  f'{year}: modelo {new["30"][year]:.3f} vs. promedio móvil {expected:.3f} MM.')

    # Control explícito para evitar la congelación del margen o la utilidad
    # cuando cambiaron sus insumos netos. Si los efectos se compensan, no
    # generar un falso error por exigir una respuesta diferente de cero.
    for year in (2026, 2027, 2028, 2029, 2030):
        for parent in ('23', '28', '29'):
            result = delta(parent, year)
            changes = [(delta(k, year), sign) for k, sign in CONSOLIDACIONES[parent]]
            if result is None or any(v is None for v, _ in changes):
                continue
            expected = sum(v * sign for v, sign in changes)
            if abs(expected) <= 0.01:
                continue
            checks += 1
            direct = observaciones.get('sbs_contable', {}).get(parent, {}).get(str(year))
            if not (isinstance(direct, dict) and direct.get('status') == 'observed') and abs(result) < 0.001:
                issue('error', parent,
                      f'{year}: el modelo no respondió a cambios netos de {expected:.4f} MM.')

    errors = sum(f['severity'] == 'error' for f in findings)
    warnings = sum(f['severity'] == 'warning' for f in findings)
    return {'passed': errors == 0, 'checks': checks,
            'errors': errors, 'warnings': warnings,
            'findings': findings[:100], 'modelCount': len(mains),
            'componentCount': len(despues)}
