"""Adquisición independiente de oficinas SBS; nunca ejecuta modelos financieros."""
from __future__ import annotations

import argparse
from copy import deepcopy
import csv
from datetime import date, datetime, timedelta, timezone
import hashlib
from html.parser import HTMLParser
import io
import json
import math
from pathlib import Path
import re
import sys
import tempfile
import unicodedata
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse, urlunparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

IASPE = Path(__file__).resolve().parents[3]
MODULE = IASPE / 'Scraper' / 'Oficinas'
RAW = MODULE / 'fuentes'
OUTPUT = MODULE / 'output'
SYSTEM = IASPE.parent / 'Dashboard' / 'Sistema'
sys.path.insert(0, str(SYSTEM))
from instituciones_sbs import BANKS, category_at, entity_metadata, match_entity
from oficinas_sbs import validate_dataset, value_revision

REPORTS = {'B-2303': 'Bancos', 'B-3201': 'Empresas financieras', 'C-2201': 'Cajas rurales'}
MONTHS = [('Enero','en'),('Febrero','fe'),('Marzo','ma'),('Abril','ab'),('Mayo','my'),('Junio','jn'),
          ('Julio','jl'),('Agosto','ag'),('Setiembre','se'),('Octubre','oc'),('Noviembre','no'),('Diciembre','di')]
DEPARTMENTS = [
    ('01','Amazonas'),('02','Áncash'),('03','Apurímac'),('04','Arequipa'),('05','Ayacucho'),
    ('06','Cajamarca'),('07','Callao'),('08','Cusco'),('09','Huancavelica'),('10','Huánuco'),
    ('11','Ica'),('12','Junín'),('13','La Libertad'),('14','Lambayeque'),('15','Lima'),
    ('16','Loreto'),('17','Madre de Dios'),('18','Moquegua'),('19','Pasco'),('20','Piura'),
    ('21','Puno'),('22','San Martín'),('23','Tacna'),('24','Tumbes'),('25','Ucayali')]


def normalized(value):
    text = unicodedata.normalize('NFKD', str(value or '')).encode('ascii','ignore').decode().lower()
    text = re.sub(r'(?:\d+\s*[/)]|\*+)\s*$', '', text)
    return re.sub(r'[^a-z0-9 ]', ' ', text).strip()


DEPARTMENT_NAMES = {normalized(name): code for code, name in DEPARTMENTS}
DEPARTMENT_NAMES.update({'provincia constitucional del callao':'07','prov const del callao':'07',
                         'prov constitucional del callao':'07','cuzco':'08'})


def department_code(value):
    return DEPARTMENT_NAMES.get(' '.join(normalized(value).split()))


def entity_id(value):
    # Los números de nota no son códigos de institución.
    clean = re.sub(r'(?:\d+\s*[/)]|\*+)\s*$', '', str(value or '')).strip()
    clean=re.sub(r'\s*\(con sucursales en el exterior\)\s*$','',clean,flags=re.I)
    # C-2201 marzo2019 acredita la conversión por Resolución753-2019.
    if normalized(clean)=='crac cat peru':clean='CRAC CAT'
    return match_entity(clean)


def count(value):
    if value is None or isinstance(value, str) and not value.strip():
        return None
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0 or int(value) != value:
        raise ValueError(f'Oficinas: recuento no entero o sin definición de cero: {value!r}')
    return int(value)


def excel_cell(row, column):
    letters = ''; number = column + 1
    while number:
        number, remainder = divmod(number - 1, 26)
        letters = chr(65 + remainder) + letters
    return letters + str(row + 1)


def read_tables(body):
    if body.startswith(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'):
        import xlrd
        book = xlrd.open_workbook(file_contents=body, on_demand=True)
        try:
            for sheet in book.sheets():
                rows = []
                for r in range(sheet.nrows):
                    row = []
                    for c in range(sheet.ncols):
                        cell = sheet.cell(r,c)
                        if cell.ctype in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK): value = None
                        elif cell.ctype == xlrd.XL_CELL_DATE: value = xlrd.xldate_as_datetime(cell.value, book.datemode)
                        elif cell.ctype == xlrd.XL_CELL_ERROR: value = '#ERROR'
                        else: value = cell.value
                        row.append(value)
                    rows.append(row)
                yield sheet.name, rows
        finally:
            book.release_resources()
    elif body.startswith(b'PK'):
        from openpyxl import load_workbook
        book = load_workbook(io.BytesIO(body), read_only=True, data_only=True)
        try:
            for sheet in book:
                yield sheet.title, list(sheet.values)
        finally:
            book.close()
    else:
        raise ValueError('Oficinas: la respuesta no es un Excel; no se interpreta HTML como datos')


def internal_periods(rows):
    periods = set()
    for row in rows[:12]:
        for value in row[:10]:
            if isinstance(value, datetime):
                periods.add(value.strftime('%Y-%m'))
            elif isinstance(value, str):
                text = normalized(value)
                for i, (name, _) in enumerate(MONTHS, 1):
                    names = [normalized(name)] + (['septiembre'] if i == 9 else [])
                    for name in names:
                        for match in re.finditer(r'\b' + name + r'\s+(?:(?:de|del)\s+)?(20\d{2})\b', text):
                            periods.add(f'{match[1]}-{i:02}')
                for match in re.finditer(r'\b\d{1,2}[/-](\d{1,2})[/-](20\d{2})\b', value):
                    raw_date=match[0]
                    for pattern in ('%d/%m/%Y','%m/%d/%Y','%d-%m-%Y','%m-%d-%Y'):
                        try:parsed=datetime.strptime(raw_date,pattern)
                        except ValueError:continue
                        periods.add(parsed.strftime('%Y-%m'))
    return periods


def auxiliary_row_control(aux_rows,header,row,values,labels,counts,sheet):
    lima=labels['total provincia de lima'];other=labels['otras provincias de lima'];callao=labels['total provincia del callao']
    # Un guion solo se admite como cero si la fila distrital completa concilia
    # con ambas provincias y con los departamentos de la matriz nacional.
    dashed=[]
    def number(column):
        value=values[column]
        if isinstance(value,str) and value.strip()=='-':
            dashed.append(excel_cell(row,column));return 0
        return count(value)
    province=number(lima);other_provinces=number(other);province_callao=number(callao)
    if any(value is None for value in (province,other_provinces,province_callao)):
        raise ValueError('Oficinas: detalle Lima/Callao sin datos')
    if province+other_provinces!=counts['15'] or province_callao!=counts['07']:
        raise ValueError('Oficinas: detalle Lima/Callao distinto de los totales departamentales')
    lima_districts=[number(column) for column in range(1,lima)
                    if not normalized(aux_rows[header][column]).startswith('total ')]
    callao_districts=[number(column) for column in range(other+1,callao)]
    if (any(value is None for value in lima_districts+callao_districts)
        or sum(lima_districts)!=province or sum(callao_districts)!=province_callao):
        raise ValueError('Oficinas: distritos de Lima/Callao no concilian con su provincia')
    for label,column in labels.items():
        if label=='total lima metropolitana':
            components=[number(c) for c in range(1,column)]
            if any(value is None for value in components) or sum(components)!=number(column):
                raise ValueError('Oficinas: subtotal histórico de Lima Metropolitana no concilia')
    result={'sheet':sheet,'limaProvinceCell':excel_cell(row,lima),'otherLimaCell':excel_cell(row,other),
            'callaoCell':excel_cell(row,callao),'limaProvince':province,'otherLima':other_provinces,
            'callao':province_callao,'reconciled':True}
    if dashed:result.update(derivedZeroCells=sorted(set(dashed)),
        zeroRule='Printed dashes certified by all district subtotals and the independently published Lima/Callao departments; blanks never replaced')
    return result


def parse_institution_rows(tables, body, report, period, url, strict=True, audit=None):
    """Formato SBS: empresas en filas y los 25 territorios en columnas."""
    candidates=[]
    for sheet,rows in tables:
        title=' '.join(normalized(value) for row in rows[:12] for value in row if isinstance(value,str))
        if not ('distribucion' in title and 'oficinas' in title):continue
        for header,row in enumerate(rows[:15]):
            columns={}
            for column,value in enumerate(row):
                code=department_code(value)
                if code:
                    if code in columns:raise ValueError('Oficinas: territorio repetido en el encabezado')
                    columns[code]=column
            if set(columns)!={code for code,_ in DEPARTMENTS}:
                if report!='C-2201' or not columns:continue
            if period not in internal_periods(rows):raise ValueError('Oficinas: fecha interna distinta del periodo solicitado')
            labels={column:' '.join(normalized(value).split()) for column,value in enumerate(row) if isinstance(value,str)}
            total=[column for column,label in labels.items() if label in ('total','total oficinas','total nacional')]
            outside=[column for column,label in labels.items() if label in ('exterior','sucursales en el exterior','oficinas en el exterior')]
            entity=[column for column,label in labels.items() if label in ('empresas','entidades','instituciones')]
            if len(total)!=1 or len(entity)!=1 or len(outside)>1:raise ValueError('Oficinas: encabezados de empresa, total o exterior ambiguos')
            declared={column for column,label in labels.items() if entity[0]<column<total[0] and column not in outside}
            if declared!=set(columns.values()):raise ValueError('Oficinas: columnas territoriales sin correspondencia geográfica')
            candidates.append((sheet,rows,header,columns,total[0],outside[0] if outside else None,entity[0]))
    if not candidates:return None
    if len(candidates)!=1:raise ValueError('Oficinas: hay varias tablas departamentales completas; no se suman automáticamente')
    sheet,rows,header,columns,total_column,outside_column,entity_column=candidates[0]
    records={};company_rows=[];summary=[];resolved_values={}
    audit=audit if audit is not None else []
    def issue(message):
        if strict:raise ValueError(message)
        if message not in audit:audit.append(message)
    def nullable(value):
        return None if isinstance(value,str) and value.strip()=='-' else count(value)
    def raw(row,column):return rows[row][column] if column<len(rows[row]) else None
    for row in range(header+1,len(rows)):
        label=raw(row,entity_column)
        if not isinstance(label,str) or not label.strip():continue
        if normalized(label).startswith('total '):
            if count(raw(row,total_column)) is not None:summary.append(row)
            continue
        total=nullable(raw(row,total_column))
        identifier=entity_id(label)
        if total is None:
            if identifier:issue(f'Oficinas: falta el total publicado de {label}')
            continue
        components=[*columns.values(),*([outside_column] if outside_column is not None else [])]
        dashes={column for column in components if isinstance(raw(row,column),str) and raw(row,column).strip()=='-'}
        other_values=[nullable(raw(row,column)) for column in components if column not in dashes]
        certified=bool(dashes) and all(value is not None for value in other_values) and sum(other_values)==total
        def number(column):
            return 0 if certified and column in dashes else nullable(raw(row,column))
        counts={code:number(columns[code]) if code in columns else None for code,_ in DEPARTMENTS}
        outside=number(outside_column) if outside_column is not None else None
        missing_cells=[code for code in columns if counts[code] is None]
        if strict and missing_cells:raise ValueError(f'Oficinas: faltan recuentos de {label}; no se imputan ceros')
        if strict and outside_column is not None and outside is None:raise ValueError('Oficinas: exterior sin dato')
        known=sum(value for value in counts.values() if value is not None)
        peru=total-outside if outside is not None else total if outside_column is None or known==total else known if not missing_cells else None
        complete=not missing_cells and len(columns)==25
        if (peru is not None and known>peru) or (complete and peru is not None and known!=peru):
            issue(f'Oficinas: suma territorial y exterior distinta del total publicado de {label}');continue
        if all(value is None for value in counts.values()) and peru is None:
            issue(f'Oficinas: sin detalle territorial ni total Perú de {label}');continue
        company_rows.append(row)
        for column in components:resolved_values[row,column]=number(column)
        resolved_values[row,total_column]=total
        if identifier is None:continue
        if category_at(identifier,period)!=REPORTS[report]:
            raise ValueError(f'Oficinas: licencia del catálogo incompatible con {label}/{period}')
        if identifier in records:raise ValueError('Oficinas: institución duplicada en la tabla')
        source={'report':report,'url':url,'file':f'fuentes/{report}/{report}-{period}.XLS',
            'sha256':hashlib.sha256(body).hexdigest(),'sheet':sheet,'institutionCell':excel_cell(row,entity_column),
            'institutionLabel':label.strip(),'institutionCodeMethod':'matchedByPublishedNameToSharedCatalog',
            'cells':{code:excel_cell(row,columns[code]) if code in columns else None for code,_ in DEPARTMENTS},
            'totalCell':excel_cell(row,total_column),'outsideCell':excel_cell(row,outside_column) if outside_column is not None else None,
            'publishedTotalScope':'PeruAndExterior' if outside_column is not None else 'ReportedPeruTerritories',
            'departmentCodeMethod':'mappedFromDepartmentName','zeroRule':'Explicit numeric zeros only'}
        missing=sorted(code for code,value in counts.items() if value is None)
        omitted=sorted(code for code,_ in DEPARTMENTS if code not in columns)
        if omitted:source['unreportedDepartments']=omitted
        if missing_cells:source['missingDepartmentCells']=missing_cells
        if certified:
            source['zeroRule']='Printed dashes certified by the complete nonnegative institution row and its published total; blanks are never replaced'
            source['derivedZeroCells']=[excel_cell(row,column) for column in sorted(dashes)]
        source['institutionControl']={'knownDepartmentSum':known,'publishedTotal':total,'peruTotal':peru,
                                      'completeDetail':not missing,'reconciled':not missing and peru==known}
        records[identifier]={'counts':counts,'total':peru,'coverage':None if missing else sum(value>0 for value in counts.values()),
            'sourceTotal':total,'outsidePeru':outside,'category':REPORTS[report],'sbsCode':None,'source':source}
    if not records:
        if strict:raise ValueError('Oficinas: ninguna entidad comparable identificada')
        return {}
    if len(summary)!=1:raise ValueError('Oficinas: total sectorial no unívoco')
    aggregate=summary[0]
    differences=[]
    for column in [*columns.values(),total_column,*([outside_column] if outside_column is not None else [])]:
        published=nullable(raw(aggregate,column))
        values=[resolved_values[row,column] for row in company_rows]
        if published is None or any(value is None for value in values) or sum(values)!=published:
            differences.append({'cell':excel_cell(aggregate,column),'published':published,
                                'companySum':sum(value for value in values if value is not None),'hasMissing':any(value is None for value in values)})
    if differences:issue('Oficinas: control sectorial publicado no conciliado; se conservan solo las cifras individuales verificadas')
    for record in records.values():
        margins=[nullable(raw(aggregate,column)) for column in columns.values()]
        record['source']['sectorControl']={'totalCell':excel_cell(aggregate,total_column),
            'total':nullable(raw(aggregate,total_column)),'peru':sum(margins) if all(value is not None for value in margins) else None,
            'companyRows':len(company_rows),'reconciled':not differences,'differences':differences}
    # El detalle distrital de Lima/Callao es una comprobación, no otro territorio.
    required={'total provincia de lima','otras provincias de lima','total provincia del callao'}
    for auxiliary,aux_rows in tables:
        for header,values in enumerate(aux_rows[:15]):
            labels={' '.join(normalized(value).split()):column for column,value in enumerate(values) if isinstance(value,str)}
            if not required.issubset(labels):continue
            lima=labels['total provincia de lima'];other=labels['otras provincias de lima'];callao=labels['total provincia del callao']
            seen=set()
            for row,values in enumerate(aux_rows[header+1:],header+1):
                identifier=entity_id(values[0]) if values else None
                if identifier not in records:continue
                if identifier in seen:raise ValueError('Oficinas: entidad duplicada en detalle Lima/Callao')
                seen.add(identifier)
                try:
                    control=auxiliary_row_control(aux_rows,header,row,values,labels,records[identifier]['counts'],auxiliary)
                except ValueError as error:
                    issue(str(error))
                    control={'sheet':auxiliary,'reconciled':False,'reason':str(error),
                             'limaProvinceCell':excel_cell(row,lima),'otherLimaCell':excel_cell(row,other),
                             'callaoCell':excel_cell(row,callao),'primaryLima':records[identifier]['counts']['15'],
                             'primaryCallao':records[identifier]['counts']['07']}
                records[identifier]['source']['limaCallaoControl']=control
            if seen!=set(records):issue('Oficinas: faltan comparables en el detalle Lima/Callao')
    return records


def certified_dash_zeros(rows,header,department_rows,total_row):
    """Certifica guiones impresos solo mediante ambos márgenes publicados."""
    labels={' '.join(normalized(value).split()):column for column,value in enumerate(rows[header]) if isinstance(value,str)}
    total_column=labels.get('total')
    if total_column is None:return set()
    company_columns=list(range(1,total_column))
    locations=[(row,column) for row in department_rows.values() for column in company_columns]
    dashed={(row,column) for row,column in locations
            if isinstance(rows[row][column],str) and rows[row][column].strip()=='-'}
    if not dashed:return set()
    def value(row,column):
        return 0 if (row,column) in dashed else count(rows[row][column])
    # Un blanco o un dato no numérico distinto del guion impide la certificación.
    for row in department_rows.values():
        values=[value(row,column) for column in company_columns]
        published=count(rows[row][total_column])
        if any(x is None for x in values) or published is None or sum(values)!=published:
            raise ValueError('Oficinas: guiones sin conciliación por departamento; no se convierten a cero')
    for column in company_columns:
        values=[value(row,column) for row in department_rows.values()]
        published=count(rows[total_row][column])
        if published is None or sum(values)!=published:
            raise ValueError('Oficinas: guiones sin conciliación por empresa; no se convierten a cero')
    grand=count(rows[total_row][total_column])
    if (grand is None or sum(count(rows[total_row][column]) for column in company_columns)!=grand
        or sum(count(rows[row][total_column]) for row in department_rows.values())!=grand):
        raise ValueError('Oficinas: guiones sin conciliación del total general')
    return dashed


def parse_workbook(body, report, period, url=None, strict=True, audit=None):
    """Tabla departamental con encabezados identificables; variantes ambiguas fallan."""
    if report not in REPORTS:
        raise ValueError('Oficinas: reporte no autorizado')
    tables=list(read_tables(body))
    audit=audit if audit is not None else []
    horizontal=parse_institution_rows(tables,body,report,period,url or source_url(report,period),strict,audit)
    if horizontal is not None:return horizontal
    candidates = []
    for sheet, rows in tables:
        title = ' '.join(normalized(value) for row in rows[:12] for value in row if isinstance(value, str))
        if not ('oficinas' in title and 'distribucion' in title and any(word in title for word in ('geograf','departament','region'))):
            continue
        if period not in internal_periods(rows):
            raise ValueError(f'Oficinas: fecha interna distinta de {period} en {sheet}')
        for r, row in enumerate(rows[:25]):
            entities = {c: identifier for c, value in enumerate(row) if (identifier := entity_id(value))}
            if entities:
                candidates.append((len(entities), sheet, rows, r, entities))
    if not candidates:
        raise ValueError('Oficinas: no se encontró una tabla departamental con entidades reconocidas')
    candidates.sort(key=lambda entry: entry[0], reverse=True)
    _, sheet, rows, header, entities = candidates[0]
    if len(set(entities.values())) != len(entities):
        raise ValueError('Oficinas: entidad duplicada en encabezados; no sumar categorías distintas')
    first_entity_column = min(entities)
    department_rows = {}
    total_rows = []; outside_rows = []
    for r, row in enumerate(rows[header+1:], header+1):
        leading = [value for value in row[:first_entity_column] if isinstance(value,str) and value.strip()]
        codes = {department_code(value) for value in leading} - {None}
        labels = {' '.join(normalized(value).split()) for value in leading}
        if any('lima metropolitana' in label or 'lima provincias' in label for label in labels):
            raise ValueError('Oficinas: Lima presenta fragmentos; se requiere verificar su cobertura antes de agregarlos')
        if len(codes) > 1:
            raise ValueError('Oficinas: fila con departamentos ambiguos')
        if codes:
            code = next(iter(codes))
            if code in department_rows:
                raise ValueError('Oficinas: departamento repetido; no se mezclan subtotales y distritos')
            department_rows[code] = r
        if labels & {'total','total general','total nacional','total pais','total oficinas'}:
            total_rows.append(r)
        if labels & {'exterior','extranjero','fuera del pais','oficinas en el exterior'}:
            outside_rows.append(r)
    if set(department_rows) != {code for code, _ in DEPARTMENTS}:
        missing = sorted({code for code, _ in DEPARTMENTS} - set(department_rows))
        raise ValueError(f'Oficinas: no hay 25 departamentos inequívocos; faltan {missing}')
    if len(total_rows) != 1 or len(outside_rows) > 1:
        raise ValueError('Oficinas: el total nacional o el exterior no son inequívocos')
    try:certified=certified_dash_zeros(rows,header,department_rows,total_rows[0])
    except ValueError:
        if strict:raise
        certified=set()
    records = {}
    for column, identifier in entities.items():
        if category_at(identifier, period) != REPORTS[report]:
            continue
        def raw(r): return rows[r][column] if column < len(rows[r]) else None
        published_total = count(raw(total_rows[0]))
        if published_total is None:
            raise ValueError(f'Oficinas: falta total publicado de {identifier}/{period}')
        column_dashes={r for r in department_rows.values() if isinstance(raw(r),str) and raw(r).strip()=='-'}
        other=[count(raw(r)) for r in department_rows.values() if r not in column_dashes]
        column_certified=bool(column_dashes) and all(value is not None for value in other) and sum(other)==published_total
        def number(r):
            if (r,column) in certified or column_certified and r in column_dashes:return 0
            if not strict and isinstance(raw(r),str) and raw(r).strip()=='-':return None
            return count(raw(r))
        counts = {code:number(r) for code,r in department_rows.items()}
        outside = count(raw(outside_rows[0])) if outside_rows else None
        if outside_rows and outside is None:
            raise ValueError('Oficinas: exterior sin dato; no se puede determinar el total Perú')
        # Sin fila exterior no se afirma que la institución tenga cero oficinas
        # fuera de Perú; el total publicado debe conciliar con los 25 territorios.
        territorial_total = published_total - outside if outside is not None else published_total
        if territorial_total < 0:
            raise ValueError('Oficinas: total Perú negativo')
        if strict and any(value is None for value in counts.values()):
            # Sin una convención acreditada, ni blanco ni guion significan cero.
            raise ValueError(f'Oficinas: celdas departamentales sin dato en {identifier}/{period}; no se imputan ceros')
        known=sum(value for value in counts.values() if value is not None)
        complete=all(value is not None for value in counts.values())
        if known>territorial_total or complete and known!=territorial_total:
            raise ValueError(f'Oficinas: distribución no concilia con total Perú de {identifier}/{period}')
        meta = entity_metadata(identifier, period)
        source = {'report':report,'url':url or source_url(report,period),
                  'file':f'fuentes/{report}/{report}-{period}.XLS','sha256':hashlib.sha256(body).hexdigest(),
                  'sheet':sheet,'institutionCell':excel_cell(header,column),
                  'cells':{code:excel_cell(r,column) for code,r in department_rows.items()},
                  'totalCell':excel_cell(total_rows[0],column),
                  'outsideCell':excel_cell(outside_rows[0],column) if outside_rows else None,
                  'publishedTotalScope':'PeruAndExterior' if outside_rows else 'ReportedPeruTerritories',
                  'departmentCodeMethod':'mappedFromDepartmentName','zeroRule':'Explicit numeric zeros only'}
        if certified or column_certified:
            source['zeroRule']=('Printed dash certified by every department and company total plus the grand total'
                                if certified else 'Printed dash certified by the complete nonnegative institution column and published total; blanks never replaced')
            source['derivedZeroCells']={code:excel_cell(r,column) for code,r in department_rows.items() if (r,column) in certified or column_certified and r in column_dashes}
            source['dashCertification']=({'departmentMargins':len(department_rows),
                'companyMargins':next(i for i,value in enumerate(rows[header]) if normalized(value)=='total')-1,
                'grandTotalReconciled':True} if certified else {'institutionMarginReconciled':True,
                'departmentMargins':None,'companyMargins':1,'grandTotalReconciled':None})
        if not complete:source['missingDepartmentCells']=[code for code,value in counts.items() if value is None]
        records[identifier] = {'counts':counts,'total':territorial_total,'coverage':sum(value>0 for value in counts.values()) if complete else None,
                               'sourceTotal':published_total,'outsidePeru':outside,'category':REPORTS[report],
                               'sbsCode':None,'source':source}
    if not records:
        raise ValueError('Oficinas: el reporte no contiene entidades compatibles con su licencia')
    return records


def official_url(url):
    """Solo HTTPS en el dominio institucional; nunca usuarios, puertos o terceros."""
    try:
        parsed=urlparse(url)
        return (parsed.scheme=='https' and not parsed.username and not parsed.password
                and parsed.port in (None,443) and parsed.hostname is not None
                and (parsed.hostname=='sbs.gob.pe' or parsed.hostname.endswith('.sbs.gob.pe')))
    except ValueError:
        return False


def source_url(report, period, template=None):
    year, month = map(int, period.split('-'))
    folder, abbreviation = MONTHS[month-1]
    if template and official_url(template):
        parsed=urlparse(template)
        pattern=r'/20\d{2}/[^/]+/'+re.escape(report)+r'-[a-z]{2}20\d{2}\.xlsx?$'
        match=re.search(pattern,parsed.path,re.I)
        if match and not parsed.query:
            suffix=f'/{year}/{folder}/{report}-{abbreviation}{year}.XLS'
            return urlunparse(parsed._replace(path=parsed.path[:match.start()]+suffix,fragment=''))
    return f'https://intranet2.sbs.gob.pe/estadistica/financiera/{year}/{folder}/{report}-{abbreviation}{year}.XLS'


class PublishedLinks(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True);self.hrefs=[]

    def handle_starttag(self,tag,attributes):
        if tag.lower()=='a':
            href=dict(attributes).get('href')
            if href:self.hrefs.append(href)


def published_links(html,report,base_url):
    """Identifica mes y reporte en los enlaces fechados que publica el catálogo."""
    parser=PublishedLinks();parser.feed(html)
    links={};abbreviations={abbr:index for index,(_,abbr) in enumerate(MONTHS,1)}
    for href in parser.hrefs:
        url=urljoin(base_url,href)
        parsed=urlparse(url)
        # Los catálogos antiguos pueden enlazar HTTP; se usa el mismo recurso
        # oficial sobre TLS, sin alterar el host ni sus controles de acceso.
        if parsed.scheme=='http':url=urlunparse(parsed._replace(scheme='https'))
        if not official_url(url):continue
        parsed=urlparse(url)
        pattern=r'/(20\d{2})/([^/]+)/'+re.escape(report)+r'-([a-z]{2})(20\d{2})\.xlsx?$'
        match=re.search(pattern,parsed.path,re.I)
        if not match or match[1]!=match[4] or match[3].lower() not in abbreviations:continue
        month=abbreviations[match[3].lower()]
        names={normalized(MONTHS[month-1][0])}
        if month==9:names.add('septiembre')
        if normalized(match[2]) not in names:continue
        period=f'{match[1]}-{month:02}'
        if period in links and links[period]!=url:raise ValueError('Oficinas: enlaces publicados ambiguos para el mismo mes')
        links[period]=url
    return links


class NotPublished(FileNotFoundError):
    pass


class OfficialRedirects(HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, url):
        if not official_url(url):
            raise ValueError('Oficinas: redirección fuera del host oficial autorizado')
        return super().redirect_request(request,response,code,message,headers,url)


def discover_catalog(report,ledger):
    url='https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c='+report
    record={'kind':'catalog','report':report,'url':url,'checkedAt':datetime.now(timezone.utc).isoformat()}
    ledger['requests'].append(record)
    try:
        with build_opener(OfficialRedirects()).open(Request(url,headers={'Accept':'text/html'}),timeout=20) as response:
            body=response.read(2_000_001)
            record.update(httpStatus=response.status,finalUrl=response.geturl(),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
            if len(body)>2_000_000:raise ValueError('Oficinas: catálogo excesivo')
            html=body.decode('utf-8-sig',errors='replace')
            if any(marker in html.lower() for marker in ('incapsula','captcha','request unsuccessful')):
                record['status']='access_control'
                raise RuntimeError('Oficinas: el catálogo requiere controles de acceso; no se eluden')
            links=published_links(html,report,response.geturl())
            record.update(status='published_links' if links else 'no_monthly_links',links=len(links))
            return links
    except HTTPError as error:
        record.update(httpStatus=error.code,status='unavailable')
        if error.code in (401,403,429):
            record['status']='access_control'
            raise RuntimeError(f'Oficinas: HTTP {error.code} del catálogo; se detiene la consulta') from error
        return {}
    except (URLError,TimeoutError,OSError) as error:
        record.update(status='unavailable',error=str(error))
        return {}


def previous_source(data,report,period=None):
    sources=[(month,row['source'].get('url')) for records in (data or {}).get('series',{}).values()
             for month,row in records.items() if row.get('source',{}).get('report')==report and (period is None or month==period)]
    return max(sources,default=('',None),key=lambda pair:pair[0])[1]


def fetch(report, period, ledger, url=None):
    url = url or source_url(report,period)
    if not official_url(url):raise ValueError('Oficinas: enlace de descarga fuera del dominio oficial SBS')
    record = {'kind':'workbook','report':report,'period':period,'url':url,'checkedAt':datetime.now(timezone.utc).isoformat()}
    ledger['requests'].append(record)
    try:
        request = Request(url, headers={'Accept':'application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})
        with build_opener(OfficialRedirects()).open(request,timeout=25) as response:
            record.update(httpStatus=response.status,finalUrl=response.geturl(),contentType=response.headers.get('Content-Type'))
            if not official_url(response.geturl()):
                raise ValueError('Oficinas: redirección fuera del host oficial autorizado')
            body=response.read(20_000_001)
            if len(body)>20_000_000:raise ValueError('Oficinas: respuesta excesiva')
            record.update(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
            if not body.startswith((b'PK',b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1')):
                raise ValueError('Oficinas: respuesta no Excel; se conserva la base anterior')
            record['status']='downloaded'
            return body
    except HTTPError as error:
        record.update(httpStatus=error.code,status='not_published' if error.code in (404,410) else 'error')
        if error.code in (404,410):raise NotPublished(url) from error
        raise RuntimeError(f'Oficinas: HTTP {error.code}; se detiene la adquisición sin eludir el bloqueo') from error
    except (URLError,TimeoutError,OSError) as error:
        record.update(status='error',error=str(error))
        raise RuntimeError(f'Oficinas: no se pudo consultar el host oficial: {error}') from error
    except ValueError as error:
        record.update(status='error',error=str(error))
        raise


def latest_publication(report,ledger,template=None):
    """El Excel público conocido es independiente del HTML del catálogo."""
    ceiling=(date.today().replace(day=1)-timedelta(days=1)).strftime('%Y-%m')
    period=ceiling
    for attempt in range(6):
        url=source_url(report,period,template)
        try:
            return period,fetch(report,period,ledger,url=url),url,'known_public_dated_path',{}
        except NotPublished:
            period=previous_month(period)
    # Solo la ausencia404/410 de archivos permite buscar un enlace nuevo.
    # Un403/challenge del Excel aborta antes y nunca se resuelve por otra ruta.
    links=discover_catalog(report,ledger)
    available=[month for month in links if month<=ceiling]
    if not available:raise ValueError(f'Oficinas: no se verificó publicación reciente de {report}')
    period=max(available);url=links[period]
    try:body=fetch(report,period,ledger,url=url)
    except NotPublished as error:
        raise ValueError(f'Oficinas: el último enlace publicado de {report}/{period} no está disponible') from error
    return period,body,url,'published_href',links


def months(first,last):
    year,month=map(int,first.split('-'))
    while f'{year:04}-{month:02}' <= last:
        yield f'{year:04}-{month:02}'
        year,month=(year+1,1) if month==12 else (year,month+1)


def previous_month(period):
    year,month=map(int,period.split('-'))
    return f'{year-1:04}-12' if month==1 else f'{year:04}-{month-1:02}'


def raw_path(report,period):
    return RAW/report/f'{report}-{period}.XLS'


def atomic_bytes(path, body):
    path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix='.'+path.name+'.',suffix='.tmp',dir=path.parent,delete=False) as stream:
        temporary=Path(stream.name);stream.write(body)
    try:temporary.replace(path)
    finally:temporary.unlink(missing_ok=True)


def json_bytes(data):
    return (json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')


def publish(payloads):
    """Preparar todos los archivos y restaurar el estado previo si falla el commit."""
    prepared={};before={};committed=[]
    try:
        for path,body in payloads.items():
            path.parent.mkdir(parents=True,exist_ok=True)
            before[path]=path.read_bytes() if path.is_file() else None
            with tempfile.NamedTemporaryFile(prefix='.'+path.name+'.',suffix='.tmp',dir=path.parent,delete=False) as stream:
                prepared[path]=Path(stream.name);stream.write(body)
        for path,temporary in prepared.items():
            temporary.replace(path);committed.append(path)
    except BaseException:
        for path in reversed(committed):
            if before[path] is None:path.unlink(missing_ok=True)
            else:atomic_bytes(path,before[path])
        raise
    finally:
        for temporary in prepared.values():temporary.unlink(missing_ok=True)


def update(*, history=False, since='2012-01', offline=False):
    checked=datetime.now(timezone.utc).isoformat()
    ledger={'source':'oficinas','checkedAt':checked,'reports':{},'requests':[],'errors':[],'limitations':[]}
    path=OUTPUT/'oficinas_historico.json'
    old=None
    downloaded={};latest={};catalogs={};resolved={}
    try:
        loaded=json.loads(path.read_text(encoding='utf-8')) if path.is_file() else None
        if loaded is not None and not isinstance(loaded,dict):raise ValueError('Oficinas: base histórica no válida')
        old=loaded
        if old:validate_dataset(old)
        data=deepcopy(old) if old else {'schemaVersion':1,'unit':'oficinas',
            'territorialScope':'Perú: 24 departamentos y la Provincia Constitucional del Callao',
            'departments':[{'code':code,'name':name} for code,name in DEPARTMENTS],
            'series':{},'sources':[],'limitations':[]}
        if offline:
            missing=[report for report in REPORTS if not any((RAW/report).glob(report+'-????-??.XLS'))]
            if missing:
                ledger['limitations'].append('No hay originales locales suficientes de '+', '.join(missing))
                ledger.update(status='local_only',verification='local_only',changed=False,latestPublished=None,
                              latestProcessed=old.get('latestPeriod') if old else None,downloaded=0)
                consultation={'checkedAt':checked,'status':'local_only','verification':'local_only',
                    'message':'No hay originales locales suficientes; no se consultó la SBS',
                    'latestPeriod':old.get('latestPeriod') if old else None,'preservedPreviousBase':old is not None}
                return consultation
        for report,category in REPORTS.items():
            discovery='local_cache'
            if offline:
                available=sorted(p.stem[-7:] for p in (RAW/report).glob(report+'-????-??.XLS'))
                if not available:raise FileNotFoundError(f'Oficinas: no hay originales locales de {report}')
                last=available[-1];body=raw_path(report,last).read_bytes()
                resolved[report]=previous_source(old,report,last) or source_url(report,last)
            else:
                last,body,resolved[report],discovery,catalogs[report]=latest_publication(report,ledger,previous_source(old,report))
                downloaded[report,last]=body
            latest[report]=last
            parsed=parse_workbook(body,report,last,url=resolved[report])
            expected={identifier for identifier in BANKS if category_at(identifier,last)==category}
            if set(parsed)!=expected:
                raise ValueError(f'Oficinas: faltan entidades vigentes de {report}/{last}: {sorted(expected-set(parsed))}')
            for identifier,row in parsed.items():data['series'].setdefault(identifier,{})[last]=row
            ledger['reports'][report]={'latestPublished':None if offline else last,'latestProcessed':last,
                'verification':'local_only' if offline else 'official_http','url':resolved[report],
                'discovery':discovery}
        availability={'requestedSince':since,'licenseExcluded':[],'notPublished':[], 'unsupported':[], 'secondaryControlWarnings':[], 'missingComparables':{}}
        if history:
            for report,last in latest.items():
                for month in months(since,last):
                    if month==last:continue
                    expected={identifier for identifier in BANKS if category_at(identifier,month)==REPORTS[report]}
                    if not expected:
                        availability['licenseExcluded'].append({'report':report,'period':month})
                        continue
                    cached=raw_path(report,month)
                    url=(previous_source(old,report,month) or catalogs.get(report,{}).get(month)
                         or source_url(report,month,resolved[report]))
                    if cached.is_file():body=cached.read_bytes()
                    elif offline:
                        ledger['limitations'].append(f'{report}/{month}: original no disponible en caché');continue
                    else:
                        try:body=fetch(report,month,ledger,url=url)
                        except NotPublished:
                            availability['notPublished'].append({'report':report,'period':month})
                            ledger['limitations'].append(f'{report}/{month}: publicación no encontrada');continue
                        downloaded[report,month]=body
                    checks=[]
                    try:parsed=parse_workbook(body,report,month,url=url,strict=False,audit=checks)
                    except ValueError as error:
                        availability['unsupported'].append({'report':report,'period':month,'reason':str(error)})
                        ledger['limitations'].append(f'{report}/{month}: formato histórico no procesado: {error}')
                        continue
                    if checks:
                        availability['secondaryControlWarnings'].append({'report':report,'period':month,'warnings':checks})
                        ledger['limitations'].extend(f'{report}/{month}: {message}' for message in checks)
                    for identifier in sorted(expected-set(parsed)):
                        availability['missingComparables'].setdefault(identifier,[]).append(month)
                    for identifier,row in parsed.items():data['series'].setdefault(identifier,{})[month]=row
            availability['absenceDoesNotMeanZero']=True
            availability['note']='Se conservan ausencias de entidades no publicadas o sin denominación histórica acreditada; no se crean oficinas cero.'
            data['availability']=availability
        data['series']={identifier:dict(sorted(records.items())) for identifier,records in sorted(data['series'].items())}
        data['latestPeriod']=max(latest.values())
        data['sources']=[{'report':report,'category':category,'catalogUrl':'https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c='+report,
                          **ledger['reports'][report]} for report,category in REPORTS.items()]
        notes=list(ledger['limitations'])
        if data.get('availability',{}).get('missingComparables'):
            notes.append('Hay ausencias históricas de entidades no publicadas o sin denominación acreditada; no equivalen a cero oficinas.')
        if any(row['source'].get('unreportedDepartments') for records in data['series'].values() for row in records.values()):
            notes.append('Algunos reportes rurales históricos omiten departamentos; se conservan valores ausentes y cobertura no calculada, sin imputar ceros.')
        if any(row['source'].get('missingDepartmentCells') for records in data['series'].values() for row in records.values()):
            notes.append('Algunas celdas departamentales históricas están vacías o no tienen un cero verificable; se mantienen ausentes y no se calcula cobertura completa.')
        data['limitations']=sorted(set(notes))
        data['valueRevision']=value_revision(data)
        changed=old is None or old.get('valueRevision')!=data['valueRevision']
        data['checkedAt']=checked;data['updatedAt']=checked if changed else old.get('updatedAt',checked)
        validate_dataset(data)
        geometry=OUTPUT/'departamentos.geojson'
        if not geometry.is_file():raise ValueError('Oficinas: falta la cartografía departamental validada')
        geo=json.loads(geometry.read_text(encoding='utf-8'))
        if len(geo.get('features',[]))!=25 or {feature.get('properties',{}).get('code') for feature in geo['features']}!={code for code,_ in DEPARTMENTS}:
            raise ValueError('Oficinas: cartografía no válida')
        # Todo dato numérico anterior debe seguir presente; nunca completar huecos con cero.
        if old:
            for identifier,records in old['series'].items():
                for month,row in records.items():
                    current=data['series'].get(identifier,{}).get(month)
                    if current is None:raise ValueError('Oficinas: la nueva historia omite una observación previa')
                    for code,value in row['counts'].items():
                        if value is not None and current['counts'].get(code) is None:
                            raise ValueError('Oficinas: la nueva historia pierde datos departamentales válidos')
        stream=io.StringIO(newline='')
        fields=['periodo','institucion_id','institucion','categoria','codigo_sbs','departamento_codigo','departamento','oficinas','total_peru','exterior','total_fuente','reporte','url','sha256','hoja','celda']
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for identifier,records in data['series'].items():
            for month,row in records.items():
                for code,name in DEPARTMENTS:
                    writer.writerow(dict(zip(fields,[month,identifier,entity_metadata(identifier,month)['name'],row['category'],row.get('sbsCode'),code,name,
                        row['counts'][code],row['total'],row['outsidePeru'],row['sourceTotal'],row['source']['report'],row['source']['url'],
                        row['source']['sha256'],row['source']['sheet'],row['source']['cells'][code]])))
        # Los originales y productos se publican solo después de validar el conjunto.
        payloads={raw_path(report,month):body for (report,month),body in downloaded.items()}
        payloads[OUTPUT/'oficinas_departamentos.csv']=stream.getvalue().encode('utf-8-sig')
        payloads[path]=json_bytes(data)
        publish(payloads)
        ledger.update(status='local_only' if offline else 'ok',verification='local_only' if offline else 'official_http',
                      changed=changed,latestPublished=None if offline else max(latest.values()),
                      latestProcessed=max(latest.values()),downloaded=len(downloaded),valueRevision=data['valueRevision'])
        consultation={'checkedAt':checked,'status':'local_only' if offline else 'updated' if changed else 'unchanged',
                      'message':'Reprocesado local; no se consultó la SBS' if offline else 'Actualizado' if changed else 'Sin cambios',
                      'latestPeriod':data['latestPeriod'],'valueRevision':data['valueRevision'],
                      'verification':'local_only' if offline else 'official_http'}
    except Exception as error:
        ledger['errors'].append(str(error));ledger['status']='error';ledger['changed']=False
        consultation={'checkedAt':checked,'status':'error','message':str(error),
                      'latestPeriod':old.get('latestPeriod') if old else None,'preservedPreviousBase':old is not None}
        raise
    finally:
        ledger['detail']=consultation.get('message','')
        atomic_bytes(OUTPUT/'consulta_oficinas.json',json_bytes(consultation))
        atomic_bytes(IASPE/'Scraper/Actualizacion/output/descarga_oficinas.json',json_bytes(ledger))
    return consultation


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--latest',action='store_true',help='Consultar las publicaciones recientes de los tres reportes')
    parser.add_argument('--history',action='store_true',help='Adquirir historia mensual sin volver a descargar originales locales')
    parser.add_argument('--since',default='2012-01',help='Primer mes de historia compatible con el catálogo institucional')
    parser.add_argument('--solo-cache',action='store_true',help='Reprocesar solo originales locales; no acredita publicación reciente')
    args=parser.parse_args()
    if not re.fullmatch(r'20\d{2}-(?:0[1-9]|1[0-2])',args.since):parser.error('--since debe tener formato YYYY-MM')
    try:
        print(json.dumps(update(history=args.history,since=args.since,offline=args.solo_cache),ensure_ascii=False))
    except Exception as error:
        print(str(error),file=sys.stderr);return 1
    return 0


if __name__=='__main__':raise SystemExit(main())
