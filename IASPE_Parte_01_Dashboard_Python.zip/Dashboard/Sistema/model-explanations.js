/* Explicaciones de las variables e identidades; textos de lectura independientes de los cálculos. */
(() => {
  'use strict';
  const descriptions = {"01":{"dependent":"Crecimiento logarítmico anual del número total de tarjetas del mercado: 100 × ln(Nₜ / Nₜ₋₁).","terms":[{"label":"Constante","definition":"Intercepto del crecimiento estimado cuando las demás regresoras valen cero. Se mide en puntos del crecimiento de la dependiente.","motivation":"Permite que el crecimiento medio no quede forzado a pasar por el origen. No representa una tasa de equilibrio."},{"label":"PBI real anual (%)","definition":"Crecimiento real anual del PBI del mismo año, en %. No se aplica logaritmo a esta regresora.","motivation":"Se utiliza como indicador de actividad económica del mercado."}]},"02":{"dependent":"Crecimiento logarítmico anual del número de tarjetas de consumo del mercado: 100 × ln(Nₜ / Nₜ₋₁).","terms":[{"label":"Constante","definition":"Intercepto del crecimiento estimado cuando las demás regresoras valen cero. Se mide en puntos del crecimiento de la dependiente.","motivation":"Permite que el crecimiento medio no quede forzado a pasar por el origen. No representa una tasa de equilibrio."},{"label":"PBI real anual (%)","definition":"Crecimiento real anual del PBI del mismo año, en %. No se aplica logaritmo a esta regresora.","motivation":"Se utiliza como indicador de actividad económica del mercado."}]},"03":{"dependent":"Crecimiento logarítmico anual del flujo nominal de compras del mercado: 100 × ln(Cₜ / Cₜ₋₁).","terms":[{"label":"Constante","definition":"Intercepto del crecimiento estimado cuando las demás regresoras valen cero. Se mide en puntos del crecimiento de la dependiente.","motivation":"Permite que el crecimiento medio no quede forzado a pasar por el origen. No representa una tasa de equilibrio."},{"label":"PBI real anual (%)","definition":"Crecimiento real anual del PBI del mismo año, en %. No se aplica logaritmo a esta regresora.","motivation":"Se utiliza como indicador de actividad económica del mercado."},{"label":"Cambio del desempleo t−1 (p.p.)","definition":"Cambio de la tasa de desempleo entre los dos años anteriores, en puntos porcentuales.","motivation":"Incorpora deterioro o mejora previa del mercado laboral como información asociada a la capacidad de gasto."},{"label":"TPM t−1 (%)","definition":"Nivel de la tasa de política monetaria de diciembre del año anterior, en %.","motivation":"Incorpora condiciones monetarias previas, compatibles con un ajuste rezagado del uso del crédito."}]},"04":{"dependent":"Crecimiento logarítmico anual del número de tarjetas de Falabella: 100 × ln(Nₜ / Nₜ₋₁).","terms":[{"label":"Constante","definition":"Intercepto del crecimiento estimado cuando las demás regresoras valen cero. Se mide en puntos del crecimiento de la dependiente.","motivation":"Permite que el crecimiento medio no quede forzado a pasar por el origen. No representa una tasa de equilibrio."},{"label":"PBI real anual (%)","definition":"Crecimiento real anual del PBI del mismo año, en %. No se aplica logaritmo a esta regresora.","motivation":"Se utiliza como indicador de actividad económica del mercado."},{"label":"PBI real t−1 (%)","definition":"Crecimiento real anual del PBI del año anterior, en %.","motivation":"Incorpora información rezagada del ciclo económico. El desfase de un año es la especificación vigente, no una demora causal demostrada."},{"label":"Inflación t−1 (%)","definition":"Inflación al cierre del año anterior, en %.","motivation":"Controla el entorno de precios y poder adquisitivo previo; la relación estimada no separa esos canales."}]},"05":{"dependent":"Crecimiento logarítmico anual del saldo bruto de tarjetas de Falabella: 100 × ln(Sₜ / Sₜ₋₁).","terms":[{"label":"Constante","definition":"Intercepto del crecimiento estimado cuando las demás regresoras valen cero. Se mide en puntos del crecimiento de la dependiente.","motivation":"Permite que el crecimiento medio no quede forzado a pasar por el origen. No representa una tasa de equilibrio."},{"label":"Crecimiento log de compras t−1 (%)","definition":"100 ln(C_{t-1}/C_{t-2}); crecimiento logarítmico de las compras del MERCADO del año anterior, en %. Lee el resultado del modelo de compras.","motivation":"Aporta una medida del uso previo de tarjetas. Compras del mercado y saldo propio de Falabella tienen cobertura distinta."},{"label":"PBI real t−1 (%)","definition":"Crecimiento real anual del PBI del año anterior, en %.","motivation":"Incorpora información rezagada del ciclo económico. El desfase de un año es la especificación vigente, no una demora causal demostrada."},{"label":"Desempleo anual (%)","definition":"Tasa de desempleo del mismo año, en %.","motivation":"Aporta información del mercado laboral asociada a capacidad de pago y demanda de crédito; el modelo no identifica esos canales por separado."}]},"06":{"dependent":"Variación anual del saldo de préstamos no revolventes: saldo de diciembre t menos saldo de diciembre t−1, en S/ millones.","terms":[{"label":"Constante","definition":"Intercepto de la variación anual del saldo, medido en S/ millones.","motivation":"Permite un cambio anual de cartera distinto de cero aun cuando las otras regresoras sean cero."},{"label":"Aceleración del PBI rezagada (pp)","definition":"Crecimiento real anual del PBI en t−1 menos su crecimiento en t−2, en puntos porcentuales.","motivation":"La aceleración previa de la actividad económica aproxima el impulso de la demanda de financiamiento de consumo."},{"label":"Dicotómica SBS 2021","definition":"Vale 1 exclusivamente en 2021 y 0 en todos los demás años.","motivation":"Controla la reclasificación de operaciones no revolventes que genera un salto contable en 2021; no se repite como flujo futuro."},{"label":"Compras con tarjetas del mercado, t−1","definition":"Volumen anual de compras con tarjetas de crédito del mercado, rezagado un año, tomado del Modelo 03.","motivation":"Indicador observable de actividad de consumo y utilización de productos crediticios; distinto del saldo propio del banco."}]},"07":{"dependent":"Saldo bruto consolidado: tarjetas de crédito más préstamos de consumo no revolventes, utilizando los cierres de diciembre.","terms":[{"label":"Saldo bruto de tarjetas","definition":"Saldo bruto de tarjetas de Falabella al cierre, S/ millones.","motivation":"Primer componente del consolidado."},{"label":"Préstamos no revolventes","definition":"Saldo de préstamos de consumo no revolventes al cierre, S/ millones.","motivation":"Segundo componente del consolidado."}]},"10":{"dependent":"Obligaciones con el público: suma de ahorro, plazo, depósitos restringidos y otras obligaciones. La participación de plazo se calcula como 100 × plazo / obligaciones.","terms":[{"label":"Depósitos de ahorro","definition":"Depósitos de ahorro, S/ millones.","motivation":"Componente del fondeo."},{"label":"Depósitos a plazo, incluida CTS","definition":"Depósitos a plazo, incluida CTS, S/ millones.","motivation":"Componente del fondeo."},{"label":"Depósitos restringidos","definition":"Depósitos restringidos, S/ millones.","motivation":"Componente del fondeo."},{"label":"Otras obligaciones","definition":"Otras obligaciones con el público, S/ millones.","motivation":"Componente del fondeo."},{"label":"Participación de depósitos a plazo","definition":"100×plazo/obligaciones al cierre de diciembre, en %.","motivation":"Resume la mezcla de fondeo que alimenta la ecuación de costo."}]},"11":{"dependent":"Costo implícito anualizado de obligaciones con el público, observado al cierre de diciembre, en %.","terms":[{"label":"Constante","definition":"Intercepto de la tasa o rendimiento estimado cuando las demás regresoras valen cero; unidad: puntos porcentuales.","motivation":"Da flexibilidad al nivel de la ecuación; su valor aislado no es una tasa objetivo ni de equilibrio."},{"label":"Costo rezagado t−1 (%)","definition":"Costo implícito de diciembre del año anterior, en %.","motivation":"Recoge persistencia del costo de fondeo."},{"label":"TPM diciembre t (%)","definition":"Nivel de la tasa de política monetaria de diciembre del mismo año, en %.","motivation":"Representa las condiciones monetarias de referencia; el traspaso a tasas o actividad es una hipótesis económica."},{"label":"Participación plazo diciembre t (%)","definition":"Participación de depósitos a plazo sobre obligaciones al cierre: 100×P_t/O_t, en %.","motivation":"Incorpora la mezcla de productos de fondeo; cambios en la proporción a plazo pueden asociarse a cambios del costo medio."}]},"13":{"dependent":"Tasa activa de tarjetas del mercado a diciembre, en %.","terms":[{"label":"Constante","definition":"Intercepto de la tasa o rendimiento estimado cuando las demás regresoras valen cero; unidad: puntos porcentuales.","motivation":"Da flexibilidad al nivel de la ecuación; su valor aislado no es una tasa objetivo ni de equilibrio."},{"label":"Tasa de mercado rezagada","definition":"Tasa activa de tarjetas del mercado de diciembre del año anterior, en %.","motivation":"Recoge persistencia en la tasa."},{"label":"TPM de diciembre","definition":"Nivel de la tasa de política monetaria de diciembre del mismo año, en %.","motivation":"Representa las condiciones monetarias de referencia; el traspaso a tasas o actividad es una hipótesis económica."},{"label":"Crecimiento del PBI rezagado","definition":"Crecimiento real anual del PBI del año anterior, en %.","motivation":"Incorpora información rezagada del ciclo económico. El desfase de un año es la especificación vigente, no una demora causal demostrada."}]},"14":{"dependent":"Tasa activa de préstamos de consumo del mercado a más de 360 días, diciembre, en %.","terms":[{"label":"Constante","definition":"Intercepto de la tasa o rendimiento estimado cuando las demás regresoras valen cero; unidad: puntos porcentuales.","motivation":"Da flexibilidad al nivel de la ecuación; su valor aislado no es una tasa objetivo ni de equilibrio."},{"label":"Tasa de mercado rezagada","definition":"La misma tasa activa de diciembre del año anterior, en %.","motivation":"Recoge persistencia de esa tasa de mercado."},{"label":"TPM de diciembre","definition":"Nivel de la tasa de política monetaria de diciembre del mismo año, en %.","motivation":"Representa las condiciones monetarias de referencia; el traspaso a tasas o actividad es una hipótesis económica."}]},"15":{"dependent":"Tasa pasiva del mercado a 181–360 días, diciembre, en %.","terms":[{"label":"Constante","definition":"Intercepto de la tasa o rendimiento estimado cuando las demás regresoras valen cero; unidad: puntos porcentuales.","motivation":"Da flexibilidad al nivel de la ecuación; su valor aislado no es una tasa objetivo ni de equilibrio."},{"label":"TPM de diciembre","definition":"Nivel de la tasa de política monetaria de diciembre del mismo año, en %.","motivation":"Representa las condiciones monetarias de referencia; el traspaso a tasas o actividad es una hipótesis económica."},{"label":"Inflación rezagada","definition":"Inflación al cierre del año anterior, en %.","motivation":"Controla el entorno de precios y poder adquisitivo previo; la relación estimada no separa esos canales."}]},"10_restringidos":{"dependent":"Saldo de cierre anual, en S/ millones. Para 2026 se utiliza el crecimiento observado entre junio y agosto de 2025 y 2026.","terms":[{"label":"Cierre de diciembre 2025","definition":"Último saldo anual completo observado.","motivation":"Base contable de la proyección 2026."},{"label":"Crecimiento interanual junio–agosto","definition":"Promedio de junio–agosto 2026 dividido entre el mismo trimestre móvil de 2025, menos uno.","motivation":"Evita extender patrones de meses no comparables al cierre de 2026."},{"label":"Participación sobre M08 + M09","definition":"Saldo estimado 2026 dividido entre ahorro y plazo de 2026.","motivation":"La cuenta menor sigue los saldos proyectados por los modelos econométricos de depósitos, sin una regresión nueva."}]},"10_otras":{"dependent":"Saldo de cierre anual, en S/ millones. Para 2026 se utiliza el crecimiento observado entre junio y agosto de 2025 y 2026.","terms":[{"label":"Cierre de diciembre 2025","definition":"Último saldo anual completo observado.","motivation":"Base contable de la proyección 2026."},{"label":"Crecimiento interanual junio–agosto","definition":"Promedio de junio–agosto 2026 dividido entre el mismo trimestre móvil de 2025, menos uno.","motivation":"Evita extender patrones de meses no comparables al cierre de 2026."},{"label":"Participación sobre M08 + M09","definition":"Saldo estimado 2026 dividido entre ahorro y plazo de 2026.","motivation":"La cuenta menor sigue los saldos proyectados por los modelos econométricos de depósitos, sin una regresión nueva."}]}};

  const escapeKey=(model)=>String(model.id||'');
  const detailTerms={
    '08_mn':[
      ['Constante','Intercepto estimado en puntos de variación anual del ahorro en moneda nacional.','Permite un crecimiento base distinto de cero.' ],
      ['Producto bruto interno del año anterior','Crecimiento real anual del producto bruto interno observado o proyectado para el año previo, en puntos porcentuales.','Representa las condiciones generales de actividad con las que se relaciona el ahorro.' ],
      ['Inflación del año anterior','Variación anual de precios correspondiente al año precedente, expresada en porcentaje.','Incorpora el entorno previo de precios y de valor real de los depósitos.' ],
      ['Indicador de 2024 y 2025','Variable que vale uno durante 2024 y 2025, y cero fuera de ese intervalo.','Permite separar el patrón de crecimiento observado en esos dos años del resto de la muestra.' ]
    ],
    '08_me':[
      ['Constante','Intercepto del crecimiento logarítmico anual del ahorro en moneda extranjera.','Recoge la variación base del saldo.' ],
      ['Cambio rezagado del tipo de cambio','Diferencia en el tipo de cambio de cierre entre los dos años anteriores al proyectado. Se usa el cambio de nivel y no una tasa porcentual.','Relaciona el comportamiento del saldo en moneda extranjera con los movimientos previos del mercado cambiario.' ]
    ],
    '09_plazo':[
      ['Constante','Intercepto del crecimiento porcentual de los depósitos a plazo ordinarios.','Deja un término base no explicado por las variables macroeconómicas.' ],
      ['Producto bruto interno rezagado','Crecimiento real del producto bruto interno correspondiente al año anterior.','Aporta información de actividad y de recursos disponibles para depósitos a plazo.' ],
      ['Inflación rezagada','Tasa de inflación anual correspondiente al año previo.','Considera las condiciones de precios vinculadas a la decisión de mantener recursos a plazo.' ],
      ['Cambio de tasa de política monetaria','Diferencia entre la tasa de política monetaria de diciembre actual y la de diciembre del año anterior, medida en puntos porcentuales.','Permite que la variación de las condiciones monetarias se relacione con la captación a plazo.' ]
    ],
    '09_cts':[
      ['Constante','Intercepto del crecimiento porcentual anual del saldo de compensación por tiempo de servicios.','Permite un crecimiento base de la cuenta.' ],
      ['Indicador de 2021','Vale uno en 2021 y cero para el resto de los años.','Recoge la discontinuidad histórica de 2021 sin extenderla a los años futuros.' ]
    ],
    '11':[
      ['Constante','Intercepto de la tasa implícita de costo, expresado en puntos porcentuales.','Permite ajustar el nivel de costo estimado.' ],
      ['Costo del año anterior','Tasa de costo implícita de obligaciones con el público registrada en diciembre anterior, en porcentaje.','Representa la persistencia de la remuneración del fondeo entre ejercicios.' ],
      ['Tasa de política monetaria de diciembre','Nivel de la tasa de referencia del Banco Central de Reserva del Perú al cierre del año, en porcentaje.','Relaciona el costo de captación con las condiciones monetarias vigentes.' ],
      ['Participación de depósitos a plazo','Porcentaje de depósitos a plazo dentro del saldo total de obligaciones con el público al cierre de diciembre.','Representa la composición del fondeo, ya que los productos de captación tienen costos diferentes.' ]
    ],
    '12_entidades':[
      ['Constante','Intercepto de la regresión del logaritmo del gasto anual incrementado en 0,05.','Permite un nivel base distinto de cero en la escala transformada.' ],
      ['Tasa de política monetaria','Tasa de referencia empleada para el año proyectado, expresada en porcentaje.','Representa las condiciones de tasas que pueden estar asociadas al costo de depósitos de otras instituciones.' ],
      ['Inflación','Inflación anual correspondiente al ejercicio, en porcentaje.','Incorpora el entorno nominal que puede acompañar el precio del fondeo.' ]
    ],
    '12_adeudos':[
      ['Constante','Intercepto del gasto anual por adeudos expresado en millones de soles.','Recoge el nivel base del gasto.' ],
      ['Tasa de política monetaria','Nivel de la tasa de política monetaria del ejercicio, en porcentaje.','Relaciona el gasto por adeudos con el precio de referencia del financiamiento.' ],
      ['Indicador de 2020 y 2021','Vale uno en esos dos años y cero en el resto.','Distingue las observaciones afectadas por el entorno excepcional de ese periodo.' ]
    ],
    '12_otras':[
      ['Constante','Intercepto del logaritmo de uno más el gasto anual de otras fuentes.','Permite una referencia base en la escala transformada.' ],
      ['Tasa de política monetaria rezagada','Tasa de política monetaria registrada al cierre del año anterior.','Relaciona el gasto de otras fuentes con las condiciones monetarias previas.' ]
    ],
    '16_creditos':[
      ['Constante','Intercepto del rendimiento anual implícito de la cartera, en puntos porcentuales.','Recoge el nivel base de rentabilidad de los créditos.' ],
      ['Tasa de tarjetas del mercado','Tasa activa de tarjetas de crédito del mercado estimada por el modelo de tasas, correspondiente al mismo año.','Ofrece una referencia de precio para explicar el rendimiento propio de la cartera.' ],
      ['Indicador de 2020','Toma el valor uno únicamente en 2020 y cero en los demás años.','Permite un desplazamiento específico del rendimiento durante ese año.' ],
      ['Indicador de 2021','Toma el valor uno únicamente en 2021 y cero en los demás años.','Distingue el segundo año del periodo excepcional sin prolongar el ajuste al futuro.' ]
    ],
    '16_disponible':[
      ['Constante','Intercepto de la ecuación para el logaritmo de los ingresos anuales por disponibilidades.','Permite un nivel base en la escala logarítmica.' ],
      ['Producto bruto interno del año','Crecimiento real anual de la producción del mismo ejercicio, en porcentaje.','Relaciona el ingreso financiero con la actividad económica contemporánea.' ],
      ['Logaritmo del ingreso anterior','Logaritmo natural del ingreso por disponibilidades acumulado durante el ejercicio precedente.','Incorpora la persistencia histórica del flujo de ingresos.' ]
    ],
    '16_interbancarios':[
      ['Constante','Intercepto del logaritmo del ingreso anual por fondos interbancarios.','Determina el punto de partida del flujo en la escala de la regresión.' ],
      ['Indicador de 2020 y 2021','Toma el valor uno en 2020 y 2021 y cero en los demás ejercicios.','Recoge la diferencia observada en los ingresos de esos años sin aplicarla a períodos posteriores.' ]
    ],
    '17_caja':[
      ['Constante','Intercepto del saldo mensual de caja, en la unidad monetaria del modelo.','Permite un nivel base no condicionado por el saldo previo.' ],
      ['Saldo de caja del mes anterior','Saldo de caja observado o proyectado para el mes inmediatamente anterior.','Representa la continuidad mensual de una partida de activo con persistencia entre cierres.' ]
    ],
    '18_diversos':[
      ['Constante del primer modelo','Intercepto de la primera regresión de crecimiento de ingresos diversos.','Permite un crecimiento base en la primera trayectoria.' ],
      ['Inflación anual','Inflación del mismo año, expresada en porcentaje.','Relaciona el crecimiento de ingresos con las condiciones nominales de la economía.' ],
      ['Indicador de 2018','Vale uno en el año 2018 y cero en los restantes.','Permite controlar una diferencia específica de la serie histórica en ese año.' ],
      ['Indicador de 2020 y 2021','Vale uno en los años 2020 y 2021 y cero en los restantes.','Recoge una discontinuidad histórica sin proyectar ese indicador en el futuro.' ],
      ['Constante del segundo modelo','Intercepto de la regresión alternativa vinculada a compras con tarjetas.','Permite un crecimiento base en la segunda trayectoria.' ],
      ['Crecimiento de compras con tarjetas','Crecimiento anual del flujo de compras con tarjetas del mercado que proporciona el modelo de compras.','Relaciona los ingresos diversos con el uso de tarjetas.' ]
    ],
    '19_personal':[
      ['Constante','Intercepto del crecimiento logarítmico anual del número de trabajadores.','Permite una variación base en la dotación.' ],
      ['Producto bruto interno anual','Crecimiento real de la actividad económica del mismo año.','Relaciona la evolución del personal con el nivel de actividad.' ],
      ['Indicador de 2020 y 2021','Vale uno en los ejercicios 2020 y 2021 y cero en los demás.','Distingue el comportamiento excepcional de la plantilla en ese periodo.' ]
    ],
    '19_terceros':[
      ['Constante del modelo de crecimiento','Intercepto de la regresión del crecimiento logarítmico anual del gasto por servicios de terceros.','Permite un crecimiento base en la primera trayectoria.' ],
      ['Producto bruto interno anual','Crecimiento real del producto bruto interno durante el ejercicio, expresado en porcentaje.','Relaciona la evolución de servicios contratados con la actividad económica.' ]
    ],
    '31':[
      ['Constante','Intercepto del crecimiento logarítmico anual de las cuentas por cobrar netas.','Permite una variación base de la partida.' ],
      ['Producto bruto interno anual','Crecimiento real anual de la economía en el mismo ejercicio, en porcentaje.','Relaciona las cuentas por cobrar con la actividad económica.' ]
    ],
    '32':[
      ['Constante','Intercepto de la variación anual de rendimientos por cobrar, en millones de soles.','Permite un movimiento base de la cuenta.' ],
      ['Variación de ingresos por créditos','Diferencia entre los ingresos anuales por créditos del ejercicio actual y el anterior.','Relaciona los intereses devengados pendientes de cobro con la evolución de los ingresos financieros de cartera.' ]
    ]
  };

  /* Lectura detallada de identidades, para no presentar sus componentes como una regresión. */
  const derivedTerms={
    '16_rev':[
      ['Ingresos por créditos totales', 'Flujo anual calculado por el componente de créditos del Modelo 16 mediante rendimiento implícito por saldo promedio. No es una cifra tomada de las proyecciones desagregadas del Anexo IASPE.', 'Es el importe agregado que se debe distribuir sin modificar su total.'],
      ['Participación observada de ingresos revolventes en 2025', '717,3815149 dividido entre 1.149,16032273 millones, según las filas 61 y 55 del Anexo_1 de 2025. Resultado cercano a 62,4266 por ciento.', 'Ancla la apertura en un dato efectivamente observado, en lugar de extrapolar el presupuesto por producto.'],
      ['Participación del capital revolvente', 'Capital promedio de los doce meses de REVOLVING dividido entre el capital promedio conjunto de REVOLVING y CUOTAS, sumando los tres stages de Libro1.xlsx. En 2026 se completan noviembre y diciembre.', 'Aproxima cómo cambia el peso relativo del crédito revolvente. No es el rendimiento de una cartera.'],
      ['Variación anual de la participación', 'Promedio de las diferencias en puntos porcentuales entre 2024 y 2025, y entre 2025 y 2026. Para 2027 en adelante el incremento anual aplicado es aproximadamente 0,3846 puntos porcentuales.', 'Evita mantener una participación fija, pero es un supuesto de distribución y no un efecto causal estimado.']
    ],
    '16_nrev':[
      ['Ingresos totales por créditos', 'Ingreso anual obtenido del Modelo 16, previo a cualquier apertura por modalidad.', 'Mantener este importe permite conciliar las dos categorías con el total de ingresos por créditos.'],
      ['Ingresos revolventes del mismo año', 'Ingresos totales multiplicados por la participación revolvente anclada en IASPE 2025 y actualizada con los cambios de capital de Libro1.xlsx.', 'La diferencia evita asignar dos veces el mismo ingreso.'],
      ['Residual de otros ingresos por créditos', 'En 2025 la resta entre los ingresos totales y los ingresos revolventes incluye aproximadamente 0,7063 millones de otros créditos. No se trata de intereses no revolventes puros.', 'Evita presentar el saldo residual como una desagregación estrictamente observada de préstamos no revolventes.']
    ],
    '07':[
      ['Colocaciones revolventes de tarjetas','Saldo bruto de consumo revolvente del banco al cierre de diciembre del ejercicio, procedente del modelo de tarjetas.','Representa el financiamiento revolvente que sigue la dinámica de utilización de tarjetas.'],
      ['Colocaciones no revolventes','Saldo bruto de préstamos de consumo no revolventes del mismo diciembre, procedente del modelo de préstamos.','Completa la cartera de consumo con créditos que tienen un esquema de pago distinto al revolvente.']
    ],
    '08':[
      ['Ahorro en moneda nacional','Saldo de captaciones de ahorro en moneda nacional de diciembre, después de aplicar el crecimiento anual proyectado de esa moneda.','Permite mantener el comportamiento específico del ahorro doméstico.'],
      ['Ahorro en moneda extranjera','Saldo consolidado de ahorro en moneda extranjera de diciembre, según su especificación de tipo de cambio y su conversión de presentación.','Incluye la captación en moneda extranjera sin mezclar tasas de crecimiento distintas.']
    ],
    '09':[
      ['Depósitos a plazo ordinarios','Saldo de los productos de plazo ordinario de diciembre, incluyendo la trayectoria anual y los ajustes de captación aplicables.','Representa el fondeo contractual distinto de la compensación por tiempo de servicios.'],
      ['Depósitos de compensación por tiempo de servicios','Saldo de diciembre del producto de compensación por tiempo de servicios, calculado por separado.','Mantiene identificado un producto sujeto a una dinámica histórica y estacional diferente.']
    ],
    '10':[
      ['Depósitos de ahorro','Suma de saldos de ahorro en moneda nacional y extranjera del cierre de diciembre.','Constituye una fuente principal de fondeo a la vista.'],
      ['Depósitos a plazo','Suma de depósitos ordinarios y de compensación por tiempo de servicios del mismo cierre.','Representa la captación a plazo y sirve para calcular su participación en el fondeo.'],
      ['Depósitos restringidos','Saldo de depósitos sujetos a restricciones de disponibilidad, proyectado por separado.','Completa el total de obligaciones sin incorporarlos indebidamente a los depósitos de libre disponibilidad.'],
      ['Otras obligaciones','Saldo de las demás obligaciones con el público, proyectado por separado.','Evita omitir componentes de fondeo distintos de ahorro, plazo y restringidos.']
    ],
    '12':[
      ['Intereses por obligaciones con el público','Gasto anual calculado con los saldos de depósitos, el costo implícito y la calibración histórica.','Representa la remuneración de las captaciones del público.'],
      ['Intereses por depósitos de entidades financieras','Gasto anual proyectado mediante la especificación logarítmica y las condiciones monetarias.','Identifica por separado el financiamiento recibido de otras instituciones financieras.'],
      ['Intereses por adeudos','Gasto anual proyectado en niveles con la tasa de política monetaria y el indicador histórico.','Reconoce el costo de las obligaciones por adeudos.'],
      ['Intereses por otras fuentes','Gasto anual obtenido de la regresión transformada y su recuperación a niveles.','Incluye los intereses que no pertenecen a las otras tres fuentes.']
    ],
    '12_obligaciones':[
      ['Saldo promedio de obligaciones','Promedio aritmético del saldo de obligaciones con el público del cierre anterior y del cierre proyectado.','Aproxima el volumen de recursos que origina intereses durante el año.'],
      ['Costo promedio implícito','Promedio aritmético de las tasas de costo de obligaciones de ambos cierres anuales, expresadas en porcentaje.','Representa el precio aplicado al saldo de financiamiento.'],
      ['Factor histórico de calibración','Mediana de los factores anuales de 2015 a 2026. Cada factor relaciona el gasto anual registrado, o el cierre supuesto de 2026, con el gasto aproximado mediante saldos y costos medios.','Incluye expresamente 2026 en la calibración sin presentarlo como un año observado. Ajusta la escala de la identidad contable sin introducir una regresión adicional.']
    ],
    '16':[
      ['Ingresos por créditos','Flujo anual de ingresos de cartera obtenido a partir del rendimiento implícito y del saldo promedio de colocaciones.','Representa los intereses generados por los créditos directos.'],
      ['Ingresos por inversiones','Flujo anual obtenido aplicando el rendimiento del año base al promedio de las inversiones.','Incorpora intereses y rendimientos de la cartera de inversiones.'],
      ['Ingresos por disponibilidades','Flujo anual obtenido de la proyección logarítmica de ingresos por saldos disponibles.','Reconoce la rentabilidad de las posiciones de liquidez.'],
      ['Ingresos por fondos interbancarios','Flujo anual calculado con la especificación correspondiente al ingreso por interbancarios.','Incluye intereses de colocaciones interbancarias.']
    ],
    '17':[
      ['Caja','Saldo de diciembre obtenido de la proyección autorregresiva mensual.','Representa el efectivo mantenido en caja.'],
      ['Bancos y corresponsales','Saldo de depósitos y disponibilidades bancarias que se concilia con el balance.','Permite que el activo total cuadre con la suma de pasivo y patrimonio.'],
      ['Canje','Saldo de canje de diciembre, construido con el último dato disponible y los supuestos posteriores.','Conserva por separado los recursos pendientes de compensación.'],
      ['Otros disponibles','Saldo de otras posiciones disponibles a diciembre.','Incluye disponibilidades que no se clasifican como caja, bancos o canje.']
    ],
    '18':[
      ['Ingresos diversos','Ingreso anual proyectado con la combinación de dos regresiones de crecimiento.','Representa las fuentes principales de ingresos por servicios.'],
      ['Otros ingresos','Flujo anual de otros ingresos financieros por servicios del consolidado.','Completa el ingreso de servicios con conceptos no incluidos en ingresos diversos.'],
      ['Gastos diversos','Gasto anual vinculado a los ingresos diversos mediante la proporción del año base.','Reconoce los costos operativos directamente asociados a dichos ingresos.'],
      ['Otros gastos','Gasto anual adicional de servicios según la serie presupuestada.','Completa los egresos de servicios que se restan para obtener el resultado neto.']
    ],
    '19':[
      ['Gastos de personal','Flujo anual de remuneraciones construido a partir del gasto base, la plantilla promedio y la inflación.','Relaciona una parte central de los costos operativos con la dotación laboral.'],
      ['Servicios de terceros','Gasto anual de contrataciones externas obtenido combinando dos trayectorias de proyección.','Representa la contratación de servicios operativos a terceros.'],
      ['Gastos de directorio','Gasto anual de directorio mantenido conforme al presupuesto del componente.','Permite incorporar esta obligación administrativa diferenciada.'],
      ['Impuestos y contribuciones','Gasto presupuestado y posteriormente actualizado con la inflación anual.','Incluye los conceptos tributarios y contribuciones contabilizados como gastos administrativos.']
    ],
    '20':[
      ['Consorcios y empresas asociadas','Resultados anuales de consorcios y de subsidiarias y asociadas según sus proyecciones originales.','Reconoce resultados financieros que no proceden de intereses de créditos.'],
      ['Diferencia de cambio y derivados','Resultados de mercado previstos de cada año, con la relación de diferencia de cambio sobre compras y el componente derivado.','Representa movimientos financieros vinculados a monedas y derivados.'],
      ['Inversiones y otros resultados','Resultados de inversiones, ventas de cartera y otras operaciones financieras del consolidado.','Completa el resultado financiero con las fuentes restantes.']
    ],
    '21':[
      ['Inversiones disponibles para la venta','Saldo al cierre procedente de la trayectoria del presupuesto de Tesorería.','Representa la cartera de inversiones que responde al plan de gestión de tesorería.'],
      ['Inversiones en subsidiarias','Saldo de inversiones en subsidiarias del cierre correspondiente.','Identifica participaciones que forman parte del activo de inversión.'],
      ['Otras inversiones','Saldo de las restantes inversiones financieras según la fuente original.','Completa el total invertido sin duplicar posiciones ya clasificadas.']
    ],
    '23':[
      ['Ingresos financieros por intereses','Total anual de ingresos por intereses proyectados en el modelo de ingresos financieros.','Constituye la fuente positiva del margen financiero bruto.'],
      ['Gastos financieros por intereses','Total anual de gasto por intereses asociado a las fuentes de fondeo.','Se deduce para reflejar el costo financiero de generar los ingresos.']
    ],
    '30':[
      ['Número de tarjetas previsto','Cantidad de tarjetas de crédito del banco al cierre del ejercicio proyectado.','Aproxima la dimensión de la base de clientes que dispone de líneas de crédito.'],
      ['Relación histórica de líneas por tarjeta','Promedio de las razones entre líneas no utilizadas y tarjetas de los tres años anteriores.','Permite vincular el saldo contingente con la utilización histórica de líneas por tarjeta.']
    ],
    '45':[
      ['Resultados acumulados anteriores','Saldo de utilidades retenidas al cierre del ejercicio previo.','Sirve como base del movimiento patrimonial de resultados acumulados.'],
      ['Utilidad del ejercicio anterior aplicable','Importe del resultado neto del ejercicio anterior que se traslada al saldo acumulado.','Incorpora las utilidades disponibles que pueden permanecer en el patrimonio.'],
      ['Transferencia a reservas','Movimiento de resultados acumulados hacia las reservas del patrimonio.','Se resta para no contabilizar simultáneamente el mismo importe como reserva y resultado acumulado.'],
      ['Dividendos distribuidos','Importe aprobado de dividendos con el límite de resultados disponibles.','Reconoce la distribución de utilidades que reduce el patrimonio retenido.']
    ],
    '46':[
      ['Resultado neto del ejercicio','Utilidad neta anual del estado de resultados obtenida del modelo de cierre de resultados.','La misma utilidad debe figurar en el patrimonio sin duplicación ni una nueva estimación.']
    ],
    '47':[
      ['Activos distintos de bancos y corresponsales','Suma de los demás activos previstos de diciembre, incluidos cartera, disponible distinto de bancos, inversiones y otras cuentas.','Permite identificar la porción de activos fijada por las demás proyecciones.'],
      ['Pasivos totales','Suma de las obligaciones y demás pasivos del mismo cierre anual.','Representa las fuentes de financiamiento de terceros que deben estar respaldadas por activos.'],
      ['Patrimonio','Suma de capital, reservas, ajustes y resultados correspondientes al ejercicio.','Completa las fuentes de financiamiento del activo mediante fondos propios.'],
      ['Ajuste de bancos y corresponsales','Diferencia residual que se incorpora al saldo de bancos cuando activo y pasivo más patrimonio no coinciden antes del cierre.','Permite verificar la igualdad contable sin modificar los restantes saldos proyectados.']
    ],
    '48_cuota':[
      ['Consumo revolvente de Falabella','Saldo bruto de tarjetas de crédito de Falabella al cierre de diciembre.','Aporta la porción revolvente de la cartera de consumo del banco.'],
      ['Consumo no revolvente de Falabella','Saldo bruto de créditos de consumo no revolventes de Falabella al cierre del mismo año.','Completa el numerador con el resto de préstamos de consumo.'],
      ['Consumo de toda la banca múltiple','Saldo bruto total de consumo de las entidades de banca múltiple en el mismo diciembre.','Permite medir la participación del banco con un denominador de mercado comparable.']
    ],
    '49':[
      ['Saldo de consumo al inicio del año','Saldo bruto de la cartera al cierre de diciembre del año anterior.','Representa el saldo que debe explicarse al comenzar la conciliación anual.'],
      ['Compras con tarjetas','Flujo anual de consumos con tarjetas de Falabella calculado con las variables de mercado y la calibración histórica.','Incrementa la cartera revolvente por utilización de tarjetas.'],
      ['Disposiciones de RappiCash','Flujo de disposiciones del producto RappiCash durante el ejercicio.','Incorpora nuevas utilizaciones de crédito revolvente distintas de compras.'],
      ['Desembolsos de préstamos','Flujo anual de desembolsos de consumo no revolvente.','Incorpora los créditos nuevos que aumentan la cartera no revolvente.'],
      ['Saldo de consumo al cierre y castigos','Saldo bruto final de diciembre y montos castigados durante el ejercicio, que se restan de las entradas.','Permite obtener por diferencia las salidas atribuibles a amortizaciones sin confundirlas con castigos.']
    ],
    '49_rev':[
      ['Saldo revolvente inicial y final','Saldos de consumo revolvente de diciembre del ejercicio previo y del ejercicio analizado.','Identifican el cambio de stock que debe conciliarse con los flujos.'],
      ['Compras y disposiciones','Compras de tarjetas de Falabella y disposiciones anuales de RappiCash.','Son entradas nuevas a la cartera revolvente y se suman al saldo inicial.'],
      ['Castigos revolventes','Importes retirados por castigo de cartera revolvente durante el ejercicio.','Se separan de la amortización para no contabilizarlos como pagos recibidos.']
    ],
    '49_nrev':[
      ['Saldo no revolvente inicial y final','Saldos brutos de préstamos de consumo no revolventes al inicio y al cierre del ejercicio.','Miden el cambio de cartera pendiente de amortizar.'],
      ['Desembolsos y castigos','Desembolsos de préstamos y castigos de la cartera no revolvente del ejercicio.','Permiten obtener el flujo implícito de amortizaciones por conciliación.']
    ],
    '49_tasa_rev':[
      ['Amortización revolvente','Flujo anual de amortizaciones del producto revolvente, calculado en la conciliación de cartera.','Es el numerador que mide las salidas por amortización.'],
      ['Saldo inicial y nuevas utilizaciones','Suma del saldo revolvente inicial, las compras del año y las disposiciones de RappiCash.','Es la base de recursos que podían amortizarse durante el ejercicio.']
    ],
    '49_tasa_nrev':[
      ['Amortización no revolvente','Flujo anual de amortizaciones de préstamos no revolventes.','Mide las salidas correspondientes al repago de préstamos.'],
      ['Saldo inicial y desembolsos','Suma del saldo pendiente al comenzar el año y los préstamos nuevos desembolsados.','Representa el capital financiado sujeto a amortización.']
    ]
  };
  const definitions={
    '01':'Se estima el crecimiento logarítmico del número de tarjetas del mercado entre dos cierres de diciembre.',
    '02':'Se estima el crecimiento logarítmico del número de tarjetas de consumo del mercado entre dos cierres anuales.',
    '03':'Se estima el crecimiento del flujo anual de compras con tarjetas del mercado y se reconstruye el importe de compras del año.',
    '04':'Se estima el crecimiento del número de tarjetas del banco a partir de sus propios saldos de diciembre.',
    '05':'Se pronostica el crecimiento logarítmico anual del saldo bruto revolvente del banco, comparando el saldo de diciembre de un año con el de diciembre anterior. Al conocer esa tasa, el saldo futuro se recupera multiplicando el saldo previo por la exponencial del crecimiento dividido entre cien.',
    '06':'Se estima directamente el cambio anual del saldo no revolvente y se suma al saldo anterior.',
    '08_mn':'Se estima el crecimiento porcentual anual del saldo de ahorro en moneda nacional.',
    '08_me':'Se estima el crecimiento logarítmico anual del saldo de ahorro en moneda extranjera.',
    '09_plazo':'Se estima la variación porcentual anual de los depósitos a plazo ordinarios.',
    '09_cts':'Se estima el crecimiento porcentual anual del saldo de compensación por tiempo de servicios.',
    '11':'Se estima la tasa implícita anual del costo de las obligaciones con el público.',
    '12_entidades':'Se estima el logaritmo del gasto anual por depósitos de entidades financieras incrementado en 0,05.',
    '12_adeudos':'Se estima el gasto anual por intereses de adeudos directamente en millones de soles.',
    '12_otras':'Se estima el logaritmo de uno más el gasto anual por otras fuentes.',
    '16_creditos':'Se estima el rendimiento anual propio y se aplica a la cartera promedio para reconstruir ingresos.',
    '16_disponible':'Se estima el logaritmo del ingreso anual por disponibilidades y se recupera su monto mediante la exponencial.',
    '16_interbancarios':'Se estima el logaritmo de los ingresos anuales por fondos interbancarios.',
    '17_caja':'Se estima el saldo mensual de caja utilizando la relación con el saldo del mes anterior.',
    '18_diversos':'Se combinan en niveles dos pronósticos de ingresos diversos con pesos de 75 y 25 por ciento.',
    '19_personal':'La regresión explica la variación de trabajadores, mientras el gasto se determina por dotación promedio e inflación.',
    '19_terceros':'Se combinan en niveles una trayectoria de crecimiento logarítmico y otra trayectoria de gasto con rezago.',
    '31':'Se estima el crecimiento logarítmico anual de las cuentas por cobrar netas.',
    '32':'Se estima el cambio anual de los rendimientos por cobrar, que se añade al saldo del año anterior.',
    '48':'Se estima el crecimiento logarítmico anual de la cartera total de consumo de la banca múltiple.'
  };
  function predictor(name) {
    const n=String(name||'').toLowerCase();
    if (n.includes('constante')||n.includes('intercepto')) return ['Término independiente de la ecuación, medido en la escala de la variable explicada.','Evita imponer que la predicción sea cero cuando las demás regresoras toman valor cero.'];
    if (n.includes('desempleo')) return ['Medida de desempleo del mercado laboral en el año indicado. Cuando se señala cambio, representa la diferencia entre tasas anuales en puntos porcentuales.','Incorpora información de las condiciones laborales vinculadas a la capacidad de gasto y de pago.'];
    if (n.includes('inflaci')||n.includes('π')) return ['Inflación correspondiente al año indicado, medida como variación porcentual anual de los precios.','Considera el entorno nominal y las condiciones de precios que acompañan la actividad bancaria.'];
    if (n.includes('pbi')||n.includes('producto bruto')) return ['Variación real anual del producto bruto interno del año indicado, en porcentaje. Si el nombre señala rezago, corresponde al año anterior.','Representa el entorno de actividad económica asociado a la demanda o al desempeño de la cuenta.'];
    if (n.includes('tpm')||n.includes('política monetaria')) return ['Tasa de referencia del Banco Central de Reserva del Perú. El nombre indica si se utiliza el cierre actual, el anterior o su variación en puntos porcentuales.','Representa las condiciones monetarias y de tasas de referencia.'];
    if (n.includes('rezag')||n.includes('anterior')) return ['Valor de la misma variable o del indicador señalado correspondiente al periodo anterior.','Captura la persistencia observable entre los cierres sucesivos de la serie.'];
    if (n.includes('2020')||n.includes('2021')||n.includes('2024')||n.includes('2025')) return ['Indicador temporal que toma el valor uno en los años señalados y cero en los demás.','Permite distinguir el comportamiento específico de esos años sin prolongar dicho ajuste a otros periodos.'];
    if (n.includes('compras')) return ['Flujo de compras con tarjetas del mercado en el periodo expresamente indicado por la especificación.','Representa el uso observado o proyectado de los medios de pago asociados al crédito de consumo.'];
    if (n.includes('tasa')||n.includes('costo')) return ['Tasa de interés o costo expresado como porcentaje, con el período indicado en el nombre del término.','Incorpora el precio financiero relevante para el comportamiento de la partida.'];
    return ['Regresora incluida en la ecuación con la transformación y el período indicados en su nombre.','Aporta la información adicional observada en la estimación de la relación de esta cuenta.'];
  }
  const referenceName=id=>({pbi:'Producto bruto interno',inflacion:'Inflación anual',desempleo:'Desempleo anual',tpm:'Tasa de política monetaria',tc_cierre:'Tipo de cambio al cierre',tc_promedio:'Tipo de cambio promedio'})[id] || (window.IASPEApp?.model?.(id)?.name) || id;
  function termsFor(model) {
    const id=escapeKey(model), coeff=model.coefficients||[];
    if(window.IASPEPrecision?.terms?.[id]) return window.IASPEPrecision.terms[id];
    if(derivedTerms[id])return derivedTerms[id].map(([label,definition,motivation])=>({label,definition,motivation}));
    if(detailTerms[id])return detailTerms[id].map(([label,definition,motivation])=>({label,definition,motivation}));
    const existing=descriptions[id]?.terms||[];
    if(existing.length && (coeff.length===0 || existing.length===coeff.length)) return existing;
    if(coeff.length) return coeff.map(c=>{
      const [definition,motivation]=predictor(c.name||c.variable);
      return {label:c.name||c.variable||'Término estimado',definition,motivation};
    });
    const inputs=(model.inputs||[]).filter(x=>x&&typeof x==='object');
    if(inputs.length){
      return inputs.map(x=>{
        const key=String(x.id||x.name||'');
        const label=referenceName(key);
        const unit=x.unit ? ' La unidad de referencia es '+(x.unit==='%'?'porcentaje':x.unit)+'.' : '';
        const time=x.lag>0?' Se utiliza con un rezago de '+x.lag+' '+(model.frequency==='monthly'?'meses':'años')+'.':'';
        const definition='Este componente toma la información de '+label.toLowerCase()+' y la incorpora a la regla de cálculo del modelo.'+time+unit;
        const motivation='Su valor permite calcular '+model.name.toLowerCase()+' con los datos y supuestos provenientes del modelo o fuente correspondiente.';
        return {label,definition,motivation};
      });
    }
    const method=String(model.method||'');
    if(/Pronóstico original|Insumo exógeno|Modelo IASPE Base/i.test(method)){
      return [{label:'Saldo o flujo presupuestado de la cuenta',definition:'Se utiliza el importe anual correspondiente al ejercicio que figura en la serie de resultados del modelo financiero original, con su carácter de dato observado, supuesto o proyectado.',motivation:'Mantiene la partida dentro de los estados financieros con los supuestos de su fuente original sin incorporar parámetros econométricos no documentados.'}];
    }
    if(/Conciliación|identidad|derivad|contable|componente|traslado/i.test(method) || ['07','08','09','10','12','16','17','18','19','20','21','22','23','29','45','46','47','48_cuota','49'].includes(id)) {
      return [{label:'Partidas de la identidad',definition:'Se combinan los saldos o flujos especificados en la ecuación para el mismo ejercicio, respetando las operaciones y signos contables.',motivation:'Permite obtener el rubro consolidado de forma coherente con los valores calculados para sus componentes.'}];
    }
    return [{label:'Componente de proyección',definition:'El valor anual se obtiene mediante la regla de cálculo registrada para esta partida en la fuente del modelo.',motivation:'Completa el indicador o movimiento financiero correspondiente sin agregar una regresión independiente.'}];
  }
  function mathify(text){
    let s=String(text||'');
    // Convert technical fragments to real KaTeX, preserving prose and accounting currency.
    s=s.replace(/100\s*×\s*ln\(Nₜ\s*\/\s*Nₜ₋₁\)/g,String.raw`\(100\ln\left(\frac{N_t}{N_{t-1}}\right)\)`)
      .replace(/100\s*×\s*ln\(Cₜ\s*\/\s*Cₜ₋₁\)/g,String.raw`\(100\ln\left(\frac{C_t}{C_{t-1}}\right)\)`)
      .replace(/100\s*×\s*ln\(Sₜ\s*\/\s*Sₜ₋₁\)/g,String.raw`\(100\ln\left(\frac{S_t}{S_{t-1}}\right)\)`)
      .replace(/100\s*(?:×\s*)?ln\(\s*([a-zA-Z]_{[^}]+})\s*\/\s*([a-zA-Z]_{[^}]+})\s*\)/g,(_,a,b)=>String.raw`\(100\ln\left(\frac{${a}}{${b}}\right)\)`)
      .replace(/100\s*×\s*P_t\/O_t/g,String.raw`\(100\frac{P_t}{O_t}\)`)
      .replace(/100\s*×\s*plazo\/obligaciones/gi,String.raw`\(100\frac{\mathrm{Plazo}_t}{\mathrm{Obligaciones}_t}\)`)
      .replace(/\(Tarjetas_\{t-1\}\+Préstamos_\{t-1\}\+Tarjetas_t\+Préstamos_t\)\/2/g,String.raw`\(\frac{\mathrm{Tarjetas}_{t-1}+\mathrm{Prestamos}_{t-1}+\mathrm{Tarjetas}_t+\mathrm{Prestamos}_t}{2}\)`);
    // Correct accidental double-escaped inline math in content data.
    return s.replace(/\\\\\(/g,String.raw`\(`).replace(/\\\\\)/g,String.raw`\)`);
  }
  function inline(app,string){
    const e=app.escape;
    return mathify(string).split(/(\\\(.+?\\\))/g).map(part=>{
      if(part.startsWith('\\(') && part.endsWith('\\)')) return `<span data-spec-inline-tex="${e(part.slice(2,-2))}"></span>`;
      return e(part);
    }).join('');
  }
  function render(app,model){
    const e=app.escape,regression=(model.coefficients||[]).length>0;
    const terms=termsFor(model);
    const original=descriptions[model.id];
    const typedTerms=terms.map((term,i)=>{
      const coef=(model.coefficients||[])[i];
      if(!coef || !Number.isFinite(coef.value??coef.estimate) || /constante|intercepto/i.test(term.label)) return term;
      const eligible=['01','02','03','04','05','06','08_mn','08_me','09_plazo','09_cts','11','13','14','15','31','32','48'];
      if(!eligible.includes(String(model.id))) return term;
      const val=Number((coef.value??coef.estimate).toFixed(5));
      const regressor= /indicador|dicotómica|dummy|2021|2024|2025/i.test(term.label) ? 'Este indicador entra en la ecuación multiplicado por el coeficiente '+val+'.' : 'La ecuación multiplica el valor de esta variable por el coeficiente estimado '+val+'.';
      return {...term,definition:term.definition+' '+regressor};
    });
    const dependent=definitions[model.id]||original?.dependent||model.definition||`Se calcula ${String(model.name||'la partida').toLowerCase()} en ${model.unit||'la unidad indicada'} para cada cierre anual del horizonte financiero.`;
    return `<details class="iaspe-spec-fold iaspe-explanations-fold" data-spec-variables data-explanation-model="${e(model.id)}"><summary>Variables y justificación</summary><div class="iaspe-explanations"><p class="iaspe-explanation-dependent"><strong>${regression?'Variable explicada':'Qué se calcula'}</strong> ${inline(app,dependent)}</p><div class="iaspe-spec-table-wrap"><table class="iaspe-explanation-table"><thead><tr><th>Variable o componente</th><th>Cómo interviene en el cálculo</th><th>Por qué se incluye</th></tr></thead><tbody>${typedTerms.map((term,i)=>{const refs=window.IASPEFichaInteractions?.links?.(app,model,i,term)||[];return `<tr><th scope="row">${refs.length===1?`<button class="iaspe-term-source-name" type="button" data-spec-source-model="${e(refs[0])}" title="Abrir la ficha del modelo ${e(refs[0])}">${e(term.label)} <span aria-hidden="true">↗</span></button>`:e(term.label)}${refs.length===1?``:refs.length>1?`<span class="iaspe-term-sources">${refs.map(id=>`<button class="iaspe-model-source-link" type="button" data-spec-source-model="${e(id)}" title="Abrir la ficha del modelo de origen">Ver modelo ${e(id)} ↗</button>`).join('')}</span>`:''}</th><td>${inline(app,term.definition)}</td><td>${inline(app,term.motivation)}</td></tr>`}).join('')}</tbody></table></div></div></details>`;
  }
  function explanation(model,coefficient){
    const terms=termsFor(model);
    const idx=(model.coefficients||[]).indexOf(coefficient);
    const t=terms[idx];
    return t?t.definition+' '+t.motivation:(coefficient.interpretation||coefficient.description||'');
  }
  window.IASPEExplanations={render,explanation,inline,terms:termsFor,label:(model,index)=>termsFor(model)[index]?.label||model.coefficients?.[index]?.name||''};
})();
