from __future__ import annotations

import gzip
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PANEL = ROOT / 'Scraper' / 'EEFF_Benchmark' / 'output' / 'panel_eeff_16_bancos.json.gz'

# Coeficientes de cuentas SBS; los importes están en S/ millones.
CUENTAS = {
    '08': {'balance:044': 1},
    '09': {'balance:045': 1},
    '09_plazo': {'balance:047': 1},
    '09_cts': {'balance:048': 1},
    '10': {'balance:042': 1},
    '10_restringidos': {'balance:050': 1},
    '10_otras': {'balance:051': 1},
    '12': {f'er_acumulado:{x}': 1 for x in (112, 113, 114, 115, 116, 117)},
    '12_obligaciones': {'er_acumulado:112': 1},
    '12_entidades': {'er_acumulado:113': 1},
    '12_adeudos': {'er_acumulado:115': 1},
    '12_otras': {f'er_acumulado:{x}': 1 for x in (114, 116, 117)},
    '16': {f'er_acumulado:{x}': 1 for x in (102, 103, 104, 105)},
    '16_creditos': {'er_acumulado:105': 1},
    '16_inversiones': {'er_acumulado:104': 1},
    '16_disponible': {'er_acumulado:102': 1},
    '16_interbancarios': {'er_acumulado:103': 1},
    '17': {'balance:000': 1},
    '17_caja': {'balance:001': 1},
    '17_bancos': {'balance:002': 1},
    '17_canje': {'balance:003': 1},
    '17_otros': {'balance:004': 1},
    '18': {'er_acumulado:127': 1, 'er_acumulado:132': -1},
    '18_diversos': {'er_acumulado:131': 1},
    '18_otros_ing': {'er_acumulado:129': 1},
    '18_gastos_div': {'er_acumulado:136': 1},
    '18_otros_gastos': {'er_acumulado:133': 1},
    '18_fsd': {'er_acumulado:120': 1},
    '19': {'er_acumulado:139': 1},
    '19_personal': {'er_acumulado:140': 1},
    '19_directorio': {'er_acumulado:141': 1},
    '19_terceros': {'er_acumulado:142': 1},
    '19_impuestos': {'er_acumulado:143': 1},
    '20': {'er_acumulado:106': 1, 'er_acumulado:107': 1,
           'er_acumulado:108': 1, 'er_acumulado:109': 1,
           'er_acumulado:110': 1, 'er_acumulado:121': -1,
           'er_acumulado:119': -1, 'er_acumulado:122': -1,
           'er_acumulado:123': -1, 'er_acumulado:118': -1,
           'er_acumulado:137': 1},
    '20_tc': {'er_acumulado:108': 1, 'er_acumulado:121': -1},
    '20_consorcios': {'er_acumulado:107': 1, 'er_acumulado:119': -1},
    '20_derivados': {'er_acumulado:109': 1, 'er_acumulado:122': -1},
    '20_inversiones': {'er_acumulado:106': 1, 'er_acumulado:118': -1},
    '20_otros': {'er_acumulado:110': 1, 'er_acumulado:123': -1, 'er_acumulado:137': 1},
    '21': {'balance:006': 1},
    '21_venta': {'balance:008': 1},
    '21_asociadas': {'balance:010': 1},
    '22': {'balance:005': 1},
    '22_interbancarios': {'balance:005': 1},
    '23': {'er_acumulado:124': 1},
    '24': {'er_acumulado:153': 1},
    '25': {'er_acumulado:125': 1},
    '26': {'er_acumulado:151': 1, 'er_acumulado:152': 1},
    '27': {'er_acumulado:145': 1, 'er_acumulado:151': -1, 'er_acumulado:152': -1},
    '28': {'er_acumulado:155': 1},
    '29': {'er_acumulado:156': 1},
    '30': {'balance:090': 1},
    '31': {'balance:031': 1},
    '32': {'balance:032': 1},
}

LAST_FLOW = {'12','12_obligaciones','12_entidades','12_adeudos','12_otras',
             '16','16_creditos','16_inversiones','16_disponible','16_interbancarios'}
LINEAR_YTD = {'18_otros_ing','18_gastos_div','18_otros_gastos','18_fsd','20_tc','20_derivados'}
MEDIAN_YTD = {'19_personal','19_directorio','19_terceros','19_impuestos'}


def _importe(panel, cuentas, mes):
    valores = []
    for codigo, peso in cuentas.items():
        valor = panel['series'].get(codigo, {}).get('05', {}).get(mes)
        if not isinstance(valor, (int, float)) or not math.isfinite(valor):
            return None
        valores.append(peso * valor)
    return sum(valores)


def _cierre_estacional(panel, cuentas, anio, mes):
    acumulado = _importe(panel, cuentas, f'{anio}-{mes:02d}')
    if acumulado is None:
        return None
    if mes == 12:
        return acumulado
    faltantes = 0.0
    for pendiente in range(mes + 1, 13):
        historial = []
        for previo in (2023, 2024, 2025):
            actual = _importe(panel, cuentas, f'{previo}-{pendiente:02d}')
            anterior = _importe(panel, cuentas, f'{previo}-{pendiente - 1:02d}')
            if actual is not None and anterior is not None:
                historial.append(actual - anterior)
        if len(historial) != 3:
            return None
        faltantes += sum(historial) / len(historial)
    return acumulado + faltantes


def _cierre_ultimo_flujo(panel, cuentas, anio, mes):
    """Regla de los Inputs M12 obligaciones y M16 créditos, sin cambiarla."""
    actual = _importe(panel, cuentas, f'{anio}-{mes:02d}')
    previo = 0.0 if mes == 1 else _importe(panel, cuentas, f'{anio}-{mes-1:02d}')
    if actual is None or previo is None:
        return None
    return actual + (12-mes)*(actual-previo)


def _factor_mediano(panel, cuentas, mes, years, *, annual_over_month=True):
    ratios=[]
    for year in years:
        same=_importe(panel,cuentas,f'{year}-{mes:02d}')
        december=_importe(panel,cuentas,f'{year}-12')
        denominator=same if annual_over_month else december
        numerator=december if annual_over_month else same
        if denominator is None or numerator is None or abs(denominator)<1e-12:
            return None
        ratios.append(numerator/denominator)
    return statistics.median(ratios)


def _meses_2026_del_original(modelo):
    # Los Excel 25–27 ya incorporan septiembre 2026.
    return 9 if modelo in {'25', '26', '27', '31'} else 8


def construir(modelos, modelos_elegidos=None):
    with gzip.open(PANEL, 'rt', encoding='utf-8') as archivo:
        panel = json.load(archivo)
    resultados, sin_datos = {}, []
    for modelo, cuentas in CUENTAS.items():
        if modelos_elegidos is not None and modelo not in modelos_elegidos:
            continue
        actual = modelos.get(modelo)
        if not actual:
            raise ValueError(f'No existe el Modelo {modelo}.')
        anterior = next((r['value'] for r in actual['annual'] if r['year'] == 2025), None)
        control = _importe(panel, cuentas, '2025-12')
        if modelo=='20_consorcios' and control is not None:
            associated=next(r['value'] for r in modelos['20_asociadas']['annual'] if r['year']==2025)
            control-=associated
        if control is None or anterior is None or not math.isclose(
            anterior, control, rel_tol=0, abs_tol=0.005):
            raise ValueError(f'Cuenta SBS no conciliada con Modelo {modelo} al cierre de 2025.')
        periodos = set.intersection(*(set(panel['series'][codigo].get('05', {}))
                                    for codigo in cuentas))
        cierres = {}
        for anio in range(2026, 2031):
            disponibles = sorted(p for p in periodos if p.startswith(f'{anio}-')
                                 and (anio != 2026 or int(p[5:]) > _meses_2026_del_original(modelo)))
            if not disponibles:
                continue
            mes = disponibles[-1]
            flujo = next(iter(cuentas)).startswith('er_')
            month=int(mes[5:])
            if modelo in {'17_canje','17_otros'} and month<12:
                history=[_importe(panel,cuentas,f'{year}-12') for year in range(2021,2026)]
                if any(value is None for value in history):
                    raise ValueError(f'{modelo}: faltan los cinco cierres observados 2021–2025')
                cierres[str(anio)]={'value':statistics.median(history),'status':'assumed','sourceMonth':mes,
                                   'sourceValue':_importe(panel,cuentas,mes),
                                   'method':'Mediana fija de cierres observados 2021–2025; nuevo mes SBS conservado por separado'}
                continue
            if modelo=='21_venta' and month<12:
                budget=next((r['value'] for r in actual['annual'] if r['year']==anio),None)
                if budget is None:
                    raise ValueError(f'M21: falta el presupuesto exógeno de {anio}')
                cierres[str(anio)]={'value':budget,'status':'assumed','sourceMonth':mes,
                                   'sourceValue':_importe(panel,cuentas,mes),
                                   'method':'Presupuesto IASC exógeno vigente; saldo mensual SBS conservado por separado'}
                continue
            if modelo=='21_asociadas' and month<12:
                factor=_factor_mediano(panel,cuentas,month,(2023,2024,2025))
                if factor is None:
                    sin_datos.append(f'{modelo}/{anio}')
                    continue
                cierres[str(anio)]={'value':_importe(panel,cuentas,mes)*factor,'status':'assumed',
                                   'sourceMonth':mes,'method':'Último stock SBS por mediana diciembre/mes 2023–2025'}
                continue
            if modelo == '09_plazo' and anio == 2026 and int(mes[5:]) < 12:
                cfg_path=ROOT/'Control_Supuestos/plan_captaciones_iasc.json'
                cfg=json.loads(cfg_path.read_text(encoding='utf-8'))['cierre_plazo_2026']
                sample=cfg.get('anios_muestra',[2021,2022,2023,2024,2025])
                ratios=[]
                for year in sample:
                    december=_importe(panel,cuentas,f'{year}-12')
                    comparable=_importe(panel,cuentas,f'{year}-{mes[5:]}')
                    if december is None or comparable is None or comparable<=0:
                        raise ValueError(f'M09: falta el par estacional de {year}/{mes[5:]}')
                    ratios.append(december/comparable-1)
                value=_importe(panel,cuentas,mes)*(1+statistics.mean(ratios))
                cierres[str(anio)]={'value':value,'status':'assumed','sourceMonth':mes,
                                   'method':'MCO de constante de variación mes-diciembre 2021–2025 (Control_Supuestos vigente)'}
                continue
            if modelo == '30' and int(mes[5:]) < 12:
                # Regla recuperada y conciliada con el cierre original de 2026:
                # saldo observado + promedio de los cambios dic/mes 2021–2025.
                actual = _importe(panel, cuentas, mes)
                diferencias = []
                for previo in range(anio-5, anio):
                    diciembre = _importe(panel, cuentas, f'{previo}-12')
                    comparable = _importe(panel, cuentas, f'{previo}-{mes[5:]}')
                    if diciembre is not None and comparable is not None:
                        diferencias.append(diciembre - comparable)
                if actual is None or len(diferencias) != 5:
                    sin_datos.append(f'{modelo}/{anio}')
                    continue
                valor = actual + sum(diferencias) / 5
                cierres[str(anio)] = {'value': valor, 'status': 'assumed', 'sourceMonth': mes,
                     'method': f'Último saldo observado + media de cinco diferencias diciembre/{mes[5:]} (2021–2025)'}
                continue
            if modelo in {'31', '32'} and int(mes[5:]) < 12:
                valor_ult = _importe(panel, cuentas, mes)
                if valor_ult is None:
                    continue
                ultimo_mes = int(mes[5:])
                if modelo == '31' and anio == 2026 and ultimo_mes == 9:
                    # Regla exacta del Input del Modelo 31: septiembre + recuperación 3%.
                    valor = valor_ult * 1.03
                else:
                    # Modelo 32: mediana de diferencias diciembre/mes durante cinco años.
                    # Si el mes avanza, usa su mes homólogo (no mezcla agosto con septiembre).
                    difs = []
                    for previo in range(anio-5, anio):
                        dic = _importe(panel, cuentas, f'{previo}-12')
                        base = _importe(panel, cuentas, f'{previo}-{ultimo_mes:02d}')
                        if dic is not None and base is not None:
                            difs.append(dic - base)
                    if len(difs) != 5:
                        sin_datos.append(f'{modelo}/{anio}')
                        continue
                    valor = valor_ult + statistics.median(difs)
                cierres[str(anio)] = {'value': valor, 'status': 'assumed', 'sourceMonth': mes,
                                     'method': 'Modelo 31: ajuste 3% sobre septiembre' if modelo=='31' and ultimo_mes==9 and anio==2026 else
                                               'Mediana de cinco diferencias diciembre/mes del mismo período'}
                continue
            if flujo and anio >= 2027 and int(mes[5:]) < 12:
                observados = {int(p[5:]) for p in disponibles}
                if not set(range(1, 8)).issubset(observados):
                    continue
            if modelo=='20_consorcios':
                associated=statistics.median(r['value'] for r in modelos['20_asociadas']['annual']
                                             if r['year'] in (2023,2024,2025))
                valor=_importe(panel,cuentas,mes)*12/month-associated
            elif flujo and modelo in LAST_FLOW and month<12:
                valor = _cierre_ultimo_flujo(panel,cuentas,anio,int(mes[5:]))
            elif flujo and modelo in LINEAR_YTD and month<12:
                valor=_importe(panel,cuentas,mes)*12/month
            elif flujo and modelo in MEDIAN_YTD and month<12:
                factor=_factor_mediano(panel,cuentas,month,(2023,2024,2025),annual_over_month=False)
                valor=(_importe(panel,cuentas,mes)/factor) if factor is not None and abs(factor)>1e-12 else None
            elif flujo and modelo == '24' and anio == 2026 and int(mes[5:]) < 12:
                # Conservar el cierre aprobado: acumulado del período y
                # mediana de factores anuales del mismo mes, 2022–2025.
                actual = _importe(panel, cuentas, mes)
                factors = []
                for historical in range(2022, 2026):
                    h_month = _importe(panel, cuentas, f'{historical}-{mes[5:]}')
                    h_dec = _importe(panel, cuentas, f'{historical}-12')
                    if h_month is None or h_dec is None or abs(h_month) < 1e-10:
                        factors = []
                        break
                    factors.append(h_dec/h_month)
                if actual is None or len(factors)!=4:
                    sin_datos.append(f'{modelo}/{anio}')
                    continue
                valor = actual * statistics.median(factors)
            elif flujo and modelo in {'25', '26', '27'} and int(mes[5:]) < 12:
                valor = _cierre_estacional(panel, cuentas, anio, int(mes[5:]))
            else:
                valor = _importe(panel, cuentas, mes)
            if valor is None:
                continue
            # SBS publica participaciones agregadas, sin separar consorcios
            # de asociadas. Restar la mediana conserva un componente supuesto
            # incluso cuando el agregado de diciembre ya sea observado.
            tipo = 'observed' if mes.endswith('-12') and modelo!='20_consorcios' else 'assumed'
            if tipo == 'assumed' and flujo and modelo not in LAST_FLOW|LINEAR_YTD|MEDIAN_YTD|{'20_consorcios','20_inversiones','20_otros','24','25','26','27'}:
                referencia = _importe(panel, cuentas, f'{anio-1}-{mes[5:]}')
                completo = _importe(panel, cuentas, f'{anio-1}-12')
                if referencia is None or completo is None or abs(referencia) < 1e-8:
                    sin_datos.append(f'{modelo}/{anio}')
                    continue
                valor = completo * valor / referencia
                if not math.isfinite(valor):
                    sin_datos.append(f'{modelo}/{anio}')
                    continue
            metodo=('Cierre diciembre SBS observado' if tipo=='observed' else
                    'Acumulado SBS + meses pendientes por último flujo mensual observado (regla original)' if modelo in LAST_FLOW else
                    'Acumulado SBS anualizado 12/mes (regla original)' if modelo in LINEAR_YTD else
                    'Acumulado SBS / mediana mes/diciembre 2023–2025' if modelo in MEDIAN_YTD else
                    'Participación neta SBS anualizada 12/mes menos mediana de asociadas 2023–2025' if modelo=='20_consorcios' else
                    'Acumulado SBS conservado como supuesto (sin anualización)' if modelo in {'20_inversiones','20_otros'} else
                    'Acumulado SBS por mediana diciembre/mes 2022–2025' if modelo=='24' else
                    'Promedio 2023–2025 de incrementos mensuales faltantes' if flujo and modelo in {'25','26','27'} else
                    'Proporción interanual acumulada del Estado de Resultados' if flujo else
                    'Último saldo de stock publicado; pendiente de observar el diciembre efectivo')
            cierres[str(anio)] = {'value': valor, 'status': tipo, 'sourceMonth': mes, 'method': metodo}
            if modelo=='20_consorcios':
                cierres[str(anio)].update(sourceValue=_importe(panel,cuentas,mes),sourceStatus='observed')
        if cierres:
            resultados[modelo] = cierres
    archivo = ROOT / 'Scraper' / 'Actualizacion' / 'output' / 'ahorro_moneda_sbs.json'
    if archivo.is_file() and (modelos_elegidos is None or bool({'08_mn', '08_me'} & modelos_elegidos)):
        datos = json.loads(archivo.read_text(encoding='utf-8'))
        series = datos.get('series', {})
        if not all(isinstance(series.get(key), dict) for key in ('08_mn', '08_me')):
            raise ValueError('B-220513: faltan series de ahorro MN y ME.')
        fechas = sorted(set(series['08_mn']) & set(series['08_me']))
        if set(series['08_mn']) != set(series['08_me']):
            raise ValueError('B-220513: MN y ME tienen períodos distintos.')
        for fecha in fechas:
            total = _importe(panel, CUENTAS['08'], fecha)
            if total is None:
                continue
            mn = float(series['08_mn'][fecha])
            me = float(series['08_me'][fecha])
            if not math.isclose(mn + me, total, abs_tol=0.05, rel_tol=0):
                raise ValueError(f'Ahorro MN + ME no concilia con SBS 044: {fecha}.')
        for key in ('08_mn', '08_me'):
            if modelos_elegidos is not None and key not in modelos_elegidos:
                continue
            actual = modelos[key]
            previo = next((r['value'] for r in actual['annual'] if r['year'] == 2025), None)
            if previo is None:
                raise ValueError(f'Sin cierre 2025 para {key}.')
            # La validación del año base se hace al descargar B-220513.
            cierres = {}
            for anio in range(2026, 2031):
                opciones = [fecha for fecha in fechas if fecha.startswith(f'{anio}-')]
                if not opciones:
                    continue
                fecha = opciones[-1]
                if anio == 2026 and fecha <= '2026-08':
                    continue
                padre = resultados.get('08', {}).get(str(anio), {})
                if padre and padre['sourceMonth'] != fecha:
                    raise ValueError(f'B-220513: {fecha} no coincide con el cierre SBS 044 ({padre["sourceMonth"]}).')
                if fecha not in panel['series']['balance:044'].get('05', {}):
                    raise ValueError(f'B-220513: falta el saldo total SBS 044 en {fecha}.')
                valor = float(series[key][fecha])
                if valor < 0 or not math.isfinite(valor):
                    raise ValueError(f'B-220513: importe inválido de {key} en {fecha}.')
                cierres[str(anio)] = {'value': valor,
                                      'status': 'observed' if fecha.endswith('-12') else 'assumed',
                                      'sourceMonth': fecha,
                                      'method': 'Cierre SBS diciembre' if fecha.endswith('-12') else 'Último saldo SBS publicado (stock)'}
            if cierres:
                resultados[key] = cierres
    return resultados, sin_datos
