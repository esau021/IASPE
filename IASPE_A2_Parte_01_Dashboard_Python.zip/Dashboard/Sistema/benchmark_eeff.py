"""Consulta de EEFF SBS de bancos disponibles; solo información observada.

Los archivos son producidos de forma reproducible desde IASPE/Scraper/EEFF_Benchmark.
No se ejecuta web scraping durante la consulta del dashboard.
"""
from __future__ import annotations
from functools import lru_cache
import gzip
import json
from pathlib import Path
from instituciones_sbs import category_at, entity_metadata

LOCAL_PANEL = Path(__file__).resolve().parent / 'Scraper' / 'EEFF_Benchmark' / 'output' / 'panel_eeff_16_bancos.json.gz'
EXTERNAL_PANEL = Path(__file__).resolve().parents[2] / 'IASPE' / 'Scraper' / 'EEFF_Benchmark' / 'output' / 'panel_eeff_16_bancos.json.gz'
DATA_PATH = next((q for q in (EXTERNAL_PANEL, LOCAL_PANEL) if q.is_file()), EXTERNAL_PANEL)

@lru_cache(maxsize=2)
def _load(path: str, mtime_ns: int, size: int):
    with gzip.open(path, 'rt', encoding='utf-8') as source:
        return json.load(source)

def _read():
    if not DATA_PATH.exists():
        raise FileNotFoundError('No se encontró el panel SBS. Ejecuta el generador en IASPE/Scraper/EEFF_Benchmark/script.')
    stat=DATA_PATH.stat()
    return _load(str(DATA_PATH),stat.st_mtime_ns,stat.st_size)

def catalog():
    d=_read()
    meta=d['meta']
    result={k:v for k,v in meta.items() if k not in {'audit'}}
    result['banks']=[dict(bank, **entity_metadata(bank['id'], meta.get('last'))) for bank in meta['banks']]
    stat=DATA_PATH.stat()
    result['revision']=f'{stat.st_mtime_ns}:{stat.st_size}'
    result['market_note']='Suma de las entidades comparables seleccionadas con dato; puede incluir bancos, financieras y cajas rurales según el mes. No representa un total oficial sectorial.'
    return result

def account_data(account: str):
    d=_read()
    meta=d['meta']
    info=next((a for a in meta['accounts'] if a['id']==account),None)
    if info is None:
        raise ValueError('Cuenta del benchmark no reconocida.')
    source=d['series'][account]
    bankids=[x['id'] for x in meta['banks']]
    months=meta['months']
    rows=[]
    for month in months:
        values={bankid:series[month] for bankid in bankids if (series:=source.get(bankid,{})) and month in series}
        categories={bankid:category_at(bankid, month) for bankid in values}
        sector_totals={category:round(sum(value for bankid,value in values.items() if categories[bankid]==category),8)
                       for category in set(categories.values()) if category is not None}
        # El agregado NO equivale al total oficial y puede variar por composición.
        rows.append({'date':month,'banks':values,'aggregate':round(sum(values.values()),8) if values else None,
                     'coverage':len(values),'expected':len(bankids),
                     'categories':categories,'category_aggregates':sector_totals})
    return {'account':info,'rows':rows,'source':{'name':meta['source_name'],'url':meta['source_url'],
            'unit':meta['unit'],'notes':[meta['source_note'],catalog()['market_note'],meta['income_note'],meta['coverage_note']]},
            'revision':catalog()['revision']}
