"""Modelo 49 - amortizaciones agregadas IASPE.
Ejecutar desde el directorio Script con Python y artifact_tool.
Input: compras TC, disposiciones RC, desembolsos PE y castigos históricos o supuestos externos.
Pronósticos: se leen de los Output M01, M03, M04, M05 y M06 de IASPE.
"""
from pathlib import Path
from artifact_tool import Blob,SpreadsheetFile,Workbook
here=Path(__file__).resolve().parent;mod=here.parent
root=mod.parents[1]
oper=root/'Variables Operativas';balance=root/'Estado de Situacion Financiera'

def by_year(fname,sheet,col='B'):
 w=SpreadsheetFile.import_xlsx(Blob.load(str(fname)))
 a=w.worksheets.get_item(sheet).get_range(f'A2:{col}40').values
 d={}
 for row in a:
  if isinstance(row[0],(int,float)) and row[1] is not None:
   k=int(row[0]);v=row[ord(col)-65];
   if isinstance(v,(int,float)):d[k]=float(v)
 return d

def read_input():
 w=SpreadsheetFile.import_xlsx(Blob.load(str(mod/'Input/Base_modelo.xlsx')))
 hist={}
 for r in w.worksheets.get_item('Historico').get_range('A2:D4').values:
  hist[int(r[0])]=[float(r[1]),float(r[2]),float(r[3])]
 casts={}
 for r in w.worksheets.get_item('Supuestos').get_range('A2:B6').values:
  casts[int(r[0])]=float(r[1])
 return hist,casts
hist,casts=read_input()
w_prod=SpreadsheetFile.import_xlsx(Blob.load(str(mod/'01_Apertura_TC_RC_PE/Input/Base_productos.xlsx')))
products={int(row[0]):[float(v) for v in row[1:5]] for row in w_prod.worksheets.get_item('Historico').get_range('A2:E7').values}
rc_ratio=sum(products[y][2]/products[y][0] for y in (2024,2025))/2
# La cadena oficial del Dashboard reestima M01/M03/M04/M05/M06 a partir de
# sus Input y su motor. Leer solamente los Excel Output guardados podría
# reproducir una versión previa de esas proyecciones.
# El script independiente utiliza exactamente la misma cadena que el botón
# Recalcular; no aplica ni importa presupuestos comerciales futuros.
import sys
system=root.parent.parent/'Dashboard'/'Sistema'
if not system.is_dir():
 raise FileNotFoundError('No se encontro el motor del Dashboard dentro del IASPE completo.')
sys.path.insert(0,str(system))
import motor
original,_=motor.load_base(refresh=True)
current,warnings=motor._run(original,{}, {})
if warnings:raise RuntimeError('Cadena IASPE con observaciones: '+'; '.join(warnings))
def from_motor(mid):
 return {int(row['year']):float(row['value']) for row in current[mid]['annual']}
d={
 'market':from_motor('03'),
 'cardmarket':from_motor('01'),
 'cardbf':from_motor('04'),
 'rev':from_motor('05'),
 'nrev':from_motor('06'),
}
ratio=hist[2025][1]/d['nrev'][2025]
calib=hist[2025][0]/(d['market'][2025]*d['cardbf'][2025]/d['cardmarket'][2025])
wb=Workbook.create();s=wb.worksheets.add('Anual')
s.get_range('A1:M1').values=[['Año','Condición','Compras BF (S/ MM)','Saldo REV M05','Castigos REV','Amort. REV','Tasa REV','Desembolsos NREV','Saldo NREV M06','Castigos NREV','Amort. NREV','Tasa NREV','Disposiciones RC (S/ MM)']]
rows=[]
for year in range(2024,2031):
 purchases=hist[year][0] if year<=2025 else d['market'][year]*d['cardbf'][year]/d['cardmarket'][year]*calib
 disb=hist[year][1] if year<=2025 else d['nrev'][year]*ratio
 cast=hist[year][2] if year<=2025 else casts[year]
 rev=d['rev'][year];nrev=d['nrev'][year]
 cr=cast*rev/(rev+nrev);cn=cast-cr
 disp_rc=products[year][2] if year<=2025 else purchases*rc_ratio
 rows.append([year,'Observado' if year<=2025 else 'Cierre supuesto' if year==2026 else 'Pronóstico IASPE',purchases,rev,cr,None,None,disb,nrev,cn,None,None,disp_rc])
s.get_range('A2:M8').values=rows
for ri in range(3,9):
 s.get_range(f'F{ri}').formulas=[[f'=D{ri-1}+C{ri}+M{ri}-D{ri}-E{ri}']]
 s.get_range(f'G{ri}').formulas=[[f'=F{ri}/(D{ri-1}+C{ri}+M{ri})']]
 s.get_range(f'K{ri}').formulas=[[f'=I{ri-1}+H{ri}-I{ri}-J{ri}']]
 s.get_range(f'L{ri}').formulas=[[f'=K{ri}/(I{ri-1}+H{ri})']]
s.get_range('A1:M1').format={'fill':'#203348','font':{'bold':True,'color':'#FFFFFF'},'wrap_text':True,'row_height':37}
s.get_range('A1:A12').format.column_width=12;s.get_range('B1:B12').format.column_width=20
for c in 'CDEFHIJKM':s.get_range(f'{c}1:{c}12').format.column_width=20
s.get_range('G1:G12').format.column_width=15;s.get_range('L1:L12').format.column_width=15
s.get_range('C2:F8').set_number_format('#,##0.00;[Red](#,##0.00);-');s.get_range('H2:K8').set_number_format('#,##0.00;[Red](#,##0.00);-');s.get_range('M2:M8').set_number_format('#,##0.00;[Red](#,##0.00);-');s.get_range('G2:G8').set_number_format('0.00%');s.get_range('L2:L8').set_number_format('0.00%')
s.get_range('A1:M8').format={'font':{'name':'Calibri'},'horizontal_alignment':'justify','vertical_alignment':'center'}
s.get_range('B2:B8').format.horizontal_alignment='left'
s.get_range('A1:M1').format={'fill':'#F2F2F2','font':{'name':'Calibri','bold':True},'horizontal_alignment':'justify','vertical_alignment':'center'}
SpreadsheetFile.export_xlsx(wb).save(str(mod/'Output/Pronostico.xlsx'))
print('Modelo49 generado:',mod/'Output/Pronostico.xlsx')
