from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import tempfile
import time
import unicodedata
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from pathlib import Path

import requests

CODIGO = "B-3202"
BASE_SBS = "https://intranet2.sbs.gob.pe/estadistica/financiera"
PAGINA_SBS = "https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c=B-3202"
MESES = {
    1: ("Enero", "en"), 2: ("Febrero", "fe"), 3: ("Marzo", "ma"),
    4: ("Abril", "ab"), 5: ("Mayo", "my"), 6: ("Junio", "jn"),
    7: ("Julio", "jl"), 8: ("Agosto", "ag"), 9: ("Setiembre", "se"),
    10: ("Octubre", "oc"), 11: ("Noviembre", "no"), 12: ("Diciembre", "di"),
}
ALIASES = {"financiera uno", "financiera oh", "infinance xp", "in finance xp"}
COLUMNAS = ["periodo", "banco", "personal_total", "gerentes", "funcionarios",
            "empleados", "otros", "nombre_sbs", "archivo", "hoja", "fila_excel", "sistema"]
OLE = bytes.fromhex("D0CF11E0A1B11AE1")
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0 Safari/537.36",
    "Referer": PAGINA_SBS,
    "Accept": "application/vnd.ms-excel,application/octet-stream,*/*",
}


def raiz_proyecto():
    variable = os.getenv("IASPE_DIR", "").strip()
    if variable and (Path(variable) / "Scraper" / "Numero_trabajadores").is_dir():
        return (Path(variable) / "Scraper" / "Numero_trabajadores").resolve()
    candidatos = [Path.cwd(), *Path.cwd().parents]
    if "__file__" in globals():
        f = Path(__file__).resolve()
        candidatos = [f.parent, *f.parents, *candidatos]
    candidatos.extend([
        Path.home() / "Desktop" / "IASPE" / "Scraper" / "Numero_trabajadores",
        Path.home() / "OneDrive" / "Desktop" / "IASPE" / "Scraper" / "Numero_trabajadores",
    ])
    for p in candidatos:
        if p.name.casefold() == "numero_trabajadores" and (p / "script").is_dir():
            return p.resolve()
        q = p / "IASPE" / "Scraper" / "Numero_trabajadores"
        if (q / "script").is_dir():
            return q.resolve()
    raise FileNotFoundError("No se encontró IASPE/Scraper/Numero_trabajadores")


def normalizar(valor):
    texto = unicodedata.normalize("NFKD", str(valor)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", texto)).strip()


def meses_entre(inicio, fin):
    anio, mes = inicio
    while (anio, mes) <= fin:
        yield anio, mes
        anio, mes = (anio + 1, 1) if mes == 12 else (anio, mes + 1)


def ultimo_cierre():
    hoy = date.today()
    return (hoy.year - 1, 12) if hoy.month == 1 else (hoy.year, hoy.month - 1)


def nombre_url(anio, mes):
    nombre, abrev = MESES[mes]
    archivo = f"{CODIGO}-{abrev}{anio}.XLS"
    return archivo, f"{BASE_SBS}/{anio}/{nombre}/{archivo}"


def firma_excel(datos):
    return len(datos) >= 500 and (datos.startswith(OLE) or datos.startswith(b"PK\x03\x04"))


def filas_excel(datos):
    if datos.startswith(OLE):
        try:
            import xlrd
        except ImportError as e:
            raise RuntimeError("No está instalado xlrd") from e
        libro = xlrd.open_workbook(file_contents=datos, on_demand=True)
        try:
            for hoja in libro.sheets():
                for i in range(hoja.nrows):
                    yield hoja.name, i + 1, hoja.row_values(i)
        finally:
            libro.release_resources()
    elif datos.startswith(b"PK\x03\x04"):
        try:
            from openpyxl import load_workbook
        except ImportError as e:
            raise RuntimeError("No está instalado openpyxl") from e
        libro = load_workbook(io.BytesIO(datos), read_only=True, data_only=True)
        try:
            for hoja in libro.worksheets:
                for i, fila in enumerate(hoja.iter_rows(values_only=True), 1):
                    yield hoja.title, i, fila
        finally:
            libro.close()
    else:
        raise ValueError("Formato XLS no reconocido")


def numero(valor, *, admite_vacio=False):
    if valor is None or (isinstance(valor, str) and valor.strip() in {"", "-", "–"}):
        if admite_vacio:
            return 0
        raise ValueError("Total sin informar")
    texto = str(valor).strip().replace(",", "").replace(" ", "")
    n = float(texto)
    if n < 0 or not n.is_integer():
        raise ValueError(f"Conteo inválido: {valor}")
    return int(n)


def extraer_personal(datos, periodo, archivo):
    titulo = False
    coincidencias = []
    for hoja, fila_num, fila in filas_excel(datos):
        if any("personal segun categoria laboral por empresa financiera" in normalizar(v)
               for v in fila if isinstance(v, str)):
            titulo = True
        for i, v in enumerate(fila):
            if not isinstance(v, str) or normalizar(v) not in ALIASES:
                continue
            valores = list(fila[i + 1:i + 6])
            if len(valores) != 5:
                raise ValueError(f"Fila incompleta: {hoja}:{fila_num}")
            ger, fun, emp, otr = [numero(x, admite_vacio=True) for x in valores[:4]]
            total = numero(valores[4])
            if ger + fun + emp + otr != total:
                raise ValueError(f"Descuadre de personal: {hoja}:{fila_num}")
            coincidencias.append({
                "periodo": periodo, "banco": "InFinance XP", "personal_total": total,
                "gerentes": ger, "funcionarios": fun, "empleados": emp, "otros": otr,
                "nombre_sbs": v.strip(), "archivo": archivo, "hoja": hoja,
                "fila_excel": fila_num, "sistema": "Empresas Financieras",
            })
    if not titulo:
        raise ValueError("El Excel no corresponde al reporte de personal de Empresas Financieras")
    if len(coincidencias) > 1:
        raise ValueError(f"Más de una coincidencia para {periodo}")
    return coincidencias[0] if coincidencias else None


def csv_actual(path):
    if not path.exists():
        return []
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def escribir_csv(path, campos, filas):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8-sig", newline="",
                                     suffix=".csv", dir=path.parent, delete=False) as f:
        temporal = Path(f.name)
        w = csv.DictWriter(f, fieldnames=campos, extrasaction="ignore")
        w.writeheader()
        w.writerows(filas)
    os.replace(temporal, path)


def descargar_mes(raiz, anio, mes, revisar=False):
    periodo = f"{anio}-{mes:02d}"
    archivo, url = nombre_url(anio, mes)
    destino = raiz / "fuentes" / CODIGO / archivo
    destino.parent.mkdir(parents=True, exist_ok=True)
    anterior = raiz / "fuentes" / archivo
    if not destino.is_file() and anterior.is_file():
        anterior.replace(destino)
    previo = destino.read_bytes() if destino.is_file() else None
    if previo is not None and firma_excel(previo) and not revisar:
        try:
            extraer_personal(previo, periodo, archivo)
            return {"periodo": periodo, "archivo": archivo, "estado": "existente", "bytes": len(previo),
                    "sha256": hashlib.sha256(previo).hexdigest(), "url": url, "detalle": ""}
        except Exception:
            pass
    ultimo_error = ""
    for intento in range(2):
        try:
            r = requests.get(url, headers=HEADERS, timeout=(12, 40))
            if r.status_code in {404, 410}:
                return {"periodo": periodo, "archivo": archivo, "estado": "no_publicado", "bytes": 0,
                        "sha256": "", "url": url, "detalle": f"HTTP {r.status_code}"}
            r.raise_for_status()
            datos = r.content
            if not firma_excel(datos):
                raise ValueError("Respuesta no es un Excel XLS/XLSX")
            extraer_personal(datos, periodo, archivo)
            hash_nuevo = hashlib.sha256(datos).hexdigest()
            hash_viejo = hashlib.sha256(previo).hexdigest() if previo else None
            if hash_nuevo != hash_viejo:
                with tempfile.NamedTemporaryFile(mode="wb", suffix=".tmp", dir=destino.parent, delete=False) as f:
                    tmp = Path(f.name)
                    f.write(datos)
                os.replace(tmp, destino)
            estado = "sin_cambios" if hash_nuevo == hash_viejo else ("revisado" if previo else "descargado")
            return {"periodo": periodo, "archivo": archivo, "estado": estado, "bytes": len(datos),
                    "sha256": hash_nuevo, "url": url, "detalle": ""}
        except Exception as e:
            ultimo_error = f"{type(e).__name__}: {str(e)[:200]}"
            if intento == 0:
                time.sleep(0.5)
    return {"periodo": periodo, "archivo": archivo, "estado": "error", "bytes": 0,
            "sha256": "", "url": url, "detalle": ultimo_error}


def actualizar_personal_financieras(raiz=None, inicio=(2012, 1), fin=None, revisar_recientes=3, workers=4, mostrar_progreso=True):
    raiz = Path(raiz) if raiz is not None else raiz_proyecto()
    fuentes = raiz / "fuentes" / CODIGO
    salida = raiz / "output"
    fuentes.mkdir(parents=True, exist_ok=True)
    salida.mkdir(parents=True, exist_ok=True)
    fin = fin or ultimo_cierre()
    if inicio > fin:
        raise ValueError("Rango de fechas inválido")
    periodos = list(meses_entre(inicio, fin))
    revisar = set(periodos[-revisar_recientes:]) if revisar_recientes > 0 else set()
    descargas = []
    archivos_presentes = {p.name for p in fuentes.glob("B-3202-*.XLS")}
    disponibles = sum(nombre_url(y, m)[0] in archivos_presentes for y, m in periodos)
    inicio_label = f"{periodos[0][0]}-{periodos[0][1]:02d}"
    fin_label = f"{periodos[-1][0]}-{periodos[-1][1]:02d}"
    if mostrar_progreso:
        print(f"B-3202 | {inicio_label} a {fin_label} | {len(periodos)} meses", flush=True)
        print(f"Fuentes: {fuentes} | Disponibles: {disponibles} | Por consultar: {len(periodos)-disponibles}", flush=True)
    conteo = Counter()
    with ThreadPoolExecutor(max_workers=max(1, min(int(workers), 4))) as pool:
        futures = {pool.submit(descargar_mes, raiz, y, m, (y, m) in revisar): (y, m) for y, m in periodos}
        for indice, future in enumerate(as_completed(futures), 1):
            y, m = futures[future]
            try:
                dato = future.result()
            except Exception as exc:
                nombre, url = nombre_url(y, m)
                dato = {"periodo": f"{y}-{m:02d}", "archivo": nombre, "estado": "error",
                        "bytes": 0, "sha256": "", "url": url, "detalle": str(exc)[:200]}
            descargas.append(dato)
            conteo[dato["estado"]] += 1
            if mostrar_progreso:
                detalle = f" | {dato['detalle']}" if dato["estado"] == "error" else ""
                print(f"[{indice:03d}/{len(periodos):03d}] {dato['periodo']} | {dato['estado']}{detalle}", flush=True)
    descargas.sort(key=lambda x: x["periodo"])
    if mostrar_progreso:
        print("Extracción y conciliación...", flush=True)

    anterior = {r["periodo"]: r for r in csv_actual(salida / "personal_financieras.csv")}
    seleccionados = {f"{y}-{m:02d}" for y, m in periodos}
    actual = {periodo: row for periodo, row in anterior.items() if periodo not in seleccionados}
    auditoria = []
    for y, m in periodos:
        periodo = f"{y}-{m:02d}"
        nombre, _ = nombre_url(y, m)
        origen = fuentes / nombre
        try:
            if not origen.is_file():
                auditoria.append({"periodo": periodo, "archivo": nombre, "estado": "sin_archivo", "detalle": ""})
                if periodo in anterior:
                    actual[periodo] = anterior[periodo]
                continue
            datos = origen.read_bytes()
            if not firma_excel(datos):
                raise ValueError("Archivo Excel inválido")
            fila = extraer_personal(datos, periodo, nombre)
            if fila is not None:
                actual[periodo] = fila
                auditoria.append({"periodo": periodo, "archivo": nombre, "estado": "extraido", "detalle": fila["nombre_sbs"]})
            else:
                auditoria.append({"periodo": periodo, "archivo": nombre, "estado": "entidad_ausente", "detalle": ""})
                if periodo in anterior:
                    actual[periodo] = anterior[periodo]
        except Exception as e:
            auditoria.append({"periodo": periodo, "archivo": nombre, "estado": "error_estructura", "detalle": str(e)[:200]})
            if periodo in anterior:
                actual[periodo] = anterior[periodo]

    valor_cols = ("personal_total", "gerentes", "funcionarios", "empleados", "otros")
    nuevos = [p for p in sorted(actual) if p not in anterior]
    revisados = [p for p in sorted(actual) if p in anterior and
                any(str(actual[p].get(c, "")) != str(anterior[p].get(c, "")) for c in valor_cols)]
    escribir_csv(salida / "personal_financieras.csv", COLUMNAS, [actual[p] for p in sorted(actual)])
    escribir_csv(salida / "descargas_financieras.csv",
                 ["periodo", "archivo", "estado", "bytes", "sha256", "url", "detalle"], descargas)
    escribir_csv(salida / "auditoria_financieras.csv",
                 ["periodo", "archivo", "estado", "detalle"], auditoria)

    mercado = {}
    for nombre in ("personal_historico_2012_2015.csv", "personal_banca_mensual.csv"):
        for fila in csv_actual(salida / nombre):
            if fila.get("periodo") and fila.get("banco"):
                r = {c: fila.get(c, "") for c in COLUMNAS}
                r["sistema"] = "Banca Múltiple"
                mercado[(r["periodo"], r["banco"])] = r
    for p, fila in actual.items():
        mercado[(p, "InFinance XP")] = {c: fila.get(c, "") for c in COLUMNAS}
    escribir_csv(salida / "personal_mercado.csv", COLUMNAS,
                 [mercado[k] for k in sorted(mercado)])

    if mostrar_progreso:
        conteos_audit = Counter(d["estado"] for d in auditoria)
        print(f"Registros InFinance XP: {len(actual)} | Nuevos: {len(nuevos)} | Modificados: {len(revisados)}", flush=True)
        print(f"Auditoría: {dict(conteos_audit)} | Mercado: {len(mercado)} filas | Salida: {salida}", flush=True)
    return {
        "descargas": dict(Counter(d["estado"] for d in descargas)),
        "extraccion": dict(Counter(d["estado"] for d in auditoria)),
        "periodos_financieras": len(actual), "nuevos": nuevos, "revisados": revisados,
        "entidades_septiembre_2026": len({b for (p, b) in mercado if p == "2026-09"}),
        "output": str(salida),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inicio", type=int, default=2012)
    parser.add_argument("--revisar-recientes", type=int, default=3)
    parser.add_argument("--raiz", type=Path)
    args, _ = parser.parse_known_args()
    print(json.dumps(actualizar_personal_financieras(raiz=args.raiz, inicio=(args.inicio, 1),
        revisar_recientes=args.revisar_recientes), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
