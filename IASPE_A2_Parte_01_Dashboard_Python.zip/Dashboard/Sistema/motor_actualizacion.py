"""Recálculo de submodelos con datos SBS y fórmulas originales."""
from __future__ import annotations
import gzip
import json
import math
import statistics
from pathlib import Path

import numpy as np
import statsmodels.api as sm
from openpyxl import load_workbook
from rutas import buscar_modelo


def _rows(path, tab='Anual'):
    book=load_workbook(path,read_only=True,data_only=True)
    try:return [list(r) for r in book[tab].values]
    finally:book.close()


def _input(root,num,sub):
    return buscar_modelo(root,num)/sub/'Input'/'Base_modelo.xlsx'


def _data(path):
    return {int(r[0]):r for r in _rows(path)[1:] if isinstance(r[0],(int,float))}


def _value(model,year):
    return next((r['value'] for r in model['annual'] if r['year']==year),None)


def _status(model,year):
    return next((r['status'] for r in model['annual'] if r['year']==year),'forecast')


def _put(models,key,year,value):
    if not math.isfinite(float(value)):
        raise ValueError(f'Resultado no finito: {key}/{year}')
    if _status(models[key],year)!='forecast':
        return False
    models[key]['canUpdate']=True
    models[key]['status']='ok'
    models[key].pop('issues',None)
    for row in models[key]['annual']:
        if row['year']==year:
            before=float(row['value'])
            row['value']=float(value)
            row['forecast']=float(value)
            if abs(before-value)>1e-8:
                models[key]['reestimated']=True
            return abs(before-value)>1e-8
    return False


def _fit(y,x,models=None,key=None):
    fit=sm.OLS(np.asarray(y,float),np.asarray(x,float)).fit()
    if models is not None and key in models:
        robust=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
        previous=models[key].get('coefficients') or []
        names=[previous[i].get('name',f'Beta {i}') if i<len(previous) else f'Beta {i}'
               for i in range(len(robust.params))]
        models[key]['coefficients']=[{'name':name,'value':float(robust.params[i]),
             'se':float(robust.bse[i]),'pValue':float(robust.pvalues[i]),
             't':float(robust.tvalues[i])} for i,name in enumerate(names)]
        stats=models[key].setdefault('statistics',{})
        stats.update(nobs=int(fit.nobs),r2=float(fit.rsquared),adjustedR2=float(fit.rsquared_adj),
                     aic=float(fit.aic),bic=float(fit.bic),covariance='HAC / Newey-West, 1 rezago')
        # Resultados estadísticos completos para reconstruir los Excel MCO/HAC.
        # El libro físico se publica únicamente si coincide con el cálculo.
        def snapshot(result):
            return {'params':[float(x) for x in result.params],
                    'stderr':[float(x) for x in result.bse],
                    'tvalues':[float(x) for x in result.tvalues],
                    'pvalues':[float(x) for x in result.pvalues],
                    'ci':[[float(v) for v in pair] for pair in result.conf_int(alpha=.05)]}
        models[key]['mcoSnapshot']={'mco':snapshot(fit),'hac':snapshot(robust),
            'nobs':int(fit.nobs),'r2':float(fit.rsquared),
            'adjusted_r2':float(fit.rsquared_adj),'aic':float(fit.aic),
            'bic':float(fit.bic),
            'dw':float(sm.stats.stattools.durbin_watson(fit.resid)),
            'rmse':float(math.sqrt(fit.mse_resid))}
    return np.asarray(fit.params,float)


def _series(models,key):
    return {r['year']:float(r['value']) for r in models[key]['annual']}


def _macro(data,key,year,col,changes):
    return float((changes or {}).get(key,{}).get(str(year),data[year][col]))


def _costos_depositos(models,root,changes):
    from motor_01_07 import get_macros
    D=_data(buscar_modelo(root,'11')/'Input'/'Base_modelo.xlsx')
    macro={m['id']:{int(y):float(v) for y,v in m['values'].items()} for m in get_macros(root)}
    series=_series(models,'11')
    share={t:float(D[t][3]) for t in D if isinstance(D[t][3],(float,int))}
    for y in range(2026,2031):
        share[y]=100*_value(models['09'],y)/_value(models['10'],y)
    names=['Constante','TPM diciembre (t)','Inflación anual (t)','Participación plazo diciembre (t-1)']
    models['11']['coefficients']=[{'name':n,'value':0.} for n in names]
    years=list(range(2016,2027))
    # Se conserva la muestra aprobada de A.2, incluido el cierre supuesto 2026.
    X=[[1.,float(D[t][2]),macro['inflacion'][t],share[t-1]] for t in years]
    coeff=_fit([series[t] for t in years],X,models,'11')
    model=models['11']
    model.update(method='MCO anual: TPM, inflación y participación a plazo rezagada; HAC(1)',
      dependencies=['tpm','inflacion',{'id':'09','lag':1},{'id':'10','lag':1}],
      inputs=[{'id':'tpm','lag':0},{'id':'inflacion','lag':0}],
      equationTex=r'c_t=\alpha+\beta_1TPM_t+\beta_2\pi_t+\beta_3PartPlazo_{t-1}+\varepsilon_t',
      estimatedEquationTex='',updateRule='Reestimar MCO 2016–2026 con TPM, inflación y participación a plazo del año anterior; transmitir las sendas del escenario.',
      limitations=['2026 es un cierre supuesto incluido en la muestra.','La inflación estimada presenta signo negativo condicional; no se interpreta como efecto causal.','La significancia es sensible al estimador de varianzas y al cierre supuesto.'])
    model['statistics'].update(period='2016–2026',methodologyVersion='IASPE-A2-M11',includesAssumed2026=True)
    model['statistics']['regressorsByYear']={str(t):x for t,x in zip(years,X)}
    model['statistics']['macroByYear']={str(y):{'tpm':float((changes or {}).get('tpm',{}).get(str(y),macro['tpm'][y])), 'inflacion':float((changes or {}).get('inflacion',{}).get(str(y),macro['inflacion'][y]))} for y in range(2026,2031)}
    for y in range(2027,2031):
        if _status(model,y)!='forecast':continue
        tpm=float((changes or {}).get('tpm',{}).get(str(y),macro['tpm'][y]))
        inf=float((changes or {}).get('inflacion',{}).get(str(y),macro['inflacion'][y]))
        model['statistics']['regressorsByYear'][str(y)]=[1.,tpm,inf,share[y-1]]
        series[y]=float(np.dot(coeff,[1.,tpm,inf,share[y-1]]))
        _put(models,'11',y,series[y])


def _gastos_obligaciones(models,root):
    path=buscar_modelo(root,'12')/'01_Obligaciones_publico'/'Output'/'Pronostico.xlsx'
    rs=_rows(path)
    records={int(r[0]):r for r in rs if isinstance(r[0],(int,float))}
    obl=_series(models,'10');costo=_series(models,'11')
    # Mediana original de factores 2015–2026; 2026 se actualiza con
    # los saldos y tasas vigentes, conservando el gasto anual registrado.
    historical=[float(records[y][5]) for y in range(2015,2026)]
    expense=float(_value(models['12_obligaciones'],2026))
    denominator=(obl[2025]+obl[2026])/2*(costo[2025]+costo[2026])/2/100
    if denominator<=0:raise ValueError('M12: costo de fondeo no válido.')
    factor=statistics.median(historical+[expense/denominator])
    for y in range(2027,2031):
        if _status(models['12_obligaciones'],y)=='forecast':
            media=(obl[y-1]+obl[y])/2
            tasa=(costo[y-1]+costo[y])/2
            _put(models,'12_obligaciones',y,media*tasa*factor/100)


def _future(models,key,func):
    updated=[]
    for year in range(2027,2031):
        if _status(models[key],year)!='forecast':continue
        val=func(year)
        if _put(models,key,year,val):updated.append(year)
    return updated


def _plain_mco(models,key,root,num,sub,mode,inputs,changes,start=2016):
    D=_data(_input(root,num,sub))
    target=_series(models,key)
    if mode in {'pct','growthlog'} and 2015 in D and isinstance(D[2015][1],(int,float)):
        target[2015]=float(D[2015][1])
    sample=[y for y in range(start,2027) if y in target and y in D]
    # Una observación nueva se incorpora a la muestra solo con cierre completo.
    sample += [y for y in range(2027,2031) if y in target and _status(models[key],y)=='observed']
    if mode=='pct':
        sample=[y for y in sample if y-1 in target and target[y-1]>0 and target[y]>0]
        dep=[100*(target[y]/target[y-1]-1) for y in sample]
    elif mode=='growthlog':
        sample=[y for y in sample if y-1 in target and target[y-1]>0 and target[y]>0]
        dep=[100*math.log(target[y]/target[y-1]) for y in sample]
    elif mode=='log1p':
        sample=[y for y in sample if target[y]>=0]
        dep=[math.log1p(target[y]) for y in sample]
    elif mode=='log005':
        sample=[y for y in sample if target[y]>-0.05]
        dep=[math.log(target[y]+0.05) for y in sample]
    elif mode=='log':
        sample=[y for y in sample if target[y]>0]
        dep=[math.log(target[y]) for y in sample]
    else:dep=[target[y] for y in sample]
    if len(sample)<max(5,len(inputs)+2):raise ValueError(f'Sin muestra suficiente para {key}')
    def x(y):
        row=D[y]
        vals=[]
        for c in inputs:
            if isinstance(c,int):vals.append(float(row[c]))
            elif len(c)==3:vals.append(float((changes or {}).get(c[0],{}).get(str(y-c[2]),row[c[1]])))
            else:vals.append(float(_macro(D,c[0],y,c[1],changes)))
        return [1.]+vals
    beta=_fit(dep,[x(y) for y in sample],models,key)
    def predict(y):
        z=float(np.dot(beta,x(y)))
        if mode=='pct':return target[y-1]*(1+z/100)
        if mode=='growthlog':return target[y-1]*math.exp(z/100)
        if mode=='log1p':return max(0,math.expm1(max(-12,min(12,z))))
        if mode=='log005':return max(0,math.exp(max(-40,min(40,z)))-0.05)
        if mode=='log':return math.exp(max(-40,min(40,z)))
        return max(0,z) if key in {'12_adeudos','12_otras'} else z
    for y in range(2027,2031):
        if _status(models[key],y)=='forecast':
            target[y]=predict(y)
            _put(models,key,y,target[y])


def _ahorro(models, root, changes):
    Dmn = _data(_input(root, '08', '01_Ahorro_MN'))
    Dme = _data(_input(root, '08', '02_Ahorro_ME'))
    for key, D, mode in (('08_mn', Dmn, 'pct'), ('08_me', Dme, 'log')):
        saldo = _series(models, key)
        sample = [y for y in range(2017, 2027) if y in saldo and y-1 in saldo]
        sample += [y for y in range(2027, 2031) if _status(models[key], y) == 'observed' and y-1 in saldo]
        def features(y):
            if mode == 'pct':
                return [1., _macro(D, 'pbi', y-1, 2, changes),
                        _macro(D, 'inflacion', y-1, 3, changes), float(D[y][4])]
            return [1., _macro(D, 'tc_cierre', y-1, 2, changes) -
                    _macro(D, 'tc_cierre', y-2, 2, changes)]
        y = [100*(saldo[t]/saldo[t-1]-1) if mode=='pct'
             else 100*math.log(saldo[t]/saldo[t-1]) for t in sample]
        beta = _fit(y, [features(t) for t in sample],models,key)
        for year in range(2027, 2031):
            if _status(models[key],year) != 'forecast':
                continue
            z = float(np.dot(beta, features(year)))
            saldo[year] = saldo[year-1]*(1+z/100 if mode=='pct' else math.exp(z/100))
            if saldo[year] <= 0:
                raise ValueError(f'Saldo no positivo para {key}/{year}')
            _put(models, key, year, saldo[year])


def _plazo(models,root,changes):
    # Reutilizar el cierre estacional aprobado al incorporar un nuevo mes SBS;
    # la calibración y su muestra 2021–2025 permanecen idénticas.
    latest=next((row.get('sourceMonth') for row in models['09_plazo']['annual']
                 if row['year']==2026),None)
    if latest:
        from motor_08_22 import _calibrar_plazo_base_2026
        _calibrar_plazo_base_2026(models,root,latest)
    D=_data(_input(root,'09','01_Plazo_ordinario'))
    vals=_series(models,'09_plazo')
    vals[2015]=float(D[2015][1])
    def features(t):
        # El diferencial TPM debe seguir el escenario; usar la columna F
        # histórica en un escenario nuevo congelaría indebidamente el shock.
        return [1.,_macro(D,'pbi',t-1,2,changes),
                _macro(D,'inflacion',t-1,3,changes),
                _macro(D,'tpm',t,4,changes)-_macro(D,'tpm',t-1,4,changes)]
    years=list(range(2016,2027))
    years += [y for y in range(2027,2031) if _status(models['09_plazo'],y)=='observed']
    beta=_fit([100*(vals[t]/vals[t-1]-1) for t in years],[features(t) for t in years],models,"09_plazo")
    for t in range(2027,2031):
        if _status(models['09_plazo'],t)=='forecast':
            growth=float(np.dot(beta,features(t)))
            vals[t]=vals[t-1]*(1+growth/100)
            _put(models,'09_plazo',t,vals[t])
    # El IASC contiene un plan corporativo de captaciones. No se trata de un
    # coeficiente ni un tope SBS: se mantiene separado de la elasticidad MCO.
    # Bajo shocks se conserva el ajuste de gestión y se mueve la senda MCO.
    import json
    plan_file=Path(root).parent/'Control_Supuestos'/'plan_captaciones_iasc.json'
    if plan_file.is_file():
        plan=json.loads(plan_file.read_text(encoding='utf-8'))
        reference=dict(vals)
        for year in range(2027,2031):
            if _status(models['09_plazo'],year)!='forecast':continue
            item=plan.get('plan_plazo_ordinario',{}).get(str(year))
            if item:
                # Cifra del plan + desviación de la MCO por cambios macro.
                value=reference[year]+float(item['plan_plazo'])-float(item['mco_base'])
            elif year>=2029:
                # Desde 2029 no hay cifra IASC: se retoma la tasa MCO.
                value=float(vals[year-1])*(reference[year]/reference[year-1])
            else:
                continue
            if value<=0:raise ValueError(f'M09 plan IASC: depósitos negativos en {year}')
            vals[year]=value
            _put(models,'09_plazo',year,value)
        models['09_plazo']['method']='MCO de depósitos a plazo con ajuste de gestión IASC 2027–2028 explícito y sensibilidad macro conservada'
        models['09_plazo']['planManagement']={
            'source':plan.get('fuente'),'years':list(map(int,plan.get('plan_plazo_ordinario',{}))),
            'notEconometricCoefficients':True}


def _mco_16(models,key,root,sub,features,changes=None):
    D=_data(_input(root,'16',sub)); P=_series(models,key)
    actual={y:math.log(v) for y,v in P.items() if v>0 and (y<=2026 or _status(models[key],y) in {'observed','assumed'})}
    if features=='inversiones':
        # Presupuesto exogeno de Tesoreria en M21: NO estimar AFS con ingresos.
        afs=_series(models,'21_venta')
        saldo_promedio_2026=(afs[2025]+afs[2026])/2
        if saldo_promedio_2026<=0:raise ValueError('M21 AFS: saldo promedio 2026 no positivo')
        rendimiento_2026=100*P[2026]/saldo_promedio_2026
        for year in range(2027,2031):
            if _status(models[key],year)!='forecast':continue
            promedio=(afs[year-1]+afs[year])/2
            _put(models,key,year,promedio*rendimiento_2026/100)
        models[key]['method']='Saldo promedio de inversiones M21 por rendimiento 2026 persistente'
        models[key]['dependencies']=['21_venta']
        models[key]['coefficients']=[]
        models[key]['statistics']={'rendimiento2026':rendimiento_2026,'m21Presupuesto':True}
        return
    def feat(y,values):
        if features=='disponible':return [_macro(D,'pbi',y,3,changes),values[y-1]]
        return [D[y][3]]
    sample=[y for y in sorted(actual) if y>=2017 and y in D and (features!='disponible' or y-1 in actual)]
    beta=_fit([actual[y] for y in sample],[[1.]+feat(y,actual) for y in sample],models,key)
    for year in range(2027,2031):
        if _status(models[key],year)!='forecast':continue
        value=float(np.dot(beta,[1.]+feat(year,actual)))
        actual[year]=value
        _put(models,key,year,math.exp(max(-40,min(40,value))))


def _creditos(models,root):
    # M16/01: rendimiento implicito anual = constante + M13 + COVID2020 + COVID2021.
    # Las dicotomicas no estan activas en 2027–2030. Sin mezcla excepcional en 2029.
    D=_data(_input(root,'16','01_Creditos'))
    saldos=_series(models,'07');tasas=_series(models,'13')
    ingresos=_series(models,'16_creditos')
    coeffs=models['16_creditos'].get('coefficients',[])
    if len(coeffs)!=4:raise ValueError('M16: faltan los cuatro parámetros M13/COVID2020/COVID2021')
    coef=np.array([float(x['value']) for x in coeffs],dtype=float)
    changed_2026=(abs((saldos[2025]+saldos[2026])/2-float(D[2026][3]))>1e-5
                  or abs(tasas[2026]-float(D[2026][4]))>1e-5
                  or abs(ingresos[2026]-float(D[2026][1]))>1e-5)
    if changed_2026:
        rend={t:float(D[t][2]) for t in range(2016,2026)}
        rend[2026]=100*ingresos[2026]/((saldos[2025]+saldos[2026])/2)
        years=list(range(2016,2027))
        X=[[1.,tasas[t],float(t==2020),float(t==2021)] for t in years]
        coef=_fit([rend[t] for t in years],X,models,'16_creditos')
        for n,name in enumerate(['Constante','Tasa activa tarjetas (M13)','COVID 2020','COVID 2021']):
            models['16_creditos']['coefficients'][n]['name']=name
    models['16_creditos']['estimatedEquationTex']=(rf'\widehat{{r}}_t={coef[0]:.7g}{coef[1]:+.7g}T_t'
                        rf'{coef[2]:+.7g}D_{{2020,t}}{coef[3]:+.7g}D_{{2021,t}}')
    models['16_creditos']['method']='MCO anual del rendimiento implicito: M13 + COVID 2020 + COVID 2021'
    models['16_creditos'].setdefault('statistics',{}).pop('horizon3',None)
    for t in range(2027,2031):
        if _status(models['16_creditos'],t)=='forecast':
            tasa=float(np.dot(coef,[1.,tasas[t],float(t==2020),float(t==2021)]))
            nuevo=(saldos[t-1]+saldos[t])/2*tasa/100
            _put(models,'16_creditos',t,nuevo)

def _personal(models,root,changes,observaciones=None):
    D=_data(_input(root,'19','01_Personal'))
    staff={t:float(D[t][6]) for t in range(2016,2027)}
    headcount=(observaciones or {}).get('trabajadores_falabella',{})
    for year,value in headcount.items():
        if str(year).isdigit() and 2016<=int(year)<=2026:
            if not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:
                raise ValueError('M19 personal: dotación SBS no positiva/no finita')
            staff[int(year)]=float(value)
    # Cierre supuesto 2026 incluido como décima observación, coherente
    # con la especificación de la ficha M19 y con el resto del motor IASPE.
    years=list(range(2017,2027))
    beta=_fit([100*math.log(staff[t]/staff[t-1]) for t in years],
              [[1.,float(D[t][2]),float(t in (2020,2021))] for t in years],
              models, '19_personal')
    models['19_personal']['statistics']['period']='2017–2026 (cierre supuesto)'
    models['19_personal']['method']='MCO: crecimiento del personal, PBI y dicotómica 2020–2021 (2017–2026); salarios con personal promedio e inflación' 
    for t in range(2027,2031):
        staff[t]=staff[t-1]*math.exp(float(np.dot(beta,[1.,_macro(D,'pbi',t,2,changes),0.]))/100)
    avg={t:(staff[t]+staff[t-1])/2 for t in range(2017,2031)}
    G=_series(models,'19_personal')
    for t in range(2027,2031):
        if _status(models['19_personal'],t)=='forecast':
            G[t]=G[t-1]*(avg[t]/avg[t-1])*(1+_macro(D,'inflacion',t,3,changes)/100)
            _put(models,'19_personal',t,G[t])


def _caja(models,root):
    D=_rows(_input(root,'17','01_Caja'),'Mensual')
    values={str(r[0]):float(r[1]) for r in D[1:] if isinstance(r[0],str) and isinstance(r[1],(float,int))}
    file=Path(root).parent/'Scraper'/'EEFF_Benchmark'/'output'/'panel_eeff_16_bancos.json.gz'
    if file.is_file():
        with gzip.open(file,'rt',encoding='utf-8') as f:panel=json.load(f)
        # Solo pueden entrar meses APLICADOS por «Recalcular modelos».
        # Descargar una fuente no debe alterar silenciosamente el escenario base.
        applied=max(['2026-08']+[str(r['sourceMonth']) for r in models['17_caja']['annual']
                   if r.get('sourceMonth')])
        for k,v in panel.get('series',{}).get('balance:001',{}).get('05',{}).items():
            if '2026-08'<k<=applied and isinstance(v,(float,int)) and math.isfinite(v):
                values[k]=float(v)
    dates=sorted(k for k in values if k>='2016-01')
    required=max((r.get('sourceMonth','') for r in models['17_caja']['annual'] if r['year']>=2027 and r['status']!='forecast'),default='')
    if required and (not dates or dates[-1]<required):raise ValueError(f'Serie mensual incompleta: 17_caja, {required}')
    nums=np.array([values[d] for d in dates],float)
    beta=_fit(nums[13:],[[1.,nums[i-1]] for i in range(13,len(nums))],models,"17_caja")
    current=nums[-1];latest=dates[-1]
    bymonth=dict(values)
    for y in range(int(latest[:4]),2031):
        for m in range(1,13):
            date=f'{y}-{m:02d}'
            if date<=latest:continue
            current=float(beta[0]+beta[1]*current)
            bymonth[date]=current
    # Sincronizar la serie mensual del modelo con la trayectoria efectivamente
    # recalculada; antes el annual cambiaba pero el monthly conservaba el
    # pronóstico previo, provocando falsos errores de persistencia.
    for row in models['17_caja'].get('monthly',[]):
        month=str(row.get('date',''))[:7]
        if month<='2026-08' or month not in bymonth:continue
        v=float(bymonth[month])
        state='observed' if month<=latest else ('assumed' if month<'2027-01' else 'forecast')
        row.update(value=v,status=state,
                   observed=v if state=='observed' else None,
                   assumed=v if state=='assumed' else None,
                   forecast=v if state=='forecast' else None)
    # Para Caja el cierre 2026 siempre es diciembre, no el último stock
    # observado (septiembre, octubre, etc.). La MCO mensual original genera
    # los meses faltantes; nunca se distribuye un supuesto macroeconómico.
    if _status(models['17_caja'],2026)=='assumed' and '2026-12' in bymonth:
        december=float(bymonth['2026-12'])
        for row in models['17_caja']['annual']:
            if row['year']==2026:
                row.update(value=december,assumed=december,observed=None,forecast=None)
        models['17_caja']['reestimated']=True
    for year in range(2027,2031):
        _put(models,'17_caja',year,bymonth[f'{year}-12'])


def _bancos(models,root):
    D=_data(_input(root,'17','02_Bancos_y_corresponsales'))
    b=_series(models,'17_bancos')
    dep=_series(models,'10')
    sample=list(range(2017,2027))
    sample += [y for y in range(2027,2031) if _status(models['17_bancos'],y)=='observed']
    beta=_fit([b[y]-b[y-1] for y in sample],
              [[1.,dep[y]-dep[y-1]] for y in sample],models,"17_bancos")
    for y in range(2027,2031):
        if _status(models['17_bancos'],y)=='forecast':
            b[y]=b[y-1]+float(np.dot(beta,[1.,dep[y]-dep[y-1]]))
            _put(models,'17_bancos',y,b[y])


def _ingresos_diversos(models,root,changes):
    """M18 aprobado: promedio en niveles 75% inflación + 25% compras.

    Cada regresión tiene pronóstico recursivo independiente desde el cierre
    vigente 2026; el IASPE anterior NO interviene en los parámetros.
    """
    D=_data(_input(root,'18','01_Ingresos_diversos'))
    ingresos=_series(models,'18_diversos')
    compras_actual=_series(models,'03')
    compras={}
    for y in range(2016,2031):
        if y in compras_actual:
            compras[y]=float(compras_actual[y])
        elif y in D and isinstance(D[y][2],(int,float)):
            compras[y]=float(D[y][2])
    sample=[y for y in range(2017,2027) if y in ingresos and y-1 in ingresos
            and y in compras and y-1 in compras]
    sample += [y for y in range(2027,2031) if _status(models['18_diversos'],y)=='observed'
               and y in ingresos and y-1 in ingresos and y in compras and y-1 in compras]
    if len(sample)<8:raise ValueError('Histórico insuficiente para combinación M18 (2017–2026).')
    infl=lambda y:float((changes or {}).get('inflacion',{}).get(str(y),D[y][8]))
    growth=lambda y:100*math.log(ingresos[y]/ingresos[y-1])
    c_growth=lambda y:100*math.log(compras[y]/compras[y-1])
    Xinf=[[1.,infl(y),float(y==2018),float(y in (2020,2021))] for y in sample]
    betainf=_fit([growth(y) for y in sample],Xinf,models,'18_diversos')
    fit_compras=sm.OLS(np.array([growth(y) for y in sample]),
                       np.array([[1.,c_growth(y)] for y in sample])).fit()
    betacomp=np.asarray(fit_compras.params,float)
    # Los dos trayectos empiezan en el MISMO nivel de cierre aprobado,
    # evitando aplicar el promedio sobre tasas que no son comparables.
    last=max(sample)
    if last>2026 and any(y>last and y<=2030 for y in range(2027,2031)):
        # En caso de nueva observación, mantener el último cierre observado.
        anchor=last
    else:
        anchor=2026
    inf_path={anchor:float(ingresos[anchor])}
    comp_path={anchor:float(ingresos[anchor])}
    for year in range(anchor+1,2031):
        if year not in compras or year-1 not in compras:raise ValueError(f'Faltan compras M03 para {year}.')
        gi=float(np.dot(betainf,[1.,infl(year),0.,0.]))
        gc=float(np.dot(betacomp,[1.,100*math.log(compras[year]/compras[year-1])]))
        inf_path[year]=inf_path[year-1]*math.exp(gi/100)
        comp_path[year]=comp_path[year-1]*math.exp(gc/100)
        if year>=2027 and _status(models['18_diversos'],year)=='forecast':
            _put(models,'18_diversos',year,.75*inf_path[year]+.25*comp_path[year])
    m=models['18_diversos']
    m['method']='Combinación de MCO 75% inflación (con dummies) y 25% compras con tarjetas (M03)'
    m['equationTex']=r'\widehat I_t=0.75\widehat I_t^{inflacion}+0.25\widehat I_t^{compras}'
    m['dependencies']=['inflacion','03']
    stats=m.setdefault('statistics',{})
    stats['combinationWeights']={'inflacion':.75,'compras':.25}
    stats['modelCompras']={'intercept':float(betacomp[0]),'slope':float(betacomp[1]),
                           'adjustedRSquared':float(fit_compras.rsquared_adj),
                           'pValue':float(fit_compras.pvalues[1])}
    m['limitations']=['Muestra 2017–2026; 2026 es cierre supuesto.',
        'MAE backtest 2022–2025 a un año: MCO vigente 20.83 MM y combinación 75/25 18.85 MM.',
        'La combinación no mejora uniformemente las validaciones a 2–4 años.',
        'El IASPE anterior se usa solo como referencia externa, no para ajustar regresiones.']


def _fixed_median(models,key,years):
    values=[_value(models[key],year) for year in years]
    if any(value is None or not math.isfinite(value) for value in values):
        raise ValueError(f'{key}: faltan cierres de la ventana histórica aprobada')
    return float(statistics.median(values))


def _financial_source_months(models,observaciones,root):
    """Mismos flujos mensuales SBS que alimentan las fórmulas de los Inputs."""
    accounts={
        '12_obligaciones':{112:1},'12_entidades':{113:1},'12_adeudos':{115:1},
        '12_otras':{114:1,116:1,117:1},'16_creditos':{105:1},
        '16_inversiones':{104:1},'16_disponible':{102:1},'16_interbancarios':{103:1}}
    incoming=(observaciones or {}).get('sbs_contable',{})
    selected={key:str(incoming.get(key,{}).get('2026',{}).get('sourceMonth',''))[:7]
              for key in accounts if key in models}
    selected={key:period for key,period in selected.items() if period.startswith('2026-')}
    if not selected:return set()
    with gzip.open(Path(root).parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz','rt',encoding='utf-8') as file:
        panel=json.load(file)['series']
    changed=set()
    for key,period in selected.items():
        rows={str(row['date'])[:7]:dict(row) for row in models[key].get('monthly',[])}
        before={month:(row['value'],row['status']) for month,row in rows.items()}
        last=int(period[-2:]);previous=0.;flow=None
        for month in range(1,last+1):
            label=f'2026-{month:02d}'
            values=[panel.get(f'er_acumulado:{code}',{}).get('05',{}).get(label) for code in accounts[key]]
            if any(not isinstance(value,(int,float)) or not math.isfinite(value) for value in values):
                raise ValueError(f'{key}: falta el flujo SBS de {label}')
            accumulated=sum(values);flow=accumulated-previous;previous=accumulated
            row=rows.get(label,{'date':label,'year':2026})
            row.update(value=float(flow),status='observed',observed=float(flow),assumed=None,forecast=None)
            rows[label]=row
        if key.startswith('12'):
            for month in range(last+1,13):
                label=f'2026-{month:02d}';row=rows.get(label,{'date':label,'year':2026})
                row.update(value=float(flow),status='assumed',observed=None,assumed=float(flow),forecast=None)
                rows[label]=row
        if any(label not in before or before[label][1]!=row['status'] or abs(before[label][0]-row['value'])>1e-7
               for label,row in rows.items()):changed.add(key)
        models[key]['monthly']=[rows[label] for label in sorted(rows)]
    return changed


def _recent(models,key,count,stat,year=2031):
    rows=[r for r in models[key]['annual']
          if r['year']<year and r['status'] in ('observed','assumed')
          and isinstance(r['value'],(int,float)) and math.isfinite(r['value'])]
    values=[r['value'] for r in sorted(rows,key=lambda r:r['year'])[-count:]]
    if len(values)<count:
        raise ValueError(f'Histórico insuficiente: {key}')
    return stat(values)


def _forecasts_univariate(models,key,years,fn):
    for y in years:
        if _status(models[key],y)=='forecast':_put(models,key,y,fn(y))


def _depositos_menores(models,key,root,sub,panel_key):
    """Cierre con interanual reciente y 2027–2030 proporcional a M08+M09."""
    input_path=buscar_modelo(root,'10')/sub/'Input'/'Base_modelo.xlsx'
    rows=[r for r in _rows(input_path,'Mensual')[1:] if isinstance(r[0],str)]
    historical={str(r[0])[:7]:float(r[1]) for r in rows if isinstance(r[1],(int,float)) and str(r[0])[:7]<='2026-12'}
    panel_path=Path(root).parent/'Scraper'/'EEFF_Benchmark'/'output'/'panel_eeff_16_bancos.json.gz'
    last_allowed=max(['2026-08']+[str(r['sourceMonth']) for r in models[key]['annual']
                  if r.get('sourceMonth') and r['year']==2026])
    if panel_path.exists() and last_allowed>'2026-08':
        with gzip.open(panel_path,'rt',encoding='utf-8') as f:panel=json.load(f)
        for month,val in panel.get('series',{}).get('balance:'+panel_key,{}).get('05',{}).items():
            if '2026-08'<month<=last_allowed and isinstance(val,(float,int)) and math.isfinite(val):
                historical[month]=float(val)
    newer=[k for k in historical if '2026-08'<k<=last_allowed]
    if last_allowed>'2026-08' and (not newer or max(newer)!=last_allowed):
        raise ValueError(f'{key}: falta stock SBS de {last_allowed}')
    current_2026=float(_value(models[key],2026))
    if newer and _status(models[key],2026)!='observed':
        latest=max(newer)
        if latest=='2026-12':
            current_2026=historical[latest]
            status='observed'
        else:
            month=int(latest[-2:]);periods=[f'2026-{m:02d}' for m in range(month-2,month+1)]
            previous=[f'2025-{m:02d}' for m in range(month-2,month+1)]
            if any(m not in historical for m in periods+previous):
                raise ValueError(f'{key}: faltan tres meses comparables para cierre 2026')
            denominator=sum(historical[m] for m in previous)
            if denominator<=0:raise ValueError(f'{key}: base interanual no positiva')
            current_2026=historical['2025-12']*sum(historical[m] for m in periods)/denominator
            status='assumed'
        row=next(r for r in models[key]['annual'] if r['year']==2026)
        row.update(value=current_2026,status=status,
                   observed=current_2026 if status=='observed' else None,
                   assumed=current_2026 if status=='assumed' else None,forecast=None,
                   method='Cierre por crecimiento interanual de tres meses' if status=='assumed' else 'Cierre SBS observado')
        models[key]['reestimated']=True
    denominador=float(_value(models['08'],2026))+float(_value(models['09'],2026))
    if denominador<=0:raise ValueError('M10: depósitos de ahorro y plazo no positivos')
    ratio=current_2026/denominador
    annual={2026:current_2026}
    for y in range(2027,2031):
        annual[y]=ratio*(float(_value(models['08'],y))+float(_value(models['09'],y)))
        if annual[y]<0:raise ValueError(f'{key}/{y}: saldo negativo')
        _put(models,key,y,annual[y])
    rows={str(r.get('date',''))[:7]:dict(r) for r in models[key].get('monthly',[])}
    if newer:
        latest=max(newer)
        for month,v in historical.items():
            if '2026-08'<month<=latest:
                row=rows.get(month,{'date':month,'year':2026})
                row.update(value=v,status='observed',observed=v,forecast=None,assumed=None)
                rows[month]=row
        last_month=int(latest[-2:])
        for m in range(last_month+1,13):
            month=f'2026-{m:02d}'
            value=historical[latest]+(current_2026-historical[latest])*(m-last_month)/(12-last_month)
            row=rows.get(month,{'date':month,'year':2026})
            row.update(value=value,status='assumed',observed=None,forecast=None,assumed=value)
            rows[month]=row
    # Interpolación mensual de stocks entre los cierres de diciembre del método anual.
    for y in range(2027,2031):
        for month_int in range(1,13):
            month=f'{y}-{month_int:02d}'
            value=annual[y-1]+(annual[y]-annual[y-1])*month_int/12
            row=rows.get(month,{'date':month,'year':y})
            row.update(value=value,status='forecast',observed=None,assumed=None,forecast=value)
            rows[month]=row
    models[key]['monthly']=[rows[k] for k in sorted(rows)]
    models[key]['statistics']={'method':'participacion_fija','anchorYear':2026,
                               'ratioToSavingsAndTerm':ratio,'monthlyProjection':'interpolacion_cierres_anuales'}
    models[key]['method']='Participación fija sobre depósitos de ahorro y plazo (M08 + M09)'
    models[key]['reestimated']=True


def _group(models,original,parent,components,signs=None):
    signs=signs or {}
    for year in range(2026,2031):
        status=_status(models[parent],year)
        if year==2026 and status!='assumed':continue
        if year>2026 and status!='forecast':continue
        changes=0
        for key in components:
            if key not in models:continue
            before=_value(original[key],year)
            after=_value(models[key],year)
            if before is not None and after is not None:changes+=signs.get(key,1)*(after-before)
        # Preserva el residuo del consolidado original, si lo hubiera.
        base=_value(original[parent],year)
        if base is None:continue
        expected=base+changes
        if parent in {'08','09','10','20'}:
            # Estos consolidados son sumas exactas, sin residuo económico.
            # La recarga de Excel puede tener fórmulas cacheadas del Base ya
            # actualizado mientras sus componentes aún deben recalcularse.
            expected=sum(signs.get(k,1)*_value(models[k],year) for k in components)
        # No dejar que un total recalculado desde otro bloque diverja de sus
        # componentes cuando el cambio neto de estos es exactamente cero.
        current=_value(models[parent],year)
        if abs(changes)<1e-10 and current is not None and abs(current-expected)<1e-10:continue
        if year==2026:
            # El cierre SBS anterior a diciembre es una estimación (no un
            # cierre observado). Proyectar el total y cada subcuenta mediante
            # factores interanuales distintos puede generar una diferencia.
            # La identidad contable se construye desde los componentes; la
            # extrapolación independiente se conserva como trazabilidad.
            current=_value(models[parent],year)
            if current is not None and abs(current-expected)>0.05:
                models[parent]['sbsReconciliation'] = {
                    'year': 2026,
                    'independentEstimate': float(current),
                    'componentsEstimate': float(expected),
                    'difference': float(current-expected),
                    'reason': 'Cierre provisional: total conciliado a partir de componentes SBS; sin modificar la fuente.'
                }
            for row in models[parent]['annual']:
                if row['year']==2026:
                    row.update(value=float(expected),status='assumed',assumed=float(expected),observed=None,forecast=None)
            models[parent]['reestimated']=True
        else:
            _put(models,parent,year,expected)


def ejecutar(models,original,observaciones,cambios,root):
    relevant={k for k,v in models.items() if k in original and k in models and
              any(y>=2026 and _value(original[k],y) is not None and
                  abs(float(r['value'])-_value(original[k],y))>1e-6
                  for r in v.get('annual',[]) for y in [r['year']])}
    relevant.update(_financial_source_months(models,observaciones,root))
    relevant.add('11')
    # Seguridad de versión: si la regresión M16 cambió, actualizar todas las
    # proyecciones y sus cuentas dependientes, aunque el origen SBS sea idéntico.
    if '16_creditos' in models and len(models['16_creditos'].get('coefficients',[]))==4:
        try:
            coef=[float(p['value']) for p in models['16_creditos']['coefficients']]
            cartera=_series(models,'07');tasas=_series(models,'13');ingresos=_series(models,'16_creditos')
            if any(abs(ingresos[y]-(cartera[y-1]+cartera[y])/2*(coef[0]+coef[1]*tasas[y])/100)>1e-5
                   for y in range(2027,2031)):
                relevant.add('16_creditos')
        except (KeyError,ValueError,TypeError) as exc:
            raise ValueError('M16: no se pudo verificar la identidad de rendimiento.') from exc
    # La trayectoria de terceros depende del PBI aun cuando otros modelos no hayan variado.
    # Debe recalcularse también ante un cambio únicamente en el PBI proyectado.
    if (cambios or {}).get('pbi'):
        relevant.add('19_terceros')
        relevant.update(('18_gastos_div','16_disponible','19_personal'))
    if (cambios or {}).get('inflacion'):
        relevant.update(('18_diversos','19_impuestos','19_personal','12_entidades'))
    if (cambios or {}).get('tpm'):
        relevant.update(('12_entidades','12_adeudos','12_otras'))
    # Propagar actualizaciones de fórmulas de subcomponentes al consolidado.
    if all(k in models for k in ('20','20_consorcios','20_asociadas','20_tc','20_derivados','20_inversiones','20_otros')):
        parts=('20_consorcios','20_asociadas','20_tc','20_derivados','20_inversiones','20_otros')
        if any(abs(_value(models['20'],yr)-sum(_value(models[k],yr) for k in parts))>1e-4
               for yr in range(2027,2031)):
            relevant.add('20_tc')
    for key in ('17_canje','17_otros'):
        source=(observaciones or {}).get('sbs_contable',{}).get(key,{}).get('2026',{})
        latest=str(source.get('sourceMonth',''))[:7]
        observed=[str(row.get('date',''))[:7] for row in models[key].get('monthly',[])
                  if row.get('status')=='observed']
        if latest and latest>max(observed,default=''):
            relevant.add(key)
    if not relevant:return []
    errors=[]
    def attempt(key,func):
        try:func()
        except (ValueError,KeyError,IndexError,ZeroDivisionError,OverflowError,FileNotFoundError,TypeError) as exc:
            errors.append(f'{key}: {exc}')
    active=lambda *keys:any(k in relevant or models.get(k,{}).get('reestimated') for k in keys)
    if active('08_mn', '08_me'):
        attempt('08_mn/08_me',lambda:_ahorro(models,root,cambios))
        if not errors:
            _group(models,original,'08',['08_mn','08_me'])
    if active('09_cts','09_plazo'):
        attempt('09_cts',lambda:_plain_mco(models,'09_cts',root,'09','02_CTS','pct',[2],cambios,2016))
        attempt('09_plazo',lambda:_plazo(models,root,cambios))
    # Consolidar primero M09 para que las proporciones de cuentas menores
    # M10 utilicen el fondeo del nuevo cierre y no el consolidado anterior.
    if active('09','09_cts','09_plazo'):_group(models,original,'09',['09_cts','09_plazo'])
    if active('08','09','10_restringidos','10_otras','09_cts','09_plazo'):
        attempt('10_restringidos',lambda:_depositos_menores(models,'10_restringidos',root,'01_Depositos_restringidos','050'))
        attempt('10_otras',lambda:_depositos_menores(models,'10_otras',root,'02_Otras_obligaciones','051'))
    if active('09','10_restringidos','10_otras','08'):
        _group(models,original,'10',['08','09','10_restringidos','10_otras'])
    if active('10','09','11'):
        attempt('11',lambda:_costos_depositos(models,root,cambios))
    if active('10','11','12_obligaciones'):
        attempt('12_obligaciones',lambda:_gastos_obligaciones(models,root))
    if active('12_entidades','12_adeudos','12_otras','12_obligaciones','10','11'):
        attempt('12_entidades',lambda:_plain_mco(models,'12_entidades',root,'12','02_Depositos_entidades_financieras','log005',[("tpm",3),("inflacion",4)],cambios,2016))
        attempt('12_adeudos',lambda:_plain_mco(models,'12_adeudos',root,'12','03_Adeudos','level',[("tpm",2),3],cambios,2016))
        attempt('12_otras',lambda:_plain_mco(models,'12_otras',root,'12','04_Otras_fuentes','log1p',[("tpm",3,1)],cambios,2017))
        _group(models,original,'12',['12_obligaciones','12_entidades','12_adeudos','12_otras'])
    if active('16_creditos','07','13'):
        attempt('16_creditos',lambda:_creditos(models,root))
    if active('16_inversiones','21_venta'):
        attempt('16_inversiones',lambda:_mco_16(models,'16_inversiones',root,'02_Inversiones','inversiones',cambios))
    if active('16_disponible','17'):
        attempt('16_disponible',lambda:_mco_16(models,'16_disponible',root,'03_Disponibilidades','disponible',cambios))
    if active('16_interbancarios','22'):
        attempt('16_interbancarios',lambda:_mco_16(models,'16_interbancarios',root,'04_Interbancarios','interbancarios'))
    if active('17_caja'):
        attempt('17_caja',lambda:_caja(models,root))
    if active('17_bancos','10'):
        attempt('17_bancos',lambda:_bancos(models,root))
    if active('18_diversos','03'):
        attempt('18_diversos',lambda:_ingresos_diversos(models,root,cambios))
    if active('18_gastos_div','18_diversos'):
        def expenses():
            gasto=_series(models,'18_gastos_div')
            ingresos=_series(models,'18_diversos')
            if ingresos[2026]<=0:raise ValueError('M18 gastos: ingreso de referencia 2026 no positivo.')
            razon=gasto[2026]/ingresos[2026]
            for y in range(2027,2031):
                if _status(models['18_gastos_div'],y)=='forecast':
                    _put(models,'18_gastos_div',y,razon*ingresos[y])
            models['18_gastos_div']['method']='Relación gastos/ingresos 2026 aplicada a ingresos diversos proyectados'
            models['18_gastos_div']['equationTex']=r'GastosDiv_t=(GastosDiv_{2026}/IngresosDiv_{2026})\,IngresosDiv_t'
            models['18_gastos_div']['updateRule']='Recalcular ante cambios de ingresos diversos y mantener fijo el ratio observado/supuesto de 2026. No ajusta los datos de Riesgos.'
        attempt('18_gastos_div',expenses)
    if active('18_fsd','10'):
        def fsd():
            oblig=_series(models,'10');costo=_series(models,'18_fsd')
            ratio=costo[2026]/oblig[2026]
            for y in range(2027,2031):_put(models,'18_fsd',y,oblig[y]*ratio)
        attempt('18_fsd',fsd)
    if active('17_canje'):
        base=_series(models,'17_canje')
        attempt('17_canje',lambda:_forecasts_univariate(models,'17_canje',range(2027,2031),lambda y:_fixed_median(models,'17_canje',range(2021,2026))))
    if active('17_otros'):
        base=_series(models,'17_otros')
        attempt('17_otros',lambda:_forecasts_univariate(models,'17_otros',range(2027,2031),lambda y:_fixed_median(models,'17_otros',range(2021,2026))))
    # La serie mensual de Disponible debe reproducir la nueva trayectoria anual.
    for mid in ('17_canje','17_otros'):
        if not active(mid):continue
        current=_series(models,mid)
        source=(observaciones or {}).get('sbs_contable',{}).get(mid,{}).get('2026',{})
        latest=str(source.get('sourceMonth',''))[:7]
        incoming={}
        if latest:
            with gzip.open(Path(root).parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz','rt',encoding='utf-8') as file:
                panel=json.load(file)
            code='balance:003' if mid=='17_canje' else 'balance:004'
            incoming={month:value for month,value in panel['series'][code]['05'].items()
                      if '2026-08'<month<=latest}
        for row in models[mid].get('monthly',[]):
            period=str(row.get('date',''))[:7]
            if period in incoming:
                value=float(incoming[period])
                row.update(value=value,status='observed',observed=value,assumed=None,forecast=None)
            elif period=='2026-12' and mid in relevant and row.get('status')!='observed':
                row.update(value=float(current[2026]), status='assumed',assumed=float(current[2026]),forecast=None,observed=None)
            elif period>='2027-01' and period<='2030-12' and row.get('status')=='forecast':
                year=int(period[:4]);v=float(current[year])
                row.update(value=v,forecast=v,assumed=None,observed=None)
    if active('18_otros_ing'):
        base=_series(models,'18_otros_ing');med=_fixed_median(models,'18_otros_ing',range(2023,2026))
        _forecasts_univariate(models,'18_otros_ing',range(2027,2031),lambda y:med)
    if active('18_otros_gastos'):
        base=_series(models,'18_otros_gastos');med=_fixed_median(models,'18_otros_gastos',range(2023,2026))
        _forecasts_univariate(models,'18_otros_gastos',range(2027,2031),lambda y:med)
    if active('19_personal'):
        # El gasto SBS entra después del primer bloque de dotación. Repetir
        # la misma transmisión con ese cierre vigente evita guardar salarios
        # anclados al gasto anterior y cambiarlos al reiniciar la plataforma.
        attempt('19_personal',lambda:_personal(models,root,cambios,observaciones))
    if active('19_directorio'):
        base=_series(models,'19_directorio')
        for y in range(2027,2031):
            if _status(models['19_directorio'],y)=='forecast':
                base[y]=base[y-1]
                _put(models,'19_directorio',y,base[y])
    if active('19_impuestos'):
        D=_data(_input(root,'19','04_Impuestos_y_contribuciones'))
        base=_series(models,'19_impuestos')
        for y in range(2027,2031):
            if _status(models['19_impuestos'],y)=='forecast':
                base[y]=base[y-1]*(1+_macro(D,'inflacion',y,3,cambios)/100)
                _put(models,'19_impuestos',y,base[y])
    if models.get('19_personal',{}).get('reestimated') and models['19_personal'].get('canUpdate'):
        models['19_personal']['status']='ok'
        models['19_personal'].pop('issues',None)
    if active('19_terceros'):
        def third():
            # 2017–2026: se conservan el cierre supuesto 2026 y dos regresiones.
            # Cada modelo recorre su propio sendero de pronóstico y solo al final
            # Las dos MCO se combinan con peso PBI 75% y rezago 25% en todos los horizontes.
            # La referencia de IASPE anterior NO interviene en esta estimación.
            D=_data(_input(root,'19','03_Servicios_de_terceros'))
            base=_series(models,'19_terceros')
            t=list(range(2017,2027))
            pbi=lambda year:_macro(D,'pbi',year,2,cambios)
            growth=[100*math.log(base[y]/base[y-1]) for y in t]
            fit_pbi=sm.OLS(np.asarray(growth,float),np.asarray([[1,pbi(y)] for y in t],float)).fit()
            fit_lag=sm.OLS(np.asarray([base[y] for y in t],float),
                           np.asarray([[1,pbi(y),base[y-1]] for y in t],float)).fit()
            robust_pbi=fit_pbi.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
            robust_lag=fit_lag.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
            pred_pbi={2026:base[2026]}
            pred_lag={2026:base[2026]}
            for y in range(2027,2031):
                pred_pbi[y]=pred_pbi[y-1]*math.exp(float(np.dot(fit_pbi.params,[1,pbi(y)]))/100)
                pred_lag[y]=float(np.dot(fit_lag.params,[1,pbi(y),pred_lag[y-1]]))
                if _status(models['19_terceros'],y)=='forecast':
                    _put(models,'19_terceros',y,.75*pred_pbi[y]+.25*pred_lag[y])
            model=models['19_terceros']
            names=[('MCO PBI: constante',robust_pbi,0),('MCO PBI: crecimiento real',robust_pbi,1),
                   ('MCO rezago: constante',robust_lag,0),('MCO rezago: PBI real',robust_lag,1),
                   ('MCO rezago: gasto anterior',robust_lag,2)]
            model['coefficients']=[{'name':name,'value':float(res.params[i]),
                        'se':float(res.bse[i]),'pValue':float(res.pvalues[i])}
                        for name,res,i in names]
            model['statistics'].update(combinationWeights={'2027-2030':{'pbi':.75,'lagged':.25}},
                        adjustedR2Pbi=float(fit_pbi.rsquared_adj),
                        adjustedR2Lagged=float(fit_lag.rsquared_adj),
                        covariance='HAC / Newey-West (1 rezago)')
            model['method']='Combinación constante MCO 75% PBI y 25% PBI + gasto rezagado (2027–2030)'
            model['equationTex']=r'\widehat G_t=0.75\widehat G_t^{PBI}+0.25\widehat G_t^{PBI,rezago}'
            model['updateRule']='Reestimar ambas MCO con cierre vigente; combinación 75/25 constante en 2027–2030, sin utilizar la referencia IASC para estimar.'
        attempt('19_terceros',third)
    if active('20_consorcios','05'):
        def consorcios():
            base=_series(models,'20_consorcios');cards=_series(models,'05')
            if cards[2026]<=0:
                raise ValueError('M20 consorcios: saldo de tarjetas 2026 no positivo')
            for year in range(2027,2031):
                _put(models,'20_consorcios',year,base[2026]*cards[year]/cards[2026])
        attempt('20_consorcios',consorcios)
    if active('20_asociadas'):
        base=_series(models,'20_asociadas');med=_fixed_median(models,'20_asociadas',range(2023,2026))
        _forecasts_univariate(models,'20_asociadas',range(2027,2031),lambda y:med)
    if active('20_derivados'):
        base=_series(models,'20_derivados');med=_fixed_median(models,'20_derivados',range(2023,2026))
        _forecasts_univariate(models,'20_derivados',range(2027,2031),lambda y:med)
    if active('20_tc','20_derivados','03'):
        # FX y derivados: relación con el volumen de compras M03, anclada en 2026.
        fx=_series(models,'20_tc');der=_series(models,'20_derivados')
        compras=_series(models,'03')
        if compras[2026]<=0:
            raise ValueError('M20: compras del mercado 2026 no positivas')
        ratio=(fx[2026]+der[2026])/compras[2026]
        models['20_tc']['coefficients']=[]
        models['20_tc']['statistics']={'ratio2026':float(ratio),'driver':'03',
            'calibration':'FX+derivados sobre compras 2026'}
        models['20_tc']['method']='Resultado conjunto FX y derivados proporcional a compras M03; relación anclada en 2026'
        models['20_tc']['equationTex']=r'FX_t=(FX_{2026}+Der_{2026})\frac{ComprasM03_t}{ComprasM03_{2026}}-Der_t'
        for y in range(2027,2031):
            if _status(models['20_tc'],y)=='forecast':
                _put(models,'20_tc',y,float(ratio*compras[y]-der[y]))
    if active('20_inversiones'):
        base=_series(models,'20_inversiones');med=_fixed_median(models,'20_inversiones',range(2023,2026))
        _forecasts_univariate(models,'20_inversiones',range(2027,2031),lambda y:med)
    if active('20_otros'):
        base=_series(models,'20_otros');med=_fixed_median(models,'20_otros',range(2024,2027))
        _forecasts_univariate(models,'20_otros',range(2027,2031),lambda y:med)
    # M21_venta: presupuesto exogeno. No se reestima ni se le aplica M16.
    # Sus modificaciones SBS pasan hacia M16_inv, nunca en sentido inverso.
    if active('21_otras'):
        def otras():
            D=_data(_input(root,'21','03_Otras_inversiones'))
            for y in range(2027,2031):
                _put(models,'21_otras',y,sum(float(D[y][i]) for i in (1,2,3)))
        attempt('21_otras',otras)
    if active('21_asociadas','20_asociadas'):
        def shares():
            D=_data(_input(root,'21','02_Subsidiarias_y_asociadas'))
            base=_series(models,'21_asociadas');div=statistics.median(float(D[y][3]) for y in (2023,2024,2025))
            for t in range(2027,2031):
                if _status(models['21_asociadas'],t)=='forecast':
                    base[t]=base[t-1]+_value(models['20_asociadas'],t)-div
                    _put(models,'21_asociadas',t,base[t])
        attempt('21_asociadas',shares)
    if active('22_interbancarios'):
        base=_series(models,'22_interbancarios')
        for t in range(2027,2031):
            if _status(models['22_interbancarios'],t)=='forecast':
                v=statistics.median(base[y] for y in range(t-4,t))
                base[t]=v
                _put(models,'22_interbancarios',t,v)
    # Cuentas menores: supuestos históricos sin nuevos modelos econométricos.
    # Se conservan como supuestos históricos explícitos hasta obtener drivers
    # contables o comerciales verificables; no se presentan como estresados.
    for key, window in {
        '17_canje': 5, '17_otros': 5,
        '18_otros_ing': 3, '18_otros_gastos': 3,
        '20_asociadas': 3, '20_derivados': 3,
        '20_inversiones': 3, '20_otros': 3,
        '22_interbancarios': 4
    }.items():
        if active(key) and key in models:
            years=(2021,2025) if key in ('17_canje','17_otros') else (2024,2026) if key=='20_otros' else (2023,2025)
            models[key]['method'] = (f'Supuesto histórico: mediana fija {years[0]}–{years[1]}'
                                      if key!='22_interbancarios' else 'Mediana móvil de cuatro cierres, recursiva')
            models[key]['updateRule'] = 'Conservar la ventana histórica aprobada; incorporar observaciones sin tratar un cierre supuesto como observado.'
            models[key].setdefault('statistics', {})['modelRisk'] = 'Supuesto histórico; proyección no vinculada directamente a regresores macroeconómicos'

    for parent,components in (
        ('16',['16_creditos','16_inversiones','16_disponible','16_interbancarios']),
        ('17',['17_caja','17_bancos','17_canje','17_otros']),
        ('18',['18_diversos','18_otros_ing','18_gastos_div','18_otros_gastos']),
        ('19',['19_personal','19_directorio','19_terceros','19_impuestos']),
        ('20',['20_consorcios','20_asociadas','20_tc','20_derivados','20_inversiones','20_otros']),
        ('21',['21_venta','21_asociadas','21_otras']),
        ('22',['22_interbancarios'])):
        if active(*components):
            signs={'18_gastos_div':-1,'18_otros_gastos':-1} if parent=='18' else None
            _group(models,original,parent,components,signs=signs)
    return errors
