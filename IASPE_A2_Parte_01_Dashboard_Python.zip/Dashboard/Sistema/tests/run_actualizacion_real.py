"""Ejecuta una actualización real por la API local y guarda evidencia.

Modifica las bases observadas activas. --recalculate publica además el recálculo
en los Excel, usando exclusivamente el mecanismo normal de IASPE.
No inicia el actualizador de proyecciones externas ni simula fuentes oficiales.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import sys
import threading
import time
from urllib.parse import urlencode

import requests
from openpyxl import load_workbook
from openpyxl.utils.datetime import from_excel

SYSTEM=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(SYSTEM))
import actualizador_sbs as updater
import motor
import servidor
from instituciones_sbs import BANKS,CENCOSUD_ID,match_entity


def month_value(value):
    if hasattr(value,'strftime'):
        return value.strftime('%Y-%m')
    if isinstance(value,(int,float)) and 30000<value<80000:
        return from_excel(value).strftime('%Y-%m')
    return str(value)[:7]


def eeff_excel_sample(meta,section,label,period):
    entity=next(b for b in meta['banks'] if b['id']==CENCOSUD_ID)
    path=updater.PROJECT/entity['source']
    sheet={'balance':'SITUACION_FINANCIERA','er_acumulado':'ESTADO_RESULTADOS'}[section]
    wb=load_workbook(path,read_only=True,data_only=True)
    values=[]
    try:
        rows=wb[sheet].iter_rows()
        for row_number,cells in enumerate(rows,1):
            if row_number==6:
                columns=[cell.column for cell in cells[1:] if month_value(cell.value)==period]
                if len(columns)!=1:
                    raise ValueError('Periodo EEFF no identificado inequívocamente en su Excel')
                column=columns[0]
            if row_number>=7 and str(cells[0].value or '').strip().upper()==label:
                cell=cells[column-1]
                if isinstance(cell.value,(int,float)):
                    values.append((cell.coordinate,float(cell.value)/1000))
    finally:
        wb.close()
    if len({round(v,12) for _,v in values})!=1:
        raise ValueError('Cuenta EEFF ambigua o sin valor para el periodo')
    return {'file':str(path.relative_to(updater.PROJECT)),'sheet':sheet,
            'cells':[c for c,_ in values],'period':period,'value':values[0][1],'unit':'S/ millones'}


class QuietHandler(servidor.Handler):
    def log_message(self,*args):
        pass


def benchmark_checks(base):
    def get(path):
        response=requests.get(base+path,timeout=90)
        response.raise_for_status()
        return response.json()
    results=[]
    meta=get('/api/benchmark/eeff')
    for section,label in [('balance','TOTAL ACTIVO'),('er_acumulado','RESULTADO NETO DEL EJERCICIO')]:
        account=next(a for a in meta['accounts'] if a['section']==section and a['name'].strip().upper()==label)
        data=get('/api/benchmark/eeff/account?'+urlencode({'account':account['id']}))
        samples=[{'period':r['date'],'value':r['banks'][CENCOSUD_ID]} for r in data['rows'] if CENCOSUD_ID in r['banks']]
        expected=eeff_excel_sample(meta,section,label,samples[-1]['period']) if samples else None
        results.append({'family':'estados_financieros','account':label,
                        'passed':bool(expected and math.isclose(samples[-1]['value'],expected['value'],rel_tol=1e-10,abs_tol=1e-8)),
                        'latest':samples[-1] if samples else None,'excel':expected,'unit':data['source']['unit']})
    ratios=get('/api/benchmark/ratios')
    values=ratios['series'].get('ratio_capital_global',{}).get(CENCOSUD_ID,[])
    csv_match=None
    if values:
        import ratios_sbs
        source=ratios_sbs._find_source()
        with source.open(encoding='utf-8-sig',newline='') as stream:
            for row in csv.DictReader(stream):
                if (row['banco_id']==CENCOSUD_ID and row['indicador_id']=='ratio_capital_global'
                    and row['fecha_indicador'][:7]==values[-1][0] and row['reporte']==values[-1][2]
                    and row['periodo_fuente']==values[-1][3] and row['url']==values[-1][5]):
                    csv_match={'file':str(source),'value':float(row['valor']),'cell':row['celda_valor'],'url':row['url']}
    results.append({'family':'ratios','series':'ratio_capital_global',
                    'passed':bool(csv_match and values[-1][1]==csv_match['value']),
                    'latest':values[-1] if values else None,'latestSourcePeriod':ratios.get('periodo_fin_fuente'),
                    'processed':csv_match,
                    'unit':'%','note':'La primera fecha es la efectiva; no necesariamente el mes del archivo.'})
    personal=get('/api/benchmark/personal')
    rows=[r for r in personal['registros'] if r['banco']==CENCOSUD_ID]
    personal_match=None
    import personal_sbs
    source=personal_sbs.source_path().with_name(personal_sbs.RURAL)
    if rows and source.is_file():
        with source.open(encoding='utf-8-sig',newline='') as stream:
            for row in csv.DictReader(stream):
                if match_entity(row['banco'])==CENCOSUD_ID and row['periodo']==rows[-1]['periodo']:
                    personal_match={key:None if row.get(key) in (None,'','-','—') else int(row[key]) for key in personal_sbs.COLUMNS}
    results.append({'family':'personal_rurales','series':'personal_total',
                    'passed':bool(personal_match and all(personal_match[k]==rows[-1][k] for k in personal_sbs.COLUMNS)),
                    'processed':personal_match,
                    'latest':rows[-1] if rows else None,'unit':'personas'})
    cartera=get('/api/benchmark/cartera-bancos')
    aggregate=get('/api/benchmark')
    last=cartera['rows'][-1]
    excel=load_workbook(aggregate['source']['workbook'],read_only=True,data_only=True)
    expected=None
    try:
        for row_number,raw in enumerate(excel['Mensual'].iter_rows(values_only=True),1):
            date=month_value(raw[0])
            if date==last['date']:
                expected={'row':row_number,'market':float(raw[3]),'falabella':float(raw[6])}
                break
    finally:
        excel.close()
    passed=bool(expected and math.isclose(last['mercado']['cartera'],expected['market'],rel_tol=1e-9,abs_tol=1e-7)
                and math.isclose(last['bancos']['falabella']['cartera'],expected['falabella'],rel_tol=1e-9,abs_tol=1e-7))
    results.append({'family':'cartera','passed':passed,'latestPeriod':last['date'],
                    'api':{'market':last['mercado']['cartera'],'falabella':last['bancos']['falabella']['cartera']},
                    'excel':dict(expected or {},file=aggregate['source']['workbook'],sheet='Mensual'),
                    'unit':'S/ millones'})
    for family,data,key in [('estados_financieros',meta,'banks'),('ratios',ratios,'bancos'),('personal_rurales',personal,'bancos')]:
        entity=next((b for b in data[key] if b['id']==CENCOSUD_ID),None)
        results.append({'family':family,'check':'Cencosud seleccionable, identificador y categoría',
                        'passed':bool(entity and entity.get('category')=='Cajas rurales' and entity.get('sbs_code')=='18'),
                        'entity':entity})
    return results


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sources',help='IDs separados por coma; por defecto todas las fuentes.')
    parser.add_argument('--recalculate',action='store_true')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--keep-open',type=int,default=0,help='Segundos de consulta posterior para QA de interfaz.')
    args=parser.parse_args()
    if os.environ.get('IASPE_SBS_SOLO_CACHE')=='1':
        raise RuntimeError('La validación real no admite IASPE_SBS_SOLO_CACHE=1')
    sources=args.sources.split(',') if args.sources else [s for s,_ in updater.SOURCES]
    evidence={'startedAt':datetime.now(timezone.utc).isoformat(),'mode':'red real; sin mocks',
              'sourcesRequested':sources,'benchmarks':[],'errors':[]}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    def save():
        args.output.write_text(json.dumps(evidence,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    server=servidor.Server(('127.0.0.1',0),QuietHandler)
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    base=f'http://127.0.0.1:{server.server_address[1]}'
    print('Validación IASPE:',base,flush=True)
    try:
        evidence['pendingBefore']=requests.get(base+'/api/models/pending',timeout=90).json()
        start=requests.post(base+'/api/sbs/start',json={'sources':sources,'banks':list(BANKS)},timeout=90)
        start.raise_for_status()
        evidence['start']=start.json()
        save()
        # Se comprueba la exclusión a través de HTTP, sin publicar un recálculo.
        for path,payload in [('/api/sbs/start',{'sources':sources}),('/api/models/recalculate',{})]:
            conflict=requests.post(base+path,json=payload,timeout=90)
            evidence.setdefault('concurrency',[]).append({'endpoint':path,'httpStatus':conflict.status_code,'response':conflict.json()})
            if conflict.status_code!=409:
                raise AssertionError('La operación incompatible no se bloqueó: '+path)
        deadline=time.monotonic()+7200
        previous=None
        while True:
            response=requests.get(base+'/api/sbs/status',timeout=90)
            response.raise_for_status()
            status=response.json()
            evidence['finalStatus']=status
            summary=[(t['id'],t['status']) for t in status['tasks'] if t['id'] in sources]
            if summary!=previous:
                print('Fuentes:',summary,flush=True)
                previous=summary
                save()
            if not status['running']:
                break
            if time.monotonic()>deadline:
                requests.post(base+'/api/sbs/stop',json={},timeout=30)
                raise TimeoutError('Tiempo máximo de actualización agotado; se solicitó detener.')
            time.sleep(3)
        evidence['pendingAfterDownload']=requests.get(base+'/api/models/pending',timeout=90).json()
        evidence['benchmarks']=benchmark_checks(base)
        save()
        if args.recalculate:
            response=requests.post(base+'/api/models/recalculate',json={},timeout=900)
            response.raise_for_status()
            payload=response.json()
            evidence['recalculation']=payload.get('recalculation',payload.get('lastRecalculation'))
            # Evidencia de la API operativa, además de los libros y snapshots.
            selected={'01','03','04','07','13','14','15','17_bancos','23','29','32','47_bancos','48'}
            evidence['modelSamples']={m['id']:{
                'annual':[r for r in m.get('annual',[]) if int(r['year'])>=2026],
                'monthly2026':[r for r in m.get('monthly',[]) if str(r.get('date','')).startswith('2026-')],
                'status':m.get('status'),
            } for m in payload.get('models',[]) if m['id'] in selected}
            evidence['pendingAfterRecalculation']=requests.get(base+'/api/models/pending',timeout=90).json()
            print('Recálculo:',json.dumps(evidence['recalculation'],ensure_ascii=True)[:4000],flush=True)
        evidence['complete']=evidence['finalStatus']['result']=='completo' and all(x['passed'] for x in evidence['benchmarks'])
        if args.recalculate:
            evidence['complete']=bool(evidence['complete'] and evidence['recalculation'].get('ok') and not evidence['pendingAfterRecalculation'].get('pending'))
        save()
        if args.keep_open>0:
            print('QA posterior disponible:',base,flush=True)
            time.sleep(args.keep_open)
    except Exception as exc:
        evidence['errors'].append(f'{type(exc).__name__}: {exc}')
        evidence['complete']=False
        raise
    finally:
        evidence['endedAt']=datetime.now(timezone.utc).isoformat()
        save()
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
    print('Evidencia:',args.output,'completa:',evidence['complete'],flush=True)


if __name__=='__main__':
    main()
