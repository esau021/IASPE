"""Servidor local IASPE. Los modelos originales se consultan en modo lectura."""
from __future__ import annotations

import argparse
import base64
import binascii
import csv
import gzip
import io
import json
import math
import mimetypes
import re
import traceback
import uuid
import zipfile
from datetime import date, datetime, timedelta, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, urlsplit, parse_qs

import motor
import benchmark
import benchmark_eeff
import cartera_consumo_bancos
import ratios_sbs
import control_iaspe
import personal_sbs
import actualizador_sbs
import monitor_fuentes
import normativa_sbs
import proyecciones_externas

ROOT = Path(__file__).resolve().parent
MAX_BODY = 16 * 1024 * 1024
STATIC = {'.html', '.js', '.css', '.svg', '.png', '.jpg', '.jpeg', '.ico', '.webp', '.woff', '.woff2', '.ttf', '.otf'}


def _scenarios():
    data = motor.read_state('escenarios.json', [])
    return data if isinstance(data, list) else []


def _number(value):
    if isinstance(value, bool):
        raise ValueError('El valor debe ser numérico.')
    if isinstance(value, str):
        value = value.strip().replace('\u00a0', '').replace(' ', '').replace('%', '')
        if ',' in value and '.' in value:
            value = value.replace('.', '').replace(',', '.') if value.rfind(',') > value.rfind('.') else value.replace(',', '')
        elif re.fullmatch(r'-?\d{1,3}(,\d{3})+', value):
            value = value.replace(',', '')
        elif re.fullmatch(r'-?\d{1,3}(\.\d{3}){2,}', value):
            value = value.replace('.', '')
        elif ',' in value:
            value = value.replace(',', '.')
    number = float(value)
    if not math.isfinite(number):
        raise ValueError('No se admiten valores vacíos o no finitos.')
    return number


def _period(value):
    if isinstance(value, (datetime, date)):
        return value.strftime('%Y-%m')
    if isinstance(value, (int, float)):
        if float(value).is_integer() and 1900 <= value <= 2200:
            return str(int(value))
        if 30000 <= value <= 100000:
            return (datetime(1899, 12, 30) + timedelta(days=float(value))).strftime('%Y-%m')
    text = str(value or '').strip()
    if re.fullmatch(r'\d{4}', text):
        return str(int(text))
    match = re.fullmatch(r'(\d{4})[-/](\d{1,2})(?:[-/]\d{1,2}(?:.*)?)?', text)
    if match:
        year, month = int(match[1]), int(match[2])
        datetime(year, month, 1)
        return f'{year:04d}-{month:02d}'
    match = re.fullmatch(r'(\d{1,2})/(\d{4})', text)
    if match:
        month, year = int(match[1]), int(match[2])
        datetime(year, month, 1)
        return f'{year:04d}-{month:02d}'
    for fmt in ('%d/%m/%Y', '%d-%m-%Y'):
        try:
            return datetime.strptime(text, fmt).strftime('%Y-%m')
        except ValueError:
            pass
    raise ValueError(f'Período no reconocido: {text!r}. Usa AAAA o AAAA-MM.')


def _validate_changes(changes):
    if changes is None:
        return {}
    if not isinstance(changes, dict):
        raise ValueError('Los cambios de escenario deben ser una matriz por variable y período.')
    _, macro_items = motor.load_base()
    allowed = {m['id'] for m in macro_items}
    result = {}
    for key, values in changes.items():
        if key not in allowed:
            raise ValueError(f'Variable de escenario no disponible: {key}.')
        if not isinstance(values, dict):
            raise ValueError(f'La senda de {key} debe contener períodos y valores.')
        cleaned = {_period(year): _number(value) for year, value in values.items()}
        if any(not 1990 <= int(period[:4]) <= 2030 for period in cleaned):
            raise ValueError('Los supuestos deben estar dentro del horizonte actual, hasta 2030.')
        result[key] = cleaned
    return result


def _horizon(value):
    """El laboratorio solo admite horizontes anuales dentro de 2026–2030."""
    if isinstance(value, bool) or str(value) not in {'2026', '2027', '2028', '2029', '2030'}:
        raise ValueError('El último año de proyección debe estar entre 2026 y 2030.')
    return int(value)


def _validate_macro_base_changes(changes):
    """Solo pronósticos futuros: nunca convertir observaciones históricas en supuestos."""
    result = _validate_changes(changes)
    for name, values in result.items():
        for period in values:
            if int(period[:4]) < 2026:
                raise ValueError('La base macro solo admite pronósticos de 2026 a 2030.')
            if name == 'pbi_mensual' and len(period) != 7:
                raise ValueError('El índice PBI mensual requiere fechas AAAA-MM.')
            if name != 'pbi_mensual' and len(period) != 4:
                raise ValueError(f'La variable {name} requiere un dato anual AAAA.')
    return result


def _validate_entries(entries):
    if not isinstance(entries, list) or not entries:
        raise ValueError('Introduce al menos una observación.')
    if len(entries) > 12000:
        raise ValueError('El archivo contiene demasiadas observaciones para una actualización.')
    models, macro_items = motor.load_base()
    macro_ids = {m['id'] for m in macro_items}
    result = []
    keys=set()
    for index, entry in enumerate(entries, 1):
        if not isinstance(entry, dict):
            raise ValueError(f'Fila {index}: cada observación debe indicar variable, período y valor.')
        mid = str(entry.get('id', ''))
        if mid not in models and mid not in macro_ids:
            raise ValueError(f'Fila {index}: variable no disponible: {mid}.')
        if mid in models and models[mid].get('canUpdate') is False:
            raise ValueError(f'{models[mid]["name"]} es un resultado derivado. Actualiza sus componentes.')
        period = _period(entry.get('period'))
        if not 1990 <= int(period[:4]) <= 2030:
            raise ValueError('El horizonte actual llega a 2030. No se permiten cierres fuera del horizonte sin ampliar los modelos.')
        if mid in macro_ids and len(period) != 4:
            raise ValueError(f'Fila {index}: la variable macroeconómica requiere un año (AAAA).')
        if mid in models:
            model=models[mid]
            historical_months=any(r.get('status')!='forecast' for r in model.get('monthly', []))
            if historical_months and len(period)!=7:
                raise ValueError(f'Fila {index}: {model.get("name",mid)} utiliza períodos mensuales (AAAA-MM).')
            if not historical_months and len(period)!=4:
                raise ValueError(f'Fila {index}: {model.get("name",mid)} requiere períodos anuales (AAAA).')
        if len(period)==7 and period>date.today().strftime('%Y-%m'):
            raise ValueError(f'Fila {index}: {period} todavía no es un mes observado.')
        if int(period[:4])>date.today().year:
            raise ValueError(f'Fila {index}: no se permite guardar un período futuro como observado.')
        key=(mid,period)
        if key in keys:
            raise ValueError(f'Fila {index}: la variable y el período {period} están duplicados.')
        keys.add(key)
        result.append({'id': mid, 'period': period, 'value': _number(entry.get('value'))})
    return result


def _previous_value(mid, period, models, macro_items, persisted):
    if str(period) in persisted.get(mid, {}):
        if mid in models:
            tabla = models[mid].get('monthly' if len(period) == 7 else 'annual', [])
            fila = next((r for r in tabla if (str(r.get('date', ''))[:7] if len(period) == 7 else str(r.get('year', ''))) == period), None)
            return persisted[mid][str(period)], fila.get('status', 'assumed') if fila else 'assumed'
        return persisted[mid][str(period)], 'assumed'
    if mid in models:
        rows = models[mid].get('monthly' if len(period) == 7 else 'annual', [])
        for row in rows:
            key = str(row.get('date', ''))[:7] if len(period) == 7 else str(row.get('year', ''))
            if key == period:
                return row.get('value'), row.get('status', '')
    for macro in macro_items:
        if macro.get('id') == mid:
            value = macro.get('values', {}).get(period)
            if value is None:
                value = macro.get('values', {}).get(int(period)) if len(period) == 4 else None
            if value is not None:
                return value, 'assumed' if int(period[:4]) >= 2026 else 'observed'
    return None, 'new'


def _update(entries, changes, commit=False, expected=None):
    entries = _validate_entries(entries)
    changes = _validate_changes(changes)
    with motor.LOCK:
        current = motor.read_state('observaciones.json', {})
        updated = json.loads(json.dumps(current))
        models, macros = motor.load_base()
        existing = motor.latest_observations()
        preview = []
        for entry in entries:
            mid, period, value = entry['id'], entry['period'], entry['value']
            old, status = _previous_value(mid, period, models, macros, existing)
            preview.append({**entry, 'previous': old, 'new': value, 'statusBefore': status,
                            'difference': value - old if isinstance(old, (int, float)) else None})
            updated.setdefault(mid, {})[period] = value
        effective = motor.latest_observations()
        for mid, records in updated.items():
            effective.setdefault(mid, {}).update(records)
        if commit:
            if not isinstance(expected, list) or len(expected)!=len(entries):
                raise ValueError('Primero verifica los cambios mediante la vista previa.')
            expected_by_key={(str(e.get('id','')),str(e.get('period',''))):e.get('previous') for e in expected if isinstance(e,dict)}
            if len(expected_by_key)!=len(entries):
                raise ValueError('La vista previa no coincide con los datos pendientes. Vuelve a validarlos.')
            for entry in entries:
                key=(entry['id'],entry['period'])
                if key not in expected_by_key:
                    raise ValueError('Se modificaron las filas después de la vista previa.')
                previous=next(row['previous'] for row in preview if row['id']==key[0] and row['period']==key[1])
                if previous!=expected_by_key[key]:
                    raise ValueError(f'El dato original de {key[1]} cambió desde la vista previa. Revisa nuevamente.')
        result = motor.calculate(changes, effective)
        if commit:
            # Respaldo local del estado anterior, antes de la publicación atómica.
            backups=motor.DATA / 'respaldos_manuales'
            backups.mkdir(parents=True,exist_ok=True)
            name='observaciones_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')+'.json'
            backup=backups/name
            backup.write_text(json.dumps(current,ensure_ascii=False,indent=2),encoding='utf-8')
            # Punto de control para instalaciones previas: la versión aplicada
            # queda congelada antes de guardar una nueva observación pendiente.
            if not (motor.DATA / 'observaciones_aplicadas.json').exists():
                motor.write_state('observaciones_aplicadas.json', current)
            motor.write_state('observaciones.json', updated)
            prior=sorted(backups.glob('observaciones_*.json'),reverse=True)
            for path in prior[30:]:
                try:path.unlink()
                except OSError:pass
        if commit:
            # El motor sigue publicando exclusivamente la versión aplicada.
            # El usuario recalcula después, igual que con la descarga automática.
            result = motor.calculate(changes)
            result['sourceUpdates'] = motor.pending_sources()
        result.update(preview=preview, entries=entries, committed=commit,
                      needsRecalculation=commit and result.get('sourceUpdates',{}).get('pending',False))
        return result


def _import_entries(payload):
    filename = str(payload.get('filename', ''))
    extension = Path(filename).suffix.lower()
    content = payload.get('content', '')
    if isinstance(content, str) and content.startswith('data:'):
        content = content.split(',', 1)[-1]
    try:
        raw = base64.b64decode(content, validate=True)
    except (binascii.Error, ValueError, TypeError):
        raise ValueError('El archivo no contiene datos base64 válidos.')
    if len(raw) > 10 * 1024 * 1024:
        raise ValueError('El archivo supera 10 MB.')
    if extension in {'.xlsx', '.xlsm'}:
        from openpyxl import load_workbook
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            if sum(x.file_size for x in archive.infolist()) > 150 * 1024 * 1024:
                raise ValueError('El contenido del libro es demasiado grande.')
        book = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        rows = list(book.worksheets[0].iter_rows(values_only=True))
        book.close()
    elif extension == '.xls':
        import xlrd
        book = xlrd.open_workbook(file_contents=raw)
        sheet = book.sheet_by_index(0)
        rows = [sheet.row_values(i) for i in range(sheet.nrows)]
    elif extension in {'.csv', '.tsv', '.txt'}:
        try:
            text = raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            text = raw.decode('cp1252')
        try:
            dialect = csv.Sniffer().sniff(text[:8192], delimiters=',;\t')
        except csv.Error:
            dialect = csv.excel_tab if extension == '.tsv' else csv.excel
        rows = list(csv.reader(io.StringIO(text), dialect))
    else:
        raise ValueError('Importa un archivo Excel (.xlsx o .xls) o CSV.')
    # Si existen encabezados, se reconocen las columnas aunque estén reordenadas.
    import unicodedata
    def title(value):
        plain = unicodedata.normalize('NFD', str(value or '').strip().lower())
        return re.sub(r'[^a-z0-9]+', ' ', ''.join(ch for ch in plain if unicodedata.category(ch) != 'Mn')).strip()
    date_col, value_col, first_row = 0, 1, 0
    parts = None
    for index, row in enumerate(rows[:25]):
        columns = [title(v) for v in row]
        dates = [i for i, label in enumerate(columns) if label in {'periodo', 'fecha', 'mes', 'ano', 'anio', 'mes ano', 'periodo fecha'} or label.startswith(('periodo ', 'fecha '))]
        values = [i for i, label in enumerate(columns) if label in {'valor', 'valor observado', 'observado', 'saldo', 'importe', 'dato', 'valor del periodo', 'total'} or label.startswith(('valor ', 'saldo '))]
        if str(payload.get('id'))=='26' and dates:
            dep=next((i for i,x in enumerate(columns) if x.startswith('depreciacion')),None)
            amo=next((i for i,x in enumerate(columns) if x.startswith('amortizacion')),None)
            if dep is not None and amo is not None:
                date_col,parts,first_row=dates[0],(dep,amo),index+1
                break
        if dates and values and dates[0] != values[0]:
            date_col, value_col, first_row = dates[0], values[0], index + 1
            break
    entries, started = [], False
    for index, row in enumerate(rows[first_row:], first_row + 1):
        cols=(date_col,*parts) if parts else (date_col,value_col)
        if len(row)<=max(cols) or any(row[i] in (None,'') for i in cols):
            continue
        try:
            period = _period(row[date_col])
            value = sum(_number(row[i]) for i in parts) if parts else _number(row[value_col])
        except (ValueError, TypeError):
            if not started:
                continue
            raise ValueError(f'Fila {index}: revisa el período y los importes.')
        entries.append({'id': str(payload.get('id', '')), 'period': period, 'value': value})
        started = True
    return {'entries': _validate_entries(entries), 'filename': Path(filename).name}


def _export(payload):
    import xlsxwriter
    changes = _validate_changes(payload.get('changes'))
    result = motor.calculate(changes)
    mid = str(payload.get('id', ''))
    model = next((m for m in result['models'] if m['id'] == mid), None)
    if model is None:
        raise ValueError('Selecciona un modelo para exportar.')
    frequency = str(payload.get('frequency', 'annual'))
    if frequency not in {'annual', 'monthly'}:
        raise ValueError('Frecuencia no válida.')
    records = model.get(frequency, [])
    if not records:
        raise ValueError('El modelo no dispone de resultados en esa frecuencia.')
    baseline = next(m for m in result['baseline'] if m['id'] == mid)
    compare = bool(payload.get('compare', False))
    if compare and payload.get('comparison') is not None:
        other = motor.calculate(_validate_changes(payload['comparison']))
        baseline = next(m for m in other['models'] if m['id'] == mid)
    period_key = (lambda r: str(r.get('date', ''))[:7]) if frequency == 'monthly' else (lambda r: str(r['year']))
    original = {period_key(row): row['value'] for row in baseline.get(frequency, [])}
    memory = io.BytesIO()
    with xlsxwriter.Workbook(memory, {'in_memory': True}) as book:
        sheet = book.add_worksheet('Resultados')
        title = book.add_format({'font_name': 'Calibri', 'font_size': 12, 'bold': True})
        head = book.add_format({'font_name': 'Calibri', 'font_size': 11, 'bold': True, 'bottom': 1,
                                'bottom_color': '#BFBFBF', 'text_wrap': True, 'valign': 'vcenter'})
        amount = book.add_format({'font_name': 'Calibri', 'font_size': 11, 'num_format': '#,##0.000000'})
        date_format = book.add_format({'font_name': 'Calibri', 'font_size': 11,
                                       'num_format': 'mmm-yyyy' if frequency == 'monthly' else '0'})
        sheet.write(0, 0, f'{model["name"]} ({model.get("unit", "")})', title)
        headers = ['Período', 'Observado', 'Cierre estimado', 'Pronóstico']
        if compare:
            headers += [str(payload.get('comparisonLabel') or 'Antes del cambio'), 'Diferencia']
        sheet.write_row(2, 0, headers, head)
        sheet.set_column(0, 0, 17)
        sheet.set_column(1, 5, 23)
        sheet.set_row(2, 30)
        sheet.hide_gridlines(2)
        sheet.freeze_panes(3, 1)
        for rowno, row in enumerate(records, 3):
            period = period_key(row)
            if frequency == 'monthly':
                sheet.write_datetime(rowno, 0, datetime.strptime(period, '%Y-%m'), date_format)
            else:
                sheet.write_number(rowno, 0, int(period), date_format)
            values = [row.get('observed'), row.get('assumed'), row.get('forecast')]
            if compare:
                values += [original.get(period), row['value'] - original[period] if period in original else None]
            for colno, value in enumerate(values, 1):
                if value is not None:
                    sheet.write_number(rowno, colno, float(value), amount)
        sheet.autofilter(2, 0, len(records) + 2, len(headers) - 1)
    return memory.getvalue(), f'IASPE_{mid}_{frequency}.xlsx'


class Server(ThreadingHTTPServer):
    allow_reuse_address = False
    daemon_threads = True


class Handler(SimpleHTTPRequestHandler):
    server_version = 'IASPELocal/3.0'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'same-origin')
        super().end_headers()

    def _local(self):
        port = self.server.server_address[1]
        return self.headers.get('Host', '') in {f'127.0.0.1:{port}', f'localhost:{port}'}

    def _json(self, status, data, *, compress=False):
        raw = json.dumps(motor.clean(data), ensure_ascii=False, allow_nan=False).encode('utf-8')
        accepts_gzip = any(part.strip().split(';')[0] == 'gzip' and
                           not re.search(r';\s*q=0(?:\.0*)?\s*$', part)
                           for part in self.headers.get('Accept-Encoding', '').lower().split(','))
        encoded = compress and accepts_gzip and len(raw) > 1024
        if encoded:
            raw = gzip.compress(raw, compresslevel=5, mtime=0)
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        if compress:
            self.send_header('Vary', 'Accept-Encoding')
        if encoded:
            self.send_header('Content-Encoding', 'gzip')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _static(self, head=False):
        if not self._local():
            return self._json(403, {'error': 'Host local no válido.'})
        pathname = urlsplit(self.path).path
        path = (ROOT / 'index.html') if pathname == '/' else Path(self.translate_path(pathname)).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file() or path.suffix.lower() not in STATIC:
            return self.send_error(404, 'Archivo no disponible')
        if head:
            return super().do_HEAD()
        return super().do_GET()

    def do_HEAD(self):
        return self._static(True)

    def do_GET(self):
        if not self._local():
            return self._json(403, {'error': 'Host local no válido.'})
        endpoint = urlsplit(self.path).path
        if endpoint == '/api/status':
            return self._json(200, {'app': 'IASPE', 'status': 'ok', 'version': 4, 'release': 'IASPE-20261121-monitor-participacion-v1', 'root': str(ROOT)})
        try:
            if endpoint == '/api/state':
                with motor.LOCK:
                    data = motor.calculate()
                    data['scenarios'] = _scenarios()
                return self._json(200, data)
            if endpoint == '/api/executive/transmision-monetaria':
                file = ROOT / 'data' / 'transmision_tpm_m11.json'
                return self._json(200, json.loads(file.read_text(encoding='utf-8')))
            if endpoint == '/api/executive/revolving-split':
                file = ROOT / 'data' / 'apertura_ingresos_creditos.json'
                return self._json(200, json.loads(file.read_text(encoding='utf-8')))
            if endpoint == '/api/executive/financial-base':
                # Composición de los rubros del M29 (sin exposición de archivos de trabajo).
                file = ROOT / 'data' / 'eeff_sbs_base_2025_2030.json'
                return self._json(200, json.loads(file.read_text(encoding='utf-8')))
            if endpoint == '/api/scenarios':
                return self._json(200, {'scenarios': _scenarios()})
            if endpoint == '/api/macro-external/status':
                return self._json(200, proyecciones_externas.snapshot())
            if endpoint == '/api/macro-external/file':
                docid=parse_qs(urlsplit(self.path).query).get('id',[''])[0]
                content,filename=proyecciones_externas.get_document(docid)
                mime=('application/pdf' if filename.endswith('.pdf') else
                      'image/png' if filename.endswith('.png') else
                      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                self.send_response(200)
                self.send_header('Content-Type',mime)
                self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
                self.send_header('Content-Length',str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            if endpoint == '/api/normativa/status':
                return self._json(200, normativa_sbs.snapshot())
            if endpoint == '/api/normativa/download':
                doc_id = parse_qs(urlsplit(self.path).query).get('id', [''])[0]
                content, filename = normativa_sbs.download_pdf(doc_id)
                self.send_response(200)
                self.send_header('Content-Type', 'application/pdf')
                self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
                self.send_header('Content-Length', str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            if endpoint == '/api/monitor/status':
                return self._json(200, monitor_fuentes.MANAGER.snapshot(refresh=True))
            if endpoint == '/api/monitor/actualizacion':
                import monitor_actualizacion
                update_status = actualizador_sbs.MANAGER.snapshot()
                with motor.LOCK, actualizador_sbs.DATA_LOCK:
                    return self._json(200, monitor_actualizacion.snapshot(update_status=update_status), compress=True)
            if endpoint == '/api/sbs/status':
                data = actualizador_sbs.MANAGER.snapshot()
                with motor.LOCK:
                    data['pending'] = motor.pending_sources()
                    data['modelRevision'] = (motor.read_state('ultimo_recalculo.json', {}) or {}).get('generatedAt')
                return self._json(200, data)
            if endpoint == '/api/models/pending':
                with motor.LOCK:
                    return self._json(200, motor.pending_sources())
            if endpoint == '/api/diagnostico':
                import validacion_integral
                return self._json(200, validacion_integral.ejecutar())
            if endpoint == '/api/iaspe/control':
                with motor.LOCK:
                    return self._json(200, control_iaspe.snapshot(motor.calculate()['models']))
            if endpoint == '/api/benchmark/cartera-bancos':
                with actualizador_sbs.DATA_LOCK:
                    return self._json(200, cartera_consumo_bancos.historical())
            if endpoint == '/api/benchmark/participacion':
                import participacion_mercado
                with actualizador_sbs.DATA_LOCK:
                    return self._json(200, participacion_mercado.catalog(), compress=True)
            if endpoint == '/api/benchmark':
                return self._json(200, benchmark.load_benchmark())
            if endpoint == '/api/benchmark/ratios':
                with actualizador_sbs.DATA_LOCK:
                    return self._json(200, ratios_sbs.catalog())
            if endpoint == '/api/benchmark/personal':
                with actualizador_sbs.DATA_LOCK:
                    return self._json(200, personal_sbs.catalog())
            if endpoint == '/api/benchmark/oficinas':
                import oficinas_sbs
                with actualizador_sbs.DATA_LOCK:
                    return self._json(200, oficinas_sbs.catalog(), compress=True)
            if endpoint == '/api/benchmark/eeff':
                with actualizador_sbs.DATA_LOCK:
                    return self._json(200, benchmark_eeff.catalog())
            if endpoint == '/api/benchmark/eeff/account':
                account = parse_qs(urlsplit(self.path).query).get('account', [''])[0]
                with actualizador_sbs.DATA_LOCK:
                    return self._json(200, benchmark_eeff.account_data(account))
            if endpoint.startswith('/api/'):
                return self._json(404, {'error': 'Operación no disponible.'})
            return self._static()
        except Exception as error:
            traceback.print_exc()
            return self._json(422, {'error': str(error)})

    def do_POST(self):
        if not self._local():
            return self._json(403, {'error': 'Host local no válido.'})
        port = self.server.server_address[1]
        origin = self.headers.get('Origin')
        if origin and origin not in {f'http://127.0.0.1:{port}', f'http://localhost:{port}'}:
            return self._json(403, {'error': 'Origen no permitido.'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length < 1 or length > MAX_BODY:
                return self._json(413, {'error': 'El cuerpo de la solicitud debe ser JSON y no superar 16 MB.'})
            if self.headers.get_content_type() != 'application/json':
                return self._json(415, {'error': 'Se requiere contenido JSON.'})
            payload = json.loads(self.rfile.read(length).decode('utf-8'))
            if not isinstance(payload, dict):
                raise ValueError('La solicitud debe ser un objeto JSON.')
            endpoint = urlsplit(self.path).path
            if endpoint == '/api/macro-external/update':
                return self._json(200, proyecciones_externas.update(scope=payload.get('scope', 'mef')))
            if endpoint == '/api/macro-external/preview':
                return self._json(200, proyecciones_externas.preview_document(payload.get('source'), payload.get('filename'), payload.get('content')))
            if endpoint == '/api/macro-external/confirm':
                return self._json(200, proyecciones_externas.confirm_document(payload.get('token')))
            if endpoint == '/api/macro-external/import':
                return self._json(409, {'error': 'La carga directa está deshabilitada. Previsualiza el documento y confirma los cambios.'})
            if endpoint == '/api/normativa/check':
                return self._json(200, normativa_sbs.check_publications())
            if endpoint == '/api/normativa/review':
                return self._json(200, normativa_sbs.mark_reviewed(payload.get('keys', [])))
            if endpoint == '/api/iaspe/inputs':
                with actualizador_sbs.operation('manual'), motor.LOCK:
                    return self._json(200, control_iaspe.save(payload.get('entries')))
            if endpoint in {'/api/base/preview', '/api/base/apply', '/api/base/reset'}:
                resetting = endpoint == '/api/base/reset'
                changes = {} if resetting else _validate_macro_base_changes(payload.get('changes'))
                if not resetting and not changes:
                    raise ValueError('Introduce primero nuevos pronósticos macroeconómicos.')
                with actualizador_sbs.operation('base'), motor.LOCK:
                    if endpoint == '/api/base/preview':
                        report = motor.prepare_macro_base(changes)
                        report.pop('proposed', None)
                        return self._json(200, {'report': report})
                    report = motor.apply_macro_base(changes, reset=resetting)
                    data = motor.calculate()
                    data['scenarios'] = _scenarios()
                    data['macroBasePublication'] = report
                    return self._json(200, data)
            if endpoint == '/api/models/recalculate':
                with actualizador_sbs.operation('recalculation'), motor.LOCK:
                    result = motor.recalculate_sources()
                    result['scenarios'] = _scenarios()
                return self._json(200, result)
            if endpoint == '/api/sbs/start':
                return self._json(202, actualizador_sbs.MANAGER.begin(payload.get('sources'), payload.get('accounts'), payload.get('components'), payload.get('ratioCategories'), payload.get('banks')))
            if endpoint == '/api/sbs/stop':
                return self._json(202, actualizador_sbs.MANAGER.stop())
            if endpoint == '/api/sbs/resume':
                return self._json(202, actualizador_sbs.MANAGER.resume())
            if endpoint == '/api/monitor/refresh':
                return self._json(200, monitor_fuentes.MANAGER.snapshot(refresh=True, force=True))
            if endpoint == '/api/monitor/review':
                return self._json(200, monitor_fuentes.MANAGER.acknowledge(payload.get('keys')))
            if endpoint == '/api/calculate':
                horizon = _horizon(payload.get('horizon', 2030))
                changes = _validate_changes(payload.get('changes'))
                if any(int(period[:4]) > horizon for values in changes.values() for period in values):
                    raise ValueError('Los supuestos superan el último año seleccionado.')
                stress_profile = payload.get('stress_profile')
                if stress_profile not in (None, 'sbs_base', 'sbs_stress', 'sbs_severe'):
                    raise ValueError('Perfil de estrés no válido.')
                if stress_profile is not None and horizon > 2028:
                    raise ValueError('Los inputs de provisiones para estrés terminan en 2028.')
                with motor.LOCK:
                    result = motor.calculate(changes, horizon=horizon, stress_profile=stress_profile)
                return self._json(200, result)
            if endpoint == '/api/scenarios':
                name = str(payload.get('name', '')).strip()
                if not name:
                    raise ValueError('Escribe un nombre para el escenario.')
                if len(name) > 120:
                    raise ValueError('El nombre del escenario no debe superar 120 caracteres.')
                changes = _validate_changes(payload.get('changes'))
                horizon = _horizon(payload.get('horizon', 2030))
                if any(int(period[:4])>horizon for values in changes.values() for period in values):
                    raise ValueError('Los supuestos no pueden superar el horizonte seleccionado.')
                sid = str(payload.get('id') or uuid.uuid4().hex)
                with motor.LOCK:
                    motor.calculate(changes)
                    scenarios = _scenarios()
                    old = next((s for s in scenarios if s.get('id') == sid), None)
                    now = datetime.now(timezone.utc).isoformat()
                    scenario = {'id': sid, 'name': name, 'changes': changes, 'horizon': horizon, 'createdAt': old.get('createdAt', now) if old else now, 'updatedAt': now}
                    scenarios = [s for s in scenarios if s.get('id') != sid] + [scenario]
                    motor.write_state('escenarios.json', scenarios)
                return self._json(200, {'scenario': scenario, 'scenarios': scenarios})
            if endpoint == '/api/scenarios/delete':
                sid = str(payload.get('id', ''))
                with motor.LOCK:
                    scenarios = _scenarios()
                    if not any(s.get('id') == sid for s in scenarios):
                        raise ValueError('El escenario ya no está disponible.')
                    scenarios = [s for s in scenarios if s.get('id') != sid]
                    motor.write_state('escenarios.json', scenarios)
                return self._json(200, {'scenarios': scenarios})
            if endpoint in {'/api/update/preview', '/api/update/commit'}:
                with actualizador_sbs.operation('manual'):
                    return self._json(200, _update(payload.get('entries'), {}, endpoint.endswith('/commit'), payload.get('expected')))
            if endpoint == '/api/import':
                return self._json(200, _import_entries(payload))
            if endpoint == '/api/export':
                with motor.LOCK:
                    raw, filename = _export(payload)
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                self.send_header('Content-Disposition', "attachment; filename*=UTF-8''" + quote(filename, safe=''))
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return
            return self._json(404, {'error': 'Operación no disponible.'})
        except actualizador_sbs.Ocupado as error:
            return self._json(409, {'error': str(error), 'operation': actualizador_sbs.operation_status()})
        except (ValueError, TypeError, KeyError, ImportError, zipfile.BadZipFile) as error:
            return self._json(422, {'error': str(error)})
        except Exception as error:
            traceback.print_exc()
            return self._json(500, {'error': str(error)})


def main():
    parser = argparse.ArgumentParser(description='Plataforma financiera local IASPE')
    parser.add_argument('--port', type=int, default=8942)
    args = parser.parse_args()
    server = Server(('127.0.0.1', args.port), Handler)
    print(f'IASPE disponible en http://127.0.0.1:{args.port}', flush=True)
    try:
        # Solo mientras la plataforma está abierta; no modifica cálculos IASPE.
        proyecciones_externas.start_auto_update()
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        proyecciones_externas.stop_auto_update()
        server.server_close()


if __name__ == '__main__':
    main()
