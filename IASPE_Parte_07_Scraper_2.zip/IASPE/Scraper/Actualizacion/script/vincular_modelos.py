"""Vinculación conservadora de observaciones SBS a modelos IASPE.

Solo se transmiten variables con una correspondencia económica y de unidad
verificada. El resto de las fuentes actualiza sus comparativos, no los MCO.
Los libros originales de Modelos financieros permanecen inalterados.
"""
from __future__ import annotations

import argparse
import csv
from datetime import date, datetime, timezone
import json
import math
from pathlib import Path
import sys

from openpyxl import load_workbook

IASPE = Path(__file__).resolve().parents[3]
SISTEMA = IASPE.parent / 'Dashboard' / 'Sistema'
SALIDA = IASPE / 'Scraper' / 'Actualizacion' / 'output'
OBSERVACIONES = SALIDA / 'observaciones_modelos.json'
INFORME = SALIDA / 'vinculacion_modelos.json'
TARJETAS = IASPE / 'Scraper' / 'Numero_tarjetas' / 'output' / 'SBS_Tarjetas_Consumo_y_Total_Banca_Falabella_2008_2026.xlsx'
CARTERA = IASPE / 'Scraper' / 'Cartera_consumo_mercado' / 'output' / 'Cartera_consumo_banca_multiple.xlsx'

# B-2363: total mercado y solo consumo son series DISTINTAS.
VARIABLES = {'01': (4, 'N. tarjetas total banca múltiple', 'tarjetas'),
             '02': (2, 'N. tarjetas de consumo banca múltiple', 'tarjetas'),
             '04': (3, 'N. tarjetas de Banco Falabella', 'tarjetas')}
SIN_VINCULO = {
    'personal_financieras': 'Serie de personal para comparativos; no es una variable dependiente ni regresora identificada en los MCO.',
    'personal_rurales': 'Personal de cajas rurales para comparativos; no alimenta modelos de Falabella.',
    'ratios': 'Indicadores prudenciales SBS; no equivalen automáticamente a las tasas de interés de Modelos 13–15.',
    'morosidad': 'Morosidad de tarjetas: no es la TEA activa de consumo del Modelo 14.',
}


def _leer(path: Path, default):
    if path.is_file():
        return json.loads(path.read_text(encoding='utf-8'))
    return default


def _guardar(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + '.tmp')
    pending.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    pending.replace(path)


def _tarjetas():
    book = load_workbook(TARJETAS, read_only=True, data_only=True)
    updates = {mid: {} for mid in VARIABLES}
    try:
        if 'Mensual' not in book:
            raise ValueError('B-2363: falta la hoja Mensual.')
        data = book['Mensual'].iter_rows(values_only=True)
        headers = next(data)
        expected = ('anio', 'mes', 'banca_multiple', 'falabella', 'banca_total')
        if tuple(str(x).strip().lower() for x in headers[:5]) != expected:
            raise ValueError('B-2363: encabezados distintos; revisar el mapeo antes de actualizar.')
        for row in data:
            if len(row) < 5 or not isinstance(row[0], int) or not isinstance(row[1], int):
                continue
            year, month = row[:2]
            if not 1 <= month <= 12:
                raise ValueError('B-2363: mes inválido.')
            # Conservar el histórico original; transmitir cada mes nuevo del
            # horizonte vigente, incluyendo 2027–2030.
            if not (2026 <= year <= 2030) or (year == 2026 and month <= 8):
                continue
            period = f'{year}-{month:02d}'
            for mid, (col, _, unit) in VARIABLES.items():
                val = row[col]
                if val is None:
                    continue
                if isinstance(val, bool) or not isinstance(val, (int, float)) or not math.isfinite(val) or val <= 0 or int(val) != val:
                    raise ValueError(f'B-2363: dato incompatible en {period}, modelo {mid}.')
                updates[mid][period] = int(val)
    finally:
        book.close()
    return updates


def _cartera():
    book = load_workbook(CARTERA, read_only=True, data_only=True)
    changes = {'05': {}, '06': {}}
    try:
        if 'Mensual' not in book:
            raise ValueError('B-2389: falta la hoja Mensual.')
        it = book['Mensual'].iter_rows(values_only=True)
        header = next(it)
        if len(header) < 7 or not all('Falabella' in str(header[i]) for i in (4, 5, 6)):
            raise ValueError('B-2389: columnas Falabella no identificadas.')
        if 'S/ millones' not in str(header[4]) or 'S/ millones' not in str(header[5]):
            raise ValueError('B-2389: unidad de saldos no reconocida.')
        anchor = {}
        for row in it:
            if not row or row[0] is None:
                continue
            value = row[0]
            period = value.strftime('%Y-%m') if isinstance(value, (date, datetime)) else str(value)[:7]
            if len(period) != 7 or period[4] != '-':
                raise ValueError('B-2389: período no reconocido.')
            if period == '2026-08':
                anchor = {'05': row[4], '06': row[5]}
            if period < '2026-09' or period > '2030-12':
                continue
            for mid, ix in [('05', 4), ('06', 5)]:
                val = row[ix]
                if val is None:continue
                if isinstance(val, bool) or not isinstance(val, (float,int)) or not math.isfinite(val) or val <= 0:
                    raise ValueError(f'B-2389: saldo inválido en {period} para {mid}.')
                changes[mid][period] = float(val)
        # Comparación de la última observación común; el benchmark puede diferir
        # en años antiguos por la separación entre tarjetas totales/consumo.
        if set(anchor) != {'05','06'}:
            raise ValueError('B-2389: falta el ancla observada de agosto de 2026.')
        for mid in ('05','06'):
            root = IASPE / 'Modelos financieros'
            candidates = [p / 'Input' / 'Base_modelo.xlsx'
                          for group in ('Estado de Resultados', 'Estado de Situacion Financiera', 'Variables Operativas')
                          for p in sorted((root / group).glob(f'{mid}_*')) if p.is_dir()]
            from_input = next((p for p in candidates if p.is_file()), None)
            if from_input is None:
                raise FileNotFoundError(f'No existe el input del modelo {mid}.')
            wb = load_workbook(from_input, read_only=True, data_only=True)
            try:
                existing = next((r[1] for r in list(wb['Mensual'].values)[1:]
                                 if str(r[0])[:7] == '2026-08'), None)
            finally:
                wb.close()
            if existing is None or not math.isclose(float(existing), float(anchor[mid]), abs_tol=0.02):
                raise ValueError(f'B-2389: el dato de agosto 2026 no concilia con el Modelo {mid}.')
    finally:
        book.close()
    return changes


def _personal_banca():
    """Ancla de dotación: diciembre real o cierre provisional por variación IA.

    El gasto de personal no es un sinónimo del número de trabajadores.
    Se respeta la última publicación SBS y se conservan años anteriores.
    """
    filename = IASPE / 'Scraper' / 'Numero_trabajadores' / 'output' / 'personal_banca_mensual.csv'
    with filename.open(newline='', encoding='utf-8-sig') as stream:
        reader=csv.DictReader(stream)
        required={'periodo','banco','personal_total'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('Personal SBS: faltan columnas esenciales en el CSV.')
        rows = {r['periodo']:int(r['personal_total']) for r in reader
                if r['banco'] == 'Banco Falabella Perú' and r['personal_total'].isdigit()}
    candidates=sorted((k,v) for k,v in rows.items() if '2026-01' <= k <= '2030-12')
    if not candidates:
        raise ValueError('Personal SBS: faltan observaciones de Falabella desde 2026.')
    period, current = candidates[-1]
    year=int(period[:4]); prior=str(year-1)
    prior_dec=rows.get(prior+'-12')
    comparable=rows.get(prior+period[4:])
    if not prior_dec or not comparable or not current:
        raise ValueError(f'Personal SBS: faltan diciembre {prior} o el mes comparable de {prior}. No se fabrica un cierre anual.')
    if period.endswith('-12'):
        closing=float(current)
        criterio='diciembre observado; coincide con el cierre anual'
        condition='observado'
    else:
        if not 0.4 < current/comparable < 1.6:
            raise ValueError('Personal SBS: variación interanual extraordinaria; revisar la serie.')
        closing=prior_dec * current / comparable
        criterio=f'cierre dic-{prior} × trabajadores {period} / trabajadores mismo mes de {prior}'
        condition='estimado'
    return {'trabajadores_falabella':{str(year):closing}}, {
        'mes_ultimo':period,'trabajadores':current,'trabajadores_mismo_mes_previo':comparable,
        'trabajadores_diciembre_previo':prior_dec,'cierre':closing,
        'estado_cierre':condition,'criterio':criterio}


def _vincular_financieras(source, account_ids=None, component_ids=None):
    sys.path.insert(0, str(SISTEMA))
    import motor
    original, _ = motor.load_base()
    if source == 'tasas_mercado':
        archivo = SALIDA / 'tasas_mercado.json'
        nuevos = _leer(archivo, {})
        if set(nuevos) != {'13', '14', '15'} or not all(nuevos.values()):
            raise ValueError('Faltan series financieras BCRP para los modelos 13–15.')
        compras = _leer(SALIDA / 'compras_bcrp.json', {'03': {}})
        if set(compras) != {'03'}:
            raise ValueError('Serie de compras BCRP no válida.')
        nuevos.update({k: v for k, v in compras.items() if v})
        if component_ids is not None:
            nuevos = {k: v for k, v in nuevos.items() if k in component_ids}
        faltantes = []
    else:
        from cuentas_sbs import construir
        grupos = {
            'ahorro': ('08', '08_mn', '08_me'),
            'plazo_cts': ('09', '09_plazo', '09_cts'),
            'obligaciones': ('10', '10_restringidos', '10_otras'),
            'disponible': ('17', '17_caja', '17_bancos', '17_canje', '17_otros'),
            'inversiones': ('21', '21_venta', '21_asociadas'),
            'interbancarios': ('22', '22_interbancarios'),
            'gastos_intereses': ('12', '12_obligaciones', '12_entidades', '12_adeudos', '12_otras'),
            'ingresos_intereses': ('16', '16_creditos', '16_inversiones', '16_disponible', '16_interbancarios'),
            'servicios': ('18', '18_diversos', '18_otros_ing', '18_gastos_div', '18_otros_gastos', '18_fsd'),
            'administracion': ('19', '19_personal', '19_directorio', '19_terceros', '19_impuestos'),
            'operaciones': ('20', '20_consorcios', '20_tc', '20_derivados', '20_inversiones', '20_otros'),
            'provisiones': ('25',), 'depreciacion': ('26',), 'margen': ('23',),
            'otros_resultados': ('24',), 'otras_provisiones': ('27',),
            'impuesto_renta': ('28',), 'resultado_neto': ('29',),
    'lineas_no_utilizadas': ('30',), 'cuentas_cobrar': ('31',), 'rendimientos_cobrar': ('32',),
        }
        if account_ids is None:
            filtro = None if source == 'estados_financieros' else set(grupos['ahorro'])
        else:
            filtro = set()
            for account in account_ids:
                if account not in grupos:
                    raise ValueError(f'Cuenta desconocida: {account}')
                if source == 'ahorro_moneda' and account != 'ahorro':
                    continue
                filtro.update(grupos[account])
            if source == 'estados_financieros':
                filtro.difference_update({'08_mn', '08_me'})
        if component_ids is not None:
            filtro = set(component_ids) if filtro is None else filtro.intersection(component_ids)
        nuevos, faltantes = construir(original, filtro)
        if source == 'estados_financieros':
            # El saldo total de ahorro (08) no debe sustituir por separado al
            # modelo que se consolida desde sus saldos MN y ME. La fuente EEFF
            # sigue en el panel SBS, pero el motor recibe el detalle únicamente
            # desde la fuente «ahorro_moneda» para evitar un total sin desglose.
            nuevos.pop('08', None)
    guardado = _leer(OBSERVACIONES, {})
    if not isinstance(guardado, dict):
        raise ValueError('Las observaciones automáticas tienen un formato incorrecto.')
    combinado = {k: dict(v) for k, v in guardado.items()}
    cambios = []
    if source == 'estados_financieros':
        anteriores = dict(combinado.get('sbs_contable', {}))
        for modelo, periodos in nuevos.items():
            valores = dict(anteriores.get(modelo, {}))
            for periodo, dato in periodos.items():
                if valores.get(periodo) != dato:
                    cambios.append((modelo, periodo))
                valores[periodo] = dato
            anteriores[modelo] = valores
        if anteriores:
            combinado['sbs_contable'] = anteriores
    else:
        for modelo, periodos in nuevos.items():
            valores = dict(combinado.get(modelo, {}))
            for periodo, valor in periodos.items():
                if valores.get(periodo) != valor:
                    cambios.append((modelo, periodo))
                valores[periodo] = valor
            combinado[modelo] = valores
    if cambios:
        correcciones = motor.read_state('observaciones.json', {})
        efectivos = {k: dict(v) for k, v in combinado.items()}
        for modelo, periodos in correcciones.items():
            efectivos.setdefault(modelo, {}).update(periodos)
        result = motor.calculate(observations=efectivos)
        base,_ = motor.load_base()
        expected={mid for mid in base if len(mid)==2 and mid.isdigit()}
        actual={m['id'] for m in result['models'] if len(m['id'])==2 and m['id'].isdigit()}
        if actual != expected:
            raise RuntimeError('El motor no conservó el catálogo de modelos principales vigente.')
        _guardar(OBSERVACIONES, combinado)
    return {'fuente': source, 'estado': 'modelos_vinculados' if nuevos else 'sin_nuevos_datos',
            'modelos': sorted(nuevos), 'observaciones_nuevas': len(cambios),
            'detalle': f'{len(cambios)} actualizaciones; {len(nuevos)} modelos o componentes.'
                       + (f' {len(faltantes)} series sin base interanual.' if faltantes else '')}


def vincular(source: str, account_ids=None, component_ids=None):
    if source in {'tasas_mercado', 'estados_financieros', 'ahorro_moneda'}:
        return _vincular_financieras(source, account_ids, component_ids)
    if source not in {'tarjetas', 'cartera', 'personal_banca'}:
        return {'fuente': source, 'estado': 'solo_comparativo', 'modelos': [],
                'observaciones_nuevas': 0, 'detalle': SIN_VINCULO[source]}
    audit = None
    if source == 'personal_banca':
        observed, audit = _personal_banca()
    else:
        observed = _tarjetas() if source == 'tarjetas' else _cartera()
    if component_ids is not None and source in {'tarjetas', 'cartera'}:
        observed = {k: v for k, v in observed.items() if k in component_ids}
    stored = _leer(OBSERVACIONES, {})
    if not isinstance(stored, dict):
        raise ValueError('La base automática de observaciones tiene un formato incorrecto.')
    merged = {k: dict(v) for k, v in stored.items()}
    changed = []
    for mid, months in observed.items():
        previous = merged.setdefault(mid, {})
        for period, value in months.items():
            if previous.get(period) != value:
                changed.append({'modelo': mid, 'periodo': period, 'valor': value})
            previous[period] = value
    if changed:
        # Validación COMPLETA con los modelos originales; si falla se impide el
        # commit (y el actualizador restaura también el output SBS previo).
        sys.path.insert(0, str(SISTEMA))
        import motor
        manual = motor.read_state('observaciones.json', {})
        effective = {k: dict(v) for k, v in merged.items()}
        for key, periods in manual.items():
            effective.setdefault(key, {}).update(periods)  # las correcciones manuales prevalecen
        result = motor.calculate(observations=effective)
        ids = {x['id'] for x in result['models']}
        targets = {'19_personal'} if source=='personal_banca' else set(observed)
        if not targets.issubset(ids):
            raise RuntimeError('Faltan modelos de destino; no se confirma el enlace.')
        if source == 'cartera' and not {'07', '16'}.issubset(ids):
            raise RuntimeError('No se encontró la transmisión de cartera hacia los Modelos 07 y 16.')
        _guardar(OBSERVACIONES, merged)
    return {'fuente': source, 'estado': 'modelos_vinculados',
            'modelos': ['19_personal'] if source=='personal_banca' else sorted(observed),
            'derivados': ['19','28','29'] if source=='personal_banca' else ['07','16_creditos','16','20_consorcios','20','23','28','29'] if source == 'cartera' else [],
            'no_transmitidos': [],
            'observaciones_nuevas': len(changed), 'cambios': changed,
            'trazabilidad': audit,
            'detalle': ('Personal SBS conectado a gasto de personal; recalculados gastos administrativos, impuesto y resultado neto por la identidad contable verificada.'
                        if source=='personal_banca' and changed else
                        ('Cartera SBS conectada a 05, 06 y 07; transmitida a créditos, consorcios, margen, impuesto y resultado neto mediante las fórmulas verificadas.'
                        if source == 'cartera' and changed else
                        'Tarjetas SBS conectadas a 01, 02 y 04 y dependencias calculables actualizadas.'
                        if changed else 'Sin cambios nuevos; se mantuvieron los resultados.' )),
            'limitacion': 'Horizonte de los modelos: hasta 2030. Para períodos posteriores se deben ampliar supuestos y modelos.'}


def ejecutar(source: str, account_ids=None, component_ids=None):
    if source not in {'tarjetas', 'cartera', 'personal_banca', 'tasas_mercado', 'estados_financieros', 'ahorro_moneda', *SIN_VINCULO}:
        raise ValueError('Fuente SBS no reconocida.')
    result = vincular(source, account_ids, component_ids)
    prev = _leer(INFORME, {'fuentes': {}})
    prev.setdefault('fuentes', {})[source] = result
    prev['fecha'] = datetime.now(timezone.utc).isoformat(timespec='seconds')
    _guardar(INFORME, prev)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('fuente', choices=sorted({'tarjetas', 'cartera', 'personal_banca', 'tasas_mercado', 'estados_financieros', 'ahorro_moneda', *SIN_VINCULO}))
    parser.add_argument('--cuentas', default=None)
    parser.add_argument('--componentes', default=None)
    args = parser.parse_args()
    cuentas = args.cuentas.split(',') if args.cuentas is not None and args.cuentas else ([] if args.cuentas == '' else None)
    components = args.componentes.split(',') if args.componentes else ([] if args.componentes == '' else None)
    print(json.dumps(ejecutar(args.fuente, cuentas, components), ensure_ascii=False))
