from __future__ import annotations
import csv, json, math, sys
from collections import defaultdict
from pathlib import Path
from artifact_tool import Blob, SpreadsheetFile, Workbook

ROOT=Path(__file__).resolve().parents[6]
MODULE=Path(__file__).resolve().parents[1]
INPUT=MODULE/'Input'/'Libro1.xlsx'
OUT=MODULE/'Output'/'Pronostico.xlsx'
IASPE=ROOT/'IASPE'
CRED=IASPE/'Modelos financieros'/'Estado de Resultados'/'16_Ingresos_por_intereses_Falabella'/'01_Creditos'/'Output'/'Pronostico.xlsx'
ANEXO=IASPE/'Control_Supuestos'/'Anexos_BF_2026_Base_Estres_Severo.xlsx'
DASH=ROOT/'Dashboard'/'Sistema'/'data'/'apertura_ingresos_creditos.json'
for directory in ('Input','Output','Script'): (MODULE/directory).mkdir(parents=True,exist_ok=True)

# Datos de capital: los tres stages por categoría y mes.
w=SpreadsheetFile.import_xlsx(Blob.load(str(INPUT)))
raw=w.worksheets.get_item('Hoja1').get_range('A1:A355').values
assert len(raw)==355
headers=next(csv.reader([raw[0][0]]))
assert headers[:4]==['FUENTE','STAGE','fecha_proceso','CAPITAL (MM S/.)']
stock=defaultdict(dict)
for item in raw[1:]:
 name,stage,month,capital,provision,coverage=next(csv.reader([item[0]]))
 key=(int(month),name);stage=int(stage)
 assert name in {'REVOLVING','CUOTAS'} and stage in {1,2,3} and stage not in stock[key]
 stock[key][stage]=float(capital)
months=sorted({m for m,_ in stock})
assert len(months)==59 and months[0]==202112 and months[-1]==202610
assert all(len(stock[m,name])==3 for m in months for name in ('REVOLVING','CUOTAS'))
assert months==[y*100+m for y in range(2021,2027) for m in range(1,13) if 202112<=y*100+m<=202610]
monthly={m:{name:sum(stock[m,name].values()) for name in ('REVOLVING','CUOTAS')} for m in months}

# Cierre 2026: misma variación interanual enero-octubre por categoría.
growth={}
for name in ('REVOLVING','CUOTAS'):
 growth[name]=sum(monthly[y*100+m][name] for m in range(1,11) for y in [2026])/sum(monthly[202500+m][name] for m in range(1,11))-1
for m in (11,12):
 monthly[202600+m]={name:monthly[202500+m][name]*(1+growth[name]) for name in growth}

shares={}
for year in range(2021,2027):
 used=[m for m in monthly if m//100==year]
 rev=sum(monthly[m]['REVOLVING'] for m in used)
 cua=sum(monthly[m]['CUOTAS'] for m in used)
 shares[year]=rev/(rev+cua)
assert abs(shares[2026]-0.30374732563902693)<1e-11
increment=((shares[2025]-shares[2024])+(shares[2026]-shares[2025]))/2
for year in range(2027,2031): shares[year]=shares[year-1]+increment
assert all(0<share<1 for share in shares.values())

# Pronósticos intactos de M16; referencia IASC proveniente del Anexo 1.
wM=SpreadsheetFile.import_xlsx(Blob.load(str(CRED)))
original={int(y):float(credit) for y,credit,*_ in wM.worksheets.get_item('Anual').get_range('A2:H20').values if isinstance(y,(int,float)) and credit is not None}
sys.path.insert(0,str(ROOT/'Dashboard'/'Sistema'))
import motor
active={m['id']:m for m in motor.calculate()['models']}
forecast={int(point['year']):float(point['value']) for point in active['16_creditos']['annual'] if point.get('value') is not None}
assert all(abs(forecast[y]-original[y])<1e-6 for y in range(2021,2026))
wI=SpreadsheetFile.import_xlsx(Blob.load(str(ANEXO)))
s=wI.worksheets.get_item('Anexo_1')
ref={}
for year,col in zip(range(2025,2029),'CEGI'):
 total=float(s.get_range(f'{col}55').values[0][0])/1e6
 rev=float(s.get_range(f'{col}61').values[0][0])/1e6
 no_rev=float(s.get_range(f'{col}62').values[0][0])/1e6
 ref[year]={'creditos':total,'revolving':rev,'no_revolving':no_rev,'otros':total-rev-no_rev}
 assert ref[year]['otros']>=-1e-7
# La distribución de intereses de 2025 es observada en IASC, no la del capital.
# El cambio futuro de la participación se aproxima con el cambio de peso del capital.
anchor=ref[2025]['revolving']/ref[2025]['creditos']
interest_shares={year:anchor+capital_share-shares[2025] for year,capital_share in shares.items()}
assert all(0<=p<=1 for p in interest_shares.values())

w=Workbook.create()
sM=w.worksheets.add('Capital_mensual'); sP=w.worksheets.add('Participaciones'); sA=w.worksheets.add('Apertura')
sM.get_range('A1:G1').values=[['Año','Periodo','Capital revolving (S/ MM)','Capital cuotas (S/ MM)','Capital total (S/ MM)','Participación revolving','Condición']]
row_map={}
for n,ym in enumerate(sorted(monthly),start=2):
 row_map[ym]=n
 src=monthly[ym];status='Observado' if ym<=202610 else 'Estimado'
 sM.get_range(f'A{n}:D{n}').values=[[ym//100,ym,src['REVOLVING'] if status=='Observado' else None,src['CUOTAS'] if status=='Observado' else None]]
 sM.get_range(f'E{n}').formulas=[[f'=SUM(C{n}:D{n})']]
 sM.get_range(f'F{n}').formulas=[[f'=IFERROR(C{n}/E{n},0)']]
 sM.get_range(f'G{n}').values=[[status]]
for mm in (11,12):
 r=row_map[202600+mm];previous=row_map[202500+mm]
 rJan=row_map[202601];rOct=row_map[202610];pJan=row_map[202501];pOct=row_map[202510]
 for col in 'CD':
  sM.get_range(f'{col}{r}').formulas=[[f'={col}{previous}*(SUM({col}{rJan}:{col}{rOct})/SUM({col}{pJan}:{col}{pOct}))']]

sP.get_range('A1:H1').values=[['Año','Meses','Capital promedio revolving (S/ MM)','Capital promedio cuotas (S/ MM)','Capital promedio total (S/ MM)','Participación revolving','Primera diferencia (pp)','Condición']]
for y in range(2021,2031):
 r=y-2021+2
 sP.get_range(f'A{r}').values=[[y]]
 if y<=2026:
  first=row_map[min(m for m in monthly if m//100==y)]
  last=row_map[max(m for m in monthly if m//100==y)]
  sP.get_range(f'B{r}').formulas=[[f'=COUNTIF(Capital_mensual!$A$2:$A$62,A{r})']]
  sP.get_range(f'C{r}').formulas=[[f'=AVERAGE(Capital_mensual!C{first}:C{last})']]
  sP.get_range(f'D{r}').formulas=[[f'=AVERAGE(Capital_mensual!D{first}:D{last})']]
  sP.get_range(f'E{r}').formulas=[[f'=SUM(C{r}:D{r})']]
  sP.get_range(f'F{r}').formulas=[[f'=IFERROR(C{r}/E{r},0)']]
  status='Parcial (dic)' if y==2021 else 'Estimado' if y==2026 else 'Observado'
 else:
  previous=r-1
  # Promedio de variaciones de 2024-25 y 2025-26, constante en pp.
  sP.get_range(f'F{r}').formulas=[[f'=F{previous}+AVERAGE($G$6:$G$7)/100']]
  status='Proyectado'
 if y>=2023:
  sP.get_range(f'G{r}').formulas=[[f'=(F{r}-F{r-1})*100']]
 sP.get_range(f'H{r}').values=[[status]]

sA.get_range('A1:N1').values=[['Año','Créditos IASPE M16 (S/ MM)','Participación estimada ingresos revolving','Revolving IASPE (S/ MM)','No revolving IASPE (S/ MM)','Control IASPE (S/ MM)','Créditos IASC (S/ MM)','Revolving IASC (S/ MM)','No revolving IASC (S/ MM)','Otros créditos IASC (S/ MM)','Diferencia revolving (S/ MM)','Diferencia no revolving (S/ MM)','Diferencia total (S/ MM)','Condición']]
for y in range(2021,2031):
 r=y-2021+2;rp=r
 sA.get_range(f'A{r}:B{r}').values=[[y,forecast[y]]]
 if y>=2022:
  sA.get_range(f'C{r}').formulas=[[f'=IFERROR($H$6/$G$6,0)+Participaciones!F{rp}-Participaciones!$F$6']]
  for col,formula in {'D':f'=B{r}*C{r}','E':f'=B{r}-D{r}','F':f'=B{r}-SUM(D{r}:E{r})'}.items():sA.get_range(f'{col}{r}').formulas=[[formula]]
 if y in ref:
  sA.get_range(f'G{r}:I{r}').values=[[ref[y]['creditos'],ref[y]['revolving'],ref[y]['no_revolving']]]
  sA.get_range(f'J{r}').formulas=[[f'=G{r}-SUM(H{r}:I{r})']]
  for col,f in {'K':f'=D{r}-H{r}','L':f'=E{r}-I{r}','M':f'=B{r}-G{r}'}.items():sA.get_range(f'{col}{r}').formulas=[[f]]
 cond='Parcial (dic)' if y==2021 else 'Ancla IASC observada' if y==2025 else 'Estimado' if y<=2026 else 'Proyectado'
 sA.get_range(f'N{r}').values=[[cond]]

# Formato estándar, sin hojas auxiliares ni elementos decorativos.
for sheet,widths,last,condcol,pctcols in [(sM,{'A':11,'B':12,'C':26,'D':25,'E':26,'F':24,'G':19},62,'G',['F']),
                                         (sP,{'A':11,'B':12,'C':32,'D':29,'E':28,'F':26,'G':27,'H':19},11,'H',['F']),
                                         (sA,{'A':11,'B':28,'C':25,'D':27,'E':30,'F':25,'G':27,'H':27,'I':30,'J':27,'K':30,'L':31,'M':26,'N':19},11,'N',['C'])]:
 maxcol=list(widths)[-1]
 scope=sheet.get_range(f'A1:{maxcol}{last}')
 scope.format.font.name='Calibri'
 scope.format.font.size=10
 scope.format.horizontal_alignment='justify'
 scope.format.vertical_alignment='center'
 scope.format.row_height=19
 sheet.get_range(f'A1:{maxcol}1').format={'font':{'name':'Calibri','size':10,'bold':True,'color':'#202b36'},'fill':'#E9ECEF','horizontal_alignment':'center','vertical_alignment':'center','row_height':30,'wrap_text':True}
 sheet.get_range(f'{condcol}2:{condcol}{last}').format.horizontal_alignment='left'
 for col,width in widths.items():sheet.get_range(f'{col}:{col}').format.column_width=width
 for col in pctcols:sheet.get_range(f'{col}2:{col}{last}').set_number_format('0.00%')
 for col in widths:
  if col not in ['A','B',condcol] and col not in pctcols:
   sheet.get_range(f'{col}2:{col}{last}').set_number_format('#,##0.00;[Red](#,##0.00);-')
 sheet.freeze_panes.freeze_rows(1)
sP.get_range('G2:G11').set_number_format('0.0000" pp";[Red](0.0000" pp");-')
sM.get_range('A2:B62').set_number_format('0')
sP.get_range('A2:B11').set_number_format('0')
sA.get_range('A2:A11').set_number_format('0')

OUT.parent.mkdir(parents=True,exist_ok=True)
SpreadsheetFile.export_xlsx(w).save(str(OUT))
DASH.write_text(json.dumps({'fuente_cartera':'Libro1.xlsx (input estático; 2021 diciembre, 2022-2025 completo, 2026 enero-octubre)','fuente_iasc':'IASC Banco Falabella 2026-2028, Anexo_1, filas 55, 61 y 62',
 'metodologia':'2025: participación observada en IASC; 2022-2024 y 2026-2030: esa participación más el cambio acumulado de participación del capital de Libro1.xlsx (proyección de primeras diferencias desde 2027). Apertura estimada, no rendimiento observado por producto',
 'shares':{str(y):interest_shares[y] for y in range(2021,2031) if y>=2022},'capital_shares':{str(y):shares[y] for y in range(2021,2031) if y>=2022},'iasc':{str(y):v for y,v in ref.items()},
 'iasc_2025':{'activos':float(s.get_range('C8').values[0][0])/1e6,'consumo_total':(float(s.get_range('C18').values[0][0])+float(s.get_range('C19').values[0][0]))/1e6,'inversiones':float(s.get_range('C11').values[0][0])/1e6,'obligaciones':float(s.get_range('C49').values[0][0])/1e6,'pasivos':float(s.get_range('C48').values[0][0])/1e6,'patrimonio':float(s.get_range('C51').values[0][0])/1e6,'utilidad':float(s.get_range('C77').values[0][0])/1e6},
 'validation':{'registros_fuente':len(raw)-1,'meses_obs':len(months),'ult_mes_obs':months[-1], 'crecimiento_2026_revolving':growth['REVOLVING'],'crecimiento_2026_cuotas':growth['CUOTAS'], 'paso_anual_pp':100*increment,'base_creditos_iaspe_activo':{str(y):forecast[y] for y in range(2022,2031)},'diferencia_base_activa_frente_output_original':{str(y):forecast[y]-original[y] for y in range(2026,2031)}}},indent=2,ensure_ascii=False),encoding='utf-8')
print('OUT',OUT)
print('SHARES',[(y,round(100*interest_shares[y],5)) for y in range(2022,2031)])
print('IASC',ref)
print('SOURCE',len(raw)-1,'months',len(months),'growth',growth)
for year in range(2022,2031):
 a=forecast[year]*interest_shares[year]
 assert abs((a+forecast[year]-a)-forecast[year])<1e-8
 print(year,round(forecast[year],4),round(a,4),round(forecast[year]-a,4),('IASC:'+str(round(ref[year]['revolving'],2)) if year in ref else ''))
