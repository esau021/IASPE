"""Consulta de oficinas SBS observadas; no ejecuta descargas ni modelos."""
from __future__ import annotations

from copy import deepcopy
from datetime import date
from functools import lru_cache
import hashlib
import json
from pathlib import Path

from instituciones_sbs import BANKS, category_at, entity_metadata

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / 'IASPE' / 'Scraper' / 'Oficinas' / 'output'
DATA = OUTPUT / 'oficinas_historico.json'
GEOMETRY = OUTPUT / 'departamentos.geojson'
CONSULTATION = OUTPUT / 'consulta_oficinas.json'
DEPARTMENT_CODES = {f'{number:02}' for number in range(1, 26)}


def value_revision(data):
    """Huellas de cifras y definiciones; excluye la fecha de consulta y archivos."""
    fields = ('counts', 'total', 'coverage', 'outsidePeru', 'sourceTotal', 'category', 'sbsCode')
    canonical = {identifier: {month: {field: row.get(field) for field in fields}
                              for month, row in months.items()}
                 for identifier, months in data.get('series', {}).items()}
    body = json.dumps(canonical, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(body.encode('utf-8')).hexdigest()


def validate_dataset(data):
    """Valida cobertura territorial, identidad institucional y sumas exactas."""
    departments = data.get('departments', [])
    codes = [row.get('code') for row in departments]
    if len(codes) != 25 or set(codes) != DEPARTMENT_CODES:
        raise ValueError('Oficinas: se requieren los 24 departamentos y Callao, sin duplicados')
    if data.get('unit') != 'oficinas':
        raise ValueError('Oficinas: unidad no reconocida')
    if not data.get('valueRevision') or data['valueRevision'] != value_revision(data):
        raise ValueError('Oficinas: huella de valores ausente o incoherente')
    series = data.get('series', {})
    if not isinstance(series, dict) or set(series) - set(BANKS):
        raise ValueError('Oficinas: instituciones no reconocidas por el catálogo IASPE')
    observations = 0
    for identifier, months in series.items():
        if not isinstance(months, dict):
            raise ValueError('Oficinas: historia mensual inválida')
        for month, row in months.items():
            if len(month) != 7 or month[4] != '-' or not month[:4].isdigit() or not 1 <= int(month[5:]) <= 12:
                raise ValueError('Oficinas: periodo mensual inválido')
            if month > date.today().strftime('%Y-%m'):
                raise ValueError('Oficinas: no se admiten periodos futuros')
            if row.get('category') != category_at(identifier, month):
                raise ValueError(f'Oficinas: licencia incompatible para {identifier}/{month}')
            counts = row.get('counts', {})
            if set(counts) != DEPARTMENT_CODES:
                raise ValueError(f'Oficinas: distribución territorial incompleta para {identifier}/{month}')
            if any(value is not None and (type(value) is not int or value < 0) for value in counts.values()):
                raise ValueError('Oficinas: el número de oficinas debe ser entero no negativo o ausente')
            total = row.get('total')
            if total is not None and (type(total) is not int or total < 0):
                raise ValueError('Oficinas: total territorial inválido')
            complete = all(value is not None for value in counts.values())
            if complete and (total is None or sum(counts.values()) != total):
                raise ValueError(f'Oficinas: suma departamental distinta del total para {identifier}/{month}')
            if total is not None and sum(value for value in counts.values() if value is not None)>total:
                raise ValueError('Oficinas: la suma de departamentos conocidos supera el total publicado')
            if not complete and row.get('coverage') is not None:
                raise ValueError('Oficinas: no calcular cobertura completa con datos ausentes')
            expected_coverage = sum(value > 0 for value in counts.values()) if complete else None
            if row.get('coverage') != expected_coverage:
                raise ValueError('Oficinas: cobertura no concilia con sus departamentos')
            outside = row.get('outsidePeru')
            source_total = row.get('sourceTotal')
            if source_total is not None and (type(source_total) is not int or source_total < 0):
                raise ValueError('Oficinas: total de la fuente inválido')
            if all(value is None for value in counts.values()) and total is None:
                raise ValueError('Oficinas: registro vacío sin total territorial publicado')
            if outside is not None and (type(outside) is not int or outside < 0):
                raise ValueError('Oficinas: oficinas en el exterior inválidas')
            if source_total is not None and total is not None and outside is not None and source_total != total + outside:
                raise ValueError('Oficinas: total fuente no concilia con Perú y exterior')
            if not isinstance(row.get('source'), dict) or not row['source'].get('sha256'):
                raise ValueError('Oficinas: falta trazabilidad del original SBS')
            observations += len(counts)
    if not observations:
        raise ValueError('Oficinas: no hay observaciones territoriales')
    return {'entities': len(series), 'territorialObservations': observations}


def validation(project):
    """Validación de publicación y valores históricos, sin usar cachés globales."""
    project = Path(project)
    iaspe = project if (project / 'Scraper').is_dir() else project / 'IASPE'
    output = iaspe / 'Scraper' / 'Oficinas' / 'output'
    data = json.loads((output / 'oficinas_historico.json').read_text(encoding='utf-8'))
    validate_dataset(data)
    geometry = json.loads((output / 'departamentos.geojson').read_text(encoding='utf-8'))
    features = geometry.get('features', [])
    if len(features) != 25 or {f.get('properties', {}).get('code') for f in features} != DEPARTMENT_CODES:
        raise ValueError('Oficinas: cartografía incompleta o con códigos duplicados')
    values = {}
    months = set()
    for identifier, history in data['series'].items():
        for month, row in history.items():
            months.add(month)
            for code, count in row['counts'].items():
                if count is not None:
                    values[(identifier + '|' + code, month)] = count
            for field in ('total', 'outsidePeru', 'sourceTotal'):
                if row.get(field) is not None:
                    values[(identifier + '|' + field, month)] = row[field]
    return {'latestPeriod': max(months, default=None), 'records': len(values),
            'entities': len(data['series']), '_values': values, '_history': set(values),
            'valueRevision': data.get('valueRevision'), 'checkedAt': data.get('checkedAt')}


@lru_cache(maxsize=4)
def _read(path, mtime, size):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    validate_dataset(data)
    return data


def catalog():
    if not DATA.is_file():
        consultation = json.loads(CONSULTATION.read_text(encoding='utf-8')) if CONSULTATION.is_file() else {}
        geometry = json.loads(GEOMETRY.read_text(encoding='utf-8')) if GEOMETRY.is_file() else None
        features = geometry.get('features', []) if geometry else []
        if geometry and (len(features) != 25 or {f.get('properties', {}).get('code') for f in features} != DEPARTMENT_CODES):
            raise ValueError('Oficinas: cartografía departamental no válida')
        return {'ready': False, 'message': consultation.get('message') or 'Todavía no se ha descargado una base válida de oficinas SBS.',
                'institutions': [entity_metadata(identifier) for identifier in BANKS], 'series': {}, 'periods': [],
                'departments': [{'code':f['properties']['code'],'name':f['properties']['name']} for f in features],
                'geometry': geometry, 'geometryReady': geometry is not None,
                'latestPeriod': None, 'checkedAt': consultation.get('checkedAt'), 'lastCheck': consultation,
                'valueRevision': None, 'revision': None, 'unit': 'oficinas'}
    stat = DATA.stat()
    result = deepcopy(_read(str(DATA), stat.st_mtime_ns, stat.st_size))
    result['ready'] = True
    result['institutions'] = []
    periods = set()
    for identifier in BANKS:
        months = sorted(result['series'].get(identifier, {}))
        periods.update(months)
        result['institutions'].append({**entity_metadata(identifier, months[-1] if months else None),
                                       'periods': months, 'first': months[0] if months else None,
                                       'last': months[-1] if months else None})
    result['periods'] = sorted(periods)
    result['latestPeriod'] = max(periods, default=None)
    geometry = None
    geometry_hash = ''
    if GEOMETRY.is_file():
        body = GEOMETRY.read_bytes()
        geometry = json.loads(body)
        features = geometry.get('features', [])
        if len(features) != 25 or {f.get('properties', {}).get('code') for f in features} != DEPARTMENT_CODES:
            raise ValueError('Oficinas: la cartografía no contiene los 25 territorios esperados')
        geometry_hash = hashlib.sha256(body).hexdigest()
    result['geometry'] = geometry
    result['geometryReady'] = geometry is not None
    result['revision'] = str(result.get('valueRevision', '')) + ':' + geometry_hash
    if CONSULTATION.is_file():
        consultation = json.loads(CONSULTATION.read_text(encoding='utf-8'))
        result['checkedAt'] = consultation.get('checkedAt', result.get('checkedAt'))
        result['lastCheck'] = consultation
    return result
