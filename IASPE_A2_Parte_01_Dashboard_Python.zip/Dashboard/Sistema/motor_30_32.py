"""Modelos 30-32: series aprobadas y propagación de cambios verificables.

El Modelo 30 reproduce el promedio móvil de líneas por tarjeta de tres años.
Los modelos 31 y 32 leen los Excel del usuario sin modificarlos.
"""
from __future__ import annotations
from pathlib import Path
from copy import deepcopy
import math
from openpyxl import load_workbook

MODEL_NAMES = {
 '30': 'Líneas de crédito no utilizadas y créditos concedidos no desembolsados – Falabella',
 '31': 'Cuentas por cobrar netas de Falabella',
 '32': 'Rendimientos por cobrar de Falabella',
}


def _values(path, tab='Anual'):
    w = load_workbook(path, read_only=True, data_only=True)
    try:
        return [list(row) for row in w[tab].values]
    finally:
        w.close()


def _records(path):
    result = []
    for row in _values(path)[1:]:
        if len(row) < 3 or not isinstance(row[0], (int,float)) or not isinstance(row[1], (int,float)):
            continue
        year = int(row[0]); source = str(row[3] if len(row) > 3 and row[3] is not None else row[2] or '')
        if year < 1995 or year > 2030:continue
        s = source.lower()
        status = 'observed' if 'observ' in s else 'assumed' if 'supuesto' in s or 'cierre' in s else 'forecast'
        result.append({'year':year,'value':float(row[1]),'status':status,'conditionSource':source})
    return result


def _coefs(path):
    if not path.is_file():return []
    rows=_values(path,'Coeficientes')
    return [{'name':str(r[0]),'value':float(r[1]),'se':r[2], 'pValue':r[4]}
            for r in rows[1:] if len(r)>=5 and isinstance(r[1],(int,float)) and r[0]]


def _series(root, mid):
    category = 'Variables Operativas' if mid=='30' else 'Estado de Situacion Financiera'
    group = {'30':'30_Lineas_no_utilizadas_Falabella',
             '31':'31_Cuentas_por_cobrar_netas_Falabella',
             '32':'32_Rendimientos_por_cobrar_Falabella'}[mid]
    return Path(root)/category/group


def build_registry(root):
    result=[]
    for mid in MODEL_NAMES:
        folder = _series(root, mid)
        forecast = folder/'Output'/'Pronostico.xlsx'
        if not forecast.exists():continue
        coeffile = folder/'Output'/'Resultados_MCO.xlsx'
        coeffs = _coefs(coeffile)
        diag = {str(r[0]):r[1] for r in _values(coeffile,'Diagnostico')[1:]
                if len(r)>=2 and r[0] is not None} if mid in {'31','32'} and coeffile.is_file() else {}
        stats = ({'nobs':diag.get('Observaciones'),'r2':diag.get('R²'),
                  'adjustedR2':diag.get('R² ajustado'),
                  'period':'2017–2026 (cierre supuesto)',
                  'inference':'HAC Newey–West (1 rezago)'} if mid in {'31','32'} else {})
        dependencies = {'30':['04'], '31':['pbi'], '32':['16_creditos']}[mid]
        sources=[folder/'Consolidado.xlsx',forecast,coeffile, folder/'Input'/'Base_modelo.xlsx']
        result.append({'id':mid,'name':MODEL_NAMES[mid],'unit':'S/ millones',
                       'frequency':'annual','kind':'stock' if mid!='30' else 'off_balance',
                       'annual':_records(forecast),'monthly':[],
                       'sourceFiles':[str(p) for p in sources if p.exists()],
                       'dependencies':dependencies,
                       'inputs':[{'id':dep,'lag':0,'name':'PBI real' if dep=='pbi' else 'Número de tarjetas (Modelo 04)' if dep=='04' else 'Ingresos por créditos (Modelo 16)'} for dep in dependencies],
                       'method':('Promedio móvil de tres años de líneas no utilizadas por tarjeta (reproducido y validado)' if mid=='30'
                                 else 'MCO anual (coeficientes del Excel aprobado)'),
                       'coefficients':coeffs,'statistics':stats,
                       'equationTex':('' if mid=='30' else
                                      r'\widehat{g}_{CxC,t}=\alpha+\beta\,PBI_t' if mid=='31'
                                      else r'\widehat{\Delta Rend}_{t}=\alpha+\beta\Delta Ingresos_{creditos,t}'),
                       'scenarioSupport':True,'canUpdate':True,
                       'status':'ok', 'reestimated':False,
                       'limitations':(['El método anual y el cierre 2026 se reconstruyeron y contrastaron con el pronóstico aprobado; no se dispone de la hoja histórica original de estimación mensual.'] if mid=='30' else []),
                       })
    return result


def recalculate(context, changes=None, observations=None):
    changes=changes or {}
    original=context.get('original_models') or {}
    current=context.get('models') or {}
    root=context.get('source_root',context.get('sourceRoot'))
    if not original or not current:return []
    changed=[]
    def val(collection,key,year):
        m=collection.get(key)
        if not m:return None
        return next((float(r['value']) for r in m['annual'] if r['year']==year),None)
    def put(key,year,number):
        row=next(r for r in current[key]['annual'] if r['year']==year)
        if row['status']!='forecast':return
        row.update(value=number,forecast=number,observed=None,assumed=None)
        current[key]['reestimated']=True
        current[key]['status']='ok'
        current[key].pop('issues',None)
        if key not in changed:changed.append(key)
    # Modelo 30: la regla seleccionada es media móvil de 3 años de
    # líneas por tarjeta. Reproduce el Excel original (diferencias de redondeo).
    if '30' in current and '04' in current and '30' in original:
        ratio_changed=any(abs((val(current,'04',y) or 0)-(val(original,'04',y) or 0))>1e-7
                          for y in range(2026,2031))
        anchor_changed=abs((val(current,'30',2026) or 0)-(val(original,'30',2026) or 0))>1e-7
        if ratio_changed or anchor_changed:
            line={y:val(current,'30',y) for y in range(2024,2031)}
            cards={y:val(current,'04',y) for y in range(2024,2031)}
            for year in range(2027,2031):
                if cards[year] is None or cards[year]<=0:
                    raise ValueError(f'Modelo 30: faltan tarjetas positivas para {year}.')
                historical=[line[j]/cards[j] for j in range(year-3,year)
                            if line[j] is not None and cards[j] is not None and cards[j]>0]
                if len(historical)!=3:
                    raise ValueError(f'Modelo 30: no hay tres años para {year}.')
                line[year]=round(cards[year]*sum(historical)/3,2)
                put('30',year,line[year])
    # CxC: al cambiar el cierre 2026, conservar la especificación MCO log.
    anchor31=('31' in original and '31' in current and
              abs((val(current,'31',2026) or 0)-(val(original,'31',2026) or 0))>1e-7)
    if '31' in original and '31' in current and (changes.get('pbi') or anchor31):
        f = _series(root,'31')/'Output'/'Pronostico.xlsx'
        original_pbi={int(r[0]):float(r[4]) for r in _values(f)[1:] if isinstance(r[0],(float,int)) and len(r)>4 and isinstance(r[4],(float,int))}
        coeffs=current['31']['coefficients']
        if len(coeffs)>1:
            a,b=coeffs[0]['value'],coeffs[1]['value']
            path={y:val(current,'31',y) for y in range(2016,2031)}
            if anchor31:
                import numpy as np
                import statsmodels.api as sm
                years=range(2017,2027)
                if all(path.get(y,0)>0 and path.get(y-1,0)>0 and y in original_pbi for y in years):
                    yy=[100*math.log(path[y]/path[y-1]) for y in years]
                    xx=[[1.,original_pbi[y]] for y in years]
                    fit=sm.OLS(np.asarray(yy,float),np.asarray(xx,float)).fit()
                    robust=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
                    a,b=(float(x) for x in robust.params)
                    current['31']['statistics']={'nobs':int(fit.nobs),'r2':float(fit.rsquared),
                        'adjustedR2':float(fit.rsquared_adj),'period':'2017–2026 (cierre supuesto)',
                        'inference':'HAC Newey–West (1 rezago)'}
                    for i,v in enumerate((a,b)):
                        current['31']['coefficients'][i].update(value=v,
                          se=float(robust.bse[i]),pValue=float(robust.pvalues[i]))
            for y in range(2027,2031):
                if str(y) in (changes.get('pbi') or {}):
                    pbi=float(changes['pbi'][str(y)])
                else:
                    pbi=original_pbi.get(y)
                if pbi is None:continue
                path[y]=path[y-1]*math.exp((a+b*pbi)/100)
                if abs(path[y]-val(original,'31',y))>1e-9:put('31',y,path[y])
    if '32' in original and '32' in current and '16_creditos' in current:
        if (any(abs((val(current,'16_creditos',y) or 0)-(val(original,'16_creditos',y) or 0))>1e-7 for y in range(2026,2031))
            or abs((val(current,'32',2026) or 0)-(val(original,'32',2026) or 0))>1e-7):
            coeffs=current['32']['coefficients']
            if len(coeffs)>1:
                a,b=coeffs[0]['value'],coeffs[1]['value']
                # Si el cierre de diciembre de 2026 se actualiza, también
                # pertenece a la nueva muestra MCO, sin cambiar la ecuación.
                closed32=abs((val(current,'32',2026) or 0)-(val(original,'32',2026) or 0))>1e-7
                closed16=abs((val(current,'16_creditos',2026) or 0)-(val(original,'16_creditos',2026) or 0))>1e-7
                observed_2026 = any('2026' in (observations or {}).get(key,{})
                                    for key in ('32','16_creditos'))
                if (closed32 or closed16) and observed_2026:
                    import numpy as np
                    import statsmodels.api as sm
                    sample=list(range(2017,2027))
                    obs32={y:val(current,'32',y) for y in range(2016,2027)}
                    obs16={y:val(current,'16_creditos',y) for y in range(2016,2027)}
                    if any(obs32[y] is None or obs16[y] is None for y in range(2016,2027)):
                        raise ValueError('Modelo 32: faltan observaciones para reestimar MCO con cierre 2026.')
                    yy=np.array([obs32[y]-obs32[y-1] for y in sample],float)
                    xx=np.array([[1.,obs16[y]-obs16[y-1]] for y in sample],float)
                    fit=sm.OLS(yy,xx).fit()
                    hac=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
                    a,b=(float(v) for v in fit.params)
                    names=[coeffs[i]['name'] for i in range(2)]
                    current['32']['coefficients']=[{'name':names[i],'value':float(fit.params[i]),
                       'se':float(hac.bse[i]),'pValue':float(hac.pvalues[i])} for i in range(2)]
                    current['32']['statistics']={'nobs':int(fit.nobs),'r2':float(fit.rsquared),
                       'adjustedR2':float(fit.rsquared_adj),'period':'2017–2026',
                       'covariance':'HAC / Newey-West, 1 rezago'}
                last=val(current,'32',2026)
                for year in range(2027,2031):
                    now=val(current,'16_creditos',year);prev=val(current,'16_creditos',year-1)
                    if now is None or prev is None:break
                    last=last+a+b*(now-prev)
                    put('32',year,last)
    return {'models':[current[k] for k in changed]}
