/* Centro único de publicaciones. Revisar una fuente no actualiza la serie ni recalcula IASPE. */
(function(){
  'use strict';
  let status=null,pending={observations:0},open=false,busy=false,refreshing=false,started=false,timer=null,showReviewed=false;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const periodText=s=>String(s||'').replace(/^(\d{4})-(\d{2})$/,'$2/$1')||'—';
  function stamp(value){
    if(!value)return 'Sin consulta';
    try{return new Intl.DateTimeFormat('es-PE',{dateStyle:'short'}).format(new Date(value));}
    catch(_){return value;}
  }
  const fresh=s=>s?.status==='nuevo'?(s.reports||[]).filter(r=>r.status==='nuevo'&&r.alertKey):[];
  const unread=s=>fresh(s).filter(r=>!r.reviewed);
  const sources=()=>status?.sources||[];
  const pendingSources=()=>sources().filter(s=>unread(s).length);
  const reviewedSources=()=>sources().filter(s=>fresh(s).length&&!unread(s).length);
  const unreadCount=()=>pendingSources().length;
  const pendingCalculations=()=>Number(pending?.observations||0)>0;
  function bell(){
    const root=document.getElementById('source-alert-trigger');if(!root)return;
    const badge=document.getElementById('source-alert-badge'),activity=document.getElementById('source-alert-activity');
    const n=unreadCount();
    if(badge){badge.hidden=n===0;badge.textContent=n>9?'9+':String(n);}
    if(activity){activity.hidden=n>0||!(pendingCalculations()||status?.stale);}
    root.classList.toggle('has-new',n>0);root.setAttribute('aria-expanded',String(open));
    root.setAttribute('aria-label',n?`${n} publicaciones por revisar`:'Notificaciones sin publicaciones pendientes');
    root.title=n?`${n} avisos por revisar`:pendingCalculations()?'Datos descargados pendientes de recálculo':'Notificaciones al día';
  }
  function sourceRow(source,reviewed=false){
    const reports=(reviewed?fresh(source):unread(source));
    const dates=[...new Set(reports.map(r=>r.remotePeriod).filter(Boolean))].map(periodText);
    const title=reports.length===1?dates[0]:`${reports.length} reportes · ${dates.join(', ')}`;
    return `<button type="button" class="source-alert-item source-alert-action ${reviewed?'is-reviewed':''}" data-source-review="${esc(source.id)}" ${reviewed?'disabled':''} title="${reviewed?'Publicación revisada':'Marcar como revisada'}"><span class="source-alert-dot ${reviewed?'al_dia':'nuevo'}" aria-hidden="true"></span><span class="source-alert-item-text"><strong>${esc(source.name)}</strong><small>${esc(title)}</small></span><span class="source-alert-item-tag ${reviewed?'':'nuevo'}">${reviewed?'Revisada':'Revisar'}</span></button>`;
  }
  function panel(){
    const node=document.getElementById('source-alert-panel');if(!node)return;
    node.hidden=!open;if(!open)return;
    const freshItems=pendingSources(),seenItems=reviewedSources(),n=freshItems.length;
    const head=n?`${n} ${n===1?'aviso pendiente':'avisos pendientes'}`:'Sin novedades pendientes';
    node.innerHTML=`<div class="source-alert-top"><div><span class="source-alert-eyebrow">DATOS SBS Y BCRP</span><h2>Notificaciones</h2></div><button type="button" class="source-alert-close" id="source-alert-close" aria-label="Cerrar">×</button></div>
      <div class="source-alert-overview"><span class="source-alert-overview-icon ${n?'new':'ok'}">${n?'!':'✓'}</span><div><strong>${esc(head)}</strong><small>Última consulta: ${esc(stamp(status?.checkedAt))}</small></div></div>
      ${pendingCalculations()?`<div class="source-alert-pending"><div><strong>${pending.observations} datos descargados pendientes</strong><span>Necesitan recálculo antes de reflejarse en las proyecciones.</span></div></div>`:''}
      <div class="source-alert-list-head"><span>POR REVISAR</span><small>${n} ${n===1?'fuente':'fuentes'}</small></div>
      <div class="source-alert-list" role="group" aria-label="Publicaciones pendientes">${freshItems.length?freshItems.map(s=>sourceRow(s)).join(''):'<div class="source-alert-empty">Sin datos SBS/BCRP pendientes.</div>'}</div>
      ${seenItems.length?`<button type="button" class="source-alert-reviewed-toggle" id="source-reviewed-toggle" aria-expanded="${showReviewed}">Revisadas (${seenItems.length}) <span aria-hidden="true">${showReviewed?'−':'+'}</span></button>${showReviewed?`<div class="source-alert-list source-alert-reviewed-list">${seenItems.map(s=>sourceRow(s,true)).join('')}</div>`:''}`:''}
      <div class="source-alert-bottom"><button type="button" class="source-alert-refresh" id="source-alert-refresh" ${refreshing?'disabled':''}>${refreshing?'Comprobando…':'Comprobar fuentes'}</button><a class="source-alert-view" href="#datos" id="source-alert-view">Actualizar datos</a></div>`;
  }
  function paint(){bell();panel();}
  function show(value){open=!!value;paint();if(open)document.getElementById('source-alert-close')?.focus({preventScroll:true});}
  async function markSource(sourceId){
    const source=pendingSources().find(s=>s.id===sourceId);if(!source)return;
    const reports=unread(source),keys=reports.map(r=>r.alertKey);
    // La respuesta visual es inmediata. Si falla la escritura, se revierte.
    reports.forEach(r=>r.reviewed=true);paint();
    try{
      const response=await fetch('/api/monitor/review',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({keys})});
      if(!response.ok)throw new Error('No se pudo guardar la revisión.');
      status=await response.json();
      paint();
    }catch(_){reports.forEach(r=>r.reviewed=false);paint();window.IASPEApp?.toast?.('No se guardó la revisión. Inténtalo nuevamente.');}
  }
  async function poll(){
    if(busy)return;busy=true;
    const before=JSON.stringify([status?.checkedAt,status?.checking,pending?.observations]);
    try{
      const result=await Promise.allSettled([fetch('/api/monitor/status',{cache:'no-store'}),fetch('/api/models/pending',{cache:'no-store'})]);
      if(result[0].status==='fulfilled'&&result[0].value.ok)status=await result[0].value.json();
      else status={stale:true,checking:false,checkedAt:null,sources:[]};
      if(result[1].status==='fulfilled'&&result[1].value.ok)pending=await result[1].value.json();
    }catch(_){status={stale:true,checking:false,checkedAt:null,sources:[]};}
    finally{busy=false;paint();if(before!==JSON.stringify([status?.checkedAt,status?.checking,pending?.observations]))window.dispatchEvent(new CustomEvent('iaspe:monitor-updated'));clearTimeout(timer);timer=setTimeout(poll,status?.checking?5000:15*60*1000);}
  }
  async function forceRefresh(){
    if(refreshing)return;refreshing=true;paint();
    try{const response=await fetch('/api/monitor/refresh',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
      if(!response.ok)throw new Error('Error');status=await response.json();}
    catch(_){status={...status,stale:true};}
    finally{refreshing=false;paint();poll();}
  }
  function start(){
    if(started)return;started=true;
    document.addEventListener('click',event=>{
      const node=event.target;
      const review=node.closest('[data-source-review]');
      if(review){markSource(review.dataset.sourceReview);return;}
      if(node.closest('#source-alert-trigger')){show(!open);return;}
      if(node.closest('#source-alert-close')){show(false);document.getElementById('source-alert-trigger')?.focus();return;}
      if(node.closest('#source-reviewed-toggle')){showReviewed=!showReviewed;paint();return;}
      if(node.closest('#source-alert-refresh')){forceRefresh();return;}
      if(node.closest('#source-alert-view')){show(false);return;}
      if(open&&!node.closest('#source-alert-area'))show(false);
    });
    document.addEventListener('keydown',event=>{if(open&&event.key==='Escape'){show(false);document.getElementById('source-alert-trigger')?.focus();}});
    window.addEventListener('hashchange',()=>{if(open)show(false);});
    window.addEventListener('focus',()=>{if(!busy)poll();});
    poll();
  }
  window.IASPEMonitor={paint,start,refresh:poll};
})();
