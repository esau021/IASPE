"""Ejecuta las fuentes SBS incluidas en IASPE sin modificar los modelos financieros.

Un único argumento identifica la fuente. `--solo-cache` valida y reprocesa
archivos existentes sin hacer peticiones web; el botón del Dashboard ejecuta
el modo normal. Los notebooks originales siguen siendo la fuente del código.
"""
from __future__ import annotations

import argparse
import ast
import csv
from datetime import date, timedelta
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import runpy
import sys
import urllib.request
import urllib.error
from urllib.parse import urlparse

PROJECT = Path(__file__).resolve().parents[3]
SCRAPER = PROJECT / 'Scraper'
SBS = PROJECT / 'Estados financieros banca' / 'SBS tal cual'
SYSTEM = PROJECT.parent / 'Dashboard' / 'Sistema'
sys.path.insert(0, str(SYSTEM))
from instituciones_sbs import BANKS, CENCOSUD_ID, entity_metadata, match_entity, category_at
BANK_IDS = tuple(BANKS)
SOURCES = {
    'personal_banca', 'personal_financieras', 'personal_rurales', 'ratios', 'tarjetas',
    'morosidad', 'cartera', 'estados_financieros', 'ahorro_moneda', 'tasas_mercado', 'oficinas'
}
MONTHS = [('Enero','en'), ('Febrero','fe'), ('Marzo','ma'), ('Abril','ab'),
          ('Mayo','my'), ('Junio','jn'), ('Julio','jl'), ('Agosto','ag'),
          ('Setiembre','se'), ('Octubre','oc'), ('Noviembre','no'), ('Diciembre','di')]
DOWNLOAD_REPORT = {'reports': {}, 'requests': [], 'errors': [], 'limitations': []}


class NotPublished(FileNotFoundError):
    pass


def month_range(first, last):
    y,m = map(int, first.split('-'))
    while f'{y:04d}-{m:02d}' <= last:
        yield f'{y:04d}-{m:02d}'
        y,m = (y+1,1) if m==12 else (y,m+1)


def source_url(report, period):
    y,m = map(int, period.split('-'))
    folder,short = MONTHS[m-1]
    return f'https://intranet2.sbs.gob.pe/estadistica/financiera/{y}/{folder}/{report}-{short}{y}.XLS'


def source_bytes(report, period):
    """Publicaciones mensuales públicas; 404/410 no significan un dato cero."""
    url = source_url(report, period)
    record = {'report':report, 'period':period, 'url':url, 'checkedAt':datetime.now(timezone.utc).isoformat()}
    DOWNLOAD_REPORT['requests'].append(record)
    try:
        request = urllib.request.Request(url, headers={'User-Agent':'IASPE-SBS/1.0',
            'Accept':'application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})
        with urllib.request.urlopen(request, timeout=25) as response:
            record.update(httpStatus=response.status, finalUrl=response.geturl(), contentType=response.headers.get('Content-Type'))
            if urlparse(response.geturl()).hostname != 'intranet2.sbs.gob.pe':
                raise ValueError('La publicación SBS redirigió a una fuente diferente')
            body = response.read(20_000_001)
        if len(body)>20_000_000:
            raise ValueError('El Excel SBS excede el límite de descarga')
        if not (body.startswith(bytes.fromhex('D0CF11E0A1B11AE1')) or body.startswith(b'PK\x03\x04')):
            raise ValueError('SBS devolvió HTML o una respuesta que no es XLS/XLSX; no se incorpora')
        # Abrir realmente el contenedor antes de sustituir un original válido.
        printed_dates=[]
        if body.startswith(b'PK'):
            from openpyxl import load_workbook
            book=load_workbook(io.BytesIO(body),read_only=True,data_only=True)
            if not book.sheetnames:raise ValueError('Excel sin hojas')
            for sheet in book:
                for row in sheet.iter_rows(max_row=12,max_col=12,values_only=True):
                    printed_dates.extend(v.strftime('%Y-%m') for v in row if isinstance(v,(date,datetime)))
            book.close()
        else:
            import xlrd
            book=xlrd.open_workbook(file_contents=body,on_demand=True)
            if not book.nsheets:raise ValueError('Excel sin hojas')
            for sheet in book.sheets():
                for r in range(min(12,sheet.nrows)):
                    for c in range(min(12,sheet.ncols)):
                        if sheet.cell_type(r,c)==xlrd.XL_CELL_DATE:
                            printed_dates.append(xlrd.xldate_as_datetime(sheet.cell_value(r,c),book.datemode).strftime('%Y-%m'))
            book.release_resources()
        if printed_dates and period not in printed_dates:
            raise ValueError(f'El mes interno del Excel SBS no coincide con {period}: {sorted(set(printed_dates))}')
        record['internalPeriods']=sorted(set(printed_dates))
        record.update(bytes=len(body), sha256=hashlib.sha256(body).hexdigest(), status='downloaded')
        return body
    except urllib.error.HTTPError as exc:
        record.update(httpStatus=exc.code, status='not_published' if exc.code in (404,410) else 'error')
        if exc.code in (404,410):raise NotPublished(f'{report} {period}: HTTP {exc.code}') from exc
        record['error']=str(exc)
        raise RuntimeError(f'SBS {report} {period}: HTTP {exc.code}; no se reintenta ni se elude el control') from exc
    except Exception as exc:
        record.update(status='error',error=str(exc))
        raise


def save_raw(path, body):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.part')
    temporary.write_bytes(body);temporary.replace(path)


def latest_report(report, path_for, offline=False):
    """Busca el máximo mes cerrado con un Excel real, sin imponer dos meses de rezago.

    Se comprueban hacia atrás hasta seis cierres en los enlaces mensuales
    oficiales. Un bloqueo/HTML/error de red aborta; solo 404/410 permite seguir.
    """
    y,m=finish_month(1)
    for _ in range(6):
        period=f'{y:04d}-{m:02d}'
        path=Path(path_for(period))
        if offline:
            if path.is_file():
                DOWNLOAD_REPORT['reports'][report]={'latestPublished':None,'latestProcessed':period,'verification':'local_only'}
                return period
        else:
            try:
                body=source_bytes(report,period)
                save_raw(path,body)
                DOWNLOAD_REPORT['reports'][report]={'latestPublished':period,'latestProcessed':None,
                    'discovery':'Enlaces mensuales SBS verificados hasta el último mes cerrado',
                    'url':source_url(report,period)}
                return period
            except NotPublished:
                pass
        y,m=(y-1,12) if m==1 else (y,m-1)
    raise RuntimeError(f'No se verificó una publicación reciente de {report}; se conserva la base anterior')


def ensure_months(report, periods, path_for, offline=False):
    for period in periods:
        path=Path(path_for(period))
        if path.is_file():continue
        if offline:raise FileNotFoundError(path)
        save_raw(path,source_bytes(report,period))


def processed(report, period):
    DOWNLOAD_REPORT['reports'].setdefault(report,{})['latestProcessed']=period


def finish_month(lag=1):
    day = date.today().replace(day=1)
    for _ in range(lag):
        day = (day - timedelta(days=1)).replace(day=1)
    return day.year, day.month


def trace(message):
    print(message, flush=True)


def execute_notebook(path: Path, overrides: dict[str, str] | None = None, cwd: Path | None = None):
    """Execute source code cells in sequence, with only path/cutoff overrides."""
    document = json.loads(path.read_text(encoding='utf-8'))
    vendor = PROJECT.parent / 'Dashboard' / 'Sistema' / 'vendor'
    if vendor.is_dir() and str(vendor) not in sys.path:
        sys.path.insert(0, str(vendor))
    state = {'__name__': '__iaspe_notebook__', '__file__': str(path)}
    start = Path.cwd()
    if cwd is not None:
        os.chdir(cwd)
    try:
        for i, cell in enumerate(document.get('cells', [])):
            if cell.get('cell_type') != 'code':
                continue
            code = ''.join(cell['source'])
            if not code.strip() or code.lstrip().startswith('%'):
                continue
            # Jupyter display is used for previews only; no IPython dependency.
            code = code.replace('from IPython.display import display',
                                "def display(value): print(str(value)[:900], flush=True)")
            if overrides:
                for line_prefix, new_value in overrides.items():
                    found = re.search(r'(?m)^' + re.escape(line_prefix) + r'\s*=.*$', code)
                    if found:
                        code = code[:found.start()] + line_prefix + ' = ' + new_value + code[found.end():]
            try:
                exec(compile(code, f'{path.name}:cell_{i}', 'exec'), state)
            except Exception as e:
                raise RuntimeError(f'Notebook {path.name}, celda {i}: {e}') from e
    finally:
        os.chdir(start)
    return state


def run_personal_banca(offline):
    return run_personal('B-2305', 'personal_banca_mensual.csv', 'Bancos', offline)


def run_personal_financieras(offline):
    return run_personal('B-3202', 'personal_financieras.csv', 'Empresas financieras', offline)


def run_personal_rurales(offline):
    return run_personal('C-2202', 'personal_rurales.csv', 'Cajas rurales', offline)


def excel_rows(path):
    body=Path(path).read_bytes()
    if body.startswith(b'PK'):
        from openpyxl import load_workbook
        book=load_workbook(io.BytesIO(body),read_only=True,data_only=True)
        try:
            for sheet in book:
                yield sheet.title, list(sheet.iter_rows(values_only=True))
        finally:book.close()
    else:
        import xlrd
        book=xlrd.open_workbook(file_contents=body,on_demand=True)
        try:
            for sheet in book.sheets():
                yield sheet.name,[sheet.row_values(i) for i in range(sheet.nrows)]
        finally:book.release_resources()


def normalized(text):
    import unicodedata
    return re.sub(r'\s+',' ',unicodedata.normalize('NFKD',str(text or '')).encode('ascii','ignore').decode().lower()).strip()


def personal_header(value):
    # Los signos de nota no cambian la identidad de la columna publicada.
    text=normalized(value)
    return re.sub(r'\s*(?:\*+|\d+\s*/|\(\d+\))\s*$','',text).strip()


def extract_personal_source(path, period, report, category):
    monthly=[]
    for sheet,rows in excel_rows(path):
        title=' '.join(normalized(v) for row in rows[:5] for v in row if isinstance(v,str))
        if 'personal' not in title or 'laboral' not in title:continue
        header=next(((i,[personal_header(v) for v in row]) for i,row in enumerate(rows[:15])
                     if any(personal_header(v)=='total' for v in row)),None)
        if header is None:raise ValueError(f'{report} {period}: encabezado Total ausente')
        h,labels=header;total_col=labels.index('total')
        entity_col=next((j for j,label in enumerate(labels) if label in ('empresas','empresa','entidades','bancos')),None)
        if entity_col is None:raise ValueError(f'{report} {period}: encabezado Empresas ausente')
        for i,row in enumerate(rows[h+1:],h+2):
            if entity_col>=len(row) or not isinstance(row[entity_col],str):continue
            clean=re.sub(r'(?:\d+\s*/|\*+)\s*$','',row[entity_col]).strip()
            identifier=match_entity(clean)
            if not identifier:continue
            if category_at(identifier,period)!=category:
                raise ValueError(f'{report} {period}: clasificación incompatible para {clean}: fuente {category}, catálogo {category_at(identifier,period)}')
            total=row[total_col] if total_col<len(row) else None
            if not isinstance(total,(int,float)) or isinstance(total,bool) or total<0 or int(total)!=total:
                raise ValueError(f'{report} {period}: conteo total inválido de {clean}')
            item={'periodo':period,'banco':BANKS[identifier],'personal_total':int(total),
                  'nombre_sbs':row[entity_col].strip(),'archivo':path.name,'hoja':sheet,'fila_excel':i,
                  'sistema':entity_metadata(identifier,period)['sistema']}
            from openpyxl.utils import get_column_letter
            item['_total_cell']=f'{get_column_letter(total_col+1)}{i}'
            for field in ('gerentes','funcionarios','empleados','otros'):
                col=next((j for j,label in enumerate(labels) if label==field),None)
                value=row[col] if col is not None and col<len(row) else None
                item[field]=int(value) if isinstance(value,(int,float)) and not isinstance(value,bool) and value>=0 and int(value)==value else ''
            categories=('gerentes','funcionarios','empleados','otros')
            if all(isinstance(item[f],int) for f in categories) and sum(item[f] for f in categories)!=item['personal_total']:
                raise ValueError(f'{report} {period}: categorías no concilian con Total')
            monthly.append(item)
    if len({r['banco'] for r in monthly})!=len(monthly):
        raise ValueError(f'{report} {period}: entidad duplicada')
    if not monthly:raise ValueError(f'{report} {period}: ninguna entidad del catálogo reconocida')
    return monthly


def run_personal(report, filename, category, offline):
    folder=SCRAPER/'Numero_trabajadores'
    raw=folder/'fuentes'/report
    path_for=lambda p: raw/source_url(report,p).rsplit('/',1)[-1]
    latest=latest_report(report,path_for,offline)
    target=folder/'output'/filename
    previous=[]
    if target.is_file():
        with target.open(encoding='utf-8-sig',newline='') as f:previous=list(csv.DictReader(f))
    first=max((r['periodo'] for r in previous),default='2025-12')
    ensure_months(report,month_range(first,latest),path_for,offline)
    records={(r['periodo'],r['banco']):r for r in previous}
    fields=['periodo','banco','personal_total','gerentes','funcionarios','empleados','otros',
            'nombre_sbs','archivo','hoja','fila_excel','sistema']
    latest_count=0
    abbr={v[1]:i+1 for i,v in enumerate(MONTHS)}
    for path in sorted(raw.glob(f'{report}-*.XLS')):
        match=re.fullmatch(re.escape(report)+r'-([a-z]{2})(\d{4})',path.stem,re.I)
        if not match or match[1].lower() not in abbr:continue
        period=f'{int(match[2]):04d}-{abbr[match[1].lower()]:02d}'
        if period>latest:continue
        monthly=extract_personal_source(path,period,report,category)
        if period==latest:
            latest_count=len(monthly)
            if not monthly:raise ValueError(f'{report} {period}: Excel descargado sin entidades reconocidas')
            expected={identifier for identifier in BANKS if category_at(identifier,period)==category}
            actual={match_entity(r['banco']) for r in monthly}
            if expected-actual:
                missing=', '.join(BANKS[b] for b in BANKS if b in expected-actual)
                raise ValueError(f'{report} {period}: entidades comparables ausentes de la publicación procesada: {missing}')
        for item in monthly:records[item['periodo'],item['banco']]=item
    if not latest_count:raise ValueError(f'Personal {report}: no se procesó la publicación {latest}')
    target.parent.mkdir(parents=True,exist_ok=True)
    temporary=target.with_suffix('.tmp')
    with temporary.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');writer.writeheader()
        writer.writerows(records[k] for k in sorted(records))
    temporary.replace(target)
    processed(report,latest)
    if report=='C-2202':
        selected=[r for r in records.values() if r['periodo']==latest]
        proof={'iaspeId':CENCOSUD_ID,'sbsType':'CR','sbsCode':'18','period':latest,
            'unit':'personas','records':selected,'sourceFile':str(path_for(latest).relative_to(PROJECT)),
            'sourceSha256':hashlib.sha256(path_for(latest).read_bytes()).hexdigest(),
            'cell':selected[0].get('_total_cell'),'note':'Identificación por nombre de entidad y encabezados; sin posiciones fijas'}
        (folder/'output/validacion_cencosud.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    trace(f'{report}: {latest}, {latest_count} entidades, {len(records)} registros conservados.')
    return records


def run_ratios(offline):
    folder = SCRAPER / 'Ratios_financieros_mercado'
    path = folder / 'script/descargar_ratios_sbs.ipynb'
    latest={}
    firsts={}
    for report in ('B-2401','B-2402','B-3301','B-3302','C-2301','C-2257'):
        path_for=lambda p,r=report: folder/'fuentes'/r/f'{r}-{p}.XLS'
        cached=sorted(p.stem[-7:] for p in (folder/'fuentes'/report).glob(f'{report}-*.XLS'))
        first='2025-12' if report.startswith('C-') else max(cached,default='2026-08')
        period=latest_report(report,path_for,offline)
        ensure_months(report,month_range(first,period),path_for,offline)
        latest[report]=tuple(map(int,period.split('-')))
        if report.startswith('C-'):firsts[report]=(2025,12)
    trace(f'Ratios: últimas publicaciones verificadas {latest}.')
    execute_notebook(path, overrides={
        'RUTA_CARPETA': repr(str(folder)),
        'ULTIMO_POR_REPORTE': repr(latest),
        'INICIO_POR_REPORTE': repr(firsts),
        # La adquisición ya terminó y validó las fuentes; el notebook procesa.
        'REINTENTOS': '0',
    }, cwd=PROJECT)
    summary = json.loads((folder/'output/resumen_auditoria.json').read_text(encoding='utf-8'))
    if summary.get('registros_identificados', 0) < 100:
        raise RuntimeError('Ratio SBS: se detectaron muy pocos indicadores.')
    if summary.get('archivos_no_descargados', 0):
        DOWNLOAD_REPORT['limitations'].append(f"Ratios: {summary['archivos_no_descargados']} originales históricos ausentes; no se imputan")
    with (folder/'output/indicadores_16_entidades_principales.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    for report,ym in latest.items():
        period=f'{ym[0]}-{ym[1]:02d}'
        if not any(r['reporte']==report and r['periodo_fuente']==period for r in rows):
            raise ValueError(f'Ratios: última publicación {report} {period} no procesada')
        processed(report,period)
    proof=[r for r in rows if r['banco_id']==CENCOSUD_ID and r['periodo_fuente']==DOWNLOAD_REPORT['reports'][r['reporte']]['latestProcessed']]
    (folder/'output/validacion_cencosud.json').write_text(json.dumps({'iaspeId':CENCOSUD_ID,
        'sbsType':'CR','sbsCode':'18','records':proof},ensure_ascii=False,indent=2),encoding='utf-8')


def run_tarjetas(offline):
    path = SCRAPER / 'Numero_tarjetas/script/Extraer_numero_tarjetas_SBS.ipynb'
    output=SCRAPER/'Numero_tarjetas/output/SBS_Tarjetas_Consumo_y_Total_Banca_Falabella_2008_2026.xlsx'
    template=output.read_bytes()
    folder=SCRAPER/'Numero_tarjetas/fuentes'
    path_for=lambda p: folder/f'B-2363_{p[:4]}_{p[-2:]}.xls'
    latest=latest_report('B-2363',path_for,offline)
    index=folder/'Indice_fuentes.json'
    rows=json.loads(index.read_text(encoding='utf-8'))
    last=max(f'{r["anio"]}-{r["mes"]:02d}' for r in rows)
    ensure_months('B-2363',month_range(last,latest),path_for,offline)
    keys={(r['anio'],r['mes']) for r in rows}
    for period in month_range(last,latest):
        y,m=map(int,period.split('-'))
        if (y,m) not in keys:rows.append({'anio':y,'mes':m,'url':source_url('B-2363',period)})
    index.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    execute_notebook(path, overrides={'ACTUALIZAR_ENLACES':'False'}, cwd=PROJECT)
    preserve=runpy.run_path(str(Path(__file__).with_name('conservar_formato_observado.py')))['conservar_formato_observado']
    preservation=preserve(output,template,tipo='tarjetas')
    DOWNLOAD_REPORT.setdefault('formatPreservation',[]).append(preservation)
    processed('B-2363',latest)


def run_morosidad(offline):
    module = SCRAPER / 'Morosidad_tarjetas'
    path = module / 'script/Morosidad_tarjetas_SBS.ipynb'
    output=module/'output/Morosidad_tarjetas_consumo_banca_multiple.xlsx'
    template=output.read_bytes()
    path_for=lambda p: module/'fuentes'/f'B-2362_{p[:4]}_{p[-2:]}.xls'
    latest=latest_report('B-2362',path_for,offline)
    cutoff=tuple(map(int,latest.split('-')))
    index=module/'fuentes/Indice_fuentes.json'
    rows=json.loads(index.read_text(encoding='utf-8'))
    last=max(f'{r["anio"]}-{r["mes"]:02d}' for r in rows)
    ensure_months('B-2362',month_range(last,latest),path_for,offline)
    keys={(r['anio'],r['mes']) for r in rows}
    for period in month_range(last,latest):
        y,m=map(int,period.split('-'))
        if (y,m) not in keys:rows.append({'anio':y,'mes':m,'url':source_url('B-2362',period),
            'archivo':path_for(period).name,'procedencia_url':'Reporte mensual SBS B-2362'})
    index.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    trace(f'Morosidad: fecha de cierre de consulta {cutoff[0]}-{cutoff[1]:02d}.')
    execute_notebook(path, overrides={
        'ACTUALIZAR_INDICE': 'False',
        'CORTE': repr(cutoff),
    }, cwd=module)
    preserve=runpy.run_path(str(Path(__file__).with_name('conservar_formato_observado.py')))['conservar_formato_observado']
    preservation=preserve(output,template,tipo='morosidad')
    DOWNLOAD_REPORT.setdefault('formatPreservation',[]).append(preservation)
    processed('B-2362',latest)


def _download_cartera(offline):
    folder=SCRAPER/'Cartera_consumo_mercado/fuentes'
    path_for=lambda p: folder/source_url('B-2389',p).rsplit('/',1)[-1]
    abbr={v[1]:i+1 for i,v in enumerate(MONTHS)}
    cached=[]
    for path in folder.glob('B-2389-*.XLS'):
        match=re.fullmatch(r'B-2389-([a-z]{2})(\d{4})',path.stem,re.I)
        if match and match[1].lower() in abbr:cached.append(f'{int(match[2])}-{abbr[match[1].lower()]:02d}')
    first=max(cached,default='2026-08')
    latest=latest_report('B-2389',path_for,offline)
    ensure_months('B-2389',month_range(first,latest),path_for,offline)
    return latest

def run_cartera(offline):
    latest=_download_cartera(offline)
    path = SCRAPER/'Cartera_consumo_mercado/script/Extraer_cartera_consumo_mercado.py'
    runpy.run_path(str(path), run_name='__main__')
    runpy.run_path(str(SCRAPER/'Cartera_consumo_mercado/script/construir_panel_bancos.py'),run_name='__main__')
    processed('B-2389',latest)


def native_sbs_functions():
    notebook=next((SBS/'05 Banco Falabella Peru').glob('*.ipynb'))
    document=json.loads(notebook.read_text(encoding='utf-8'))
    code=next(''.join(c['source']) for c in document['cells'] if c.get('cell_type')=='code' and 'def leer_mensual(' in ''.join(c['source']))
    functions={'__name__':'iaspe_sbs_native'}
    exec(compile(code,str(notebook)+':reader','exec'),functions)
    native_normal=functions['normal']
    functions['normal']=lambda text: re.sub(r'(?:\d+[/)]|\*+)\s*$','',native_normal(text)).strip()
    return functions


def eeff_config(identifier, period=None):
    meta=entity_metadata(identifier,period)
    original={}
    if identifier!=CENCOSUD_ID:
        notebooks=list(SBS.glob(identifier+' */*.ipynb'))
        if len(notebooks)!=1:raise ValueError(f'EEFF: configuración original ambigua de {identifier}')
        document=json.loads(notebooks[0].read_text(encoding='utf-8'))
        for cell in document['cells']:
            if cell.get('cell_type')!='code':continue
            code=''.join(cell['source'])
            if 'CONFIG =' not in code:continue
            assignment=next(n for n in ast.parse(code).body if isinstance(n,ast.Assign)
                and any(isinstance(t,ast.Name) and t.id=='CONFIG' for t in n.targets))
            original=ast.literal_eval(assignment.value)
            break
    if identifier==CENCOSUD_ID:
        report='B-2201' if period and period<'2019-03' else 'C-2101'
    elif identifier=='10' or (identifier in ('06','13','15') and category_at(identifier,period)=='Empresas financieras'):
        report='B-3101'
    else:report='B-2201'
    aliases=list(dict.fromkeys([*original.get('aliases',[]),*meta['aliases']]))
    return {'id':identifier,'name':BANKS[identifier],'code':report,'aliases':aliases}


def raw_eeff(report, period):
    return SCRAPER/'EEFF_Benchmark/fuentes'/report/source_url(report,period).rsplit('/',1)[-1]


def append_eeff(source, reports, functions):
    """Edita las columnas observadas en OOXML; conserva fórmulas y sus cachés."""
    import calendar
    from copy import deepcopy
    from collections import Counter
    from zipfile import ZipFile
    from xml.etree import ElementTree as ET
    from openpyxl.utils import get_column_letter, column_index_from_string
    from openpyxl.utils.datetime import from_excel, to_excel
    ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    tag=lambda n:'{'+ns+'}'+n
    ET.register_namespace('',ns)
    relns='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
    # La presentación nativa conserva variantes literales como Vigentes** o
    # PROVISIONES con espacio final. No son alias para asignar celdas históricas.
    norm=lambda value: str(value) if value is not None else ''
    tables={}
    with ZipFile(source) as archive:
        strings=[]
        if 'xl/sharedStrings.xml' in archive.namelist():
            strings=[''.join(e.itertext()) for e in ET.fromstring(archive.read('xl/sharedStrings.xml')).findall(tag('si'))]
        rels={e.get('Id'):e.get('Target').lstrip('/') for e in ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))}
        workbook=ET.fromstring(archive.read('xl/workbook.xml'))
        for item in workbook.findall('.//'+tag('sheet')):
            name=item.get('name')
            if name not in ('SITUACION_FINANCIERA','ESTADO_RESULTADOS','ER_MENSUAL'):continue
            loc=rels[item.get(relns+'id')]
            if not loc.startswith('xl/'):loc='xl/'+loc
            root=ET.fromstring(archive.read(loc));data=root.find(tag('sheetData'))
            rows={int(r.get('r')):r for r in data.findall(tag('row'))}
            cells={};values={}
            for r,row in rows.items():
                for cell in row.findall(tag('c')):
                    letters=re.match(r'[A-Z]+',cell.get('r'))[0];col=column_index_from_string(letters)
                    cells[r,col]=cell;v=cell.find(tag('v'));inline=cell.find(tag('is'))
                    value=v.text if v is not None else ''.join(inline.itertext()) if inline is not None else None
                    if value is not None:
                        if cell.get('t')=='s':value=strings[int(value)]
                        elif cell.get('t') not in ('inlineStr','str','e'):
                            try:value=float(value)
                            except (ValueError,TypeError):pass
                    values[r,col]=value
            cols={from_excel(v).strftime('%Y-%m'):c for (r,c),v in values.items() if r==6 and isinstance(v,(int,float))}
            counts=Counter();rowkeys={}
            for r in sorted(rows):
                label=values.get((r,1))
                if r<7 or not isinstance(label,str) or not label.strip():continue
                keylabel=norm(label);counts[keylabel]+=1;rowkeys[keylabel,counts[keylabel]]=r
            tables[name]={'root':root,'data':data,'rows':rows,'cells':cells,'values':values,
                          'cols':cols,'rowkeys':rowkeys,'location':loc,'lastcol':max(cols.values()),
                          # La columna actual puede refrescarse antes de añadir
                          # la siguiente: conservar su plantilla antes de borrar.
                          'styles':{key:cell.get('s') for key,cell in cells.items()}}
        def cell_style(table,row,col):
            return table['styles'].get((row,col),table['styles'].get((row,table['lastcol'])))
        def write(table,row,col,value,formula=None,style=None):
            old=table['cells'].pop((row,col),None)
            record=table['rows'].get(row)
            if record is None:
                record=ET.SubElement(table['data'],tag('row'),{'r':str(row)});table['rows'][row]=record
            if old is not None:record.remove(old)
            table['values'][row,col]=value
            if value is None and style is None:return
            attrs={'r':f'{get_column_letter(col)}{row}'}
            if style is not None:attrs['s']=style
            cell=ET.SubElement(record,tag('c'),attrs)
            if value is None:
                pass  # Una celda vacía puede conservar un formato visible.
            elif isinstance(value,str):
                cell.set('t','inlineStr');ET.SubElement(ET.SubElement(cell,tag('is')),tag('t')).text=value
            else:
                if formula:ET.SubElement(cell,tag('f')).text=formula
                ET.SubElement(cell,tag('v')).text=str(value)
            table['cells'][row,col]=cell
        for name,table in tables.items():
            state='ESF' if name=='SITUACION_FINANCIERA' else 'ER'
            for period,report in sorted(reports.items()):
                if period in table['cols']:col=table['cols'][period]
                else:
                    col=max(table['cols'].values())+1;y,m=map(int,period.split('-'))
                    style=table['cells'][6,table['lastcol']].get('s')
                    write(table,6,col,to_excel(datetime(y,m,calendar.monthrange(y,m)[1])),style=style)
                    table['cols'][period]=col
                    columns=table['root'].find(tag('cols'))
                    if columns is not None:
                        last=next((c for c in columns if int(c.get('min'))<=table['lastcol']<=int(c.get('max'))),None)
                        if last is not None:
                            copied=deepcopy(last);copied.set('min',str(col));copied.set('max',str(col));columns.append(copied)
                for row in list(table['rows']):
                    if row>=7:write(table,row,col,None,style=cell_style(table,row,col))
                occurrences=Counter()
                for item in report['rows']:
                    if item['statement']!=state:continue
                    label=norm(item['raw_label']);occurrences[label]+=1;key=(label,occurrences[label])
                    row=table['rowkeys'].get(key)
                    if row is None:
                        row=max(table['rows'])+1;table['rowkeys'][key]=row
                        prior=table['cells'].get((row-1,1))
                        write(table,row,1,item['raw_label'],style=prior.get('s') if prior is not None else None)
                    value=item['currencies']['TOTAL']['value'];formula=None
                    if not isinstance(value,(int,float)) or isinstance(value,bool):value=None
                    if name=='ER_MENSUAL' and value is not None:
                        cumulative=tables['ESTADO_RESULTADOS'];cumrow=cumulative['rowkeys'][key]
                        formula=f"'ESTADO_RESULTADOS'!{get_column_letter(col)}{cumrow}"
                        if not period.endswith('-01'):
                            y,m=map(int,period.split('-'));priorcol=cumulative['cols'].get(f'{y}-{m-1:02d}')
                            candidates=[(r,cumulative['values'].get((r,priorcol))) for r in sorted(cumulative['rows'])
                                if norm(cumulative['values'].get((r,1)))==label and isinstance(cumulative['values'].get((r,priorcol)),(int,float))]
                            ordinal=occurrences[label]-1
                            if ordinal<len(candidates):
                                priorrow,priorvalue=candidates[ordinal];value-=priorvalue
                                formula+=f"-'ESTADO_RESULTADOS'!{get_column_letter(priorcol)}{priorrow}"
                            else:value=None;formula=None
                    write(table,row,col,value,formula,cell_style(table,row,col))
            # OOXML conserva el orden de filas/celdas y el rango de las tablas.
            for row in table['rows'].values():
                children=sorted(list(row),key=lambda c:column_index_from_string(re.match(r'[A-Z]+',c.get('r'))[0]))
                row[:]=children
            table['data'][:]=[table['rows'][r] for r in sorted(table['rows'])]
            end=f"{get_column_letter(max(table['cols'].values()))}{max(table['rows'])}"
            dimension=table['root'].find(tag('dimension'))
            if dimension is not None:dimension.set('ref','A2:'+end)
            auto=table['root'].find(tag('autoFilter'))
            if auto is not None:auto.set('ref','A6:'+end)
        replacements={t['location']:ET.tostring(t['root'],encoding='utf-8',xml_declaration=True) for t in tables.values()}
        temporary=Path(source).with_suffix('.tmp.xlsx')
        with ZipFile(temporary,'w') as target:
            for info in archive.infolist():target.writestr(info,replacements.get(info.filename,archive.read(info.filename)))
    temporary.replace(source)

def run_estados_financieros(offline, bancos=None):
    selected=set(BANK_IDS if bancos is None else bancos)
    if not selected or not selected.issubset(BANK_IDS):raise ValueError('EEFF: selección IASPE no válida')
    functions=native_sbs_functions()
    latest={}
    for report in sorted({eeff_config(identifier)['code'] for identifier in selected}):
        latest[report]=latest_report(report,lambda p,r=report:raw_eeff(r,p),offline)
    audit=[]
    proof=[]
    for identifier in BANK_IDS:
        if identifier not in selected:continue
        config=eeff_config(identifier)
        horizon=latest[config['code']]
        if identifier==CENCOSUD_ID:
            folder=SBS/(CENCOSUD_ID+' Cencosud Scotia')
            source=folder/'Caja Cencosud Scotia - SBS tal cual.xlsx'
        else:
            folders=list(SBS.glob(identifier+' *'))
            if len(folders)!=1:raise ValueError(f'EEFF: carpeta ambigua de {identifier}')
            folder=folders[0];sources=list(folder.glob('*.xlsx'))
            if len(sources)!=1:raise ValueError(f'EEFF: libro ambiguo de {identifier}')
            source=sources[0]
        if source.is_file():
            from openpyxl import load_workbook
            book=load_workbook(source,read_only=True,data_only=True)
            last=max(c.value.strftime('%Y-%m') for c in next(book['SITUACION_FINANCIERA'].iter_rows(min_row=6,max_row=6)) if isinstance(c.value,datetime));book.close()
            first='2016-01' if identifier==CENCOSUD_ID else min(last,horizon)
        else:first='2016-01'
        reports={}
        for period in month_range(first,horizon):
            cfg=eeff_config(identifier,period)
            path=raw_eeff(cfg['code'],period)
            if not path.is_file():
                if offline:raise FileNotFoundError(path)
                save_raw(path,source_bytes(cfg['code'],period))
            reports[period]=functions['leer_mensual'](path,period,cfg['aliases'])
            if identifier==CENCOSUD_ID and period==horizon:
                for row in reports[period]['rows']:
                    if functions['normal'](row['raw_label']) not in ('TOTAL ACTIVO','INGRESOS FINANCIEROS','RESULTADO NETO DEL EJERCICIO'):continue
                    cell=row['currencies']['TOTAL']
                    proof.append({'period':period,'statement':row['statement'],'account':row['raw_label'],
                        'sourceFile':str(path.relative_to(PROJECT)),'sheet':row['source_sheet'],'cell':cell['source_cell'],
                        'value':cell['value'],'unit':'S/ miles','processedValue':cell['value']/1000,
                        'processedUnit':'S/ millones','sha256':reports[period]['metadata']['sha256']})
            audit.append({'entity':identifier,'period':period,'report':cfg['code'],
                'file':str(path.relative_to(PROJECT)).replace('\\','/'),
                'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        if source.is_file() and identifier!=CENCOSUD_ID:append_eeff(source,reports,functions)
        else:
            folder.mkdir(parents=True,exist_ok=True)
            spec=functions['construir_presentacion'](config,reports)
            functions['exportar'](spec,source)
        processed(config['code'],horizon)
        trace(f'EEFF: {BANKS[identifier]} / {horizon}; {len(reports)} meses leídos, historia conservada.')
    output=SCRAPER/'EEFF_Benchmark/output';output.mkdir(parents=True,exist_ok=True)
    (output/'adquisicion_eeff.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    if proof:(output/'validacion_cencosud.json').write_text(json.dumps({'iaspeId':CENCOSUD_ID,
        'sbsType':'CR','sbsCode':'18','records':proof},ensure_ascii=False,indent=2),encoding='utf-8')
    module=runpy.run_path(str(SCRAPER/'EEFF_Benchmark/script/construir_panel.py'),run_name='iaspe_panel')
    module['build'](PROJECT,output)
    runpy.run_path(str(SCRAPER/'EEFF_Benchmark/script/validar_panel.py'),run_name='__main__')

def run_ahorro_moneda(offline):
    from ahorro_moneda_sbs import ejecutar as ahorro
    latest=latest_report('B-2201',lambda p:raw_eeff('B-2201',p),offline)
    ensure_months('B-2201',month_range('2025-12',latest),lambda p:raw_eeff('B-2201',p),offline)
    series = ahorro(offline,latest=latest)
    processed('B-2201',latest)
    trace(f"Ahorro MN/ME: {len(series['series']['08_mn'])} meses conciliados con SBS.")


def run_tasas_mercado(offline):
    import tasas_mercado
    import compras_bcrp
    try:
        datos = tasas_mercado.ejecutar(offline)
        tarjeta = compras_bcrp.ejecutar(offline)
    finally:
        DOWNLOAD_REPORT['requests'].extend(tasas_mercado.REQUESTS+compras_bcrp.REQUESTS)
    for mid,points in {**datos,**tarjeta}.items():
        code=tasas_mercado.SERIES.get(mid,compras_bcrp.SERIE)
        last=max(points,default=None)
        DOWNLOAD_REPORT['reports'][code]={'latestPublished':None if offline else last,'latestProcessed':last,
            'discovery':'Períodos no vacíos devueltos por la API oficial BCRP'}
    trace('BCRP: ' + ', '.join(f'{k}: {len(v)} meses' for k, v in {**datos, **tarjeta}.items()))


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(errors='backslashreplace')
    parser=argparse.ArgumentParser()
    parser.add_argument('source', choices=sorted(SOURCES))
    parser.add_argument('--solo-cache', action='store_true')
    parser.add_argument('--bancos', metavar='ID,ID,...', default=None,
                        help='IDs internos IASPE, separados por coma (solo estados_financieros).')
    args=parser.parse_args()
    bank_selection = None
    if args.bancos is not None:
        if args.source != 'estados_financieros':
            parser.error('--bancos solo se aplica a estados_financieros.')
        bank_selection = args.bancos.split(',')
        if (not bank_selection or len(bank_selection) != len(set(bank_selection))
                or any(bank not in BANK_IDS for bank in bank_selection)):
            parser.error('La selección --bancos debe contener IDs IASPE válidos y únicos.')
    os.environ['IASPE_DIR']=str(PROJECT)
    os.environ['IASPE_ROOT']=str(PROJECT)
    if args.source == 'oficinas':
        import subprocess
        command = [sys.executable, '-B', '-u', str(SCRAPER/'Oficinas/script/actualizar_oficinas.py'), '--history']
        if args.solo_cache:
            command.append('--solo-cache')
        result = subprocess.run(command)
        if result.returncode:
            raise SystemExit(result.returncode)
        return
    jobs={
        'personal_banca':run_personal_banca,
        'personal_financieras':run_personal_financieras,
        'personal_rurales':run_personal_rurales,
        'ratios':run_ratios,
        'tarjetas':run_tarjetas,
        'morosidad':run_morosidad,
        'cartera':run_cartera,
        'estados_financieros':run_estados_financieros,
        'ahorro_moneda':run_ahorro_moneda,
        'tasas_mercado':run_tasas_mercado,
    }
    trace(f'IASPE SBS · {args.source}: inicio')
    try:
        if args.source == 'estados_financieros':
            jobs[args.source](args.solo_cache, bank_selection)
        else:
            jobs[args.source](args.solo_cache)
        DOWNLOAD_REPORT['status']='local_only' if args.solo_cache else 'success'
    except Exception as exc:
        DOWNLOAD_REPORT['status']='error'
        DOWNLOAD_REPORT['errors'].append(f'{type(exc).__name__}: {exc}')
        raise
    finally:
        report=DOWNLOAD_REPORT
        report.update(source=args.source,checkedAt=datetime.now(timezone.utc).isoformat(),
            latestPublished=max((v.get('latestPublished') or '' for v in report['reports'].values()),default='') or None,
            latestProcessed=max((v.get('latestProcessed') or '' for v in report['reports'].values()),default='') or None,
            downloaded=sum(r.get('status')=='downloaded' for r in report['requests']))
        target=SCRAPER/'Actualizacion/output'/f'descarga_{args.source}.json'
        target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_suffix('.tmp')
        temporary.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');temporary.replace(target)
    trace(f'IASPE SBS · {args.source}: procesamiento terminado y validable')


if __name__=='__main__':
    main()
