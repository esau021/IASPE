/* v1.9.7: interfaz de previsualización, confirmación y separación del MEF. */
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const file=process.argv[2]||path.join(__dirname,'proyecciones-externas.js');
const source=fs.readFileSync(file,'utf8').replace('window.IASPEMacroExternas={',`window.testAPI={
  recordsBySeries,summaryStats,tableForVariable,forecasts,publicationCalendar,referenceLabel,update,sources,importFeedback,showImportResult,clearImportFeedback,
  previewFile,confirmFile,previewPanel,previewTables,officialSourceLinks,render,
  setState(v){state=v},setUpdate(v){updateResult=v},setTab(v){tab=v},setPreview(v){previewData=v},
  getState(){return state},getPreview(){return previewData},getImport(){return importResult},getTab(){return tab}
};window.IASPEMacroExternas={`);
const widgets={};
const root={innerHTML:'',querySelector(k){return widgets[k]||null;},querySelectorAll(){return []}};
const ctx={window:{},document:{querySelector(s){return s==='#workspace'?root:widgets[s]||null}},console,URL,Intl,Date,Map,Set,location:{hash:'#datos/proyecciones'},AbortController,AbortSignal,setTimeout,clearTimeout};
vm.createContext(ctx);vm.runInContext(source,ctx);
const a=ctx.window.testAPI;let count=0;
function check(label,test){assert(test,label);count++;}
const sourceB='BCRP · encuesta anual';
const rec=(variable,group,year,edition,value)=>({source:sourceB,variable,group,year,edition,value,unit:'%',kind:'anual',document_id:'a'});
a.setState({current_records:[rec('pbi','Analistas económicos','2026','2026-04',2.9)],editions:[],checks:[],lastCheck:null});
const idx=a.recordsBySeries();
check('historical current value',idx.get('pbi|'+sourceB+'|Analistas económicos|2026').value===2.9);
check('no state column',!a.tableForVariable('pbi',idx).includes('<th>Estado</th>'));
check('no document column',!a.tableForVariable('pbi',idx).includes('<th>Documento</th>'));
check('no redundant explorer',!a.forecasts().includes('Detalle de las expectativas'));
check('monthly recurring calendar',a.publicationCalendar(['pbi']).includes('Del 3 al 10 de cada mes'));
check('four official links including FMI', (a.officialSourceLinks().match(/target="_blank"/g)||[]).length===4);
// Media y mediana para los pronósticos visibles de TODAS las instituciones,
// por año y sin agregaciones con una sola fuente.
const gs=['Analistas económicos','Sistema financiero','Empresas no financieras'];
const cohort=[];
for (const [year,values] of [['2026',[3.1,3.2,3.2]],['2027',[3.1,3.0,3.3]],['2028',[4.0,3.5,3.5]]]) {
 gs.forEach((group,i)=>cohort.push(rec('pbi',group,year,'2026-10',values[i])));
}
const ri=(year,value)=>({source:'BCRP · Reporte de Inflación',variable:'pbi',group:'',year,edition:'Setiembre 2026',revision:'2026-09',value,unit:'%',kind:'anual'});
const mef=(year,value)=>({source:'MEF · MMM/IAPM',variable:'pbi',group:'',year,edition:'MMM 2027–2030',value,unit:'%',kind:'anual',document_id:'mef'});
const all=[...cohort,ri('2026',3.2),ri('2027',3.0),mef('2026',3.4),mef('2027',3.44),mef('2028',3.96),mef('2029',3.98),mef('2030',3.96)];
a.setState({current_records:all,editions:[],checks:[],lastCheck:null});
const derivedHTML=a.tableForVariable('pbi',a.recordsBySeries());
check('average from all five year 2026',Math.abs(a.summaryStats([all[0],all[1],all[2],all[9],all[11]]).mean-3.22)<1e-10);
check('even median from four forecasts',a.summaryStats([cohort[6],cohort[7],cohort[8],mef('2028',3.96)]).median===3.73);
check('2026 summary visible',derivedHTML.includes('3.22 %')&&derivedHTML.includes('3.20 %'));
check('2027 summary visible',derivedHTML.includes('3.17 %')&&derivedHTML.includes('3.10 %'));
check('2028 summary visible',derivedHTML.includes('3.74 %')&&derivedHTML.includes('3.73 %'));
check('no fabricated 2029 summary with one forecast',derivedHTML.includes('<td class="numeric mex-blank">—</td>'));
check('aggregation at very end after MEF',derivedHTML.indexOf('>Media</td>')>derivedHTML.indexOf('MEF · Marco Macroeconómico'));
check('labels only: no edition or source on summary',derivedHTML.includes('colspan="3" class="mex-derived-label">Media')&&!derivedHTML.includes('Resumen de encuesta'));
check('no summary explanatory note',!a.forecasts().includes('Media y mediana de grupos:'));
check('no aggregation for TC promedio single source',!a.tableForVariable('tc_promedio',a.recordsBySeries()).includes('mex-derived-row'));
check('require >= 2 values',a.summaryStats([mef('2030',3.96)])===null);
check('zero values remain valid numbers',a.summaryStats([mef('2026',0),ri('2026',0)]).mean===0);
a.setState({current_records:[rec('pbi','Analistas económicos','2026','2026-04',2.9)],editions:[],checks:[],lastCheck:null});

a.setTab('fuentes');a.render();
check('upload tab no auto MEF',!root.innerHTML.includes('id="mex-update"'));
check('three upload controls',a.sources().includes('id="mex-import-source"')&&a.sources().includes('id="mex-import-format"')&&a.sources().includes('id="mex-import-file"'));
check('no manual metadata',!a.sources().includes('Enlace oficial')&&!a.sources().includes('id="mex-import-edition"'));
check('preview step, not import',a.sources().includes('Previsualizar')&&!a.sources().includes('>Importar</button>'));
const p={token:'t'.repeat(40),document:{edition:'2026-10',source:sourceB,title:'nota.pdf',rows:27},records:[
  {variable:'pbi',source:sourceB,group:'Analistas económicos',year:'2026',unit:'%',before:2.9,after:3.1,status:'cambio',will_update:true},
  {variable:'inflacion',source:sourceB,group:'Sistema financiero',year:'2026',unit:'%',before:4.5,after:4.5,status:'igual',will_update:false},
  {variable:'tc_cierre',source:sourceB,group:'Empresas no financieras',year:'2028',unit:'S/ por USD',before:3.4,after:3.47,status:'cambio',will_update:true}
],changes:2,history_count:81};
a.setPreview(p);
let html=a.previewPanel();
check('all three variables',html.includes('PBI real')&&html.includes('Inflación anual')&&html.includes('Tipo de cambio al cierre'));
check('old vs new values',html.includes('2.90 %')&&html.includes('3.10 %'));
check('preview buttons',html.includes('Confirmar cambios')&&html.includes('Cancelar'));
check('archive not updated on preview',a.getState().current_records.length===1);
check('no redundant forecasts',!a.sources().includes('Reporte de Inflación:</strong>'));
widgets['#mex-import-file']={files:[{name:'nota.pdf',size:100}]};
widgets['#mex-import-format']={value:'pdf',options:[{value:'pdf',disabled:false},{value:'xlsx',disabled:false}]};
widgets['#mex-import-source']={value:sourceB};
widgets['#mex-import']={disabled:false,textContent:'Previsualizar'};
widgets['#mex-import-feedback']={innerHTML:''};
widgets['#mex-import-preview']={innerHTML:''};
widgets['#mex-preview-confirm']={disabled:false,textContent:'Confirmar cambios'};
widgets['#mex-preview-cancel']={disabled:false};
for(const widget of Object.values(widgets))widget.addEventListener=()=>{};
ctx.FileReader=class {readAsDataURL(){this.result='data:application/pdf;base64,dGVzdA==';this.onload()}};
(async()=>{
  let actions=[];
  ctx.fetch=async(url,opts)=>{actions.push([url,JSON.parse(opts.body)]);return {ok:true,status:200,json:async()=>p}};
  await a.previewFile();
  check('preview uses preview endpoint',actions.length===1&&actions[0][0]==='/api/macro-external/preview');
  check('preview submits source but no invented metadata',actions[0][1].source===sourceB&&!('edition' in actions[0][1]));
  check('preview displayed',a.getPreview().document.edition==='2026-10');
  // Reproduce la falla original: el botón Confirmar quedaba disabled hasta cambiar de pestaña.
  check('confirm available immediately after preview without tab switch',
    root.innerHTML.includes('id="mex-preview-confirm"') &&
    !/<button[^>]*id="mex-preview-confirm"[^>]*disabled/.test(root.innerHTML) &&
    !root.innerHTML.includes('>Guardando…</button>'));

  check('no import during preview',actions.every(x=>x[0]!=='/api/macro-external/import'));
  check('state unchanged before confirm',a.getState().current_records.length===1);
  const updated={current_records:[rec('pbi','Analistas económicos','2026','2026-10',3.1)],editions:[],checks:[]};
  ctx.fetch=async(url,opts)=>{actions.push([url,JSON.parse(opts.body)]);return {ok:true,status:200,json:async()=>({added:27,document:{rows:27,edition:'2026-10'},state:updated})}};
  await a.confirmFile();
  check('confirmation uses exact token',actions.at(-1)[0]==='/api/macro-external/confirm'&&actions.at(-1)[1].token===p.token);
  check('confirmation redirects forecasts',a.getTab()==='pronosticos');
  check('updated data visible',a.getState().current_records[0].edition==='2026-10');
  check('MEF button only forecasts',root.innerHTML.includes('id="mex-update"'));
  check('import success notification',root.innerHTML.includes('Documento confirmado'));
  a.setTab('fuentes');
  ctx.fetch=async()=>({ok:false,status:422,json:async()=>({error:'No se reconoce la tabla del PDF'})});
  await a.previewFile();
  check('failed extraction does not commit',a.getState().current_records[0].edition==='2026-10');
  check('upload failure contextual',a.getImport().stage==='Validación y extracción');
  a.setTab('pronosticos');
  ctx.fetch=async(url,opts)=>{actions.push([url,JSON.parse(opts.body)]);return {ok:true,status:200,json:async()=>({...updated,lastCheck:'2026-11-19T10:00:00Z',updateResult:{new_editions:0,revisions:0,http_events:[]}})}};
  await a.update();
  check('MEF update still independent',actions.at(-1)[0]==='/api/macro-external/update'&&actions.at(-1)[1].scope==='mef');
  // La petición puede fallar después de que el servidor haya guardado.
  // La interfaz comprueba el historial antes de informar un resultado.
  a.setTab('fuentes');a.setPreview({...p,document:{...p.document,hash:'hash-de-prueba'}});
  const aborted=Object.assign(new Error('timeout'),{name:'AbortError'});
  ctx.fetch=async(url)=>url.endsWith('/confirm')?Promise.reject(aborted):({ok:true,status:200,json:async()=>({editions:[{hash:'hash-de-prueba',file:'nota.pdf'}],current_records:updated.current_records})});
  await a.confirmFile();
  check('timeout with committed document verified by state',a.getTab()==='pronosticos'&&root.innerHTML.includes('Documento incorporado'));
  check('timeout restores buttons',!widgets['#mex-preview-confirm'].disabled&&!widgets['#mex-preview-cancel'].disabled);
  a.setTab('fuentes');a.setPreview(p);
  ctx.fetch=async(url)=>url.endsWith('/confirm')?Promise.reject(aborted):({ok:true,status:200,json:async()=>({editions:[],current_records:updated.current_records})});
  await a.confirmFile();
  check('unverified timeout displayed, not false success',a.getImport()?.stage==='Confirmación');
  check('failed request clears saving state',!widgets['#mex-preview-confirm'].disabled&&widgets['#mex-preview-confirm'].textContent==='Confirmar cambios');
  console.log('OK:',count,'frontend assertions');
})().catch(error=>{console.error(error);process.exitCode=1});
