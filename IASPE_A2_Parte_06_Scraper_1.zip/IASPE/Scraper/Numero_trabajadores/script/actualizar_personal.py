from personal_banca import actualizar_personal_banca
from personal_financieras import actualizar_personal_financieras


def actualizar_personal():
    actualizar_personal_banca()
    return actualizar_personal_financieras()


if __name__ == "__main__":
    actualizar_personal()
