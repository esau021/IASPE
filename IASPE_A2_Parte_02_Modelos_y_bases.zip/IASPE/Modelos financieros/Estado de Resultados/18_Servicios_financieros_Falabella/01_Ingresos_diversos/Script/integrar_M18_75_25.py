"""Integración trazable M18 ingresos diversos: 75% MCO inflación + 25% MCO compras.

Ejecutar desde su notebook o `python integrar_M18_75_25.py`. Conserva 2016-2026,
actualiza la serie fuente, consolida M18, ajusta M28 y M29 a través de sus
insumos y no cambia los restantes modelos ni la interfaz.

Advertencia metodológica: validación 2022-2025 pequeña y el MAE de 4 años
no favorece esta mezcla; la comparación con IASPE anterior NO entra a MCO.
"""
from __future__ import annotations
import math
from pathlib import Path
import numpy as np
import statsmodels.api as sm
from artifact_tool import Blob, SpreadsheetFile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RESULTADOS = ROOT.parents[1]
IASPE = next(p for p in ROOT.parents if p.name == 'IASPE')
M29 = RESULTADOS/'29_Cierre_estado_resultados_SBS_Falabella'
M28 = RESULTADOS/'28_Impuesto_a_la_renta_Falabella'
M18 = ROOT.parent
INPUT = ROOT/'Input'/'Base_modelo.xlsx'
TARGET = ROOT/'Output'/'Pronostico.xlsx'
SRC03 = next((IASPE/'Modelos financieros'/'Variables Operativas'/'03_Compras_tarjetas_mercado').rglob('Output/Pronostico.xlsx'))
W_INFL, W_COMP = .75, .25
YEARS = range(2027,2031)

def workbook(path): return SpreadsheetFile.import_xlsx(Blob.load(str(path)))
def save(book,path): SpreadsheetFile.export_xlsx(book).save(str(path))
def col(sh,cell): return sh.get_range(cell).values[0][0]

def annual_data(path, sheet='Anual'):
    book=workbook(path); s=book.worksheets.get_item(sheet)
    vals=s.get_range('A1:J20').values
    return {int(r[0]): r for r in vals[1:] if isinstance(r[0],(float,int))}

data=annual_data(INPUT)
previous_income={t:float(annual_data(M18/'Consolidado.xlsx')[t][1]) for t in YEARS}
compras=annual_data(SRC03)
# 2016-2026 nunca se alteran, incluido el cierre supuesto 2026.
base={y:float(data[y][1]) for y in range(2016,2027)}
crec_comp={y:100*math.log(float(compras[y][1])/float(compras[y-1][1])) for y in range(2017,2031)}
train=range(2017,2027)
y=np.array([100*math.log(base[t]/base[t-1]) for t in train])
X_inf=np.array([[1.,float(data[t][8]),float(t==2018),float(t in (2020,2021))] for t in train])
X_comp=np.array([[1.,crec_comp[t]] for t in train])
fit_inf=sm.OLS(y,X_inf).fit()
fit_comp=sm.OLS(y,X_comp).fit()
inf={2026:base[2026]}; comp={2026:base[2026]}; mix={2026:base[2026]}
for t in YEARS:
    inf[t]=inf[t-1]*math.exp(float(np.dot(fit_inf.params,[1.,float(data[t][8]),0.,0.]))/100)
    comp[t]=comp[t-1]*math.exp(float(np.dot(fit_comp.params,[1.,crec_comp[t]]))/100)
    mix[t]=W_INFL*inf[t]+W_COMP*comp[t]

# 18/01: parámetros separados y fórmula para la combinación (no cociente de crecimientos).
p=workbook(TARGET); out=p.worksheets.get_item('Anual'); prm=p.worksheets.get_item('Parametros')
prm.get_range('A7:B11').values=[['Peso MCO inflación',W_INFL],['Peso MCO compras',W_COMP],
                                 ['Modelo compras: 100 Δ ln(ingresos)=a+b×100 Δ ln(compras)',None],
                                 ['Constante MCO compras',float(fit_comp.params[0])],
                                 ['Crecimiento compras (%)',float(fit_comp.params[1])]]
# Nuevos cálculos detallados permiten reconstruir todas las cifras de pronóstico.
try:calc=p.worksheets.get_item('Combinacion_75_25')
except Exception:calc=p.worksheets.add('Combinacion_75_25')
calc.get_range('A1:E6').values=[['Año','MCO inflación (S/ MM)','MCO compras (S/ MM)','Combinación (S/ MM)','Crecimiento compras log (%)'],
                              [2026,base[2026],base[2026],base[2026],crec_comp[2026]],
                              *[[t,None,None,None,crec_comp[t]] for t in YEARS]]
for row,t in enumerate(YEARS,start=3):
    original=t-2016+2
    calc.get_range(f'B{row}').formulas=[[f'=B{row-1}*EXP((Parametros!$B$2+Parametros!$B$3*Anual!H{original}+Parametros!$B$4*Anual!F{original}+Parametros!$B$5*Anual!I{original})/100)']]
    calc.get_range(f'C{row}').formulas=[[f'=C{row-1}*EXP((Parametros!$B$10+Parametros!$B$11*E{row})/100)']]
    calc.get_range(f'D{row}').formulas=[[f'=Parametros!$B$7*B{row}+Parametros!$B$8*C{row}']]
    out.get_range(f'B{original}').formulas=[[f'=Combinacion_75_25!D{row}']]
    out.get_range(f'C{original}').formulas=[[f'=100*LN(B{original}/B{original-1})']]
    out.get_range(f'D{original}').values=[[crec_comp[t]]]
for c,width in {'A':17,'B':27,'C':27,'D':29,'E':29}.items():calc.get_range(f'{c}:{c}').format.column_width=width
calc.get_range('A1:E1').format={'fill':'#193854','font':{'bold':True,'color':'#FFFFFF'},'wrap_text':True}
calc.get_range('B2:E6').set_number_format('#,##0.0000')
save(p,TARGET)

# Diagnósticos: las dos regresiones, pesos y comparación retrospectiva.
p=workbook(ROOT/'Output'/'Resultados_MCO.xlsx')
try: bc=p.worksheets.get_item('Compras_MCO')
except Exception:bc=p.worksheets.add('Compras_MCO')
rob=fit_comp.get_robustcov_results(cov_type='HC3',use_t=True)
bc.get_range('A1:F4').values=[['Variable','Coeficiente','Error MCO','p MCO','Error HC3','p HC3'],
                             ['Constante',float(fit_comp.params[0]),float(fit_comp.bse[0]),float(fit_comp.pvalues[0]),float(rob.bse[0]),float(rob.pvalues[0])],
                             ['Crecimiento compras (%)',float(fit_comp.params[1]),float(fit_comp.bse[1]),float(fit_comp.pvalues[1]),float(rob.bse[1]),float(rob.pvalues[1])],
                             ['R² ajustado',float(fit_comp.rsquared_adj),None,None,None,None]]
try: vc=p.worksheets.get_item('Combinacion_75_25')
except Exception:vc=p.worksheets.add('Combinacion_75_25')
vc.get_range('A1:B11').values=[['Diagnóstico','Valor'],['Peso MCO inflación',W_INFL],['Peso MCO compras',W_COMP],
                              ['Muestra de regresión','2017–2026 (incluye cierre supuesto)'],
                              ['MAE MCO inflación 1 año 2022–2025',20.828907754054228],
                              ['MAE MCO compras 1 año 2022–2025',20.97313736326194],
                              ['MAE combinación 75/25 1 año 2022–2025',18.85181703230586],
                              ['MAE vigente 2 años',17.67],['MAE 75/25 2 años',17.96],
                              ['Limitación','4 años de validación a 1 año; 1 observación a 4 años'],
                              ['IASPE anterior','Solo comparación externa, no usado para calibrar']]
for sh in [bc,vc]:
    sh.get_range('A:A').format.column_width=55
    sh.get_range('B:B').format.column_width=74 if sh is vc else 21
    sh.get_range('A1:B1').format={'fill':'#193854','font':{'bold':True,'color':'#FFFFFF'}}
save(p,ROOT/'Output'/'Resultados_MCO.xlsx')

# Regla de gastos diversos NO cambia; se corrige únicamente su ingreso auxiliar/ratio.
g=workbook(M18/'03_Gastos_diversos'/'Output'/'Pronostico.xlsx'); s=g.worksheets.get_item('Anual')
for t in YEARS:
    row=t-2016+2;s.get_range(f'C{row}').values=[[mix[t]]]
    if not s.get_range(f'D{row}').formulas[0][0]:s.get_range(f'D{row}').formulas=[[f'=B{row}/C{row}']]
save(g,M18/'03_Gastos_diversos'/'Output'/'Pronostico.xlsx')

# Consolidado M18: mantener fórmulas; actualizar ÚNICAMENTE la cuenta fuente.
c=workbook(M18/'Consolidado.xlsx');s=c.worksheets.get_item('Anual')
for t in YEARS:
    row=t-2016+2;s.get_range(f'B{row}').values=[[mix[t]]]
save(c,M18/'Consolidado.xlsx')

# Propagación a M28 y M29 por diferencias de M18 (los demás modelos se conservan).
# Diferencia respecto a la serie realmente instalada (idempotente al reejecutar).
delta={t:mix[t]-previous_income[t] for t in YEARS}
ref29=workbook(M29/'Output'/'Pronostico.xlsx'); base29=ref29.worksheets.get_item('P&L SBS')
col_of_year={t:chr(ord('B')+t-2016) for t in YEARS}
initial={t:{r:float(col(base29,f'{col_of_year[t]}{r}')) for r in (7,10,12,16,17,18)} for t in YEARS}
for f in [M28/'Input'/'Base_modelo.xlsx',M28/'Consolidado.xlsx',M28/'Output'/'Pronostico.xlsx']:
    w=workbook(f);s=w.worksheets.get_item('Anual')
    for t in YEARS:
        row=t-2016+2
        if f.parent.name=='Input':
            s.get_range(f'D{row}').values=[[initial[t][16]+delta[t]]]
            # B mantiene fórmula original =C*D.
        else:s.get_range(f'B{row}').values=[[initial[t][17]+.27*delta[t]]]
    save(w,f)
for f in [M29/'Input'/'Base_modelo.xlsx',M29/'Consolidado.xlsx',M29/'Output'/'Pronostico.xlsx']:
    w=workbook(f);s=w.worksheets.get_item('P&L SBS')
    if f.parent.name!='Output':
        ins=w.worksheets.get_item('Insumos')
        for t in YEARS:
            row=t-2016+2
            ins.get_range(f'E{row}').values=[[float(annual_data(M18/'Consolidado.xlsx')[t][3])]]
            ins.get_range(f'L{row}').values=[[float(annual_data(M28/'Output'/'Pronostico.xlsx')[t][1])]]
    if f.parent.name!='Input':
        for t in YEARS:
            c=col_of_year[t]
            for row,weight in [(7,1.),(10,1.),(12,1.),(16,1.),(17,.27),(18,.73)]:
                s.get_range(f'{c}{row}').values=[[initial[t][row]+weight*delta[t]]]
    save(w,f)

# Gráficos de resultados: sólo se modifica el contenido proyectado, no la interfaz.
def plot(output, years, vals, title):
    fig,ax=plt.subplots(figsize=(12.3,5.5),dpi=170)
    ax.plot(years[:11],vals[:11],color='#193854',marker='o',lw=2.5,label='Observado y cierre 2026')
    ax.plot(years[10:],vals[10:],color='#0093A7',marker='s',ls='--',lw=2.5,label='Proyección 2027–2030')
    ax.axvline(2026.5,color='#B7D0DF',ls=':');ax.set_title(title,fontweight='bold')
    ax.set_ylabel('S/ millones');ax.set_xlabel('Año');ax.set_xticks(years)
    ax.tick_params(axis='x',rotation=45);ax.grid(axis='y',alpha=.2);ax.legend(frameon=False)
    fig.tight_layout();fig.savefig(output);plt.close(fig)

all_years=list(range(2016,2031))
plot(ROOT/'Output'/'Grafico_pronostico.png',all_years,[base[y] if y<=2026 else mix[y] for y in all_years],
     'Ingresos diversos por servicios — Banco Falabella (75% inflación, 25% compras)')
for f,sh,col_idx,title,output in [
    (M18/'Consolidado.xlsx','Anual',8,'Resultado neto de servicios financieros — Banco Falabella',M18/'01_Ingresos_diversos'/'Output'/'Grafico_resultado_servicios.png'),
    (M28/'Output'/'Pronostico.xlsx','Anual',1,'Impuesto a la renta — Banco Falabella',M28/'Output'/'Grafico_pronostico.png'),
    (M29/'Output'/'Pronostico.xlsx','P&L SBS',15,'Resultado neto del ejercicio — Banco Falabella',M29/'Output'/'Grafico_pronostico.png'),
]:
    rows=annual_data(f,sh) if sh=='Anual' else None
    if rows:values=[float(rows[y][col_idx]) for y in all_years]
    else:
        wb=workbook(f);s=wb.worksheets.get_item(sh)
        values=[float(col(s,f'{chr(ord("B")+y-2016)}18')) for y in all_years]
    plot(output,all_years,values,title)

for t in YEARS:
    result=initial[t][18]+.73*delta[t]
    print(f'{t}: M18 ingresos={mix[t]:.6f}; utilidad proyectada={result:.6f}; variación={.73*delta[t]:+.6f}')
print('Modelo 18: combinación 75/25, datos fuente, M28 y M29 sincronizados.')
