"""Control entre el cálculo dinámico y los libros físicos del IASPE."""
from __future__ import annotations
import math


def verificar_respaldo(models, physical, tolerance=0.0001):
    """Compara cifras y condición de cada año sin escribir en libros originales."""
    mismatches = []
    checks = 0
    indexed = {str(m['id']):m for m in models}
    for model in models:
        mid = str(model['id'])
        # Las aperturas REV/NREV son fichas virtuales calculadas a partir de M16;
        # no existe un libro Output independiente en la raíz del motor.
        if mid in {'16_rev','16_nrev'} and model.get('kind') == 'calculated':
            total={int(r['year']):float(r['value']) for r in
                   indexed.get('16_creditos',{}).get('annual',[])}
            for row in model.get('annual',[]):
                year=int(row['year']); checks+=1
                share=row.get('incomeShare'); amount=row.get('value')
                if year not in total or share is None or amount is None:
                    mismatches.append(f'{mid}/{year}: falta participación o total de ingresos.')
                    continue
                expected=total[year]*(float(share) if mid=='16_rev' else 1.-float(share))
                if not math.isfinite(float(amount)) or abs(float(amount)-expected)>tolerance:
                    mismatches.append(f'{mid}/{year}: apertura no reconcilia con M16.')
            continue
        source = physical.get(mid)
        if source is None:
            mismatches.append(f'{mid}: no existe el modelo de respaldo.')
            continue
        recorded = {int(r['year']): r for r in source.get('annual', [])}
        for row in model.get('annual', []):
            year = int(row['year'])
            if year not in recorded:
                mismatches.append(f'{mid}/{year}: falta el año en el libro de respaldo.')
                continue
            expected = recorded[year]
            checks += 1
            value, stored = float(row['value']), float(expected['value'])
            if not (math.isfinite(value) and math.isfinite(stored)) or abs(value - stored) > tolerance:
                mismatches.append(f'{mid}/{year}: calculado {value:.6f}, Excel {stored:.6f} MM.')
            elif year >= 2026 and row.get('status') != expected.get('status'):
                mismatches.append(f'{mid}/{year}: condición {row.get("status")}, Excel {expected.get("status")}')
        # Las series mensuales pueden cambiar sin alterar el cierre anual.
        monthly_saved = {str(r.get('date'))[:7]: r for r in source.get('monthly', [])}
        for row in model.get('monthly', []):
            period = str(row.get('date'))[:7]
            stored = monthly_saved.get(period)
            if stored is None:
                mismatches.append(f'{mid}/{period}: falta período mensual en el respaldo.')
                continue
            checks += 1
            if abs(float(row['value']) - float(stored['value'])) > tolerance:
                mismatches.append(f'{mid}/{period}: el valor mensual difiere del respaldo.')
            elif period >= '2026-01' and row.get('status') != stored.get('status'):
                mismatches.append(f'{mid}/{period}: condición mensual distinta del respaldo.')
    return {'passed': not mismatches, 'checks': checks,
            'errors': len(mismatches), 'details': mismatches[:40],
            'truncated': len(mismatches) > 40}
