/* IASPE | Mesa comparativa multiescenario. Simulaciones en memoria, nunca publica Excel.
   Los nombres y borradores se guardan solo en este navegador. */
(() => {
  'use strict';
  const YEARS=[2026,2027,2028], DISPLAY_YEARS=[2026,2027,2028,2029,2030], MAX_CASES=8, STORAGE='iaspe_lab_comparador_v3_sbs_fuentecapturas';
  const CATEGORIES=[['base','Base'],['stress','Estrés'],['severe','Estrés severo']];
  const SBS_PROFILES=['sbs_base','sbs_stress','sbs_severe'];
  const profileLabel=id=>({sbs_base:'Base SBS',sbs_stress:'Estrés SBS',sbs_severe:'Estrés Severo SBS'})[id]||'Base IASPE';
  const inputProfile=c=>SBS_PROFILES.includes(c?.profileId)?c.profileId:(c?.kind==='sbs'&&SBS_PROFILES.includes(c.id)?c.id:null);
  const legacyProfile=category=>({base:'sbs_base',stress:'sbs_stress',severe:'sbs_severe'})[category]||'sbs_base';
  const categoryName=key=>CATEGORIES.find(([id])=>id===key)?.[1]||'Base';
  const isCategory=key=>CATEGORIES.some(([id])=>id===key);
  const categorySelect=(value,attr,disabled=false)=>`<select ${attr} aria-label="Categoría del escenario" ${disabled?'disabled':''}>${CATEGORIES.map(([id,label])=>`<option value="${id}" ${id===value?'selected':''}>${label}</option>`).join('')}</select>`;
  const VARIABLES=[
    ['pbi','PBI real','Variación anual, %'],
    ['inflacion','Inflación','Variación anual, %'],
    ['tc_cierre','Tipo de cambio de cierre','S/ por USD'],
    ['tc_promedio','Tipo de cambio promedio','S/ por USD · no conectado directamente'],
    ['desempleo','Desempleo','% anual · Base y Estrés: Banco; Severo: supuesto IASPE'],
    ['tpm','Tasa de política monetaria','% anual']
  ];
  const METRICS=[
    ['16','Ingresos por intereses','Ingresos'],
    ['12','Gastos por intereses','Gastos'],
    ['23','Margen financiero bruto','Margen'],
    ['25','Provisiones para créditos','Riesgos'],
    ['netMargin','Margen financiero neto','Margen'],
    ['18','Servicios financieros netos','Servicios'],
    ['19','Gastos de administración','Gastos'],
    ['beforeTax','Resultado antes de impuestos','Resultado'],
    ['28','Impuesto a la renta','Impuestos'],
    ['29','Utilidad neta','Resultado']
  ];
  // Cada desglose se enlaza con un modelo o componente real del motor.
  // Estas cuentas no constituyen un balance completo; no se suman partidas superpuestas.
  const PNL_ROWS=[
    {id:'16',label:'Ingresos por intereses',group:'Ingresos',children:[['16_creditos','Créditos'],['16_inversiones','Inversiones'],['16_disponible','Disponibilidades'],['16_interbancarios','Interbancarios']]},
    {id:'12',label:'Gastos por intereses',group:'Gastos',children:[['12_obligaciones','Obligaciones con el público'],['12_entidades','Depósitos de entidades financieras'],['12_adeudos','Adeudos'],['12_otras','Otras fuentes']]},
    {id:'23',label:'Margen financiero bruto',group:'Margen',major:true},
    {id:'25',label:'Provisiones para créditos',group:'Riesgos'},
    {id:'netMargin',label:'Margen financiero neto',group:'Margen',major:true},
    {id:'18',label:'Servicios financieros netos',group:'Servicios',children:[['18_diversos','Ingresos diversos'],['18_otros_ing','Otros ingresos'],['18_gastos_div','Gastos diversos'],['18_otros_gastos','Otros gastos'],['18_fsd','Prima FSD']]},
    {id:'19',label:'Gastos de administración',group:'Gastos',children:[['19_personal','Personal'],['19_directorio','Directorio'],['19_terceros','Servicios de terceros'],['19_impuestos','Tributos']]},
    {id:'20',label:'Resultado de operaciones financieras',group:'Resultados',children:[['20_tc','Diferencia de cambio'],['20_derivados','Derivados'],['20_inversiones','Inversiones'],['20_consorcios','Consorcios'],['20_asociadas','Asociadas'],['20_otros','Otros']]},
    {id:'24',label:'Otros ingresos y gastos',group:'Resultados'},
    {id:'26',label:'Depreciación y amortización',group:'Gastos'},
    {id:'27',label:'Valuación y otras provisiones',group:'Gastos'},
    {id:'beforeTax',label:'Resultado antes de impuestos',group:'Resultado',major:true},
    {id:'28',label:'Impuesto a la renta',group:'Impuestos'},
    {id:'29',label:'Resultado neto del ejercicio',group:'Resultado',final:true}
  ];
  const BALANCE_ROWS=[
    {section:'Activo · cuentas modeladas'},
    {id:'17',label:'Disponible',group:'Activo',children:[['17_caja','Caja'],['17_bancos','Bancos y corresponsales'],['17_canje','Canje'],['17_otros','Otros disponibles']]},
    {id:'22',label:'Fondos interbancarios',group:'Activo',children:[['22_interbancarios','Interbancarios']]},
    {id:'21',label:'Inversiones financieras',group:'Activo',children:[['21_venta','Disponibles para la venta'],['21_asociadas','Subsidiarias y asociadas'],['21_otras','Otras inversiones']]},
    {id:'07',label:'Colocaciones brutas - consumo total',group:'Activo',children:[['05','Consumo revolvente'],['06','Consumo no revolvente']]},
    {id:'31',label:'Cuentas por cobrar netas',group:'Activo'},
    {id:'32',label:'Rendimientos por cobrar',group:'Activo'},
    {section:'Pasivo · cuentas modeladas'},
    {id:'10',label:'Obligaciones con el público',group:'Pasivo',children:[['08','Depósitos de ahorro'],['09','Depósitos a plazo'],['10_restringidos','Depósitos restringidos'],['10_otras','Otras obligaciones']]},
    {section:'Información complementaria (fuera de balance)'},
    {id:'30',label:'Líneas de crédito no utilizadas',group:'Contingentes'}
  ];
  const modelSensitivity={pbi:['01','02','03','04','06','08_mn','09_plazo','13','19_terceros','31','48'],desempleo:['48'],inflacion:['03','04','08_mn','09_plazo','11','15'],tpm:['11','13','14','15','16_inversiones','48'],tc_cierre:['08_me'],tc_promedio:[]};
  const COLORS=['#356f5b','#278465','#dd9a4a','#b85b5a','#6576b9','#9277b6','#6d8f8b','#aa876b'];
  const BASE_SCENARIOS=[
    {id:'iaspe',name:'Base IASPE',kind:'iaspe',category:'base',color:COLORS[0],enabled:true},
    {id:'sbs_base',name:'Base SBS',kind:'sbs',category:'base',color:COLORS[1],enabled:true},
    {id:'sbs_stress',name:'Estrés SBS',kind:'sbs',category:'stress',color:COLORS[2],enabled:true},
    {id:'sbs_severe',name:'Estrés Severo SBS',kind:'sbs',category:'severe',color:COLORS[3],enabled:true}
  ];
  // Fuente: las dos capturas proporcionadas el 12/11/2026.
  // Desempleo Estrés Severo es un supuesto IASPE, NO SBS.
  // No contiene años posteriores a 2028 ni estimaciones del TC promedio.
  const SBS_PRESETS={"sbs_base":{"pbi":[2.7,2.3,2.9],"inflacion":[2.8,2.4,2.3],"tc_cierre":[3.5,3.56,3.61],"tpm":[4.5,4.5,4.5],"desempleo":[5.52,5.51,5.51]},"sbs_stress":{"pbi":[1.9,0.4,1.4],"inflacion":[3.2,3.0,2.6],"tc_cierre":[3.6,3.65,3.75],"tpm":[4.3,4.5,4.3],"desempleo":[6.22,5.62,5.51]},"sbs_severe":{"pbi":[0.8,-1.0,1.1],"inflacion":[3.8,4.0,3.2],"tc_cierre":[3.7,3.85,3.95],"tpm":[4.3,4.8,4.5],"desempleo":[6.92,6.25,5.95]}};
  const $=q=>document.querySelector(q), $$=q=>Array.from(document.querySelectorAll(q));
  const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const num=x=>x==null||!Number.isFinite(Number(x))?'—':new Intl.NumberFormat('es-PE',{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(x));
  const signed=x=>x==null||!Number.isFinite(Number(x))?'—':`${x>0?'+':''}${num(x)}`;
  const compact=x=>x==null||!Number.isFinite(Number(x))?'—':new Intl.NumberFormat('es-PE',{maximumFractionDigits:2}).format(Number(x));
  const parse=x=>{let s=String(x??'').trim().replace(/[\s%]/g,'');if(!s)return NaN;return Number(s.includes(',')&&s.includes('.')?(s.lastIndexOf(',')>s.lastIndexOf('.')?s.replace(/\./g,'').replace(',','.'):s.replace(/,/g,'')):s.replace(',','.'));};
  const read=(m,id,y)=>{const row=(m||[]).find(x=>x.id===id)?.annual?.find(r=>Number(r.year)===Number(y));return row?.value==null?null:Number(row.value);};
  const metric=(models,key,y)=>{
    if(key==='netMargin'){let a=read(models,'23',y),b=read(models,'25',y);return a==null||b==null?null:a-b;}
    if(key==='beforeTax'){let a=read(models,'29',y),b=read(models,'28',y);return a==null||b==null?null:a+b;}
    return read(models,key,y);
  };
  const state={cases:null,removedDefaults:[],editor:'sbs_base',draft:null,preview:null,previewError:'',simulating:false,editOpen:false,deleteConfirm:null,year:2028,metric:'29',results:null,working:false,stage:'',error:'',warnings:[],updatedAt:'',dirty:false,view:'resultados',expanded:new Set()};
  const macro=(app,key,y)=>{const ref=app.state.data?.macros?.find(x=>x.id===key)?.values?.[String(y)];return ref==null?null:Number(ref)};
  function defaults(app){
    return BASE_SCENARIOS.map(row=>{
      const obj={...row,profileId:row.kind==='sbs'?row.id:null,values:{}};
      for(const [key] of VARIABLES){obj.values[key]={};for(let i=0;i<YEARS.length;i++){
        const year=YEARS[i],preset=SBS_PRESETS[row.id]?.[key]?.[i];
        // Solo TC promedio se conserva como referencia IASPE sin fuente SBS.
        obj.values[key][year]=row.id==='iaspe'||preset==null?macro(app,key,year):preset;
      }}
      return obj;
    });
  }
  function init(app){
    if(state.cases)return;
    const originals=defaults(app);let saved=null;
    try{saved=JSON.parse(localStorage.getItem(STORAGE)||'null')}catch(_){saved=null}
    const removed=new Set(Array.isArray(saved?.removedDefaults)?saved.removedDefaults.filter(id=>['sbs_base','sbs_stress','sbs_severe'].includes(id)):[]);
    const base=originals.filter(c=>!removed.has(c.id));
    if(saved&&Array.isArray(saved.cases)){
      const byId=new Map(saved.cases.filter(x=>x&&typeof x.id==='string').map(x=>[x.id,x]));
      for(const item of base){const old=byId.get(item.id);if(!old)continue;
        if(typeof old.name==='string'&&old.name.trim())item.name=old.name.trim().slice(0,70);
        if(item.kind!=='iaspe'&&isCategory(old.category))item.category=old.category;
        item.enabled=old.enabled!==false;
        if(item.kind!=='iaspe')for(const [key] of VARIABLES)for(const y of YEARS){const v=old.values?.[key]?.[y];if(v!==undefined&&v!==null&&Number.isFinite(Number(v)))item.values[key][y]=Number(v)}
      }
      for(const old of saved.cases.filter(x=>x?.kind==='custom').slice(0,MAX_CASES-base.length)){
        if(base.some(c=>c.id===old.id))continue;
        const copy=structuredClone(originals.find(x=>x.id==='sbs_base'));
        copy.id=String(old.id).slice(0,64);copy.kind='custom';copy.name=String(old.name||'Simulación').slice(0,70);
        copy.category=isCategory(old.category)?old.category:'base';copy.color=COLORS[base.length]||COLORS[4];copy.enabled=old.enabled!==false;
        copy.profileId=SBS_PROFILES.includes(old.profileId)?old.profileId:(old.profileId===null?null:legacyProfile(copy.category));
        for(const [key] of VARIABLES)for(const y of YEARS){const v=old.values?.[key]?.[y];if(v!=null&&Number.isFinite(Number(v)))copy.values[key][y]=Number(v)}
        base.push(copy);
      }
    }
    state.removedDefaults=[...removed];state.cases=base;
    if(!base.some(c=>c.enabled))base.find(c=>c.id==='iaspe').enabled=true;
    beginDraft(base.some(c=>c.id==='sbs_base')?'sbs_base':'iaspe',!base.some(c=>c.id==='sbs_base'));
    state.editOpen=false;
  }
  function beginDraft(id,clone=false){
    const c=scenario(id)||scenario('iaspe');if(!c)return;
    state.editor=clone?'new':c.id;
    state.draft={sourceId:clone?null:c.id,name:clone?`${c.name} · Variante`:c.name,category:c.category||'base',profileId:inputProfile(c),values:structuredClone(c.values)};
    state.draftOrigin=structuredClone(state.draft);
    state.preview=null;state.previewError='';state.editOpen=true;
  }
  function newDraft(){
    const source=scenario(state.editor)||scenario('iaspe');
    beginDraft(source.id,true);state.draft.name='Nueva simulación';state.draftOrigin=structuredClone(state.draft);
  }
  function discardDraft(){
    if(state.draftOrigin){state.draft=structuredClone(state.draftOrigin);state.editor=state.draft.sourceId||'new';}
    else beginDraft('iaspe',true);
    state.preview=null;state.previewError='';
  }
  function draftChanged(){const d=state.draft;if(!d)return false;const c=d.sourceId&&scenario(d.sourceId);
    return !c||d.name!==c.name||d.category!==c.category||d.profileId!==inputProfile(c)||JSON.stringify(d.values)!==JSON.stringify(c.values);
  }
  function persist(){try{localStorage.setItem(STORAGE,JSON.stringify({cases:state.cases,removedDefaults:state.removedDefaults}))}catch(_){/* almacenamiento opcional */}}
  const active=()=>state.cases.filter(c=>c.enabled);
  const scenario=id=>state.cases.find(x=>x.id===id);
  const refId=()=>active().some(x=>x.id==='iaspe')?'iaspe':active()[0]?.id;
  function flagDirty(){state.dirty=true;state.results=null;state.error='';persist()}
  function macroPayload(app,c){
    const changes={};for(const [key] of VARIABLES)for(const year of YEARS){
      const val=Number(c.values[key]?.[year]),base=macro(app,key,year);
      if(!Number.isFinite(val))throw Error(`Falta un valor válido de ${key} para ${c.name} en ${year}.`);
      if(base==null)throw Error(`No existe una base macroeconómica ${key} para ${year}.`);
      if(Math.abs(val-base)>1e-9)(changes[key]||={})[year]=val;
    }return changes;
  }
  function pack(models){return {models:models||[]};}
  function result(id,key,year){const r=state.results?.[id],c=scenario(id);if(c&&c.kind!=='iaspe'&&Number(year)>2028)return null;return r?metric(r.models,key,year):null;}
  function deltas(a,b){return a==null||b==null?null:a-b;}
  function pct(a,b){return a==null||b==null||Math.abs(b)<1e-10?null:100*(a-b)/Math.abs(b);}
  function statusPanel(){
    if(state.working)return `<span class="mlab-progress-dot"></span>${esc(state.stage||'Calculando escenarios…')}`;
    if(state.error)return `<span class="mlab-error-dot"></span>${esc(state.error)}`;
    if(state.preview)return 'Vista previa calculada · pendiente de confirmar';
    if(state.dirty)return 'Cambios pendientes de comparación';
    return state.updatedAt?`Última comparación · ${esc(state.updatedAt)}`:'Escenarios seleccionados';
  }
  function scenarioCards(){
    const busy=state.working||state.simulating;
    return `<div class="mlab-scenario-grid">${state.cases.map(c=>{
      const asking=state.deleteConfirm===c.id;
      return `<article class="mlab-case ${state.editor===c.id?'selected':''} ${!c.enabled?'muted':''}" style="--case:${c.color}">
        <div class="mlab-case-head"><label class="mlab-case-check"><input data-case-visible="${esc(c.id)}" type="checkbox" ${c.enabled?'checked':''} ${busy?'disabled':''} aria-label="Mostrar ${esc(c.name)}"><span></span></label><span class="mlab-case-origin">${c.kind==='iaspe'?'IASPE · referencia':c.kind==='sbs'?'SBS · datos recibidos':'Simulación propia'}</span></div>
        <input class="mlab-case-name" data-case-name="${esc(c.id)}" maxlength="70" value="${esc(c.name)}" ${busy?'disabled':''} aria-label="Nombre del escenario" title="Editar nombre">
        <div class="mlab-case-category"><span>Categoría</span>${categorySelect(c.category,`data-case-category="${esc(c.id)}"`,c.kind==='iaspe'||busy)}</div>
        ${c.kind==='custom'?`<small class="mlab-input-origin">Provisiones: ${esc(profileLabel(inputProfile(c)))}</small>`:''}
        ${asking?`<div class="mlab-confirm-delete"><strong>¿Quitar este escenario?</strong><div><button type="button" data-case-remove="${esc(c.id)}">Sí, quitar</button><button type="button" data-case-cancel="${esc(c.id)}">Cancelar</button></div></div>`:
        `<div class="mlab-case-actions"><button type="button" data-case-edit="${esc(c.id)}" ${c.kind==='iaspe'||busy?'disabled':''}>Editar</button><button type="button" data-case-clone="${esc(c.id)}" ${state.cases.length>=MAX_CASES||busy?'disabled':''}>Crear variante</button>${c.kind!=='iaspe'?`<button type="button" class="mlab-delete" data-case-delete="${esc(c.id)}" ${busy?'disabled':''}>Quitar</button>`:''}</div>`}
      </article>`}).join('')}</div>`;
  }
  function previewChecks(app,p){
    const original=app.state.data?.baseline||app.state.data?.models||[];
    const notices=[];
    for(const y of YEARS){
      const provis=metric(p.models,'25',y),baseProvis=metric(original,'25',y);
      if([provis,baseProvis].every(Number.isFinite)&&Math.abs(provis-baseProvis)<.01 && y===2028)
        notices.push(`Provisiones 2028: S/ ${num(provis)} MM, sin variación frente a Base IASPE. Los datos de Riesgos se mantienen.`);
      const profit=metric(p.models,'29',y),baseProfit=metric(original,'29',y);
      if([profit,baseProfit].every(Number.isFinite)&&Math.abs(profit-baseProfit)<.01){
        const changed=VARIABLES.some(([key])=>Math.abs(Number(p.values[key]?.[y])-Number(macro(app,key,y)))>1e-7);
        if(changed)notices.push(`Utilidad ${y}: S/ ${num(profit)} MM, sin variación frente a Base IASPE a pesar de cambiar supuestos de ese año. Revisar rezagos y tratamiento del cierre provisional.`);
      }
    }
    return notices.length?`<div class="mlab-preview-checks">${notices.slice(0,2).map(msg=>`<p>${esc(msg)}</p>`).join('')}</div>`:'';
  }
  function previewPanel(app){
    const p=state.preview;if(!p)return '';
    const base=app.state.data?.baseline||app.state.data?.models||[];
    const source=p.sourceId?scenario(p.sourceId):null;
    const summary=YEARS.map(y=>{
      const net=metric(p.models,'29',y),reference=metric(base,'29',y),diff=deltas(net,reference);
      return `<div class="mlab-preview-kpi"><small>${y} · Utilidad neta</small><strong>S/ ${num(net)} MM</strong><span>${diff==null?'Sin referencia':`${signed(diff)} MM respecto a IASPE`}</span></div>`;
    }).join('');
    const lines=[['16','Ingresos por intereses'],['12','Gastos por intereses'],['23','Margen financiero bruto'],['25','Provisiones para créditos'],['netMargin','Margen financiero neto'],['18','Servicios financieros netos'],['19','Gastos de administración'],['beforeTax','Resultado antes de impuestos'],['29','Utilidad neta']];
    const rows=lines.map(([id,label])=>`<tr class="${id==='29'?'mlab-preview-profit':''}"><th>${esc(label)}</th>${YEARS.map(y=>{
      const v=metric(p.models,id,y),b=metric(base,id,y),delta=deltas(v,b);
      return `<td><strong>${num(v)}</strong><small>${delta==null?'—':`${signed(delta)} vs. IASPE`}</small></td>`;
    }).join('')}</tr>`).join('');
    return `<section class="mlab-preview" aria-live="polite"><div class="mlab-preview-heading"><div><strong>Vista previa · ${esc(p.name)}</strong><p>${categoryName(p.category)} · Valores en S/ millones · No guardada</p></div><span class="mlab-ready">Sin incorporar</span></div>
      <div class="mlab-preview-kpis">${summary}</div>
      <div class="mlab-preview-table-head"><h4>Principales resultados proyectados</h4><span>Importe y variación frente a la Base IASPE</span></div>
      <div class="sim-table-scroll"><table class="mlab-preview-table mlab-preview-accounts"><thead><tr><th>Cuenta · S/ MM</th>${YEARS.map(y=>`<th>${y}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div>
      ${p.warnings?.length?`<p class="mlab-preview-warning">Motor: ${esc(p.warnings.slice(0,2).join(' · '))}</p>`:''}
      <div class="mlab-preview-actions"><button class="button ghost" type="button" id="mlab-discard">Descartar prueba</button><button class="button primary" type="button" id="mlab-commit" ${state.working?'disabled':''}>${source?'Aplicar cambios':'Incorporar escenario'}</button></div></section>`;
  }
  function editPanel(app){
    const c=state.draft||{sourceId:null,name:'Nueva simulación',category:'base',values:{}};
    const locked=c.sourceId==='iaspe',busy=state.simulating||state.working;
    const inputRows=VARIABLES.map(([key,title,unit])=>`<tr><th><strong>${esc(title)}</strong><small>${esc(unit)}</small></th>${YEARS.map(y=>`<td><input type="text" inputmode="decimal" value="${esc(compact(c.values[key]?.[y]))}" data-mlab-value="${esc(key)}" data-mlab-year="${y}" aria-label="${esc(title)} ${y}" ${locked||busy?'disabled':''}></td>`).join('')}</tr>`).join('');
    return `<section class="mlab-edit"><div class="mlab-edit-heading"><div><h3>${c.sourceId?'Editar escenario':'Nueva simulación'}</h3></div><label class="mlab-source-select">Editar <select id="mlab-editor" aria-label="Seleccionar escenario para editar" ${busy?'disabled':''}>${state.cases.filter(x=>x.kind!=='iaspe').map(x=>`<option value="${esc(x.id)}" ${state.editor===x.id?'selected':''}>${esc(x.name)}</option>`).join('')}<option value="new" ${state.editor==='new'?'selected':''}>Nueva simulación</option></select></label></div>
    <div class="mlab-draft-fields"><label><span>Nombre del escenario</span><input class="mlab-draft-name" id="mlab-draft-name" type="text" maxlength="70" value="${esc(c.name)}" ${busy?'disabled':''}></label>
    <label><span>Categoría (etiqueta)</span>${categorySelect(c.category,'id="mlab-draft-category"',busy)}</label></div>
    <p class="mlab-source-note">Provisiones exógenas: ${esc(profileLabel(c.profileId))}. Se conserva el perfil del escenario de origen al crear variantes; cambiar la categoría no modifica estos inputs.</p>
    <div class="sim-table-scroll"><table class="mlab-input-table"><thead><tr><th>Variable macroeconómica</th>${YEARS.map(y=>`<th>${y}</th>`).join('')}</tr></thead><tbody>${inputRows}</tbody></table></div>
    <div class="mlab-simulate-actions"><span>Modificar supuestos no cambia coeficientes ni archivos originales.</span><button type="button" class="button ghost" id="mlab-discard-draft" ${busy?'disabled':''}>Restablecer edición</button><button type="button" class="button primary" id="mlab-simulate" ${locked||busy?'disabled':''}>${state.simulating?'Calculando vista previa…':'Calcular vista previa'}</button></div>
    ${state.previewError?`<p class="mlab-preview-warning" role="alert">${esc(state.previewError)}</p>`:''}${previewPanel(app)}</section>`;
  }
  function statsCards(){
    const selected=active();const y=state.year;
    if(!state.results)return `<div class="mlab-placeholder"><strong>Comparador listo.</strong><span>Ejecuta la comparación para obtener utilidades, márgenes y brechas de los escenarios a partir del motor IASPE.</span></div>`;
    const baseline=result(refId(),'29',y);
    return `<div class="mlab-main-kpis">${selected.map(c=>{
      const val=result(c.id,'29',y),diff=deltas(val,baseline);
      return `<article class="mlab-main-kpi" style="--case:${c.color}"><span>${esc(c.name)}</span><strong>${val==null?'—':`S/ ${num(val)}`}</strong><small>${c.id===refId()?'Escenario de comparación':diff==null?'Sin información':`${signed(diff)} MM · ${signed(pct(val,baseline))}% vs. referencia`}</small></article>`;
    }).join('')}</div>`;
  }
  function graph(){
    if(!state.results)return '';
    const cs=active().filter(x=>state.results?.[x.id]);
    const chartYears=cs.some(c=>c.kind==='iaspe')?DISPLAY_YEARS:YEARS;
    const series=cs.map(c=>chartYears.map(y=>c.kind==='iaspe'||y<=2028?result(c.id,state.metric,y):null));
    const nums=series.flat().filter(Number.isFinite);
    if(!nums.length)return '<p>No hay series para este indicador.</p>';
    let low=Math.min(...nums),high=Math.max(...nums),spread=high-low;
    if(spread<1e-8){spread=Math.max(1,Math.abs(low)*.1);low-=spread/2;high+=spread/2;}
    low-=spread*.17;high+=spread*.17;
    const W=900,H=300,L=87,R=23,T=23,B=46;
    const x=i=>L+(W-L-R)*i/Math.max(1,chartYears.length-1), yy=v=>T+(high-v)*(H-T-B)/(high-low);
    const grid=Array.from({length:5},(_,i)=>{const v=low+(high-low)*i/4;return `<line x1="${L}" x2="${W-R}" y1="${yy(v)}" y2="${yy(v)}" stroke="#e9efe9"/><text x="${L-10}" y="${yy(v)+4}" text-anchor="end" class="mlab-axis">${num(v)}</text>`}).join('');
    const paths=cs.map((c,i)=>{
      const vals=series[i],points=vals.map((v,j)=>Number.isFinite(v)?[j,v]:null).filter(Boolean);
      const path=points.map(([j,v],idx)=>`${idx?'L':'M'} ${x(j)} ${yy(v)}`).join(' ');
      return `<path d="${path}" fill="none" stroke="${c.color}" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round" ${c.kind==='iaspe'?'stroke-dasharray="9 5"':''}/>${points.map(([j,v])=>`<g class="mlab-chart-point" data-mlab-graph-point="${esc(c.id)}" data-mlab-graph-year="${chartYears[j]}" tabindex="0" role="img" aria-label="${esc(c.name)} ${chartYears[j]}: S/ ${num(v)} millones"><circle cx="${x(j)}" cy="${yy(v)}" r="12" fill="transparent"/><circle class="mlab-point-marker" cx="${x(j)}" cy="${yy(v)}" r="4.5" fill="${c.color}" stroke="white" stroke-width="2"/><title>${esc(c.name)}, ${chartYears[j]}: S/ ${num(v)} MM</title></g>`).join('')}`;
    }).join('');
    return `<div class="mlab-chart-container"><svg class="mlab-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución anual comparada">${grid}${chartYears.map((y,j)=>`<text x="${x(j)}" y="${H-12}" text-anchor="middle" class="mlab-axis">${y}</text>`).join('')}${paths}</svg><div class="mlab-chart-tooltip" id="mlab-chart-tooltip" role="status" hidden></div></div>
      <div class="mlab-chart-legend">${cs.map(c=>`<span><i style="background:${c.color}"></i>${esc(c.name)}${c.kind==='iaspe'?' · 2030':''}</span>`).join('')}</div>`;
  }
  function bars(){
    if(!state.results)return '';
    const cs=active(),values=cs.map(c=>result(c.id,'29',state.year)),max=Math.max(1,...values.filter(Number.isFinite).map(Math.abs));
    return `<div class="mlab-bars">${cs.map((c,i)=>`<div class="mlab-bar-row"><span title="${esc(c.name)}">${esc(c.name)}</span><div class="mlab-bar-track"><div style="width:${Number.isFinite(values[i])?Math.max(0,Math.abs(values[i])/max*100):0}%;background:${c.color}"></div></div><strong>${num(values[i])}</strong></div>`).join('')}</div>`;
  }
  function currentRows(){return state.view==='balance'?BALANCE_ROWS:PNL_ROWS}
  function tableBody(){
    const cs=active(),base=refId();
    const renderRow=(row,child=false)=>{
      if(row.section)return `<tr class="mlab-section-row"><th colspan="${cs.length+2}">${esc(row.section)}</th></tr>`;
      const key=row.id,b=result(base,key,state.year),vals=cs.map(c=>result(c.id,key,state.year));
      const deltas=vals.filter(v=>v!=null&&b!=null).map(v=>Math.abs(v-b));
      const d=vals.filter(Number.isFinite).length>=2&&deltas.length?Math.max(...deltas):null;
      const expanded=state.expanded.has(key),hasChildren=!!row.children?.length;
      const label=`<span class="mlab-row-label">${hasChildren?`<button class="mlab-row-toggle" type="button" data-mlab-expand="${esc(key)}" aria-expanded="${expanded}" aria-label="${expanded?'Contraer':'Desglosar'} ${esc(row.label)}">${expanded?'▾':'▸'}</button>`:'<span class="mlab-row-spacer"></span>'}${hasChildren?`<button type="button" class="mlab-row-name" data-mlab-expand="${esc(key)}" aria-expanded="${expanded}">${esc(row.label)}</button>`:`<span>${esc(row.label)}</span>`}${!child&&key!=='netMargin'&&key!=='beforeTax'?`<button class="mlab-model-link" type="button" data-mlab-model="${esc(key)}" title="Abrir la ficha del modelo ${esc(key)}" aria-label="Ver especificación de ${esc(row.label)}">↗</button>`:''}</span>`;
      const cls=[row.major?'mlab-major':'',row.final?'mlab-final':'',child?'mlab-detail-row':''].join(' ');
      let markup=`<tr class="${cls}"><th>${label}</th>${vals.map(v=>`<td>${num(v)}</td>`).join('')}<td>${num(d)}</td></tr>`;
      if(hasChildren&&expanded)markup+=row.children.map(([id,label])=>renderRow({id,label},true)).join('');
      return markup;
    };
    const title=state.view==='balance'?'Situación financiera · cuentas modeladas':'Estado de resultados';
    return `<div class="sim-table-scroll"><table class="mlab-pnl"><thead><tr><th>${title} · S/ MM</th>${cs.map(c=>`<th><span style="border-top:3px solid ${c.color};padding-top:6px">${esc(c.name)}</span></th>`).join('')}<th>Brecha máx.¹</th></tr></thead><tbody>${currentRows().map(r=>renderRow(r)).join('')}</tbody></table></div>`;
  }
  function macroChanges(app){
    const changed=new Set();for(const c of active())if(c.kind!=='iaspe')for(const [key] of VARIABLES)for(const y of YEARS){const b=macro(app,key,y),v=c.values[key]?.[y];if(b!=null&&v!=null&&Math.abs(v-b)>1e-7)changed.add(key)}return changed;
  }
  function content(app){
    if(!state.results)return '';
    if(!active().some(c=>c.kind==='iaspe')&&state.year>2028)state.year=2028;
    const availableYears=active().some(c=>c.kind==='iaspe')?DISPLAY_YEARS:YEARS;
    const chartChoices=state.view==='balance'?[['07','Colocaciones brutas - consumo'],['17','Disponible'],['21','Inversiones'],['10','Obligaciones con el público'],['31','Cuentas por cobrar']]:[['29','Utilidad neta'],['23','Margen financiero bruto'],['16','Ingresos por intereses'],['19','Gastos administrativos'],['25','Provisiones']];
    if(!chartChoices.some(x=>x[0]===state.metric))state.metric=chartChoices[0][0];
    return `<div class="mlab-results"><div class="mlab-result-head"><div><span class="sim-eyebrow">02 / COMPARACIÓN FINANCIERA</span><h3>Resultados por escenario</h3></div><div class="mlab-filters">
      <label>Año <select id="mlab-year">${availableYears.map(y=>`<option value="${y}" ${state.year===y?'selected':''}>${y}</option>`).join('')}</select></label></div></div>
      <div class="mlab-finance-tabs" role="tablist" aria-label="Estado financiero"><button role="tab" type="button" data-mlab-view="resultados" aria-selected="${state.view==='resultados'}" class="${state.view==='resultados'?'selected':''}">Estado de resultados</button><button role="tab" type="button" data-mlab-view="balance" aria-selected="${state.view==='balance'}" class="${state.view==='balance'?'selected':''}">Situación financiera</button></div>
      <section class="mlab-inner mlab-chart-wide"><div class="mlab-graph-head"><h4>Evolución anual · S/ millones</h4><select id="mlab-metric" aria-label="Cuenta del gráfico">${chartChoices.map(([k,l])=>`<option value="${k}" ${state.metric===k?'selected':''}>${l}</option>`).join('')}</select></div>${graph()}</section>
      <article class="mlab-inner mlab-table-section"><div class="mlab-table-head"><div><h4>${state.view==='balance'?'Situación financiera':'Estado de resultados'}</h4><p>${state.view==='balance'?'Cuentas proyectadas por IASPE.':'Selecciona ▸ para consultar subcuentas.'}</p></div><div class="mlab-table-actions"><label>Año <select id="mlab-table-year">${availableYears.map(y=>`<option value="${y}" ${state.year===y?'selected':''}>${y}</option>`).join('')}</select></label><button class="button ghost" type="button" id="mlab-export">Exportar CSV</button></div></div>${tableBody()}<p class="mlab-table-caption">¹ Mayor diferencia absoluta frente a ${esc(scenario(refId())?.name||'la referencia visible')}, en S/ millones. Los escenarios SBS disponen de supuestos hasta 2028.</p></article>
      </div>`;
  }
  function html(app){init(app);
    return `<section class="sim-panel mlab-main"><div class="mlab-header"><div><span class="sim-eyebrow">01 / MESA COMPARATIVA</span><h2>Comparador de escenarios</h2></div><div class="mlab-header-meta"><span class="mlab-cases">${active().length} de ${state.cases.length} visibles</span></div></div>
      
      <div class="mlab-management"><h3>Escenarios</h3><div class="mlab-management-actions"><button class="button secondary" type="button" id="mlab-add" ${state.cases.length>=MAX_CASES||state.working||state.simulating?'disabled':''}>+ Nuevo escenario</button><button class="button primary" type="button" id="mlab-run" ${state.working||state.simulating?'disabled':''}>${state.working?'Comparando…':'Comparar escenarios'}</button></div></div>
      ${scenarioCards()}<div class="mlab-toolbar"><div class="mlab-status" role="status">${statusPanel()}</div><div class="mlab-toolbar-actions"><button class="button ghost" type="button" id="mlab-reset" ${state.working||state.simulating?'disabled':''}>Restaurar escenarios originales</button></div></div>
      <details class="mlab-editor-wrap" id="mlab-editor-wrap" ${state.editOpen?'open':''}><summary>Editar o simular escenario</summary>${editPanel(app)}</details>${content(app)}
      </section>`;
  }
  async function calculate(app){
    if(state.working||state.simulating)return;
    const cs=state.cases;if(active().length<1){state.error='Selecciona al menos un escenario.';render(app);return;}
    state.working=true;state.results=null;state.error='';state.warnings=[];state.dirty=false;
    const next={};render(app);
    try{
      for(const c of cs){state.stage=`Calculando ${c.name}…`;render(app);
        if(c.kind==='iaspe'){next[c.id]=pack(app.state.data?.baseline||app.state.data?.models);continue;}
        const stressProfile=inputProfile(c);
        const answer=await app.api('/api/calculate',{horizon:2028,changes:macroPayload(app,c),stress_profile:stressProfile});
        if(!Array.isArray(answer.models)||!answer.models.some(m=>m.id==='29'))throw Error(`El motor no devolvió el P&L para ${c.name}.`);
        if(answer.warnings?.length)state.warnings.push(...answer.warnings.map(w=>`${c.name}: ${w}`));
        next[c.id]=pack(answer.models);
      }
      state.results=next;state.updatedAt=new Date().toLocaleTimeString('es-PE',{hour:'2-digit',minute:'2-digit'});
    }catch(e){state.results=null;state.error=e?.message||'No se pudo completar la comparación';}
    finally{state.working=false;state.stage='';render(app);}
  }
  async function simulate(app){
    if(state.simulating||state.working||!state.draft)return;
    const snapshot=structuredClone(state.draft);
    if($$('[data-mlab-value]').some(el=>!Number.isFinite(parse(el.value)))){state.previewError='Completa los supuestos con valores numéricos válidos.';render(app);return;}
    if(!snapshot.name.trim()){state.previewError='Asigna un nombre a la simulación.';render(app);return;}
    state.simulating=true;state.preview=null;state.previewError='';state.editOpen=true;render(app);
    try{
      const stressProfile=SBS_PROFILES.includes(snapshot.profileId)?snapshot.profileId:null;
      const reply=await app.api('/api/calculate',{horizon:2028,changes:macroPayload(app,snapshot),stress_profile:stressProfile});
      if(!Array.isArray(reply.models)||!reply.models.some(x=>x.id==='29'))throw Error('El motor no devolvió el resultado del ejercicio.');
      state.preview={...snapshot,models:reply.models,warnings:reply.warnings||[]};
    }catch(e){state.previewError=e?.message||'No se pudo simular este escenario.';}
    finally{state.simulating=false;render(app);}
  }
  async function addPreview(app){
    const p=state.preview;if(!p||state.working||state.simulating)return;
    const existing=p.sourceId&&scenario(p.sourceId);
    if(!existing&&state.cases.length>=MAX_CASES){state.previewError='El comparador admite hasta ocho escenarios.';render(app);return;}
    let target=existing;
    if(existing){existing.name=p.name.trim();existing.category=p.category;existing.profileId=existing.kind==='sbs'?existing.id:p.profileId;existing.values=structuredClone(p.values);existing.enabled=true;}
    else{
      const id='custom_'+Date.now().toString(36)+'_'+state.cases.length;
      target={id,kind:'custom',category:p.category,profileId:p.profileId,name:p.name.trim(),color:COLORS[state.cases.length]||COLORS[4],enabled:true,values:structuredClone(p.values)};
      state.cases.push(target);
    }
    state.editor=target.id;state.draft={sourceId:target.id,name:target.name,category:target.category,profileId:inputProfile(target),values:structuredClone(target.values)};
    state.draftOrigin=structuredClone(state.draft);
    state.preview=null;state.previewError='';state.editOpen=false;persist();
    if(state.results){state.results[target.id]=pack(p.models);state.updatedAt=new Date().toLocaleTimeString('es-PE',{hour:'2-digit',minute:'2-digit'});state.dirty=false;render(app);}
    else{await calculate(app);}
    if(!state.error)app.toast(existing?'Escenario actualizado.':'Escenario incorporado.');
  }
  function exportCSV(){
    const cs=active();if(!state.results)return;
    const rows=[['Año','Cuenta',...cs.map(c=>c.name),'Referencia']];
    const specs=currentRows().filter(r=>r.id);
    for(const y of DISPLAY_YEARS)for(const row of specs){rows.push([y,row.label,...cs.map(c=>result(c.id,row.id,y)),scenario(refId())?.name||'']);
      if(state.expanded.has(row.id))for(const [id,label] of row.children||[])rows.push([y,'  '+label,...cs.map(c=>result(c.id,id,y)),scenario(refId())?.name||'']);
    }
    const csv='\ufeff'+rows.map(row=>row.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(';')).join('\r\n');
    const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),link=document.createElement('a');link.href=url;link.download=`IASPE_${state.view}_${state.year}.csv`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function bind(app){
    const busy=()=>state.working||state.simulating;
    const openEditor=()=>{state.editOpen=true;render(app);$('#mlab-editor-wrap')?.scrollIntoView({behavior:'smooth',block:'nearest'});};
    $$('[data-case-name]').forEach(el=>el.addEventListener('change',()=>{if(busy())return;const c=scenario(el.dataset.caseName);if(!c)return;const name=el.value.trim().slice(0,70);if(!name){el.value=c.name;return;}c.name=name;
      if(state.draft?.sourceId===c.id)state.draft.name=name;if(state.preview?.sourceId===c.id)state.preview.name=name;persist();render(app);
    }));
    $$('[data-case-category]').forEach(el=>el.addEventListener('change',()=>{if(busy())return;const c=scenario(el.dataset.caseCategory);if(!c||c.kind==='iaspe'||!isCategory(el.value))return;c.category=el.value;
      if(state.draft?.sourceId===c.id)state.draft.category=el.value;if(state.preview?.sourceId===c.id)state.preview.category=el.value;persist();render(app);
    }));
    $$('[data-case-visible]').forEach(el=>el.addEventListener('change',()=>{if(busy())return;const c=scenario(el.dataset.caseVisible);if(!c)return;if(!el.checked&&active().length<=1){app.toast('Debe haber al menos un escenario visible.');el.checked=true;return;}c.enabled=el.checked;persist();render(app)}));
    $$('[data-case-edit]').forEach(el=>el.addEventListener('click',()=>{if(busy())return;beginDraft(el.dataset.caseEdit);openEditor();}));
    $$('[data-case-clone]').forEach(el=>el.addEventListener('click',()=>{if(busy()||state.cases.length>=MAX_CASES)return;beginDraft(el.dataset.caseClone,true);openEditor();}));
    $$('[data-case-delete]').forEach(el=>el.addEventListener('click',()=>{if(busy())return;state.deleteConfirm=el.dataset.caseDelete;render(app);}));
    $$('[data-case-cancel]').forEach(el=>el.addEventListener('click',()=>{state.deleteConfirm=null;render(app);}));
    $$('[data-case-remove]').forEach(el=>el.addEventListener('click',()=>{
      if(busy())return;const id=el.dataset.caseRemove,c=scenario(id);if(!c||c.kind==='iaspe')return;
      state.cases=state.cases.filter(x=>x.id!==id);
      if(c.kind==='sbs'&&!state.removedDefaults.includes(id))state.removedDefaults.push(id);
      if(state.draft?.sourceId===id||state.preview?.sourceId===id){beginDraft('iaspe',true);state.editOpen=false;}
      if(state.results)delete state.results[id];state.deleteConfirm=null;
      if(!active().length){scenario('iaspe').enabled=true;}
      persist();render(app);
    }));
    $('#mlab-editor-wrap')?.addEventListener('toggle',e=>{state.editOpen=e.target.open;});
    $('#mlab-editor')?.addEventListener('change',e=>{if(busy())return;if(e.target.value==='new')newDraft();else beginDraft(e.target.value);openEditor();});
    $('#mlab-draft-name')?.addEventListener('input',e=>{if(!state.draft)return;state.draft.name=e.target.value.slice(0,70);state.preview=null;state.previewError='';$('.mlab-preview')?.remove();});
    $('#mlab-draft-category')?.addEventListener('change',e=>{if(!state.draft||!isCategory(e.target.value))return;state.draft.category=e.target.value;state.preview=null;state.previewError='';$('.mlab-preview')?.remove();});
    $$('[data-mlab-value]').forEach(el=>el.addEventListener('input',()=>{
      const d=state.draft;if(!d||d.sourceId==='iaspe')return;const val=parse(el.value);el.classList.toggle('invalid',!Number.isFinite(val));
      if(Number.isFinite(val)){d.values[el.dataset.mlabValue][el.dataset.mlabYear]=val;}
      state.preview=null;state.previewError='';$('.mlab-preview')?.remove();
    }));
    $('#mlab-add')?.addEventListener('click',()=>{if(busy()||state.cases.length>=MAX_CASES)return;newDraft();openEditor();});
    $('#mlab-simulate')?.addEventListener('click',()=>simulate(app));
    $('#mlab-commit')?.addEventListener('click',()=>addPreview(app));
    $('#mlab-discard')?.addEventListener('click',()=>{discardDraft();state.editOpen=false;render(app);});
    $('#mlab-discard-draft')?.addEventListener('click',()=>{discardDraft();openEditor();});
    $('#mlab-run')?.addEventListener('click',()=>calculate(app));
    $('#mlab-reset')?.addEventListener('click',()=>{
      state.cases=defaults(app);state.removedDefaults=[];state.deleteConfirm=null;beginDraft('sbs_base');state.editOpen=false;
      state.results=null;state.error='';state.updatedAt='';state.dirty=false;persist();render(app);
    });
    $$('[data-mlab-view]').forEach(el=>el.addEventListener('click',()=>{state.view=el.dataset.mlabView;state.metric=state.view==='balance'?'07':'29';render(app)}));
    $$('[data-mlab-expand]').forEach(el=>el.addEventListener('click',()=>{const id=el.dataset.mlabExpand;state.expanded.has(id)?state.expanded.delete(id):state.expanded.add(id);render(app)}));
    $$('[data-mlab-model]').forEach(el=>el.addEventListener('click',()=>window.IASPESpec?.open(app,el.dataset.mlabModel)));
    $('#mlab-year')?.addEventListener('change',e=>{state.year=Number(e.target.value);render(app)});
    $('#mlab-table-year')?.addEventListener('change',e=>{state.year=Number(e.target.value);render(app)});
    $$('[data-mlab-graph-point]').forEach(point=>{
      const tooltip=$('#mlab-chart-tooltip'), wrap=point.closest('.mlab-chart-container');
      const show=()=>{const c=scenario(point.dataset.mlabGraphPoint),y=Number(point.dataset.mlabGraphYear);
        if(!tooltip||!c)return;tooltip.textContent=`${c.name} · ${y}: S/ ${num(result(c.id,state.metric,y))} millones`;tooltip.hidden=false;
        const box=point.getBoundingClientRect(),area=wrap.getBoundingClientRect();
        tooltip.style.left=`${Math.max(0,Math.min(area.width-240,box.left-area.left-20))}px`;
        tooltip.style.top=`${Math.max(0,box.top-area.top-47)}px`;
      };
      point.addEventListener('pointerenter',show);point.addEventListener('pointermove',show);point.addEventListener('focus',show);
      const hide=()=>{if(tooltip)tooltip.hidden=true;};point.addEventListener('pointerleave',hide);point.addEventListener('blur',hide);
    });
    $('#mlab-metric')?.addEventListener('change',e=>{state.metric=e.target.value;render(app)});
    $('#mlab-export')?.addEventListener('click',exportCSV);
  }
  function render(app){if(location.hash.startsWith('#laboratorio')){const workspace=$('#workspace');if(!workspace)return;workspace.innerHTML=window.IASPELaboratorio.html(app);window.IASPELaboratorio.bind(app);}}
  window.IASPEMulti={html,bind,calculate,simulate,addPreview,beginDraft,state,defaults,metric};
})();
