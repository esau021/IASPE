"""Stock SBS mensual y cierre residual M47 se conservan por separado."""
from pathlib import Path
import gzip
import json
import sys
import tempfile
import unittest
from openpyxl import Workbook

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import persistencia_modelos as p


class BancosPersistence(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='iaspe_bancos_persistence_')
        self.root=Path(self.temp.name)/'IASPE/Modelos financieros'
        self.folder=self.root/'17_Fixture/02_Bancos_y_corresponsales'
        for kind in ('Input','Output'):
            file=self.folder/kind/('Base_modelo.xlsx' if kind=='Input' else 'Pronostico.xlsx')
            file.parent.mkdir(parents=True,exist_ok=True)
            book=Workbook();sheet=book.active;sheet.title='Anual'
            sheet.append(['Año','Valor','','','','Condición']);sheet.append([2026,100,None,None,None,'Cierre supuesto'])
            if kind=='Input':
                sh=book.create_sheet('Cierre_2026');sh.append(['Mes','2025','2026','Variación'])
                for month in range(1,13):sh.append([month,100,100,0])
            book.save(file)
        file=self.root.parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz'
        file.parent.mkdir(parents=True)
        with gzip.open(file,'wt',encoding='utf-8') as stream:
            json.dump({'series':{'balance:002':{'05':{'2025-09':120.,'2026-09':200.,'2025-12':150.,'2026-12':250.}}}},stream)

    def tearDown(self):
        self.temp.cleanup()

    def apply(self, *, value=300., source_value=200., status='assumed', month='2026-09'):
        books=p._Books(self.root)
        model={'method':'Conciliación integral de liquidez: saldo residual M47',
               'annual':[{'year':2026,'value':value,'status':status}]}
        observations={'sbs_contable':{'17_bancos':{'2026':{'sourceMonth':month,'value':source_value,'status':status}}}}
        p._bancos_cierre_2026(books,self.root,self.folder,model,observations)
        return books

    def test_provisional_source_preserved_while_output_keeps_m47_residual(self):
        books=self.apply()
        inp=self.folder/'Input/Base_modelo.xlsx';out=self.folder/'Output/Pronostico.xlsx'
        self.assertEqual(books.sheet(inp,'Cierre_2026').get_range('C10').values[0][0],200.)
        self.assertEqual(books.sheet(inp,'Anual').get_range('B2').values[0][0],200.)
        self.assertEqual(books.sheet(out,'Anual').get_range('B2').values[0][0],300.)
        self.assertEqual(books.sheet(out,'Anual').get_range('F2').values[0][0],'Cierre residual M47')

    def test_source_mismatch_is_rejected_even_with_residual_method(self):
        with self.assertRaises(ValueError):
            self.apply(source_value=201.)

    def test_observed_december_is_not_replaced_by_a_different_residual(self):
        with self.assertRaises(ValueError):
            self.apply(value=300.,source_value=250.,status='observed',month='2026-12')
        books=self.apply(value=250.,source_value=250.,status='observed',month='2026-12')
        out=self.folder/'Output/Pronostico.xlsx'
        self.assertEqual(books.sheet(out,'Anual').get_range('B2').values[0][0],250.)
        self.assertEqual(books.sheet(out,'Anual').get_range('F2').values[0][0],'Observado SBS')


if __name__=='__main__':
    unittest.main()
