/* Subfichas de apertura de ingresos del M16. Solo presentación; cálculo único en ingresos_apertura.py. */
(() => {
  'use strict';
  function detalle(app, id) {
    if (id !== '16_rev' && id !== '16_nrev') return '';
    const rev = id === '16_rev', m = app.model(id), total = app.model('16_creditos');
    if (!m || !total) return '';
    const a = m.aperturaBase || {}, esc = app.escape, n = (v,d=2)=>app.fmt(v,d), pct=(v,d=4)=>n(100*v,d)+' %';
    const get = (obj,year)=>(obj?.annual||[]).find(r=>Number(r.year)===year);
    const anchor=get(m,2025), sample=get(m,2027), c27=get(total,2027), c25=get(total,2025);
    const cap24=Number(a.capital2024),cap25=Number(a.capital2025),cap26=Number(a.capital2026);
    const step=(cap26-cap25+cap25-cap24)/2;
    const principal=rev?'Ingresos de créditos revolventes':'Ingresos no revolventes y otros créditos';
    const years=[2025,2026,2027,2028,2029,2030].filter(y=>get(m,y));
    const money=(v)=>`S/ ${n(v,2)} MM`;
    const row=y=>{const r=get(m,y),t=get(total,y);return `<tr><td>${y}</td><td>${pct(r.capitalShare)}</td><td>${pct(r.incomeShare)}</td><td class="num">${n(t.value)}</td><td class="num">${n(t.value*r.incomeShare)}</td><td class="num">${n(t.value*(1-r.incomeShare))}</td></tr>`;};
    return `<div class="model-bottom"><div class="fold">
      <div class="section-label">Cómo calculamos esta apertura de ingresos</div>
      <p><strong>Esta cuenta no tiene una regresión propia.</strong> Primero calculamos los ingresos totales por créditos en el <a href="#modelo/16_creditos">Modelo 16 · Créditos</a>. Después distribuimos ese total con una participación que procede de los ingresos observados en 2025 y de los capitales de <strong>Libro1.xlsx</strong>.</p>
      <p><strong>1. Ancla observada de 2025.</strong> El Anexo IASPE registra ${money(Number(c25?.value||0))} de ingresos totales por créditos y ${money(Number(c25?.value||0)*Number(a.ingreso2025||0))} de ingresos revolventes. Por ello, la participación de ingresos revolventes fue ${pct(a.ingreso2025)}.</p>
      <p><strong>2. Capital revolvente según Libro1.xlsx.</strong> Para cada mes sumamos los capitales de los tres stages de REVOLVING y de CUOTAS. Calculamos el promedio de los meses del año para cada categoría y dividimos <em>capital REV / (capital REV + capital CUOTAS)</em>. Así obtenemos las participaciones de 2024 (${pct(cap24)}), 2025 (${pct(cap25)}) y 2026 (${pct(cap26)}).</p>
      <p><strong>3. Cierre parcial de 2026.</strong> Libro1.xlsx llega hasta octubre de 2026. Para noviembre y diciembre aplicamos a los mismos meses de 2025 el crecimiento acumulado enero–octubre de cada categoría, ${pct(a.crecimientoRevolving2026,2)} para REVOLVING y ${pct(a.crecimientoCuotas2026,2)} para CUOTAS. Después calculamos los promedios anuales.</p>
      <p><strong>4. Participación de capital desde 2027.</strong> La variación de 2024 a 2025 fue ${n(100*(cap25-cap24),4)} puntos porcentuales y de 2025 a 2026 fue ${n(100*(cap26-cap25),4)} puntos. Su promedio es <strong>${n(100*step,4)} puntos porcentuales por año</strong>. Se lo sumamos a la participación de 2026 para obtener 2027; se vuelve a sumar para 2028 y así sucesivamente.</p>
      <p><strong>5. Convertimos la variación de capital en participación de ingresos.</strong> El supuesto utilizado es trasladar <strong>el cambio en puntos porcentuales</strong> de la participación de capital a la participación de ingresos, no equiparar ambos porcentajes.</p>
      <div class="table-scroll panel"><table class="data-table"><thead><tr><th>Año</th><th>Capital REV (%)</th><th>Ingresos REV (%)</th><th>Créditos totales</th><th>Ingresos REV</th><th>No REV + otros</th></tr></thead><tbody>${years.map(row).join('')}</tbody></table></div>
      <p><strong>6. Ejemplo 2027.</strong> La participación de ingresos es ${pct(a.ingreso2025)} + (${pct(sample.capitalShare)} − ${pct(cap25)}) = <strong>${pct(sample.incomeShare)}</strong>. Los ingresos totales de créditos son ${money(c27.value)}.</p>
      <p>${rev?`<strong>${esc(principal)} 2027 = ${n(c27.value,2)} × ${pct(sample.incomeShare)} = ${money(sample.value)}.</strong>`:`Primero, los ingresos revolventes son ${n(c27.value,2)} × ${pct(sample.incomeShare)} = ${money(c27.value*sample.incomeShare)}. <strong>${esc(principal)} 2027 = ${n(c27.value,2)} − ${n(c27.value*sample.incomeShare,2)} = ${money(sample.value)}.</strong>`}</p>
      <p><strong>Precisión contable.</strong> ${rev?'La cifra revolvente de 2025 se ancla en ingresos observados del Anexo IASPE. Las participaciones de los demás años son una apertura estimada.':'La cuenta restante incluye ingresos no revolventes y un residual de otros créditos. En 2025 ese residual fue '+money(a.otros2025)+'. No se presenta como ingreso no revolvente puro.'} Los datos proyectados de ingresos desagregados del Anexo IASPE no se utilizan como supuestos de esta apertura.</p>
      <p><strong>Origen de los cálculos.</strong> <code>16_Ingresos_por_intereses_Falabella/05_Apertura_Revolving_No_Revolving/Output/Pronostico.xlsx</code>, hojas <code>Capital_mensual</code>, <code>Participaciones</code> y <code>Apertura</code>. Ancla histórica en <code>Anexo_1</code>, filas 55 y 61 de 2025. <a href="#modelo/16_creditos">Abrir el modelo que calcula el ingreso total</a>.</p>
    </div></div>`;
  }
  window.IASPEIngresosApertura = {detalle};
})();
