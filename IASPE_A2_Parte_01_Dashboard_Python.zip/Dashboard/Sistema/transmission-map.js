/* Vista compacta de las relaciones del registro IASPE. */
(() => {
  'use strict';
  const LABELS={
    '01':['Tarjetas totales','Mercado'],'02':['Tarjetas de consumo','Mercado'],
    '03':['Compras con tarjetas','Mercado'],'04':['Número de tarjetas','Falabella'],
    '05':['Saldo de tarjetas','Falabella'],'06':['Préstamos de consumo','Falabella'],
    '07':['Cartera de consumo','Falabella'],'08':['Depósitos de ahorro'],
    '09':['Depósitos a plazo'],'10_restringidos':['Depósitos restringidos'],
    '10_otras':['Otras obligaciones'],'10':['Obligaciones','con el público'],
    '11':['Costo de obligaciones'],'12':['Gastos por intereses'],
    '13':['Tasa activa de tarjetas'],'14':['Tasa activa de préstamos','Más de 360 días'],
    '15':['Tasa pasiva','181–360 días'],'16':['Ingresos por intereses'],'16_creditos':['Intereses por créditos'],'16_inversiones':['Intereses por inversiones'],'16_disponible':['Intereses de disponible'],'16_interbancarios':['Intereses interbancarios'],
    '17':['Disponible'],'18':['Servicios financieros'],'19':['Gastos administrativos'],
    '20':['Resultado de operaciones','financieras'],'21':['Inversiones financieras'],
    '22':['Fondos interbancarios'],
    '23':['Margen financiero bruto'],'24':['Otros ingresos y gastos'],
    '25':['Provisiones crediticias'],'26':['Depreciación y','amortización'],
    '27':['Valuación y otras','provisiones'],'28':['Impuesto a la renta'],
    '29':['Resultado neto del ejercicio'],'30':['Líneas no utilizadas'],
    '31':['Cuentas por cobrar netas'],'32':['Rendimientos por cobrar'],
    pbi:['PBI'],inflacion:['Inflación'],desempleo:['Desempleo'],
    tpm:['Política monetaria'],tc_cierre:['Tipo de cambio','Cierre'],tc_promedio:['Tipo de cambio','Promedio']
  };
  const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
  const geometryCache=new Map();
  function reach(id,reverse,edges){const found=new Set([id]);let changed=true;while(changed){changed=false;for(const e of edges){const a=reverse?e.target:e.source,b=reverse?e.source:e.target;if(found.has(a)&&!found.has(b)){found.add(b);changed=true}}}return found}
  const concept=id=>id==='pbi_mensual'?'pbi':id;
  function viewGraph(graph){
    const nodes=new Map(),edges=new Map();
    for(const n of graph.nodes){const id=concept(n.id);if(!nodes.has(id))nodes.set(id,{...n,id,name:id==='pbi'?'PBI':n.name})}
    for(const e of graph.edges){
      const source=concept(e.source),target=concept(e.target),key=source+'>'+target;
      const binding={...e,sourceInputId:e.source};
      if(!edges.has(key))edges.set(key,{...e,source,target,sourceInputId:e.source,bindings:[]});
      const bindings=edges.get(key).bindings;
      if(!bindings.some(b=>b.sourceInputId===binding.sourceInputId&&b.lag===binding.lag&&b.transformation===binding.transformation))bindings.push(binding);
    }
    return {nodes:[...nodes.values()],edges:[...edges.values()]};
  }
  function intersects(a,b,r,pad=5){
    let lo=0,hi=1;const dx=b.x-a.x,dy=b.y-a.y;
    for(const [p,q] of [[-dx,a.x-r.x+pad],[dx,r.x+r.w+pad-a.x],[-dy,a.y-r.y+pad],[dy,r.y+r.h+pad-a.y]]){
      if(Math.abs(p)<1e-10){if(q<0)return false;continue}
      const t=q/p;if(p<0)lo=Math.max(lo,t);else hi=Math.min(hi,t);if(lo>hi)return false;
    }
    return true;
  }
  function clear(points,boxes,source,target){
    for(let i=1;i<points.length;i++)for(const [id,r] of Object.entries(boxes)){
      if(id!==source&&id!==target&&intersects(points[i-1],points[i],r))return false;
    }
    return true;
  }
  function simplify(points){const result=[];for(const p of points){if(result.length&&p.x===result.at(-1).x&&p.y===result.at(-1).y)continue;result.push(p);while(result.length>=3){const [a,b,c]=result.slice(-3);if(Math.abs((b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x))>1e-8)break;result.splice(result.length-2,1)}}return result}
  function rounded(points){let d=`M${points[0].x} ${points[0].y}`;for(let i=1;i<points.length-1;i++){const a=points[i-1],b=points[i],c=points[i+1],u=Math.hypot(b.x-a.x,b.y-a.y),v=Math.hypot(c.x-b.x,c.y-b.y),r=Math.min(4,u/3,v/3);if(!u||!v)continue;d+=`L${b.x-(b.x-a.x)*r/u} ${b.y-(b.y-a.y)*r/u}Q${b.x} ${b.y} ${b.x+(c.x-b.x)*r/v} ${b.y+(c.y-b.y)*r/v}`}return d+`L${points.at(-1).x} ${points.at(-1).y}`}
  function pathLength(points){return (points.length-2)*14+points.slice(1).reduce((sum,p,i)=>sum+Math.abs(p.x-points[i].x)+Math.abs(p.y-points[i].y),0)}
  function routeCost(points,previous,baseCost=pathLength(points),limit=Infinity){
    let cost=baseCost;
    for(let i=1;i<points.length;i++){
      const a=points[i-1],b=points[i],horizontal=a.y===b.y;
      for(const q of previous)for(let j=1;j<q.length;j++){
        const c=q[j-1],d=q[j],otherHorizontal=c.y===d.y;
        if(horizontal===otherHorizontal){
          const distance=Math.abs(horizontal?a.y-c.y:a.x-c.x);
          const overlap=Math.max(0,Math.min(Math.max(horizontal?a.x:a.y,horizontal?b.x:b.y),Math.max(horizontal?c.x:c.y,horizontal?d.x:d.y))-Math.max(Math.min(horizontal?a.x:a.y,horizontal?b.x:b.y),Math.min(horizontal?c.x:c.y,horizontal?d.x:d.y)));
          if(distance<7)cost+=overlap*(distance<.5?24:(7-distance)*1.5);
        }else{
          const h=horizontal?[a,b]:[c,d],v=horizontal?[c,d]:[a,b];
          if(v[0].x>Math.min(h[0].x,h[1].x)+.5&&v[0].x<Math.max(h[0].x,h[1].x)-.5&&h[0].y>Math.min(v[0].y,v[1].y)+.5&&h[0].y<Math.max(v[0].y,v[1].y)-.5)cost+=65;
        }
        if(cost>=limit)return cost;
      }
    }
    return cost;
  }
  function chooseRoute(geometry,boxes,edge,previous){
    let best=null,cost=Infinity;
    for(const option of geometry.options){
      const {points,baseCost}=option;
      if(baseCost>=cost)break;
      option.valid??=clear(points,boxes,edge.source,edge.target);
      if(!option.valid)continue;
      const value=routeCost(points,previous,baseCost,cost);
      if(value<cost){best=points;cost=value}
    }
    return best||geometry.fallback;
  }
  function route(edge,boxes,levels,channels,H,edges,previous,candidatesCache){
    if(candidatesCache.has(edge))return chooseRoute(candidatesCache.get(edge),boxes,edge,previous);
    const center=id=>boxes[id].y+boxes[id].h/2;
    const a=boxes[edge.source],b=boxes[edge.target];
    const out=edges.filter(e=>e.source===edge.source).sort((u,v)=>center(u.target)-center(v.target)||boxes[u.target].x-boxes[v.target].x||u.target.localeCompare(v.target));
    const into=edges.filter(e=>e.target===edge.target).sort((u,v)=>center(u.source)-center(v.source)||boxes[u.source].x-boxes[v.source].x||u.source.localeCompare(v.source));
    const port=(box,index,count)=>count===1?box.y+box.h/2:box.y+8+(box.h-16)*index/(count-1);
    const ay=port(a,out.indexOf(edge),out.length),by=port(b,into.indexOf(edge),into.length);
    const start={x:a.x+a.w,y:ay},end={x:b.x,y:by},candidates=[];
    if(Math.abs(ay-by)<.01)candidates.push([start,end]);
    for(let c=levels[edge.source];c<levels[edge.target];c++)for(const x of channels[c])candidates.push([start,{x,y:ay},{x,y:by},end]);
    const sourceChannels=channels[levels[edge.source]],targetChannels=channels[levels[edge.target]-1];
    const lanes=[18,H-18,...Object.values(boxes).flatMap(r=>[r.y-12,r.y+r.h+12])];
    for(const y of new Set(lanes)){
      if(y<12||y>H-12)continue;
      for(const sc of sourceChannels)for(const tc of targetChannels)if(sc<tc)candidates.push([start,{x:sc,y:ay},{x:sc,y},{x:tc,y},{x:tc,y:by},end]);
    }
    const options=candidates.map(simplify).map(points=>({points,baseCost:pathLength(points)})).sort((a,b)=>a.baseCost-b.baseCost);
    const geometry={options,fallback:simplify([start,{x:sourceChannels[0],y:ay},{x:sourceChannels[0],y:H-12},{x:targetChannels.at(-1),y:H-12},{x:targetChannels.at(-1),y:by},end])};
    candidatesCache.set(edge,geometry);
    return chooseRoute(geometry,boxes,edge,previous);
  }
  function layout(nodes,edges,all){
    const signature=JSON.stringify([nodes.map(n=>[n.id,n.kind,n.name]),edges.map(e=>[e.source,e.target]),all]);
    const cached=geometryCache.get(signature);
    if(cached)return {...cached,routed:edges.map(e=>({...e,...cached.paths[e.source+'>'+e.target]}))};
    const level=Object.fromEntries(nodes.map(n=>[n.id,0]));
    for(let i=0;i<nodes.length;i++)for(const e of edges)level[e.target]=Math.max(level[e.target],Math.min(nodes.length-1,level[e.source]+1));
    // Los componentes paralelos de una cuenta se leen en una misma columna.
    const models=new Set(nodes.filter(n=>n.kind==='model').map(n=>n.id));
    for(let i=0;i<nodes.length;i++)for(const target of [...nodes].sort((a,b)=>level[b.id]-level[a.id])){
      const parents=edges.filter(e=>e.target===target.id&&models.has(e.source));
      if(parents.length<2)continue;
      for(const e of parents){
        const desired=level[target.id]-1,children=edges.filter(q=>q.source===e.source);
        if(desired>level[e.source]&&children.every(q=>level[q.target]>desired))level[e.source]=desired;
      }
    }
    const layers=[];nodes.forEach(n=>(layers[level[n.id]]??=[]).push(n));
    for(const layer of layers)layer.sort((a,b)=>a.id.localeCompare(b.id));
    // Barridos por los vecinos para reducir cruces entre columnas.
    for(let sweep=0;sweep<5;sweep++){
      const reverse=sweep%2!==0,order=layers.map((_,i)=>i);if(reverse)order.reverse();
      for(const c of order){
        const positions={};layers.forEach((layer,i)=>layer.forEach((n,j)=>positions[n.id]=j/Math.max(1,layer.length-1)));
        const bary=n=>{const peers=edges.filter(e=>reverse?e.source===n.id:e.target===n.id).map(e=>positions[reverse?e.target:e.source]);return peers.length?peers.reduce((a,b)=>a+b,0)/peers.length:positions[n.id]};
        layers[c].sort((a,b)=>bary(a)-bary(b));
      }
    }
    const step=all?56:66,H=Math.max(284,Math.max(...layers.map(l=>l.length))*step+54),W=Math.max(560,(layers.length-1)*226+200);
    const boxes={},columnRight=[];
    layers.forEach((layer,c)=>layer.forEach((n,i)=>{
      const label=LABELS[n.id]||[n.name];
      const w=n.kind==='macro'?Math.min(140,Math.max(72,Math.max(...label.map(s=>s.length))*6.4+26)):154;
      const h=n.kind==='macro'?(label.length>1?40:34):(label.length>1?46:40);
      boxes[n.id]={x:24+c*226,y:Math.round((H-layer.length*step)/2+i*step+(step-h)/2),w:Math.round(w),h};
      columnRight[c]=Math.max(columnRight[c]||0,boxes[n.id].x+boxes[n.id].w);
    }));
    const channels=layers.slice(0,-1).map((layer,c)=>{
      const left=columnRight[c]+12,right=Math.min(...layers[c+1].map(n=>boxes[n.id].x))-12;
      const count=Math.max(1,Math.floor((right-left)/9)),middle=(left+right)/2;
      return Array.from({length:count+1},(_,i)=>left+(right-left)*i/count).sort((a,b)=>Math.abs(a-middle)-Math.abs(b-middle));
    });
    const order=[...edges].sort((a,b)=>(level[a.target]-level[a.source])-(level[b.target]-level[b.source])||Math.abs(boxes[a.target].y-boxes[a.source].y)-Math.abs(boxes[b.target].y-boxes[b.source].y));
    const paths=new Map(),candidatesCache=new Map(),key=e=>e.source+'>'+e.target;
    for(const e of order)paths.set(key(e),route(e,boxes,level,channels,H,edges,[...paths.values()],candidatesCache));
    // Una segunda pasada reduce cruces y tramos coincidentes entre recorridos.
    for(const e of order){const others=[...paths].filter(([id])=>id!==key(e)).map(([,points])=>points);paths.set(key(e),route(e,boxes,level,channels,H,edges,others,candidatesCache))}
    const routed=edges.map(e=>{const points=paths.get(key(e));return {...e,points,path:rounded(points)}});
    const geometry={boxes,W,H,paths:Object.fromEntries(routed.map(e=>[key(e),{points:e.points,path:e.path}]))};
    if(geometryCache.size>=12)geometryCache.delete(geometryCache.keys().next().value);
    geometryCache.set(signature,geometry);
    return {boxes,W,H,routed};
  }
  function edgeInfo(app,edge,event){
    const esc=app.escape,nodes=app.state.data.graph.nodes,a=nodes.find(n=>n.id===edge.source),b=nodes.find(n=>n.id===edge.target);
    const details=(edge.bindings||[edge]).map(binding=>{
      const pbi=concept(binding.sourceInputId||binding.source)==='pbi',monthly=binding.sourceInputId==='pbi_mensual';
      const name=pbi?(monthly?'Variación interanual del PBI':'Crecimiento real anual del PBI'):({tpm:'TPM de diciembre',inflacion_rezago:'Inflación del año anterior'}[binding.name]||(LABELS[binding.sourceInputId||binding.source]||[]).join(' ')||binding.name);
      const lag=binding.lag===''||binding.lag==null||binding.lag===0?'Contemporáneo':pbi?(String(binding.lag).split(',').map(v=>+v.trim()===0?'Contemporáneo':`${+v.trim()} ${monthly?(+v.trim()===1?'mes':'meses'):(+v.trim()===1?'año':'años')}`).join(' y ')):binding.lag+' período(s)';
      const operation=monthly?'100 × (PBI[t−2] / PBI[t−14] − 1)':pbi?'':binding.transformation;
      return `<dl><dt>Variable</dt><dd>${esc(name)}</dd>${pbi?`<dt>Frecuencia</dt><dd>${monthly?'Mensual':'Anual'}</dd>`:''}<dt>Unidad</dt><dd>${esc(pbi?'%':binding.unit)}</dd><dt>Rezago</dt><dd>${esc(lag)}</dd>${operation?`<dt>Operación</dt><dd>${esc(operation)}</dd>`:''}${monthly?'<dt>Dato de origen</dt><dd>Índice real, 2007 = 100</dd>':''}</dl>`;
    }).join('');
    const left=Math.min(Math.max(16,(event?.clientX||innerWidth/2)-145),innerWidth-350),top=Math.min(Math.max(100,(event?.clientY||220)+12),Math.max(100,innerHeight-370));
    $('#portal').innerHTML=`<div class="tm-dismiss"></div><section class="tm-popover" role="dialog" aria-label="Detalle de la conexión" style="left:${left}px;top:${top}px"><button class="tm-close" aria-label="Cerrar conexión">×</button><h3>${esc((LABELS[a?.id]||[a?.name||'']).join(' '))} <span>→</span> ${esc((LABELS[b?.id]||[b?.name||'']).join(' '))}</h3>${details}<button class="tm-model-link">Ver modelo ↗</button></section>`;
    $('.tm-close').onclick=$('.tm-dismiss').onclick=()=>$('#portal').innerHTML='';
    $('.tm-model-link').onclick=()=>app.navigate('modelo/'+edge.target);
  }
  function render(app,impact=false){
    const S=app.state,esc=app.escape,g=viewGraph(S.data.graph),allEdges=g.edges;
    S.mapAnchor=concept(S.mapAnchor);S.mapSelected=concept(S.mapSelected);
    if(!S.mapAnchor||!g.nodes.some(n=>n.id===S.mapAnchor))S.mapAnchor=S.mapSelected||'16';
    const anchor=g.nodes.find(n=>n.id===S.mapAnchor)||g.nodes.at(-1);
    const scope=S.mapScope||'direct';
    let visible;
    if(impact)visible=new Set([...S.data.affected,...Object.keys(S.changes)].map(concept));
    else if(scope==='all')visible=new Set(g.nodes.filter(n=>allEdges.some(e=>e.source===n.id||e.target===n.id)).map(n=>n.id));
    else if(scope==='direct')visible=new Set([anchor.id,...allEdges.filter(e=>e.source===anchor.id||e.target===anchor.id).flatMap(e=>[e.source,e.target])]);
    else if(scope==='up')visible=reach(anchor.id,true,allEdges);
    else if(scope==='down')visible=reach(anchor.id,false,allEdges);
    else visible=new Set([...reach(anchor.id,true,allEdges),...reach(anchor.id,false,allEdges)]);
    if(!visible.size)visible.add(anchor.id);if(!impact)visible.add(anchor.id);
    const nodes=g.nodes.filter(n=>visible.has(n.id)),edges=allEdges.filter(e=>visible.has(e.source)&&visible.has(e.target));
    if(!visible.has(S.mapSelected))S.mapSelected=visible.has('16')?'16':visible.has('12')?'12':visible.values().next().value;
    const selected=g.nodes.find(n=>n.id===S.mapSelected)||anchor,m=app.model(selected.id);
    const {boxes,W,H,routed}=layout(nodes,edges,scope==='all'||impact);
    const maxHeight=Math.min(520,Math.max(325,innerHeight-310)),available=Math.max(580,innerWidth-120);
    const fit=Math.min(1,available/W,(maxHeight-28)/H),zoom=S.mapZoom??fit,viewHeight=Math.min(maxHeight,Math.max(310,H*zoom+34));
    const highlighted=new Set([...reach(selected.id,true,edges),...reach(selected.id,false,edges)]);
    const short=id=>(LABELS[id]||[g.nodes.find(n=>n.id===id)?.name||id]).join(' ');
    const categories=[
      ['Variables macroeconómicas',g.nodes.filter(n=>n.kind==='macro').map(n=>n.id)],
      ['Variables operativas',g.nodes.filter(n=>n.kind!=='macro'&&['01','02','03','04','13','14','15','30'].includes(n.id)).map(n=>n.id)],
      ['Modelos complementarios',g.nodes.filter(n=>n.kind!=='macro'&&n.id.split('_')[0]==='49').map(n=>n.id)],
      ['Estado de resultados',g.nodes.filter(n=>n.kind!=='macro'&&['12','16','18','19','20','23','24','25','26','27','28','29'].includes(n.id.split('_')[0])).map(n=>n.id)],
      ['Estado de situación financiera',g.nodes.filter(n=>n.kind!=='macro'&&!['01','02','03','04','13','14','15','30','49','12','16','18','19','20','23','24','25','26','27','28','29'].includes(n.id.split('_')[0])).map(n=>n.id)]
    ].filter(([,ids])=>ids.length);
    const categoryName=categories.find(([,ids])=>ids.includes(anchor.id))?.[0]||categories[0]?.[0];
    const categoryItems=categories.find(([name])=>name===categoryName)?.[1]||[anchor.id];
    const inputs=[...new Set(allEdges.filter(e=>e.target===selected.id).map(e=>e.source))].sort((a,b)=>short(a).localeCompare(short(b),'es'));
    const outputs=[...new Set(allEdges.filter(e=>e.source===selected.id).map(e=>e.target))].sort((a,b)=>short(a).localeCompare(short(b),'es'));
    $('#workspace').innerHTML=`<section class="tm-workspace"><div class="tm-heading"><div class="tm-heading-copy"><div class="tm-heading-row"><h1>Relaciones entre variables y modelos</h1>${impact?'<span class="tm-impact-tag">Impacto del escenario</span>':''}</div><p>Selecciona una variable o un resultado para ver qué entradas lo explican y qué efectos transmite al resto del sistema.</p></div><div class="tm-controls"><label>Grupo<select id="tm-category" aria-label="Grupo de variables">${categories.map(([name,ids])=>`<option value="${esc(name)}" ${name===categoryName?'selected':''}>${esc(name)}</option>`).join('')}</select></label><label>Variable<select id="tm-target" aria-label="Variable del mapa">${categoryItems.map(id=>`<option value="${id}" ${id===anchor.id?'selected':''}>${esc(short(id))}</option>`).join('')}</select></label><label>Vista<select id="tm-scope" aria-label="Alcance del mapa">${[['direct','Relaciones directas'],['up','Determinantes'],['down','Impactos'],['chain','Ruta completa'],['all','Vista general']].map(([v,t])=>`<option value="${v}" ${scope===v?'selected':''}>${t}</option>`).join('')}</select></label><div class="tm-zoom"><button id="tm-minus" aria-label="Reducir mapa">−</button><button id="tm-fit" title="Ajustar mapa">${Math.round(zoom*100)}%</button><button id="tm-plus" aria-label="Ampliar mapa">+</button></div></div></div><div class="tm-board"><div class="tm-legend"><span><i class="tm-legend-dot macro"></i>Variable macroeconómica</span><span><i class="tm-legend-dot model"></i>Modelo o resultado</span><span><i class="tm-legend-dot selected"></i>Elemento seleccionado</span></div><div class="tm-viewport" style="height:${viewHeight}px"><div class="tm-space" style="width:${W*zoom}px;height:${H*zoom}px"><div class="tm-stage" style="width:${W}px;height:${H}px;transform:scale(${zoom})"><svg width="${W}" height="${H}" aria-label="Conexiones entre variables"><defs><marker id="tm-arrow" markerWidth="6" markerHeight="6" refX="5.8" refY="3" orient="auto"><path d="M0 0L6 3L0 6" fill="context-stroke"/></marker></defs>${routed.map((e,i)=>`<path class="tm-edge-halo" d="${e.path}"/><path class="tm-edge ${e.source===selected.id||e.target===selected.id?'connected':''} ${highlighted.has(e.source)&&highlighted.has(e.target)?'':'faded'}" d="${e.path}" marker-end="url(#tm-arrow)"/><path class="tm-edge-hit" data-connection="${i}" data-source="${e.source}" data-target="${e.target}" data-points="${esc(JSON.stringify(e.points))}" d="${e.path}" role="button" tabindex="0" aria-label="${esc(short(e.source)+' hacia '+short(e.target))}"/>`).join('')}</svg>${nodes.map(n=>{const b=boxes[n.id],label=LABELS[n.id]||[n.name];return `<button class="tm-node ${n.kind==='macro'?'economic':''} ${n.id===selected.id?'selected':''} ${highlighted.has(n.id)?'':'faded'}" data-node="${n.id}" data-x="${b.x}" data-y="${b.y}" data-width="${b.w}" data-height="${b.h}" style="left:${b.x}px;top:${b.y}px;width:${b.w}px;height:${b.h}px" title="${esc(n.name)}">${label.map((t,i)=>`<span class="${i?'tm-secondary':''}">${esc(t)}</span>`).join('')}</button>`}).join('')}</div></div></div><div class="tm-shortcuts"><div><strong>Entradas directas <small>${inputs.length}</small></strong><div>${inputs.length?inputs.map(id=>`<button type="button" data-tm-jump="${id}">${esc(short(id))}</button>`).join(''):'<span>Sin entradas en el registro</span>'}</div></div><div><strong>Efectos directos <small>${outputs.length}</small></strong><div>${outputs.length?outputs.map(id=>`<button type="button" data-tm-jump="${id}">${esc(short(id))}</button>`).join(''):'<span>Sin efectos registrados</span>'}</div></div></div><div class="tm-selection"><div><strong>${esc(selected.name)}</strong>${m?`<span>${esc(m.unit)}</span>`:''}</div><div>${selected.id!==anchor.id?'<button id="tm-follow">Usar como punto de partida</button>':''}${selected.kind==='model'?'<button id="tm-open-model">Abrir modelo</button>':'<button id="tm-open-input">Abrir supuestos</button>'}</div></div></div></section>`;
    $('#tm-category').onchange=e=>{const first=categories.find(([name])=>name===e.target.value)?.[1][0];if(first){S.mapAnchor=first;S.mapSelected=first;S.mapZoom=null;app.render()}};
    $('#tm-target').onchange=e=>{S.mapAnchor=e.target.value;S.mapSelected=e.target.value;S.mapZoom=null;app.render()};
    $('#tm-scope').onchange=e=>{S.mapScope=e.target.value;S.mapZoom=null;if(impact)app.navigate('mapa');else app.render()};
    $$('[data-node]').forEach(b=>{b.onclick=()=>{S.mapSelected=b.dataset.node;app.render()};b.ondblclick=()=>{if(app.model(b.dataset.node))app.navigate('modelo/'+b.dataset.node)}});
    $$('[data-connection]').forEach(el=>{el.onclick=e=>edgeInfo(app,routed[+el.dataset.connection],e);el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();edgeInfo(app,routed[+el.dataset.connection],null)}}});
    $('#tm-minus').onclick=()=>{S.mapZoom=Math.max(.45,zoom-.1);app.render()};
    $('#tm-plus').onclick=()=>{S.mapZoom=Math.min(1.6,zoom+.1);app.render()};
    $('#tm-fit').onclick=()=>{S.mapZoom=null;app.render()};
    $$('[data-tm-jump]').forEach(b=>b.onclick=()=>{S.mapAnchor=b.dataset.tmJump;S.mapSelected=b.dataset.tmJump;S.mapZoom=null;S.mapScope='direct';app.render()});
    if($('#tm-follow'))$('#tm-follow').onclick=()=>{S.mapAnchor=selected.id;S.mapZoom=null;S.mapScope='direct';app.render()};
    if($('#tm-open-model'))$('#tm-open-model').onclick=()=>app.navigate('modelo/'+selected.id);
    if($('#tm-open-input'))$('#tm-open-input').onclick=()=>app.navigate('escenarios/'+(/^\d{2}$/.test(app.state.labModel)?app.state.labModel:'16')+'?editar=1');
  }
  window.IASPEMap={render};
})();
