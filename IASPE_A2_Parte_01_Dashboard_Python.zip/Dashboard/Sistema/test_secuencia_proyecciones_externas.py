"""Controlled MEF discovery/update sequence; NOT a real network test.
Uses official bodies previously downloaded, mutates one numeric cell in memory,
and serves synthetic official-shaped HTML through a mocked transport.
All module storage is redirected to TemporaryDirectory.
Run: python test_secuencia_proyecciones_externas.py
The original input books are read from the external module's archived documents.
"""
import sys,io,zipfile,re,tempfile,json,hashlib,copy,base64
from pathlib import Path
from datetime import datetime,timezone,timedelta
from unittest.mock import patch
import xml.etree.ElementTree as ET
APP=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
BASE=APP/'data'/'proyecciones_externas'/'evidencias'
sys.path.insert(0,str(APP))
import proyecciones_externas as p


def mutate_cell(body,value):
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        root=ET.fromstring(archive.read('xl/workbook.xml'))
        ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        sheet=next(s for s in root.findall('m:sheets/m:sheet',ns) if s.attrib['name']=='C-01')
        rid=sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
        rels=ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))
        target=next(r.attrib['Target'] for r in rels if r.attrib['Id']==rid)
        target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        xml=archive.read(target).decode('utf-8')
        expr=r'(<c\b[^>]*\br="D29"[^>]*>.*?<v>)[^<]*(</v>)'
        xml,n=re.subn(expr,lambda m:m[1]+str(value)+m[2],xml,flags=re.S)
        assert n==1
        stream=io.BytesIO()
        with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as output:
            for info in archive.infolist():output.writestr(info,xml.encode() if info.filename==target else archive.read(info.filename))
    return stream.getvalue()

def archived_body(edition):
    state=p._load()
    documents=[d for d in state['editions'] if d.get('source')=='MEF · MMM/IAPM' and d.get('edition')==edition and d.get('file') and d.get('origin')=='official']
    if not documents:
        raise RuntimeError('Falta el respaldo oficial archivado: '+edition+'; ejecutar primero la actualización real del conector')
    for document in documents:
        body=(p.DOCS/document['file']).read_bytes()
        if hashlib.sha256(body).hexdigest()==document['hash']:
            return body
    raise RuntimeError('El respaldo archivado no coincide con su hash: '+edition)

IAPM=archived_body('IAPM 2026–2029')
MMM=mutate_cell(archived_body('MMM 2027–2030'),3.411111)
COL=p.MEF_COLLECTION
OLD_PAGE='https://www.gob.pe/institucion/mef/informes-publicaciones/555-controlled-mmm-2026-2029'
NEW_PAGE='https://www.gob.pe/institucion/mef/informes-publicaciones/777-controlled-mmm-2027-2030'
OLD_DOC='https://cdn.www.gob.pe/uploads/document/file/555/cuadros-estadisticos-iapm-2026-2029.xlsx'
NEW_DOC='https://cdn.www.gob.pe/uploads/document/file/777/cuadros-estadisticos-mmm-2027-2030.xlsx'
old_collection=f'<a href="{OLD_PAGE}">Marco Macroeconomico Multianual 2026-2029</a>'.encode()
new_collection=old_collection+f'<a href="{NEW_PAGE}">Marco Macroeconomico Multianual 2027-2030</a>'.encode()
old_page=f'<div class="institution-document__header"><p>28 de agosto de 2025</p></div><a href="{OLD_DOC}">Cuadros IAPM 2026-2029</a>'.encode()
new_page=f'<div class="institution-document__header"><p>28 de agosto de 2026</p></div><a href="{NEW_DOC}">Cuadros MMM 2027-2030</a>'.encode()
phase=1
mapping={COL:old_collection,OLD_PAGE:old_page,NEW_PAGE:new_page,OLD_DOC:IAPM,NEW_DOC:MMM}
checks=0

def check(test,label):
    global checks
    assert test,label
    checks+=1

def fake_get(url,**kwargs):
    body=mapping[url]
    stamp=(datetime.now(timezone.utc)-timedelta(seconds=10-phase)).isoformat(timespec='seconds')
    p._trace({'url':url,'http_status':200,'content_type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if url.endswith('.xlsx') else 'text/html','checked_at':stamp,'downloaded_at':stamp,'body_hash':hashlib.sha256(body).hexdigest(),'consulted':True,'downloaded':True,'test_transport':'SIMULATED'})
    return body

blocked=([],[{'id':'test-blocked-eem','source':'BCRP · encuesta anual','edition':'Descubrimiento','error':'SIMULATED protected source','blocked':True}])
result={'mode':'CONTROLLED; not a real HTTP download','assertions':0,'phases':[]}
with tempfile.TemporaryDirectory(prefix='iaspe_mef_sequence_') as temp:
    root=Path(temp)
    with patch.multiple(p,DIR=root,STATE=root/'historial.json',DOCS=root/'documentos',HTTP_CACHE=root/'http_cache.json'),patch.object(p,'_get',side_effect=fake_get),patch.object(p,'_update_eem_excel',return_value=blocked),patch.object(p,'_update_ri',side_effect=ConnectionError('SIMULATED outage')):
        first=p.update();initial=p._load()
        check(len(first['current_records'])==16,'IAPM has four years × four variables')
        check(first['updateResult']['new_editions']==1,'baseline edition incorporated')
        initial_values={(r['document_id'],r['variable'],r['year'],r['value']) for r in first['records']}
        result['phases'].append({'name':'IAPM baseline; BCRP blocked/offline','records':len(first['records']),'new_editions':first['updateResult']['new_editions']})
        phase=2;mapping[COL]=new_collection
        second=p.update()
        check(len(second['records'])==36,'history keeps 16 IAPM plus 20 MMM rows')
        check(len(second['current_records'])==20,'current cohort entirely MMM')
        check({r['edition'] for r in second['current_records']}=={'MMM 2027–2030'},'new edition selected without mixing')
        check({r['year'] for r in second['current_records']}==set(map(str,range(2026,2031))),'exact published horizon')
        check(second['updateResult']['new_editions']==1,'one genuinely new edition')
        check(initial_values.issubset({(r['document_id'],r['variable'],r['year'],r['value']) for r in second['records']}),'history values unchanged')
        check(all(r['value']==3.411111 for r in second['current_records'] if r['variable']=='pbi' and r['year']=='2026'),'mutated fixture value actually parsed')
        check(all(f['up_to_date'] for f in second['freshness']),'simulated verified MEF cohort marked current')
        check('Encuesta BCRP' not in second['updateResult']['source_summary'],'BCRP disabled in MEF automatic path')
        result['phases'].append({'name':'synthetic new MMM link plus mutated official-shaped XLSX','records':len(second['records']),'current':len(second['current_records']),'new_editions':second['updateResult']['new_editions'],'history_preserved':True})
        phase=3;third=p.update()
        check(third['updateResult']['new_editions']==0,'repeat is not new edition')
        check(third['updateResult']['added']==0,'repeat adds no rows')
        check(third['updateResult']['repeated']==2,'both repeated documents identified')
        result['phases'].append({'name':'repeated same documents','added':third['updateResult']['added'],'new_editions':third['updateResult']['new_editions'],'repeated':third['updateResult']['repeated']})
        imported=p.import_document('MEF · MMM/IAPM','MMM 2027–2030','controlled.xlsx',base64.b64encode(MMM).decode(),NEW_DOC,'2026-08-28')
        check(imported['added']==0,'manual repeated same body adds no values')
        check(len(imported['state']['records'])==36,'manual repeat does not duplicate rows')
        check(all(r['origin']=='official' and r['transport_verified'] for r in imported['state']['current_records']),'manual repeat preserves official verification')
        check(imported['document']['id']==third['current_records'][0]['document_id'],'manual/automatic document ID is canonical')
        result['phases'].append({'name':'manual repeat of identical automatically verified body','added':imported['added'],'same_document_id':True,'official_metadata_preserved':True})
        phase=4;mapping[NEW_DOC]=b'PKinvalid controlled XLSX'
        fourth=p.update()
        check(len(fourth['records'])==36,'invalid new download cannot remove valid history')
        check({(r['document_id'],r['variable'],r['year'],r['value']) for r in fourth['current_records']}=={(r['document_id'],r['variable'],r['year'],r['value']) for r in third['current_records']},'valid active values retained after failure')
        check(not any(f['up_to_date'] for f in fourth['freshness']),'failed latest document not certified')
        result['phases'].append({'name':'invalid latest XLSX; partial update from older valid attachment','records':len(fourth['records']),'active_values_preserved':True,'freshness':[f['up_to_date'] for f in fourth['freshness']]})
result['assertions']=checks
BASE.mkdir(parents=True,exist_ok=True)
(BASE/'test_secuencia_resultado.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
