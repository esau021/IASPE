'use strict';
/* La vista de WEO conserva estados individuales para FMI/MEF y su fecha de revisión. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
let source=fs.readFileSync(path.join(root,'proyecciones-externas.js'),'utf8');
assert(source.includes('window.IASPEMacroExternas='));
source=source.replace('window.IASPEMacroExternas=',
 'globalThis.probe={setState:next=>{state=next},setSourceError:(key,message)=>{if(message)sourceErrors[key]=message;else delete sourceErrors[key]},setBusy:key=>{busySource=key},updateStatusLines,checkMessage};window.IASPEMacroExternas=');
const context={window:{},document:{querySelector:()=>null},location:{hash:''},Intl,URL,Date,Map,Set,console};
vm.createContext(context);
vm.runInContext(source,context);
const {probe}=context;
assert.equal(probe.updateStatusLines(),'');
const timestamp='2026-11-21T15:00:00Z';
function status(imf,mef){probe.setState({lastChecks:{imf:imf?{...imf,date:timestamp}:undefined,mef:mef?{...mef,date:timestamp}:undefined}});return probe.updateStatusLines();}
let html=status({scope:'imf',status:'unchanged',new_editions:0,revisions:0,http_events:[{http_status:503},{http_status:200}]});
assert(html.includes('FMI consultado: no hay nuevas ediciones ni revisiones.'));
assert(html.includes('mex-source-status ok'));
assert(!html.includes('La consulta del FMI no se completó'));
html=status({scope:'imf',status:'updated',new_editions:1,revisions:1});
assert(html.includes('FMI: 1 edición(es) nueva(s) y 1 revisión(es) incorporada(s).'));
html=status({scope:'imf',status:'error',errors:['Excel inválido'],http_events:[{http_status:200}]});
assert(html.includes('mex-source-status warn'));
assert(html.includes('La consulta del FMI no se completó; se conservan los últimos datos válidos.'));
assert(!html.includes('no hay nuevas ediciones'));
html=status({scope:'imf',status:'unchanged'}, {scope:'mef',status:'unchanged'});
assert(html.includes('FMI consultado'));assert(html.includes('MEF consultado'));
probe.setSourceError('mef','Red no disponible');html=probe.updateStatusLines();
assert(html.includes('mex-source-status warn'));
assert(html.includes('La consulta del MEF no se completó: Red no disponible'));
probe.setSourceError('mef',null);
probe.setBusy('imf');html=probe.updateStatusLines();
assert(html.includes('Consultando FMI…'));
assert(!html.includes('mex-source-status warn'));
probe.setBusy('');
console.log('WEO/FMI/MEF: avisos, revisiones y errores individuales: OK');
