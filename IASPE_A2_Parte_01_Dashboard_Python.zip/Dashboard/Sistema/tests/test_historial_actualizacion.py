"""Retención de versiones y publicación atómica sin tocar bases activas."""
from pathlib import Path
import json
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from historial_actualizacion import prepare
import motor
import persistencia_modelos
from openpyxl import Workbook, load_workbook


def model(value):
    return {'07':{'name':'Consumo', 'unit':'S/ millones', 'status':'ready',
                  'annual':[{'year':2025,'value':50,'status':'observed'},
                            {'year':2026,'value':value,'status':'assumed'},
                            {'year':2030,'value':value+20,'status':'forecast'}],
                  'monthly':[{'date':'2026-09','value':value,'status':'observed'}]}}


class ForecastHistory(unittest.TestCase):
    def history(self, old=60, new=70, history=None, stamp='2026-11-21T20:00:00+00:00'):
        return prepare(history, model(old), model(new), previous_sources={'2026-08':old},
                       updated_sources={'2026-09':new}, macro_base={'changes':{}}, published_at=stamp)

    def test_retains_previous_and_updated_values_and_statuses(self):
        result=self.history()
        self.assertEqual(len(result['versions']),2)
        before,after=result['versions']
        self.assertEqual(before['models']['07']['annual'][0]['value'],60)
        self.assertEqual(after['models']['07']['annual'][0]['value'],70)
        self.assertEqual(after['models']['07']['annual'][0]['status'],'assumed')
        self.assertEqual(after['models']['07']['monthly'][0]['status'],'observed')
        self.assertEqual(result['publications'][0]['previousVersion'],before['id'])

    def test_forecasts_only_and_no_duplicate_versions(self):
        result=self.history()
        repeated=self.history(history=result)
        self.assertEqual(len(repeated['versions']),2)
        self.assertEqual(len(repeated['publications']),1)
        self.assertTrue(all(row['year']>=2026 for item in result['versions'] for row in item['models']['07']['annual']))

    def test_keeps_prior_history_immutable(self):
        result=self.history();copy=json.dumps(result,sort_keys=True)
        updated=self.history(70,80,history=result,stamp='2026-12-21T20:00:00+00:00')
        self.assertEqual(json.dumps(result,sort_keys=True),copy)
        self.assertEqual(len(updated['publications']),2)
        self.assertEqual(updated['publications'][0],result['publications'][0])

    def test_corrupt_history_is_not_replaced(self):
        with self.assertRaises(ValueError):self.history(history={'versions':'invalid'})

    def test_state_failure_rolls_back_history_and_other_states_together(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_history_test_') as temporary:
            folder=Path(temporary)
            original={'versions':[],'publications':[]}
            (folder/'historial_pronosticos.json').write_text(json.dumps(original),encoding='utf8')
            (folder/'fuentes_aplicadas.json').write_text('{"before":1}',encoding='utf8')
            import os
            replace=os.replace
            def fail_last(source,target):
                if Path(target).name=='ultimo_recalculo.json':raise OSError('fixture de fallo')
                return replace(source,target)
            with patch.object(motor,'DATA',folder),patch('os.replace',side_effect=fail_last):
                with self.assertRaises(OSError):
                    motor.write_states({'historial_pronosticos.json':self.history(),
                                        'fuentes_aplicadas.json':{'after':2},'ultimo_recalculo.json':{'ok':True}})
            self.assertEqual(json.loads((folder/'historial_pronosticos.json').read_text()),original)
            self.assertEqual(json.loads((folder/'fuentes_aplicadas.json').read_text()),{'before':1})
            self.assertFalse((folder/'ultimo_recalculo.json').exists())

    def transaction(self, fail_history=False):
        with tempfile.TemporaryDirectory(prefix='iaspe_history_publication_') as temporary:
            root=Path(temporary);source=root/'IASPE/Modelos financieros';source.mkdir(parents=True)
            states=root/'states';states.mkdir()
            book=Workbook();book.active['A1']=1;book.save(source/'Book.xlsx');book.close()
            original=(source/'Book.xlsx').read_bytes()
            (states/'fuentes_aplicadas.json').write_text('{"previous":1}',encoding='utf8')
            def generate(staged, *args):
                target=staged/'Book.xlsx';book=load_workbook(target);book.active['A1']=2
                pending=target.with_suffix('.writing');book.save(pending);book.close();pending.replace(target)
                return {'files':['Book.xlsx']}
            import os
            replace=os.replace
            def replace_or_fail(src,dst):
                if fail_history and Path(dst).name=='historial_pronosticos.json':raise OSError('No se pudo guardar historial')
                return replace(src,dst)
            passed={'passed':True,'checks':1}
            with patch.object(motor,'DATA',states),patch.object(motor,'load_base',return_value=({},[])),\
                 patch.object(motor,'_run',return_value=({},[])),\
                 patch.object(persistencia_modelos,'generar',side_effect=generate),patch('os.replace',side_effect=replace_or_fail):
                call=lambda:persistencia_modelos.aplicar_transaccion(source,model(60),model(70),lambda:{},
                    lambda *args:passed,lambda *args:passed,threading.RLock(),observations={},
                    state_updates={'fuentes_aplicadas.json':{'current':2}})
                if fail_history:
                    with self.assertRaises(OSError):call()
                    self.assertEqual((source/'Book.xlsx').read_bytes(),original)
                    self.assertEqual(json.loads((states/'fuentes_aplicadas.json').read_text()),{'previous':1})
                    self.assertFalse((states/'historial_pronosticos.json').exists())
                else:
                    call();self.assertNotEqual((source/'Book.xlsx').read_bytes(),original)
                    history=json.loads((states/'historial_pronosticos.json').read_text(encoding='utf8'))
                    self.assertEqual(len(history['versions']),2)
                    self.assertTrue(history['publications'][0]['ok'])
                    self.assertEqual(json.loads((states/'fuentes_aplicadas.json').read_text()),{'current':2})

    def test_verified_excel_and_states_commit_with_both_forecast_versions(self):
        self.transaction()

    def test_history_failure_reverts_verified_excel_and_applied_sources(self):
        self.transaction(fail_history=True)

    def test_failed_attempt_keeps_last_successful_recalculation(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_last_success_') as temporary:
            folder=Path(temporary)
            success={'ok':True,'status':'completo','generatedAt':'2026-11-20T20:00:00+00:00'}
            (folder/'ultimo_recalculo.json').write_text(json.dumps(success),encoding='utf8')
            with patch.object(motor,'DATA',folder):
                motor.write_state('ultimo_recalculo.json',{'ok':False,'status':'pendiente','generatedAt':'2026-11-21T20:00:00+00:00'})
                self.assertEqual(motor.read_state('ultimo_recalculo_exitoso.json',None),success)
                self.assertFalse(motor.read_state('ultimo_recalculo.json',{})['ok'])
                motor.write_state('ultimo_recalculo.json',{'ok':False,'status':'pendiente'})
                self.assertEqual(motor.read_state('ultimo_recalculo_exitoso.json',None),success)

    def test_new_success_replaces_success_marker_without_changing_values(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_last_success_') as temporary:
            success={'ok':True,'status':'completo','generatedAt':'2026-11-21T20:00:00+00:00'}
            with patch.object(motor,'DATA',Path(temporary)):
                motor.write_state('ultimo_recalculo.json',success)
                self.assertEqual(motor.read_state('ultimo_recalculo_exitoso.json',None),success)


if __name__=='__main__':unittest.main()
