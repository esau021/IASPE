"""Resolución de enlaces SBS publicados; pruebas sin solicitudes de red."""
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import MagicMock,patch
from urllib.error import HTTPError,URLError

ROOT=Path(__file__).resolve().parents[3]
SCRIPT=ROOT/'IASPE/Scraper/Oficinas/script/actualizar_oficinas.py'
spec=importlib.util.spec_from_file_location('oficinas_published_sources_tests',SCRIPT)
source=importlib.util.module_from_spec(spec);spec.loader.exec_module(source)
CATALOG='https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c=B-2303'


class PublishedSourcesTests(unittest.TestCase):
    def test_public_excel_does_not_require_catalog_html(self):
        def fetch(report,period,ledger,url=None):
            if period!='2026-09':raise source.NotPublished(period)
            return b'public workbook fixture'
        with patch.object(source,'date') as clock,patch.object(source,'fetch',side_effect=fetch),\
             patch.object(source,'discover_catalog',side_effect=AssertionError('El catálogo no es requisito')) as catalog:
            from datetime import date
            clock.today.return_value=date(2026,11,21)
            period,body,url,method,links=source.latest_publication('B-2303',{'requests':[]})
        self.assertEqual(period,'2026-09')
        self.assertEqual(body,b'public workbook fixture')
        self.assertEqual(method,'known_public_dated_path')
        catalog.assert_not_called()

    def test_excel_access_control_is_fatal_without_catalog_fallback(self):
        with patch.object(source,'fetch',side_effect=RuntimeError('HTTP403delExcel')),patch.object(source,'discover_catalog') as catalog:
            with self.assertRaisesRegex(RuntimeError,'403'):source.latest_publication('B-2303',{'requests':[]})
        catalog.assert_not_called()

    def test_published_href_follows_an_official_host_migration(self):
        href='https://estadisticas.sbs.gob.pe/publicaciones/2027/Abril/B-2303-ab2027.XLS'
        html=f'<a href="{href}">Abril</a>'
        self.assertEqual(source.published_links(html,'B-2303',CATALOG),{'2027-04':href})

    def test_official_domain_is_not_a_substring_or_userinfo(self):
        for url in ('https://sbs.gob.pe.evil.example/file.xls','https://sbs.gob.pe@evil.example/file.xls',
                    'https://127.0.0.1/file.xls','http://www.sbs.gob.pe/file.xls','https://www.sbs.gob.pe:444/file.xls'):
            self.assertFalse(source.official_url(url),url)
        self.assertTrue(source.official_url('https://www.sbs.gob.pe/file.xls'))

    def test_wrong_report_month_folder_and_filename_year_are_ignored(self):
        urls=['https://www.sbs.gob.pe/2026/Setiembre/B-3201-se2026.XLS',
              'https://www.sbs.gob.pe/2026/Agosto/B-2303-se2026.XLS',
              'https://www.sbs.gob.pe/2025/Setiembre/B-2303-se2026.XLS',
              'https://unrelated.example/2026/Setiembre/B-2303-se2026.XLS']
        html=''.join(f'<a href="{url}">Mes</a>' for url in urls)
        self.assertEqual(source.published_links(html,'B-2303',CATALOG),{})

    def test_relative_and_old_http_links_are_resolved_on_https(self):
        html='<a href="http://intranet2.sbs.gob.pe/estadistica/financiera/2026/Setiembre/B-2303-se2026.XLS">Setiembre</a>'
        links=source.published_links(html,'B-2303',CATALOG)
        self.assertEqual(links['2026-09'],'https://intranet2.sbs.gob.pe/estadistica/financiera/2026/Setiembre/B-2303-se2026.XLS')

    def test_different_published_documents_for_same_month_are_not_silently_selected(self):
        html=''.join(f'<a href="https://{host}/2026/Setiembre/B-2303-se2026.XLS">Setiembre</a>'
                     for host in ('www.sbs.gob.pe','intranet2.sbs.gob.pe'))
        with self.assertRaisesRegex(ValueError,'ambiguos'):source.published_links(html,'B-2303',CATALOG)

    def test_bounded_fallback_uses_the_last_official_template_host(self):
        template='https://estadisticas.sbs.gob.pe/nuevo/2026/Setiembre/B-2303-se2026.XLS'
        self.assertEqual(source.source_url('B-2303','2027-04',template),
            'https://estadisticas.sbs.gob.pe/nuevo/2027/Abril/B-2303-ab2027.XLS')

    def test_403_is_not_a_reason_to_fall_back_to_another_route(self):
        ledger={'requests':[]}
        with patch.object(source,'build_opener') as opener:
            opener.return_value.open.side_effect=HTTPError(CATALOG,403,'Forbidden',{},None)
            with self.assertRaisesRegex(RuntimeError,'403'):source.discover_catalog('B-2303',ledger)
        self.assertEqual(ledger['requests'][0]['status'],'access_control')
        self.assertEqual(opener.return_value.open.call_count,1)

    def test_catalog_network_outage_is_recorded_for_bounded_fallback(self):
        ledger={'requests':[]}
        with patch.object(source,'build_opener') as opener:
            opener.return_value.open.side_effect=URLError('DNS fixture unavailable')
            self.assertEqual(source.discover_catalog('B-2303',ledger),{})
        self.assertEqual(ledger['requests'][0]['status'],'unavailable')

    def test_challenge_is_never_treated_as_a_catalog(self):
        ledger={'requests':[]};response=MagicMock()
        response.status=200;response.geturl.return_value=CATALOG
        response.read.return_value=b'<html>Incapsula challenge</html>'
        with patch.object(source,'build_opener') as opener:
            opener.return_value.open.return_value.__enter__.return_value=response
            with self.assertRaisesRegex(RuntimeError,'controles de acceso'):source.discover_catalog('B-2303',ledger)
        self.assertEqual(ledger['requests'][0]['status'],'access_control')

    def test_external_download_and_redirect_are_rejected_before_request(self):
        with patch.object(source,'build_opener') as opener:
            with self.assertRaises(ValueError):source.fetch('B-2303','2026-09',{'requests':[]},url='https://other.example/file.xls')
            opener.assert_not_called()
        with self.assertRaises(ValueError):
            source.OfficialRedirects().redirect_request(None,None,302,'Found',{},'https://other.example/file.xls')


if __name__=='__main__':unittest.main()
