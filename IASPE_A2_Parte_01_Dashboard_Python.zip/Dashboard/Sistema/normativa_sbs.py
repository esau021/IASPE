"""Módulo independiente de consulta y vigilancia de fuentes contables SBS.
No interactúa con motor, supuestos, escenarios ni datos financieros.
"""
from __future__ import annotations
import hashlib
import json
import re
import copy
from html.parser import HTMLParser
from urllib.parse import urljoin
import threading
from datetime import datetime, timezone, date
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
CATALOG = json.loads((ROOT / 'data' / 'normativa_sbs_catalogo.json').read_text(encoding='utf-8'))
STATE_PATH = ROOT / 'data' / 'normativa_sbs_vigilancia.json'
LOCK = threading.RLock()
MAX_DOCUMENT_BYTES = 24 * 1024 * 1024
MAX_MONITOR_BYTES = 6 * 1024 * 1024


def _utc():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def _load():
    try:
        data = json.loads(STATE_PATH.read_text(encoding='utf-8'))
        if isinstance(data, dict):
            return data
    except (ValueError, OSError):
        pass
    return {'reviewed': [], 'fingerprints': {}, 'alerts': [], 'lastCheck': None, 'checkErrors': [], 'manualVersions': {}}


def _save(data):
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = STATE_PATH.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(STATE_PATH)


def _initial_alerts():
    return [dict(key='norma:' + n['id'], title='Resolución SBS N.° ' + n['numero'] + ' — ' + n['titulo'],
                 detail=n['relevancia'], type='norma', normaId=n['id'], url=n['url'],
                 priority=n['prioridad'], original=True)
            for n in CATALOG['normas'] if n.get('reviewInitial')]


def _current_catalog(state):
    catalog = copy.deepcopy(CATALOG)
    for doc in catalog['documentos']:
        ver = state.get('manualVersions', {}).get(doc['id'])
        if ver and ver.get('url'):
            doc['url'] = ver['url']
            doc['detalle'] = 'Vigente desde ' + ver['month'] + '/' + str(ver['year'])
    cap4 = next(d for d in catalog['documentos'] if d['id'] == 'manual4')
    catalog['manualPdf'] = cap4['url']
    catalog['manualLabel'] = cap4.get('detalle', 'Capítulo IV vigente')
    return catalog


def snapshot():
    with LOCK:
        state = _load()
        known = _initial_alerts() + state.get('alerts', [])
        reviewed = set(state.get('reviewed', []))
        alerts = [{**item, 'reviewed': item['key'] in reviewed} for item in known]
        return {'catalogo': _current_catalog(state), 'alertas': alerts,
                'unread': sum(not item['reviewed'] for item in alerts),
                'lastCheck': state.get('lastCheck'), 'checkErrors': state.get('checkErrors', [])}


MONTHS = {w: i + 1 for i, w in enumerate('enero febrero marzo abril mayo junio julio agosto setiembre octubre noviembre diciembre'.split())}
MONTHS['septiembre'] = 9
PORTAL_URL = CATALOG['manualPortal']


class _ManualParser(HTMLParser):
    """Recupera los vínculos PDF publicados en la página oficial SBS, con su vigencia."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.text = ''
        self.current = None
        self.href = None
        self.found = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'a':
            self.href = dict(attrs).get('href')
            if self.href and self.href.lower().split('?')[0].endswith('.pdf'):
                # En la SBS el título del capítulo precede a sus enlaces PDF/DOCX.
                chapter = list(re.finditer(r'Cap[ií]tulo\s+(I{1,3}|IV)\s*:', self.text, re.I))
                if chapter:
                    context = self.text[chapter[-1].start():][-600:]
                    match = re.search(r'(enero|febrero|marzo|abril|mayo|junio|julio|agosto|setiembre|septiembre|octubre|noviembre|diciembre)\s*(?:de\s*)?(20\d{2})', context, re.I)
                    if match:
                        month = MONTHS[match.group(1).lower()]
                        year = int(match.group(2))
                        name = chapter[-1].group(1).upper()
                        url = urljoin(PORTAL_URL, self.href)
                        if urlsplit(url).hostname == 'www.sbs.gob.pe':
                            self.found.append((name, year, month, url))

    def handle_data(self, data):
        self.text += data
        if len(self.text)>70000:
            self.text=self.text[-50000:]


def discover_current_manual(page: bytes, today: date | None = None):
    today=today or datetime.now(timezone.utc).date()
    parser=_ManualParser()
    parser.feed(page.decode('utf-8',errors='replace'))
    result={}
    for chapter, year, month, url in parser.found:
        if date(year,month,1)>date(today.year,today.month,1):
            continue  # No presentar documentos anunciados para una vigencia futura.
        doc_id='manual'+str({'I':1,'II':2,'III':3,'IV':4}.get(chapter,0))
        if doc_id=='manual0': continue
        prev=result.get(doc_id)
        if not prev or (year,month)>(prev['year'],int(prev['month'])):
            result[doc_id]={'year':year,'month':f'{month:02d}','url':url}
    return result

def mark_reviewed(keys):
    valid_keys = {a['key'] for a in snapshot()['alertas']}
    if not isinstance(keys, list) or len(keys) > 100:
        raise ValueError('Indica una lista válida de notificaciones.')
    keys = [k for k in keys if isinstance(k, str) and k in valid_keys]
    with LOCK:
        data = _load()
        data['reviewed'] = sorted(set(data.get('reviewed', [])) | set(keys))
        _save(data)
    return snapshot()


def _fetch(url, limit, timeout):
    parts = urlsplit(url)
    if parts.scheme != 'https' or parts.hostname != 'www.sbs.gob.pe':
        raise ValueError('Solo se permiten documentos públicos de la SBS.')
    req = Request(url, headers={'User-Agent': 'IASPE-NormativaSBS/1.0 (consulta pública)', 'Accept': 'application/pdf,text/html,*/*'})
    with urlopen(req, timeout=timeout) as response:
        final = urlsplit(response.geturl())
        if final.scheme != 'https' or final.hostname != 'www.sbs.gob.pe':
            raise ValueError('La respuesta redirigió fuera del portal oficial SBS.')
        blob = response.read(limit + 1)
        if len(blob) > limit:
            raise ValueError('El documento supera el límite de descarga de seguridad.')
        return blob


def check_publications():
    """Compara versiones vigentes de capítulos del Manual, sin aplicar normas a IASPE."""
    pending=[]; errors=[]
    with LOCK:
        state=_load()
        versions=dict(state.get('manualVersions',{}))
        existing={a['key'] for a in state.get('alerts',[])}
        try:
            page=_fetch(PORTAL_URL,MAX_MONITOR_BYTES,timeout=12)
            discovered=discover_current_manual(page)
            if not discovered:
                raise ValueError('No se identificaron los enlaces PDF vigentes en el portal.')
            for doc_id, record in discovered.items():
                prior=versions.get(doc_id)
                # En la primera comprobación se establece la línea base; no hay actualización confirmada.
                if prior and prior.get('url') != record['url']:
                    digest=hashlib.sha256(record['url'].encode()).hexdigest()[:16]
                    key=f'manual:{doc_id}:{digest}'
                    if key not in existing:
                        chapter=doc_id[-1]
                        pending.append({'key':key,'title':f'Nueva versión SBS del Manual — Capítulo {chapter}',
                                        'detail':f'Aplicación desde {record["month"]}/{record["year"]}. Revisar cambios antes de utilizarlos en el IASPE.',
                                        'type':'manual','normaId':None,'url':record['url'],
                                        'priority':'Alta','original':False,'detectedAt':_utc()})
                        existing.add(key)
                versions[doc_id]=record
        except Exception as exc:
            errors.append('Manual SBS: '+type(exc).__name__+'. No se pudo verificar la versión PDF.')
        state['manualVersions']=versions
        # Avisar cambios del compendio solo después de establecer la primera huella.
        source=next((x for x in CATALOG['seguimiento'] if x['id']=='sbs_cambios'),None)
        if source:
            try:
                blob=_fetch(source['url'],MAX_MONITOR_BYTES,timeout=11)
                digest=hashlib.sha256(blob).hexdigest()
                fingerprints=dict(state.get('fingerprints',{}))
                previous=fingerprints.get(source['id'])
                if previous and previous!=digest:
                    key='cambio:historial:'+digest[:16]
                    if key not in existing:
                        pending.append({'key':key,'title':'SBS actualizó el historial de modificaciones',
                                        'detail':'Revisar el documento oficial. Una actualización no implica un cambio contable aplicado al banco.',
                                        'type':'fuente','normaId':None,'url':source['url'],
                                        'priority':'Media','original':False,'detectedAt':_utc()})
                fingerprints[source['id']]=digest
                state['fingerprints']=fingerprints
            except Exception as exc:
                errors.append('Historial SBS: '+type(exc).__name__+'. No se pudo verificar el historial.')
        state['alerts']=(state.get('alerts',[])+pending)[-80:]
        state['lastCheck']=_utc()
        state['checkErrors']=errors
        _save(state)
    return snapshot()

def download_pdf(doc_id):
    if not isinstance(doc_id, str) or not re.fullmatch('[a-z0-9]{2,30}', doc_id):
        raise ValueError('Documento no permitido.')
    doc = next((doc for doc in _current_catalog(_load())['documentos'] if doc['id'] == doc_id and doc.get('pdf')), None)
    if doc is None:
        raise ValueError('Documento no incluido en la biblioteca.')
    content = _fetch(doc['url'], MAX_DOCUMENT_BYTES, timeout=40)
    if not content.startswith(b'%PDF-'):
        raise ValueError('La SBS no devolvió un PDF válido. Abre la fuente oficial para descargarlo.')
    return content, 'SBS_' + doc_id + '.pdf'
