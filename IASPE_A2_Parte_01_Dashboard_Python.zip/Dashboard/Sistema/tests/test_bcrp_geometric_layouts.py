"""Layout variation tests; synthetic pages are not evidence for real PDFs."""
from pathlib import Path
import sys

import pytest
import pymupdf

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from bcrp_documents import parse_document, current_forecasts


def varied_report(missing=False, duplicate=False):
    """Two historical years, three revisions for one year, one for another."""
    pdf=pymupdf.open()
    page=pdf.new_page(width=900,height=500)
    page.insert_text((50,45),'Diciembre 2028',fontsize=13)
    page.insert_text((220,100),'RESUMEN DE LAS PROYECCIONES',fontsize=13)
    for y in (130,160,190,280):
        page.draw_line((50,y),(830,y),width=.6)
    for x in (350,430,510,750,830):
        page.draw_line((x,130),(x,190),width=.6)
    for x in (590,670):
        page.draw_line((x,160),(x,190),width=.6)
    for x,label in [(370,'2026'),(450,'2027'),(620,'2028*'),(770,'2029*')]:
        page.insert_text((x,150),label,fontsize=10)
    for x,label in [(520,'RI Jun.28'),(600,'RI Set.28'),(680,'RI Dic.28'),(760,'RI Dic.28')]:
        page.insert_text((x,180),label,fontsize=9)
    page.insert_text((60,220),'1. Producto bruto interno',fontsize=11)
    page.insert_text((60,260),'6. Inflación (fin de periodo)',fontsize=11)
    pbi=['2,8','3,0','3,4','3,2','3,1','3,0']
    inflation=['2,1','2,0','2,8','2,5','2,2','2,0']
    for i,x in enumerate((380,460,540,620,700,780)):
        if not (missing and i==4):
            page.insert_text((x,220),pbi[i],fontsize=11)
        page.insert_text((x,260),inflation[i],fontsize=11)
    if duplicate:
        page.insert_text((718,220),'9,9',fontsize=11)
    body=pdf.tobytes()
    pdf.close()
    return body


def test_variable_number_of_years_and_revisions():
    parsed=parse_document(varied_report(),document_name='any-filename.pdf')
    assert parsed['document']['edition']=='2028-12'
    assert len(parsed['records'])==12
    columns=parsed['tables'][0]['columns']
    assert len([c for c in columns if c['year']=='2028'])==3
    assert len([c for c in columns if c['year']=='2029'])==1
    assert len([c for c in columns if c['kind']=='historical'])==2
    current=current_forecasts(parsed['records'])
    assert {(r['variable'],r['year'],r['value']) for r in current}=={
        ('pbi','2028',3.1),('pbi','2029',3.0),
        ('inflacion','2028',2.2),('inflacion','2029',2.0)}


@pytest.mark.parametrize('options',[{'missing':True},{'duplicate':True}])
def test_incomplete_or_ambiguous_geometric_cell_is_rejected(options):
    with pytest.raises(ValueError):
        parse_document(varied_report(**options),document_name='incomplete.pdf')
