"""Monitor de publicaciones SBS/BCRP en modo lectura.

No descarga archivos al repositorio de IASPE, no modifica observaciones ni llama al
recálculo. Revisa cada reporte por separado, sin inferir que toda la SBS publica
al mismo tiempo. Un error de red nunca equivale a «fuente al día».
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
import json
import os
from copy import deepcopy
from pathlib import Path
import re
import threading
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[2] / 'IASPE'
OUTPUT = ROOT / 'Scraper' / 'Actualizacion' / 'output'
CACHE = OUTPUT / 'monitor_fuentes.json'
# Perfil del usuario: conserva las revisiones incluso si se reemplaza el ZIP o cambia el puerto.
SEEN = (Path(os.environ.get('LOCALAPPDATA') or (Path.home() / '.local' / 'share'))
        / 'IASPE' / 'monitor_revisadas.json')
TTL = timedelta(hours=1)
MONTHS = ('Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre')
ABBR = ('en','fe','ma','ab','my','jn','jl','ag','se','oc','no','di')
BCRP_CODES = {'PN07845NM': 'Tasa activa de tarjetas', 'PN07847NM': 'Tasa activa de consumo',
              'PN07814NM': 'Tasa pasiva de depósitos', 'PN09406SM': 'Compras con tarjetas'}
REPORTS = {
    'personal_banca': [('B-2305', 'Personal de banca múltiple')],
    'personal_financieras': [('B-3202', 'Personal de financieras')],
    'ratios': [('B-2401', 'Indicadores bancarios I'), ('B-2402', 'Indicadores bancarios II'),
               ('B-3301', 'Indicadores financieras I'), ('B-3302', 'Indicadores financieras II')],
    'tarjetas': [('B-2363', 'Tarjetas de crédito')],
    'morosidad': [('B-2362', 'Morosidad de tarjetas')],
    'cartera': [('B-2389', 'Cartera de consumo')],
    'estados_financieros': [('B-2201', 'Bancos'), ('B-3101', 'Financieras')],
    'ahorro_moneda': [('B-2201', 'Estados financieros base del ahorro MN/ME')],
    'tasas_mercado': [(c, BCRP_CODES[c]) for c in BCRP_CODES],
}
LABELS = {
    'personal_banca': 'Personal · Banca Múltiple',
    'personal_financieras': 'Personal · Empresas Financieras',
    'ratios': 'Indicadores financieros SBS',
    'tarjetas': 'Número de tarjetas de crédito',
    'morosidad': 'Morosidad de tarjetas',
    'cartera': 'Cartera de consumo',
    'estados_financieros': 'Estados financieros SBS',
    'ahorro_moneda': 'Depósitos de ahorro MN y ME',
    'tasas_mercado': 'Series financieras BCRP',
}
LOCAL_GLOBS = {
    'B-2305': ('Numero_trabajadores/fuentes/B-2305', 'B-2305-*'),
    'B-3202': ('Numero_trabajadores/fuentes/B-3202', 'B-3202-*'),
    'B-2401': ('Ratios_financieros_mercado/fuentes/B-2401', 'B-2401-*'),
    'B-2402': ('Ratios_financieros_mercado/fuentes/B-2402', 'B-2402-*'),
    'B-3301': ('Ratios_financieros_mercado/fuentes/B-3301', 'B-3301-*'),
    'B-3302': ('Ratios_financieros_mercado/fuentes/B-3302', 'B-3302-*'),
    'B-2363': ('Numero_tarjetas/fuentes', 'B-2363_*'),
    'B-2362': ('Morosidad_tarjetas/fuentes', 'B-2362_*'),
    'B-2389': ('Cartera_consumo_mercado/fuentes', 'B-2389-*'),
}
VALID_EXCEL = (b'PK\x03\x04', bytes.fromhex('D0CF11E0A1B11AE1'))


def _ym(year, month):
    return f'{year:04d}-{month:02d}'


def _prev(year, month):
    return (year - 1, 12) if month == 1 else (year, month - 1)


def _next(year, month):
    return (year + 1, 1) if month == 12 else (year, month + 1)


def _last_from_file(path, code):
    name = path.name
    patterns = (rf'{re.escape(code)}[-_](\d{{4}})[-_](\d{{1,2}})\.',
                rf'{re.escape(code)}[-_](?:[a-z]{{2}})(\d{{4}})\.')
    match = re.match(patterns[0], name, re.I)
    if match:
        year, month = int(match[1]), int(match[2]); return _ym(year, month) if 1 <= month <= 12 else None
    match = re.match(patterns[1], name, re.I)
    if match:
        code_abbr = name[len(code)+1:len(code)+3].lower()
        if code_abbr in ABBR:
            return _ym(int(match[1]), ABBR.index(code_abbr)+1)
    return None


def _panel_month():
    try:
        info = json.loads((ROOT / 'Scraper/EEFF_Benchmark/output/auditoria_panel.json').read_text(encoding='utf-8'))
        periods = [row['last'] for row in info.get('files', []) if row.get('sheet') == 'balance' and re.fullmatch(r'\d{4}-\d{2}', str(row.get('last','')))]
        return max(periods) if periods else None
    except (OSError, ValueError, TypeError, KeyError):
        return None


def _local_month(code):
    if code in ('B-2201', 'B-3101'):
        return _panel_month()
    location = LOCAL_GLOBS.get(code)
    if not location:
        return None
    directory, pattern = location
    folder = ROOT / 'Scraper' / directory
    try:
        periods = [_last_from_file(p, code) for p in folder.glob(pattern) if p.is_file() and p.stat().st_size >= 512]
        return max((p for p in periods if p), default=None)
    except OSError:
        return None


def _bcrp_local(code):
    output = OUTPUT / ('compras_bcrp.json' if code == 'PN09406SM' else 'tasas_mercado.json')
    model = {'PN09406SM':'03', 'PN07845NM':'13', 'PN07847NM':'14', 'PN07814NM':'15'}[code]
    try:
        rows = json.loads(output.read_text(encoding='utf-8'))
        return max((p for p,v in rows.get(model,{}).items() if re.fullmatch(r'\d{4}-\d{2}',p) and v is not None), default=None)
    except (OSError, ValueError, TypeError):
        pass
    # La distribución original ya contiene una base BCRP observada aunque
    # todavía no se haya ejecutado Actualizar fuentes en esta instalación.
    if code in ('PN07845NM', 'PN07847NM', 'PN07814NM'):
        raw = ROOT / 'Data bruta/BCRP/series_tasa_tarjetas.json'
        field = {'PN07845NM':'tasa_tarjetas_pct',
                 'PN07847NM':'tasa_consumo_mas360_pct',
                 'PN07814NM':'tasa_deposito_181_360_pct'}[code]
        try:
            rows = json.loads(raw.read_text(encoding='utf-8')).get('observados', [])
            return max((str(row.get('fecha',''))[:7] for row in rows
                        if isinstance(row.get(field),(int,float)) and re.fullmatch(r'\d{4}-\d{2}',str(row.get('fecha',''))[:7])),default=None)
        except (ValueError, OSError, TypeError):
            pass
    return None


def _sbs_url(code, year, month):
    return f'https://intranet2.sbs.gob.pe/estadistica/financiera/{year}/{MONTHS[month-1]}/{code}-{ABBR[month-1]}{year}.XLS'


def _probe_excel(url):
    """Return True (valid Excel), False (404), or None (unverified)."""
    request = Request(url, headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) IASPE/1.0',
        'Accept':'application/vnd.ms-excel,application/octet-stream,*/*',
        'Range':'bytes=0-15',
    })
    try:
        with urlopen(request, timeout=7) as response:
            header = response.read(8)
            return any(header.startswith(magic) for magic in VALID_EXCEL) or None
    except HTTPError as exc:
        return False if exc.code == 404 else None
    except (OSError, URLError, ValueError, TimeoutError):
        return None


def _probe_bcrp(code, today=None):
    today = today or date.today()
    url = f'https://estadisticas.bcrp.gob.pe/estadisticas/series/api/{code}/json/2026-8/{today.year}-{today.month}/esp'
    with urlopen(Request(url, headers={'User-Agent': 'IASPE/1.0'}), timeout=10) as response:
        payload = json.loads(response.read(1024 * 1024).decode('utf-8'))
    rows = payload.get('periods')
    if not isinstance(rows, list):
        raise ValueError('BCRP no entregó los períodos de la serie')
    months = {a.lower(): i+1 for i,a in enumerate(('Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'))}
    periods = []
    for row in rows:
        try:
            label = row['name'].split('.')
            month = months[label[0][:3].lower()]
            value = row.get('values', [None])[0]
            if value not in ('', None, 'n.d.', 'N.D.'):
                periods.append(_ym(int(label[1]), month))
        except (KeyError, IndexError, TypeError, ValueError):
            continue
    if not periods:
        raise ValueError('BCRP sin datos mensuales verificables')
    return max(periods)


def _check_report(code, label, today, probe=None, bcrp_probe=None):
    local = _bcrp_local(code) if code.startswith('PN') else _local_month(code)
    result = {'code':code,'name':label,'localPeriod':local,'remotePeriod':None,'status':'no_verificado'}
    if code.startswith('PN'):
        try:
            remote = (bcrp_probe or _probe_bcrp)(code, today)
            result['remotePeriod'] = remote
            result['status'] = 'no_verificado' if not local else ('nuevo' if remote > local else 'al_dia')
        except (ValueError, OSError, URLError, TimeoutError, KeyError):
            pass
        return result
    if not local:
        return result
    base_year, base_month = map(int, local.split('-'))
    year, month = _next(base_year, base_month)
    target_year, target_month = today.year, today.month
    # Cota de seis consultas por reporte para limitar carga sobre portales SBS.
    dates = []
    while (year, month) <= (target_year, target_month) and len(dates) < 6:
        dates.append((year, month)); year, month = _next(year, month)
    if not dates:
        result['remotePeriod'] = local
        result['status'] = 'al_dia'
        return result
    remote = local
    missing = 0
    unknown = 0
    for yy, mm in dates:
        verdict = (probe or _probe_excel)(_sbs_url(code, yy, mm))
        if verdict is True:
            remote = _ym(yy, mm)
        elif verdict is False:
            missing += 1
        else:
            unknown += 1
    result['remotePeriod'] = remote if remote != local else None
    if remote != local:
        result['status'] = 'nuevo'
    elif not unknown and (probe or _probe_excel)(_sbs_url(code, base_year, base_month)) is not True:
        # Todos los meses posteriores parecen ausentes, pero no pudimos
        # confirmar ni siquiera el reporte que figura en el histórico local.
        result['status'] = 'no_verificado'
    elif unknown or len(dates) == 6 and (year,month) <= (target_year,target_month):
        result['status'] = 'no_verificado'
    else:
        result['status'] = 'al_dia'
    return result


def check_all(today=None, probe=None, bcrp_probe=None):
    today = today or date.today()
    tasks = [(source, code, label) for source, reports in REPORTS.items() for code,label in reports]
    unique = {(code,label) for _,code,label in tasks}
    with ThreadPoolExecutor(max_workers=7) as pool:
        jobs = {pool.submit(_check_report, code, label, today, probe, bcrp_probe): (code,label) for code,label in unique}
        found = {}
        for job in as_completed(jobs):
            code,label = jobs[job]
            try:
                found[(code,label)] = job.result()
            except Exception:
                found[(code,label)] = {'code':code,'name':label,'localPeriod':None,'remotePeriod':None,'status':'no_verificado'}
    sources=[]
    for source, reports in REPORTS.items():
        detail=[found[(code,label)] for code,label in reports]
        has_new=any(item['status']=='nuevo' for item in detail)
        has_unknown=any(item['status']=='no_verificado' for item in detail)
        sources.append({'id':source,'name':LABELS[source], 'status':'nuevo' if has_new else 'no_verificado' if has_unknown else 'al_dia',
                        'partial':has_new and has_unknown,'reports':detail})
    counts={k:sum(item['status']==k for item in sources) for k in ('nuevo','al_dia','no_verificado')}
    return {'checkedAt':datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'sources':sources,'counts':counts,
            'note':'Se detectan períodos nuevos; las revisiones de cifras de un período ya descargado requieren actualizar la fuente.'}


class Monitor:
    def __init__(self):
        self.lock=threading.RLock()
        self.checking=False
        self.result=None
        self._last=None
        self.seen={}
        self._load()
        self._load_seen()

    def _load(self):
        try:
            r=json.loads(CACHE.read_text(encoding='utf-8'))
            if isinstance(r, dict) and isinstance(r.get('sources'),list):
                self.result=r
                self._last=datetime.fromisoformat(r['checkedAt'])
        except (ValueError, OSError, KeyError, TypeError):
            pass

    @staticmethod
    def _report_key(source, report):
        """Identidad estable: la consulta puede repetirse pero el período no."""
        return f"{source.get('id','')}|{report.get('code','')}|{report.get('remotePeriod','')}"

    def _load_seen(self):
        try:
            result=json.loads(SEEN.read_text(encoding='utf-8'))
            self.seen={str(k):str(v) for k,v in result.items() if isinstance(k,str)} if isinstance(result,dict) else {}
        except (ValueError,OSError,TypeError):
            self.seen={}

    def acknowledge(self, keys):
        """Revisada no significa descargada ni aplicada a los modelos."""
        if not isinstance(keys,list) or not keys or len(keys)>50:
            raise ValueError('Selecciona una o más notificaciones válidas.')
        with self.lock:
            visible={self._report_key(source,report)
                     for source in (self.result or {}).get('sources',[])
                     for report in source.get('reports',[])
                     if report.get('status')=='nuevo' and report.get('remotePeriod')}
            accepted=[]
            for key in keys:
                if not isinstance(key,str) or key not in visible:
                    raise ValueError('La publicación ha cambiado. Comprueba las fuentes nuevamente.')
                accepted.append(key)
            timestamp=datetime.now(timezone.utc).isoformat(timespec='seconds')
            for key in accepted:
                self.seen[key]=timestamp
            SEEN.parent.mkdir(parents=True,exist_ok=True)
            destination=SEEN.with_suffix('.tmp')
            destination.write_text(json.dumps(self.seen,ensure_ascii=False,indent=2),encoding='utf-8')
            destination.replace(SEEN)
            return self.snapshot(refresh=False)

    def _apply_reviewed(self, result):
        for source in result.get('sources', []):
            for report in source.get('reports', []):
                if report.get('status')=='nuevo' and report.get('remotePeriod'):
                    key=self._report_key(source,report)
                    report['alertKey']=key
                    report['reviewed']=key in self.seen
        result['unreviewedSources']=sum(any(r.get('status')=='nuevo' and not r.get('reviewed')
                                           for r in s.get('reports',[])) for s in result.get('sources',[]))
        return result

    @staticmethod
    def _manual_period_for(source_id, code):
        """Evita volver a avisar sobre períodos que ya se incorporaron manualmente.

        Solo usa correspondencias directas entre reporte y serie; no infiere
        que la carga de una cuenta cubra un estado financiero entero.
        """
        relation={('tarjetas','B-2363'):'01',
                  ('tasas_mercado','PN09406SM'):'03',
                  ('tasas_mercado','PN07845NM'):'13',
                  ('tasas_mercado','PN07847NM'):'14',
                  ('tasas_mercado','PN07814NM'):'15'}
        model=relation.get((source_id,code))
        if not model:return None
        path=ROOT.parent / 'Dashboard' / 'Sistema' / 'data' / 'observaciones.json'
        try:
            manual=json.loads(path.read_text(encoding='utf-8')).get(model,{})
            return max((key for key,value in manual.items()
                        if re.fullmatch(r'\d{4}-\d{2}',key)
                        and isinstance(value,(int,float)) and not isinstance(value,bool)),default=None)
        except (OSError,ValueError,TypeError,AttributeError):
            return None

    def _reconcile_downloaded(self, result):
        # Al pulsar Actualizar selección pueden guardarse nuevos XLS locales.
        # No mantener una alerta ya atendida durante las cuatro horas de caché.
        for source in result.get('sources', []):
            for report in source.get('reports', []):
                remote = report.get('remotePeriod')
                if report.get('status') != 'nuevo' or not remote:
                    continue
                local = (_bcrp_local(report['code']) if report['code'].startswith('PN')
                         else _local_month(report['code']))
                manual=self._manual_period_for(source.get('id'),report['code'])
                local=max((x for x in (local,manual) if x),default=None)
                if local and local >= remote:
                    report['status'] = 'al_dia'
                    report['localPeriod'] = local
            details=source.get('reports',[])
            if details:
                unknown = any(r.get('status')=='no_verificado' for r in details)
                newer = any(r.get('status')=='nuevo' for r in details)
                source['status'] = 'nuevo' if newer else 'no_verificado' if unknown else 'al_dia'
                source['partial'] = newer and unknown
        result['counts']={kind:sum(s.get('status')==kind for s in result.get('sources',[]))
                          for kind in ('nuevo','al_dia','no_verificado')}
        return result

    def snapshot(self, refresh=True, force=False):
        with self.lock:
            t=datetime.now(timezone.utc)
            if refresh and not self.checking and (force or not self._last or t-self._last >= TTL):
                self.checking=True
                threading.Thread(target=self._run,daemon=True,name='iaspe-monitor-sbs').start()
            result = self._reconcile_downloaded(deepcopy(self.result or {'checkedAt':None,'sources':[], 'counts':{'nuevo':0,'al_dia':0,'no_verificado':0}}))
            result = self._apply_reviewed(result)
            result['checking']=self.checking
            result['stale']=not self._last or t-self._last >= TTL
            return result

    def _run(self):
        try:
            result=check_all()
            with self.lock:
                self.result=result
                self._last=datetime.fromisoformat(result['checkedAt'])
            try:
                OUTPUT.mkdir(parents=True,exist_ok=True)
                temp=CACHE.with_suffix('.tmp')
                temp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
                temp.replace(CACHE)
            except OSError:
                pass
        except Exception:
            with self.lock:
                self.result={'checkedAt':datetime.now(timezone.utc).isoformat(timespec='seconds'),
                             'sources':[{'id':id,'name':LABELS[id],'status':'no_verificado','partial':False,'reports':[]} for id in REPORTS],
                             'counts':{'nuevo':0,'al_dia':0,'no_verificado':len(REPORTS)},'note':'No se pudieron verificar las publicaciones.'}
                self._last=datetime.now(timezone.utc)
        finally:
            with self.lock:
                self.checking=False

MANAGER = Monitor()
