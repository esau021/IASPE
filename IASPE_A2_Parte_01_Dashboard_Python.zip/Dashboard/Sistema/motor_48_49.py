"""IASPE M48 y M49: mercado total y amortizaciones propias por cartera.

M48: regresión anual sobre históricos SBS y macroeconomía del IASPE.
M49: identidad de cartera con compras TC M01/M03/M04, disposiciones RC,
      saldos M05/M06, desembolsos PE y castigos. Apertura comercial separada.
Los escenarios recalculan ambos módulos desde el contexto del Dashboard.
"""
from __future__ import annotations
import json
import math
from datetime import datetime, timedelta
from pathlib import Path
import numpy as np
from motor_33_45 import _read_rows


def _dir(root, id_):
    from rutas import buscar_modelo
    return buscar_modelo(root, id_)


def _annual_output(path, col):
    result={}
    for row in _read_rows(path,'Anual'):
        year=row.get('A')
        if isinstance(year,(int,float)) and isinstance(row.get(col),(int,float)):
            result[int(year)]=float(row[col])
    return result


def _rows(points):
    return [dict(year=y,date=f'{y}-12-01',value=float(v),
                 status='observed' if y<=2025 else 'assumed' if y==2026 else 'forecast')
            for y,v in sorted(points.items()) if v is not None and math.isfinite(float(v))]



def _model_rows(mid,values):
    rows=_rows(values)
    if mid in ('49_tc','49_rc','49_pe'):
        for row in rows:
            if row['year']<=2025:
                row['status']='assumed'  # Apertura, no dato contable observado.
    return rows

def _model(mid,name,vals,unit,dependencies,source,method):
    return {'id':mid,'name':name,'unit':unit,'frequency':'annual',
        'kind':'derived','method':method,'annual':_model_rows(mid,vals),'monthly':[],
        'sourceFiles':[str(source)],'dependencies':dependencies,'inputs':[],
        'coefficients':[], 'statistics':{},'scenarioSupport':True,
        'canUpdate':True,'status':'ok','reestimated':True}


def _reference(root):
    f48=_dir(root,'48')/'Output'/'Pronostico.xlsx'
    f49=_dir(root,'49')/'Output'/'Pronostico.xlsx'
    fprod=_dir(root,'49')/'01_Apertura_TC_RC_PE'/'Output'/'Pronostico.xlsx'
    market=_annual_output(f48,'C')
    bf_share={k:v*100 for k,v in _annual_output(f48,'K').items()}
    rev=_annual_output(f49,'F');nrev=_annual_output(f49,'K')
    compras=_annual_output(f49,'C');disb=_annual_output(f49,'H')
    disposiciones_rc=_annual_output(f49,'M')
    trev={k:v*100 for k,v in _annual_output(f49,'G').items()}
    tnrev={k:v*100 for k,v in _annual_output(f49,'L').items()}
    tc=_annual_output(fprod,'L');rc=_annual_output(fprod,'M')
    pe=_annual_output(fprod,'N')
    part_rc={k:v*100 for k,v in _annual_output(fprod,'I').items()}
    total={y:rev[y]+nrev[y] for y in set(rev)&set(nrev)}
    return [( '48','Cartera total de consumo de la banca múltiple',market,'S/ millones', ['05','06'],f48,'MCO de variación logarítmica; PBI, desempleo rezagado y TPM rezagada'),
            ('48_cuota','Participación de Falabella en consumo del mercado',bf_share,'%', ['05','06','48'],f48,'M05 + M06, dividido entre M48'),
            ('49','Amortizaciones de consumo de Falabella',total,'S/ millones',['01','03','04','05','06'],f49,'Identidad de saldos, compras TC, disposiciones RC, desembolsos PE y castigos'),
            ('49_rev','Amortización consumo revolvente',rev,'S/ millones',['01','03','04','05'],f49,'M05 inicial + compras TC + disposiciones RC - M05 final - castigos REV'),
            ('49_nrev','Amortización consumo no revolvente',nrev,'S/ millones',['06'],f49,'Amortización implícita M06'),
            ('49_compras','Compras anuales de tarjetas Falabella',compras,'S/ millones',['01','03','04'],f49,'M01 × M03 × M04; calibración histórica 2025'),
            ('49_desembolsos','Desembolsos no revolventes',disb,'S/ millones',['06'],f49,'Intensidad histórica de desembolsos 2025'),
            ('49_disposiciones_rc','Disposiciones de RappiCash',disposiciones_rc,'S/ millones',['49_compras'],f49,'Flujo histórico RC 2025; futuro: RC/TC medio de 2024 y 2025'),
            ('49_tasa_rev','Tasa de amortización revolvente',trev,'%', ['49_rev'],f49,'Amortización / (saldo inicial + compras TC + disposiciones RC)'),
            ('49_tasa_nrev','Tasa de amortización no revolvente',tnrev,'%', ['49_nrev'],f49,'Amortización / (saldo inicial + desembolsos)'),
            ('49_tc','Amortizaciones de tarjetas de crédito',tc,'S/ millones',['49_rev','49_part_rc'],fprod,'M49 revolvente × (1 - participación de RappiCash)'),
            ('49_rc','Amortizaciones de RappiCash',rc,'S/ millones',['49_rev','49_part_rc'],fprod,'M49 revolvente × participación de RappiCash'),
            ('49_pe','Amortizaciones de préstamos efectivos',pe,'S/ millones',['49_nrev'],fprod,'Igual a M49 no revolvente'),
            ('49_part_rc','Participación de RappiCash en salidas revolventes',part_rc,'%',[],fprod,'Histórico de salidas implícitas de TC y RC; primera diferencia media 2023-2025')]


def build_registry(root):
    return [_model(*spec) for spec in _reference(root)]


def _scraper_close(root, fallback):
    """Cierre basado en último mes SBS homólogo; no convierte agosto en diciembre.

    Si todavía no se ha descargado un nuevo mes, reproduce el Input vigente.
    """
    source=Path(root).parent/'Scraper'/'Cartera_consumo_mercado'/'output'/'Cartera_consumo_banca_multiple.xlsx'
    if not source.is_file():return fallback
    monthly={}
    for entry in _read_rows(source,'Mensual'):
        raw=entry.get('A')
        if isinstance(raw,(int,float)):
            date=(datetime(1899,12,30)+timedelta(days=float(raw))).strftime('%Y-%m')
        else:date=str(raw)[:7]
        if len(date)!=7 or date[:4] not in ('2025','2026'):continue
        if isinstance(entry.get('B'),(int,float)) and isinstance(entry.get('C'),(int,float)):
            monthly[date]=(float(entry['B']),float(entry['C']))
    valid=[m for m in range(1,13) if f'2026-{m:02d}' in monthly and f'2025-{m:02d}' in monthly]
    if not valid:return fallback
    m=max(valid)
    past,actual=monthly[f'2025-{m:02d}'],monthly[f'2026-{m:02d}']
    dec2025=monthly.get('2025-12')
    if not dec2025 or min(*past,*actual,*dec2025)<=0:raise ValueError('M48: stock SBS no positivo en cierre')
    # En diciembre la proyección se sustituye exactamente por lo observado.
    return ((actual[0],actual[1]) if m==12 else
            (dec2025[0]*actual[0]/past[0],dec2025[1]*actual[1]/past[1]))


def _recalculate_market(models, root, changes):
    f48=_dir(root,'48')
    history={int(x['A']):x for x in _read_rows(f48/'Input'/'Base_modelo.xlsx','Anual')
             if isinstance(x.get('A'),(float,int)) and 2010<=int(x['A'])<=2026}
    if len(history)!=17:raise ValueError('M48: histórico de mercado incompleto')
    past={y:float(row['D']) for y,row in history.items()}
    ref=(float(history[2026]['B']),float(history[2026]['C']))
    rev,nonrev=_scraper_close(root,ref)
    past[2026]=rev+nonrev
    macro={y:{'pbi':float(row['E']),'desempleo':float(row['F']),'tpm':float(row['G'])}
           for y,row in history.items()}
    cfg=json.loads((f48/'Script'/'escenario_base.json').read_text(encoding='utf-8'))
    macro.update({int(y):{k:float(v) for k,v in d.items()} for y,d in cfg['macros'].items()})
    # Las proyecciones macro no modifican los coeficientes estimados con la muestra
    # histórica/base; únicamente sus valores futuros del modelo.
    def x(y,m):return [1.0,m[y]['pbi'],m[y-1]['desempleo']-m[y-2]['desempleo'],m[y-1]['tpm']]
    X=np.asarray([x(y,macro) for y in range(2012,2027)],dtype=float)
    Y=np.asarray([100*math.log(past[y]/past[y-1]) for y in range(2012,2027)],dtype=float)
    coef=np.linalg.lstsq(X,Y,rcond=None)[0]
    future={y:dict(row) for y,row in macro.items()}
    for key,years in (changes or {}).items():
        if key not in {'pbi','desempleo','tpm'} or not isinstance(years,dict):continue
        for period,val in years.items():
            if len(str(period))==4 and 2026<=int(period)<=2030:
                future[int(period)][key]=float(val)
    # La tasa de 2026 es parte de la muestra estimada; los shocks futuros
    # afectan la senda de 2027 en adelante, sin reestimar la MCO.
    for y in range(2027,2031):
        predicted=float(np.dot(coef,np.asarray(x(y,future),dtype=float)))
        past[y]=past[y-1]*math.exp(predicted/100)
    cuota={}
    for y in past:
        try:bf=next(r['value'] for r in models['05']['annual'] if r['year']==y)+next(r['value'] for r in models['06']['annual'] if r['year']==y)
        except StopIteration:continue
        if past[y]<=0:raise ValueError(f'M48/{y}: saldo de mercado no positivo')
        cuota[y]=100*bf/past[y]
    return {'48':past,'48_cuota':cuota}



def _producto_shares(file):
    # Las salidas incluyen amortización, castigos y posibles ajustes de cartera.
    raw={int(r['A']):r for r in _read_rows(file,'Historico')
         if isinstance(r.get('A'),(int,float))}
    if sorted(raw)!=list(range(2020,2026)):
        raise ValueError('M49 productos: histórico 2020-2025 incompleto')
    shares={}
    for y in range(2021,2026):
        tc=float(raw[y-1]['C'])+float(raw[y]['B'])-float(raw[y]['C'])
        rc=float(raw[y-1]['E'])+float(raw[y]['D'])-float(raw[y]['E'])
        if min(tc,rc)<0 or tc+rc<=0:
            raise ValueError(f'M49 productos/{y}: salidas históricas inválidas')
        shares[y]=rc/(tc+rc)
    # Promedio de las tres primeras diferencias disponibles desde 2023.
    trend=(shares[2025]-shares[2022])/3
    for y in range(2026,2031):
        shares[y]=shares[y-1]+trend
        if not 0<=shares[y]<=1:
            raise ValueError(f'M49 productos/{y}: participación fuera de rango')
    return shares

def _recalculate_amort(models,root):
    f49=_dir(root,'49')
    hist={int(row['A']):row for row in _read_rows(f49/'Input'/'Base_modelo.xlsx','Historico')
          if isinstance(row.get('A'),(float,int))}
    casts={int(row['A']):float(row['B']) for row in _read_rows(f49/'Input'/'Base_modelo.xlsx','Supuestos')
           if isinstance(row.get('A'),(float,int)) and isinstance(row.get('B'),(int,float))}
    def val(mid,y):
        series=next((r['value'] for r in models[mid]['annual'] if int(r['year'])==y),None)
        if series is None:raise ValueError(f'M49: falta {mid}/{y}')
        return float(series)
    calib=float(hist[2025]['B'])/(val('03',2025)*val('04',2025)/val('01',2025))
    ratio=float(hist[2025]['C'])/val('06',2025)
    product_file=f49/'01_Apertura_TC_RC_PE'/'Input'/'Base_productos.xlsx'
    shares=_producto_shares(product_file)
    products={int(r['A']):r for r in _read_rows(product_file,'Historico')
              if isinstance(r.get('A'),(float,int))}
    if any(y not in products for y in (2024,2025)):
        raise ValueError('M49: no se pudo calcular ratio histórico RC / compras TC')
    ratios=[float(products[y]['D'])/float(products[y]['B']) for y in (2024,2025)]
    if any(not 0<rate<1 for rate in ratios):
        raise ValueError('M49: ratios de disposiciones RC inválidos')
    rc_ratio=sum(ratios)/len(ratios)
    datasets={key:{} for key in ['49','49_rev','49_nrev','49_compras','49_desembolsos','49_tasa_rev','49_tasa_nrev',
                                  '49_tc','49_rc','49_pe','49_part_rc','49_disposiciones_rc']}
    datasets['49_part_rc'].update({y:100*p for y,p in shares.items() if y<2025})
    for year in range(2025,2031):
        compras=float(hist[year]['B']) if year<=2025 else val('03',year)*val('04',year)/val('01',year)*calib
        desemb=float(hist[year]['C']) if year<=2025 else val('06',year)*ratio
        disp_rc=float(products[year]['D']) if year<=2025 else compras*rc_ratio
        cast=float(hist[year]['D']) if year<=2025 else casts[year]
        rev,nrev=val('05',year),val('06',year)
        castrev=cast*rev/(rev+nrev);castnrev=cast-castrev
        ar=val('05',year-1)+compras+disp_rc-rev-castrev
        an=val('06',year-1)+desemb-nrev-castnrev
        denomrev=val('05',year-1)+compras+disp_rc; denomnrev=val('06',year-1)+desemb
        if min(denomrev,denomnrev)<=0:raise ValueError(f'M49/{year}: denominador inválido')
        datasets['49'][year]=ar+an
        datasets['49_rev'][year]=ar;datasets['49_nrev'][year]=an
        datasets['49_compras'][year]=compras;datasets['49_desembolsos'][year]=desemb
        datasets['49_disposiciones_rc'][year]=disp_rc
        datasets['49_tasa_rev'][year]=100*ar/denomrev
        datasets['49_tasa_nrev'][year]=100*an/denomnrev
        datasets['49_part_rc'][year]=100*shares[year]
        datasets['49_rc'][year]=ar*shares[year]
        datasets['49_tc'][year]=ar-datasets['49_rc'][year]
        datasets['49_pe'][year]=an
    return datasets


def recalculate(context,changes=None,observations=None):
    models=context['models'];root=Path(context.get('source_root') or context['sourceRoot'])
    data={**_recalculate_market(models,root,changes),**_recalculate_amort(models,root)}
    updated=[]
    for mid,series in data.items():
        m=models[mid]
        old={row['year']:row['value'] for row in m['annual']}
        if set(old)!=set(series) or any(abs(old[y]-value)>1e-7 for y,value in series.items()):
            copy=dict(m,annual=_model_rows(mid,series),series=_model_rows(mid,series),reestimated=True,status='ok')
            updated.append(copy)
    return {'models':updated}
