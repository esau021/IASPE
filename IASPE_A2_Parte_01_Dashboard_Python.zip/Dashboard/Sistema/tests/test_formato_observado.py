"""Formato de procesados: observaciones nuevas, reimportación y fallos seguros."""
from datetime import datetime
from io import BytesIO
import importlib.util
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile

from openpyxl import load_workbook

PROJECT = Path(__file__).resolve().parents[3]
MODULE = PROJECT / 'IASPE/Scraper/Actualizacion/script/conservar_formato_observado.py'
spec = importlib.util.spec_from_file_location('preserve_observed', MODULE)
preserve = importlib.util.module_from_spec(spec)
spec.loader.exec_module(preserve)


class FormatoObservadoTests(unittest.TestCase):
    def _path(self, kind):
        relative = ('Numero_tarjetas/output/SBS_Tarjetas_Consumo_y_Total_Banca_Falabella_2008_2026.xlsx'
                    if kind == 'tarjetas' else 'Morosidad_tarjetas/output/Morosidad_tarjetas_consumo_banca_multiple.xlsx')
        return PROJECT / 'IASPE/Scraper' / relative

    def test_new_month_keeps_original_format_and_values(self):
        for kind in ('tarjetas', 'morosidad'):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory(prefix='iaspe_format_test_') as temp:
                template = self._path(kind).read_bytes()
                before = load_workbook(BytesIO(template), data_only=True)
                generated = load_workbook(BytesIO(template))
                monthly = generated['Mensual']
                if kind == 'tarjetas':
                    dates = [(row[0].value, row[1].value) for row in monthly.iter_rows(min_row=2)
                             if isinstance(row[0].value, (int, float)) and isinstance(row[1].value, (int, float))]
                    year, month = max(dates)
                    year, month = (year + 1, 1) if month == 12 else (year, month + 1)
                    new_row = [year, month, 7500000, 1470000, 7550000, 1470000,
                               100 * 1470000 / 7500000, 100 * 1470000 / 7550000]
                else:
                    last = max(row[0].value for row in monthly.iter_rows(min_row=2) if isinstance(row[0].value, datetime))
                    new_row = [datetime(last.year + (last.month == 12), last.month % 12 + 1, 1), 3.4, 2.4, 2.7]
                monthly.append(new_row)
                monthly.column_dimensions['A'].width = 77
                monthly.row_dimensions[2].height = 42
                generated.create_sheet('Diagnostico_no_autorizado')
                target = Path(temp) / 'observado.xlsx'
                generated.save(target)
                report = preserve.conservar_formato_observado(target, template, tipo=kind)
                after = load_workbook(target, data_only=True)
                self.assertEqual(after.sheetnames, before.sheetnames)
                self.assertEqual(after['Mensual'].max_column, before['Mensual'].max_column)
                self.assertEqual(after['Mensual'].column_dimensions['A'].width, before['Mensual'].column_dimensions['A'].width)
                self.assertEqual(after['Mensual'].row_dimensions[2].height, before['Mensual'].row_dimensions[2].height)
                found = [list(row) for row in after['Mensual'].iter_rows(values_only=True)
                         if (row[0], row[1]) == tuple(new_row[:2])]
                if kind == 'morosidad':
                    found = [list(row) for row in after['Mensual'].iter_rows(values_only=True) if row[0] == new_row[0]]
                self.assertEqual(len(found), 1)
                for actual, expected in zip(found[0], new_row):
                    if isinstance(expected, float):
                        self.assertAlmostEqual(actual, expected, places=12)
                    else:
                        self.assertEqual(actual, expected)
                with ZipFile(BytesIO(template)) as old_zip, ZipFile(target) as new_zip:
                    self.assertEqual(old_zip.namelist(), new_zip.namelist())
                    for name in old_zip.namelist():
                        if not (name.startswith('xl/worksheets/') and name.endswith('.xml')):
                            self.assertEqual(old_zip.read(name), new_zip.read(name), name)
                self.assertIn('Diagnostico_no_autorizado', report['ignoredExtraSheets'])
                once = target.read_bytes()
                preserve.conservar_formato_observado(target, once, tipo=kind)
                self.assertEqual(target.read_bytes(), once)
                generated.close(); before.close(); after.close()

    def test_incompatible_header_does_not_replace_file(self):
        template = self._path('morosidad').read_bytes()
        with tempfile.TemporaryDirectory(prefix='iaspe_format_test_') as temp:
            target = Path(temp) / 'observado.xlsx'
            book = load_workbook(BytesIO(template))
            book['Mensual']['A1'] = 'Fecha cambiada'
            book.save(target); before = target.read_bytes()
            with self.assertRaisesRegex(ValueError, 'encabezados'):
                preserve.conservar_formato_observado(target, template, tipo='morosidad')
            self.assertEqual(target.read_bytes(), before)
            book.close()

    def test_missing_numeric_observation_is_rejected(self):
        template = self._path('morosidad').read_bytes()
        with tempfile.TemporaryDirectory(prefix='iaspe_format_test_') as temp:
            target = Path(temp) / 'observado.xlsx'
            book = load_workbook(BytesIO(template))
            book['Mensual']['B2'] = None
            book.save(target)
            with self.assertRaisesRegex(ValueError, 'vaciaría'):
                preserve.conservar_formato_observado(target, template, tipo='morosidad')
            book.close()


if __name__ == '__main__':
    unittest.main()
