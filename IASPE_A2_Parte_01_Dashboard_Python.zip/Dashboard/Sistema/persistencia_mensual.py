"""Sincronización de series SBS mensuales y regresiones operativas.

Conserva hojas, fórmulas y formatos de los libros de origen. No publica
resultados antes de superar las conciliaciones del motor.
"""
from __future__ import annotations

import math
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np
import statsmodels.api as sm

MODELS = frozenset({'01','02','03','04','05','06','13','14','15'})
MONTHLY = {'01': 'Tarjetas_mensual', '03': 'Compras_mensuales',
           '04': 'Mensual', '05': 'Mensual', '06': 'Mensual',
           '13': 'Mensual', '14': 'Mensual', '15': 'Mensual'}
INPUT_ANNUAL = {'01': ('Macros_anuales','D'), '02': ('Tarjetas_anuales','B'),
                '03': ('Anual','B'),'04':('Anual','B'),'05':('Anual','B'),
                '06':('Anual','B'), '13':('Anual','B'),'14':('Anual','B'),'15':('Anual','B')}
OUT_STATUS = {'01':'E','02':'E','03':'E', '04':'D', '05':'D', '06':'D',
              '13':'C','14':'C','15':'C'}


def month_key(raw):
    if isinstance(raw, (datetime,date)):
        return raw.strftime('%Y-%m')
    if isinstance(raw, (float,int)) and raw > 15000:
        return (date(1899,12,30)+timedelta(days=int(raw))).strftime('%Y-%m')
    return str(raw or '')[:7]


def month_deltas(previous, updated):
    out={}
    for mid,new in updated.items():
        if mid not in previous and mid in {'16_rev', '16_nrev'}:
            continue
        old={month_key(v.get('date')):v for v in previous[mid].get('monthly',[])}
        for row in new.get('monthly',[]):
            k=month_key(row.get('date'))
            past=old.get(k)
            if past is None or (abs(float(past['value'])-float(row['value']))>1e-7 or past.get('status')!=row.get('status')):
                out.setdefault(mid,{})[k]=row
    return out


def _labels(status, original):
    a=str(original or '').strip()
    if status=='observed':
        return 'Observado SBS' if 'SBS' in a else 'Observado'
    if status=='assumed':
        return 'Cierre supuesto' if 'cierre' in a.lower() else 'Supuesto'
    return 'Pronosticado' if 'Pronosticado' in a else 'Proyección' if 'Proyección' in a else 'Pronóstico'


def _index_month(books,path,tab):
    data=books.data(path,tab,350,'J')
    return {month_key(r[0]):i for i,r in enumerate(data,1) if i>1 and r[0] is not None and len(month_key(r[0]))==7}


def _write_months(books,mid,folder,months):
    tab=MONTHLY[mid]
    inp=folder/'Input'/'Base_modelo.xlsx'
    index=_index_month(books,inp,tab)
    raw=books.data(inp,tab,350,'J')
    last=max(index.values(),default=1)
    date_serial=mid=='01'
    output=folder/'Output'/'Pronostico.xlsx' if mid=='06' else None
    output_index=_index_month(books,output,'Mensual') if output else {}
    output_data=books.data(output,'Mensual',350,'G') if output else []
    status_col={'01':None,'03':'C','04':'D','05':'D','06':'I',
                '13':'C','14':'C','15':'C'}[mid]
    for month,row in sorted(months.items()):
        if month not in index:
            # Solo agregar periodos contiguos al histórico del mismo origen.
            if last>1 and month <= max(index):
                raise ValueError(f'{mid}/{month}: falta un mes intermedio en el histórico de origen.')
            last += 1
            index[month]=last
            year,mon=map(int,month.split('-'))
            key=(date(year,mon,1)-date(1899,12,30)).days if date_serial else month
            books.cell(inp,tab,f'A{last}',key)
            if date_serial:
                books.sheet(inp,tab).get_range(f'A{last}').set_number_format('yyyy-mm-dd')
        r=index[month]
        cell=f'B{r}'
        existing=books.sheet(inp,tab).get_range(cell)
        formula=existing.formulas[0][0]
        if formula and row.get('status')=='observed':
            # La observación SBS/BCRP se introduce en la celda de captura
            # preexistente, sin reemplazar las fórmulas de imputación,
            # crecimiento interanual ni condición de 2026.
            capture = {'03':'D','04':'E','05':'E'}.get(mid)
            if capture is not None and month.startswith('2026-'):
                books.cell(inp,tab,f'{capture}{r}',float(row['value']))
                modeled=books.sheet(inp,tab).get_range(cell).values[0][0]
                if not isinstance(modeled,(float,int)) or abs(float(modeled)-float(row['value']))>0.0005:
                    raise ValueError(f'M{mid}/{month}: el dato capturado no actualizó la fórmula.')
            else:
                books.cell(inp,tab,cell,float(row['value']),allow_formula=True)
        elif formula:
            current=existing.values[0][0]
            if not isinstance(current,(int,float)) or abs(float(current)-float(row['value']))>0.0005:
                if mid in ('13','14','15'):
                    actual=[(k,idx) for k,idx in index.items() if k<=month and k.startswith(month[:4]) and
                            k in months and months[k].get('status')=='observed']
                    if actual:
                        books.formula(inp,tab,cell,f'=B{max(actual)[1]}')
                    else:
                        raise ValueError(f'M{mid}/{month}: no se identificó ancla observada.')
                elif mid in ('04','05','06') and month.startswith('2026-') and row.get('status')=='assumed':
                    observed=[]
                    for m in range(1,13):
                        k=f'2026-{m:02d}';prev=f'2025-{m:02d}'
                        if k in index and prev in index and k<=month and (
                            m<=8 or (k in months and months[k].get('status')=='observed')):
                            observed.append(f'B{index[k]}/B{index[prev]}-1')
                    if len(observed)<8:raise ValueError(f'M{mid}: muestra mensual incompleta.')
                    prev=f'2025-{month[5:]}'
                    if prev not in index:raise ValueError(f'M{mid}/{month}: falta año anterior.')
                    expr=f'B{index[prev]}*(1+AVERAGE({",".join(observed)}))'
                    books.formula(inp,tab,cell,f'=ROUND({expr},0)' if mid=='04' else f'={expr}')
                else:
                    raise ValueError(f'M{mid}/{month}: la imputación original no coincide con el nuevo cierre.')
        else:
            books.cell(inp,tab,cell,float(row['value']))
        if status_col:
            original=raw[r-1][ord(status_col)-65] if r<=len(raw) else ''
            status_cell=f'{status_col}{r}'
            if not books.sheet(inp,tab).get_range(status_cell).formulas[0][0]:
                books.cell(inp,tab,status_cell,_labels(row.get('status'),original))
        if mid=='06':
            # La tabla física mensual termina en el último mes observado.
            # Añadir únicamente la observación publicada siguiente; no crear
            # registros futuros ni fabricar una serie mensual 2027–2030.
            if month not in output_index:
                if not output_index or month <= max(output_index):
                    raise ValueError(f'M06/{month}: el nuevo mes no es posterior al último observado.')
                prior=max(output_index)
                y,m=map(int,prior.split('-'))
                next_month=f'{y+int(m==12)}-{(m%12)+1:02d}'
                if month!=next_month:
                    raise ValueError(f'M06/{month}: faltan observaciones mensuales entre {prior} y {month}.')
                rr=max(output_index.values())+1
                previous=output_index[prior]
                prevval=books.sheet(output,'Mensual').get_range(f'B{previous}').values[0][0]
                if not isinstance(prevval,(int,float)) or prevval<=0:
                    raise ValueError('M06: falta saldo anterior para crecimiento mensual.')
                new=float(row['value'])
                books.cell(output,'Mensual',f'A{rr}',month)
                books.cell(output,'Mensual',f'C{rr}',100*math.log(new/prevval))
                books.cell(output,'Mensual',f'E{rr}',books.sheet(output,'Mensual').get_range(f'C{previous}').values[0][0])
                if previous>2:
                    books.cell(output,'Mensual',f'F{rr}',books.sheet(output,'Mensual').get_range(f'C{previous-1}').values[0][0])
                output_index[month]=rr
            rr=output_index[month]
            books.cell(output,'Mensual',f'B{rr}',float(row['value']))
            old=output_data[rr-1][6] if rr<=len(output_data) else 'Observado'
            books.cell(output,'Mensual',f'G{rr}',_labels(row['status'],old))
    return True


def _period(books,file,tab='Anual'):
    rows=books.data(file,tab,300,'K')
    return {int(row[0]):idx for idx,row in enumerate(rows,1) if idx>1 and isinstance(row[0],(int,float)) and not isinstance(row[0],bool) and 2000<=row[0]<=2030}


def _write_operational(books, mid, folder, original, updated, years):
    inp=folder/'Input'/'Base_modelo.xlsx'
    tab,col=INPUT_ANNUAL[mid]
    inrows=_period(books,inp,tab)
    outf=folder/'Output'/'Pronostico.xlsx'
    outrows=_period(books,outf,'Anual')
    now={int(r['year']):r for r in updated[mid]['annual']}
    past={int(r['year']):r for r in original[mid]['annual']}
    if mid in ('03','05'):
        design=updated[mid]['statistics']['regressorsByYear']
        headers=('PBI real (%)','Inflación anual (%)','Dicotómica COVID 2020–2021') if mid=='03' else ('Crecimiento log compras t (%)','Dicotómica SBS 2021','No utilizado (A.2)')
        cols='FGH' if mid=='03' else 'EFG'
        for col_,label in zip(cols,headers):books.cell(outf,'Anual',f'{col_}1',label)
        for y,row_ in outrows.items():
            x=design.get(str(y))
            for j,col_ in enumerate(cols):
                books.cell(outf,'Anual',f'{col_}{row_}',float(x[j+1]) if x and j+1<len(x) else None,allow_formula=True)
    for year in sorted(years):
        if year not in inrows or year not in outrows:
            raise ValueError(f'M{mid}: no figura el año {year} en Input/Output.')
        current=now[year];row=inrows[year]
        # Los inputs futuros contienen supuestos exógenos, nunca copias
        # de la variable endógena ya pronosticada en Output.
        if year<=2026 or mid in {'13','14','15'}:
            if mid!='06' or current['status'] in ('observed','assumed'):
                target=f'{col}{row}'
                if mid in {'01','06'} and year==2026 and books.sheet(inp,tab).get_range(target).formulas[0][0]:
                    derived=books.sheet(inp,tab).get_range(target).values[0][0]
                    if not isinstance(derived,(int,float)) or abs(float(derived)-float(current['value']))>0.0005:
                        raise ValueError(f'M{mid}: el cierre calculado en Input!{target} no concilia con los meses SBS.')
                else:
                    books.cell(inp,tab,target,float(current['value']))
        row=outrows[year]
        books.cell(outf,'Anual',f'B{row}',float(current['value']))
        s=OUT_STATUS[mid]
        current_status=books.sheet(outf,'Anual').get_range(f'{s}{row}').values[0][0]
        books.cell(outf,'Anual',f'{s}{row}',_labels(current['status'],current_status))
        if mid in {'01','02','03','04','05','06'} and year-1 in now:
            p=now[year-1]['value'];v=now[year]['value']
            if p<=0 or v<=0:raise ValueError(f'M{mid}: crecimiento logaritmico no definido para {year}.')
            books.cell(outf,'Anual',f'C{row}',100*math.log(v/p))
            if mid=='03':books.cell(outf,'Anual',f'D{row}',100*(v/p-1))
            if mid=='06':books.cell(outf,'Anual',f'E{row}',100*(v/p-1))
    return True


def _fit_operational(books,mid,folder,updated):
    values={int(r['year']):float(r['value']) for r in updated[mid]['annual']}
    file=folder/'Output'/'Pronostico.xlsx'
    data=books.data(file,'Anual',250,'J')
    index=_period(books,file)
    n=int(updated[mid].get('statistics',{}).get('nobs') or updated[mid].get('statistics',{}).get('n') or 0)
    if mid in ('01','02'):
        end=2026
        years=list(range(end-n+1,end+1))
        y=[100*math.log(values[t]/values[t-1]) for t in years]
        x=[[1.,float(data[index[t]-1][3])] for t in years]
    elif mid=='03':
        years=list(range(2014,2014+n))
        y=[100*math.log(values[t]/values[t-1]) for t in years]
        x=[updated[mid]['statistics']['regressorsByYear'][str(t)] for t in years]
    elif mid=='04':
        # Regresoras de las series macro ya presentes en Input.
        m=books.data(folder/'Input'/'Base_modelo.xlsx','Anual',200,'H')
        ix=_period(books,folder/'Input'/'Base_modelo.xlsx')
        years=list(range(2027-n,2027))
        y=[100*math.log(values[t]/values[t-1]) for t in years]
        x=[[1.,float(m[ix[t]-1][2]),float(m[ix[t-1]-1][2]),float(m[ix[t-1]-1][3])] for t in years]
    elif mid=='05':
        years=list(range(2017,2017+n))
        y=[100*math.log(values[t]/values[t-1]) for t in years]
        x=[updated[mid]['statistics']['regressorsByYear'][str(t)] for t in years]
    elif mid=='06':
        # El libro anual usa variaciones de saldo (S/ MM), no crecimientos mensuales.
        # El cierre histórico de 2015 se consulta en el archivo SBS existente.
        from datetime import date,datetime
        iaspe=folder.parents[2]
        source=iaspe/'Scraper'/'Cartera_consumo_mercado'/'output'/'Cartera_consumo_banca_multiple.xlsx'
        market=books.data(source,'Mensual',250,'F')
        from datetime import date
        d2015=(date(2015,12,1)-date(1899,12,30)).days
        values[2015]=next(float(row[5]) for row in market if row[0]==d2015 or
                          (isinstance(row[0],(date,datetime)) and row[0].year==2015 and row[0].month==12))
        macros=iaspe/'Modelos financieros'/'Variables Operativas'/'01_Numero_tarjetas_mercado'/'Input'/'Base_modelo.xlsx'
        pbi={int(row[0]):float(row[1]) for row in books.data(macros,'Macros_anuales',40,'B') if isinstance(row[0],(int,float)) and isinstance(row[1],(int,float))}
        purchase_file=iaspe/'Modelos financieros'/'Variables Operativas'/'03_Compras_tarjetas_mercado'/'Output'/'Pronostico.xlsx'
        purchases={int(row[0]):float(row[1]) for row in books.data(purchase_file,'Anual',40,'B') if isinstance(row[0],(int,float)) and isinstance(row[1],(int,float))}
        years=list(range(2027-n,2027))
        x=[[1.,pbi[year-1]-pbi[year-2],float(year==2021),purchases[year-1]] for year in years]
        y=[values[year]-values[year-1] for year in years]
    elif mid in ('13','14','15'):
        d=books.data(folder/'Input'/'Base_modelo.xlsx','Anual',100,'E')
        ix=_period(books,folder/'Input'/'Base_modelo.xlsx')
        years=list(range(2027-n,2027))
        y=[values[t] for t in years]
        if years[0]-1 not in values:
            values[years[0]-1]=float(d[ix[years[0]-1]-1][1])
        if mid=='13':
            x=[[1.,values[t-1],float(d[ix[t]-1][3]),float(d[ix[t-1]-1][2])] for t in years]
        elif mid=='14':
            x=[[1.,values[t-1],float(d[ix[t]-1][2])] for t in years]
        else:
            x=[[1.,float(d[ix[t]-1][2]),float(d[ix[t-1]-1][3])] for t in years]
    else:raise ValueError(mid)
    fit=sm.OLS(np.asarray(y,float),np.asarray(x,float)).fit()
    robust=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
    expected=updated[mid].get('coefficients',[])
    if len(expected)!=len(fit.params) or max(abs(float(e['value'])-float(p)) for e,p in zip(expected,fit.params))>2e-4:
        raise ValueError(f'M{mid}: la MCO de la hoja de origen no reproduce la estimación del motor.')
    return fit,robust


def _write_mco(books,mid,folder,model):
    f=folder/'Output'/'Resultados_MCO.xlsx'
    if not f.is_file():raise ValueError(f'M{mid}: falta Resultados_MCO.xlsx')
    fit,hac=_fit_operational(books,mid,folder,{mid:model})
    if mid in ('01','02'):
        sheets=[('MCO_clasico',fit),('MCO_HAC',hac)]
        start=2
    elif mid=='03':
        sheets=[('MCO',fit),('HAC_1',hac)]
        start=2
    else:
        sheets=[('MCO',fit),('HAC',hac)]
        start=7 if mid in ('13','14','15') else 12 if mid=='06' else 11
        if mid in ('04',):
            headings=books.data(f,'MCO',25,'B')
            start=next((i+1 for i,row in enumerate(headings) if row[0]=='Variable'),start)+1
    for tab,estimated in sheets:
        if mid=='06':
            for row,label in enumerate(('Constante','Aceleración PBI real t−1 (pp)',
                'Dicotómica SBS 2021','Compras mercado t−1 (S/ MM)'),start=12):
                books.cell(f,tab,f'A{row}',label)
            books.cell(f,tab,'A17','Nota: variación anual del saldo en S/ MM; MCO 2016–2026 incluye cierre supuesto 2026. SBS 2021 es una intervención puntual.')
        if mid in ('03','05'):
            for i,c in enumerate(model['coefficients']):books.cell(f,tab,f'A{start+i}',c['name'])
            if mid=='05':
                for col in 'ABCDEFG':books.cell(f,tab,f'{col}{start+3}',None,allow_formula=True)
        ci=np.asarray(estimated.conf_int(alpha=.05))
        for i,param in enumerate(estimated.params):
            row=start+i
            for col,val in zip('BCDEFG',[param,estimated.bse[i],estimated.tvalues[i],estimated.pvalues[i],ci[i,0],ci[i,1]]):
                # Algunos Resultados_MCO no tienen IC; sus celdas se dejan intactas.
                if mid in ('13','14','15') and col in ('F','G'):continue
                books.cell(f,tab,f'{col}{row}',float(val))
        if mid in ('13','14','15','04','05','06'):
            headers=books.data(f,tab,12,'B')
            for row,entry in enumerate(headers,1):
                key=str(entry[0] or '').strip().lower()
                data = (str(model.get('statistics',{}).get('period','')) if key in ('período','período mco','muestra mco') else
                        int(fit.nobs) if key=='observaciones' else
                        float(fit.rsquared_adj) if key=='r² ajustado' else
                        float(fit.rsquared) if key=='r²' else
                        float(fit.aic) if key=='aic' else
                        float(fit.bic) if key=='bic' else
                        float(sm.stats.stattools.durbin_watson(fit.resid)) if key=='durbin-watson' else None)
                if data is not None:books.cell(f,tab,f'B{row}',data)
    if mid=='03':
        for row,entry in enumerate(books.data(f,'Indicadores',25,'C'),1):
            key=str(entry[0] or '').lower()
            val=(str(model['statistics']['period']) if key=='muestra' else
                 int(fit.nobs) if 'observaciones' in key else
                 float(fit.rsquared) if key=='r²' else
                 float(fit.rsquared_adj) if 'r² ajustado' in key else
                 float(fit.aic) if key=='aic' else
                 float(fit.bic) if key=='bic' else
                 float(sm.stats.stattools.durbin_watson(fit.resid)) if 'durbin' in key else None)
            if val is not None:
                for col in ('B','C'):books.cell(f,'Indicadores',f'{col}{row}',val)
            elif key=='estadístico f':
                for col,res in (('B',fit),('C',hac)):books.cell(f,'Indicadores',f'{col}{row}',float(res.fvalue))
            elif key=='p-valor f':
                for col,res in (('B',fit),('C',hac)):books.cell(f,'Indicadores',f'{col}{row}',float(res.f_pvalue))


def persistir(books,original,updated,root,annual_changes,monthly_changes,observations=None):
    # La responsabilidad de cada archivo está definida, no inferida por coincidencia.
    applied=set()
    # M06 no presenta estimaciones mensuales en el catálogo: las observaciones
    # del saldo se guardan, sin embargo, en su hoja mensual de origen.
    observations=observations or {}
    new06={k[:7]:{'value':float(v),'status':'observed'}
           for k,v in observations.get('06',{}).items()
           if isinstance(v,(float,int)) and str(k).startswith('2026-')}
    if new06:
        monthly_changes={**monthly_changes, '06':{**monthly_changes.get('06',{}), **new06}}
    for mid in sorted(set(annual_changes) | set(monthly_changes)):
        if mid not in MODELS:continue
        from persistencia_modelos import _folder_for
        folder=_folder_for(original[mid],root,root)
        if folder is None:raise ValueError(f'No se identificó el directorio original M{mid}.')
        if mid in monthly_changes:
            if mid not in MONTHLY:raise ValueError(f'M{mid}: no existe plantilla mensual validada.')
            _write_months(books,mid,folder,monthly_changes[mid])
        if mid in annual_changes:_write_operational(books,mid,folder,original,updated,annual_changes[mid])
        old=original[mid].get('coefficients',[]);new=updated[mid].get('coefficients',[])
        if len(old)!=len(new) or any(abs(float(a['value'])-float(b['value']))>1e-8 for a,b in zip(old,new)):
            _write_mco(books,mid,folder,updated[mid])
        applied.add(mid)
    return applied
