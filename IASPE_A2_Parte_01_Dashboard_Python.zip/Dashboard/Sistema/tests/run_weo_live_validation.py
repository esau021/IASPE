"""Validación real FMI por HTTP local; sin mocks ni cambios en modelos.

python tests/run_weo_live_validation.py --output resultado.json
Por defecto usa una copia temporal del historial. --apply confirma las dos
consultas en el historial activo, igual que pulsar dos veces Actualizar FMI.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
from io import BytesIO
import json
from pathlib import Path
import shutil
import sys
import tempfile
import threading

import requests
from openpyxl import load_workbook

SYSTEM = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SYSTEM))
import proyecciones_externas as p
import servidor
import weo_imf as w


def validate():
    before = deepcopy(p._load())
    other_rows = [r for r in before['records'] if r['source'] != w.SOURCE]
    other_docs = [e for e in before['editions'] if e.get('source') != w.SOURCE]
    archived = {e['file']: hashlib.sha256((p.DOCS / e['file']).read_bytes()).hexdigest()
                for e in before['editions'] if e.get('file')}
    server = servidor.Server(('127.0.0.1', 0), servidor.Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    url = f'http://127.0.0.1:{server.server_address[1]}/api/macro-external/update'
    try:
        responses = []
        for _ in range(2):
            response = requests.post(url, json={'scope': 'imf'}, timeout=180)
            response.raise_for_status()
            result = response.json()
            responses.append(result)
            assert not result['updateResult']['errors'], result['updateResult']
        first, second = responses
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
    assert second['updateResult']['added'] == 0
    assert second['updateResult']['new_editions'] == 0
    assert second['updateResult']['revisions'] == 0
    assert len(first['records']) == len(second['records'])
    assert len(first['editions']) == len(second['editions'])
    after = p._load()
    assert [r for r in after['records'] if r['source'] != w.SOURCE] == other_rows
    assert [e for e in after['editions'] if e.get('source') != w.SOURCE] == other_docs
    for filename, digest in archived.items():
        assert hashlib.sha256((p.DOCS / filename).read_bytes()).hexdigest() == digest
    current = [r for r in second['current_records'] if r['source'] == w.SOURCE]
    assert {r['code_weo'] for r in current} == set(w.CODES)
    assert all(r['transport_verified'] for r in current)
    edition = max(r['edition'] for r in current)
    document = next(e for e in after['editions'] if e['id'] == current[0]['document_id'])
    assert document['discovery_verified']
    body = (p.DOCS / document['file']).read_bytes()
    assert hashlib.sha256(body).hexdigest() == document['hash']
    # Lector independiente del parser XML de producción, todas las cifras.
    wb = load_workbook(BytesIO(body), read_only=True, data_only=True)
    expected = {}
    try:
        rows = wb['Countries'].iter_rows(values_only=True)
        headers = next(rows)
        for raw in rows:
            row = dict(zip(headers, raw))
            code = row.get('INDICATOR.ID')
            if row.get('COUNTRY.ID') != 'PER' or code not in w.CODES:
                continue
            for record in current:
                if record['code_weo'] != code:
                    continue
                year = int(record['year'])
                assert year > int(row['LATEST_ACTUAL_ANNUAL_DATA'])
                assert record['value'] == float(row[year]), (code, year)
                assert record['published'] == str(row['PUBLICATION_DATE'])[:10]
                expected[f'{code}:{year}'] = float(row[year])
    finally:
        wb.close()
    assert len(expected) == len(current)
    events = [event for result in responses for event in result['updateResult']['http_events']]
    assert any(e['url'] == document['url'] and e.get('http_status') == 200
               and e.get('downloaded') for e in events), 'No hubo una descarga Excel HTTP 200 nueva'
    return {'executed_at_utc': datetime.now(timezone.utc).isoformat(),
            'network': 'real; sin mocks', 'endpoint': 'POST /api/macro-external/update; scope=imf',
            'edition': edition, 'published': document['published'],
            'document_url': document['url'], 'bytes': len(body), 'sha256': document['hash'],
            'sdmx_metadata': document.get('sdmx_metadata'),
            'latest_actual': document['latest_actual'], 'values_checked_against_excel': expected,
            'exact_values_match': True, 'repeat_added': second['updateResult']['added'],
            'other_sources_unchanged': True, 'previous_documents_preserved': len(archived),
            'first_update': first['updateResult'], 'second_update': second['updateResult']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    original = {key: getattr(p, key) for key in ('DIR', 'STATE', 'DOCS', 'HTTP_CACHE')}
    with tempfile.TemporaryDirectory(prefix='iaspe_weo_live_') as folder:
        try:
            if not args.apply:
                base = Path(folder)
                shutil.copyfile(p.STATE, base / 'historial.json')
                shutil.copytree(p.DOCS, base / 'documentos')
                p.DIR = base
                p.STATE = base / 'historial.json'
                p.DOCS = base / 'documentos'
                p.HTTP_CACHE = base / 'http_cache.json'
            result = validate()
        finally:
            for key, value in original.items():
                setattr(p, key, value)
    result['applied_to_active_history'] = args.apply
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"FMI {result['edition']}: descarga real, {len(result['values_checked_against_excel'])} cifras exactas, segunda ejecución sin duplicados.")


if __name__ == '__main__':
    main()
