"""Lectura de pronósticos WEO del FMI para Perú."""
from __future__ import annotations

from datetime import datetime, timezone
import csv
from html.parser import HTMLParser
from io import BytesIO
import json
import math
import re
from urllib.parse import urljoin, urlparse
import xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile

PORTAL = 'https://data.imf.org/datasets/WEO'
SDMX_STRUCTURE_URL = ('https://api.imf.org/external/sdmx/3.0/structure/'
                      'dataflow/IMF.RES/WEO/latest?references=none')
INITIAL_URL = ('https://data.imf.org/-/media/iData/External-Storage/Documents/'
               '0FA3DC49A04D446E9D69DBEB29979E1C/en/WEOOct2026all.xlsx')
SOURCE = 'FMI · WEO'
# El nombre local en IASPE y el código original del FMI se conservan por separado.
CODES = {'NGDP_RPCH': ('pbi', '%'),
         'PCPIEPCH': ('inflacion', '%'),
         'LUR': ('desempleo', '%'),
         'LP': ('poblacion', 'Millones de personas')}
MONTHS = {'Apr': 4, 'Oct': 10}
MAIN = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
PACKAGE = '{http://schemas.openxmlformats.org/package/2006/relationships}'
FILE_RE = re.compile(r'WEO(Apr|Oct)(20\d{2})all\.xlsx', re.I)


def _vintage(url):
    match = FILE_RE.search(urlparse(url).path)
    if not match:
        raise ValueError('El archivo no identifica una edición WEO completa')
    month = MONTHS[match[1].title()]
    return f'{int(match[2]):04d}-{month:02d}'


def _official_link(value):
    parsed = urlparse(value)
    return (parsed.scheme == 'https' and parsed.hostname == 'data.imf.org'
            and not parsed.username and not parsed.password and FILE_RE.search(parsed.path) is not None)


class _Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self._json_script = False
        self._json_parts = []

    def _add(self, value):
        if not isinstance(value, str):
            return
        link = urljoin(PORTAL, value)
        if _official_link(link):
            self.links.append(link)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a':
            self._add(attrs.get('href', ''))
        elif tag == 'script' and (attrs.get('id') == '__NEXT_DATA__'
                                  or attrs.get('type') == 'application/json'):
            self._json_script = True
            self._json_parts = []

    def handle_data(self, data):
        if self._json_script:
            self._json_parts.append(data)

    def handle_endtag(self, tag):
        if tag != 'script' or not self._json_script:
            return
        self._json_script = False
        try:
            payload = json.loads(''.join(self._json_parts))
        except (ValueError, TypeError):
            return
        pending = [payload]
        while pending:
            item = pending.pop()
            if isinstance(item, dict):
                # El catálogo también publica enlaces dentro de datos JSON.
                self._add(item.get('href'))
                pending.extend(item.values())
            elif isinstance(item, list):
                pending.extend(item)


def discover(body):
    """Identifica el último Excel WEO publicado en el portal oficial."""
    if isinstance(body, bytes):
        body = body.decode('utf-8', errors='replace')
    page = _Links()
    page.feed(body)
    links = sorted(set(page.links), key=lambda x: (_vintage(x), x), reverse=True)
    if not links:
        raise ValueError('La página del FMI no expone un Excel WEO descargable verificable')
    return links[0]


def latest_sdmx(fetch):
    """Contrasta edición y metadatos mediante la API SDMX del FMI."""
    structure_body = fetch(SDMX_STRUCTURE_URL, limit=8_000_000, timeout=25)
    try:
        structure = json.loads(structure_body)
        flows = structure['data']['dataflows']
        flows = [f for f in flows if f.get('agencyID') == 'IMF.RES'
                 and f.get('id') == 'WEO']
        if len(flows) != 1:
            raise ValueError('No consta un único flujo WEO del FMI')
        version = flows[0]['version']
        if not re.fullmatch(r'\d+(?:\.\d+){1,3}', version):
            raise ValueError('Versión SDMX WEO no reconocida')
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError('Metadatos SDMX WEO no válidos') from exc
    # Usar la versión WEO publicada en los metadatos SDMX.
    data_url = ('https://api.imf.org/external/sdmx/2.1/data/'
                f'IMF.RES,WEO,{version}/PER.' + '+'.join(CODES) + '.A')
    body = fetch(data_url, limit=5_000_000, timeout=25)
    if isinstance(body, bytes):
        body = body.decode('utf-8-sig')
    reader = csv.DictReader(body.splitlines())
    required = {'COUNTRY', 'INDICATOR', 'FREQUENCY', 'TIME_PERIOD',
                'OBS_VALUE', 'PUBLICATION_DATE', 'LATEST_ACTUAL_ANNUAL_DATA',
                'SCALE', 'UNIT'}
    if not required.issubset(reader.fieldnames or ()):
        raise ValueError('La respuesta SDMX WEO no incluye los metadatos requeridos')
    metadata = {}
    for row in reader:
        code = row['INDICATOR']
        if row['COUNTRY'] != 'PER' or code not in CODES or row['FREQUENCY'] != 'A':
            raise ValueError('La respuesta SDMX contiene series distintas de las solicitadas')
        publication = row['PUBLICATION_DATE']
        try:
            date = datetime.fromisoformat(publication.replace('Z', '+00:00'))
            last_actual = int(row['LATEST_ACTUAL_ANNUAL_DATA'])
            year = int(row['TIME_PERIOD'])
        except (ValueError, TypeError) as exc:
            raise ValueError(f'Metadatos temporales SDMX no válidos: {code}') from exc
        if date.month not in (4, 10) or not 1900 <= last_actual <= date.year:
            raise ValueError('La respuesta SDMX no identifica una edición completa WEO')
        signature = (publication, last_actual, row['SCALE'], row['UNIT'])
        item = metadata.setdefault(code, {'signature': signature, 'years': set()})
        if item['signature'] != signature or year in item['years']:
            raise ValueError(f'Metadatos inconsistentes o años duplicados SDMX: {code}')
        if row['OBS_VALUE'].strip():
            item['years'].add(year)
    if set(metadata) != set(CODES):
        raise ValueError('SDMX no recuperó los cuatro indicadores de Perú')
    publications = {m['signature'][0] for m in metadata.values()}
    if len(publications) != 1:
        raise ValueError('SDMX mezcla fechas de publicación WEO')
    publication = publications.pop()
    edition = publication[:7]
    for code, item in metadata.items():
        if any(y not in item['years'] for y in range(int(edition[:4]), int(edition[:4])+6)):
            raise ValueError(f'SDMX no incluye seis años de la edición: {code}')
    return {'edition': edition, 'published': publication[:10], 'url': data_url,
            'structure_url': SDMX_STRUCTURE_URL, 'flow_version': version,
            'codes': list(CODES),
            'latest_actual': {c: m['signature'][1] for c, m in metadata.items()}}


def _col(ref):
    return re.match(r'^([A-Z]+)', str(ref))[1]


def _sheet_name(z):
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    targets = {item.attrib['Id']: item.attrib['Target'] for item in rels.findall(PACKAGE+'Relationship')}
    for sh in wb.findall('.//'+MAIN+'sheet'):
        if sh.get('name') == 'Countries':
            target = targets[sh.get(REL+'id')].lstrip('/')
            return target if target.startswith('xl/') else 'xl/'+target
    raise ValueError('Falta la hoja Countries del WEO')


def parse_workbook(body, file_url, *, provenance='official'):
    """Extrae las series de Perú y valida sus años proyectados."""
    if not _official_link(file_url):
        raise ValueError('No es el enlace de una publicación oficial WEO')
    edition = _vintage(file_url)
    if len(body) > 35_000_000 or len(body) < 1000:
        raise ValueError('Tamaño inesperado del Excel WEO')
    try:
        z = ZipFile(BytesIO(body))
    except BadZipFile as exc:
        raise ValueError('No es un archivo Excel válido') from exc
    with z:
        if sum(item.file_size for item in z.infolist()) > 300_000_000:
            raise ValueError('El contenido expandido del WEO supera el límite de seguridad')
        if 'xl/sharedStrings.xml' in z.namelist():
            if z.getinfo('xl/sharedStrings.xml').file_size > 40_000_000:
                raise ValueError('El índice de textos del WEO supera el límite de seguridad')
            strings = [''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall(MAIN+'si')]
        else:
            strings = []
        sheet = _sheet_name(z)
        if z.getinfo(sheet).file_size > 180_000_000:
            raise ValueError('La hoja de países supera el límite de seguridad')
        header = None
        found = {}
        with z.open(sheet) as stream:
            for _, elem in ET.iterparse(stream, events=('end',)):
                if elem.tag != MAIN+'row':
                    continue
                vals = {}
                for c in elem.findall(MAIN+'c'):
                    v = c.find(MAIN+'v')
                    inline = c.find(MAIN+'is')
                    value = v.text if v is not None else ''.join(inline.itertext()) if inline is not None else ''
                    if c.get('t') == 's' and value:
                        value = strings[int(value)]
                    vals[_col(c.get('r'))] = value
                if header is None:
                    header = {str(v): k for k, v in vals.items() if v}
                    required = {'COUNTRY.ID', 'COUNTRY', 'INDICATOR.ID', 'INDICATOR',
                                'FREQUENCY', 'SCALE', 'UNIT', 'PUBLICATION_DATE', 'LATEST_ACTUAL_ANNUAL_DATA'}
                    if not required.issubset(header):
                        raise ValueError('La estructura de columnas del WEO cambió')
                    continue
                if vals.get(header['COUNTRY.ID']) != 'PER':
                    elem.clear()
                    continue
                code = vals.get(header['INDICATOR.ID'])
                if code not in CODES:
                    elem.clear()
                    continue
                if code in found:
                    raise ValueError(f'Indicador duplicado en Perú: {code}')
                if vals.get(header['FREQUENCY']) != 'Annual':
                    raise ValueError('Frecuencia WEO inesperada')
                publication = str(vals.get(header['PUBLICATION_DATE']) or '')
                try:
                    published_date = datetime.fromisoformat(publication.replace('Z', '+00:00'))
                except ValueError as exc:
                    raise ValueError('Fecha de publicación interna WEO no válida') from exc
                if published_date.strftime('%Y-%m') != edition:
                    raise ValueError('La fecha interna del Excel no coincide con su edición')
                last_actual = str(vals.get(header['LATEST_ACTUAL_ANNUAL_DATA']) or '')
                if not re.fullmatch(r'\d{4}', last_actual):
                    raise ValueError(f'No consta el último año observado de {code}')
                if int(last_actual) > published_date.year:
                    raise ValueError(f'Último año observado posterior a la edición: {code}')
                if code == 'LP' and vals.get(header['SCALE']) != 'Millions':
                    raise ValueError('Población no se encuentra expresada en millones')
                if code != 'LP':
                    if vals.get(header['SCALE']) != 'Units':
                        raise ValueError(f'Escala porcentual inesperada de {code}')
                    # El FMI deja UNIT vacío para LUR; su código lo identifica.
                    units = ('Percent', '') if code == 'LUR' else ('Percent',)
                    if vals.get(header['UNIT']) not in units:
                        raise ValueError(f'Unidad porcentual inesperada de {code}')
                years = {}
                year_columns = sorted(int(y) for y in header if re.fullmatch(r'20\d{2}', y)
                                      and int(y) >= int(edition[:4]))
                for year in year_columns:
                    raw = vals.get(header[str(year)])
                    if raw in ('', None):
                        continue
                    try:
                        number = float(raw)
                    except (ValueError, TypeError) as exc:
                        raise ValueError(f'Dato no numérico: {code} {year}') from exc
                    if not math.isfinite(number) or not -30.0 <= number <= 100.0:
                        raise ValueError(f'Dato fuera de rango: {code} {year}')
                    if year > int(last_actual):
                        years[year] = number
                # Requerir el horizonte completo de la edición.
                expected = [y for y in range(int(edition[:4]), int(edition[:4])+6) if y > int(last_actual)]
                if any(y not in years for y in expected):
                    raise ValueError(f'La edición WEO tiene periodos futuros incompletos para {code}')
                found[code] = {'years': years, 'published': publication[:10],
                               'last_actual': int(last_actual),
                               'indicator': vals.get(header['INDICATOR'], ''),
                               'row': int(elem.get('r')),
                               'unit': vals.get(header['UNIT'], ''),
                               'scale': vals.get(header['SCALE'], ''),
                               'origin': provenance}
                elem.clear()
        if set(found) != set(CODES):
            raise ValueError('No se localizaron las cuatro series oficiales de Perú')
        if len({series['published'] for series in found.values()}) != 1:
            raise ValueError('El Excel mezcla fechas de publicación WEO')
        return edition, found
