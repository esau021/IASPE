"""Ubicación de modelos financieros dentro de IASPE."""
from pathlib import Path

GRUPOS = ('Estado de Resultados', 'Estado de Situacion Financiera', 'Variables Operativas')

def buscar_modelo(base, codigo, opcional=False):
    raiz = Path(base)
    for nombre in GRUPOS:
        carpeta = raiz / nombre
        if carpeta.is_dir():
            hallados = sorted(p for p in carpeta.glob(f'{codigo}_*') if p.is_dir())
            if hallados:
                return hallados[0]
    if opcional:
        return None
    raise FileNotFoundError(f'No se encontró el modelo {codigo} en {raiz}')
