"""Modelos patrimoniales 33-46 en el catálogo original del Dashboard.

Usa los Output oficiales IASPE (solo lectura), sin reestimar decisiones
exógenas de Tesorería, reservas, capital y dividendos. Los movimientos del
Modelo 45 se recalculan desde el resultado corriente del M29.
"""
from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from io import BytesIO
import copy
import math

NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
    'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
NAMES={
'33':'Inmuebles, mobiliario y equipo neto',
'34':'Otros activos',
'35':'Depósitos del sistema financiero',
'36':'Obligaciones en circulación no subordinadas',
'37':'Cuentas por pagar',
'38':'Intereses y otros gastos por pagar',
'39':'Otros pasivos',
'40':'Provisiones del pasivo',
'41':'Capital social',
'42':'Capital adicional',
'43':'Reservas',
'44':'Ajustes al patrimonio',
'45':'Resultados acumulados',
'46':'Resultado neto del ejercicio',
}
DEPEND={
'33':['26'], '34':['07'], '35':[], '36':[],
'37':['03','01','04'], '38':['10','12','35','36'],
'39':['28'], '40':['19_personal'], '41':[], '42':[],
'43':['41'], '44':['21_venta'],
'45':['45_utilidad_aplicada','45_dividendos','45_transferencias_reservas'], '46':['29']}
# Solo cuentan con propagación en escenarios las identidades contables que
# pueden reproducirse con los insumos verificables del registro.
RECALCULABLE={'33','34','37','38','39','40','44','45','46','45_utilidad_aplicada','45_transferencias_reservas','45_dividendos'}


def _read_rows(path, sheet='Anual'):
    with ZipFile(path) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(e.text or '' for e in it.findall('.//m:t',NS)) for it in root]
        book=ET.fromstring(z.read('xl/workbook.xml'))
        rels={r.get('Id'):r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        targets={s.get('name'):rels[s.get('{'+NS['r']+'}id')] for s in book.find('m:sheets',NS)}
        p=targets[sheet].lstrip('/')
        if not p.startswith('xl/'):p='xl/'+p
        xml=ET.fromstring(z.read(p))
        result=[]
        for row in xml.findall('./m:sheetData/m:row',NS):
            entry={}
            for c in row.findall('./m:c',NS):
                address=c.get('r');col=address.rstrip('0123456789')
                v=c.find('m:v',NS); inline=c.find('m:is',NS)
                if v is not None:
                    value=shared[int(v.text)] if c.get('t')=='s' else v.text
                    if c.get('t') not in ('s','str','e'):
                        try:value=float(value)
                        except (ValueError,TypeError):pass
                elif inline is not None:
                    value=''.join(e.text or '' for e in inline.findall('.//m:t',NS))
                else:continue
                entry[col]=value
            if entry:result.append(entry)
        return result


def _folder(root,mid):
    sub=Path(root)/'Estado de Situacion Financiera'
    result=sorted(p for p in sub.glob(f'{mid}_*') if (p/'Output'/'Pronostico.xlsx').is_file())
    return result[0] if result else None


def _annual(rows,col='B'):
    out=[]
    for r in rows:
        y=r.get('A');v=r.get(col)
        if not isinstance(y,(float,int)) or not isinstance(v,(float,int)) or int(y)<2016 or int(y)>2030:continue
        year=int(y)
        out.append({'year':year,'value':float(v), 'status': 'observed' if year<=2025 else 'assumed' if year==2026 else 'forecast'})
    return out


def _make(mid,name,annual,path,dependencies,method,can_update):
    return {'id':mid,'name':name,'unit':'S/ millones','frequency':'annual',
        'kind':'stock' if mid not in {'46','45_dividendos','45_utilidad_aplicada','45_transferencias_reservas','45_dividendos'} else 'flow',
        'annual':annual,'monthly':[], 'sourceFiles':[str(path)],
        'dependencies':dependencies,'inputs':[],
        'method':method,'coefficients':[],'statistics':{},
        'scenarioSupport':can_update,'canUpdate':can_update,
        'status':'ok','reestimated':False,
        'limitations':([] if can_update else ['Cuenta mostrada con el presupuesto o pronóstico Base aprobado; no se reestima automáticamente con shocks macroeconómicos.'])}


def build_registry(root):
    result=[]
    for mid,name in NAMES.items():
        folder=_folder(root,mid)
        if not folder:continue
        p=folder/'Output'/'Pronostico.xlsx'
        series=_annual(_read_rows(p))
        if not series:continue
        method=('Conciliación contable del resultado anterior, dividendos y transferencia a reservas'
                if mid=='45' else
                'Traslado de utilidad neta M29 al patrimonio (sin regresión adicional)' if mid=='46' else
                'Insumo exógeno presupuestado / saldo SBS' if mid in {'35','36','41','42','43'}
                else 'Modelo IASPE Base según Input y Output')
        result.append(_make(mid,name,series,p,DEPEND[mid],method,mid in RECALCULABLE))
        if mid=='45':
            whole=_read_rows(p)
            for suffix,col,label,deps,method in [
                ('dividendos','E','Dividendos distribuidos (limitados a resultados disponibles)',['29','43'], 'Presupuesto del Banco sujeto a disponibilidad de resultados; no es regresión'),
                ('transferencias_reservas','F','Transferencias a reservas (M43)',['43'], 'Variación contable anual de reservas'),
                ('utilidad_aplicada','D','Utilidad del ejercicio anterior aplicada (M29)',['29'], 'Resultado neto del ejercicio anterior')]:
                comp=f'45_{suffix}'
                result.append(_make(comp,label,_annual(whole,col),p,deps,method,comp in RECALCULABLE))
    return result


def recalculate(context,changes=None,observations=None):
    original=context.get('original_models') or {}
    current=context.get('models') or {}
    if '45' not in current:return {'models':[]}
    changed=[]
    def val(key,year,source=current):
        m=source.get(key)
        if not m:return None
        return next((float(r['value']) for r in m.get('annual',[]) if r['year']==year),None)
    def put(key,year,x):
        if x is None or not math.isfinite(x):return
        row=next((r for r in current[key]['annual'] if r['year']==year),None)
        if row is None or row.get('status')=='observed':return
        # El valor 2026 ejecutado en resultados acumulados no se recalcula.
        if key=='45' and year==2026:return
        x=float(x)
        if abs(float(row['value'])-x)<=1e-8:return
        row.update(value=x,forecast=x,observed=None)
        current[key]['reestimated']=True
        if key not in changed:changed.append(key)
    # M33: CAPEX presupuestado (exógeno), depreciación tangible proporcional
    # a su driver M26; 2026 mantiene ancla SBS agosto y CAPEX aprobado.
    if '33' in current and '26' in current:
        folder=_folder(context.get('source_root') or context.get('sourceRoot'),'33')
        if folder:
            annual={int(r['A']):r for r in _read_rows(folder/'Output'/'Pronostico.xlsx','Anual') if isinstance(r.get('A'),(int,float))}
            oldprev=val('33',2026)
            for year in range(2027,2031):
                row=annual.get(year,{})
                capex,depr=row.get('E'),row.get('F')
                old26=val('26',year,original)
                new26=val('26',year)
                if not all(isinstance(x,(int,float)) for x in (oldprev,capex,depr,old26,new26)) or old26==0:break
                oldprev=oldprev+float(capex)-float(depr)*new26/old26
                put('33',year,oldprev)
    # M34: dos componentes presupuestados; el activo operativo de 2029-2030
    # crece con cartera M07, tal como la fórmula original del Output.
    if '34' in current and '07' in current:
        folder=_folder(context.get('source_root') or context.get('sourceRoot'),'34')
        if folder:
            cal={int(r['A']):r for r in _read_rows(folder/'Output'/'Pronostico.xlsx','Calculo_Base') if isinstance(r.get('A'),(int,float))}
            operational=cal[2028].get('D')
            for year in (2029,2030):
                now,prev=val('07',year),val('07',year-1)
                if any(x is None or x<=0 for x in (now,prev)) or not isinstance(operational,(int,float)):break
                operational=operational*now/prev
                row=cal.get(year,{})
                if all(isinstance(row.get(key),(int,float)) for key in ('B','C')):
                    put('34',year,row['B']+row['C']+operational)
    # M38: reproducir las fórmulas originales de Excel con los drivers históricos
    # de las hojas Drivers_Base, sin imponer que coincidan exactamente con M12.
    if '38' in current and all(k in current for k in ('10','35','36','12_obligaciones','12_entidades')):
        folder=_folder(context.get('source_root') or context.get('sourceRoot'),'38')
        if folder:
            source=folder/'Output'/'Pronostico.xlsx'
            rows={int(r['A']):r for r in _read_rows(source) if isinstance(r.get('A'),(int,float))}
            drivers={int(r['A']):r for r in _read_rows(source,'Drivers_Base') if isinstance(r.get('A'),(int,float))}
            prior={}
            for year in range(2026,2031):
                row=rows.get(year,{})
                if year==2026:
                    components={}
                    for col,dep in [('C','10'),('D','35'),('E','36')]:
                        initial=row.get(col);old=val(dep,year,original);now=val(dep,year)
                        if not all(isinstance(x,(int,float)) for x in (initial,old,now)) or old==0:break
                        components[col]=initial*now/old
                    if len(components)!=3:continue
                    components['F']=float(row.get('F',0) or 0)
                else:
                    components={}
                    for col,dep,driver in [('C','12_obligaciones','E'),('D','12_entidades','F'),('E','36','D')]:
                        last_ref=drivers.get(year-1,{}).get(driver)
                        now_ref=drivers.get(year,{}).get(driver)
                        last_old=val(dep,year-1,original);now_old=val(dep,year,original)
                        last_new=val(dep,year-1);now_new=val(dep,year)
                        if not all(isinstance(x,(int,float)) for x in (last_ref,now_ref,last_old,now_old,last_new,now_new)) or min(abs(last_ref),abs(last_old),abs(now_old))==0:break
                        factor=(now_ref/last_ref)*(now_new/now_old)/(last_new/last_old)
                        components[col]=prior[col]*factor
                    if len(components)!=3:continue
                    components['F']=prior['F']
                prior=components
                put('38',year,sum(components.values()))
    # M40: provisiones indirectas observadas se mantienen como ancla;
    # únicamente otras provisiones siguen el gasto de personal del M19.
    if '40' in current and '19_personal' in current:
        folder=_folder(context.get('source_root') or context.get('sourceRoot'),'40')
        if folder:
            rows={int(r['A']):r for r in _read_rows(folder/'Output'/'Pronostico.xlsx') if isinstance(r.get('A'),(int,float))}
            other=rows[2026].get('D')
            credit=rows[2026].get('C')
            for year in range(2027,2031):
                now,prev=val('19_personal',year),val('19_personal',year-1)
                if any(x is None or x==0 for x in (prev,)) or now is None or other is None:break
                other=other*now/prev
                put('40',year,other+credit)

    # M37: se reproduce el crecimiento de compras BF = compras mercado ×
    # (tarjetas BF / tarjetas mercado), respetando el saldo SBS 2025.
    if all(k in current for k in ('37','03','01','04')):
        previous=val('37',2025)
        for year in range(2026,2031):
            market,marketprev=val('03',year),val('03',year-1)
            cards,cards_prev=val('01',year),val('01',year-1)
            bf,bfprev=val('04',year),val('04',year-1)
            if any(x is None or x<=0 for x in (market,marketprev,cards,cards_prev,bf,bfprev)) or previous is None:break
            previous=previous*(market*bf/cards)/(marketprev*bfprev/cards_prev)
            put('37',year,previous)
    # M39: impuesto corriente ligado al M28; diferido y operativo exógenos.
    # Reconstruye la fórmula observada 90% gasto IR menos ajuste IASC.
    if '39' in current and '28' in current:
        f=_folder(context.get('source_root') or context.get('sourceRoot'),'39')
        if f:
            drivers={int(r['A']):r for r in _read_rows(f/'Output'/'Pronostico.xlsx','Drivers_Base') if isinstance(r.get('A'),(int,float))}
            initial={int(r['A']):r for r in _read_rows(f/'Output'/'Pronostico.xlsx') if isinstance(r.get('A'),(int,float))}
            prev_adjust=None
            for year in range(2026,2031):
                source=drivers.get(year,{});base=initial.get(year,{})
                tax=val('28',year)
                ratio=source.get('G',.9)
                if not isinstance(ratio,(int,float)):ratio=.9
                if year<=2028:
                    adj=source.get('C')
                else:
                    prior=val('28',year-1)
                    adj=prev_adjust*tax/prior if prev_adjust is not None and prior else None
                if all(isinstance(x,(int,float)) for x in (tax,adj,base.get('D'),base.get('E'))):
                    put('39',year,ratio*tax-adj+float(base['D'])+float(base['E']))
                if isinstance(adj,(int,float)):prev_adjust=adj
    # M44: revalorización Base asociada al saldo exógeno de inversiones M21.
    if '44' in current and '21_venta' in current:
        for year in range(2026,2031):
            anchor=val('44',year,original);dep=val('21_venta',year,original);new=val('21_venta',year)
            if anchor is not None and dep and new is not None:put('44',year,anchor*new/dep)
    # Dividendos: presupuesto exógeno sujeto a no distribuir resultados inexistentes.
    for year in range(2027,2031):
        net=val('29',year-1)
        if net is not None:put('45_utilidad_aplicada',year,net)
        reserves,previous=val('43',year),val('43',year-1)
        if reserves is not None and previous is not None:put('45_transferencias_reservas',year,reserves-previous)
    path45=_folder(context.get('source_root') or context.get('sourceRoot'),'45')
    dividend_plan={}
    if path45:
        dividend_plan={int(r['A']):float(r['E']) for r in _read_rows(path45/'Output'/'Pronostico.xlsx','Drivers_Base')
                       if isinstance(r.get('A'),(int,float)) and isinstance(r.get('E'),(int,float))}
    for year in range(2027,2031):
        prev=val('45',year-1)
        app=val('45_utilidad_aplicada',year)
        div=val('45_dividendos',year)
        trans=val('45_transferencias_reservas',year)
        if all(x is not None for x in (prev,app,div,trans)):
            applied=min(max(0.0,dividend_plan.get(year,div)), max(0.0,prev+app-trans))
            put('45_dividendos',year,applied)
            put('45',year,prev+app-applied-trans)
    # M46: la utilidad del ejercicio reflejada en el balance siempre debe
    # coincidir con la utilidad neta calculada en el M29; ningún ajuste de
    # reservas/dividendos altera la utilidad del ejercicio corriente.
    if '46' in current and '29' in current:
        for year in range(2026,2031):
            net=val('29',year)
            if net is not None:put('46',year,net)
    return {'models':[current[k] for k in changed]}
