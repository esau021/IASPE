'use strict';
// Pruebas de regresión de navegación; no dependen del servidor ni de un DOM simulado.
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'..');
const workspace=fs.readFileSync(path.join(root,'workspace.js'),'utf8');
const styles=fs.readFileSync(path.join(root,'workspace.css'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const start=workspace.indexOf('function shell(){'),end=workspace.indexOf('function render(){');
assert(start>=0&&end>start,'No se encontró el generador real de navegación.');
const source=workspace.slice(start,end);
const invoke=new Function('route','modelMenu','S','escape',source+'\nreturn shell();');
const sections=[
 ['catalogo','Modelos','#catalogo'],
 ['datos','Datos observados','#datos'],
 ['monitor','Monitor','#monitor'],
 ['escenarios/16?editar=1','Escenarios','#escenarios/16?editar=1'],
 ['datos/proyecciones','Proyecciones externas','#datos/proyecciones'],
 ['normativa','Normativa SBS','#normativa'],
 ['laboratorio','Laboratorio','#laboratorio'],
 ['benchmark/eeff','Mercado','#benchmark/eeff'],
 ['benchmark/cartera','Mercado','#benchmark/eeff'],
 ['benchmark/ratios','Mercado','#benchmark/eeff'],
 ['benchmark/personal','Mercado','#benchmark/eeff']
];
for(const [routeName,label,url] of sections){
 const markup=invoke(()=>routeName,()=>'<div class="nav-flyout-top"><a href="#resumen">Visión ejecutiva</a></div>',{labModel:'16',data:null}, x=>x);
 const nav=markup.slice(markup.indexOf('<nav class="main-nav"'),markup.indexOf('</nav>')+6);
 assert(nav.includes(`href="${url}"`),`Falta ruta ${url}`);
 assert(nav.includes(label),'Falta acceso '+label);
 assert(!nav.includes('>Herramientas<'),'No deben volver a agruparse todos los apartados en Herramientas.');
 const topLinks=nav.match(/class="topnav-link [^"]*active[^"]*" href="[^"]+"/g)||[];
 assert.strictEqual(topLinks.length,1,`Debe existir una sección principal activa en ${routeName}`);
 assert(topLinks[0].includes(`href="${url}"`),`Sección activa incorrecta para ${routeName}`);
 assert(nav.includes('role="group" aria-label="Modelo IASPE"'));
 assert(nav.includes('role="group" aria-label="Fuentes de referencia"'));
 assert(nav.includes('role="group" aria-label="Análisis comparativo"'));
 assert(nav.includes('aria-controls="modelos-desplegable"'));
 assert(nav.includes('aria-controls="mercado-desplegable"'));
 for(const market of ['#benchmark/cartera','#benchmark/oficinas','#benchmark/eeff','#benchmark/ratios','#benchmark/personal'])assert(nav.includes(`href="${market}"`));
 assert(!nav.includes('href="#benchmark/depositos"'));assert(!nav.includes('href="#benchmark/tarjetas"'));assert(nav.includes('Análisis comercial'));assert(nav.includes('Comparación financiera'));
 const labels=['Cartera de consumo','Oficinas'];
 const positions=labels.map(label=>nav.indexOf('<b>'+label+'</b>'));
 assert(positions.every(p=>p>=0),'Faltan apartados del menú comercial');
 assert(positions.every((p,i)=>i===0||p>positions[i-1]),'Orden comercial no corresponde a la secuencia solicitada');
 assert(!nav.includes('Proyección de cartera'),'Se añadió un módulo duplicado de cartera');
 assert(!nav.includes('href="#benchmark/consumo"'),'No debe aparecer la pantalla Consumo duplicada');
}
for(const media of ['1650px','1320px','1110px','730px','440px'])assert(styles.includes(`max-width:${media}`),`Falta adaptación ${media}`);
assert(html.includes('workspace.css?v=20261119_v1913'));
assert(/workspace\.js\?v=20261124_mercado_original/.test(html));
assert(/href="nav-refine-20261120\.css(?:\?[^"]*)?"/.test(html));
assert(fs.existsSync(path.join(root,'nav-refine-20261120.css')));
assert(!styles.includes('.topnav-tools-trigger'),'La CSS anterior ya no debe existir.');
assert(!workspace.includes('<span>IASPE</span></a>'),'El logotipo no debe repetir IASPE.');
assert(workspace.includes('>MODELO</span>'),'El rótulo debe ser MODELO.');
assert(styles.includes('grid-template-columns:minmax(340px,1.27fr)'),'Distribución horizontal fluida ausente.');
assert(styles.includes('text-align:center'),'Las categorías deben estar centradas.');
console.log(`OK: ${sections.length} rutas, cinco módulos de Mercado, dos grupos, accesibilidad y estilos de navegación.`);
