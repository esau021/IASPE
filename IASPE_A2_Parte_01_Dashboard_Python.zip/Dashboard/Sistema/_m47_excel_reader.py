from zipfile import ZipFile
from xml.etree import ElementTree as ET
from pathlib import Path
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
def extract_value(file,sheet,cell):
    with ZipFile(file) as z:
        book=ET.fromstring(z.read('xl/workbook.xml'))
        rels={e.get('Id'):e.get('Target') for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        target=next(rels[e.get('{'+NS['r']+'}id')] for e in book.find('m:sheets',NS) if e.get('name')==sheet)
        t=target.lstrip('/')
        if not t.startswith('xl/'):t='xl/'+t
        root=ET.fromstring(z.read(t))
        c=root.find(f'.//m:c[@r="{cell}"]',NS)
        if c is None:raise ValueError((sheet,cell,'missing'))
        v=c.find('m:v',NS)
        if v is None:raise ValueError((sheet,cell,'missing value'))
        return float(v.text)
