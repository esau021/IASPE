"""Controles del cierre 2026 y transmisión de nuevas observaciones SBS."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import motor
import motor_01_07
from auditoria_calculos import verificar


def punto(model, year):
    return next(x for x in model['annual'] if x['year'] == year)


def mes(model, period):
    return next(x for x in model['monthly'] if x['date'][:7] == period)


class CierreIncremental(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = motor.SOURCE
        cls.base = motor_01_07.recalculate({'source_root': str(cls.root)})

    def test_mes_nuevo_sustituye_estimacion(self):
        obs = {'04': {'2026-09': 1453000, '2026-10': 1459000},
               '05': {'2026-09': 1810, '2026-10': 1840}}
        antes = motor_01_07.recalculate({'source_root': str(self.root)}, observations=obs)
        obs['04']['2026-11'] = 1495000
        obs['05']['2026-11'] = 1960
        despues = motor_01_07.recalculate({'source_root': str(self.root)}, observations=obs)
        for key in ('04', '05'):
            self.assertEqual(mes(antes[key], '2026-11')['status'], 'assumed')
            self.assertEqual(mes(despues[key], '2026-11')['status'], 'observed')
            self.assertEqual(mes(despues[key], '2026-12')['status'], 'assumed')
            self.assertNotEqual(punto(antes[key], 2026)['value'], punto(despues[key], 2026)['value'])
            self.assertNotEqual(punto(antes[key], 2027)['value'], punto(despues[key], 2027)['value'])

    def test_diciembre_real_reemplaza_cierre(self):
        obs = {'04': {'2026-12': 1530000}, '05': {'2026-12': 2100},
               '06': {'2026-12': 3250}, '01': {'2026-12': 7250000}}
        actual = motor_01_07.recalculate({'source_root': str(self.root)}, observations=obs)
        for key in ('01', '04', '05', '06', '07'):
            self.assertEqual(punto(actual[key], 2026)['status'], 'observed', key)
        self.assertAlmostEqual(punto(actual['07'], 2026)['value'], 5350, places=6)

    def test_consumo_total_y_cascada_de_modelos(self):
        previo = motor.calculate(use_macro_base=False)
        nuevo = motor.calculate(use_macro_base=False,
            observations={'04': {'2026-09': 1453000}, '05': {'2026-09': 1800}})
        principales = [m for m in nuevo['models'] if len(m['id']) == 2 and m['id'].isdigit()]
        self.assertEqual(len(principales), 49)
        self.assertFalse(nuevo['warnings'])
        audit = verificar(previo, nuevo, {'04': {'2026-09': 1453000},
                                         '05': {'2026-09': 1800}})
        self.assertTrue(audit['passed'], audit['findings'][:8])
        byid = {m['id']: m for m in nuevo['models']}
        self.assertAlmostEqual(punto(byid['07'],2026)['value'],
                               punto(byid['05'],2026)['value'] + punto(byid['06'],2026)['value'])

    def test_presupuesto_de_tesoreria_no_es_regresion(self):
        baseline = motor.calculate(use_macro_base=False)
        byid = {m['id']: m for m in baseline['models']}
        old = punto(byid['21_venta'], 2026)['value']
        update = {'sbs_contable': {'21_venta': {'2026': {
            'value': old * 1.02, 'status': 'assumed', 'sourceMonth': '2026-09'}}}}
        new = motor.calculate(observations=update, use_macro_base=False)
        actual = {m['id']: m for m in new['models']}
        self.assertNotIn(actual['21_venta']['status'], ('error', 'needs_input'))
        for year in range(2027, 2031):
            self.assertAlmostEqual(punto(actual['21_venta'],year)['value'],
                                   punto(byid['21_venta'],year)['value'],places=7)

    def test_ahorro_sin_desglose_no_se_publica(self):
        old = punto(self.base['01'], 2026)['value']
        self.assertGreater(old, 0)
        baseline = motor.calculate(use_macro_base=False)
        index = {m['id']:m for m in baseline['models']}
        total = punto(index['08'], 2026)['value']
        bad = motor.calculate(observations={'sbs_contable': {'08': {'2026': {
            'value': total * 1.05, 'status': 'assumed', 'sourceMonth': '2026-09'}}}},
            use_macro_base=False)
        changed = {m['id']:m for m in bad['models']}
        self.assertEqual(changed['08']['status'], 'needs_input')


if __name__ == '__main__':
    unittest.main()
