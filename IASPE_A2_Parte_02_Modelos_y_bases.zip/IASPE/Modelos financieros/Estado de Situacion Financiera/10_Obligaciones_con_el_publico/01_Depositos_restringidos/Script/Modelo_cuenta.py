"""Reproduce M10 desde los insumos observados y los depósitos proyectados."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"Script"))
from Proyeccion_M10 import proyectar

if __name__=="__main__":
    proyectar()
