"""Convertir el shapefile adjunto conservando códigos, islas y límites comunes.

Regeneración: pip install -r requisitos_cartografia.txt; python convertir_cartografia.py
Las dependencias se usan solo para preparar la cartografía, no en el Dashboard.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import tempfile
import zipfile

import shapefile
from shapely.geometry import shape

ROOT = Path(__file__).resolve().parents[1]
NAMES = {
    '01':'Amazonas','02':'Áncash','03':'Apurímac','04':'Arequipa','05':'Ayacucho',
    '06':'Cajamarca','07':'Callao','08':'Cusco','09':'Huancavelica','10':'Huánuco',
    '11':'Ica','12':'Junín','13':'La Libertad','14':'Lambayeque','15':'Lima',
    '16':'Loreto','17':'Madre de Dios','18':'Moquegua','19':'Pasco','20':'Piura',
    '21':'Puno','22':'San Martín','23':'Tacna','24':'Tumbes','25':'Ucayali'}
EARTH_RADIUS = 6371008.8


def normalize(value):
    import unicodedata
    return ''.join(c for c in unicodedata.normalize('NFKD',str(value).upper()) if not unicodedata.combining(c))


def rings(geometry):
    polygons = geometry['coordinates'] if geometry['type']=='MultiPolygon' else [geometry['coordinates']]
    return [[tuple(point[:2]) for point in ring] for polygon in polygons for ring in polygon]


def read_archive(file):
    with zipfile.ZipFile(file) as archive:
        by_suffix={Path(name).suffix.lower():name for name in archive.namelist()
            if Path(name).stem.upper()=='DEPARTAMENTAL' and Path(name).suffix.lower() in ('.shp','.shx','.dbf','.prj','.cpg')}
        if not all(ext in by_suffix for ext in ('.shp','.shx','.dbf','.prj')):
            raise ValueError('Falta un componente DEPARTAMENTAL del shapefile')
        prj=archive.read(by_suffix['.prj']).decode('utf-8-sig').strip()
        if ('GEOGCS[' not in prj or 'WGS_1984' not in prj or 'PROJCS[' in prj
                or 'Degree' not in prj or '6378137' not in prj or '298.257223563' not in prj
                or not re.search(r'PRIMEM\["Greenwich",0(?:\.0+)?\]',prj.replace(' ',''))):
            raise ValueError('La conversión requiere el original geográfico WGS84; otro CRS necesita reproyección explícita')
        encoding=archive.read(by_suffix['.cpg']).decode('ascii').strip() if '.cpg' in by_suffix else 'utf-8'
        reader=shapefile.Reader(shp=io.BytesIO(archive.read(by_suffix['.shp'])),
            shx=io.BytesIO(archive.read(by_suffix['.shx'])),dbf=io.BytesIO(archive.read(by_suffix['.dbf'])),encoding=encoding)
        rows=[]
        for item in reader.iterShapeRecords():
            code=str(item.record['CCDD']).zfill(2);raw_name=str(item.record['DEPARTAMEN']).strip()
            if code not in NAMES or normalize(raw_name)!=normalize(NAMES[code]):
                raise ValueError(f'Código/nombre departamental desconocido: {code}/{raw_name}')
            geometry=item.shape.__geo_interface__
            if geometry['type'] not in ('Polygon','MultiPolygon') or not shape(geometry).is_valid:
                raise ValueError(f'Geometría departamental inválida en {code}')
            for ring in rings(geometry):
                if len(ring)<4 or ring[0]!=ring[-1]:raise ValueError(f'Anillo no cerrado en {code}')
                if any(not(-82<=x<=-68 and -19<=y<=1) for x,y in ring):
                    raise ValueError(f'Coordenadas fuera de Perú/WGS84: {code}')
            rows.append({'code':code,'name':NAMES[code],'sourceName':raw_name,'geometry':geometry})
        if len(rows)!=25 or {r['code'] for r in rows}!=set(NAMES):
            raise ValueError('Se requieren los 24 departamentos y Callao, una vez cada uno')
        hashes={ext:hashlib.sha256(archive.read(name)).hexdigest() for ext,name in by_suffix.items()}
        return sorted(rows,key=lambda row:row['code']),prj,hashes


def topology(rows):
    """Identificar límites por coincidencia exacta, sin snapping ni desplazamientos."""
    edge_owners=defaultdict(set);neighbors=defaultdict(set);all_rings=[]
    for index,row in enumerate(rows):
        for ring in rings(row['geometry']):
            owner=len(all_rings);all_rings.append((index,ring))
            for a,b in zip(ring,ring[1:]):
                if a==b:continue
                edge_owners[tuple(sorted((a,b)))].add(owner)
                neighbors[a].add(b);neighbors[b].add(a)
    cuts=set()
    for point,adjacent in neighbors.items():
        ownership={frozenset(edge_owners[tuple(sorted((point,other)))]) for other in adjacent}
        if len(adjacent)!=2 or len(ownership)!=1:cuts.add(point)
    arcs=[];lookup={};ring_arcs=[];feature_arcs=defaultdict(set);protected=set()
    for feature,ring in all_rings:
        positions=[i for i,point in enumerate(ring[:-1]) if point in cuts]
        if not positions:
            sequences=[ring]
        else:
            sequences=[];body=ring[:-1];length=len(body)
            for j,start in enumerate(positions):
                end=positions[(j+1)%len(positions)]
                if end<=start:end+=length
                sequences.append([body[i%length] for i in range(start,end+1)])
        refs=[]
        for sequence in sequences:
            forward=tuple(sequence);backward=forward[::-1];canonical=min(forward,backward)
            if canonical not in lookup:lookup[canonical]=len(arcs);arcs.append(list(canonical))
            index=lookup[canonical];refs.append(index if forward==canonical else ~index)
            feature_arcs[feature].add(index)
            if sequence[0]==sequence[-1] or rows[feature]['code'] in ('07','15'):protected.add(index)
        ring_arcs.append(refs)
    return arcs,ring_arcs,feature_arcs,protected


def xyz(point):
    lon,lat=map(math.radians,point);cos=math.cos(lat)
    return (EARTH_RADIUS*cos*math.cos(lon),EARTH_RADIUS*cos*math.sin(lon),EARTH_RADIUS*math.sin(lat))


def simplify_arc(points,tolerance):
    if len(points)<=2 or points[0]==points[-1]:return points
    positions=list(map(xyz,points));keep={0,len(points)-1};stack=[(0,len(points)-1)];threshold=tolerance*tolerance
    while stack:
        start,end=stack.pop();a,b=positions[start],positions[end];delta=[b[i]-a[i] for i in range(3)]
        norm=sum(v*v for v in delta);farthest=-1;distance=threshold
        for index in range(start+1,end):
            point=positions[index]
            ratio=max(0.,min(1.,sum((point[i]-a[i])*delta[i] for i in range(3))/norm)) if norm else 0.
            squared=sum((point[i]-a[i]-ratio*delta[i])**2 for i in range(3))
            if squared>distance:distance=squared;farthest=index
        if farthest>=0:keep.add(farthest);stack.extend(((start,farthest),(farthest,end)))
    return [points[index] for index in sorted(keep)]


def rebuild(rows,arcs,references):
    ring_index=0;result=[]
    for row in rows:
        source=row['geometry'];polygons=source['coordinates'] if source['type']=='MultiPolygon' else [source['coordinates']]
        output=[]
        for polygon in polygons:
            rebuilt=[]
            for _ in polygon:
                ring=[]
                for reference in references[ring_index]:
                    sequence=arcs[reference] if reference>=0 else arcs[~reference][::-1]
                    ring.extend(sequence if not ring else sequence[1:])
                if ring and ring[-1]!=ring[0]:ring.append(ring[0])
                rebuilt.append(ring);ring_index+=1
            output.append(rebuilt)
        result.append({'type':source['type'],'coordinates':output if source['type']=='MultiPolygon' else output[0]})
    return result


def optimized(rows,tolerance):
    arcs,references,by_feature,protected=topology(rows)
    simplified=[points if index in protected else simplify_arc(points,tolerance) for index,points in enumerate(arcs)]
    original=[shape(row['geometry']) for row in rows]
    # Las pequeñas imperfecciones originales no se corrigen ni se amplían.
    overlaps={(i,j):original[i].intersection(original[j]).area for i in range(len(rows)) for j in range(i+1,len(rows))
              if original[i].envelope.intersects(original[j].envelope)}
    reverted=set()
    for _ in range(26):
        geometries=rebuild(rows,simplified,references);current=[shape(geometry) for geometry in geometries]
        bad={index for index,geometry in enumerate(current) if geometry.is_empty or not geometry.is_valid}
        for (i,j),area in overlaps.items():
            if i in bad or j in bad:continue
            if current[i].intersection(current[j]).area>area+1e-12:bad.update((i,j))
        if not bad:break
        changed=False
        for index in bad:
            for arc in by_feature[index]:
                if simplified[arc]!=arcs[arc]:simplified[arc]=arcs[arc];changed=True;reverted.add(arc)
        if not changed:raise ValueError('No se pudo preservar la geometría original')
    else:raise ValueError('La validación topológica no converge')
    geometries=[row['geometry'] if row['code'] in ('07','15') else geometry for row,geometry in zip(rows,geometries)]
    for row,geometry in zip(rows,geometries):
        if len(rings(geometry))!=len(rings(row['geometry'])):raise ValueError('Se perdió un anillo')
        if row['code'] in ('07','15') and geometry!=row['geometry']:
            if not shape(geometry).equals_exact(shape(row['geometry']),0):raise ValueError('Se alteró Lima o Callao')
    return geometries,{'arcs':len(arcs),'protectedArcs':len(protected),'revertedArcs':len(reverted)}


def save_json(file,data):
    file.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=file.parent,suffix='.tmp',delete=False) as stream:
        temp=Path(stream.name);json.dump(data,stream,ensure_ascii=False,separators=(',',':'),allow_nan=False);stream.write('\n')
    try:os.replace(temp,file)
    finally:
        if temp.exists():temp.unlink()


def geojson_orientation(geometry):
    polygons=geometry['coordinates'] if geometry['type']=='MultiPolygon' else [geometry['coordinates']]
    output=[]
    for polygon in polygons:
        oriented=[]
        for index,ring in enumerate(polygon):
            signed=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(ring,ring[1:]))
            oriented.append(ring[::-1] if (signed<0)==(index==0) else ring)
        output.append(oriented)
    return {'type':geometry['type'],'coordinates':output if geometry['type']=='MultiPolygon' else output[0]}


def convert(source,output,tolerance=100.):
    rows,prj,hashes=read_archive(source);geometries,topology_info=optimized(rows,tolerance)
    features=[]
    for row,geometry in zip(rows,geometries):
        features.append({'type':'Feature','id':row['code'],'properties':{'code':row['code'],'name':row['name'],
            'CCDD':row['code'],'DEPARTAMEN':row['sourceName']},'geometry':geojson_orientation(geometry)})
    bounds=[shape(feature['geometry']).bounds for feature in features]
    collection={'type':'FeatureCollection','bbox':[min(b[0] for b in bounds),min(b[1] for b in bounds),
        max(b[2] for b in bounds),max(b[3] for b in bounds)],'features':features}
    counts=lambda geometry:sum(len(ring) for ring in rings(geometry))
    summary={'sourceFile':source.name,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'sourceMembersSha256':hashes,'sourceCrsWkt':prj,'outputCrs':'EPSG:4326','reprojected':False,
        'features':25,'territorialCriterion':'24 departamentos y Provincia Constitucional del Callao; Lima incluye toda su geometría departamental',
        'codes':list(NAMES),'sourceVertices':sum(counts(row['geometry']) for row in rows),
        'outputVertices':sum(counts(geometry) for geometry in geometries),
        'simplification':{'method':'Douglas–Peucker sobre arcos compartidos, distancia de cuerda en esfera de radio medio terrestre',
            'toleranceMeters':tolerance,'coordinates':'Solo vértices originales, sin redondeo ni desplazamiento; orientación GeoJSON exterior antihoraria',
            'preservation':'Lima y Callao íntegros; todos los polígonos, islas y huecos originales. Se revierten arcos si generan invalidez o aumentan solapamientos.',**topology_info},
        'sourceAttribution':'Archivo Departamental.zip facilitado por el usuario; autor/fecha de la cartografía no declarados en sus atributos',
        'outputFile':output.name}
    save_json(output,collection);summary['outputSha256']=hashlib.sha256(output.read_bytes()).hexdigest();summary['outputBytes']=output.stat().st_size
    save_json(output.with_name('cartografia_metadata.json'),summary)
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=ROOT/'fuentes/Cartografia/Departamental.zip')
    parser.add_argument('--output',type=Path,default=ROOT/'output/departamentos.geojson')
    parser.add_argument('--tolerance',type=float,default=100.)
    args=parser.parse_args()
    if not math.isfinite(args.tolerance) or args.tolerance<0:parser.error('La tolerancia debe ser finita y no negativa')
    print(json.dumps(convert(args.source,args.output,args.tolerance),ensure_ascii=False))


if __name__=='__main__':main()
