/* Comparación de ratios SBS. Los criterios de orden dependen del indicador. */
(()=>{
'use strict';
const $=s=>document.querySelector(s);
const FAL='05';
const GROUPS=['Solvencia','Calidad de activos','Eficiencia y gestión','Rentabilidad','Liquidez'];
const TILES=['ratio_capital_global','morosidad','cobertura_atrasada','roe','roa'];
const LOWER=new Set(['morosidad','morosidad_90_dias','creditos_refinanciados','cartera_atrasada_ajustada','cartera_alto_riesgo_ajustada','morosidad_mn','morosidad_me','eficiencia_operativa','gastos_administracion_activo','apalancamiento_pasivo_capital']);
const HIGHER=new Set(['ratio_capital_global','capital_nivel_1','cet1','cobertura_atrasada','roe','roa']);
const MONTH=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
const SHORT=['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
const state={banks:['02'],metric:'morosidad',annual:false,showAll:false,panel:'chart',mode:'level'};
const PEER_COLORS=['#3f9566','#9d7b46','#8a5a9b','#4b7fa8','#b6605a','#7d8b3e','#7a6e63'];
let app,cat,promise,request=0;
const esc=v=>app.escape(String(v??''));
const fmt=(v,d=2)=>Number.isFinite(v)?app.fmt(v,d):'—';
const dateText=(s,short=false)=>/^\d{4}-\d{2}$/.test(String(s))?`${(short?SHORT:MONTH)[Number(s.slice(5))-1]} ${s.slice(0,4)}`:(s||'—');
const metric=id=>cat.indicadores.find(m=>m.id===id);
const bank=id=>cat.bancos.find(b=>b.id===id);
const kind=id=>LOWER.has(id)?'lower':HIGHER.has(id)?'higher':'neutral';
const obs=(id,b)=>((cat.series||{})[id]?.[b]||[]).filter(r=>!state.annual||r[0].endsWith('-12'));
const records=(id,b)=>new Map(obs(id,b).map(r=>[r[0],r]));
const latest=(id,b)=>obs(id,b).at(-1);
function chartRecords(id,b){
  const rows=obs(id,b),original=new Map(((cat.series||{})[id]?.[b]||[]).map(r=>[r[0],r[1]]));
  if(state.mode==='level')return new Map(rows.map(r=>[r[0],r]));
  return new Map(rows.map(r=>{
    const previous=original.get(`${+r[0].slice(0,4)-1}${r[0].slice(4)}`);
    return [r[0],[r[0],Number.isFinite(previous)?r[1]-previous:null]];
  }));
}
function seriesTable(m){
  const ids=[FAL,...selectedBanks()],datasets=ids.map(id=>({id,name:bank(id)?.nombre||'Falabella',map:chartRecords(m.id,id)}));
  const dates=[...new Set(datasets.flatMap(x=>[...x.map.keys()]))].sort().reverse();
  const unitText=state.mode==='level'?m.unidad:m.unidad==='%'?'pp':m.unidad;
  return `<div class="eeff-table-wrap ratio-history-table"><table><thead><tr><th>Período</th>${datasets.map(s=>`<th>${esc(s.name)}</th>`).join('')}</tr></thead><tbody>${dates.map(date=>`<tr><td>${esc(dateText(date))}</td>${datasets.map(s=>{const v=s.map.get(date)?.[1];return `<td>${Number.isFinite(v)?esc(fmt(v)):'—'}</td>`;}).join('')}</tr>`).join('')}</tbody></table></div><p class="ratio-data-unit">${esc(unitText)}</p>`;
}

const average=a=>a.length?a.reduce((s,v)=>s+v,0)/a.length:null;
const unit=m=>m.unidad==='S/ miles'?'S/ miles':m.unidad;
const nav='<nav class="market-main-tabs"><a href="#benchmark/cartera">Cartera de consumo</a><a href="#benchmark/oficinas">Oficinas</a><a href="#benchmark/eeff">Estados financieros</a><a class="active" href="#benchmark/ratios" aria-current="page">Indicadores financieros</a><a href="#benchmark/personal">Personal</a></nav>';
const selectedBanks=()=>{
  const valid=(state.banks||[]).filter(id=>id!==FAL && cat?.bancos?.some(b=>b.id===id));
  if(!valid.length){
    const fallback=cat?.bancos?.find(b=>b.id!==FAL)?.id;
    return fallback?[fallback]:[];
  }
  return [...new Set(valid)];
};
function setSelectedBanks(ids){
  state.banks=(ids||[]).filter(Boolean);
  const valid=selectedBanks();
  state.banks=valid.length?valid:state.banks;
}
function observationsFor(id){
  const selected=selectedBanks();
  const a=records(id,FAL);
  let common=[...a.keys()];
  for(const bid of selected){
    const b=records(id,bid);
    common=common.filter(d=>b.has(d));
  }
  const date=common.sort().at(-1)||null;
  const ranking=cat.bancos.map(ent=>({id:ent.id,name:ent.nombre,value:date?records(id,ent.id).get(date)?.[1]:null}))
    .filter(x=>Number.isFinite(x.value));
  const order=kind(id);
  ranking.sort((x,y)=>order==='lower'?x.value-y.value:y.value-x.value);
  const fa=ranking.find(x=>x.id===FAL)||null;
  const peers=selected.map(bid=>({id:bid,name:bank(bid)?.nombre||bid,value:date?records(id,bid).get(date)?.[1]:null}));
  const peerValues=peers.map(x=>x.value).filter(Number.isFinite);
  const bestPeer=peers.filter(x=>Number.isFinite(x.value)).sort((x,y)=>order==='lower'?x.value-y.value:y.value-x.value)[0]||null;
  return {date,ranking,fa,peers,bestPeer,avgPeer:average(peerValues),order};
}
function lineChart(m,current){
  const selected=selectedBanks();
  const datasets=[{name:'Falabella',key:'fal',color:'#214e68',values:chartRecords(m.id,FAL)}];
  selected.forEach((bid,i)=>datasets.push({name:bank(bid)?.nombre||bid,key:`peer-${bid}`,color:PEER_COLORS[i%PEER_COLORS.length],values:chartRecords(m.id,bid)}));
  const dates=[...new Set(datasets.flatMap(s=>[...s.values.keys()]))].sort();
  if(dates.length<2)return '<div class="eeff-empty">Sin serie histórica disponible.</div>';
  const vals=datasets.flatMap(s=>[...s.values.values()].map(r=>Array.isArray(r)?r[1]:r)).filter(Number.isFinite);
  if(!vals.length)return '<div class="eeff-empty">Sin información disponible.</div>';
  let lo=Math.min(...vals),hi=Math.max(...vals);const pad=Math.max((hi-lo)*.12,Math.abs(hi)*.02,.02);lo-=pad;hi+=pad;
  const W=980,H=322,L=68,R=18,T=19,B=45,w=W-L-R,h=H-T-B;
  const x=i=>L+i*w/(dates.length-1),y=v=>T+(hi-v)*h/(hi-lo);
  function path(values){let p='',prev=-2;dates.forEach((dt,i)=>{let r=values.get(dt);r=Array.isArray(r)?r[1]:r;if(!Number.isFinite(r))return;p+=(prev===i-1?'L':'M')+x(i).toFixed(2)+' '+y(r).toFixed(2)+' ';prev=i;});return p;}
  const ticks=[0,1,2,3,4].map(i=>{const v=lo+(hi-lo)*i/4,j=y(v);return `<line class="eeff-grid" x1="${L}" x2="${W-R}" y1="${j}" y2="${j}"/><text x="${L-8}" y="${j+4}" text-anchor="end">${esc(fmt(v))}</text>`;}).join('');
  const labels=[...new Set(Array.from({length:6},(_,i)=>Math.round((dates.length-1)*i/5)))].map(i=>`<text x="${x(i)}" y="${H-8}" text-anchor="middle">${esc(state.annual?dates[i].slice(0,4):dateText(dates[i],true))}</text>`).join('');
  const paths=datasets.map((s)=>`<path class="ratio-ej-line ${s.key}" d="${path(s.values)}" stroke="${s.color}"/>`).join('');
  const hits=dates.map((dt,i)=>{
    const xa=i?(x(i-1)+x(i))/2:L,xb=i<dates.length-1?(x(i)+x(i+1))/2:W-R;
    return `<rect class="ratio-ej-hit" x="${xa}" y="${T}" width="${xb-xa}" height="${h}" data-index="${i}" data-date="${dt}" tabindex="0" aria-label="${esc(dateText(dt))}"/>`;
  }).join('');
  const legend=datasets.map(s=>`<span class="ratio-ej-legend-item"><i style="background:${s.color}"></i>${esc(s.name)}</span>`).join('');
  return `<div class="ratio-ej-chart-wrap"><div class="ratio-ej-legend">${legend}</div><div class="ratio-ej-plot"><svg viewBox="0 0 ${W} ${H}" class="ratio-ej-svg" role="img" aria-label="Evolución de ${esc(m.nombre)}">${ticks}${labels}${paths}<line class="ratio-ej-cross" x1="0" x2="0" y1="${T}" y2="${H-B}" visibility="hidden"/>${hits}</svg><div class="ratio-ej-tooltip" hidden></div></div></div>`;
}
function bindChart(m){
  const plot=$('.ratio-ej-plot');if(!plot)return;
  const svg=plot.querySelector('svg'),tip=plot.querySelector('.ratio-ej-tooltip'),cross=plot.querySelector('.ratio-ej-cross');
  const datasets=[{name:'Falabella',map:chartRecords(m.id,FAL)}].concat(selectedBanks().map(bid=>({name:bank(bid)?.nombre||bid,map:chartRecords(m.id,bid)})));
  const hide=()=>{tip.hidden=true;cross.setAttribute('visibility','hidden');};
  plot.querySelectorAll('.ratio-ej-hit').forEach(hit=>{
    function show(){
      const key=hit.dataset.date,dt=dateText(key);
      const x=Number(hit.getAttribute('x'))+Number(hit.getAttribute('width'))/2;
      cross.setAttribute('x1',x);cross.setAttribute('x2',x);cross.setAttribute('visibility','visible');
      tip.hidden=false;tip.style.left=`${Math.max(17,Math.min(81,x/980*100))}%`;
      tip.innerHTML=`<strong>${esc(dt)}</strong>${datasets.map(s=>({name:s.name,value:s.map.get(key)?.[1]})).sort((a,b)=>(Number.isFinite(b.value)?b.value:-Infinity)-(Number.isFinite(a.value)?a.value:-Infinity)).map(s=>`<div><span>${esc(s.name)}</span><b>${Number.isFinite(s.value)?esc(fmt(s.value)):'—'} ${esc(state.mode==='level'?unit(m):unit(m)==='%'?'pp':unit(m))}</b></div>`).join('')}`;
    }
    hit.addEventListener('pointerenter',show);hit.addEventListener('pointermove',show);hit.addEventListener('focus',show);hit.addEventListener('blur',hide);
  });
  svg.addEventListener('pointerleave',hide);
}
function exportCSV(){
  const m=metric(state.metric),selected=selectedBanks(),all=[FAL,...selected],maps=all.map(id=>records(m.id,id));
  const periods=[...new Set(maps.flatMap(mp=>[...mp.keys()]))].sort();
  const head=['Periodo',...all.map(id=>bank(id)?.nombre||'Banco Falabella'),'Unidad'];
  const rows=[head,...periods.map(d=>[d,...all.map(id=>records(m.id,id).get(d)?.[1]??''),m.unidad])];
  const text='\ufeff'+rows.map(row=>row.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(';')).join('\r\n');
  const url=URL.createObjectURL(new Blob([text],{type:'text/csv;charset=utf-8'})),aTag=document.createElement('a');
  aTag.href=url;aTag.download=`IASPE_${m.id}_${state.annual?'anual':'mensual'}.csv`;aTag.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function toggleBankSelection(id){
  if(id===FAL)return;
  const current=new Set(selectedBanks());
  if(current.has(id) && current.size>1)current.delete(id);
  else current.add(id);
  state.banks=[...current];
  paint();
}
function paint(){
  const host=$('#workspace');if(!host)return;
  if(!cat?.ready){host.innerHTML='<div class="notice">No se encontró la base SBS.</div>';return;}
  if(!metric(state.metric))state.metric=cat.indicadores[0]?.id;
  setSelectedBanks(state.banks);
  const selected=selectedBanks();
  const m=metric(state.metric),current=observationsFor(m.id),data=current.ranking, order=current.order;
  const validRank=current.fa?data.findIndex(x=>x.id===FAL)+1:null;
  const opts=GROUPS.map(g=>`<optgroup label="${esc(g)}">${cat.indicadores.filter(i=>i.categoria===g).map(i=>`<option value="${esc(i.id)}" ${i.id===m.id?'selected':''}>${esc(i.nombre)}</option>`).join('')}</optgroup>`).join('');
  const banks=window.IASPEInstitutionGroups.html(cat.bancos.filter(b=>b.id!==FAL),current.date||cat.periodo_fin,b=>`<label class="ratio-bank-option" data-option-name="${esc(b.name.toLowerCase())}"><input type="checkbox" value="${esc(b.id)}" ${selected.includes(b.id)?'checked':''}><span>${esc(b.name)}</span></label>`);
  const selectedSummary=selected.length===1?(bank(selected[0])?.nombre||'1 entidad'):`${selected.length} entidades seleccionadas`;
  const overallDate=cat.periodo_fin||latest('roe',FAL)?.[0]||null;
  const tiles=TILES.map(id=>{const k=metric(id),point=k&&latest(id,FAL);if(!k)return '';const cutoff=point?.[0]!==overallDate&&point?dateText(point[0]):'';return `<button type="button" data-ratio-metric="${esc(id)}" class="ratio-ej-tile ${id===m.id?'is-active':''}"><span>${esc(k.nombre)}</span><strong>${point?esc(fmt(point[1])):'—'}<small>${esc(k.unidad)}</small></strong><em>${esc(cutoff)}</em></button>`;}).join('');
  const f=current.fa?.value;
  const singleSelected=current.peers.length===1?current.peers[0]:null;
  const compareValue=singleSelected?.value ?? current.bestPeer?.value ?? null;
  const compareLabel=singleSelected?singleSelected.name:'Mejor entidad seleccionada';
  const compareSub=singleSelected?'Entidad seleccionada':(current.bestPeer?.name||`${current.peers.length} seleccionados`);
  const delta=Number.isFinite(f)&&Number.isFinite(compareValue)?f-compareValue:null;
  const sign=(d)=>d===null||order==='neutral'?'neutral':((order==='lower'?-d:d)>=0?'good':'bad');
  const sortNote=order==='lower'?'Menor es mejor':order==='higher'?'Mayor es mejor':'De mayor a menor';
  const top=data.slice(0,Math.min(5,data.length));
  if(!state.showAll) for(const id of [FAL,...selected]){const row=data.find(x=>x.id===id);if(row&&!top.some(x=>x.id===id))top.push(row);}
  const chosen=state.showAll?data:top;
  const low=Math.min(...data.map(x=>x.value)),high=Math.max(...data.map(x=>x.value));
  const rankList=chosen.map(row=>{
    const index=data.findIndex(x=>x.id===row.id)+1;
    const norm=high===low?60:(order==='lower'?((high-row.value)/(high-low)):(row.value-low)/(high-low))*82+12;
    const activePeers=selected.includes(row.id);
    return `<button type="button" class="ratio-ej-rank ${row.id===FAL?'is-fal':''} ${activePeers?'is-peer':''}" data-ratio-bank="${esc(row.id)}" ${row.id===FAL?'disabled':''}><span class="ratio-ej-rank-pos">${index}</span><span class="ratio-ej-rank-name">${esc(row.name)}</span><span class="ratio-ej-rank-bar"><i style="width:${Math.max(8,Math.min(100,norm))}%"></i></span><strong>${esc(fmt(row.value))}<small>${esc(m.unidad)}</small></strong></button>`;
  }).join('');
  const period=current.date?dateText(current.date):'Sin fecha común';
  const middle=order==='neutral'?`${data.length} entidades`:(validRank?`${validRank} de ${data.length}`:'—');
  host.innerHTML=`<section class="ratio-ej-workspace">${nav}
    <header class="ratio-ej-header"><h1>Indicadores financieros</h1>${window.IASPESourceUpdates.control('ratios',overallDate)}</header>
    <div class="ratio-ej-tiles">${tiles}</div>
    <div class="ratio-ej-main">
      <section class="ratio-ej-panel ratio-ej-primary">
        <div class="ratio-ej-toolbar"><div class="ratio-ej-toolbar-title"><h2>${esc(m.nombre)}</h2><span>${esc(period)}</span></div><div class="ratio-ej-controls"><label>Indicador<select id="ratio-indicator">${opts}</select></label><div class="ratio-bank-field"><span class="ratio-bank-field-label">Comparar con</span><div class="ratio-bank-picker" id="ratio-bank-picker"><button type="button" id="ratio-bank-open" class="ratio-bank-trigger" aria-haspopup="true" aria-expanded="false" aria-controls="ratio-bank-menu"><span>${esc(selectedSummary)}</span><i aria-hidden="true"></i></button><div class="ratio-bank-menu" id="ratio-bank-menu" hidden><div class="ratio-bank-menu-header"><strong>Seleccionar entidades</strong><button type="button" id="ratio-bank-reset">Restablecer</button></div><input type="search" id="ratio-bank-search" placeholder="Buscar entidad…" aria-label="Buscar entidad"><div class="ratio-bank-options">${banks}</div><div class="ratio-bank-menu-footer"><span id="ratio-bank-count">${selected.length} seleccionados</span><button type="button" id="ratio-bank-apply">Cerrar</button></div></div></div></div><label>Frecuencia<select id="ratio-frequency"><option value="m" ${state.annual?'':'selected'}>Mensual</option><option value="a" ${state.annual?'selected':''}>Diciembre</option></select></label><button class="eeff-export" type="button" id="ratio-export">CSV</button></div></div>
        <div class="ratio-ej-stats">
          <div class="ratio-ej-stat primary"><span>Falabella</span><strong>${f!==null&&f!==undefined?esc(fmt(f)):'—'} <small>${esc(m.unidad)}</small></strong></div>
          <div class="ratio-ej-stat"><span>${esc(compareLabel)}</span><strong>${compareValue!==null&&compareValue!==undefined?esc(fmt(compareValue)):'—'} <small>${esc(m.unidad)}</small></strong><small>${esc(compareSub)}</small></div>
          <div class="ratio-ej-stat neutral"><span>Posición</span><strong>${middle}</strong><small>${esc(sortNote)}</small></div>
          <div class="ratio-ej-stat ${sign(delta)}"><span>Brecha</span><strong>${delta!==null?esc((delta>0?'+':'')+fmt(delta)):'—'} <small>${esc(m.unidad==='%'?'p.p.':m.unidad)}</small></strong><small>${singleSelected?esc(singleSelected.name):'Vs mejor seleccionado'}</small></div>
        </div>
        <div class="ratio-view-tools"><div class="segmented"><button type="button" data-ratio-value="level" class="${state.mode==='level'?'active':''}">Nivel</button><button type="button" data-ratio-value="change" class="${state.mode==='change'?'active':''}">Variación anual ${m.unidad==='%'?'(pp)':''}</button></div><div class="segmented"><button type="button" data-ratio-panel="chart" class="${state.panel==='chart'?'active':''}">Gráfico</button><button type="button" data-ratio-panel="table" class="${state.panel==='table'?'active':''}">Tabla</button></div></div>
        ${state.panel==='chart'?lineChart(m,current):seriesTable(m)}
      </section>
      <aside class="ratio-ej-panel ratio-ej-ranking"><div class="ratio-ej-ranking-head"><h2>${order==='neutral'?'Comparación del mercado':'Ranking del mercado'}</h2><span>${esc(period)}</span></div><div class="ratio-ej-ranking-rule">${esc(sortNote)} · ${data.length} entidades</div><div class="ratio-ej-rank-list">${rankList||'<p>Sin información de este periodo.</p>'}</div><button type="button" id="ratio-toggle" class="ratio-ej-toggle">${state.showAll?'Mostrar menos':`Ver las ${data.length} entidades`}</button></aside>
    </div></section>`;
  host.querySelectorAll('[data-ratio-metric]').forEach(el=>el.onclick=()=>{state.metric=el.dataset.ratioMetric;state.showAll=false;paint();});
  host.querySelectorAll('[data-ratio-bank]').forEach(el=>el.onclick=()=>toggleBankSelection(el.dataset.ratioBank));
  $('#ratio-indicator').onchange=e=>{state.metric=e.target.value;state.showAll=false;paint();};
  const picker=$('#ratio-bank-picker'),trigger=$('#ratio-bank-open'),menu=$('#ratio-bank-menu');
  const chooser=Array.from(menu.querySelectorAll('input[type="checkbox"]'));
  const closePicker=()=>{menu.hidden=true;trigger.setAttribute('aria-expanded','false');document.removeEventListener('pointerdown',outsidePicker);document.removeEventListener('keydown',escPicker);};
  function outsidePicker(e){if(!picker.contains(e.target))closePicker();}
  function escPicker(e){if(e.key==='Escape'){closePicker();trigger.focus();}}
  trigger.onclick=()=>{const opening=menu.hidden;if(!opening){closePicker();return;}menu.hidden=false;trigger.setAttribute('aria-expanded','true');document.addEventListener('pointerdown',outsidePicker);document.addEventListener('keydown',escPicker);};
  const updateCount=()=>{$('#ratio-bank-count').textContent=`${chooser.filter(x=>x.checked).length} seleccionados`;};
  // Cambio inmediato de series, sin cerrar el selector ni exigir Aplicar.
  function refreshBanks(next){
    if(!next.length){app.toast('Selecciona al menos una entidad.');return false;}
    const term=$('#ratio-bank-search')?.value||'';
    const scroll=menu.querySelector('.ratio-bank-options')?.scrollTop||0;
    closePicker();
    state.banks=next;
    paint();
    $('#ratio-bank-open').click();
    const search=$('#ratio-bank-search');
    search.value=term;search.dispatchEvent(new Event('input'));
    $('#ratio-bank-menu').querySelector('.ratio-bank-options').scrollTop=scroll;
    return true;
  }
  chooser.forEach(ch=>ch.onchange=()=>{
    const next=chooser.filter(x=>x.checked).map(x=>x.value);
    if(!next.length){ch.checked=true;updateCount();app.toast('Selecciona al menos una entidad.');return;}
    refreshBanks(next);
  });
  $('#ratio-bank-search').oninput=e=>window.IASPEInstitutionGroups.filter(menu,'.ratio-bank-option',e.target.value);
  $('#ratio-bank-reset').onclick=()=>{refreshBanks(['02']);};
  $('#ratio-bank-apply').onclick=closePicker;
  $('#ratio-frequency').onchange=e=>{state.annual=e.target.value==='a';paint();};
  $('#ratio-toggle').onclick=()=>{state.showAll=!state.showAll;paint();};
  $('#ratio-export').onclick=exportCSV;
  host.querySelectorAll('[data-ratio-value]').forEach(btn=>btn.onclick=()=>{state.mode=btn.dataset.ratioValue;paint();});
  host.querySelectorAll('[data-ratio-panel]').forEach(btn=>btn.onclick=()=>{state.panel=btn.dataset.ratioPanel;paint();});
  if(state.panel==='chart')bindChart(m);
  window.IASPESourceUpdates.bind(app);
}
async function render(newApp){
  app=newApp;await window.IASPESourceUpdates.refresh(app).catch(()=>null);
  if(!location.hash.startsWith('#benchmark/ratios'))return;
  const token=++request,host=$('#workspace');if(!host)return;host.innerHTML='<div class="empty">Cargando indicadores…</div>';
  try{promise ||=app.api('/api/benchmark/ratios');const loaded=await promise;if(token!==request||!location.hash.startsWith('#benchmark/ratios'))return;cat=loaded;paint();}
  catch(err){if(token!==request)return;promise=null;if(location.hash.startsWith('#benchmark/ratios'))host.innerHTML=`<div class="notice">${app.escape(err.message||'No se pudieron cargar los indicadores.')}</div>`;}
}
function invalidate(){request++;cat=null;promise=null;}
window.IASPERatiosSBS={render,invalidate};
})();
