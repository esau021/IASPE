/* Actualización central, clasificación histórica y respuestas tardías reales de los módulos. */
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function runtime(){
  const events=[],timers=[];
  const host={innerHTML:'',querySelectorAll:()=>[]};
  const context={window:{addEventListener(){},dispatchEvent:event=>events.push(event)},
    document:{querySelector:()=>host,querySelectorAll:()=>[],getElementById:()=>null},
    location:{hash:'#other'},URL,Intl,Date,Map,Set,console,structuredClone,
    CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},
    setTimeout:fn=>{timers.push(fn);return timers.length;},clearTimeout(){},Blob};
  vm.createContext(context);
  return {context,events,timers,host};
}
function execute(rt,file,transform=s=>s){vm.runInContext(transform(fs.readFileSync(path.join(root,file),'utf8')),rt.context,{filename:file});}
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return {promise,resolve,reject};};
const flush=async()=>{for(let i=0;i<4;i++)await Promise.resolve();};

(async()=>{
  const rt=runtime();execute(rt,'workspace-panels.js',source=>source.replace('window.IASPESourceUpdates={','globalThis.refreshBenchmarkBase=refreshBenchmarkBase;window.IASPESourceUpdates={'));
  const {window}=rt.context,updates=window.IASPESourceUpdates,groups=window.IASPEInstitutionGroups;
  const counts={eeff:0,ratios:0,personal:0,cartera:0};
  for(const [family,key] of [['eeff','IASPEBenchmarkEEFF'],['ratios','IASPERatiosSBS'],['personal','IASPEPersonalSBS'],['cartera','IASPECarteraConsumo']])window[key]={invalidate:()=>counts[family]++};
  const app={state:{data:{}},escape,toast:()=>{},render(){}};
  let status={generation:0,running:false,sources:{},pending:{pending:false}};
  updates.accept(status,app);
  status={...status,generation:1,sources:{ratios:{generation:1,status:'correcto',latestPeriod:'2026-10'}}};
  updates.accept(status,app);
  assert.deepEqual(counts,{eeff:0,ratios:1,personal:0,cartera:0});
  assert.equal(rt.events[0].type,'iaspe:sources-updated');
  assert.deepEqual(Array.from(rt.events[0].detail.sources),['ratios']);
  updates.accept(status,app);
  assert.equal(counts.ratios,1,'Una consulta repetida no debe invalidar otra vez.');
  updates.accept({...status,sources:{ratios:{...status.sources.ratios,status:'error',detail:'HTTP503'}}},app);
  assert.equal(counts.ratios,1,'Un fallo sin publicación conserva la caché válida.');
  assert(updates.control('ratios','2026-10').includes('incidencias'));
  assert(updates.control('ratios','2026-10').includes('Último dato: 2026-10'));
  updates.accept({...status,operation:{running:true,kind:'recalculation'}},app);
  assert(updates.control('eeff','2026-10').includes('disabled'));
  updates.accept({...status,operation:{running:false}},app);
  let calls=[];
  app.api=async(endpoint,payload)=>{calls.push([endpoint,payload]);return endpoint==='/api/sbs/start'?{...status,running:true,selected:payload.sources}:status;};
  await Promise.all([updates.start(app,'ratios'),updates.start(app,'personal')]);
  assert.equal(calls.filter(([endpoint])=>endpoint==='/api/sbs/start').length,1,'Los clics concurrentes no duplican el trabajo.');
  assert.deepEqual(Array.from(calls.find(([endpoint])=>endpoint==='/api/sbs/start')[1].sources),['ratios']);
  assert(updates.control('ratios','2026-10').includes('Actualizando'));
  assert(updates.control('personal','2026-10').includes('disabled'));
  const entities=[
    {id:'05',name:'Falabella',category:'Bancos'},
    {id:'15',name:'Banco Efectiva',category:'Bancos',category_history:[
      {from:'2000-01',to:'2026-05',category:'Empresas financieras',name:'Financiera Efectiva'},
      {from:'2026-06',to:null,category:'Bancos',name:'Banco Efectiva'}]},
    {id:'10',name:'InFinance XP',category:'Empresas financieras'},
    {id:'crac_18',name:'Caja Cencosud Scotia',category:'Cajas rurales'}];
  assert.equal(groups.at(entities[1],'2026-05').category,'Empresas financieras');
  assert.equal(groups.at(entities[1],'2026-06').category,'Bancos');
  const html=groups.html(entities,'2026-05',entity=>`<label><input value="${entity.id}">${entity.name}</label>`);
  assert(html.includes('aria-label="Empresas financieras"'));
  assert(html.includes('Financiera Efectiva'));
  assert(html.includes('aria-label="Cajas rurales"'));
  assert.equal((html.match(/value="crac_18"/g)||[]).length,1);
  assert.equal((html.match(/<input/g)||[]).length,4);
  assert.equal(groups.at({id:'cencosud',name:'Banco Cencosud',category:'Bancos',historical_only:true,last:'2019-02',category_history:[{from:'2012-01',to:'2019-02',category:'Bancos',name:'Banco Cencosud'},{from:'2019-03',to:null,category:'Cajas rurales',name:'Caja Cencosud'}]},'2026-09').category,'Bancos');

  // Buscar la denominación actual también encuentra la etiqueta histórica del periodo.
  const historicalHTML=groups.html([{id:'07',name:'Banco Pichincha',nombre:'Banco Pichincha',aliases:['Banco Pichincha','Banco Financiero'],category:'Bancos',category_history:[{from:'2012-01',to:'2018-07',category:'Bancos',name:'Banco Financiero'}]}],'2017-12',entity=>`<label><input value="${entity.id}" checked>${entity.name}</label>`);
  assert(historicalHTML.includes('>Banco Financiero</label>'));
  const historicalTerms=historicalHTML.match(/data-institution-search="([^"]+)"/)[1];
  assert(historicalTerms.includes('Banco Pichincha'));
  const searchRows=[{textContent:'Banco Financiero',checked:true,getAttribute:()=>historicalTerms},
                    {textContent:'BBVA Perú',checked:false,getAttribute:()=> 'Banco Continental BBVA Perú'}];
  const searchGroup={querySelectorAll:()=>searchRows};
  const searchContainer={querySelectorAll:selector=>selector==='[data-institution-group]'?[searchGroup]:searchRows};
  groups.filter(searchContainer,'.option','Pichincha');
  assert.equal(searchRows[0].hidden,false);assert.equal(searchRows[1].hidden,true);assert.equal(searchRows[0].checked,true);
  groups.filter(searchContainer,'.option','Continental');
  assert.equal(searchRows[0].hidden,true);assert.equal(searchRows[1].hidden,false);
  groups.filter(searchContainer,'.option','Peru');assert.equal(searchRows[1].hidden,false);
  groups.filter(searchContainer,'.option','Entidad inexistente');assert.equal(searchGroup.hidden,true);

  // El recálculo terminado actualiza Base sin reemplazar ediciones ni escenarios abiertos.
  const recalculationBefore={modelRevision:'v1',operation:{running:true,kind:'recalculation'}},recalculationAfter={modelRevision:'v2',operation:{running:false}};
  let baseRequests=0,baseRenders=0;
  const baseApp={state:{data:{version:'old'},changes:{},scenarios:[{id:'saved'}]},api:async endpoint=>{assert.equal(endpoint,'/api/state');baseRequests++;return {version:'new'};},render:()=>baseRenders++};
  rt.context.location.hash='#benchmark/cartera';
  assert.equal(await rt.context.refreshBenchmarkBase(baseApp,recalculationBefore,recalculationAfter),true);
  assert.equal(baseApp.state.data.version,'new');
  assert.deepEqual(baseApp.state.scenarios,[{id:'saved'}]);
  assert.equal(baseRequests,1);assert.equal(baseRenders,1);
  assert.equal(await rt.context.refreshBenchmarkBase(baseApp,recalculationAfter,recalculationAfter),false);
  baseApp.state.changes={'01':{2026:5}};
  assert.equal(await rt.context.refreshBenchmarkBase(baseApp,recalculationAfter,{modelRevision:'v3'}),false);
  assert.equal(baseRequests,1);
  assert.equal(baseApp.state.changes['01'][2026],5);
  baseApp.state.changes={};
  assert.equal(await rt.context.refreshBenchmarkBase(baseApp,{modelRevision:'v3'},{modelRevision:'v3'}),true,'El refresco pendiente puede completarse al volver a Base.');
  const delayedState=deferred();baseApp.api=()=>delayedState.promise;baseApp.state.data={version:'preserve'};
  const refresh=rt.context.refreshBenchmarkBase(baseApp,{modelRevision:'v3'},{modelRevision:'v4'});
  await flush();rt.context.location.hash='#escenarios';delayedState.resolve({version:'discard'});
  assert.equal(await refresh,false);
  assert.equal(baseApp.state.data.version,'preserve','Navegar mientras llega la respuesta no reemplaza el escenario.');
  rt.context.location.hash='#benchmark/cartera';baseApp.state.busy=true;
  assert.equal(await rt.context.refreshBenchmarkBase(baseApp,{modelRevision:'v4'},{modelRevision:'v4'}),false);
  baseApp.state.busy=false;

  // Un render manual puede consultar el nuevo sello antes del siguiente sondeo.
  const revisionRuntime=runtime();
  execute(revisionRuntime,'workspace-panels.js',source=>source.replace('window.IASPESourceUpdates={','globalThis.refreshBenchmarkBase=refreshBenchmarkBase;window.IASPESourceUpdates={'));
  revisionRuntime.context.location.hash='#benchmark/cartera';
  let revisionReads=0;
  const revisionApp={state:{data:{lastRecalculation:{generatedAt:'old'}},changes:{}},api:async()=>{revisionReads++;return {updated:true};},render(){}};
  revisionRuntime.context.window.IASPESourceUpdates.accept({modelRevision:'old'},revisionApp);
  revisionRuntime.context.window.IASPESourceUpdates.accept({modelRevision:'new'},revisionApp);
  assert.equal(await revisionRuntime.context.refreshBenchmarkBase(revisionApp,{modelRevision:'new'},{modelRevision:'new'}),true);
  assert.equal(revisionReads,1,'El sello nuevo debe quedar pendiente aunque lo lea primero un render del selector.');

  // Una respuesta anterior a invalidate no puede reponer datos viejos en la caché.
  for(const [file,key,probe] of [
    ['benchmark-eeff.js','IASPEBenchmarkEEFF','({meta,metaPromise,cacheSize:cached.size})'],
    ['benchmark-ratios.js','IASPERatiosSBS','({cat,promise})'],
    ['personal-sbs.js','IASPEPersonalSBS','({db,pending})'],
    ['mercado-cartera.js','IASPECarteraConsumo','({data,pending})']]){
    const test=runtime(),download=deferred();
    test.context.location.hash='#benchmark/'+({'IASPEBenchmarkEEFF':'eeff','IASPERatiosSBS':'ratios','IASPEPersonalSBS':'personal','IASPECarteraConsumo':'cartera'}[key]);
    test.context.window.IASPESourceUpdates={refresh:async()=>({}),bind(){},control:()=>''};
    execute(test,file,source=>source.replace(`window.${key}={render,invalidate};`,`globalThis.probe=()=>${probe};window.${key}={render,invalidate};`));
    const currentApp={state:{},api:()=>download.promise,escape,fmt:String,toast(){}};
    const loading=test.context.window[key].render(currentApp);
    await flush();
    test.context.window[key].invalidate();
    test.context.location.hash='#other';
    download.resolve({ready:true,accounts:[],banks:[],rows:[],bancos:[],registros:[]});
    await loading;
    const state=test.context.probe();
    assert(!state.meta&&!state.cat&&!state.db&&!state.data,`${file}: una respuesta vieja repuso el catálogo.`);
  }
  // Un total publicado sigue siendo válido si una categoría laboral no está publicada.
  const staff=runtime();execute(staff,'workspace-panels.js');
  staff.context.window.IASPESourceUpdates={control:()=>'',bind(){}};
  execute(staff,'personal-sbs.js',source=>source.replace('window.IASPEPersonalSBS={render,invalidate};',
    'globalThis.staffProbe={set:(application,source,changes)=>{app=application;db=source;Object.assign(state,changes)},plotValues,historicalTable,paint};window.IASPEPersonalSBS={render,invalidate};'));
  const staffApp={escape,fmt:String,state:{}},staffData={ready:true,periodo_fin:'2026-05',bancos:[
    {id:'05',nombre:'Banco Falabella',registros:2,category:'Bancos'},
    {id:'01',nombre:'Banco de Crédito del Perú',registros:1,category:'Bancos'},
    {id:'15',nombre:'Banco Efectiva',registros:2,category:'Bancos',category_history:entities[1].category_history}],registros:[
      {banco:'05',periodo:'2025-05',personal_total:1500,gerentes:10,funcionarios:90,empleados:1390,otros:10},
      {banco:'05',periodo:'2026-05',personal_total:1600,gerentes:10,funcionarios:100,empleados:1480,otros:10},
      {banco:'01',periodo:'2026-05',personal_total:4000,gerentes:10,funcionarios:999,empleados:2981,otros:10},
      {banco:'15',periodo:'2025-05',personal_total:1500,gerentes:30,funcionarios:200,empleados:1257,otros:13},
      {banco:'15',periodo:'2026-05',personal_total:1582,gerentes:31,funcionarios:null,empleados:1538,otros:13}]};
  const staffProbe=staff.context.staffProbe;
  staffProbe.set(staffApp,staffData,{peers:['15'],category:'funcionarios',panel:'table',mode:'level'});
  assert.equal(staffProbe.plotValues('15').get('2026-05'),null);
  assert(staffProbe.historicalTable().includes('<td>100</td><td>—</td>'));
  staffProbe.paint();
  assert(!staff.host.innerHTML.includes('NaN'));
  assert.equal((staff.host.innerHTML.match(/class="person-rank /g)||[]).length,2,'Una categoría ausente no debe crear una barra de cero.');
  assert(staff.host.innerHTML.includes('<small>Banco Efectiva</small><strong>—</strong><span>Comparación seleccionada</span>'),'La categoría ausente de la entidad seleccionada no debe rellenarse con cifras de otra entidad.');
  assert(staff.host.innerHTML.includes('Financiera Efectiva'),'Mayo2026 conserva la clasificación de financiera.');
  assert(staff.host.innerHTML.includes('<td>31</td><td>—</td><td>1,538</td><td>13</td><td>1,582</td>'));
  staffProbe.set(staffApp,staffData,{mode:'growth'});
  assert.equal(staffProbe.plotValues('15').get('2026-05'),null,'La categoría ausente tampoco debe convertirse en una caída de100%.');
  staffProbe.set(staffApp,staffData,{category:'personal_total',mode:'level'});
  assert.equal(staffProbe.plotValues('15').get('2026-05'),1582);
  assert(staffProbe.historicalTable().includes('1,582'));

  console.log('Benchmark update coordination: passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
