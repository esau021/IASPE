"""Registro y coordinación del sistema IASPE vigente. Los originales son de lectura."""
from __future__ import annotations
import copy
import hashlib
import importlib
import json
import math
import threading
import tempfile
from datetime import date, datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / 'IASPE' / 'Modelos financieros'
DATA = HERE / 'data'
GROUPS = ['motor_01_07', 'motor_13_16', 'motor_08_22', 'motor_23_29', 'motor_30_32', 'motor_33_45', 'motor_47', 'motor_48_49']
LOCK = threading.RLock()
_BASE = None
_MACROS = None
MACRO_NAMES = {'pbi': 'PBI', 'inflacion': 'Inflación', 'desempleo': 'Desempleo', 'tpm': 'Tasa de política monetaria', 'pbi_mensual': 'PBI mensual', 'tc_cierre': 'Tipo de cambio de cierre', 'tc_promedio': 'Tipo de cambio promedio'}
DESCRIPTIONS = {
 'pbi': 'Variación real de la actividad económica. Su incidencia depende del signo y rezago de cada regresión.',
 'inflacion': 'Variación de precios utilizada por las regresiones del sistema.',
 'desempleo': 'Tasa de desempleo; M03 y M05 A.2 ya no tienen una regresora de desempleo. Su transmisión se limita a otros modelos que la utilizan, como M48.',
 'tpm': 'Tasa de referencia de política monetaria. No equivale a una tasa propia del banco.',
 'pbi_mensual': 'Serie mensual histórica legada. El Modelo 06 ya no la utiliza para pronósticos.',
 'tc_cierre': 'Tipo de cambio al cierre del año. Regresora del ahorro en moneda extranjera (08_ME).',
 'tc_promedio': 'Tipo de cambio promedio del año. Referencia macroeconómica sin vínculo en las regresiones vigentes.'}


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items() if not str(k).startswith('_')}
    if isinstance(value, (tuple, list, set)):
        return [clean(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if hasattr(value, 'item'):
        return clean(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def rows(model, frequency):
    values = model.get(frequency, [])
    if not values and frequency == 'annual':
        values = model.get('series', [])
    if isinstance(values, dict):
        values = [dict(year=int(y), value=v) if not isinstance(v, dict) else dict(year=int(y), **v) for y, v in values.items()]
    result = []
    for item in values:
        r = dict(item)
        if 'year' not in r and r.get('date'):
            r['year'] = int(str(r['date'])[:4])
        if 'date' not in r and r.get('year'):
            r['date'] = f"{r['year']}-12-31"
        status = r.get('status')
        if status not in {'observed', 'assumed', 'forecast'}:
            status = 'observed' if r.get('observed') is not None else 'assumed' if r.get('assumed') is not None else 'forecast'
        value = r.get('value')
        if value is None:
            value = r.get(status)
        if value is None:
            continue
        r.update(value=float(value), status=status)
        for key in ['observed', 'assumed', 'forecast']:
            r[key] = float(value) if status == key else None
        result.append(r)
    return sorted(result, key=lambda r: str(r.get('date', r.get('year'))))


def normalize(model):
    m = copy.deepcopy(model)
    m['id'] = str(m['id'])
    m['annual'] = rows(m, 'annual')
    m['monthly'] = rows(m, 'monthly')
    m['equationTex'] = m.get('equationTex') or m.get('equationLatex') or m.get('formulaTex') or ''
    m['coefficients'] = m.get('coefficients') or m.get('statistics', {}).get('coefficients', [])
    m['dependencies'] = m.get('dependencies', [])
    m['inputs'] = m.get('inputs', [])
    m['sourceFiles'] = m.get('sourceFiles', [])
    m['status'] = m.get('status', 'ok')
    number = int(m['id'][:2])
    m['group'] = ('Variables operativas' if number in {1, 2, 3, 4, 13, 14, 15, 30, 49}
                  else 'Estado de resultados' if number in {12, 16, 18, 19, 20, 23, 24, 25, 26, 27, 28, 29}
                  else 'Estado de situación financiera')
    m['role'] = 'Consolidación' if m['id'] in {'07', '08', '09', '10', '12', '16', '17', '18', '19', '20', '21', '22', '23', '29'} else 'Componente' if '_' in m['id'] else 'Modelo principal'
    return clean(m)


def model_map(result):
    if isinstance(result, list):
        return {str(m['id']): m for m in result}
    if 'models' in result:
        return model_map(result['models'])
    return {str(k): v for k, v in result.items() if isinstance(v, dict) and v.get('id') is not None}


def modules():
    return [importlib.import_module(name) for name in GROUPS]


def load_base(refresh=False):
    global _BASE, _MACROS
    with LOCK:
        if _BASE is not None and not refresh:
            return copy.deepcopy(_BASE), copy.deepcopy(_MACROS)
        models, macros = {}, []
        for module in modules():
            group_models = model_map(module.build_registry(SOURCE))
            models.update(group_models)
            if hasattr(module, 'get_macros'):
                data = module.get_macros(SOURCE)
                if isinstance(data, dict):
                    data = [dict(id=k, values=v) if isinstance(v, dict) and 'id' not in v else v for k, v in data.items()]
                for item in data:
                    if not item.get('modelIds') and not item.get('models'):
                        item['modelIds'] = [m['id'] for m in group_models.values() if any(x.get('id') == item['id'] for x in m.get('inputs', []) if isinstance(x, dict))]
                macros.extend(data)
        for item in reference_macros():
            if not any(m['id'] == item['id'] for m in macros):
                macros.append(dict(item, frequency='annual'))
        _BASE = {k: normalize(v) for k, v in models.items()}
        if '17_bancos' in _BASE:
            _BASE['17_bancos']['method']='Saldo residual de liquidez, conciliación SBS del Estado de Situación Financiera (M47).'
            _BASE['17_bancos']['coefficients']=[]
            _BASE['17_bancos']['statistics']={}
            _BASE['17_bancos']['dependencies']=['47']
            _BASE['17_bancos']['equationTex']=r'Bancos_t=Pasivo_t+Patrimonio_t-Activos_t^{\neg Bancos}'

        _MACROS = clean(macros)
        return copy.deepcopy(_BASE), copy.deepcopy(_MACROS)


def read_state(name, default):
    path = DATA / name
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else copy.deepcopy(default)


def write_state(name, value):
    if name == 'ultimo_recalculo.json':
        # Un intento fallido no elimina la fecha del último éxito documentado.
        with LOCK:
            previous = read_state(name, None)
            successful = lambda report: isinstance(report, dict) and report.get('ok') is True and report.get('status') in ('completo', 'success', 'published')
            updates = {name:value}
            if successful(value):
                updates['ultimo_recalculo_exitoso.json'] = value
            elif successful(previous):
                updates['ultimo_recalculo_exitoso.json'] = previous
            write_states(updates)
    else:
        write_states({name: value})


def write_states(updates):
    """Publica una fotografía coherente; revierte todos los JSON si falla."""
    import os
    DATA.mkdir(parents=True, exist_ok=True)
    with LOCK, tempfile.TemporaryDirectory(prefix='iaspe_estado_', dir=str(DATA)) as temporary:
        stage = Path(temporary)
        previous, changed = {}, []
        for name, value in updates.items():
            if Path(name).name != name:
                raise ValueError('Nombre de estado no válido')
            (stage/name).write_text(json.dumps(clean(value), ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
            target = DATA/name
            previous[name] = target.read_bytes() if target.exists() else None
        try:
            for name in updates:
                os.replace(stage/name, DATA/name)
                changed.append(name)
        except Exception:
            for name in reversed(changed):
                target = DATA/name
                if previous[name] is None:
                    target.unlink(missing_ok=True)
                else:
                    saved = stage/name
                    saved.write_bytes(previous[name])
                    os.replace(saved, target)
            raise


def reference_macros():
    return read_state('supuestos_macro.json', {'variables': []})['variables']


def macro_registry(items):
    result = {}
    for item in items:
        if not isinstance(item, dict) or not item.get('id'):
            continue
        key = item['id']
        m = result.setdefault(key, {'id': key, 'name': MACRO_NAMES.get(key, item.get('name', key)), 'unit': item.get('unit', '%'), 'frequency': item.get('frequency', 'annual'), 'values': {}, 'variants': [], 'description': DESCRIPTIONS.get(key, '')})
        values = item.get('values', {})
        if isinstance(values, list):
            values = {str(r.get('year', r.get('date'))): r.get('value') for r in values}
        values = {str(k): v for k, v in values.items() if isinstance(v, (int, float))}
        m['variants'].append({'modelIds': item.get('modelIds', item.get('models', [])), 'values': values})
        for year, value in values.items():
            if year not in m['values']:
                m['values'][year] = value
            elif m['values'][year] is not None and abs(m['values'][year] - value) > 1e-8:
                m['values'][year] = None
    ordered = []
    for reference in reference_macros():
        key = reference['id']
        m = result.get(key, dict(id=key, frequency='annual', variants=[], values={}))
        m.update(name=reference['name'], unit=reference['unit'], referenceOnly=reference.get('referenceOnly', False) and key != 'tc_cierre')
        m['values'].update(reference['values'])
        ordered.append(m)
    ordered += [m for k, m in result.items() if k not in {r['id'] for r in ordered}]
    return ordered


# La base macroeconómica operativa se almacena separada de los Excel originales.
# Nunca se escribe en Input/Output de los modelos por una edición de escenarios.
def macro_base_state():
    state = read_state('base_macro_aplicada.json', {'changes': {}, 'appliedAt': None})
    if not isinstance(state, dict) or not isinstance(state.get('changes', {}), dict):
        raise ValueError('La configuración de la base macroeconómica está dañada.')
    return state


def _combine_macros(base, delta):
    combined = copy.deepcopy(base)
    for variable, values in delta.items():
        combined.setdefault(variable, {}).update({str(k): float(v) for k, v in values.items()})
    return {k: v for k, v in combined.items() if v}


def _macro_report(before, after, warnings, proposed):
    changes = []
    for mid, new in after.items():
        old = {row['year']: row['value'] for row in before[mid]['annual']}
        for row in new['annual']:
            year = row['year']
            if 2026 <= year <= 2030 and year in old and abs(row['value'] - old[year]) > 1e-7:
                changes.append({'id': mid, 'year': year, 'before': old[year], 'after': row['value']})
    issues = [{'id': mid, 'name': m['name'], 'messages': m.get('issues', [])[:3]}
              for mid, m in after.items() if m.get('status') in {'needs_input', 'error'}]
    main = sorted({r['id'] for r in changes if len(r['id']) == 2})
    return {'complete': not warnings and not issues,
            'partial': bool(warnings or issues),
            'changedModels': main,
            'changedComponents': len(set(r['id'] for r in changes)),
            'changedValues': len(changes),
            'warnings': warnings,
            'issues': issues,
            'variables': sorted(proposed),
            'preservedOriginalExcels': True,
            'notice': ('Recálculo parcial: algunos modelos conservan salidas originales o requieren insumos adicionales.'
                       if warnings or issues else 'Los modelos compatibles fueron recalculados en la base operativa.')}


def prepare_macro_base(changes=None, reset=False):
    """Previsualiza un nuevo escenario base sin modificar la base instalada ni los libros Excel."""
    changes = changes or {}
    if not isinstance(changes, dict):
        raise ValueError('Los cambios macroeconómicos deben ser un objeto.')
    for variable, values in changes.items():
        if not isinstance(values, dict):
            raise ValueError(f'La senda macroeconómica {variable} es inválida.')
        for period, value in values.items():
            if not (str(period)[:4].isdigit() and 2026 <= int(str(period)[:4]) <= 2030):
                raise ValueError('Solo se pueden aplicar pronósticos macro de 2026 a 2030.')
            if not isinstance(value, (float, int)) or isinstance(value, bool) or not math.isfinite(value):
                raise ValueError(f'Valor macroeconómico inválido para {variable}/{period}.')
    existing = macro_base_state().get('changes', {})
    proposed = {} if reset else _combine_macros(existing, changes)
    original, macros = load_base()
    allowed = {m['id'] for m in macros}
    if set(proposed) - allowed:
        raise ValueError('Variables macroeconómicas no reconocidas: ' + ', '.join(sorted(set(proposed) - allowed)))
    obs = all_observations()
    previous, _ = _run(original, existing, obs)
    after, warnings = _run(original, proposed, obs)
    for mid, model in after.items():
        for row in model.get('annual', []):
            value = row.get('value')
            if value is None or not math.isfinite(float(value)):
                raise ValueError(f'Recálculo inválido para el modelo {mid}, año {row.get("year")}')
    report = _macro_report(previous, after, warnings, proposed)
    report['changedMacroCells'] = sum(1 for mid, vals in proposed.items()
             for period, value in vals.items() if existing.get(mid, {}).get(period) != value)
    report['activeCells'] = sum(len(x) for x in proposed.values())
    report['proposed'] = proposed
    return report


def apply_macro_base(changes=None, reset=False):
    """Publica solo la configuración del escenario base, sin reescribir proyecciones originales.

    Se acepta explícitamente una base PARCIAL con advertencias: las celdas afectadas
    se recalculan y las dependencias incompletas se marcan, nunca se presentan como validadas.
    """
    with LOCK:
        report = prepare_macro_base(changes, reset)
        old = macro_base_state()
        history = read_state('historial_base_macro.json', [])
        if not isinstance(history, list):
            history = []
        history.append({'previous': old, 'changedAt': datetime.now(timezone.utc).isoformat()})
        write_state('historial_base_macro.json', history[-20:])
        applied = datetime.now(timezone.utc).isoformat()
        write_state('base_macro_aplicada.json', {
            'changes': report['proposed'], 'appliedAt': applied,
            'complete': report['complete'],
            'report': {k: v for k, v in report.items() if k != 'proposed'},
        })
        return {k: v for k, v in report.items() if k != 'proposed'} | {'appliedAt': applied}


def graph(models, macros):
    nodes = [dict(id=m['id'], name=m['name'], group=m['group'], role=m['role'], unit=m.get('unit', ''), kind='model') for m in models.values()]
    nodes += [dict(id=m['id'], name=m['name'], group='Variables de origen', role='Origen', unit=m['unit'], kind='macro') for m in macros]
    ids = {n['id'] for n in nodes}
    edges = []
    for m in models.values():
        inputs = {str(x.get('id', x.get('source', ''))): x for x in m.get('inputs', []) if isinstance(x, dict)}
        dependencies = list(m.get('dependencies', []))
        known = {str(d.get('id', d.get('source', ''))) if isinstance(d, dict) else str(d) for d in dependencies}
        dependencies += [x for x in m.get('inputs', []) if isinstance(x, dict) and x.get('id') in ids and x.get('id') not in known]
        for dep in dependencies:
            d = dep if isinstance(dep, dict) else {'id': str(dep)}
            source = str(d.get('id', d.get('source', d.get('from', ''))))
            if source not in ids or source == m['id']:
                continue
            detail = {**inputs.get(source, {}), **d}
            matching = [x for x in m.get('inputs', []) if isinstance(x, dict) and x.get('id') == source]
            lags = list(dict.fromkeys(x.get('lag', 0) for x in matching))
            if len(lags) > 1:
                detail['lag'] = ', '.join(map(str, lags))
            edges.append({'source': source, 'target': m['id'], 'name': detail.get('variable', detail.get('name', detail.get('label', MACRO_NAMES.get(source, models.get(source, {}).get('name', source))))), 'unit': detail.get('unit', models.get(source, {}).get('unit', '%')), 'lag': detail.get('lag', ''), 'transformation': detail.get('transformation', detail.get('transform', '')), 'description': detail.get('description', detail.get('interpretation', '')), 'equationTex': m['equationTex']})
    return {'nodes': nodes, 'edges': edges}


def _aplicar_sbs(modelos, datos, alcance):
    observaciones = (datos or {}).get('sbs_contable', {})
    pendientes = []
    for modelo, periodos in observaciones.items():
        if modelo not in modelos or (modelo[:2] in {'23', '24', '25', '26', '27', '28', '29'}) != (alcance == 'resultados'):
            continue
        m = modelos[modelo]
        manual = (datos or {}).get(modelo, {})
        cambios = []
        for r in m['annual']:
            y = str(r['year'])
            if y not in periodos or y in manual:
                continue
            nuevo = periodos[y]
            valor = float(nuevo['value'])
            estado = nuevo['status']
            if estado not in {'observed', 'assumed'} or not math.isfinite(valor):
                raise ValueError(f'Observación SBS incorrecta para {modelo} / {y}.')
            if estado == 'observed' and y == '2026' and str(nuevo.get('sourceMonth', ''))[:7] != '2026-12':
                raise ValueError(f'El cierre observado {modelo}/2026 requiere diciembre de 2026.')
            if abs(float(r['value']) - valor) > 1e-7:
                cambios.append(int(y))
            r.update(value=valor, status=estado,
                     observed=valor if estado == 'observed' else None,
                     assumed=valor if estado == 'assumed' else None,
                     forecast=None, sourceMonth=nuevo['sourceMonth'])
            if modelo=='25':
                for field in ('method','sourceValue','previousQuarterAccumulated'):
                    if field in nuevo:r[field]=nuevo[field]
        if cambios:
            # El cierre se actualiza; no se atribuye una reestimación inexistente.
            if modelo not in {'21_venta','24','25','26','27'} and not m.get('reestimated') and any(r['year'] > max(cambios) and r['status'] == 'forecast' for r in m['annual']):
                m['status'] = 'needs_input'
                m.setdefault('issues', []).append('Cierre SBS incorporado; falta reestimar la proyección posterior con el script original.')
                pendientes.append(modelo)
    # Ajustar la consolidación cuando el usuario corrigió gastos de personal.
    personal = (datos or {}).get('19_personal', {})
    referencia = observaciones.get('19_personal', {})
    for periodo, importe in personal.items():
        if periodo not in referencia or not (periodo.isdigit() and len(periodo) == 4):
            continue
        anio = int(periodo)
        diferencia = float(importe) - float(referencia[periodo]['value'])
        if alcance == 'operativos':
            ajustes = [('19', diferencia)]
        else:
            ajustes = [('28', -0.27 * diferencia), ('29', -0.73 * diferencia)]
        for modelo, ajuste in ajustes:
            if modelo not in modelos or periodo not in observaciones.get(modelo, {}):
                continue
            fila = next((r for r in modelos[modelo]['annual'] if r['year'] == anio), None)
            if fila:
                fila['value'] += ajuste
                fila['observed'] = fila['value'] if fila['status'] == 'observed' else None
                fila['assumed'] = fila['value'] if fila['status'] == 'assumed' else None
    if alcance == 'resultados':
        diferencia_resultado = {}
        for modelo, signo in (('24', 1), ('25', -1), ('26', -1), ('27', -1)):
            overrides = (datos or {}).get(modelo, {})
            referencia = observaciones.get(modelo, {})
            for periodo, importe in overrides.items():
                if periodo not in referencia or not (len(periodo) == 4 and periodo.isdigit()):
                    continue
                delta = signo * (float(importe) - float(referencia[periodo]['value']))
                diferencia_resultado[periodo] = diferencia_resultado.get(periodo, 0) + delta
        for periodo, delta in diferencia_resultado.items():
            for modelo, ajuste in (('28', 0.27 * delta), ('29', 0.73 * delta)):
                if modelo not in modelos or periodo not in observaciones.get(modelo, {}):
                    continue
                fila = next((r for r in modelos[modelo]['annual'] if r['year'] == int(periodo)), None)
                if fila:
                    fila['value'] += ajuste
                    fila[fila['status']] = fila['value']
    return [f'Cierre SBS actualizado; las proyecciones posteriores de {len(pendientes)} componentes requieren recalibración.'] if pendientes else []


def _reconciliar_consolidados_2026(current, base, observations):
    """Cuadra en memoria los cierres 2026, sin alterar datos ni Excel de origen.

    Los efectos de un nuevo componente contable deben llegar a su total ANTES
    del recálculo del P&L. Conserva el residuo contable del paquete aprobado.
    Los cierres SBS consolidados de diciembre observado se contrastan, nunca
    se sobreescriben sin evidencia de sus componentes.
    """
    groups = [
        ('08', [('08_mn',1),('08_me',1)]),
        ('09', [('09_plazo',1),('09_cts',1)]),
        ('10', [('08',1),('09',1),('10_restringidos',1),('10_otras',1)]),
        ('12', [('12_obligaciones',1),('12_entidades',1),('12_adeudos',1),('12_otras',1)]),
        ('16', [('16_creditos',1),('16_inversiones',1),('16_disponible',1),('16_interbancarios',1)]),
        ('17', [('17_caja',1),('17_bancos',1),('17_canje',1),('17_otros',1)]),
        ('18', [('18_diversos',1),('18_otros_ing',1),('18_gastos_div',-1),('18_otros_gastos',-1)]),
        ('19', [('19_personal',1),('19_directorio',1),('19_terceros',1),('19_impuestos',1)]),
        ('20', [('20_consorcios',1),('20_asociadas',1),('20_tc',1),('20_derivados',1),('20_inversiones',1),('20_otros',1)]),
        ('21', [('21_venta',1),('21_asociadas',1),('21_otras',1)]),
        ('22', [('22_interbancarios',1)]),
    ]
    def get(mid, source, year=2026):
        if mid not in source:return None
        return next((r for r in source[mid]['annual'] if r['year']==year),None)
    discrepancies=[]
    for parent, components in groups:
        parent0, parent1 = get(parent,base), get(parent,current)
        if parent0 is None or parent1 is None:continue
        delta=0.
        parts=[]
        for child, sign in components:
            old,new=get(child,base),get(child,current)
            if old is None or new is None:continue
            change=sign*(float(new['value'])-float(old['value']))
            delta+=change
            if abs(change)>1e-8:parts.append(child)
        direct=(observations or {}).get('sbs_contable',{}).get(parent,{}).get('2026')
        if not direct:
            direct=(observations or {}).get(parent,{}).get('2026')
        # Al recargar un Excel ya sincronizado, los componentes no cambian.
        # La estimación consolidada independiente sigue siendo provisional y
        # debe contrastarse/restaurarse con la misma identidad de componentes.
        if not parts and not direct:continue
        if not parts and parent=='08' and not {'08_mn','08_me'}.issubset((observations or {}).get('sbs_contable',{})):
            # Un ahorro total nuevo sin desglose no acredita los saldos por
            # moneda requeridos por los dos modelos; conservar el bloqueo.
            continue
        expected=float(parent0['value'])+delta
        if direct and isinstance(direct,dict) and direct.get('status')=='observed':
            if abs(float(direct['value'])-expected)>0.05:
                raise ValueError(f'Cierre observado {parent}/2026 no cuadra con componentes; diferencia {float(direct["value"])-expected:.6f} S/ MM.')
            continue
        if direct and abs(float(direct['value'] if isinstance(direct,dict) else direct)-expected)>0.05:
            discrepancies.append(dict(model=parent, year=2026,
                independent=float(direct['value'] if isinstance(direct,dict) else direct),
                reconciled=expected, method='Consolidación de componentes'))
        parent1.update(value=expected, status='assumed', assumed=expected,
                       forecast=None, observed=None, reestimatedBy='componentes')
        current[parent]['reestimated']=True
        current[parent]['canUpdate']=True
        current[parent]['status']='ok'
        current[parent].pop('issues',None)
    return discrepancies


def _run(base, changes, observations):
    current = copy.deepcopy(base)
    warnings = []
    reconciliations = []
    if changes or observations:
        for module in modules():
            if module.__name__ == 'motor_23_29':
                # Aplicar primero las observaciones SBS de gastos y provisiones.
                # Su efecto debe entrar al impuesto y al resultado del ejercicio.
                _aplicar_sbs(current, observations, 'resultados')
            context = {'source_root': SOURCE, 'sourceRoot': SOURCE, 'models': current, 'upstream': current, 'original_models': base, 'results': {k: v['annual'] for k, v in current.items()}}
            result = module.recalculate(context, changes, observations)
            if isinstance(result, dict):
                warnings.extend(result.get('warnings', []))
            current.update({k: normalize(v) for k, v in model_map(result).items()})
            if module.__name__ == 'motor_23_29':
                # Comprobar los totales SBS observados antes de concluir el cierre.
                for key in ('23', '28', '29'):
                    target = (observations.get('sbs_contable', {}).get(key, {})
                              if isinstance(observations.get('sbs_contable'), dict) else {})
                    for period, source in target.items():
                        if not isinstance(source, dict) or source.get('status') != 'observed':
                            continue
                        item = next((r for r in current[key]['annual'] if str(r['year']) == period), None)
                        if item and abs(float(item['value']) - float(source['value'])) > 0.05:
                            raise ValueError(f'Cierre SBS observado {key}/{period} no concilia con sus componentes.')
            if module.__name__ == 'motor_08_22':
                _aplicar_sbs(current, observations, 'operativos')
                from motor_actualizacion import ejecutar
                pendientes = ejecutar(current, base, observations, changes, SOURCE)
                reconciliations += _reconciliar_consolidados_2026(current, base, observations)
                if pendientes:
                    warnings.append('Recálculos no concluidos: ' + '; '.join(pendientes))

    final_pending=[k for k,v in current.items() if v.get('status')=='needs_input'
                   and not v.get('reestimated')]
    if final_pending:
        warnings.append('Modelos con información pendiente para recálculo: '+', '.join(sorted(final_pending)))
    # Las discrepancias entre extrapolaciones *provisionales* son información
    # de conciliación, no errores de la fuente. No bloquear por ellas la
    # publicación: cada total queda respaldado por la identidad de componentes.
    # Un cierre SBS observado y no conciliado sigue disparando ValueError arriba.
    for item in reconciliations:
        current[item['model']]['sbsReconciliation'] = {
            'year': item['year'],
            'independentEstimate': item['independent'],
            'componentsEstimate': item['reconciled'],
            'difference': item['independent']-item['reconciled'],
            'reason': 'Cierre provisional conciliado por componentes; extrapolación independiente conservada para auditoría.'
        }
    return current, warnings


def source_observations():
    """Observaciones descargadas por SBS, aún NO necesariamente aplicadas."""
    sbs_file = SOURCE.parent / 'Scraper' / 'Actualizacion' / 'output' / 'observaciones_modelos.json'
    return json.loads(sbs_file.read_text(encoding='utf-8')) if sbs_file.is_file() else {}


def source_flat(data):
    """Compara periodos individuales, incluso cierres contables anidados."""
    flat = {}
    for key, value in (data or {}).items():
        if key == 'sbs_contable':
            for mid, periods in value.items():
                for period, detail in periods.items():
                    flat[f'{mid}/{period}'] = detail
        elif isinstance(value, dict):
            for period, detail in value.items():
                flat[f'{key}/{period}'] = detail
    return flat


def source_delta(before, after):
    old, new = source_flat(before), source_flat(after)
    changed = [{'model': k.split('/')[0], 'period': k.split('/', 1)[1],
                'previous': old.get(k), 'current': v}
               for k, v in new.items() if old.get(k) != v]
    changed.sort(key=lambda entry: (entry['model'], entry['period']))
    return changed


def freeze_sources():
    """Congela la última versión aplicada antes de iniciar una descarga."""
    if not (DATA / 'fuentes_aplicadas.json').exists():
        write_state('fuentes_aplicadas.json', read_state('fuentes_iniciales.json', {}))


def _combine_observed(automatic, manual):
    combined = copy.deepcopy(automatic)
    for key, periods in manual.items():
        combined.setdefault(key, {}).update(periods)
    return combined


def _manual_applied():
    # Migración: los registros manuales de instalaciones anteriores se respetan.
    # Al hacer una nueva carga se crea la fotografía explícita previa al cambio.
    return read_state('observaciones_aplicadas.json', read_state('observaciones.json', {}))


def all_observations(applied=True):
    """Una sola base: la observación manual prevalece sobre SBS en el mismo mes.

    Lo guardado sin recalcular permanece visible como pendiente, nunca como
    pronóstico oficial. Benchmark de otros bancos no entra al motor Falabella.
    """
    automatic = (read_state('fuentes_aplicadas.json', read_state('fuentes_iniciales.json', {}))
                 if applied else source_observations())
    manual = _manual_applied() if applied else read_state('observaciones.json', {})
    return _combine_observed(automatic, manual)


def latest_observations():
    return all_observations(applied=False)


def pending_sources():
    old_auto = read_state('fuentes_aplicadas.json', read_state('fuentes_iniciales.json', {}))
    new_auto = source_observations()
    old_manual = _manual_applied()
    new_manual = read_state('observaciones.json', {})
    auto_deltas = source_delta(old_auto, new_auto)
    manual_deltas = source_delta(old_manual, new_manual)
    effective_deltas = source_delta(_combine_observed(old_auto, old_manual),
                                    _combine_observed(new_auto, new_manual))
    overrides = sum(len(v) for v in new_manual.values() if isinstance(v, dict))
    return {'pending': bool(effective_deltas), 'observations': len(effective_deltas),
            'manualPending': len(manual_deltas), 'automaticPending': len(auto_deltas),
            'manualRecords': overrides, 'manualModels': sorted(new_manual),
            'manualDetails': manual_deltas[:200], 'manualTruncated': len(manual_deltas)>200,
            'models': sorted({d['model'] for d in effective_deltas}),
            'details': effective_deltas[:200], 'truncated': len(effective_deltas) > 200}


def recalculate_sources():
    """Valida y aplica fuentes únicamente cuando los respaldos están sincronizados.

    La descarga y el cálculo en memoria no constituyen persistencia de los
    pronósticos. Si falta recalcular o guardar algún componente, la descarga
    permanece pendiente y el escenario aprobado sigue siendo el visible.
    """
    downloaded = source_observations()
    old = read_state('fuentes_aplicadas.json', read_state('fuentes_iniciales.json', {}))
    old_effective = all_observations(applied=True)
    new_effective = latest_observations()
    differences = source_delta(old_effective, new_effective)
    # Sin datos nuevos no hay nada que publicar. Verificar el mismo escenario
    # operativo en memoria (incluida la base macro aplicada), evitando comparar
    # resultados de escenarios distintos y generar falsos descuadres.
    if not differences:
        active = calculate()
        from auditoria_fuentes import verificar_fuentes
        from auditoria_persistencia import verificar_respaldo
        base_books = load_base(refresh=True)[0]
        applied, pending = _run(base_books, macro_base_state().get('changes', {}), all_observations(applied=True))
        matching = verificar_respaldo(active['models'], applied)
        integrity = verificar_fuentes(SOURCE)
        warnings = list(active.get('warnings') or []) + list(pending)
        if not integrity['passed']:
            warnings += integrity['errors'][:10]
        if not matching['passed']:
            warnings += matching['details'][:10]
        # Puede haber novedades SBS completamente cubiertas por una corrección
        # manual. Se registran sin cambiar el pronóstico, y desaparecen del
        # listado pendiente una vez que la versión aplicada queda conciliada.
        if not warnings:
            old_auto=read_state('fuentes_aplicadas.json',read_state('fuentes_iniciales.json',{}))
            old_manual=_manual_applied()
            new_manual=read_state('observaciones.json',{})
            updates = {}
            if source_delta(old_auto,downloaded):
                updates['fuentes_aplicadas.json'] = downloaded
            if source_delta(old_manual,new_manual):
                updates['observaciones_aplicadas.json'] = new_manual
            if updates:
                write_states(updates)
        report = {'generatedAt':datetime.now(timezone.utc).isoformat(),
                  'observations':0,'sourceModels':[],
                  'changedModels':[],'proposedChanges':[],
                  'warnings':warnings,'issues':[],
                  'audit':{'passed':integrity['passed'],
                           'checks':integrity['checks'],'errors':len(integrity['errors'])},
                  'persistence':matching,'publication':None,
                  'ok':not warnings,'status':'completo' if not warnings else 'pendiente',
                  'modelsCount':49}
        write_state('ultimo_recalculo.json', report)
        active['recalculation']=report
        active['lastRecalculation']=report
        active['sourceUpdates']=pending_sources()
        return active
    previous = calculate(observations=old_effective, use_macro_base=False)
    updated = calculate(observations=new_effective, use_macro_base=False)
    if len([m for m in updated['models'] if len(m['id']) == 2 and m['id'].isdigit()]) != 49:
        raise RuntimeError('El cálculo no conservó los 49 modelos principales.')

    old_models = {m['id']: m for m in previous['models']}
    changed_models = []
    for m in updated['models']:
        old_rows = {r['year']: r for r in old_models[m['id']]['annual']}
        deltas = [{'year': r['year'], 'previous': old_rows[r['year']]['value'],
                   'current': r['value']}
                  for r in m['annual'] if r['year'] in old_rows
                  and abs(r['value'] - old_rows[r['year']]['value']) > 1e-7]
        if deltas:
            changed_models.append({'id': m['id'], 'name': m['name'],
                                   'years': deltas,
                                   'verified': m.get('status') not in {'needs_input', 'error'}})

    issues = [{'id': m['id'], 'name': m['name'], 'messages': m.get('issues', [])[:3]}
              for m in updated['models'] if m.get('status') in {'needs_input', 'error'}]
    from auditoria_calculos import verificar
    from auditoria_fuentes import verificar_fuentes
    audit = verificar(previous, updated, latest_observations())
    source_audit = verificar_fuentes(SOURCE)
    audit['checks'] += source_audit['checks']
    audit['errors'] += len(source_audit['errors'])
    for message in source_audit['errors']:
        audit['findings'].append({'severity': 'error', 'id': 'fuentes_excel', 'message': message})
    audit['passed'] = audit['passed'] and source_audit['passed']
    audit['sources'] = {'passed': source_audit['passed'],
                        'checks': source_audit['checks'],
                        'errors': len(source_audit['errors'])}

    # Validación de respaldo físico, seguida de publicación controlada.
    from auditoria_persistencia import verificar_respaldo
    physical = load_base(refresh=True)[0]
    physical_active, physical_warnings = _run(physical, {}, all_observations(applied=True))
    persistence = verificar_respaldo(updated['models'], physical_active)
    warnings = list(updated.get('warnings') or [])
    publication = None
    # No modificar ningún libro cuando falta recálculo o el motor informa error.
    if differences and audit['passed'] and not issues and not warnings:
        try:
            from persistencia_modelos import aplicar_transaccion
            earlier = load_base(refresh=True)[0]
            expected = {m['id']:m for m in updated['models']}
            publication = aplicar_transaccion(
                SOURCE, earlier, expected,
                lambda: load_base(refresh=True)[0],
                verificar_respaldo, verificar_fuentes, LOCK,
                observations=new_effective,
                state_updates={'fuentes_aplicadas.json': downloaded,
                               'observaciones_aplicadas.json': read_state('observaciones.json', {})})
            physical = load_base(refresh=True)[0]
            physical_active, physical_warnings = _run(physical, {}, latest_observations())
            persistence = verificar_respaldo(updated['models'],physical_active)
            audited_after=verificar_fuentes(SOURCE)
            if not audited_after['passed'] or not persistence['passed']:
                raise ValueError('Falló la auditoría posterior a publicación.')
        except Exception as exc:
            # El cambio queda pendiente; los libros sin publicar no son aplicados.
            warnings.append(f'Persistencia inconclusa: {exc}')
            physical = load_base(refresh=True)[0]
            physical_active, physical_warnings = _run(physical, {}, all_observations(applied=True))
            persistence = verificar_respaldo(updated['models'],physical_active)
    if differences and not persistence['passed']:
        warnings.append('Existen resultados calculados que aún no constan en los Excel; la actualización continúa pendiente.')
        if changed_models:
            warnings.append('Modelos por sincronizar: ' + ', '.join(m['id'] for m in changed_models[:35]) + '.')
    if differences and issues:
        warnings.append('Hay modelos pendientes de recálculo; las nuevas fuentes no se han aplicado.')
    if differences and not source_audit['passed']:
        warnings.append('Los archivos de respaldo presentan descuadres; las nuevas fuentes no se han aplicado.')
    completed = (audit['passed'] and not issues and not warnings and persistence['passed'])
    report = {
        'generatedAt': datetime.now(timezone.utc).isoformat(),
        'observations': len(differences),
        'sourceModels': sorted({d['model'] for d in differences}),
        'changedModels': changed_models if completed else [],
        'proposedChanges': changed_models if not completed else [],
        'warnings': warnings,
        'issues': issues,
        'audit': audit,
        'persistence': persistence,
        'publication': publication,
        'ok': completed,
        'status': 'completo' if completed else 'pendiente',
        'modelsCount': 49,
    }
    if completed:
        # La fotografía aplicada se publicó junto con los Excel, bajo la misma
        # reversión. El informe describe ese resultado ya verificado.
        write_state('ultimo_recalculo.json', report)
        updated['recalculation'] = report
        updated['lastRecalculation'] = report
        updated['sourceUpdates'] = pending_sources()
        # Mostrar la base macro operativa al usuario; la persistencia de fuentes
        # se hizo exclusivamente contra la base física (sin choques macro).
        visible = calculate()
        visible['recalculation'] = report
        visible['lastRecalculation'] = report
        return visible
    # Un cálculo parcial solo es una vista de diagnóstico. La API retorna
    # el escenario aplicado, nunca resultados no guardados como definitivos.
    write_state('ultimo_recalculo.json', report)
    previous['recalculation'] = report
    previous['lastRecalculation'] = report
    previous['sourceUpdates'] = pending_sources()
    previous['warnings'] = list(previous.get('warnings', [])) + warnings
    visible = calculate()
    visible['recalculation'] = report
    visible['lastRecalculation'] = report
    visible['warnings'] = list(visible.get('warnings', [])) + warnings
    return visible



def calculate(changes=None, observations=None, use_macro_base=True, horizon=2030, stress_profile=None):
    if isinstance(horizon, bool) or not isinstance(horizon, int) or not 2026 <= horizon <= 2030:
        raise ValueError('Horizonte anual fuera de 2026–2030.')
    original, macro_items = load_base()
    if observations is None:
        observations = all_observations()
    changes = changes or {}
    # La base operativa proviene de los libros originales más los supuestos
    # macro aprobados expresamente. Los escenarios son incrementales sobre ella.
    # Nunca se modifican las hojas Input/Output de los notebooks.
    base_state = macro_base_state()
    base_changes = base_state.get('changes', {}) if use_macro_base else {}
    base, base_warnings = _run(original, base_changes, observations)
    active = _combine_macros(base_changes, changes)
    for key, values in observations.items():
        if key in active:
            for period in values:
                active[key].pop(str(period), None)
    # Laboratorio: los tres perfiles SBS utilizan sus propias sendas macro,
    # y las provisiones IASC por escenario como inputs directos, sin inventar
    # una variación de recuperaciones. La Base IASPE original NO se cambia.
    from escenarios_iasc import observations_for, input_stock
    stress_labels={'sbs_base':'base','sbs_stress':'estres','sbs_severe':'estres_severo'}
    if stress_profile is not None and stress_profile not in stress_labels:
        raise ValueError('Perfil de escenario SBS no reconocido.')
    label_iasc=stress_labels.get(stress_profile)
    if label_iasc:
        horizon=min(horizon,2028)
        scenario_obs=observations_for(label_iasc,base,observations)
        scenario_changes=copy.deepcopy(active)
        scenario_changes['__iasc_provisiones_stock__']=input_stock(label_iasc)
        current,warnings=_run(original,scenario_changes,scenario_obs)
        warnings=list(warnings)+['M25 SBS utiliza directamente el gasto por provisiones reportado en el IASC para este escenario; no se estimaron recuperaciones. La serie del Base IASPE se mantiene independiente.']
    else:
        current,warnings=_run(original,active,observations) if changes else (copy.deepcopy(base),list(base_warnings))
    # Si SBS actualizó saldos de cartera, algunas ecuaciones descendientes
    # siguen leyendo los pronósticos originales. Se señalan como pendientes
    # para no presentar un cierre congelado como resultado recalculado.
    # Propagar advertencias únicamente cuando la actualización ha cambiado
    # algún valor de cierre o de proyección: no convertir una fuente validada
    # sin cambios en una alerta falsa de falta de recálculo.
    candidates = {k for k in ('05','06','19_personal') if observations.get(k)}
    if observations.get('trabajadores_falabella'):
        candidates.add('19_personal')
    changed_stocks = set()
    for k in candidates:
        old={r['year']:r['value'] for r in original[k]['annual']}
        if any(r['year'] in old and abs(r['value']-old[r['year']]) > 1e-5
               for r in base[k]['annual'] if r['year'] >= 2026):
            changed_stocks.add(k)
    if changed_stocks:
        for registry in (base, current):
            transmitted = set(changed_stocks)
            if {'05','06'} & transmitted:
                transmitted.add('07')
            for _ in range(len(registry)):
                grew = False
                for key, model in registry.items():
                    if key in transmitted:
                        continue
                    deps = {str(d.get('id', d.get('source', ''))) if isinstance(d, dict) else str(d)
                            for d in model.get('dependencies', [])}
                    if deps & transmitted:
                        transmitted.add(key)
                        grew = True
                        if model.get('canUpdate') is False and not model.get('reestimated',False):
                            model['status'] = 'needs_input'
                            msg = 'Actualización SBS parcial: el pronóstico permanece como salida original y requiere transmisión/reestimación validada.'
                            model.setdefault('issues', [])
                            if msg not in model['issues']:
                                model['issues'].append(msg)
                if not grew:
                    break
        frozen = sorted(key for key, model in current.items()
                        if key not in changed_stocks | {'07'} and model.get('status') == 'needs_input'
                        and model.get('canUpdate') is False)
        if frozen:
            avisos = [k for k in frozen if not (k == '08' and any('Modelo 08: falta el desglose' in a for a in warnings))]
            if avisos:
                warnings.append('SBS: modelos descendientes sin recálculo verificado: ' + ', '.join(avisos) + '.')
    affected = []
    for key, m in current.items():
        before = {r['year']: r['value'] for r in base[key]['annual']}
        differences = [dict(year=r['year'], base=before.get(r['year']), value=r['value'], difference=r['value'] - before[r['year']]) for r in m['annual'] if r['year'] in before and abs(r['value'] - before[r['year']]) > 1e-8]
        m['differences'] = differences
        m['reestimated'] = bool(m.get('reestimated', False))
        if differences or m['status'] not in {'ok', 'ready', 'success'}:
            affected.append(key)
    macros = macro_registry(macro_items)
    for item in macros:
        item['values'].update(base_changes.get(item['id'], {}))
        item['observedPeriods'] = list(observations.get(item['id'], {}))
        item['values'].update(observations.get(item['id'], {}))
    base_macro = {'appliedAt': base_state.get('appliedAt'),
                  'active': bool(base_changes), 'complete': base_state.get('complete', True),
                  'cells': sum(len(v) for v in base_changes.values()),
                  'report': base_state.get('report', {}),
                  'warnings': base_warnings}
    # Incorporar dos fichas de apertura como resultados DERIVADOS del M16.
    # No afectan ninguna ecuación, macro, input ni identidad de los 111 modelos.
    from ingresos_apertura import incorporar as incorporar_apertura_ingresos
    for registry in (base, current):
        incorporar_apertura_ingresos(registry)
    # El laboratorio entrega únicamente cierres/estimaciones hasta el último año
    # solicitado. Se preservan observaciones históricas; no se escriben Excel.
    # Los módulos preexistentes aún calculan internamente la senda completa:
    # el horizonte controla las salidas visibles de la simulación, no reestima MCO.
    if horizon < 2030:
        for registry in (base, current):
            for model in registry.values():
                model['annual'] = [r for r in model.get('annual', []) if int(r.get('year', 0)) <= horizon]
                model['monthly'] = [r for r in model.get('monthly', []) if int(str(r.get('date',''))[:4] or 0) <= horizon]
                model['differences'] = [r for r in model.get('differences', []) if int(r.get('year', 0)) <= horizon]
        for item in macros:
            item['values'] = {period:value for period,value in item.get('values',{}).items()
                              if not str(period)[:4].isdigit() or int(str(period)[:4]) <= horizon}
    return clean({'horizon': horizon, 'models': list(current.values()), 'baseline': list(base.values()), 'macros': macros, 'graph': graph(current, macros), 'affected': affected, 'warnings': warnings, 'changes': changes, 'observations': observations, 'baseMacro': base_macro, 'sourceUpdates': pending_sources(), 'lastRecalculation': read_state('ultimo_recalculo.json', None), 'meta': {'source': str(SOURCE), 'generatedAt': datetime.now(timezone.utc).isoformat(), 'modelCount': len([k for k in base if '_' not in k]), 'edition': 'Modelos financieros', 'frequencyPolicy': 'Base: provisiones acumuladas BF BLSBS y EEFF completos hasta 2030; SBS estrés y severo hasta 2028.', 'escenarioIASC': label_iasc, 'notaEscenario': ('M25 SBS: gasto por provisiones tomado del IASC del escenario seleccionado, sin ajustes estimados; Base IASPE inalterado' if label_iasc else None)}})


def fingerprint():
    return {str(p.relative_to(SOURCE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
