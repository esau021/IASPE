#!/usr/bin/env python3
"""Controles de no duplicidad, fuentes, identidad contable y acumulado vs mensual."""
from pathlib import Path
import gzip,json,math
from datetime import datetime
ROOT=Path(__file__).resolve().parents[1]
d=json.load(gzip.open(ROOT/'output/panel_eeff_16_bancos.json.gz','rt',encoding='utf-8'))
m=d['meta'];s=d['series'];checks=[]
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[4]/'Dashboard'/'Sistema'))
from instituciones_sbs import BANKS
ids=[b['id'] for b in m['banks']]
assert len(ids)==len(set(ids)) and set(ids)==set(BANKS), 'Catálogo institucional incompleto o duplicado'
# El índice del Dashboard debe señalar exactamente el XLSX que originó cada cifra.
import hashlib
PROJECT=Path(__file__).resolve().parents[3]
for bank in m['banks']:
    filename=PROJECT/bank['source']
    if not filename.is_file():
        raise FileNotFoundError(f'Fuente histórica no encontrada: {filename}')
    if hashlib.sha256(filename.read_bytes()).hexdigest()!=bank['sha256']:
        raise ValueError(f'La fuente histórica cambió sin reconstruir el panel: {filename}')
months=m['months']
assert months and len(months)==len(set(months))
assert months==sorted(months) and m['first']==months[0] and m['last']==months[-1]
start=datetime.strptime(months[0],'%Y-%m')
end=datetime.strptime(months[-1],'%Y-%m')
assert months[0]=='2016-01' and end>=start
expected=[f'{y}-{mo:02d}' for y in range(start.year,end.year+1)
          for mo in range(1,13) if (y,mo)>=(start.year,start.month) and (y,mo)<=(end.year,end.month)]
assert months==expected, 'Periodos faltantes, duplicados o desordenados en el panel SBS'
assert len(m['accounts'])>=200

def get(section, label):
    match=[x['id'] for x in m['accounts'] if x['section']==section and x['name'].strip().upper()==label]
    assert len(match)==1,(section,label,match)
    return s[match[0]]
assets=get('balance','TOTAL ACTIVO');pe=get('balance','TOTAL PASIVO Y PATRIMONIO')
for b in m['banks']:
    for month,v in assets[b['id']].items():
        other=pe[b['id']].get(month)
        if other is None:continue
        diff=abs(v-other)
        checks.append(diff)
        if not math.isclose(v,other,rel_tol=1e-8,abs_tol=0.005):
            raise ValueError(f'Activo vs pasivo+patrimonio: {b["name"]} {month}: {v} vs {other}')
print('Cuadre de Balance:',len(checks),'celdas, máxima diferencia S/ millones:',max(checks))
acc=get('er_acumulado','RESULTADO NETO DEL EJERCICIO')
monthly=get('er_mensual','RESULTADO NETO DEL EJERCICIO')
valid=0
for b in m['banks']:
    for year in range(start.year,end.year+1):
        months=[f'{year}-{m:02d}' for m in range(1,13)]
        for lastmonth in months:
            i=int(lastmonth[-2:])
            vals=[monthly[b['id']].get(x) for x in months[:i]]
            total=acc[b['id']].get(lastmonth)
            if total is None or not all(x is not None for x in vals):continue
            if not math.isclose(sum(vals),total,rel_tol=1e-8,abs_tol=1e-5):
                raise ValueError(f'ER mensual vs acumulado {b["name"]} {lastmonth}: {sum(vals)} vs {total}')
            valid+=1
print('Conciliación ER mensual/acumulado:',valid,'celdas')
print('Conservación: no se alteraron originales; panel validado',len(m['accounts']),'cuentas,',len(m['banks']),'bancos.')
