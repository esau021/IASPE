"""Previsualización y confirmación: pruebas sobre archivos reales y estado aislado."""
import base64
import os
import hashlib
import json
from pathlib import Path
import pytest
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import proyecciones_externas as p

NOTE = Path(os.environ.get('BCRP_PDF_DIR', str(Path(__file__).resolve().parent / 'pdfs'))) / 'nota-de-estudios-77-2026.pdf'

@pytest.fixture
def storage(tmp_path, monkeypatch):
    for k, v in {'DIR': tmp_path, 'STATE': tmp_path / 'historial.json',
                 'DOCS': tmp_path / 'documentos', 'HTTP_CACHE': tmp_path / 'http_cache.json',
                 'BASE_REVISIONS': tmp_path / 'base_revisions.json'}.items():
        monkeypatch.setattr(p, k, v)
    p.PREVIEWS.clear()
    yield tmp_path
    p.PREVIEWS.clear()

def note():
    if not NOTE.exists(): pytest.skip('No se proporcionó la Nota 77 original para esta prueba')
    return base64.b64encode(NOTE.read_bytes()).decode()

def test_preview_real_note_has_three_variables_and_does_not_write(storage):
    response=p.preview_document('BCRP · encuesta anual', NOTE.name, note())
    assert response['history_count']==81
    assert len(response['records'])==27
    assert set(row['variable'] for row in response['records'])=={'pbi','inflacion','tc_cierre'}
    values={(r['variable'],r['group'],r['year']):r['after'] for r in response['records']}
    assert values[('pbi','Analistas económicos','2026')]==3.1
    assert values[('inflacion','Empresas no financieras','2026')]==3.52
    assert values[('tc_cierre','Empresas no financieras','2028')]==3.47
    assert not p.STATE.exists() and not p.DOCS.exists()

def test_commit_requires_token_and_is_single_use(storage):
    preview=p.preview_document('BCRP · encuesta anual', NOTE.name, note())
    with pytest.raises(ValueError):p.confirm_document('fake')
    assert not p.STATE.exists()
    out=p.confirm_document(preview['token'])
    assert out['added']==27
    assert p.STATE.exists()
    assert len(list(p.DOCS.glob('*.pdf')))==1
    assert len(p.snapshot()['current_records'])==27
    with pytest.raises(ValueError):p.confirm_document(preview['token'])

def test_preview_detects_concurrent_changes_and_refuses(storage):
    token=p.preview_document('BCRP · encuesta anual',NOTE.name,note())['token']
    other=p._load()
    other['editions'].append({'source':'MEF · MMM/IAPM','id':'concurrent', 'edition':'MMM 2027–2030'})
    p._save(other)
    with pytest.raises(ValueError,match='cambiaron'):p.confirm_document(token)
    assert not p.DOCS.exists()

def test_bad_file_fails_without_writing(storage):
    with pytest.raises(Exception):
        p.preview_document('BCRP · encuesta anual','fake.pdf',base64.b64encode(b'%PDF-error').decode())
    assert not p.STATE.exists() and not p.DOCS.exists()

def test_preview_counters_against_real_baseline(storage):
    source=Path(__file__).resolve().parents[1]/'data'/'proyecciones_externas'/'historial.json'
    p.STATE.write_bytes(source.read_bytes())
    before=hashlib.sha256(p.STATE.read_bytes()).hexdigest()
    response=p.preview_document('BCRP · encuesta anual',NOTE.name,note())
    assert hashlib.sha256(p.STATE.read_bytes()).hexdigest()==before
    assert len(response['records'])==27
    assert any(row['before'] is not None for row in response['records'])
    assert any(row['status'] == 'cambio' for row in response['records'])

def test_slow_mef_network_does_not_block_local_confirmation(storage, monkeypatch):
    """Una descarga externa lenta no debe dejar «Guardando» bloqueado."""
    import threading
    import time

    token=p.preview_document('BCRP · encuesta anual', NOTE.name, note())['token']
    started=threading.Event()
    release=threading.Event()
    failures=[]

    def slow_mef():
        started.set()
        if not release.wait(8):
            raise TimeoutError('La prueba no liberó el conector MEF')
        return [], []

    def run_update():
        try:
            p.update()
        except Exception as exc:
            failures.append(exc)

    monkeypatch.setattr(p, '_update_mef', slow_mef)
    thread=threading.Thread(target=run_update, daemon=True)
    thread.start()
    try:
        assert started.wait(3), 'El conector MEF no empezó'
        start=time.monotonic()
        response=p.confirm_document(token)
        elapsed=time.monotonic()-start
        assert response['added']==27
        assert elapsed<1.5, f'El guardado se bloqueó durante una consulta externa: {elapsed:.2f}s'
    finally:
        release.set()
        thread.join(timeout=5)
    assert not thread.is_alive()
    assert not failures
    assert len(p.snapshot()['current_records'])==27
