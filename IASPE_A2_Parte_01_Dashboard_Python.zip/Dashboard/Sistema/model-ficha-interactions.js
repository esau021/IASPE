/* Interpretaciones cuantitativas y navegación de insumos entre modelos IASPE. */
(() => {
  'use strict';
  const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const fmt=(v,n=4)=>new Intl.NumberFormat('es-PE',{maximumFractionDigits:n,minimumFractionDigits:n}).format(Number(v));
  const profiles={
    '01':['growth','número total de tarjetas de crédito del mercado'],
    '02':['growth','número de tarjetas de crédito de consumo del mercado'],
    '03':['growth','compras con tarjetas de crédito del mercado'],
    '04':['growth','número de tarjetas de crédito de Falabella'],
    '05':['growth','colocaciones revolventes de Falabella'],
    '06':['change','saldo de colocaciones no revolventes de Falabella'],
    '08_mn':['percent','depósitos de ahorro en moneda nacional'],
    '08_me':['growth','depósitos de ahorro en moneda extranjera'],
    '09_plazo':['percent','depósitos a plazo ordinarios'],
    '09_cts':['percent','depósitos por compensación por tiempo de servicios'],
    '11':['rate','costo implícito de las obligaciones con el público'],
    '12_entidades':['lnOffset005','gasto por depósitos de entidades financieras'],
    '12_adeudos':['amount','gasto por intereses de adeudos'],
    '12_otras':['lnOffset1','gasto por otras fuentes de financiamiento'],
    '13':['rate','tasa activa de tarjetas del mercado'],
    '14':['rate','tasa activa de préstamos de consumo del mercado'],
    '15':['rate','tasa pasiva del mercado'],
    '16_creditos':['rate','rendimiento implícito de la cartera de créditos'],
    '16_disponible':['lnLevel','ingresos por disponibilidades'],
    '16_interbancarios':['lnLevel','ingresos por fondos interbancarios'],
    '17_caja':['amount','saldo de caja'],
    '18_diversos':['mixedGrowth','ingresos diversos por servicios financieros'],
    '19_terceros':['mixedGrowth','gastos por servicios de terceros'],
    '31':['growth','cuentas por cobrar netas'],
    '32':['change','saldo de rendimientos por cobrar'],
    '48':['growth','cartera total de consumo de la banca múltiple']
  };
  const explicit={
    '05':{1:['03']},
    '06':{3:['03']},
    '07':{0:['05'],1:['06']},
    '08':{0:['08_mn'],1:['08_me']},
    '09':{0:['09_plazo'],1:['09_cts']},
    '10':{0:['08'],1:['09'],2:['10_restringidos'],3:['10_otras']},
    '12':{0:['12_obligaciones'],1:['12_entidades'],2:['12_adeudos'],3:['12_otras']},
    '12_obligaciones':{0:['10'],1:['11']},
    '16':{0:['16_creditos'],1:['16_inversiones'],2:['16_disponible'],3:['16_interbancarios']},
    '16_creditos':{1:['13']},
    '17':{0:['17_caja'],1:['17_bancos'],2:['17_canje'],3:['17_otros']},
    '18':{0:['18_diversos'],1:['18_otros_ing'],2:['18_gastos_div'],3:['18_otros_gastos']},
    '18_diversos':{5:['03']},
    '18_gastos_div':{0:['18_diversos']},
    '19':{0:['19_personal'],1:['19_terceros'],2:['19_directorio'],3:['19_impuestos']},
    '20':{0:['20_consorcios','20_asociadas'],1:['20_tc','20_derivados'],2:['20_inversiones','20_otros']},
    '21':{0:['21_venta'],1:['21_asociadas'],2:['21_otras']},
    '22':{0:['22_interbancarios']},
    '23':{0:['16'],1:['12']},
    '29':{0:['23']},
    '32':{1:['16_creditos']},
    '45':{0:['45_utilidad_aplicada'],1:['45_transferencias_reservas'],2:['45_dividendos']},
    '46':{0:['29']},
    '47':{0:['17'],1:['07']},
    '48_cuota':{0:['07'],1:['48']},
    '49':{0:['49_rev'],1:['49_nrev']},
    '49_rev':{0:['05'],1:['49_compras'],2:['49_disposiciones_rc']},
    '49_nrev':{0:['06'],1:['49_desembolsos']},
    '49_tc':{0:['49_rev'],1:['49_part_rc']},
    '49_rc':{0:['49_rev'],1:['49_part_rc']},
    '49_pe':{0:['49_nrev']}
  };
  // Term hints may connect components whose model.inputs metadata does not expose the source.
  const sourcesByTerm=[
    [/compras (?:con tarjetas|del mercado|mercado|anuales|logaritmicas|logaritmico)/, '03'],
    [/cartera (?:de )?consumo (?:de )?la banca multiple/,'48'],
    [/numero de tarjetas (?:de )?falabella/,'04'],
    [/saldo (?:bruto )?de tarjetas|colocaciones (?:brutas )?revolventes/,'05'],
    [/prestamos (?:de consumo )?no revolventes|colocaciones no revolventes/,'06'],
    [/ingresos por creditos/,'16_creditos'],
    [/tasas? activa de tarjetas del mercado/,'13'],
    [/ingresos diversos/,'18_diversos'],
    [/depositos de ahorro/,'08'],
    [/depositos a plazo/,'09'],
    [/costo implicito de obligaciones/,'11']
  ];
  const isModel=(app,id)=>!!(id&&app?.model?.(String(id)));
  function links(app,model,index,term){
    const id=String(model?.id||'');
    const fromExplicit=explicit[id]?.[index]||[];
    const items=[...fromExplicit];
    // For non-regression models, inputs can be aligned one-to-one with explanation rows.
    const inputs=Array.isArray(model?.inputs)?model.inputs:[];
    const co=Array.isArray(model?.coefficients)?model.coefficients:[];
    const expected=window.IASPEExplanations?.terms?.(model)?.length;
    if(co.length===0 && inputs.length===expected){
      const reference=String(inputs[index]?.id||'');
      if(reference) items.push(reference);
    }
    const label=norm(term?.label);
    if(!items.length){
      for(const [pattern,target] of sourcesByTerm){if(pattern.test(label)){items.push(target);break;}}
    }
    return [...new Set(items)].filter(target=>target!==id&&isModel(app,target));
  }
  function inputChange(name,id,index){
    const v=norm(name);
    if(/constante|intercepto/.test(v)||index===0&&/constante/.test(v))return {kind:'constant',label:''};
    if(/2020|2021|2024|2025|2018|reclasific|pandemia|covid|indicador|dicotom|\bd\s*20/.test(v))return {kind:'dummy',label:name};
    if(id==='06'&&/compras/.test(v))return {kind:'continuous',step:100,label:'cien millones de soles en las compras del mercado del año anterior'};
    if(id==='08_me'&&/tc|cambio/.test(v))return {kind:'continuous',step:0.1,label:'diez céntimos en la variación del tipo de cambio del año anterior'};
    if(/ln\(|logaritmo|log\(|logaritmico de ingresos|ingresos\) t/.test(v)&&id==='16_disponible')return {kind:'logInput',label:'ingresos por disponibilidades del año anterior'};
    if(/caja t-1/.test(v))return {kind:'continuous',step:1,label:'un millón de soles en el saldo de caja del mes anterior'};
    if(/ingresos por intereses|variacion de ingresos|Δ ingresos/.test(v))return {kind:'continuous',step:1,label:'un millón de soles en la variación anual de ingresos por créditos'};
    if(/aceleracion|aceleración/.test(v))return {kind:'continuous',step:1,label:'un punto porcentual en la aceleración del crecimiento del producto bruto interno del año anterior'};
    if(/tpm|politica monetaria|política monetaria/.test(v))return {kind:'continuous',step:1,label:/variaci|Δ/.test(v)?'un punto porcentual en la variación de la tasa de política monetaria':'un punto porcentual en la tasa de política monetaria'};
    if(/desempleo/.test(v))return {kind:'continuous',step:1,label:/cambio|variac|diferencia/.test(v)?'un punto porcentual en la variación de la tasa de desempleo':'un punto porcentual en la tasa de desempleo'};
    if(/inflac/.test(v))return {kind:'continuous',step:1,label:'un punto porcentual en la inflación anual'};
    if(/pbi|producto bruto/.test(v))return {kind:'continuous',step:1,label:/anterior|rezagad|t.?1/.test(v)?'un punto porcentual en el crecimiento real del producto bruto interno del año anterior':'un punto porcentual en el crecimiento real del producto bruto interno del año'};
    if(/crecimiento.*compras/.test(v))return {kind:'continuous',step:1,label:'un punto porcentual en el crecimiento logarítmico de las compras con tarjetas del año anterior'};
    if(/participacion.*plazo/.test(v))return {kind:'continuous',step:1,label:'un punto porcentual en la participación de depósitos a plazo'};
    if(/costo rezagado/.test(v))return {kind:'continuous',step:1,label:'un punto porcentual en el costo de obligaciones del año anterior'};
    if(/tasa de mercado rezagada/.test(v))return {kind:'continuous',step:1,label:'un punto porcentual en la tasa de mercado del año anterior'};
    if(/tasa activa de tarjetas/.test(v))return {kind:'continuous',step:1,label:'un punto porcentual en la tasa activa de tarjetas del mercado'};
    if(/saldo|gasto rezagado/.test(v)&&/t-1|rezagad/.test(v))return {kind:'continuous',step:1,label:'un millón de soles en el saldo del período anterior'};
    if(/compras/.test(v))return {kind:'continuous',step:1,label:'una unidad de la medida de compras incluida en el modelo'};
    return {kind:'continuous',step:1,label:'una unidad de '+String(name).trim().toLowerCase()};
  }
  const outcomeUnit={growth:'puntos porcentuales del crecimiento logarítmico anual',percent:'puntos porcentuales de la tasa de crecimiento anual',rate:'puntos porcentuales',change:'millones de soles en la variación anual del saldo',amount:'millones de soles'};
  function interpretation(model,coef,index){
    const id=String(model?.id||'');
    const profile=profiles[id];
    const name=String(coef?.name||coef?.variable||'este término');
    const value=Number(coef?.value??coef?.estimate);
    if(!profile||!Number.isFinite(value))return null;
    const [kind,outcome]=profile,setting=inputChange(name,id,index);
    const verb=v=>v<0?'disminuye':'aumenta';
    if(setting.kind==='constant'){
      if(['lnLevel','lnOffset005','lnOffset1'].includes(kind))return `Si las demás variables explicativas toman valor cero, la constante fija en ${fmt(value)} el valor estimado del logaritmo utilizado para proyectar ${outcome}. El importe final se calcula aplicando la transformación inversa de la ecuación.`;
      if(kind==='mixedGrowth')return `Si las demás regresoras toman valor cero, la constante de esta regresión auxiliar aporta ${fmt(value)} puntos al crecimiento logarítmico previsto. El resultado definitivo combina varias trayectorias y no se obtiene únicamente de esta constante.`;
      const unit=outcomeUnit[kind]||'unidades de la variable explicada';
      return `Si las demás variables explicativas toman valor cero, la constante aporta ${fmt(value)} ${unit} a la predicción de ${outcome}. Este valor es el punto de partida algebraico de la ecuación y no necesariamente una situación económica habitual.`;
    }
    const isDummy=setting.kind==='dummy';
    const basis=isDummy?`Cuando el indicador «${name}» pasa de cero a uno`:`Ante un aumento de ${setting.label}`;
    const hold='manteniendo constantes las demás variables del modelo';
    const delta=value*(setting.step||1);
    if(['lnLevel','lnOffset1','lnOffset005'].includes(kind)){
      if(setting.kind==='logInput'){
        const pct=100*(Math.pow(1.01,value)-1);
        return `Ante un aumento de uno por ciento en ${setting.label}, el importe proyectado de ${outcome} ${verb(pct)} aproximadamente ${fmt(Math.abs(pct),2)} por ciento, ${hold}. Como ambas magnitudes entran en logaritmos, el coeficiente permite interpretar su relación porcentual.`;
      }
      const pct=100*(Math.exp(delta)-1);
      const target=kind==='lnLevel'?`el importe proyectado de ${outcome}`:kind==='lnOffset1'?`el valor proyectado de ${outcome} más una unidad`:`el valor proyectado de ${outcome} más 0,05 millones de soles`;
      return `${basis}, ${target} ${verb(pct)} aproximadamente ${fmt(Math.abs(pct),2)} por ciento, ${hold}. El porcentaje se obtiene aplicando la transformación inversa del logaritmo.${isDummy?' El indicador solo toma el valor uno en los ejercicios definidos por la especificación.':''}`;
    }
    const target=kind==='growth'?`el crecimiento logarítmico anual de ${outcome}`:kind==='percent'?`la tasa de crecimiento anual de ${outcome}`:kind==='rate'?`la tasa estimada de ${outcome}`:kind==='change'?`la variación anual del ${outcome}`:kind==='mixedGrowth'?`la trayectoria auxiliar de crecimiento anual de ${outcome}`:`el valor proyectado de ${outcome}`;
    const unit=kind==='change'||kind==='amount'?'millones de soles':'puntos porcentuales';
    let message=`${basis}, ${target} ${verb(delta)} en ${fmt(Math.abs(delta))} ${unit}, ${hold}.`;
    if(kind==='growth')message+=' La interpretación se refiere a la tasa de crecimiento logarítmico y no a una variación directa del saldo en millones de soles.';
    if(kind==='mixedGrowth')message+=' La proyección definitiva combina esta trayectoria con otra de acuerdo con las ponderaciones establecidas en el modelo.';
    if(isDummy)message+=' El ajuste se aplica únicamente a los períodos en que el indicador vale uno.';
    return message;
  }
  window.IASPEFichaInteractions={links,interpretation,profiles};
})();
