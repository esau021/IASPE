/* IASPE · Laboratorio de escenarios. Proyección anual y comparativos de P&L.
   Simulaciones en memoria: no cambian los libros SBS ni los Excel de Riesgos. */
(() => {
  'use strict';
  const YEARS = [2026, 2027, 2028, 2029, 2030];
  const KEYS = ['pbi','inflacion','tc_cierre','tc_promedio','desempleo','tpm'];
  const horizon = app => Math.max(2026,Math.min(2030,Number(app.state.laboratorioHorizon || 2030)));
  const years = app => YEARS.filter(y=>y<=horizon(app));
  const scopeChanges = app => Object.fromEntries(Object.entries(app.state.changes||{}).map(([key,values])=>[key,Object.fromEntries(Object.entries(values||{}).filter(([yr,value])=>Number(yr)<=horizon(app)&&Number.isFinite(Number(value))))]).filter(([,values])=>Object.keys(values).length));
  const ACCOUNTS = [
    ['16','Ingresos por intereses','Ingresos'],
    ['12','Gastos por intereses','Gastos'],
    ['23','Margen financiero bruto','Margen'],
    ['25','Provisiones para créditos','Riesgos'],
    ['netMargin','Margen financiero neto','Margen'],
    ['18','Servicios financieros netos','Ingresos'],
    ['19','Gastos de administración','Gastos'],
    ['beforeTax','Resultado antes de impuestos','Resultado'],
    ['28','Impuesto a la renta','Impuestos'],
    ['29','Resultado neto del ejercicio','Resultado']
  ];
  const $ = (selector) => document.querySelector(selector);
  const money = v => Number.isFinite(v) ? new Intl.NumberFormat('es-PE',{minimumFractionDigits:2,maximumFractionDigits:2}).format(v) : '—';
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let timer;
  let saving=false;
  const get = (models, id, year) => {
    const model = (models || []).find(m => m.id === id);
    const row = model?.annual?.find(r => Number(r.year) === year);
    return row && row.value !== null && row.value !== undefined && Number.isFinite(Number(row.value)) ? Number(row.value) : null;
  };
  function financial(models, key, year) {
    if (key === 'netMargin') {
      const gross=get(models,'23',year), provisions=get(models,'25',year);
      return gross===null||provisions===null?null:gross-provisions;
    }
    if (key === 'beforeTax') {
      const net=get(models,'29',year), taxes=get(models,'28',year);
      return net===null||taxes===null?null:net+taxes;
    }
    return get(models,key,year);
  }
  function changeSummary(models, baseline, year, key) {
    const sim=financial(models,key,year), base=financial(baseline,key,year);
    return {base,sim,delta:base===null||sim===null?null:sim-base,pct:base!==null&&sim!==null&&Math.abs(base)>1e-9?100*(sim-base)/Math.abs(base):null};
  }
  function selectedYear(app) {
    const year=Number(app.state.laboratorioYear||horizon(app));
    return years(app).includes(year)?year:horizon(app);
  }
  function summaryCard(app, key, label, tag) {
    const yr=selectedYear(app);
    const result=changeSummary(app.state.data?.models,app.state.data?.baseline,yr,key);
    return `<article class="sim-kpi"><div class="sim-kpi-top"><span>${esc(label)}</span><span class="sim-kpi-tag">${esc(tag)}</span></div><strong>${money(result.sim)}</strong><span class="sim-kpi-foot">S/ millones · Base ${money(result.base)}</span><span class="sim-kpi-delta ${result.delta===null?'':result.delta>1e-7?'positive':result.delta< -1e-7?'negative':'flat'}">${result.delta===null?'Sin información':Math.abs(result.delta)<1e-7?'Sin variación':`${result.delta>0?'+':''}${money(result.delta)} (${result.pct===null?'—':`${result.pct>0?'+':''}${money(result.pct)}%`})`}</span></article>`;
  }
  function paths(app,key) {
    const yrs=years(app);
    const a=yrs.map(y=>changeSummary(app.state.data?.models,app.state.data?.baseline,y,key));
    const both=a.flatMap(x=>[x.base,x.sim]).filter(v=>v!==null && Number.isFinite(v));
    if(!both.length)return '<p class="sim-quiet">No existen valores comparables para esta cuenta.</p>';
    let min=Math.min(...both),max=Math.max(...both),span=max-min;
    if(span<1e-8){span=Math.max(1,Math.abs(max)*.15);min-=span/2;max+=span/2;}
    min-=span*.2;max+=span*.17;
    const L=73,R=25,T=25,B=42,W=920,H=283;
    const x=i=>L+i*(W-L-R)/Math.max(1,yrs.length-1);
    const y=v=>T+(max-v)*(H-T-B)/(max-min);
    const path=which=>a.map((r,i)=>r[which]===null?'':`${i===0?'M':'L'}${x(i).toFixed(1)},${y(r[which]).toFixed(1)}`).join(' ');
    const grid=Array.from({length:5},(_,i)=>{const value=min+i*(max-min)/4;const yy=y(value);return `<line x1="${L}" x2="${W-R}" y1="${yy}" y2="${yy}" class="sim-gridline"/><text x="${L-12}" y="${yy+4}" text-anchor="end" class="sim-axis-label">${money(value)}</text>`}).join('');
    const baseDots=a.map((r,i)=>r.base===null?'':`<circle cx="${x(i)}" cy="${y(r.base)}" r="4" class="sim-dot-base"><title>${yrs[i]} · Base: ${money(r.base)} S/ MM</title></circle>`).join('');
    const simDots=a.map((r,i)=>r.sim===null?'':`<circle cx="${x(i)}" cy="${y(r.sim)}" r="5" class="sim-dot-current"><title>${yrs[i]} · Simulado: ${money(r.sim)} S/ MM</title></circle>`).join('');
    return `<div class="sim-legend"><span><i class="sim-legend-base"></i>Base</span><span><i class="sim-legend-current"></i>Simulado</span></div><div class="sim-svg-container"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución comparativa anual de ${esc(key)}">${grid}${yrs.map((yr,i)=>`<text x="${x(i)}" y="${H-13}" text-anchor="middle" class="sim-axis-label">${yr}</text>`).join('')}<path d="${path('base')}" class="sim-series-base"/><path d="${path('sim')}" class="sim-series-current"/>${baseDots}${simDots}</svg></div>`;
  }
  function impactChart(app) {
    const yr=selectedYear(app),models=app.state.data?.models,base=app.state.data?.baseline;
    const metrics=ACCOUNTS.filter(([key])=>!['netMargin','beforeTax'].includes(key));
    const deltas=metrics.map(([key,label])=>({key,label,d:changeSummary(models,base,yr,key).delta}));
    const scale=Math.max(1,...deltas.map(r=>Math.abs(r.d||0)));
    return `<div class="sim-impact-chart">${deltas.map(row=>`<div class="sim-impact-row"><span title="${esc(row.label)}">${esc(row.label)}</span><div class="sim-impact-track"><span class="sim-impact-zero"></span>${row.d!==null?`<span class="sim-impact-bar ${row.d<0?'negative':'positive'}" style="${row.d<0?'right:50%;':'left:50%;'}width:${Math.max(Math.abs(row.d)>0?1.5:0,Math.abs(row.d)/scale*47).toFixed(2)}%"></span>`:''}</div><b>${row.d===null?'—':`${row.d>0?'+':''}${money(row.d)}`}</b></div>`).join('')}</div>`;
  }
  function invalidInputs() {return Array.from(document.querySelectorAll('.sim-macro-input')).some(el=>el.value.trim()===''||!Number.isFinite(readNumber(el.value)));}
  function readNumber(s) {
    const t=String(s??'').trim().replace(/[\s%]/g,'');
    if(!t)return NaN;
    return Number(t.includes(',')&&t.includes('.')?(t.lastIndexOf(',')>t.lastIndexOf('.')?t.replace(/\./g,'').replace(',','.'):t.replace(/,/g,'')):t.replace(',','.'));
  }
  function changedCount(app) {return Object.values(scopeChanges(app)).reduce((sum,values)=>sum+Object.keys(values||{}).length,0);}
  function macroPanel(app) {
    const vars=(app.state.data?.macros||[]).filter(m=>KEYS.includes(m.id));
    const yrs=years(app);
    const selector=`<label class="sim-year-select sim-horizon-label">Último año de proyección <select id="sim-horizon" aria-label="Último año de proyección">${YEARS.map(y=>`<option value="${y}" ${horizon(app)===y?'selected':''}>${y}</option>`).join('')}</select></label>`;
    return `<section class="sim-panel sim-macro"><div class="sim-section-heading"><div><span class="sim-eyebrow">01 / INSUMOS</span><h2>Supuestos macroeconómicos</h2><p>Selecciona hasta qué año tienes proyecciones. No es necesario completar los años posteriores.</p></div><div class="sim-horizon-tools">${selector}<span class="sim-data-label">2026–${horizon(app)} · Anual</span></div></div><div class="sim-table-scroll"><table class="sim-input-table"><thead><tr><th>Variable</th>${yrs.map(y=>`<th>${y}</th>`).join('')}</tr></thead><tbody>${vars.map(m=>`<tr><th><strong>${esc(m.name)}</strong><span>${esc(m.unit||'')}</span></th>${yrs.map(y=>{const key=String(y),value=app.state.changes?.[m.id]?.[key]??m.values?.[key];return `<td><input class="sim-macro-input ${app.state.changes?.[m.id]?.[key]!==undefined?'edited':''}" data-sim-macro="${esc(m.id)}" data-sim-year="${key}" aria-label="${esc(m.name)} ${key}" type="text" inputmode="decimal" value="${value===null||value===undefined?'':esc(value)}" placeholder="—"></td>`;}).join('')}</tr>`).join('')}</tbody></table></div><div class="sim-actions"><div class="sim-actions-note"><strong>${changedCount(app)} cambios · Hasta ${horizon(app)}</strong><span>Solo se mostrarán resultados hasta ${horizon(app)}. Las fuentes SBS y los datos de Riesgos permanecen intactos.</span></div><div class="sim-buttons"><button type="button" class="button ghost" id="sim-reset">Restaurar simulación</button><button type="button" class="button primary" id="sim-run" ${app.state.busy?'disabled':''}>${app.state.busy?'Calculando…':'Simular escenario'}</button></div></div></section>`;
  }
  function missingIssues(app) {
    const models=app.state.data?.models||[];
    const keys=['16','12','23','25','18','19','28','29'];
    const issues=models.filter(m=>keys.includes(m.id)&&['needs_input','error'].includes(m.status));
    const warnings=(app.state.data?.warnings||[]);
    const fixed=keys.filter(k=>models.find(m=>m.id===k)?.scenarioSupport===false);
    const tcAverage=Object.keys(app.state.changes?.tc_promedio||{}).length > 0;
    return `<div class="sim-explain"><strong>Alcance de esta simulación</strong><span>Las cuentas con fórmulas o dependencias actualizables responden a los supuestos. Las partidas de Riesgos y otras proyecciones recibidas se conservan sin cambios. Un valor sin variación no implica necesariamente ausencia de riesgo.</span>${issues.length?`<p class="sim-warning">Revisión pendiente: ${issues.map(m=>esc(m.name)).join(', ')}.</p>`:''}${warnings.length?`<p class="sim-warning">${esc(warnings.slice(0,2).join(' '))}</p>`:''}${fixed.length?`<p class="sim-note">Proyecciones sin sensibilidad propia: ${fixed.join(', ')}.</p>`:''}${tcAverage?'<p class="sim-warning">El tipo de cambio promedio es una variable de referencia: actualmente no alimenta una regresión del motor. Su cambio por sí solo no modifica el P&L.</p>':''}</div>`;
  }
  function pnlTable(app) {
    const yr=selectedYear(app),models=app.state.data?.models,base=app.state.data?.baseline;
    return `<div class="sim-table-scroll"><table class="sim-pnl-table"><thead><tr><th>Principales cuentas del P&L</th><th>Base</th><th>Simulado</th><th>Variación</th><th>Var. %</th></tr></thead><tbody>${ACCOUNTS.map(([key,label,group])=>{
      const r=changeSummary(models,base,yr,key),major=['23','netMargin','beforeTax','29'].includes(key);
      return `<tr class="${major?'major':''} ${key==='29'?'final':''}"><th>${esc(label)}<small>${esc(group)}</small></th><td>${money(r.base)}</td><td>${money(r.sim)}</td><td class="${r.delta>1e-7?'var-up':r.delta< -1e-7?'var-down':''}">${r.delta===null?'—':`${r.delta>0?'+':''}${money(r.delta)}`}</td><td class="${r.pct>1e-7?'var-up':r.pct< -1e-7?'var-down':''}">${r.pct===null?'—':`${r.pct>0?'+':''}${money(r.pct)}%`}</td></tr>`;
    }).join('')}</tbody></table></div>`;
  }
  /* Comparativa multiescenario, completamente calculada por el motor IASPE.
     Las sensibilidades contables se identifican por separado y nunca se publican. */
  const CMP_YEARS=[2026,2027,2028];
  const CMP_VARIABLES=[['pbi','PBI real','%'],['inflacion','Inflación','%'],['desempleo','Desempleo','%'],['tpm','Tasa de política monetaria','%'],['tc_cierre','Tipo de cambio de cierre','S/ por USD']];
  const CMP_NAMES=['Base del Excel','Estrés del Excel','Severo del Excel'];
  const CMP_KEYS=['base','stress','severe'];
  const CMP_LINES=[['16','Ingresos por intereses'],['12','Gastos por intereses'],['23','Margen financiero bruto'],['25','Provisiones para créditos'],['netMargin','Margen financiero neto'],['18','Servicios financieros netos'],['19','Gastos de administración'],['beforeTax','Resultado antes de impuestos'],['28','Impuesto a la renta'],['29','Utilidad neta']];
  const CMP_MODE_LABELS={A:'A · Desempleo del Excel',B:'B · Shocks de desempleo',C:'C · Rigidez de gastos'};
  const COMP={mode:'A',matrix:null,results:null,loading:false,error:'',stale:false,year:2028,metric:'29',lastRun:''};
  function referenceMacro(app,k,y){const m=app.state.data?.macros?.find(x=>x.id===k);const value=m?.values?.[String(y)]??m?.values?.[y];return value==null?null:Number(value);}
  function presets(app,mode) {
    // MarketShare, Escenario_ - copia.xlsx, 2026–2028. Los shocks de desempleo
    // severo son hipótesis explícitas, no valores oficiales de la SBS.
    const initial={
      base:{pbi:[2.7429440235464453,2.3444777132555883,2.9145251495953595],inflacion:[2.8,2.4,2.3],tpm:[4.5,4.5,4.5],tc_cierre:[3.5000944444444446,3.5551573770491802,3.612361095890411]},
      stress:{pbi:[1.9,0.4,1.4],inflacion:[3.2,3.0,2.6],tpm:[4.25,4.5,4.25],tc_cierre:[3.6,3.5551573770491802,3.612361095890411]},
      severe:{pbi:[0.8,-1,1.1],inflacion:[3.8,4.0,3.2],tpm:[4.25,4.75,4.5],tc_cierre:[3.7,3.85,3.95]}
    };
    const result={};
    for(const sc of CMP_KEYS){
      result[sc]={};
      for(const [key] of CMP_VARIABLES){
        result[sc][key]={};
        for(let i=0;i<CMP_YEARS.length;i++){
          const yr=CMP_YEARS[i];let val=initial[sc][key]?.[i];
          if(key==='desempleo'){
            const base=referenceMacro(app,'desempleo',yr)??5.8;
            val=sc==='base'?base:mode==='B'?base+(sc==='stress'?1.5:3):sc==='stress'?[6.22,5.62,5.51][i]:[6.8,7.3,7][i];
          }
          result[sc][key][yr]=val;
        }
      }
    }
    return result;
  }
  const cmoney=v=>v==null||!Number.isFinite(v)?'—':new Intl.NumberFormat('es-PE',{minimumFractionDigits:2,maximumFractionDigits:2}).format(v);
  const csigned=v=>v==null||!Number.isFinite(v)?'—':`${v>0?'+':''}${cmoney(v)}`;
  function cmpF(r,key,yr){if(!r)return null;let a=r.metrics?.[key]?.[String(yr)];if(key==='netMargin')return cmpF(r,'23',yr)-cmpF(r,'25',yr);if(key==='beforeTax')return cmpF(r,'29',yr)+cmpF(r,'28',yr);return a==null?null:Number(a);}
  function cmpStatus(){if(COMP.loading)return 'Ejecutando tres escenarios…';if(COMP.error)return COMP.error;if(COMP.stale)return 'Supuestos modificados: vuelve a ejecutar la comparativa';return COMP.lastRun?`Cálculos actualizados · ${COMP.lastRun}`:'Escenarios precargados · sin calcular todavía';}
  function cmpMatrix(app){if(!COMP.matrix)COMP.matrix=presets(app,COMP.mode);
    const columns=CMP_KEYS.flatMap(sc=>CMP_YEARS.map(year=>`<th class="cmp-col-${sc}">${year}</th>`));
    return `<details class="cmp-editor"><summary>Editar supuestos de los tres escenarios <span>15 columnas de entrada · 2026–2028</span></summary><div class="sim-table-scroll"><table class="cmp-matrix-table"><thead><tr><th rowspan="2">Variable</th>${CMP_KEYS.map(sc=>`<th colspan="3" class="cmp-col-${sc}">${esc(CMP_NAMES[CMP_KEYS.indexOf(sc)])}</th>`).join('')}</tr><tr>${columns.join('')}</tr></thead><tbody>${CMP_VARIABLES.map(([key,label,unit])=>`<tr><th>${esc(label)}<small>${esc(unit)}</small></th>${CMP_KEYS.map(sc=>CMP_YEARS.map(yr=>`<td class="cmp-col-${sc}"><input data-cmp-sc="${sc}" data-cmp-key="${key}" data-cmp-year="${yr}" type="text" inputmode="decimal" aria-label="${esc(label)} ${sc} ${yr}" value="${esc(COMP.matrix[sc][key][yr])}"></td>`).join('')).join('')}</tr>`).join('')}</tbody></table></div><p class="cmp-caption">El tipo de cambio promedio y las provisiones no se alteran. Para estrés 2027–2028, el tipo de cambio de cierre conserva el valor de referencia mientras no se confirme su correspondencia con el Excel.</p></details>`;
  }
  function cmpLineChart(key){
    const results=COMP.results;if(!results)return '';
    const rows=CMP_KEYS.map(sc=>CMP_YEARS.map(y=>cmpF(results[sc],key,y)));
    const nums=rows.flat().filter(Number.isFinite);
    if(!nums.length)return '<p class="sim-quiet">Sin información comparable.</p>';
    let min=Math.min(...nums),max=Math.max(...nums),span=max-min;
    if(span<.0001){span=Math.max(1,Math.abs(min)*.1);min-=span/2;max+=span/2}
    min-=span*.15;max+=span*.15;
    const W=800,H=272,L=78,R=22,T=24,B=43;
    const xx=i=>L+(W-L-R)*i/2, yy=v=>T+(max-v)*(H-T-B)/(max-min);
    const colors=['#188261','#dfa64f','#bb6258'];
    const lines=rows.map((a,i)=>`<polyline points="${a.map((v,k)=>`${xx(k)},${yy(v)}`).join(' ')}" fill="none" stroke="${colors[i]}" stroke-width="${i===0?3.5:3}" stroke-linejoin="round" stroke-linecap="round"${i===0?'':' stroke-dasharray="9 5"'}/>${a.map((v,k)=>`<circle cx="${xx(k)}" cy="${yy(v)}" r="4.5" fill="${colors[i]}" stroke="#fff" stroke-width="2"><title>${esc(CMP_NAMES[i])} ${CMP_YEARS[k]}: ${cmoney(v)} S/ MM</title></circle>`).join('')}`).join('');
    const grid=Array.from({length:5},(_,i)=>{const v=min+(max-min)*i/4;return `<line x1="${L}" y1="${yy(v)}" x2="${W-R}" y2="${yy(v)}" stroke="#e7ede8"/><text x="${L-10}" y="${yy(v)+4}" text-anchor="end" fill="#6e8275" font-size="11">${cmoney(v)}</text>`}).join('');
    return `<svg class="cmp-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución 2026–2028 de los tres escenarios">${grid}${CMP_YEARS.map((yr,k)=>`<text x="${xx(k)}" y="${H-10}" text-anchor="middle" fill="#6e8275" font-size="12">${yr}</text>`).join('')}${lines}</svg><div class="cmp-legend">${CMP_KEYS.map((sc,i)=>`<span><i style="background:${colors[i]}"></i>${esc(CMP_NAMES[i])}</span>`).join('')}</div>`;
  }
  function cmpResultTable(){const yy=COMP.year,r=COMP.results;
    return `<div class="sim-table-scroll"><table class="cmp-pnl-table"><thead><tr><th>Cuenta · S/ millones</th><th>Base</th><th>Estrés</th><th>Severo</th><th>Δ Estrés</th><th>Δ Severo</th></tr></thead><tbody>${CMP_LINES.map(([key,label])=>{const b=cmpF(r.base,key,yy),s=cmpF(r.stress,key,yy),v=cmpF(r.severe,key,yy);const highlight=['23','netMargin','beforeTax','29'].includes(key);return `<tr class="${highlight?'cmp-major':''} ${key==='29'?'cmp-final':''}"><th>${esc(label)}</th><td>${cmoney(b)}</td><td>${cmoney(s)}</td><td>${cmoney(v)}</td><td>${csigned(s-b)}</td><td>${csigned(v-b)}</td></tr>`}).join('')}</tbody></table></div>`;
  }
  function cmpResultCards(){const y=COMP.year,r=COMP.results,b=cmpF(r.base,'29',y),s=cmpF(r.stress,'29',y),v=cmpF(r.severe,'29',y),ok=(b>=s-.00001&&s>=v-.00001);
    return `<div class="cmp-kpis">${CMP_KEYS.map((sc,i)=>{const value=cmpF(r[sc],'29',y);return `<article class="cmp-card cmp-${sc}"><span>${esc(CMP_NAMES[i])}</span><strong>S/ ${cmoney(value)}</strong><small>${i===0?'Referencia del Excel':`${csigned(value-b)} vs. Base · S/ MM`}</small></article>`}).join('')}</div><div class="cmp-order ${ok?'cmp-order-ok':'cmp-order-review'}">${ok?'Orden de rentabilidad esperado: Base ≥ Estrés ≥ Severo':'La rentabilidad no sigue el orden Base ≥ Estrés ≥ Severo'} <span>El indicador describe el resultado, no altera cálculos.</span></div>`;
  }
  function cmpDrivers(){const y=COMP.year,r=COMP.results,fields=[['07','Colocaciones brutas - consumo'],['16','Ingresos por intereses'],['12','Gastos por intereses'],['19','Gastos administrativos'],['25','Provisiones de Riesgos'],['29','Utilidad neta']];
    const d=fields.map(([key,label])=>({label,value:cmpF(r.severe,key,y)-cmpF(r.base,key,y)}));const max=Math.max(1,...d.map(x=>Math.abs(x.value||0)));
    return `<div class="cmp-bridges">${d.map(x=>`<div class="cmp-bridge"><span>${esc(x.label)}</span><div class="cmp-track"><i class="cmp-zero"></i><i class="cmp-bar ${x.value<0?'cmp-down':'cmp-up'}" style="${x.value<0?'right:50%':'left:50%'};width:${Math.abs(x.value)/max*46}%"></i></div><b>${csigned(x.value)}</b></div>`).join('')}</div>`;
  }
  function cmpResults(){if(!COMP.results)return `<div class="cmp-empty"><strong>Comparador listo</strong><p>Pulsa «Ejecutar comparativa» para calcular Base, Estrés y Severo en el motor actual. Los resultados responden a los datos efectivamente instalados en tu equipo.</p></div>`;
    return `<div class="cmp-output"><div class="cmp-result-toolbar"><h3>Comparativa de rentabilidad</h3><label>Año<select id="cmp-year">${CMP_YEARS.map(y=>`<option value="${y}" ${COMP.year===y?'selected':''}>${y}</option>`).join('')}</select></label></div>${cmpResultCards()}<div class="cmp-panels"><section class="cmp-inner"><div class="cmp-result-toolbar"><h3>Evolución financiera</h3><select id="cmp-metric" aria-label="Cuenta para el gráfico">${[['29','Utilidad neta'],['23','Margen financiero bruto'],['16','Ingresos por intereses'],['19','Gastos administrativos'],['07','Colocaciones brutas - consumo']].map(([key,label])=>`<option value="${key}" ${COMP.metric===key?'selected':''}>${label}</option>`).join('')}</select></div>${cmpLineChart(COMP.metric)}</section><section class="cmp-inner"><h3>Variación de cuentas: Severo − Base</h3><p class="cmp-caption">Diferencias contables, no atribuciones causales de modelos.</p>${cmpDrivers()}</section></div><div class="cmp-inner cmp-table-panel"><div class="cmp-result-toolbar"><div><h3>Estado de resultados · tres escenarios</h3><p class="cmp-caption">S/ millones · ${COMP.year} · base, estrés y severo</p></div><button type="button" class="button ghost" id="cmp-export">Exportar CSV</button></div>${cmpResultTable()}</div><p class="cmp-caveat">Las provisiones del Modelo 25 permanecen iguales entre escenarios porque se reciben de Riesgos. El cierre supuesto de 2026 puede no reaccionar a los shocks. ${COMP.mode==='C'?'En la prueba C se añade una sensibilidad contable de rigidez de gastos, fuera de las ecuaciones econométricas.':''} No se fuerza el orden de utilidad ni se modifican datos fuente.</p></div>`;
  }
  function comparePanel(app){return window.IASPEMulti.html(app);}
  function cmpPack(models){const metrics={};for(const [key] of [...CMP_LINES,['07','Colocaciones brutas - consumo']]){if(['netMargin','beforeTax'].includes(key))continue;metrics[key]={};for(const y of CMP_YEARS)metrics[key][y]=financial(models,key,y)};return {metrics};}
  function cmpWithRigidity(all){if(COMP.mode!=='C')return all;const fresh=structuredClone(all);for(const sc of ['stress','severe'])for(const yr of CMP_YEARS){const gap=cmpF(fresh.base,'19',yr)-cmpF(fresh[sc],'19',yr);const adj=.75*gap;if(!(adj>0))continue;const m=fresh[sc].metrics;m['19'][yr]+=adj;m['28'][yr]-=.27*adj;m['29'][yr]-=.73*adj;}return fresh;}
  function cmpChanges(app,sc){const changes={};for(const [key] of CMP_VARIABLES){for(const yr of CMP_YEARS){const next=Number(COMP.matrix[sc][key][yr]);const old=referenceMacro(app,key,yr);if(!Number.isFinite(next))throw Error(`Revisa ${key} de ${sc}, ${yr}`);if(old===null||Math.abs(next-old)>1e-8)(changes[key]||={})[yr]=next;}}return changes;}
  async function cmpCalculate(app){if(COMP.loading)return;COMP.loading=true;COMP.error='';COMP.results=null;COMP.stale=false;draw(app);const all={};try{for(const [idx,sc] of CMP_KEYS.entries()){COMP.lastRun=`Calculando ${CMP_NAMES[idx]}…`;draw(app);const raw=await app.api('/api/calculate',{changes:cmpChanges(app,sc),horizon:2028});if((raw.warnings||[]).length)throw Error(`Advertencias en ${CMP_NAMES[idx]}: ${raw.warnings.slice(0,2).join(' ')}`);all[sc]=cmpPack(raw.models);}COMP.results=cmpWithRigidity(all);COMP.lastRun=new Date().toLocaleTimeString('es-PE',{hour:'2-digit',minute:'2-digit'});}catch(e){COMP.error=e.message||'No se pudo completar la comparativa.';COMP.results=null;}finally{COMP.loading=false;draw(app);}}
  function cmpCSV(){const header=['Año','Cuenta','Base','Estrés','Severo','Δ Estrés−Base','Δ Severo−Base','Modo'];const lines=[header];for(const yr of CMP_YEARS)for(const [key,label] of CMP_LINES){const b=cmpF(COMP.results.base,key,yr),s=cmpF(COMP.results.stress,key,yr),v=cmpF(COMP.results.severe,key,yr);lines.push([yr,label,b,s,v,s-b,v-b,COMP.mode]);}const csv='\ufeff'+lines.map(row=>row.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(';')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),link=document.createElement('a');link.href=url;link.download=`IASPE_Estres_Comparativa_${COMP.mode}_2026_2028.csv`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
  function cmpBind(app){window.IASPEMulti.bind(app);}

  function html(app) {
    const year=selectedYear(app),chartKey=app.state.laboratorioChart||'29';
    const caption={29:'Utilidad neta',23:'Margen financiero bruto',16:'Ingresos por intereses',19:'Gastos administrativos',25:'Provisiones para créditos'}[chartKey];
    return `<section class="sim-workspace"><header class="sim-hero"><div><span class="sim-eyebrow">IASPE / LABORATORIO FINANCIERO</span><h1>Laboratorio de escenarios</h1><p>Compara distintas trayectorias macroeconómicas, identifica los resultados más sensibles y explora nuevas variantes sin alterar los datos originales.</p></div><div class="sim-hero-aside"><span class="sim-state"><i></i>Espacio de simulación</span></div></header>
    ${comparePanel(app)}
    </section>`;
  }
  function draw(app) {if(location.hash.startsWith('#laboratorio')){$('#workspace').innerHTML=html(app);bind(app);}}
  function exportCSV(app) {
    const yr=selectedYear(app),lines=[['Cuenta','Base','Simulado','Variación','Variación %']];
    ACCOUNTS.forEach(([key,label])=>{const r=changeSummary(app.state.data?.models,app.state.data?.baseline,yr,key);lines.push([label,r.base,r.sim,r.delta,r.pct]);});
    const csv='\ufeff'+lines.map(row=>row.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(';')).join('\r\n');
    const link=document.createElement('a'),blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob);
    link.href=url;link.download=`IASPE_Laboratorio_PyL_${yr}.csv`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function bind(app) {
    $('#sim-year')?.addEventListener('change',e=>{app.state.laboratorioYear=+e.target.value;draw(app);});
    $('#sim-horizon')?.addEventListener('change',e=>{
      clearTimeout(timer);app.state.laboratorioHorizon=Number(e.target.value);
      app.state.laboratorioYear=horizon(app);
      app.calculate(scopeChanges(app));
    });
    $('#sim-chart-key')?.addEventListener('change',e=>{app.state.laboratorioChart=e.target.value;draw(app);});
    $('#sim-run')?.addEventListener('click',()=>{if(invalidInputs()){app.toast('Revisa los supuestos: todos los valores deben ser numéricos.');return;} clearTimeout(timer);app.calculate(scopeChanges(app));});
    document.querySelectorAll('.sim-macro-input').forEach(input=>{
      input.addEventListener('input',()=>{const value=readNumber(input.value);input.classList.toggle('invalid',!Number.isFinite(value));});
      input.addEventListener('change',()=>{
        const value=readNumber(input.value),key=input.dataset.simMacro,yr=input.dataset.simYear;
        if(!Number.isFinite(value)) {input.classList.add('invalid');return;}
        const baseline=app.state.data?.macros?.find(m=>m.id===key)?.values?.[yr];
        app.state.changes ||= {};
        if(baseline!==null && baseline!==undefined && Math.abs(Number(baseline)-value)<1e-10){if(app.state.changes[key]){delete app.state.changes[key][yr];if(!Object.keys(app.state.changes[key]).length)delete app.state.changes[key];}}
        else (app.state.changes[key] ||= {})[yr]=value;
        input.classList.toggle('edited',app.state.changes?.[key]?.[yr]!==undefined);
        input.classList.remove('invalid');
        app.state.scenarioId='';
        clearTimeout(timer);timer=setTimeout(()=>{if(!invalidInputs())app.calculate(scopeChanges(app));},300);
      });
    });
    $('#sim-reset')?.addEventListener('click',()=>{clearTimeout(timer);app.state.changes={};app.state.scenarioId='';app.calculate({});});
    $('#sim-export')?.addEventListener('click',()=>exportCSV(app));
    $('#sim-name')?.addEventListener('input',e=>app.state.laboratorioName=e.target.value);
    cmpBind(app);
    $('#sim-save')?.addEventListener('click',async()=>{
      const name=($('#sim-name')?.value||'').trim();
      if(!name){app.toast('Introduce un nombre para guardar la simulación.');$('#sim-name')?.focus();return;}
      if(invalidInputs()){app.toast('Corrige los supuestos antes de guardar.');return;}
      saving=true;
      try {const d=await app.api('/api/scenarios',{name,changes:scopeChanges(app),horizon:horizon(app)});
        app.state.scenarios=d.scenarios;app.state.scenarioId=d.scenario?.id||'';
        app.toast('Escenario guardado. Disponible también en Escenarios.');
      } catch(error){app.toast(error.message||'No se pudo guardar.');}
      finally {saving=false;draw(app);}
    });
  }
  window.IASPELaboratorio={html,bind,financial,changeSummary};
})();
