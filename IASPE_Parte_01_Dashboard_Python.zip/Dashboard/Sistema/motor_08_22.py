"""Lectura no destructiva de los módulos financieros vigentes 08–22.

Las proyecciones mostradas en base provienen de los XLSX originales. Los únicos
choques reestimados son los que tienen ecuación y coeficientes trazables; el
resto se mantiene fijo y se informa explícitamente al usuario.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import date, datetime
from functools import lru_cache
from pathlib import Path
import math
from openpyxl import load_workbook
from rutas import buscar_modelo

MODULES = {
 '08':('Depósitos de ahorro de Falabella', 3, 'stock'),
 '09':('Depósitos a plazo de Falabella', 3, 'stock'),
 '12':('Gastos por intereses de Falabella', 5, 'flow'),
 '16':('Ingresos por intereses de Falabella', 5, 'flow'),
 '17':('Disponible de Falabella', 5, 'stock'),
 '18':('Resultado neto de servicios financieros', 8, 'flow'),
 '19':('Gastos administrativos de Falabella', 5, 'flow'),
 '20':('Resultado de operaciones financieras de Falabella', 7, 'flow'),
 '21':('Inversiones financieras de Falabella', 6, 'stock'),
 '22':('Fondos interbancarios de Falabella', 2, 'stock'),
}
COMPONENTS = {
 '08':[('mn','01_Ahorro_MN',1,'Ahorro moneda nacional'),('me','02_Ahorro_ME',1,'Ahorro moneda extranjera')],
 '09':[('plazo','01_Plazo_ordinario',1,'Depósitos a plazo ordinario'),('cts','02_CTS',1,'Depósitos CTS')],
 '12':[('obligaciones','01_Obligaciones_publico',6,'Gastos por obligaciones con el público'),('entidades','02_Depositos_entidades_financieras',1,'Gastos por depósitos de entidades financieras'),('adeudos','03_Adeudos',1,'Gastos por adeudos'),('otras','04_Otras_fuentes',1,'Gastos por otras fuentes')],
 '16':[('creditos','01_Creditos',1,'Ingresos por créditos'),('inversiones','02_Inversiones',1,'Ingresos por inversiones'),('disponible','03_Disponibilidades',1,'Ingresos por disponibilidades'),('interbancarios','04_Interbancarios',1,'Ingresos por interbancarios')],
 '17':[('caja','01_Caja',1,'Caja'),('bancos','02_Bancos_y_corresponsales',1,'Bancos y corresponsales'),('canje','03_Canje',1,'Canje'),('otros','04_Otros_disponibles',1,'Otros disponibles')],
 '18':[('diversos','01_Ingresos_diversos',1,'Ingresos diversos'),('otros_ing','02_Otros_ingresos',1,'Otros ingresos'),('gastos_div','03_Gastos_diversos',1,'Gastos diversos'),('otros_gastos','04_Otros_gastos',1,'Otros gastos'),('fsd','05_Primas_FSD',1,'Primas FSD (gasto financiero)')],
 '19':[('personal','01_Personal',1,'Gastos de personal'),('directorio','02_Directorio',1,'Gastos del directorio'),('terceros','03_Servicios_de_terceros',1,'Servicios de terceros'),('impuestos','04_Impuestos_y_contribuciones',1,'Impuestos y contribuciones')],
 '20':[('consorcios','01_Consorcios',1,'Resultados de consorcios'),('asociadas','02_Subsidiarias_y_asociadas',1,'Resultados de subsidiarias y asociadas'),('tc','03_Diferencia_de_cambio',1,'Diferencia de cambio'),('derivados','04_Derivados_de_negociacion',1,'Derivados de negociación'),('inversiones','05_Inversiones',1,'Resultado de inversiones'),('otros','06_Otros_y_venta_cartera',1,'Otros financieros y venta de cartera')],
 '21':[('venta','01_Disponibles_para_la_venta',1,'Inversiones disponibles para la venta'),('asociadas','02_Subsidiarias_y_asociadas',1,'Inversiones en subsidiarias'),('otras','03_Otras_inversiones',4,'Otras inversiones')],
 '22':[('interbancarios','01_Fondos_interbancarios',3,'Fondos interbancarios')],
}
DEPENDENCIES = {
 '08_mn':['pbi','inflacion'], '08_me':['tc_cierre'], '09_plazo':['pbi','inflacion','tpm'],
 '09_cts':[], '10':['08','09','10_restringidos','10_otras'], '10_restringidos':['08','09'], '10_otras':['08','09'], '11':['10','tpm'],
 '12_obligaciones':['10','11'], '12_entidades':['tpm','inflacion'], '12_adeudos':['tpm'], '12_otras':['tpm'],
 '16_creditos':['07','13'], '16_inversiones':['21_venta'], '16_disponible':['17'], '16_interbancarios':['22'],
 '17_bancos':['10'], '18_diversos':['inflacion','03'], '18_gastos_div':['18_diversos'],
 '19_personal':['pbi'], '19_terceros':['pbi'], '19_impuestos':['inflacion'],
 '20_consorcios':['05'], '20_asociadas':['18_diversos'], '20_tc':['20_derivados','03'],
 '20_derivados':['18_diversos'], '20_inversiones':['18_diversos'], '20_otros':['18_diversos'],
 '21_venta':[], '21_asociadas':['20_asociadas'],
}
# Los canales efectivamente probados son cuatro regresiones de depósitos, la
# suma de 10, el costo de 11 y la identidad de gastos 12_Obligaciones.
# Los componentes siguientes cuentan con recalculo verificable en
# motor_actualizacion.py; no marcarlos como congelados antes de su ejecución.
SCENARIO_READY = {
 '08_mn','08_me','09_plazo','09_cts','08','09','10','10_restringidos','10_otras','11',
 '12_obligaciones','12_entidades','12_adeudos','12_otras','12',
 '16_creditos','16_inversiones','16_disponible','16_interbancarios','16',
 '17_caja','17_bancos','17_canje','17_otros','17',
 '18_diversos','18_gastos_div','18_fsd','18',
 '19_personal','19_terceros','19_impuestos','19',
 '21_venta','21_asociadas','21_otras','21',
} 

def _path(root, mid):
    return buscar_modelo(root, mid)

def _sheet(path, tab='Anual'):
    with_path=Path(path)
    wb=load_workbook(with_path,read_only=True,data_only=True)
    try:
        return [list(x) for x in wb[tab].values]
    finally:
        wb.close()

def _status(raw, yr):
    s=str(raw or '').lower()
    if any(k in s for k in ('supuesto', 'imput', 'mixto')) or 'cierre 2026' in s: return 'assumed'
    if 'observ' in s or 'audit' in s or ('sbs' in s and 'pron' not in s):return 'observed'
    if yr==2026 and ('proyec' in s or 'pronós' in s or 'pronost' in s):return 'assumed'
    if 'proyec' in s or 'pronós' in s or 'pronost' in s:return 'forecast'
    return 'observed' if yr<2026 else 'assumed' if yr==2026 else 'forecast'

def _annual(path, val_col=1):
    rows=_sheet(path);out={}
    hdr=[str(x or '').lower() for x in rows[0]]
    idx=next((i for i,s in enumerate(hdr) if 'condici' in s),len(hdr)-1)
    for r in rows[1:]:
        if not isinstance(r[0],(int,float)) or len(r)<=val_col or not isinstance(r[val_col],(int,float)):continue
        y=int(r[0]);flag=r[idx] if idx<len(r) else ''
        out[y]={'year':y,'value':float(r[val_col]),'status':_status(flag,y),
                'conditionSource':str(flag).strip() if flag is not None else ''}
    return out

def _monthly(path, val_col=1):
    try:rows=_sheet(path,'Mensual')
    except KeyError:return []
    out=[]
    hdr=[str(x or '').lower() for x in rows[0]]
    idx=next((i for i,s in enumerate(hdr) if 'condici' in s),len(hdr)-1)
    for r in rows[1:]:
        if not r[0] or len(r)<=val_col or not isinstance(r[val_col],(int,float)):continue
        d=r[0].strftime('%Y-%m') if isinstance(r[0],(date,datetime)) else str(r[0])[:7]
        if len(d)!=7: continue
        out.append({'date':d,'year':int(d[:4]),'value':float(r[val_col]),'status':_status(r[idx] if idx<len(r) else '',int(d[:4]))})
    return sorted(out,key=lambda r:r['date'])

def _coefficients(path):
    if not Path(path).is_file():return [],{}
    wb=load_workbook(path,read_only=True,data_only=True)
    try:
        if 'Resultados_MCO' in wb.sheetnames:
            rows=list(wb['Resultados_MCO'].values)
            coeff=[{'name':str(r[0]),'value':float(r[1]),
                    'se':float(r[2]) if isinstance(r[2],(int,float)) else None,
                    'pValue':float(r[3]) if isinstance(r[3],(int,float)) else None}
                   for r in rows[1:4] if r[0] and isinstance(r[1],(int,float))]
            summary={str(r[0]):r[1] for r in rows[6:10] if r[0]}
            return coeff,{'nobs':summary.get('Observaciones'),
                          'adjustedR2':summary.get('R² ajustado'),
                          'period':summary.get('Muestra'),
                          'inference':'HAC Newey–West (1 rezago)'}
        if 'MCO' in wb.sheetnames:
            a=list(wb['MCO'].values);h=list(wb['HAC'].values) if 'HAC' in wb.sheetnames else a
            head=next((i for i,r in enumerate(a) if r and str(r[0]).lower()=='variable'),10)
            result=[]
            for i in range(head+1,len(a)):
                r=a[i];u=h[i] if i<len(h) else r
                if len(r)<2 or not isinstance(r[1],(int,float)) or not r[0]:break
                result.append({'name':str(r[0]),'value':float(r[1]),'se':float(u[2]) if isinstance(u[2],(int,float)) else None,
                               'pValue':float(u[4]) if len(u)>4 and isinstance(u[4],(int,float)) else None})
            return result, {'observations':next((int(r[1]) for r in a if r[0]=='Observaciones'),None),
                             'adjustedRSquared':next((r[1] for r in a if r[0]=='R² ajustado'),None),
                             'inference':'HAC(1) publicado en el Excel original'}
        if 'Coeficientes' in wb.sheetnames:
            rows=list(wb['Coeficientes'].values)
            return ([{'name':str(r[0]),'value':float(r[1]),'pValue':r[3]} for r in rows[1:] if r[0] and isinstance(r[1],(int,float))],{'inference':'Coeficientes originales, HAC(1)'})
    finally:wb.close()
    return [],{}

def _model(mid,title,series,paths,depends=(),method='Pronóstico original (Excel)',kind='stock',coeffs=None,stats=None,monthly=None,notes=None):
    return {'id':mid,'name':title,'unit':'S/ millones' if mid!='11' else '%', 'frequency':'annual','kind':kind,
            'annual':list(series.values()),'monthly':monthly or [],'sourceFiles':[str(p) for p in paths if Path(p).exists()],
            'dependencies':list(depends),'inputs':[{'id':dep,'name':dep,'lag':0} for dep in depends],
            'method':method,'coefficients':coeffs or [],'statistics':stats or {},
            'status':'ok','reestimated':False,'canUpdate':False,
            'equationTex':'', 'limitations':notes or ['Los resultados proceden del Excel original. No se inventa un recálculo para una especificación no implementada.'],
            'scenarioSupport':mid in SCENARIO_READY}

def _make(root):
    models={}
    for mid,(title,col,kind) in MODULES.items():
        folder=_path(root,mid); consolidated=folder/'Consolidado.xlsx'
        series=_annual(consolidated,col)
        deps=[f'{mid}_{tag}' for tag,_,_,_ in COMPONENTS[mid]]
        if mid=='18':deps=deps[:-1] # primas FSD fuera del resultado neto de servicios
        if mid=='22':deps=['22_interbancarios']
        parent=_model(mid,title,series,[consolidated],deps,'Consolidación original (Excel)',kind)
        parent['closingRule']='Se utilizan los cierres reportados en el archivo consolidado.'
        models[mid]=parent
        for tag,subfolder,column,name in COMPONENTS[mid]:
            node=f'{mid}_{tag}'; sub=folder/subfolder
            source=sub/'Output'/'Pronostico.xlsx';inp=sub/'Input'/'Base_modelo.xlsx';coef=sub/'Output'/'Resultados_MCO.xlsx'
            if mid=='22':column=3 # saldo del modelo de fondos interbancarios
            if mid=='21' and tag=='otras':column=4
            series=_annual(source,column)
            coeffs,stats=_coefficients(coef)
            moncol = 1
            mon=_monthly(source,moncol) or _monthly(inp,moncol)
            dependencies=DEPENDENCIES.get(node, [])
            met='MCO, coeficientes originales' if coeffs else 'Pronóstico original (Excel)'
            models[node]=_model(node,name,series,[inp,source,coef,*sub.glob('Script/*.ipynb'),*sub.glob('Script/*.py')],dependencies,met,
                                'flow' if mid in {'12','16','18','19','20'} else 'stock',coeffs,stats,mon)
            if node == '20_tc':
                models[node]['equationTex'] = r'FX_t=(FX_{2026}+Der_{2026})\frac{ComprasM03_t}{ComprasM03_{2026}}-Der_t'
                models[node]['method'] = 'Relación FX+derivados sobre compras M03 con base 2026'
                models[node]['financialIdentityTex'] = r'FX_t=(FX+Der)_t-Der_t'
                models[node]['coefficients'] = []
                models[node]['statistics'] = {'method':'Proporción sobre compras M03, anclada en 2026'}
                models[node]['limitations'] = ['El rendimiento FX puede diferir de la actividad transaccional.',
                    '2026 es un cierre supuesto y se mantiene como ancla.']
                models[node]['dependencies']=['03','20_derivados']
            if node == '16_inversiones':
                models[node]['equationTex'] = r'I_t=\frac{AFS_{t-1}+AFS_t}{2}\times r_{2026}/100'
                models[node]['method']='Saldo promedio M21 por rendimiento estimado 2026 constante'
                models[node]['financialIdentityTex']=models[node]['equationTex']
                models[node]['coefficients']=[]
                models[node]['statistics']={'method':'Persistencia del rendimiento 2026'}
            if node == '09_plazo':
                planfile=Path(root).parent/'Control_Supuestos'/'plan_captaciones_iasc.json'
                if planfile.is_file():
                    models[node]['method']='MCO anual con cierre 2026 recalibrado y plan de captaciones IASC 2027–2028 como input exógeno explícito.'
                    models[node]['sourceFiles']=list(dict.fromkeys(models[node].get('sourceFiles',[])+[str(planfile)]))
                    models[node].setdefault('limitations',[]).append('Los ajustes de plan de 2027–2028 no son coeficientes de la regresión.')
            if node == '21_venta':
                models[node]['equationTex'] = r'AFS_t=PresupuestoTesoreria_t'
                models[node]['method']='Presupuesto IASC de inversiones de Tesorería'
                models[node]['coefficients']=[]
                models[node]['statistics']={'method':'Presupuesto estratégico sin regresión'}
            if node == '18_diversos':
                models[node]['equationTex'] = r'\widehat I_t=0.75\widehat I_t^{inflacion}+0.25\widehat I_t^{compras}'
                models[node]['method']='Combinación MCO 75% inflación + 25% compras tarjetas (M03)'
                models[node]['statistics']['combinationWeights']={'inflacion':.75,'compras':.25}
                models[node]['canUpdate']=True
            if node == '16_creditos':
                models[node]['equationTex'] = r'\widehat r_t=\alpha+\beta T_t+\gamma D_{2020,t}+\delta D_{2021,t}'
                models[node]['method'] = 'MCO anual del rendimiento implicito: M13 + COVID 2020 + COVID 2021'
                models[node]['financialIdentityTex'] = r'Ingresos_{creditos,t}=\overline{Saldo}_{t}\times \widehat r_t/100'
                models[node]['limitations'] = ['2026 incorpora un cierre estimado, no un año totalmente observado.', 'Las variables COVID identifican dos años excepcionales y no constituyen efectos causales.']
            if node == '18_gastos_div':
                models[node]['equationTex'] = r'GastosDiv_t=(GastosDiv_{2026}/IngresosDiv_{2026})\,IngresosDiv_t'
                models[node]['method'] = 'Ratio gastos/ingresos diversos del cierre supuesto de 2026'
                models[node]['dependencies'] = ['18_diversos']
                models[node]['canUpdate'] = True
            if node == '19_terceros':
                models[node]['method'] = 'Combinación MCO 75/25 en 2027–2030 (PBI y PBI + gasto rezagado)'
                models[node]['equationTex'] = r'\widehat G_t=w_t\widehat G_t^{PBI}+(1-w_t)\widehat G_t^{PBI,rezago}'
                models[node]['statistics']['combinationWeights'] = {'2027-2030':{'pbi':.75,'lagged':.25}}
                models[node]['canUpdate'] = True
                models[node]['limitations'] = ['2026 se mantiene como cierre supuesto; la estimación usa 2017–2026.',
                    'La ponderación 75/25 se conserva en todos los horizontes; su superioridad predictiva debe verificarse en futuras validaciones.',
                    'La comparación con IASPE anterior es externa a la estimación.']
            if node == '19_personal':
                models[node]['canUpdate'] = True
                models[node]['dependencies'] = ['pbi','inflacion']
                models[node]['method'] = 'Proyección vinculada a trabajadores y precios (MCO)'
    # Dos cuentas menores ancladas al cierre 2026 y a la base de depósitos desde 2027.
    base=_path(root,'10')
    for node,sub,title in [('10_restringidos','01_Depositos_restringidos','Depósitos restringidos'),
                            ('10_otras','02_Otras_obligaciones','Otras obligaciones con el público')]:
        folder=base/sub
        pred=folder/'Output'/'Pronostico.xlsx'
        models[node]=_model(node,title,_annual(pred),[folder/'Input'/'Base_modelo.xlsx',pred],
            depends=['08','09'],method='Cierre 2026 con variación interanual jun-ago; 2027–2030 proporcional a M08 + M09',
            monthly=_monthly(pred))
        models[node]['canUpdate']=True
        models[node]['equationTex']=r'Saldo_t=Saldo_{2026}\frac{Ahorro_t+Plazo_t}{Ahorro_{2026}+Plazo_{2026}}'
        models[node]['updateRule']='Cierre 2026: diciembre 2025 multiplicado por el crecimiento de los saldos promedio junio–agosto; 2027–2030: proporción fija de ahorro + plazo. Al actualizar SBS, se recalcula con los últimos tres meses comparables.'
        models[node]['limitations']=['Partida menor contable: no se afirma causalidad directa con variables macro.',
             'El supuesto proporcional requiere aprobación de Tesorería / Contabilidad; se recalibra con el cierre SBS definitivo.',
             'Las variaciones de M08 y M09 transmiten cada escenario; 2026 es un cierre supuesto hasta disponer del dato observado de diciembre.']
    book=base/'03_Consolidacion_obligaciones'/'Obligaciones_con_el_publico.xlsx'
    models['10']=_model('10','Obligaciones con el público de Falabella',_annual(book,5),[book],
        ['08','09','10_restringidos','10_otras'],'Suma contable de los cuatro componentes')
    folder=_path(root,'11'); inp=folder/'Input'/'Base_modelo.xlsx';pred=folder/'Output'/'Pronostico.xlsx'
    coeff,stats=_coefficients(folder/'Output'/'Resultados_MCO.xlsx')
    models['11']=_model('11','Costo de obligaciones con el público de Falabella',_annual(pred),
        [inp,pred,folder/'Output'/'Resultados_MCO.xlsx'],['10','tpm'],
        'MCO anual dinámico (coeficientes originales)','rate',coeff,stats,_monthly(inp))
    models['11']['unit']='%'
    # metadata: identificar insumos macro en ecuaciones documentadas
    return models

def _year_value(s,yr):
    return next((r['value'] for r in s if r['year']==yr),None)

def _put(model,y,v):
    for r in model['annual']:
        if r['year']==y:
            r.update(value=float(v),status='forecast');return
    model['annual'].append({'year':y,'value':float(v),'status':'forecast'});
    model['annual'].sort(key=lambda r:r['year'])

def _c(model):return [r['value'] for r in model['coefficients']]

def _changed(scenarios,ids):return any(scenarios.get(k) for k in ids)

def _apply_paths(models,scenarios,context):
    warnings=[]; affected=set(); macro={}
    for k in ('pbi','inflacion','tpm','tc_cierre'):
        macro[k]={}
        if k=='tc_cierre':
            folder=_path(context['source_root'],'08')/'02_Ahorro_ME'/'Input'/'Base_modelo.xlsx'
            macro[k]={int(r[0]):float(r[2]) for r in _sheet(folder)[1:] if isinstance(r[0],(int,float)) and isinstance(r[2],(int,float))}
        else:
            folder=_path(context['source_root'],'09')/'01_Plazo_ordinario'/'Input'/'Base_modelo.xlsx'
            col={'pbi':2,'inflacion':3,'tpm':4}[k]
            macro[k]={int(r[0]):float(r[col]) for r in _sheet(folder)[1:] if isinstance(r[0],(int,float)) and isinstance(r[col],(int,float))}
        for y,v in scenarios.get(k,{}).items():macro[k][int(y)]=float(v)
    # Solo son shocks reales las desviaciones respecto de los Excel vigentes;
    # las trayectorias de referencia no constituyen escenarios alterados.
    changed = {}
    for k in macro:
        if k == 'tc_cierre':
            source = _path(context['source_root'],'08')/'02_Ahorro_ME'/'Input'/'Base_modelo.xlsx'
            ref = {int(r[0]):float(r[2]) for r in _sheet(source)[1:] if isinstance(r[0],(int,float)) and isinstance(r[2],(int,float))}
        else:
            source = _path(context['source_root'],'09')/'01_Plazo_ordinario'/'Input'/'Base_modelo.xlsx'
            col = {'pbi':2,'inflacion':3,'tpm':4}[k]
            ref = {int(r[0]):float(r[col]) for r in _sheet(source)[1:] if isinstance(r[0],(int,float)) and isinstance(r[col],(int,float))}
        changed[k] = {str(y):v for y,v in macro[k].items() if 2026 <= y <= 2030 and y in ref and abs(v-ref[y]) > 1e-9}
    scenarios = {k:v for k,v in changed.items() if v}
    # Pronóstico condicionado con los parámetros originales, sin volver a estimar coeficientes.
    for mid in ['08_mn','08_me','09_plazo','09_cts']:
        model=models[mid]
        ids=DEPENDENCIES.get(mid,[])
        # no se recalcula el escenario cuando solo cambian otros drivers
        if not _changed(scenarios,ids):continue
        coeff=_c(model)
        if not coeff:continue
        for year in range(2027,2031):
            prior=_year_value(model['annual'],year-1)
            if prior is None:continue
            if mid=='08_mn':
                x=[1.,macro['pbi'][year-1],macro['inflacion'][year-1],float(year in (2024,2025))]
                growth=sum(a*b for a,b in zip(coeff,x));v=prior*(1+growth/100)
            elif mid=='08_me':
                # original: 100×Δln(saldo) = const + β × ΔTC(t−1)
                diff=macro['tc_cierre'][year-1]-macro['tc_cierre'][year-2]
                growth=coeff[0]+coeff[1]*diff;v=prior*math.exp(growth/100)
            elif mid=='09_plazo':
                x=[1.,macro['pbi'][year-1],macro['inflacion'][year-1],macro['tpm'][year]-macro['tpm'][year-1]]
                growth=sum(a*b for a,b in zip(coeff,x));v=prior*(1+growth/100)
            else:continue
            if v<=0:raise ValueError(f'El escenario genera saldo no positivo para {mid}: {year}.')
            _put(model,year,v)
        affected.add(mid)
    # Consolidación 08 y 09: todos los componentes en unidades S/ MM.
    for group in ('08','09'):
        ids=[f'{group}_{tag}' for tag,*_ in COMPONENTS[group]]
        if not any(mid in affected for mid in ids):continue
        for y in range(2027,2031):_put(models[group],y,sum(_year_value(models[m]['annual'],y) for m in ids))
        affected.add(group)
    if '08' in affected or '09' in affected:
        for y in range(2027,2031):
            v=sum(_year_value(models[k]['annual'],y) for k in ['08','09','10_restringidos','10_otras'])
            _put(models['10'],y,v)
        affected.add('10')
    # Ecuación del costo según el Excel de MCO: c_t = constante + β1*c(t-1) + β2*TPM(t) + β3*100*P(t)/O(t)
    if '10' in affected or _changed(scenarios,['tpm']):
        c=_c(models['11'])
        if len(c)==4:
            for y in range(2027,2031):
                share=100*_year_value(models['09']['annual'],y)/_year_value(models['10']['annual'],y)
                v=c[0]+c[1]*_year_value(models['11']['annual'],y-1)+c[2]*macro['tpm'][y]+c[3]*share
                _put(models['11'],y,v)
            affected.add('11')
    # Únicamente el componente 12_obligaciones utiliza estos dos drivers.
    if '10' in affected or '11' in affected:
        # Factor histórico (2015-2026), medianas definidas en output original.
        src=_path(context['source_root'],'12')/'01_Obligaciones_publico'/'Output'/'Pronostico.xlsx'
        rs=_sheet(src)
        factor=next((float(r[5]) for r in rs if isinstance(r[0],(int,float)) and int(r[0])==2027 and isinstance(r[5],(int,float))),None)
        if factor is None:
            factors=[float(r[5]) for r in rs if isinstance(r[0],(int,float)) and 2015<=int(r[0])<=2026 and isinstance(r[5],(int,float))]
            factor=sorted(factors)[len(factors)//2] if factors else None
        if factor is None: raise ValueError('No se encontró factor de gastos por intereses del modelo 12 original.')
        for y in range(2027,2031):
            ob=( _year_value(models['10']['annual'],y-1)+_year_value(models['10']['annual'],y))/2
            cost=(_year_value(models['11']['annual'],y-1)+_year_value(models['11']['annual'],y))/2
            v=ob*cost*factor/100
            _put(models['12_obligaciones'],y,v)
            others=[_year_value(models[f'12_{k}']['annual'],y) for k in ('entidades','adeudos','otras')]
            _put(models['12'],y,v+sum(others))
        affected.update(('12','12_obligaciones'))
    # Los restantes bloques exponen pronóstico original, no un supuesto recálculo.
    # Identificar TODA la cadena sin cálculo validado. No dibujar como
    # resultado simulado lo que sigue siendo un pronóstico congelado.
    frozen_ids = set()
    if scenarios:
        for _ in range(len(models)):
            newer = {m['id'] for m in models.values()
                     if m['id'] not in SCENARIO_READY
                     and any(d in affected or d in frozen_ids or bool(scenarios.get(d))
                             for d in m.get('dependencies',[]))}
            if newer == frozen_ids:
                break
            frozen_ids = newer
    if '12' in affected and any(k in frozen_ids for k in ('12_entidades','12_adeudos','12_otras')):
        frozen_ids.add('12') # suma parcial: se recalcula solo obligaciones al público
    if frozen_ids:
        for id in frozen_ids:
            m=models[id]
            m['status']='needs_input'
            m['issues']=['Escenario parcial: este componente conserva el pronóstico original; falta integrar y validar su mecanismo de transmisión.']
            m['limitations'].append('ADVERTENCIA: el escenario actual no se transmite automáticamente a este componente.')
        names=', '.join(sorted(frozen_ids))
        warnings.append('Escenario parcial: los siguientes modelos conservan su pronóstico original y NO reflejan íntegramente los choques: '+names+'.')
    return warnings


def _recalcular_gasto_personal(models, escenarios, observaciones, root):
    """Reproduce el notebook 19/Personal sin sobrescribir ninguno de los Excel originales.

    Los gastos observados/cierre son un input distinto del número de trabajadores.
    La SBS B-2305 alimenta solamente el número de trabajadores, no el gasto.
    """
    headcount = (observaciones or {}).get('trabajadores_falabella', {})
    expenses = (observaciones or {}).get('19_personal', {})
    change_macro = any((escenarios or {}).get(k) for k in ('pbi', 'inflacion'))
    if not headcount and not expenses and not change_macro:
        return False
    import numpy as np
    import statsmodels.api as sm
    file = _path(root, '19') / '01_Personal' / 'Input' / 'Base_modelo.xlsx'
    rows = _sheet(file)
    data = {int(r[0]): r for r in rows[1:] if isinstance(r[0], (int,float))}
    N = {y:float(data[y][6]) for y in range(2016,2027)}
    observed_headcount={}
    for period,value in headcount.items():
        if not str(period).isdigit() or not 2016 <= int(period) <= 2030:
            raise ValueError('Personal SBS: el cierre debe ser un año entre 2016 y 2030.')
        if not np.isfinite(float(value)) or float(value) <= 0:
            raise ValueError('Personal SBS: el número de trabajadores debe ser positivo.')
        observed_headcount[int(period)] = float(value)
    N.update({y:v for y,v in observed_headcount.items() if y<=2026})
    G = {r['year']:float(r['value']) for r in models['19_personal']['annual']}
    for period, value in expenses.items():
        if not str(period).isdigit() or len(str(period))!=4 or not 2016 <= int(period) <= 2030:
            raise ValueError('Los gastos de personal admiten observaciones anuales entre 2016 y 2030.')
        if not math.isfinite(float(value)) or float(value)<0:
            raise ValueError('Los gastos de personal deben ser no negativos.')
        G[int(period)] = float(value)
    pbi = {y: float(r[2]) for y,r in data.items()}
    pbi_estimacion = dict(pbi)  # 2017–2026 se estima con la base original, sin alterar betas por estrés.
    pi = {y: float(r[3]) for y,r in data.items()}
    for y,v in (escenarios or {}).get('pbi',{}).items():pbi[int(y)]=float(v)
    for y,v in (escenarios or {}).get('inflacion',{}).items():pi[int(y)]=float(v)
    # Ecuación del notebook original: crecimiento logarítmico de personal
    # ~ constante + PBI + indicadora 2020–2021 (muestra 2017–2026; cierre supuesto).
    years = list(range(2017,2027))
    Y = np.array([100*math.log(N[t]/N[t-1]) for t in years])
    X = np.array([[1.,pbi_estimacion[t],int(t in (2020,2021))] for t in years])
    fitted = sm.OLS(Y,X).fit()
    hac = fitted.get_robustcov_results(cov_type='HAC', maxlags=1, use_t=True)
    model_personal=models['19_personal']
    names=['Constante · crecimiento de trabajadores','PBI real anual','D 2020–2021']
    model_personal['coefficients']=[{'name':names[i], 'value':float(fitted.params[i]),
       'se':float(hac.bse[i]),'pValue':float(hac.pvalues[i])} for i in range(3)]
    model_personal['statistics']={'nobs':int(fitted.nobs),'adjustedR2':float(fitted.rsquared_adj),
       'r2':float(fitted.rsquared),'period':'2017–2026 (cierre supuesto)',
       'inference':'HAC Newey–West (1 rezago)'}
    for t in range(2027,2031):
        N[t] = observed_headcount.get(t, N[t-1]*math.exp(float(np.dot([1.,pbi[t],0.],fitted.params))/100))
    avg = {t:(N[t-1]+N[t])/2 for t in range(2017,2031)}
    annual_expenses={int(k) for k in expenses}
    for t in range(2027,2031):
        if t not in annual_expenses:
            G[t] = G[t-1]*(avg[t]/avg[t-1])*(1+pi[t]/100)
    component=models['19_personal']
    parent=models['19']
    parent_rows={r['year']:r for r in parent['annual']}
    for r in component['annual']:
        y=r['year']
        if y in G and 2016<=y<=2030:
            old=float(r['value']);new=float(G[y])
            if y in parent_rows:
                parent_rows[y]['value'] += new-old
            r['value']=new
            if y in {int(x) for x in expenses if str(x).isdigit()}:
                r['status']='observed'
            elif y>=2027:
                r['status']='forecast'
    component['reestimated']=True
    parent['reestimated']=True
    component['updateRule']='Trabajadores SBS B-2305 ajustan cierre del personal; el gasto se proyecta con personal promedio e inflación. La carga manual de gastos tiene prioridad.'
    return True


def _propagar_cartera_a_resultados(models, upstream, root):
    """Reproduce la transmisión explícita de los notebooks originales 16 y 20.

    Solo actualiza los componentes cuyos drivers y fórmulas están verificados.
    El resto del P&L permanece en el Excel original hasta disponer de motor propio.
    """
    def values(mid):
        return {r['year']:float(r['value']) for r in (upstream[mid]['annual'] if mid in upstream else models[mid]['annual'])}
    affected = []
    # Modelo 20 / Consorcios: C_t=C_2026 × tarjetas_t/tarjetas_2026.
    if '05' in upstream:
        cards=values('05')
        original = _sheet(_path(root,'20')/'01_Consorcios'/'Input'/'Base_modelo.xlsx')
        old={int(r[0]):float(r[3]) for r in original[1:] if isinstance(r[0],(int,float)) and isinstance(r[3],(int,float))}
        moved=any(y in old and abs(cards[y]-old[y])>1e-6 for y in range(2026,2031))
        if moved:
            c2026=_year_value(models['20_consorcios']['annual'],2026)
            for y in range(2027,2031):
                new = c2026*cards[y]/cards[2026]
                before=_year_value(models['20_consorcios']['annual'],y)
                _put(models['20_consorcios'],y,new)
                _put(models['20'],y,_year_value(models['20']['annual'],y)+(new-before))
            models['20_consorcios']['reestimated']=True
            models['20']['reestimated']=True
            affected += ['20_consorcios','20']
    # Modelo 16 / 01_Creditos: M13 + dos dummies COVID (2020 y 2021).
    # Propagar movimientos de M07 y M13 sin introducir el blend antiguo 2029.
    if '07' in upstream and '13' in upstream:
        cards=values('07');rates=values('13')
        records=_sheet(_path(root,'16')/'01_Creditos'/'Input'/'Base_modelo.xlsx')
        data={int(r[0]):r for r in records[1:] if isinstance(r[0],(int,float))}
        moved=any(abs((cards[y-1]+cards[y])/2-float(data[y][3]))>1e-5
                  or abs(rates[y]-float(data[y][4]))>1e-5 for y in range(2026,2031))
        if moved:
            import numpy as np
            coeffs=models['16_creditos'].get('coefficients',[])
            if len(coeffs)!=4:raise ValueError('M16: faltan coeficientes M13 y dos COVID')
            coef=np.array([float(c['value']) for c in coeffs],dtype=float)
            cierre_modificado=(abs((cards[2025]+cards[2026])/2-float(data[2026][3]))>1e-5
                                 or abs(rates[2026]-float(data[2026][4]))>1e-5)
            if cierre_modificado:
                rend={t:float(data[t][2]) for t in range(2016,2026)}
                inc2026=_year_value(models['16_creditos']['annual'],2026)
                rend[2026]=100*inc2026/((cards[2025]+cards[2026])/2)
                years=range(2016,2027)
                X=np.array([[1.,rates[t],float(t==2020),float(t==2021)] for t in years])
                Y=np.array([rend[t] for t in years])
                coef=np.linalg.lstsq(X,Y,rcond=None)[0]
            for t in range(2027,2031):
                tasa=float(np.dot(coef,[1.,rates[t],0.,0.]))
                new=(cards[t-1]+cards[t])/2*tasa/100
                old=_year_value(models['16_creditos']['annual'],t)
                _put(models['16_creditos'],t,new)
                _put(models['16'],t,_year_value(models['16']['annual'],t)+(new-old))
            models['16_creditos']['reestimated']=True
            models['16_creditos']['estimatedEquationTex']=r'\widehat r_t=\alpha+\beta T_t+\gamma D_{2020,t}+\delta D_{2021,t}'
            models['16']['reestimated']=True
            affected += ['16_creditos','16']

    return affected


def build_registry(source_root):
    return list(_make(source_root).values())


def get_macros(source_root):
    root=Path(source_root)
    dep=_path(root,'08')/'02_Ahorro_ME'/'Input'/'Base_modelo.xlsx'
    vals={str(int(r[0])):float(r[2]) for r in _sheet(dep)[1:] if isinstance(r[0],(int,float)) and isinstance(r[2],(int,float))}
    return [{'id':'tc_cierre','name':'Tipo de cambio de cierre','frequency':'annual','unit':'S/ por US$',
             'values':vals,'modelIds':['08_me']}]


def _calibrar_plazo_base_2026(models, root, latest_observed=None):
    """2026: estacionalidad observada SBS, no extrapolación de septiembre ficticio.

    Se calcula sobre el histórico mensual, sin utilizar proyecciones de 2026
    como datos de estimación. Al publicarse diciembre observado, se desactiva.
    """
    import json, statistics
    plan_path=Path(root).parent/'Control_Supuestos'/'plan_captaciones_iasc.json'
    if not plan_path.is_file():return
    data=json.loads(plan_path.read_text(encoding='utf-8'))
    cfg=data.get('cierre_plazo_2026',{})
    input_path=_path(root,'09')/'01_Plazo_ordinario'/'Input'/'Base_modelo.xlsx'
    history={str(r[0])[:7]:r for r in _sheet(input_path,'Mensual')[1:]
             if r and r[0] is not None and isinstance(r[1],(float,int))}
    if latest_observed and str(latest_observed).startswith('2026-'):
        import gzip
        panel_path=Path(root).parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz'
        with gzip.open(panel_path,'rt',encoding='utf-8') as source:
            incoming=json.load(source)['series']['balance:047']['05']
        for month,value in incoming.items():
            if '2026-08'<month<=latest_observed:
                if not isinstance(value,(int,float)) or not math.isfinite(value):
                    raise ValueError(f'M09: saldo observado inválido en {month}')
                history[month]=[month,float(value),None,'Observado SBS']
    observed=sorted(k for k,r in history.items() if k.startswith('2026-') and
                    'observ' in str(r[3] if len(r)>3 else '').lower())
    if not observed:return
    last=observed[-1]
    for row in models['09_plazo'].get('monthly',[]):
        key=str(row.get('date',''))[:7]
        if key in observed:
            value=float(history[key][1])
            row.update(value=value,status='observed',observed=value,assumed=None,forecast=None)
    if last.endswith('-12'):return
    month=last[5:7]
    selected=cfg.get('anios_muestra',[2021,2022,2023,2024,2025])
    ratios=[float(history[f'{y}-12'][1])/float(history[f'{y}-{month}'][1])-1
            for y in selected if f'{y}-12' in history and f'{y}-{month}' in history
            and float(history[f'{y}-{month}'][1])>0]
    if len(ratios)!=len(selected):
        raise ValueError('M09: faltan observaciones para la estimación estacional de cierre 2026.')
    rate=statistics.mean(ratios)
    latest=float(history[last][1]); forecast=latest*(1+rate)
    if forecast<=0:raise ValueError('M09: estacionalidad produce un stock no positivo.')
    model=models['09_plazo']
    closing=next(r for r in model['annual'] if r['year']==2026)
    if abs(closing['value']-forecast)>1e-7:model['reestimated']=True
    closing.update(value=forecast,status='assumed',observed=None,assumed=forecast,forecast=None)
    last_month=int(month)
    for row in model.get('monthly',[]):
        key=str(row.get('date',''))[:7]
        if key.startswith('2026-') and int(key[5:7])>last_month:
            elapsed=(int(key[5:7])-last_month)/(12-last_month)
            val=latest*(1+rate)**elapsed
            row.update(value=val,status='assumed',assumed=val,observed=None,forecast=None)
    model['method']='Cierre 2026: MCO estacional de variación relativa; 2027–2030: MCO macroeconómico y, cuando corresponda, plan IASC explícito.'
    model['closingRule']=f'Saldo SBS {last} = {latest:.3f} MM; variación restante estimada {rate*100:.2f}% (MCO constante, 2021–2025).'
    model.setdefault('statistics',{})['seasonalClosing2026']={
        'lastObservedMonth':last,'sample':selected,'estimatedRelativeChange':rate,
        'forecastDecember':forecast,'trainingProjectionsExcluded':True}
    model['sourceFiles']=list(dict.fromkeys(model.get('sourceFiles',[])+[str(plan_path)]))

def recalculate(context, scenarios=None, observations=None):
    root=context.get('source_root',context.get('sourceRoot'))
    models=_make(root)
    _calibrar_plazo_base_2026(models, root)
    scenarios=scenarios or {};observations=observations or {}
    new_obs={k:v for k,v in observations.items() if k in models and k!='19_personal' and v}
    pendientes=set(new_obs)-{'08','08_mn','08_me','21_venta'}
    if pendientes:
        raise ValueError('Los modelos 08–22 restantes utilizan salidas originales: '+', '.join(sorted(pendientes)))
    warning=_apply_paths(models,scenarios,{'source_root':root}) if scenarios else []
    for key in ('08_mn','08_me','08','21_venta'):
        for periodo,dato in new_obs.get(key,{}).items():
            if not str(periodo).isdigit() or not 2026<=int(periodo)<=2030:
                raise ValueError(f'Período inválido para {key}: {periodo}')
            year=int(periodo)
            row=next((r for r in models[key]['annual'] if r['year']==year),None)
            if row is None:
                raise ValueError(f'Sin cierre anual para {key}/{year}')
            valor=float(dato['value'] if isinstance(dato,dict) else dato)
            if not math.isfinite(valor) or valor<0:
                raise ValueError(f'Saldo inválido para {key}/{year}')
            estado=(dato.get('status',row['status']) if isinstance(dato,dict) else row['status'])
            if estado not in {'observed','assumed','forecast'}:
                raise ValueError(f'Condición inválida para {key}/{year}')
            row.update(value=valor,status=estado)
            row['observed']=valor if estado=='observed' else None
            row['assumed']=valor if estado=='assumed' else None
            row['forecast']=valor if estado=='forecast' else None
            if isinstance(dato,dict) and dato.get('sourceMonth'):
                row['sourceMonth']=dato['sourceMonth']
            models[key]['canUpdate']=True
    for periodo in set(new_obs.get('08_mn',{})) & set(new_obs.get('08_me',{})):
        a=new_obs['08_mn'][periodo];b=new_obs['08_me'][periodo]
        if isinstance(a,dict) and isinstance(b,dict) and a.get('sourceMonth')!=b.get('sourceMonth'):
            raise ValueError(f'Ahorro MN/ME con meses distintos en {periodo}')
        if periodo in new_obs.get('08',{}):
            v=lambda x:float(x['value'] if isinstance(x,dict) else x)
            if not math.isclose(v(a)+v(b),v(new_obs['08'][periodo]),rel_tol=0,abs_tol=0.05):
                raise ValueError(f'Ahorro MN + ME no concilia con total SBS en {periodo}')
    for periodo in new_obs.get('08',{}):
        year=int(periodo)
        if year > 2026 or periodo in observations.get('sbs_contable',{}).get('10',{}):
            continue
        total=sum(_year_value(models[k]['annual'],year) for k in ('08','09','10_restringidos','10_otras'))
        cierre=next(r for r in models['10']['annual'] if r['year']==year)
        cierre.update(value=total,status='assumed',assumed=total,observed=None,forecast=None)
        models['10']['canUpdate']=True
    _recalcular_gasto_personal(models,scenarios,observations,root)
    _propagar_cartera_a_resultados(models,context.get('models',{}),root)
    return {'models':list(models.values()),'warnings':warning}
