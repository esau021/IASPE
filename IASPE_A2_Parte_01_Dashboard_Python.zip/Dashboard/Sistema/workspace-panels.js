/* Mesas de escenarios y actualización del entorno IASPE. */
(() => {
  'use strict';
  const YEARS = [2026, 2027, 2028, 2029, 2030];
  const MONTHS = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  let calculationTimer;
  let comparisonRequest = 0;
  const list = data => Array.isArray(data) ? data : Object.values(data || {});
  const esc = (app, value) => app.escape(String(value ?? ''));
  const signed = (app, value, digits = 2) => value == null || !Number.isFinite(value) ? '—' : `${value > 0 ? '+' : ''}${app.fmt(value, digits)}`;
  const finite = value => typeof value === 'number' && Number.isFinite(value);
  function number(text) {
    let value = String(text ?? '').trim().replace(/[\s\u00a0%]/g, '');
    if (!value || value === '—' || value === '-') return null;
    let negative = false;
    if (/^\(.*\)$/.test(value)) { negative = true; value = value.slice(1, -1); }
    if (value.includes(',') && value.includes('.')) {
      value = value.lastIndexOf(',') > value.lastIndexOf('.') ? value.replace(/\./g, '').replace(',', '.') : value.replace(/,/g, '');
    } else if (/^-?\d{1,3}(,\d{3})+$/.test(value)) value=value.replace(/,/g,'');
    else if (/^-?\d{1,3}(\.\d{3}){2,}$/.test(value)) value=value.replace(/\./g,'');
    else if (value.includes(',')) value = value.replace(',', '.');
    const result = Number(value);
    return Number.isFinite(result) ? (negative ? -result : result) : null;
  }
  function period(text) {
    const value = String(text ?? '').trim();
    let match;
    if (/^\d{4}$/.test(value)) return value;
    if ((match = value.match(/^(\d{4})[-/](\d{1,2})(?:[-/]\d{1,2})?(?:T.*| .*|$)/))) return `${match[1]}-${match[2].padStart(2, '0')}`;
    if ((match = value.match(/^\d{1,2}[-/](\d{1,2})[-/](\d{4})$/))) return `${match[2]}-${match[1].padStart(2, '0')}`;
    if ((match = value.match(/^(\d{1,2})[-/](\d{4})$/))) return `${match[2]}-${match[1].padStart(2, '0')}`;
    const monthNames = {ene: 1, jan: 1, feb: 2, mar: 3, abr: 4, apr: 4, may: 5, jun: 6, jul: 7, ago: 8, aug: 8, sep: 9, set: 9, oct: 10, nov: 11, dic: 12, dec: 12};
    if ((match = value.toLowerCase().match(/^([a-záéíóú]+)[- /](\d{2}|\d{4})$/)) && monthNames[match[1].slice(0, 3)]) return `${match[2].length === 2 ? '20' + match[2] : match[2]}-${String(monthNames[match[1].slice(0, 3)]).padStart(2, '0')}`;
    return null;
  }
  function validPeriod(value) {
    if (!value || !/^\d{4}(?:-\d{2})?$/.test(value)) return false;
    const year = Number(value.slice(0, 4)), month = value.length > 4 ? Number(value.slice(5)) : 1;
    return year >= 1990 && year <= 2030 && month >= 1 && month <= 12;
  }
  function allModels(app) { return list(app.state.data?.models); }
  // Una sola categoría para el Estado de Situación Financiera. El M47 continúa
  // como control interno del cierre, pero no se ofrece como subcuenta del balance.
  const RESULT_SECTIONS = [
    {area:'', name:'Ingresos y margen', ids:['12','16','18','20','23']},
    {area:'', name:'Gastos y provisiones', ids:['19','24','25','26','27','28']},
    {area:'', name:'Resultado del ejercicio', ids:['29']}
  ];
  const BALANCE_SECTIONS = [
    {area:'Activo', name:'Cartera y colocaciones', ids:['05','06','07']},
    {area:'Activo', name:'Liquidez e inversiones', ids:['17','21','22','31','32']},
    {area:'Activo', name:'Otros activos', ids:['33','34']},
    {area:'Pasivo', name:'Depósitos y financiamiento', ids:['08','09','10','11','35','36']},
    {area:'Pasivo', name:'Cuentas por pagar y provisiones', ids:['37','38','39','40']},
    {area:'Patrimonio', name:'Capital y resultados', ids:['41','42','43','44','45','46']}
  ];
  const MODEL_CATEGORIES = [
    {id:'mercado', name:'Mercado', models:['48']},
    {id:'operativas', name:'Variables operativas', models:['01','02','03','04','13','14','15','30']},
    {id:'complementarios', name:'Modelos complementarios', models:['49']},
    {id:'resultados', name:'Estado de resultados', models:RESULT_SECTIONS.flatMap(s=>s.ids)},
    {id:'balance', name:'Estado de situación financiera', models:[...BALANCE_SECTIONS.flatMap(s=>s.ids),'47']}
  ];
  function modelCategory(model) {
    if(model.derivedExecutive)return MODEL_CATEGORIES.find(category=>category.id==='resultados');
    return MODEL_CATEGORIES.find(category => category.models.includes(model.id.split('_')[0]))
      || {id: model.group || 'otros', name: model.group || 'Otros'};
  }
  function scenarioCategories(models) {
    const categories = MODEL_CATEGORIES.filter(category => models.some(model => modelCategory(model).id === category.id));
    for (const model of models) {
      const category = modelCategory(model);
      if (!categories.some(item => item.id === category.id)) categories.push(category);
    }
    return categories;
  }
  function orderedModels(models) {
    const categories=scenarioCategories(models);
    const position=model=>{
      const category=modelCategory(model),index=category.models?.indexOf(model.id.split('_')[0])??-1;
      return categories.findIndex(c=>c.id===category.id)*100+(index>=0?index:model.id==='10_restringidos'?2.1:model.id==='10_otras'?2.2:99);
    };
    return [...models].sort((a,b)=>position(a)-position(b));
  }
  function annualMacros(app) {
    const order = ['pbi', 'inflacion', 'tc_cierre', 'tc_promedio', 'desempleo', 'tpm'];
    return (app.state.data?.macros || []).filter(m => m.id !== 'pbi_mensual' && m.frequency !== 'monthly')
      .sort((a, b) => (order.indexOf(a.id) < 0 ? 99 : order.indexOf(a.id)) - (order.indexOf(b.id) < 0 ? 99 : order.indexOf(b.id)));
  }
  function baselineModel(app, id) { return list(app.state.comparisonModels || app.state.data?.baseline).find(m => m.id === id); }
  function comparisonName(app) { return app.state.comparisonId ? app.state.comparisonName || 'Escenario guardado' : 'Antes del cambio'; }
  function yearValue(model, year = 2030) { return model?.annual?.find(row => Number(row.year) === year)?.value ?? null; }
  function selectedMacroValue(app, macro, key) {
    const change = app.state.changes?.[macro.id]?.[key];
    return finite(change) ? change : (macro.values?.[key] ?? null);
  }
  function setMacro(app, id, key, value) {
    app.state.changes ||= {};
    if (value == null) {
      if (app.state.changes[id]) delete app.state.changes[id][key];
      if (app.state.changes[id] && !Object.keys(app.state.changes[id]).length) delete app.state.changes[id];
    } else (app.state.changes[id] ||= {})[key] = value;
    app.state.scenarioId = '';
  }
  async function calculate(app) {
    const focused = document.activeElement;
    const selector = focused?.dataset.macro ? `[data-macro="${focused.dataset.macro}"][data-year="${focused.dataset.year}"]` : null;
    const start = focused?.selectionStart;
    try {
      await app.calculate(JSON.parse(JSON.stringify(app.state.changes || {})));
      if (selector) requestAnimationFrame(() => {
        const input = document.querySelector(selector);
        input?.focus({preventScroll: true});
        if (input && start != null) input.setSelectionRange(start, start);
      });
    } catch (error) { app.toast(error.message || 'No se pudo recalcular el escenario.'); }
  }
  function queueCalculation(app) { clearTimeout(calculationTimer); calculationTimer = setTimeout(() => calculate(app), 550); }
  function macroVariantsHTML(app, macro) {
    if (!YEARS.some(year => macro.values?.[String(year)] == null)) return '';
    const variants = macro.variants || [];
    return `<details class="macro-variants"><summary>Sendas de ${esc(app, macro.name)} por modelo</summary><div class="table-scroll"><table class="data-table"><thead><tr><th>Modelos</th>${YEARS.map(y => `<th>${y}</th>`).join('')}</tr></thead><tbody>${variants.map(v => `<tr><td>${esc(app, (v.modelIds || v.models || []).map(id=>app.model(id)?.name||id).join(', ') || 'Senda del modelo')}</td>${YEARS.map(y => `<td>${finite(v.values?.[y]) ? app.fmt(v.values[y], 3) : '—'}</td>`).join('')}</tr>`).join('')}</tbody></table></div></details>`;
  }
  function cellHTML(app, macro, key, label) {
    const value = selectedMacroValue(app, macro, key);
    const changed = finite(app.state.changes?.[macro.id]?.[key]);
    return `<input class="macro-cell${changed ? ' changed-cell' : ''}" inputmode="decimal" autocomplete="off" aria-label="${esc(app, macro.name + ' ' + label)}" data-macro="${esc(app, macro.id)}" data-year="${key}" value="${value == null ? '' : esc(app, value)}" placeholder="${value == null ? 'Mixto' : ''}" ${app.state.busy ? 'disabled' : ''}>`;
  }
  function monthlyMacroHTML(app) {
    return ''; // IASPE 2026–2030: el Modelo 06 y los supuestos de proyección son anuales.
    const macro = app.state.data?.macros?.find(m => m.id === 'pbi_mensual');
    if (!macro) return '';
    return `<details class="monthly-macro"><summary>PBI mensual <span class="quiet">${esc(app, macro.unit || 'Índice 2007=100')}</span></summary><p class="quiet">Préstamos de consumo utiliza esta trayectoria mensual. Si cambias el PBI anual, incorpora aquí una senda mensual compatible.</p><div class="table-scroll"><table class="data-table monthly-matrix"><thead><tr><th>Año</th>${MONTHS.map(m => `<th>${m}</th>`).join('')}</tr></thead><tbody>${YEARS.map(y => `<tr><th>${y}</th>${MONTHS.map((m, i) => `<td>${cellHTML(app, macro, `${y}-${String(i + 1).padStart(2, '0')}`, `${m} ${y}`)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="inline-paste"><textarea id="pbi-paste" class="paste-zone" rows="2" placeholder="Pegar dos columnas: mes e índice de PBI" aria-label="Pegar senda mensual de PBI"></textarea><button class="button secondary" id="apply-pbi-paste">Aplicar senda mensual</button></div></details>`;
  }
  function assumptionsHTML(app) {
    const macros=annualMacros(app),edited=Object.keys(app.state.changes||{}).length>0;
    return `<section id="scenario-assumptions" class="matrix-section scenario-assumptions"><div class="section-head"><h2>Variables macroeconómicas · Base IASPE</h2></div><div class="table-scroll"><table class="data-table matrix-table"><thead><tr><th>Variable</th>${YEARS.map(y=>`<th>${y}</th>`).join('')}</tr></thead><tbody>${macros.map(m=>`<tr><th scope="row"><span class="macro-label">${esc(app,m.name)}</span><small class="macro-unit">${esc(app,m.unit)}${m.referenceOnly?' · Referencia':''}</small></th>${YEARS.map(y=>`<td>${cellHTML(app,m,String(y),y)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="scenario-toolbar toolbar"><span class="quiet">Las modificaciones aquí son pruebas sobre el Base IASPE; los escenarios SBS se comparan exclusivamente en el Laboratorio.</span>${edited?'<button class="button ghost" id="restore-scenario">Restaurar valores Base</button>':''}</div></section>`;
  }
  function comparisonHTML(app) {
    const scenarios=app.state.scenarios||app.state.data?.scenarios||[];
    if(!app.state.labCompareEnabled||!scenarios.length)return '';
    return `<div class="scenario-comparison-toolbar"><label>Comparar con<select id="lab-comparison" aria-label="Comparar con" ${app.state.comparisonBusy?'disabled':''}><option value="">Antes del cambio</option>${scenarios.map(s=>`<option value="${esc(app,s.id)}" ${s.id===app.state.comparisonId?'selected':''}>${esc(app,s.name)}</option>`).join('')}</select></label>${app.state.comparisonBusy?'<span class="quiet" role="status">Calculando…</span>':''}</div>`;
  }
  function labTableHTML(app, model, compare) {
    const current=new Map((model.annual||[]).map(row=>[Number(row.year),row]));
    const previous=new Map((baselineModel(app,model.id)?.annual||[]).map(row=>[Number(row.year),row]));
    const years=[...new Set([...current.keys(),...(compare?previous.keys():[])])].sort((a,b)=>a-b);
    const display=value=>finite(value)?app.fmt(value,6):'—';
    return `<div class="table-scroll scenario-selected-table"><table class="data-table"><thead><tr><th>Año</th>${compare?`<th>${esc(app,comparisonName(app))}</th><th>${Object.keys(app.state.changes||{}).length?'Con cambios':'Pronóstico'}</th><th>Diferencia</th>`:'<th>Observado</th><th>Cierre estimado</th><th>Pronóstico</th>'}</tr></thead><tbody>${years.map(year=>{
      const row=current.get(year),old=previous.get(year);
      if(compare)return `<tr><td>${year}</td><td>${display(old?.value)}</td><td>${display(row?.value)}</td><td>${finite(old?.value)&&finite(row?.value)?signed(app,row.value-old.value,6):'—'}</td></tr>`;
      return `<tr><td>${year}</td><td>${display(row?.observed??(row?.status==='observed'?row.value:null))}</td><td>${display(row?.assumed??(row?.status==='assumed'?row.value:null))}</td><td>${display(row?.forecast??(row?.status==='forecast'?row.value:null))}</td></tr>`;
    }).join('')}</tbody></table></div>`;
  }
  function labHTML(app) {
    // Escenarios es la matriz de supuestos del Base IASPE; los resultados se consultan en Modelos.
    // No se presenta aquí una segunda tabla de observaciones o pronósticos.
    app.state.labCompareEnabled=false;
    return `<section class="lab-workspace scenario-chart-first">
      <header class="scenario-page-header"><div><h1>Escenarios</h1><span>Base IASPE · sensibilidad de los modelos originales</span></div></header>
      ${assumptionsHTML(app)}
    </section>`;
  }
  function bindLab(app) {
    bindScenarioControls(app);
  }
  function bindScenarioControls(app) {
    const macros = annualMacros(app);
    document.querySelectorAll('[data-macro]').forEach(input => {
      input.addEventListener('input', () => {
        const value = number(input.value);
        input.classList.toggle('invalid-cell', input.value.trim() !== '' && value == null);
        if (input.value.trim() !== '' && value == null) return;
        setMacro(app, input.dataset.macro, input.dataset.year, value);
        input.classList.toggle('changed-cell', value != null);
        queueCalculation(app);
      });
      input.addEventListener('paste', event => {
        const text = event.clipboardData?.getData('text/plain') || '';
        if (!/[\t\n]/.test(text) || input.dataset.macro === 'pbi_mensual') return;
        event.preventDefault();
        const rowStart = macros.findIndex(m => m.id === input.dataset.macro), columnStart = YEARS.indexOf(Number(input.dataset.year));
        let count = 0;
        text.trim().split(/\r?\n/).forEach((row, i) => row.split('\t').forEach((cell, j) => {
          const macro = macros[rowStart + i], year = YEARS[columnStart + j], value = number(cell);
          if (macro && year && value != null) { setMacro(app, macro.id, String(year), value); count++; }
        }));
        if (count) { clearTimeout(calculationTimer); calculate(app); app.toast(`${count} supuestos incorporados.`); }
      });
    });
    const publishMacroBase = async(reset=false) => {
      clearTimeout(calculationTimer);
      if (document.querySelector('.invalid-cell')) { app.toast('Corrige primero las celdas macroeconómicas no válidas.'); return; }
      const changes=JSON.parse(JSON.stringify(app.state.changes||{}));
      if (!reset && !Object.keys(changes).length) { app.toast('Modifica primero los supuestos macroeconómicos.'); return; }
      if (reset && !window.confirm('¿Restaurar la base original del ZIP? Se conservarán tus escenarios alternativos guardados.')) return;
      // Cancelar cualquier respuesta anterior de cálculo al abrir la vista previa.
      app.state.calcToken=(app.state.calcToken||0)+1;
      app.state.busy=true;
      app.render();
      try {
        if (!reset) {
          const preview=await app.api('/api/base/preview',{changes});
          const report=preview.report||{};
          const notice=report.partial
            ? `El recálculo es PARCIAL. ${report.issues?.length||0} componentes requieren insumos o revisión y ${report.warnings?.length||0} advertencias están activas. Se observan cambios en ${report.changedModels?.length||0} modelos principales (no todos completamente validados); los Excel de origen no se modifican. ¿Aplicar esta base de trabajo con esas limitaciones?`
            : `Se recalcularán ${report.changedModels?.length||0} modelos principales y ${report.changedComponents||0} componentes. Los archivos originales no se modifican. ¿Aplicar como nueva base de trabajo?`;
          if (!window.confirm(notice)) { app.state.busy=false;app.render();return; }
        }
        // Invalidar una respuesta asíncrona de escenarios que pudiera estar en vuelo.
        app.state.calcToken=(app.state.calcToken||0)+1;
        const result=await app.api(reset?'/api/base/reset':'/api/base/apply',reset?{}:{changes});
        app.state.data=result;
        app.state.scenarios=result.scenarios||app.state.scenarios;
        app.state.changes={};app.state.scenarioId='';app.state.scenarioName='';
        comparisonRequest++;app.state.comparisonId='';app.state.comparisonName='';app.state.comparisonModels=null;app.state.comparisonBusy=false;
        app.state.busy=false;
        app.render();
        app.toast(reset?'Base original restaurada.':result.macroBasePublication?.partial?'Base aplicada con recálculo parcial; revisa las advertencias.':'Base macroeconómica recalculada y aplicada.');
      } catch(error) {app.state.busy=false;app.render();app.toast(error.message||'No fue posible aplicar la base macroeconómica.');}
    };
    document.getElementById('recalculate-macro-base')?.addEventListener('click',()=>publishMacroBase(false));
    document.getElementById('restore-macro-base')?.addEventListener('click',()=>publishMacroBase(true));
    document.getElementById('scenario-name')?.addEventListener('input', event => app.state.scenarioName = event.target.value);
    const save = async duplicate => {
      const input = document.getElementById('scenario-name');
      let name = input?.value.trim();
      if (!name) { input?.focus(); app.toast('Escribe un nombre para guardar el escenario.'); return; }
      if (duplicate) name += ' (copia)';
      try {
        const payload = await app.api('/api/scenarios', {name, changes: app.state.changes || {}, ...(!duplicate && app.state.scenarioId ? {id: app.state.scenarioId} : {})});
        app.state.scenarios = payload.scenarios || [];
        app.state.scenarioId = payload.scenario?.id || '';
        app.state.scenarioName = payload.scenario?.name || name;
        if (app.state.comparisonId === app.state.scenarioId) {
          comparisonRequest++; app.state.comparisonId = ''; app.state.comparisonModels = null; app.state.comparisonName = ''; app.state.comparisonBusy = false;
        }
        app.render(); app.toast(duplicate ? 'Escenario duplicado.' : 'Escenario guardado.');
      } catch (error) { app.toast(error.message); }
    };
    document.getElementById('save-scenario')?.addEventListener('click', () => save(false));
    document.getElementById('duplicate-scenario')?.addEventListener('click', () => save(true));
    document.getElementById('restore-scenario')?.addEventListener('click', () => {
      clearTimeout(calculationTimer); app.state.scenarioId = ''; app.state.scenarioName = '';
      comparisonRequest++; app.state.comparisonId = ''; app.state.comparisonModels = null; app.state.comparisonName = ''; app.state.comparisonBusy = false;
      app.state.labCompareEnabled = false;
      app.state.changes = {}; calculate(app);
    });
    document.getElementById('lab-comparison')?.addEventListener('change', async event => {
      const id = event.target.value;
      const token = ++comparisonRequest;
      if (!id) {
        app.state.comparisonId = ''; app.state.comparisonName = ''; app.state.comparisonModels = null; app.state.comparisonBusy = false; app.render(); return;
      }
      const scenario = (app.state.scenarios || app.state.data?.scenarios || []).find(s => s.id === id);
      if (!scenario) return;
      app.state.comparisonBusy = true; app.render();
      try {
        const result = await app.api('/api/calculate', {changes: scenario.changes || {}});
        if (token !== comparisonRequest) return;
        app.state.comparisonModels = result.models || result.data?.models;
        app.state.comparisonId = scenario.id; app.state.comparisonName = scenario.name;
      } catch (error) { if (token === comparisonRequest) app.toast(error.message || 'No se pudo calcular el comparador.'); }
      finally { if (token === comparisonRequest) { app.state.comparisonBusy = false; app.render(); } }
    });
    document.getElementById('apply-pbi-paste')?.addEventListener('click', () => {
      const text = document.getElementById('pbi-paste').value;
      let count = 0;
      text.trim().split(/\r?\n/).forEach(line => {
        const cells = line.split(/\t|;/), key = period(cells[0]), value = number(cells[1]);
        if (key?.length === 7 && Number(key.slice(0, 4)) >= 2026 && Number(key.slice(0, 4)) <= 2030 && value != null) { setMacro(app, 'pbi_mensual', key, value); count++; }
      });
      if (!count) { app.toast('Pega meses y sus índices de PBI en dos columnas.'); return; }
      clearTimeout(calculationTimer); calculate(app); app.toast(`${count} índices mensuales incorporados.`);
    });
  }

  function updateModels(app) {
    const models = allModels(app).filter(model => model.canUpdate !== false && !['07', '10'].includes(model.id) &&
      ((model.monthly || []).some(p => p.status !== 'forecast') || (model.annual || []).some(p => p.status !== 'forecast')));
    const macros = (app.state.data?.macros || []).filter(m => m.frequency !== 'monthly' && m.id !== 'pbi_mensual').map(macro => {
      const persisted = app.state.data?.observations?.[macro.id] || {};
      const years = [...new Set([...Object.keys(macro.values || {}), ...Object.keys(persisted)])]
        .filter(key => /^\d{4}$/.test(key) && Number(key) <= 2030).sort();
      const annual = years.map(key => {
        const observed = finite(persisted[key]);
        const value = observed ? persisted[key] : macro.values[key];
        return {year: Number(key), value, status: observed != null ? 'observed' : Number(key) < 2026 ? 'observed' : 'assumed'};
      }).filter(row => finite(row.value));
      return {id: macro.id, name: macro.name, unit: macro.unit || '%', annual, monthly: [],
        frequency: 'annual', isMacro: true, group: 'Macroeconomía', canUpdate: true,
        closingRule: 'La observación anual se incorpora en los modelos que utilizan esta variable. Cuando los inputs difieren, se omite el valor común hasta introducir una observación.'};
    });
    return models.concat(macros);
  }
  function updateModel(app, id) { return app.model(id) || updateModels(app).find(model => model.id === id); }
  function updateRows(model, expanded = false) {
    const monthly = model.monthly?.filter(p => Number(String(p.date || '').slice(0, 4)) <= 2030 && p.status !== 'forecast') || [];
    return (monthly.length ? monthly : model.annual?.filter(p => Number(p.year) <= 2030 && (p.status !== 'forecast' || p.external)) || [])
      .map(p => ({...p, period: monthly.length ? String(p.date).slice(0, 7) : String(p.year)})).slice(expanded ? 0 : -8);
  }
  function pendingEntry(app, id, key) { return (app.state.entries || []).find(e => e.id === id && e.period === key); }
  function isMonthlyInput(model) {
    return !model?.isMacro && (model?.monthly || []).some(row=>row.status!=='forecast');
  }
  function validEntry(app, entry) {
    if (!entry?.id || !validPeriod(entry.period) || !finite(entry.value)) return false;
    const model=updateModel(app,entry.id);
    if (!model)return false;
    if (isMonthlyInput(model) !== (entry.period.length===7)) return false;
    const current=new Date(),today=`${current.getFullYear()}-${String(current.getMonth()+1).padStart(2,'0')}`;
    return entry.period.length===7 ? entry.period<=today : Number(entry.period)<=current.getFullYear();
  }
  function stage(app, entry) {
    if (!validEntry(app,entry)) return false;
    app.state.entries ||= [];
    app.state.entries=app.state.entries.filter(e=>e.id!==entry.id||e.period!==entry.period);
    app.state.entries.push(entry);
    app.state.manualReview=null;
    return true;
  }
  function stageMany(app, entries) {
    if (!entries.length) { app.toast('No se encontraron filas para importar.');return false; }
    const normalized=[],keys=new Set(),issues=[];
    entries.forEach((entry,index)=>{
      const candidate={id:String(entry.id||app.state.updateId),period:period(entry.period),value:finite(entry.value)?entry.value:number(entry.value)};
      const key=candidate.id+'|'+candidate.period;
      if(!validEntry(app,candidate))issues.push(index+1);
      else if(keys.has(key))issues.push(index+1);
      else {normalized.push(candidate);keys.add(key);}
    });
    if(issues.length){
      app.toast(`Carga detenida: revisa ${issues.length===1?'la fila':'las filas'} ${issues.slice(0,7).join(', ')}${issues.length>7?'…':''}. No se añadió ningún dato.`);
      return false;
    }
    normalized.forEach(entry=>stage(app,entry));
    app.render();app.toast(`${normalized.length} ${normalized.length===1?'fila preparada':'filas preparadas'}. Valida antes de guardar.`);
    return true;
  }
  function pendingHTML(app) {
    const entries=app.state.entries||[];
    if(!entries.length)return '';
    const lines=[...entries].sort((a,b)=>a.id.localeCompare(b.id)||a.period.localeCompare(b.period));
    const review=app.state.manualReview;
    const reviewed=new Map((review?.preview||[]).map(r=>[r.id+'|'+r.period,r]));
    const noChanges=!!review && (review.preview||[]).every(r=>r.difference===0 || (r.previous!==null&&r.previous===r.new));
    const rows=lines.map(entry=>{
      const prior=reviewed.get(entry.id+'|'+entry.period);
      const priorValue=prior?.previous;
      const diff=prior?.difference;
      const original=review?`<td class="num">${finite(priorValue)?app.fmt(priorValue,4):'Nuevo'}</td>`:'';
      const variation=review?`<td class="num ${finite(diff)&&diff!==0?'update-delta':''}">${finite(diff)?signed(app,diff,4):'—'}</td>`:'';
      return `<tr><td>${esc(app,updateModel(app,entry.id)?.name||entry.id)}</td><td>${esc(app,entry.period)}</td>${original}<td class="num">${app.fmt(entry.value,4)}</td>${variation}<td><button type="button" class="update-delete" data-remove-id="${esc(app,entry.id)}" data-remove-period="${esc(app,entry.period)}">Quitar</button></td></tr>`;
    }).join('');
    const message=review?`<p class="update-validation-ok" role="status">${noChanges?'La información coincide con los datos existentes. No hay cambios por aplicar.':`Validación correcta. Se guardarán ${lines.length} ${lines.length===1?'observación':'observaciones'}; después debes recalcular los modelos.`}</p>`:'';
    return `<section class="update-pending" id="update-pending" aria-label="Revisión de cambios">
      <div class="update-pending-heading"><div><h2>Revisar y aplicar <span>${lines.length}</span></h2><p>Los valores no modifican el IASPE hasta que confirmes.</p></div></div>
      <div class="table-scroll update-pending-wrap"><table class="data-table update-pending-table"><thead><tr><th>Variable</th><th>Período</th>${review?'<th>Anterior</th>':''}<th>Nuevo valor</th>${review?'<th>Diferencia</th>':''}<th></th></tr></thead><tbody>${rows}</tbody></table></div>
      ${message}
      <div class="update-savebar"><span>${review?'Vista previa comprobada':'Pendiente de validación'}</span><div><button type="button" class="button ghost" id="clear-update">Descartar</button>${review?(noChanges?'':'<button type="button" class="button" id="confirm-update">Confirmar y guardar</button>'):'<button type="button" class="button" id="preview-update">Validar cambios</button>'}</div></div>
    </section>`;
  }
  const institutionCategories=['Bancos','Empresas financieras','Cajas rurales'];
  function institutionAt(item,period){
    const selected=String(period||'9999-12').slice(0,7);
    const month=item.historical_only&&item.last&&item.last<selected?item.last:selected;
    const history=(item.category_history||[]).find(entry=>(!entry.from||entry.from<=month)&&(!entry.to||entry.to>=month));
    return {...item,category:history?.category||item.category||'Bancos',name:history?.name||item.name||item.nombre||item.id};
  }
  function institutionGroups(items,period,entryHTML){
    const groups=new Map(institutionCategories.map(category=>[category,[]]));
    for(const item of items){const entry=institutionAt(item,period);if(!groups.has(entry.category))groups.set(entry.category,[]);groups.get(entry.category).push(entry);}
    const escape=window.IASPEApp?.escape||((value)=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
    return [...groups].filter(([,entries])=>entries.length).map(([category,entries])=>`<div data-institution-group role="group" aria-label="${escape(category)}"><strong class="quiet">${escape(category)}</strong>${entries.map(entry=>{
      const terms=[entry.name,entry.nombre,...(entry.aliases||[]),...(entry.category_history||[]).map(item=>item.name)].filter(Boolean).join(' ');
      return entryHTML(entry).replace(/<label\b/,`<label data-institution-search="${escape(terms)}"`);
    }).join('')}</div>`).join('');
  }
  function filterInstitutions(container,selector,query){
    if(!container)return;
    const term=String(query||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
    container.querySelectorAll(selector).forEach(row=>{row.hidden=!`${row.textContent} ${row.getAttribute('data-institution-search')||''}`.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(term);});
    container.querySelectorAll('[data-institution-group]').forEach(group=>{group.hidden=![...group.querySelectorAll(selector)].some(row=>!row.hidden);});
  }
  window.IASPEInstitutionGroups={at:institutionAt,html:institutionGroups,filter:filterInstitutions};

  const sourceFamilies={eeff:['estados_financieros'],ratios:['ratios'],personal:['personal_banca','personal_financieras','personal_rurales'],cartera:['cartera'],oficinas:['oficinas'],participacion:['cartera','tarjetas','estados_financieros']};
  const sourceFamilyLabels={eeff:'EEFF',ratios:'indicadores',personal:'personal',oficinas:'oficinas',participacion:'participación'};
  let sourceSnapshot=null,sourceRequest=null,sourceTimer=null,sourceApp=null,sourceStarting=false;
  function monitorRevision(snapshot){
    return JSON.stringify([snapshot?.generation,snapshot?.modelRevision,snapshot?.pending?.observations,snapshot?.running,snapshot?.operation?.running,Object.entries(snapshot?.sources||{}).map(([id,item])=>[id,item.status,item.checkedAt])]);
  }
  const sourceBusy=()=>sourceStarting||!!(sourceSnapshot?.running||sourceSnapshot?.operation?.running||sourceSnapshot?.canResume);
  function familyResult(family){
    const entries=(sourceFamilies[family]||[]).map(id=>sourceSnapshot?.sources?.[id]).filter(Boolean);
    if(sourceSnapshot?.running&&(sourceSnapshot.selected||[]).some(id=>(sourceFamilies[family]||[]).includes(id)))return 'Actualizando…';
    if(!entries.length)return 'Sin actualización registrada';
    const failed=entries.filter(entry=>entry.status==='error');
    if(failed.length)return 'Última actualización con incidencias';
    if(entries.some(entry=>entry.status==='parcial'))return 'Última actualización parcial';
    if(entries.some(entry=>entry.status==='correcto'))return 'Última actualización validada';
    return 'Sin actualización validada';
  }
  function familyCaption(family,period,checkedAt,lastCheck={}){
    if(family==='oficinas'){
      lastCheck=lastCheck||{};
      const result=sourceSnapshot?.sources?.oficinas;
      const fallbackLocal=(lastCheck.verification||lastCheck.status)==='local_only';
      const newerFallback=fallbackLocal&&(!result?.checkedAt||(Date.parse(checkedAt)||0)>(Date.parse(result.checkedAt)||0));
      const local=newerFallback||(result?.download?.verification||result?.download?.status)==='local_only';
      const checked=newerFallback?checkedAt:result?.checkedAt||checkedAt;
      const date=checked?new Date(checked):null;
      const query=date&&!Number.isNaN(date.getTime())?date.toLocaleString('es-PE',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}):'Sin consulta registrada';
      const busy=sourceSnapshot?.running&&(sourceSnapshot.selected||[]).includes('oficinas');
      const localMessage=newerFallback?lastCheck.message:result?.download?.detail||result?.download?.message;
      const status=busy?'Actualizando…':local?(localMessage||'Reprocesado local; no se consultó la SBS'):result?.status==='error'?'Error en la última consulta'+(period?'; se conserva la base válida':''):result?.status==='parcial'?(result.changed===false?'Sin cambios; histórico con observaciones':'Histórico con observaciones'):result?.status==='correcto'?(result.changed===false?'Sin cambios':'Actualización validada'):'Sin actualización registrada';
      return `Último dato: ${period||'—'} · ${local?'Revisión local':'Consulta'}: ${query} · ${status}`;
    }
    const pending=sourceSnapshot?.pending?.pending?' · Pendiente de recalcular':'';
    return `Último dato: ${period||'—'} · ${familyResult(family)}${pending}`;
  }
  function sourceControl(family,period,button=true,checkedAt='',lastCheck={}){
    const escape=window.IASPEApp?.escape||((value)=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
    return `<div class="market-information-actions" data-source-family="${family}" data-source-period="${escape(period||'')}" data-source-checked="${escape(checkedAt||'')}" data-source-lastcheck="${escape(JSON.stringify(lastCheck||{}))}"><small class="quiet" data-source-result role="status">${escape(familyCaption(family,period,checkedAt,lastCheck))}</small>${button?`<button type="button" class="text-link" data-source-update="${family}" ${sourceBusy()?'disabled':''}>Actualizar ${sourceFamilyLabels[family]||'datos'}</button>`:''}</div>`;
  }
  function paintSourceControls(){
    document.querySelectorAll('[data-recalculate-models],#preview-update,#confirm-update').forEach(button=>{button.disabled=sourceBusy();});
    document.querySelectorAll('[data-source-family]').forEach(node=>{
      let lastCheck={};try{lastCheck=JSON.parse(node.dataset.sourceLastcheck||'{}');}catch(_){/* Un atributo incompleto no altera el último resultado central. */}
      const text=node.querySelector('[data-source-result]');if(text)text.textContent=familyCaption(node.dataset.sourceFamily,node.dataset.sourcePeriod,node.dataset.sourceChecked,lastCheck);
      const button=node.querySelector('[data-source-update]');if(button){button.disabled=sourceBusy();button.title=sourceSnapshot?.canResume?'Retoma o detén la actualización pendiente en Datos observados.':sourceBusy()?'Hay una operación de datos en curso.':'';}
    });
  }
  function acceptSourceStatus(data,app){
    const previous=sourceSnapshot;
    sourceSnapshot=data;sourceApp=app||sourceApp;
    queueModelRefresh(previous||{modelRevision:sourceApp?.state.data?.lastRecalculation?.generatedAt},data);
    if(sourceApp){sourceApp.state.sbsUpdate=data;if(data.pending&&sourceApp.state.data)sourceApp.state.data.sourceUpdates=data.pending;}
    const changed=previous?Object.keys(data.sources||{}).filter(id=>Number(data.sources[id].generation||0)!==Number(previous.sources?.[id]?.generation||0)):[];
    if(previous&&Number(data.generation||0)!==Number(previous.generation||0)&&!changed.length&&!data.sources)changed.push(...Object.values(sourceFamilies).flat());
    const modules=[['eeff','IASPEBenchmarkEEFF'],['ratios','IASPERatiosSBS'],['personal','IASPEPersonalSBS'],['cartera','IASPECarteraConsumo'],['oficinas','IASPEOficinasSBS']];
    for(const [family,module] of modules)if((sourceFamilies[family]||[]).some(id=>changed.includes(id)))window[module]?.invalidate?.();
    if(changed.length||previous&&monitorRevision(previous)!==monitorRevision(data))window.IASPEMonitorActualizacion?.invalidate?.();
    if(changed.length)window.dispatchEvent(new CustomEvent('iaspe:sources-updated',{detail:{sources:changed,generation:data.generation}}));
    paintSourceControls();
    return changed;
  }
  async function refreshSourceStatus(app){
    sourceApp=app||sourceApp;if(!sourceApp)return sourceSnapshot;
    if(sourceRequest)return sourceRequest;
    sourceRequest=(async()=>{
      const data=await sourceApp.api('/api/sbs/status');
      acceptSourceStatus(data,sourceApp);
      return data;
    })();
    try{return await sourceRequest;}finally{sourceRequest=null;}
  }
  let modelRefreshToken=0,pendingModelRevision=null;
  function queueModelRefresh(before,data){
    const completed=before?.operation?.running&&before.operation.kind==='recalculation'&&!(data.operation?.running&&data.operation.kind==='recalculation');
    if(completed||(before&&data.modelRevision&&data.modelRevision!==before.modelRevision))pendingModelRevision=data.modelRevision||'completed';
  }
  async function refreshBenchmarkBase(app,before,data){
    queueModelRefresh(before,data);
    if(!pendingModelRevision||!(location.hash.startsWith('#benchmark/')||location.hash.startsWith('#monitor'))||location.hash.startsWith('#benchmark/oficinas')||app.state.busy||Object.keys(app.state.changes||{}).length)return false;
    const route=location.hash,token=++modelRefreshToken;
    const fresh=await app.api('/api/state');
    if(token!==modelRefreshToken||location.hash!==route||app.state.busy||Object.keys(app.state.changes||{}).length)return false;
    app.state.data=fresh;pendingModelRevision=null;
    app.render();return true;
  }

  function scheduleSources(app){
    sourceApp=app||sourceApp;clearTimeout(sourceTimer);
    if(!sourceSnapshot?.running&&!sourceSnapshot?.operation?.running&&!location.hash.startsWith('#benchmark/')&&!location.hash.startsWith('#monitor'))return;
    sourceTimer=setTimeout(async()=>{
      const previous=sourceSnapshot;
      try{
        const data=await refreshSourceStatus(sourceApp);
        const baseRefreshed=await refreshBenchmarkBase(sourceApp,previous,data);
        const monitorChanged=location.hash.startsWith('#monitor')&&previous&&monitorRevision(previous)!==monitorRevision(data);
        if(!baseRefreshed&&previous&&(Number(previous.generation||0)!==Number(data.generation||0)&&location.hash.startsWith('#benchmark/')||monitorChanged))sourceApp.render();
      }catch(_){/* La consulta fallida no invalida la información visible. */}
      scheduleSources(sourceApp);
    },sourceSnapshot?.running||sourceSnapshot?.operation?.running?1400:10000);
  }
  async function startSourceFamily(app,family){
    if(sourceStarting)return;
    sourceStarting=true;paintSourceControls();
    try{
      await refreshSourceStatus(app);
      if(sourceSnapshot?.running||sourceSnapshot?.operation?.running||sourceSnapshot?.canResume)throw Error('Hay una operación pendiente o en curso. Revísala en Datos observados.');
      const data=await app.api('/api/sbs/start',{sources:sourceFamilies[family]});
      acceptSourceStatus(data,app);scheduleSources(app);
    }catch(error){app.toast(error.message||'No se pudo iniciar la actualización.');}
    finally{sourceStarting=false;paintSourceControls();}
  }
  function bindSourceControls(app){
    document.querySelectorAll('[data-source-update]').forEach(button=>button.onclick=()=>startSourceFamily(app,button.dataset.sourceUpdate));
    paintSourceControls();scheduleSources(app);
  }
  window.IASPESourceUpdates={refresh:refreshSourceStatus,control:sourceControl,bind:bindSourceControls,accept:acceptSourceStatus,start:startSourceFamily};

  let sbsTimer=null;
  const sbsGroups = [
    {id:'eeff',title:'Estados financieros SBS',ids:['estados_financieros','ahorro_moneda'],details:true},
    {id:'cartera',title:'Crédito y tarjetas',ids:['tarjetas','morosidad','cartera']},
    {id:'mercado',title:'Indicadores y tasas',ids:['ratios','tasas_mercado']},
    {id:'personal',title:'Personal',ids:['personal_banca','personal_financieras','personal_rurales']},
    {id:'oficinas',title:'Cobertura de oficinas',ids:['oficinas']}
  ];
  const sbsAccountGroupBase = [
    {id:'balance',title:'Situación financiera',items:[
      {id:'ahorro',label:'Depósitos de ahorro',parts:[['08_mn','Moneda nacional (MN)'],['08_me','Moneda extranjera (ME)']]},
      {id:'plazo_cts',label:'Depósitos a plazo y CTS',parts:[['09_plazo','Depósitos a plazo'],['09_cts','Depósitos CTS']]},
      {id:'obligaciones',label:'Obligaciones con el público',parts:[['10_restringidos','Depósitos restringidos'],['10_otras','Otras obligaciones']]},
      {id:'disponible',label:'Disponible',parts:[['17_caja','Caja'],['17_bancos','Bancos y corresponsales'],['17_canje','Canje'],['17_otros','Otros disponibles']]},
      {id:'inversiones',label:'Inversiones',parts:[['21_venta','Disponibles para la venta'],['21_asociadas','Subsidiarias y asociadas']]},
      {id:'interbancarios',label:'Fondos interbancarios',parts:[['22_interbancarios','Fondos interbancarios']]}
    ]},
    {id:'results',title:'Estado de resultados',items:[
      {id:'gastos_intereses',label:'Gastos por intereses',parts:[['12_obligaciones','Obligaciones con el público'],['12_entidades','Depósitos de entidades financieras'],['12_adeudos','Adeudos'],['12_otras','Otros gastos por intereses']]},
      {id:'ingresos_intereses',label:'Ingresos por intereses',parts:[['16_creditos','Créditos'],['16_inversiones','Inversiones'],['16_disponible','Disponible'],['16_interbancarios','Fondos interbancarios']]},
      {id:'servicios',label:'Servicios financieros',parts:[['18_diversos','Ingresos diversos'],['18_otros_ing','Otros ingresos'],['18_gastos_div','Gastos diversos'],['18_otros_gastos','Otros gastos'],['18_fsd','Primas FSD']]},
      {id:'administracion',label:'Gastos administrativos',parts:[['19_personal','Personal'],['19_directorio','Directorio'],['19_terceros','Servicios de terceros'],['19_impuestos','Impuestos y contribuciones']]},
      {id:'operaciones',label:'Operaciones financieras',parts:[['20_tc','Diferencia de cambio'],['20_derivados','Derivados'],['20_inversiones','Inversiones'],['20_consorcios','Participación en consorcios'],['20_otros','Otros resultados de operaciones financieras']]},
      {id:'provisiones',label:'Provisiones para créditos',parts:[['25','Provisiones para créditos']]},
      {id:'depreciacion',label:'Depreciación y amortización',parts:[['26','Depreciación y amortización']]},
      {id:'margen',label:'Margen financiero',parts:[['23','Margen financiero']]},
      {id:'otros_resultados',label:'Otros ingresos y gastos',parts:[['24','Otros ingresos y gastos']]},
      {id:'otras_provisiones',label:'Otras provisiones',parts:[['27','Otras provisiones']]},
      {id:'impuesto_renta',label:'Impuesto a la renta',parts:[['28','Impuesto a la renta']]},
      {id:'resultado_neto',label:'Resultado neto',parts:[['29','Resultado neto']]}
    ]},
    {id:'contingentes',title:'Operaciones contingentes',items:[
      {id:'lineas_no_utilizadas',label:'Líneas de crédito no utilizadas',parts:[['30','Líneas disponibles y créditos no desembolsados']]}
    ]},
    {id:'cxc',title:'Otras cuentas del balance',items:[
      {id:'cuentas_cobrar',label:'Cuentas por cobrar netas',parts:[['31','Cuentas por cobrar netas']]},
      {id:'rendimientos_cobrar',label:'Rendimientos por cobrar',parts:[['32','Rendimientos por cobrar']]}
    ]}
  ];
  // La cuenta es seleccionable según su fuente real; no ofrecer cálculos
  // derivados como si fueran series SBS descargables.
  const _accountItems=Object.fromEntries(sbsAccountGroupBase.flatMap(g=>g.items.map(i=>[i.id,i])));
  const sbsAccountGroups=[
    {id:'pasivo',title:'Pasivo · Depósitos y obligaciones',keys:['ahorro','plazo_cts','obligaciones']},
    {id:'activo',title:'Activo · Disponible y cartera',keys:['disponible','inversiones','interbancarios','cuentas_cobrar','rendimientos_cobrar']},
    {id:'ingresos',title:'Resultados · Ingresos y margen',keys:['ingresos_intereses','servicios','margen','operaciones','otros_resultados']},
    {id:'gastos',title:'Resultados · Gastos y provisiones',keys:['gastos_intereses','administracion','provisiones','depreciacion','otras_provisiones','impuesto_renta','resultado_neto']},
    {id:'operaciones',title:'Operaciones contingentes',keys:['lineas_no_utilizadas']}
  ].map(g=>({id:g.id,title:g.title,items:g.keys.map(k=>_accountItems[k]).filter(Boolean)}));
  if(sbsAccountGroups.flatMap(g=>g.items).length!==Object.keys(_accountItems).length)
    throw new Error('El catálogo de cuentas SBS quedó incompleto.');
  const sbsSourceSeries={
    tarjetas:[['01','Tarjetas de la banca múltiple'],['02','Tarjetas de consumo'],['04','Tarjetas de Banco Falabella']],
    cartera:[['05','Colocaciones brutas - consumo revolvente'],['06','Colocaciones brutas - consumo no revolvente']],
    tasas_mercado:[['03','Compras con tarjetas'],['13','Tasa de tarjetas'],['14','Tasa de consumo'],['15','Tasa de depósitos']]
  };
  const sbsRatioCategories=['Liquidez','Calidad de activos','Eficiencia y gestión','Solvencia','Rentabilidad','Otros'];
  const allSbsAccounts=sbsAccountGroups.flatMap(group=>group.items.map(item=>item.id));
  const accountParts=Object.fromEntries(sbsAccountGroups.flatMap(group=>group.items.map(item=>[item.id,item.parts.map(part=>part[0])])));
  const allSbsComponents=[...new Set([...sbsAccountGroups.flatMap(group=>group.items.flatMap(item=>item.parts.map(part=>part[0]))),...Object.values(sbsSourceSeries).flatMap(items=>items.map(item=>item[0]))])];
  function accountsForComponents(components){
    const included=new Set(components);
    return allSbsAccounts.filter(id=>accountParts[id].some(code=>included.has(code)));
  }
  function sourceUsesComponents(id){return sbsSourceSeries[id]||[];}
  const sbsBanks = [
    'Banco de Crédito del Perú','Interbank','BBVA Perú','Scotiabank Perú',
    'Banco Falabella Perú','Santander Consumer Bank','Banco Pichincha','BanBif',
    'Banco GNB','InFinance XP','Banco Ripley','Banco de Comercio',
    'Compartamos Banco','Alfin Banco','Banco Efectiva','Mibanco',
    'Caja Cencosud Scotia'
  ];
  const sbsBankIds=sbsBanks.map((_, index)=>index===16?'crac_18':String(index+1).padStart(2,'0'));
  function sbsBankNames(ids){return ids.map(id=>sbsBanks[sbsBankIds.indexOf(id)]).filter(Boolean);}
  function updateWindow(app,title,summary,kind='sources'){
    document.getElementById('iaspe-update-dialog')?.remove();
    const modal=document.createElement('div');
    modal.id='iaspe-update-dialog';modal.className='iaspe-update-modal';
    const summaryList=kind==='models'
      ?(summary.changedModels||[]).map(m=>`<li><strong>${esc(app,m.id)} · ${esc(app,m.name)}</strong> — ${m.years.length} año(s) modificado(s)${m.verified?'':' · Revisión pendiente'}</li>`)
      :(summary.success||[]).map(x=>`<li>${esc(app,x)}</li>`);
    const failures=(kind==='models'?[...(summary.issues||[]).map(x=>`${x.id}: ${(x.messages||[]).join('; ')}`),...(summary.audit?.findings||[]).filter(f=>f.severity==='error').map(f=>`${f.id}: ${f.message}`)]:(summary.failed||[]).map(x=>x.name+': '+x.message));
    const warnings=(summary.warnings||[]);
    modal.innerHTML=`<div class="iaspe-update-card" role="dialog" aria-modal="true" aria-label="${esc(app,title)}">
      <div class="iaspe-update-title"><h2>${esc(app,title)}</h2><button type="button" class="button secondary" data-close-update>Cerrar</button></div>
      <p>${kind==='models'?`${summary.changedModels?.length||0} modelos cambiaron sus valores · ${summary.modelsCount||32} modelos principales revisados.`:`${summary.updated||0} observaciones nuevas o modificadas.`}</p>
      ${kind==='sources'?'<p>Las proyecciones se mantienen sin cambios hasta seleccionar Recalcular modelos.</p>':''}
      ${kind==='models'&&summary.audit?`<p>Auditoría de cálculos: <strong>${summary.audit.checks||0} controles</strong> · ${summary.audit.errors||0} errores · ${summary.audit.warnings||0} advertencias · ${summary.audit.componentCount||0} componentes verificados.</p>`:''}
      ${summaryList.length?`<h3>${kind==='sources'?'Fuentes procesadas':'Modelos con cambios'}</h3><ul>${summaryList.slice(0,70).join('')}</ul>`:'<p>No se identificaron cambios nuevos.</p>'}
      ${kind==='sources'&&summary.models?.length?`<h3>Modelos con observaciones nuevas</h3><p>${esc(app,summary.models.join(', '))}</p>`:''}
      ${kind==='sources'&&summary.details?.length?`<details><summary>Ver los períodos actualizados (${summary.updated})</summary><ul>${summary.details.slice(0,90).map(x=>`<li>Modelo ${esc(app,x.model)} · ${esc(app,x.period)}${x.current?.sourceMonth?' · Fuente: '+esc(app,x.current.sourceMonth):''}${x.current?.method?' · '+esc(app,x.current.method):''}</li>`).join('')}</ul>${summary.truncated?'<p>El detalle se ha limitado a los primeros períodos.</p>':''}</details>`:''}
      ${failures.length?`<h3>Incidencias pendientes</h3><ul>${failures.slice(0,40).map(x=>`<li>${esc(app,x)}</li>`).join('')}</ul>`:''}
      ${warnings.length?`<h3>Advertencias de cálculo</h3><ul>${warnings.slice(0,25).map(x=>`<li>${esc(app,x)}</li>`).join('')}</ul>`:''}
      <div class="iaspe-update-actions"><button type="button" class="button" data-close-update>Entendido</button></div></div>`;
    document.body.appendChild(modal);
    const dismiss=()=>modal.remove();
    modal.querySelectorAll('[data-close-update]').forEach(b=>b.addEventListener('click',dismiss));
    modal.addEventListener('click',e=>{if(e.target===modal)dismiss()});
    modal.querySelector('button[data-close-update]')?.focus();
  }
  function sbsHTML(app,data){
    const tasks=data?.tasks||[];
    const allowed=tasks.map(task=>task.id);
    if(!Array.isArray(app.state.sbsSources))app.state.sbsSources=allowed.filter(id=>id!=='personal_financieras');
    if(!Array.isArray(app.state.sbsComponents))app.state.sbsComponents=[...(data?.components||allSbsComponents)];
    if(!Array.isArray(app.state.sbsRatios))app.state.sbsRatios=[...(data?.ratioCategories||sbsRatioCategories)];
    if(!Array.isArray(app.state.sbsAccounts))app.state.sbsAccounts=accountsForComponents(app.state.sbsComponents);
    if(!Array.isArray(app.state.sbsBanks))app.state.sbsBanks=['05'];
    app.state.sbsBanks=app.state.sbsBanks.filter(id=>sbsBankIds.includes(id));
    const chosen=app.state.sbsSources.filter(id=>allowed.includes(id));
    const selectedAccounts=new Set(app.state.sbsAccounts);
    const selectedComponents=new Set(app.state.sbsComponents);
    const locked=!!(data?.running||data?.operation?.running||data?.canResume);
    const lastSelection=new Set(data?.selected||[]);
    const considered=tasks.filter(task=>lastSelection.has(task.id));
    const done=considered.filter(task=>task.status==='correcto'||task.status==='error').length;
    const passed=considered.filter(task=>task.status==='correcto').length;
    const active=tasks.find(task=>task.status==='en_curso');
    const anyEeff=chosen.includes('estados_financieros')||chosen.includes('ahorro_moneda');
    const visibleTotal=tasks.length-(allowed.includes('ahorro_moneda')?1:0);
    const visibleSelected=chosen.length-(chosen.includes('ahorro_moneda')&&chosen.includes('estados_financieros')?1:0);
    const manualCount=Number(app.state.data?.sourceUpdates?.manualRecords||0);
    const caption=data?.stopping?'Deteniendo la actualización…':
      data?.running?`${done} de ${considered.length} procesos terminados · ${active?.label||'Preparando datos'}`:
      data?.result==='detenido'||data?.result==='interrumpido'?'Actualización detenida · puedes reanudar':
      data?.result==='completo'?`Última ejecución · ${passed} de ${considered.length} procesos validados`:
      data?.result==='parcial'?`Última ejecución · ${passed} de ${considered.length} validados; revisa los errores`:
      data?.result==='error'?'La última actualización no pudo finalizar':
      data?.started?'Última ejecución disponible':'Selecciona la información que deseas actualizar';
    const status={correcto:'Validado',error:'Error',en_curso:'En curso',pendiente:'Pendiente',omitida:'No seleccionada'};
    const lastStatus=task=>data?.started&&task?.status!=='omitida'
      ?`<span class="sbs-task-status sbs-${esc(app,task.status)}" title="Resultado de la última ejecución">${esc(app,status[task.status]||task.status)}</span>`:'';
    const errorDetail=task=>task?.status==='error'&&task.detail
      ?`<details class="sbs-source-error" data-sbs-error="${task.id}" ${app.state.sbsErrorOpen?.[task.id]?'open':''}><summary>Ver motivo del error</summary><p>${esc(app,task.detail)}</p></details>`:'';
    const groups=sbsGroups.map(group=>{
      const items=group.ids.map(id=>tasks.find(task=>task.id===id)).filter(Boolean);
      if(!items.length)return '';
      const selected=items.filter(item=>chosen.includes(item.id)).length;
      let choices='';
      if(group.id==='eeff'){
        const financial=items.find(item=>item.id==='estados_financieros');
        const saving=items.find(item=>item.id==='ahorro_moneda');
        const executed=items.filter(item=>lastSelection.has(item.id));
        const failed=executed.some(item=>item.status==='error');
        const running=executed.some(item=>item.status==='en_curso');
        const pending=executed.some(item=>item.status==='pendiente');
        const financialStatus=executed.length
          ?(failed?'Error':running?'En curso':pending?'Pendiente':executed.every(item=>item.status==='correcto')?'Validado':'')
          :'';
        const financialClass=failed?'error':running?'en_curso':pending?'pendiente':'correcto';
        choices=`<div class="sbs-source-entry-row sbs-financial-unified">
          <label class="sbs-source-choice"><input type="checkbox" data-sbs-eeff="all" ${anyEeff?'checked':''} ${locked?'disabled':''}>
            <span>Estados financieros y cuentas por moneda</span>
            ${data?.started&&financialStatus?`<span class="sbs-task-status sbs-${financialClass}" title="Resultado de la última ejecución">${financialStatus}</span>`:''}
          </label>
          ${errorDetail(financial)}${errorDetail(saving)}
        </div>`;
      }else{
        choices=items.map(task=>{
          const parts=sourceUsesComponents(task.id);
          const ratioParts=task.id==='ratios'?sbsRatioCategories:[];
          const ratioDrill=ratioParts.length?`<details class="sbs-source-drill" data-sbs-drill="ratios" ${app.state.sbsDrillOpen?.ratios?'open':''}>
            <summary>Ver indicadores <span>${ratioParts.filter(item=>app.state.sbsRatios.includes(item)).length} de ${ratioParts.length}</span></summary>
            <div class="sbs-source-parts">${ratioParts.map(label=>`<label><input type="checkbox" data-sbs-ratio="${esc(app,label)}" ${app.state.sbsRatios.includes(label)?'checked':''} ${locked?'disabled':''}><span>${esc(app,label)}</span></label>`).join('')}</div>
          </details>`:'';
          const drill=parts.length?`<details class="sbs-source-drill" data-sbs-drill="${task.id}" ${app.state.sbsDrillOpen?.[task.id]?'open':''}>
            <summary>Ver series <span>${parts.filter(part=>selectedComponents.has(part[0])).length} de ${parts.length}</span></summary>
            <div class="sbs-source-parts">${parts.map(([id,label])=>`<label><input type="checkbox" data-sbs-series="${id}" data-sbs-series-source="${task.id}" ${selectedComponents.has(id)?'checked':''} ${locked?'disabled':''}><span>${esc(app,label)}</span></label>`).join('')}</div>
          </details>`:'';
          return `<div class="sbs-source-entry-row"><label class="sbs-source-choice"><input type="checkbox" data-sbs-source="${esc(app,task.id)}" ${chosen.includes(task.id)?'checked':''} ${locked?'disabled':''}><span>${esc(app,task.label)}</span>${lastStatus(task)}</label>${drill}${ratioDrill}${errorDetail(task)}</div>`;
        }).join('');
      }
      const details=group.details?`<details class="sbs-accounts" ${app.state.sbsDetailsOpen?'open':''}>
        <summary>Elegir cuentas y subcuentas <span class="sbs-detail-hint">${selectedAccounts.size} de ${allSbsAccounts.length}</span></summary>
        <div class="sbs-account-columns">${sbsAccountGroups.map(cat=>`<details class="sbs-account-category" data-sbs-account="${cat.id}" ${app.state.sbsAccountOpen?.[cat.id]?'open':''}>
          <summary>${cat.title}<span>${cat.items.filter(item=>selectedAccounts.has(item.id)).length} de ${cat.items.length}</span></summary>
          <ul>${cat.items.map(item=>{
            const parts=item.parts;
            return `<li class="sbs-account-line"><label class="sbs-account-choice"><input type="checkbox" data-sbs-account-choice="${item.id}" ${selectedAccounts.has(item.id)?'checked':''} ${locked?'disabled':''}><span>${esc(app,item.label)}</span></label>${parts.length>1?`<details class="sbs-account-drill" data-sbs-account-drill="${item.id}" ${app.state.sbsAccountDrillOpen?.[item.id]?'open':''}><summary>${item.id==='ahorro'?'Ver desglose por moneda':'Ver subcuentas'}</summary><div class="sbs-subaccount-list">${parts.map(([id,label])=>`<label><input type="checkbox" data-sbs-component="${id}" data-sbs-component-parent="${item.id}" ${selectedComponents.has(id)?'checked':''} ${locked?'disabled':''}><span>${esc(app,label)}</span></label>`).join('')}</div></details>`:''}</li>`;
          }).join('')}</ul></details>`).join('')}
        </div>
        <p class="sbs-account-hint">Elige un bloque completo o abre una cuenta para seleccionar sus componentes.</p>
      </details>`:'';
      const wholeEeff=sbsAccountGroups.every(cat=>cat.items.every(item=>item.parts.every(([id])=>selectedComponents.has(id))));
      const groupComplete=group.id==='eeff'?(anyEeff&&wholeEeff):selected===items.length;
      const coverage=group.id==='oficinas'?'<p class="sbs-account-hint">Catálogo completo de instituciones.</p>':'';
      return `<section class="sbs-source-group" aria-label="${esc(app,group.title)}"><div class="sbs-group-title"><h3>${esc(app,group.title)}</h3><button type="button" data-sbs-group="${group.id}" ${locked?'disabled':''}>${groupComplete?'Quitar selección':'Seleccionar todo'}</button></div><div class="sbs-group-choices">${choices}</div>${coverage}${details}</section>`;
    }).join('');
    const allSelected=chosen.length===tasks.length&&allSbsComponents.every(id=>selectedComponents.has(id))&&sbsRatioCategories.every(id=>app.state.sbsRatios.includes(id));
    const title=data?.running?(data?.stopping?'Deteniendo…':'Detener actualización'):
      data?.canResume?'Reanudar actualización':`Actualizar ${allSelected?'todo':'selección'}`;
    const disabled=data?.stopping||(!data?.running&&data?.operation?.running)||(!data?.running&&!data?.canResume&&!chosen.length);
    const allMain=allModels(app).filter(m=>/^\d{2}$/.test(m.id));
    const covered=new Set(allSbsComponents.map(x=>x.split('_')[0]));
    const coverageInventory=MODEL_CATEGORIES.map(cat=>{
      const items=allMain.filter(m=>modelCategory(m).id===cat.id);
      if(!items.length)return '';
      return `<div class="sbs-inventory-group"><strong>${esc(app,cat.name)}</strong>${items.map(m=>`<div><span>${esc(app,m.name)}</span><small>${covered.has(m.id)?'Fuente SBS/BCRP':'Derivada o fuente propia'}</small></div>`).join('')}</div>`;
    }).join('');
    const bankCount=app.state.sbsBanks.length;
    const coverage=`<details class="sbs-bank-coverage" ${app.state.sbsCoverageOpen?'open':''}>
      <summary>Entidades <span>${bankCount===1&&app.state.sbsBanks[0]==='05'?'Banco Falabella':bankCount+' entidades seleccionadas'}</span></summary>
      <p>La proyección IASPE utiliza las series de Banco Falabella. Las demás entidades solo alimentan comparaciones históricas en Mercado. Las series agregadas conservan su cobertura.</p>
      <div class="sbs-bank-actions"><button type="button" data-sbs-bank-all ${locked?'disabled':''}>Seleccionar todos</button><button type="button" data-sbs-bank-none ${locked?'disabled':''}>Limpiar bancos</button></div>
      <div class="sbs-bank-list">${institutionGroups(data?.institutions||sbsBanks.map((name,index)=>({id:sbsBankIds[index],name,category:index===16?'Cajas rurales':index===9?'Empresas financieras':'Bancos'})),data?.latestPeriod||new Date().toISOString().slice(0,7),item=>`<label><input type="checkbox" data-sbs-bank="${esc(app,item.id)}" ${app.state.sbsBanks.includes(item.id)?'checked':''} ${locked?'disabled':''}><span>${esc(app,item.name)}</span></label>`)}</div>
    </details>`;
    return `<div class="sbs-source-head"><div><h2>Fuentes financieras</h2><span class="quiet" role="status">${esc(app,caption)}</span></div><button type="button" class="button secondary" id="sbs-start" ${disabled?'disabled':''}>${title}</button></div>
      <div class="sbs-scope-row">${coverage}<span class="sbs-source-datatype">${manualCount?`${manualCount} observaciones manuales registradas · `:''}Fuentes SBS/BCRP</span></div>
      <div class="sbs-select-head"><span>${visibleSelected} de ${visibleTotal} opciones seleccionadas${anyEeff?' · '+selectedAccounts.size+' cuentas financieras':''}</span><div><button type="button" id="sbs-select-all" ${locked?'disabled':''}>Seleccionar todo</button><button type="button" id="sbs-select-none" ${locked?'disabled':''}>Limpiar selección</button></div></div>
      <div class="sbs-source-groups">${groups}</div>
      <details class="sbs-model-inventory"><summary>Ver cobertura de las cuentas IASPE <span>${allMain.length} modelos</span></summary><p>Las cuentas con fuente SBS/BCRP pueden actualizarse desde los grupos superiores. Las derivadas se recalculan desde sus componentes, sin descarga ficticia.</p><div class="sbs-inventory-grid">${coverageInventory}</div></details>
      ${!chosen.length&&!data?.canResume?'<p class="sbs-selection-warning">Selecciona la información que deseas actualizar.</p>':''}
      ${data?.started?`<div class="sbs-process-summary"><span>Última ejecución: ${passed} de ${considered.length} procesos validados${considered.length-passed?' · '+(considered.length-passed)+' pendiente(s) o con error':''}</span><span>${done} terminados</span></div>
        <div class="sbs-source-progress" role="progressbar" aria-label="Avance de última ejecución" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${considered.length?Math.round(done/considered.length*100):0}"><div style="width:${considered.length?done/considered.length*100:0}%"></div></div>
        <details class="sbs-source-log" ${app.state.sbsLogOpen===true?'open':''}><summary>Registro técnico de ejecución <span>${(data.lines||[]).length} líneas</span></summary><pre>${esc(app,(data.lines||[]).slice(-120).join('\n'))}</pre></details>`:''}`;
  }
  function sbsRender(app) {
    const container=document.getElementById('sbs-update');
    if(!container)return;
    const previousLog=container.querySelector('.sbs-source-log');
    const previousPre=previousLog?.querySelector('pre');
    const logScroll=previousPre?.scrollTop||0;
    const followLog=!previousPre||previousPre.scrollHeight-previousPre.clientHeight-previousPre.scrollTop<18;
    const pageScroll=window.scrollY;
    if(previousLog)app.state.sbsLogOpen=previousLog.open;
    container.innerHTML=sbsHTML(app,app.state.sbsUpdate);
    const nextPre=container.querySelector('.sbs-source-log pre');
    if(nextPre)nextPre.scrollTop=followLog?nextPre.scrollHeight:logScroll;
    if(Math.abs(window.scrollY-pageScroll)>2)window.scrollTo(0,pageScroll);
    function save(components,chosen){
      const accounts=accountsForComponents(components);
      if(accounts.some(id=>id!=='ahorro'))chosen.add('estados_financieros');
      if(accounts.includes('ahorro')){chosen.add('ahorro_moneda');chosen.add('estados_financieros');}
      else chosen.delete('ahorro_moneda');
      if(!accounts.length)chosen.delete('estados_financieros');
      app.state.sbsSources=[...chosen];
      app.state.sbsAccounts=accounts;
      app.state.sbsComponents=[...components];
      sbsRender(app);
    }
    const addSourceParts=(source,components)=>sourceUsesComponents(source).forEach(([id])=>components.add(id));
    const removeSourceParts=(source,components)=>sourceUsesComponents(source).forEach(([id])=>components.delete(id));
    container.querySelector('[data-sbs-eeff]')?.addEventListener('change',event=>{
      const chosen=new Set(app.state.sbsSources||[]),components=new Set(app.state.sbsComponents||[]);
      sbsAccountGroups.flatMap(group=>group.items).forEach(item=>item.parts.forEach(([code])=>event.target.checked?components.add(code):components.delete(code)));
      if(event.target.checked){chosen.add('estados_financieros');chosen.add('ahorro_moneda');}
      else{chosen.delete('estados_financieros');chosen.delete('ahorro_moneda');}
      save(components,chosen);
    });
    document.querySelectorAll('[data-sbs-source]').forEach(input=>input.addEventListener('change',()=>{
      const chosen=new Set(app.state.sbsSources||[]),components=new Set(app.state.sbsComponents||[]);
      const id=input.dataset.sbsSource;
      if(input.checked&&id==='ratios'&&!app.state.sbsRatios?.length)app.state.sbsRatios=[...sbsRatioCategories];
      if(input.checked){chosen.add(id);addSourceParts(id,components);if(id==='estados_financieros')sbsAccountGroups.flatMap(cat=>cat.items).filter(item=>item.id!=='ahorro').forEach(item=>item.parts.forEach(([code])=>components.add(code)));
        if(id==='ahorro_moneda')accountParts.ahorro.forEach(code=>components.add(code));
      }else{chosen.delete(id);removeSourceParts(id,components);
        if(id==='estados_financieros')sbsAccountGroups.flatMap(cat=>cat.items).filter(item=>item.id!=='ahorro').forEach(item=>item.parts.forEach(([code])=>components.delete(code)));
        if(id==='ahorro_moneda')accountParts.ahorro.forEach(code=>components.delete(code));
      }
      save(components,chosen);
    }));
    document.querySelectorAll('[data-sbs-group]').forEach(button=>button.addEventListener('click',()=>{
      const group=sbsGroups.find(item=>item.id===button.dataset.sbsGroup);
      if(!group)return;
      const chosen=new Set(app.state.sbsSources||[]),components=new Set(app.state.sbsComponents||[]);
      const enable=group.id==='eeff'?(!chosen.has('estados_financieros')||!chosen.has('ahorro_moneda')||sbsAccountGroups.some(cat=>cat.items.some(item=>item.parts.some(([code])=>!components.has(code))))):!group.ids.every(id=>chosen.has(id));
      if(enable&&group.ids.includes('ratios')&&!app.state.sbsRatios?.length)app.state.sbsRatios=[...sbsRatioCategories];
      group.ids.forEach(id=>{
        if(enable){chosen.add(id);addSourceParts(id,components);}else{chosen.delete(id);removeSourceParts(id,components);}
      });
      if(group.id==='eeff')sbsAccountGroups.flatMap(cat=>cat.items).forEach(item=>item.parts.forEach(([code])=>enable?components.add(code):components.delete(code)));
      save(components,chosen);
    }));
    document.querySelectorAll('[data-sbs-account-choice]').forEach(input=>input.addEventListener('change',()=>{
      const chosen=new Set(app.state.sbsSources||[]),components=new Set(app.state.sbsComponents||[]);
      accountParts[input.dataset.sbsAccountChoice].forEach(code=>input.checked?components.add(code):components.delete(code));
      save(components,chosen);
    }));
    document.querySelectorAll('[data-sbs-component]').forEach(input=>input.addEventListener('change',()=>{
      const chosen=new Set(app.state.sbsSources||[]),components=new Set(app.state.sbsComponents||[]);
      if(input.checked)components.add(input.dataset.sbsComponent);else components.delete(input.dataset.sbsComponent);
      save(components,chosen);
    }));
    document.querySelectorAll('[data-sbs-series]').forEach(input=>input.addEventListener('change',()=>{
      const chosen=new Set(app.state.sbsSources||[]),components=new Set(app.state.sbsComponents||[]);
      if(input.checked)components.add(input.dataset.sbsSeries);else components.delete(input.dataset.sbsSeries);
      const source=input.dataset.sbsSeriesSource;
      if(sourceUsesComponents(source).some(([id])=>components.has(id)))chosen.add(source);else chosen.delete(source);
      save(components,chosen);
    }));
    document.querySelectorAll('[data-sbs-ratio]').forEach(input=>input.addEventListener('change',()=>{
      const chosen=new Set(app.state.sbsSources||[]),ratios=new Set(app.state.sbsRatios||[]);
      if(input.checked)ratios.add(input.dataset.sbsRatio);else ratios.delete(input.dataset.sbsRatio);
      if(ratios.size)chosen.add('ratios');else chosen.delete('ratios');
      app.state.sbsRatios=[...ratios];app.state.sbsSources=[...chosen];sbsRender(app);
    }));
    const expanded=[['.sbs-accounts','sbsDetailsOpen',null],['[data-sbs-account]','sbsAccountOpen','sbsAccount'],['[data-sbs-account-drill]','sbsAccountDrillOpen','sbsAccountDrill'],['[data-sbs-drill]','sbsDrillOpen','sbsDrill'],['[data-sbs-error]','sbsErrorOpen','sbsError']];
    expanded.forEach(([selector,key,attribute])=>container.querySelectorAll(selector).forEach(item=>item.addEventListener('toggle',()=>{
      if(attribute)(app.state[key]||={})[item.dataset[attribute]]=item.open;
      else app.state[key]=item.open;
    })));
    container.querySelector('.sbs-bank-coverage')?.addEventListener('toggle',event=>app.state.sbsCoverageOpen=event.target.open);
    container.querySelectorAll('[data-sbs-bank]').forEach(input=>input.addEventListener('change',()=>{
      const ids=new Set(app.state.sbsBanks);
      input.checked?ids.add(input.dataset.sbsBank):ids.delete(input.dataset.sbsBank);
      app.state.sbsBanks=sbsBankIds.filter(id=>ids.has(id));sbsRender(app);
    }));
    container.querySelector('[data-sbs-bank-all]')?.addEventListener('click',()=>{app.state.sbsBanks=[...sbsBankIds];sbsRender(app)});
    container.querySelector('[data-sbs-bank-none]')?.addEventListener('click',()=>{app.state.sbsBanks=[];sbsRender(app)});
    container.querySelector('.sbs-source-log')?.addEventListener('toggle',event=>app.state.sbsLogOpen=event.target.open);
    document.getElementById('sbs-select-all')?.addEventListener('click',()=>{
      app.state.sbsSources=(app.state.sbsUpdate?.tasks||[]).map(task=>task.id);
      app.state.sbsComponents=[...allSbsComponents];app.state.sbsAccounts=[...allSbsAccounts];app.state.sbsRatios=[...sbsRatioCategories];sbsRender(app);
    });
    document.getElementById('sbs-select-none')?.addEventListener('click',()=>{
      app.state.sbsSources=[];app.state.sbsComponents=[];app.state.sbsAccounts=[];app.state.sbsRatios=[];sbsRender(app);
    });
    document.getElementById('sbs-start')?.addEventListener('click',async()=>{
      const data=app.state.sbsUpdate||{};
      const button=document.getElementById('sbs-start');
      if(data.stopping)return;
      let endpoint='/api/sbs/start',payload={};
      if(data.running)endpoint='/api/sbs/stop';
      else if(data.canResume)endpoint='/api/sbs/resume';
      else{
        const banks=app.state.sbsBanks||[];
        const selected=(app.state.sbsSources||[]).filter(id=>id!=='personal_financieras'||banks.includes('10')).filter(id=>id!=='personal_rurales'||banks.includes('crac_18'));
        if(!selected.length){app.toast('Selecciona al menos una fuente.');return;}
        if(!banks.length&&selected.some(id=>['estados_financieros','ratios','personal_banca','personal_financieras','personal_rurales'].includes(id))){
          app.state.sbsCoverageOpen=true;sbsRender(app);app.toast('Elige al menos una entidad para las fuentes bancarias.');return;
        }
        let confirmText = banks.length === sbsBankIds.length
          ? '¿Actualizar las fuentes seleccionadas para todas las entidades?'
          : banks.length === 1
            ? '¿Actualizar las fuentes seleccionadas para ' + sbsBankNames(banks)[0] + '?'
            : banks.length > 1
              ? '¿Actualizar las fuentes seleccionadas para los ' + banks.length + ' entidades seleccionadas?'
              : '¿Actualizar las fuentes seleccionadas?';
        if(selected.length===1&&selected[0]==='oficinas')confirmText='¿Actualizar oficinas para el catálogo completo de instituciones?';
        else if(selected.includes('oficinas'))confirmText+=' Las oficinas abarcan el catálogo completo de instituciones.';
        if(!window.confirm(confirmText))return;
        const components=new Set(app.state.sbsComponents||[]);
        sbsAccountGroups.flatMap(group=>group.items).forEach(item=>{
          if(item.parts.every(([id])=>components.has(id)))components.add(item.id==='interbancarios'?'22':item.id==='ahorro'?'08':({plazo_cts:'09',obligaciones:'10',disponible:'17',inversiones:'21',gastos_intereses:'12',ingresos_intereses:'16',servicios:'18',administracion:'19',operaciones:'20'}[item.id]||item.parts[0][0]));
        });
        payload={sources:selected,accounts:app.state.sbsAccounts||[],components:[...components],ratioCategories:app.state.sbsRatios||sbsRatioCategories,banks:app.state.sbsBanks||[]};
      }
      button.disabled=true;
      try{app.state.sbsUpdate=await app.api(endpoint,payload);acceptSourceStatus(app.state.sbsUpdate,app);scheduleSources(app);sbsRender(app);sbsPoll(app);}
      catch(error){button.disabled=false;app.toast(error.message);sbsRender(app);}
    });
  }
  async function sbsPoll(app){
    clearTimeout(sbsTimer);
    if(!document.getElementById('sbs-update'))return;
    try{
      const before=app.state.sbsUpdate;
      const data=await refreshSourceStatus(app);
      app.state.sbsUpdate=data;
      sbsRender(app);
      if(data.running){sbsTimer=setTimeout(()=>sbsPoll(app),1400);}
      else if(before?.running){
        const state=await app.api('/api/state');
        app.state.data=state;
        app.state.scenarios=state.scenarios||[];
        const pageScroll=window.scrollY;
        app.render();
        window.scrollTo(0,pageScroll);
        updateWindow(app, data.result==='completo'?'Actualización de fuentes finalizada':'Actualización de fuentes con incidencias', data.summary||{},'sources');
        app.toast(data.pending?.pending?'Datos SBS disponibles; pulsa Recalcular modelos.':'Actualización finalizada; sin nuevos datos para el motor.');
        window.IASPEMonitor?.refresh();
      }
    }catch(error){app.toast('No se pudo consultar el avance SBS.');}
  }
  function recalculationStatus(app){
    const pending=app.state.data?.sourceUpdates||{};
    const total=Number(pending.observations||0),manual=Number(pending.manualRecords||0);
    const badge=total?`${total} observación${total===1?'':'es'} pendiente${total===1?'':'s'} de recalcular`:'Modelos actualizados';
    return `<span class="update-recalc-status" role="status">${esc(app,badge)}${manual?` · ${manual} registro${manual===1?'':'s'} manual${manual===1?'':'es'} integrado${manual===1?'':'s'}`:''}</span>`;
  }
  function recalculationButton(){return '<button type="button" class="button" data-recalculate-models>Recalcular modelos</button>';}
  function groupedUpdateOptions(app,models,selected){
    const groups=new Map();
    for(const m of models){
      const group=m.isMacro?'Variables macroeconómicas':modelCategory(m).name;
      if(!groups.has(group))groups.set(group,[]);
      groups.get(group).push(m);
    }
    const order=['Variables macroeconómicas','Variables operativas','Estado de situación financiera','Estado de resultados','Modelos complementarios','Mercado'];
    return [...groups].sort((a,b)=>{
      const aa=order.indexOf(a[0]),bb=order.indexOf(b[0]);
      return (aa<0?100:aa)-(bb<0?100:bb);
    }).map(([category,items])=>`<optgroup label="${esc(app,category)}">${items.map(m=>`<option value="${esc(app,m.id)}" ${m.id===selected?.id?'selected':''}>${esc(app,m.name)}</option>`).join('')}</optgroup>`).join('');
  }
  function updateHTML(app) {
    const models=updateModels(app);
    const selected=models.find(m=>m.id===app.state.updateId)||models[0];
    if(selected)app.state.updateId=selected.id;
    const mode=app.state.dataUpdateMode||'manual';
    const baseRows=selected?updateRows(selected,true):[];
    const staged=(app.state.data?.sourceUpdates?.manualDetails||[])
      .filter(item=>item.model===selected?.id && finite(item.current))
      .map(item=>({period:item.period,value:item.current,status:'staged'}));
    const byPeriod=new Map(baseRows.map(row=>[row.period,row]));
    staged.forEach(row=>byPeriod.set(row.period,row));
    const sortedRows=[...byPeriod.values()].sort((a,b)=>String(a.period).localeCompare(String(b.period)));
    const rows=app.state.updateShowAll?sortedRows:sortedRows.slice(-8);
    const count=(app.state.entries||[]).length;
    const importMode=app.state.updateImportMode||'paste';
    const annual=!isMonthlyInput(selected);
    const externo=selected?.id==='26';
    const example=annual?'2025':'2026-09';
    const sample=annual?'Periodo\tValor\n2024\t3.20\n2025\t3.45':'Periodo\tValor\n2026-07\t120.50\n2026-08\t123.10';
    return `<section class="update-workspace update-workspace-v2">
      <header class="work-heading update-page-heading"><div><h1>Datos observados</h1><p class="quiet">Actualización de las series que alimentan las proyecciones.</p></div></header>
      <div class="update-method-tabs" role="tablist" aria-label="Modo de actualización"><button type="button" role="tab" data-update-mode="manual" aria-selected="${mode==='manual'}" class="${mode==='manual'?'active':''}">Carga manual</button><button type="button" role="tab" data-update-mode="automatic" aria-selected="${mode==='automatic'}" class="${mode==='automatic'?'active':''}">Fuentes automáticas</button></div>
      <div class="update-auto-area" ${mode==='automatic'?'':'hidden'}>
        <div class="update-auto-heading"><div><h2>Actualizar fuentes SBS y BCRP</h2><p>Datos de Falabella para IASPE; las otras entidades se consultan como referentes de mercado.</p>${recalculationStatus(app)}</div>${recalculationButton()}</div>
        <section id="sbs-update" class="sbs-update-panel" aria-label="Actualizar fuentes"></section>
      </div>
      <div class="update-manual-area" ${mode==='manual'?'':'hidden'}>
        <div class="update-manual-top"><div><h2>Actualización manual</h2><p>Guarda las observaciones y recalcula para publicarlas en los modelos.</p>${recalculationStatus(app)}</div><div class="update-manual-actions">${recalculationButton()}<button type="button" class="button secondary" id="manual-export-series">Exportar serie</button><button type="button" class="button secondary" id="manual-template">Plantilla CSV</button></div></div>
        <div class="update-series-toolbar"><label>Variable<select id="update-model" aria-label="Variable a actualizar">${groupedUpdateOptions(app,models,selected)}</select></label><div class="update-series-unit">${esc(app,selected?.unit||'')} · ${annual?'Anual':'Mensual'}</div><button type="button" class="button ghost" id="toggle-observation-history">${app.state.updateShowAll?'Ver períodos recientes':'Ver serie completa'}</button></div>
        <section class="update-observations" aria-label="Serie observada"><div class="update-section-heading"><h2>Serie histórica</h2><small>Para corregir un valor, edita su celda.</small></div><div class="observed-grid-wrap table-scroll"><table class="data-table update-table observed-grid"><thead><tr><th>Período</th><th>${externo?'Valor del área':'Valor observado'}</th><th>Estado</th></tr></thead><tbody>${rows.map(row=>{const entry=pendingEntry(app,selected.id,row.period);const value=app.fmt(entry?entry.value:row.value,selected?.unit?.toLowerCase().includes('tarjetas')?0:6);return `<tr class="${entry?'pending-row':''}"><td>${esc(app,row.period)}</td><td><input class="observation-cell${entry?' changed-cell':''}" inputmode="decimal" autocomplete="off" aria-label="Valor ${esc(app,selected.name)} ${row.period}" data-observation="${row.period}" data-initial="${esc(app,value)}" data-original="${esc(app,row.value)}" data-original-display="${esc(app,app.fmt(row.value,selected?.unit?.toLowerCase().includes('tarjetas')?0:6))}" value="${esc(app,value)}"></td><td>${entry?'<span class="pending-label">Por guardar</span>':row.status==='staged'?'<span class="pending-label">Guardado · sin recalcular</span>':row.status==='assumed'?'<span class="assumption-label">Supuesto</span>':row.status==='forecast'?'<span class="assumption-label">Proyección del área</span>':'Observado'}</td></tr>`}).join('')||'<tr><td colspan="3" class="quiet">No hay observaciones para esta variable.</td></tr>'}</tbody></table></div></section>
        <div class="update-manual-tools">
          <section class="update-entry-card"><div class="update-section-heading"><h2>Añadir un período</h2></div><div class="update-entry-fields"><label>Período<input id="new-observation-period" aria-label="Período nuevo" placeholder="${example}" autocomplete="off"></label><label>${externo?'Importe del área':'Valor observado'}<input id="new-observation-value" inputmode="decimal" aria-label="Valor nuevo" placeholder="0.00" autocomplete="off"></label><button type="button" class="button secondary" id="add-observation">Agregar</button></div><small class="update-help">Formato: ${annual?'AAAA':'AAAA-MM'}. Se admiten correcciones históricas.</small></section>
          <section class="update-bulk-card"><div class="update-bulk-header"><div><h2>Carga masiva</h2></div><div class="segmented update-import-tabs" role="group"><button type="button" data-update-import="paste" class="${importMode==='paste'?'active':''}" aria-pressed="${importMode==='paste'}">Pegar</button><button type="button" data-update-import="file" class="${importMode==='file'?'active':''}" aria-pressed="${importMode==='file'}">Excel / CSV</button></div></div>
            ${importMode==='paste'?`<div class="update-paste-grid"><div><label for="observations-paste" class="update-field-label">Columnas Período y Valor</label><textarea id="observations-paste" class="paste-zone" rows="5" spellcheck="false" placeholder="${sample.replaceAll('\t','&#9;').replaceAll('\n','&#10;')}" aria-label="Pegar períodos y valores desde Excel"></textarea></div><div class="update-paste-action"><button type="button" class="button" id="stage-paste">Cargar filas</button></div></div>`:
            `<label class="update-drop" id="observations-drop" for="observations-file" tabindex="0"><span class="update-file-symbol" aria-hidden="true">XLS</span><strong>Seleccionar Excel o CSV</strong><span>O arrastra el archivo aquí</span><small>.xlsx · .xls · .xlsm · .csv · .tsv</small><input type="file" id="observations-file" accept=".xlsx,.xls,.xlsm,.csv,.tsv,.txt" hidden></label>`}
          </section>
        </div>
        ${pendingHTML(app)}
      </div>
    </section>`;
  }
  function bindUpdate(app) {
    paintSourceControls();
    document.querySelectorAll('[data-recalculate-models]').forEach(button=>button.addEventListener('click',async()=>{
      if((app.state.entries||[]).length){app.toast('Primero valida y guarda los cambios de la carga manual.');return;}
      button.disabled=true;button.textContent='Recalculando…';
      try {
        const result=await app.api('/api/models/recalculate',{});
        await refreshSourceStatus(app);
        app.state.data=result;
        app.state.scenarios=result.scenarios||[];
        app.render();
        const report=result.recalculation||{};
        updateWindow(app,report.ok?'Recálculo de modelos concluido':'Recálculo detenido: revisa las incidencias',report,'models');
        window.IASPEMonitor?.refresh();
      }catch(err){button.disabled=false;button.textContent='Recalcular modelos';
        try{const status=await app.api('/api/state');const report=status.lastRecalculation;
          if(report?.audit?.errors||report?.warnings?.length){updateWindow(app,'Recálculo detenido por inconsistencias',report,'models');}
        }catch(_ignored){}
        app.toast(err.message||'No se pudo recalcular.');}
    }));
    if((app.state.dataUpdateMode||'manual')==='automatic'||app.state.sbsUpdate?.running){sbsRender(app);sbsPoll(app);}
    else clearTimeout(sbsTimer);
    document.querySelectorAll('[data-update-mode]').forEach(button=>button.addEventListener('click',()=>{
      const mode=button.dataset.updateMode;
      if(mode!==(app.state.dataUpdateMode||'manual')){app.state.dataUpdateMode=mode;app.render();}
    }));
    function downloadCsv(filename,rows){
      const encoded='\ufeff'+rows.map(row=>row.map(value=>'"'+String(value??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');
      const blob=new Blob([encoded],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
      a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200);
    }
    document.getElementById('manual-template')?.addEventListener('click',()=>{
      const model=updateModel(app,app.state.updateId);
      downloadCsv('plantilla_IASPE_'+model.id+'.csv',[['Periodo','Valor'],[isMonthlyInput(model)?'2026-09':'2025','']]);
    });
    document.getElementById('manual-export-series')?.addEventListener('click',()=>{
      const selected=updateModel(app,app.state.updateId);
      const rows=updateRows(selected,true);
      downloadCsv('respaldo_IASPE_'+selected.id+'.csv',[['Periodo','Valor'],...rows.map(row=>[row.period,row.value])]);
      app.toast('Serie exportada. Conserva este respaldo antes de actualizarla.');
    });
    document.getElementById('update-model')?.addEventListener('change', event => { app.state.updateId=event.target.value;app.state.manualReview=null;app.state.updateShowAll=false;app.render(); });
    const redrawGrid = (key, select = false, focusId = '') => {
      const scroll = document.querySelector('.observed-grid-wrap')?.scrollTop || 0;
      app.render();
      const wrap = document.querySelector('.observed-grid-wrap');
      if (wrap) wrap.scrollTop = scroll;
      if (key) {
        const input = document.querySelector(`[data-observation="${key}"]`);
        input?.focus({preventScroll: true});
        if (select) input?.select();
      } else if (focusId) document.getElementById(focusId)?.focus({preventScroll: true});
    };
    const saveCell = input => {
      const raw = input.value.trim();
      if (raw === input.dataset.initial) return true;
      const value = number(raw);
      if (!raw || raw === input.dataset.originalDisplay || value === number(input.dataset.original)) {
        app.state.entries = (app.state.entries || []).filter(e => e.id !== app.state.updateId || e.period !== input.dataset.observation);
        app.state.preview = null;app.state.manualReview=null;return true;
      }
      if (value == null) { app.toast('Introduce un número válido.'); input.focus(); return false; }
      return stage(app, {id: app.state.updateId, period: input.dataset.observation, value});
    };
    document.querySelectorAll('[data-observation]').forEach(input => {
      input.addEventListener('change', () => {
        if (input.dataset.keyboardHandled || !saveCell(input)) return;
        setTimeout(() => redrawGrid(document.activeElement?.dataset.observation, false, document.activeElement?.id || ''), 0);
      });
      input.addEventListener('keydown', event => {
        if (!['Enter', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
        event.preventDefault();
        const cells = [...document.querySelectorAll('[data-observation]')];
        const index = cells.indexOf(input);
        const offset = event.key === 'ArrowUp' || event.key === 'Enter' && event.shiftKey ? -1 : 1;
        const next = cells[Math.max(0, Math.min(cells.length - 1, index + offset))]?.dataset.observation;
        if (saveCell(input)) { input.dataset.keyboardHandled = '1'; redrawGrid(next, true); }
      });
      input.addEventListener('paste', event => {
        const text = event.clipboardData?.getData('text/plain') || '';
        if (!text.includes('\t')) return;
        event.preventDefault();
        stageMany(app, text.trim().split(/\r?\n/).map(line => {
          const cells = line.split('\t'); return {id: app.state.updateId, period: cells[0], value: cells[1]};
        }));
      });
    });
    document.getElementById('toggle-observation-history')?.addEventListener('click', () => {
      app.state.updateShowAll = !app.state.updateShowAll; app.render();
    });
    // Carga individual y pegado de bloques sin recálculos parciales.
    const addRow=()=>{
      const key=period(document.getElementById('new-observation-period')?.value);
      const value=number(document.getElementById('new-observation-value')?.value);
      if(!stage(app,{id:app.state.updateId,period:key,value})){
        app.toast('Verifica el período y el valor observado.');return;
      }
      app.render();app.toast('Valor añadido a los cambios pendientes.');
    };
    document.getElementById('add-observation')?.addEventListener('click', addRow);
    ['new-observation-period','new-observation-value'].forEach(id=>document.getElementById(id)?.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();addRow();}}));
    document.querySelectorAll('[data-update-import]').forEach(button=>button.addEventListener('click',()=>{app.state.updateImportMode=button.dataset.updateImport;app.render();}));
    document.getElementById('stage-paste')?.addEventListener('click',()=>{
      const text=document.getElementById('observations-paste')?.value?.trim()||'';
      if(!text){app.toast('Pega dos columnas de Excel.');return;}
      const lines=text.split(/\r?\n/);
      const entries=lines.map(line=>{
        const columns=line.includes('\t')?line.split('\t'):line.split(';');
        return {id:app.state.updateId,period:columns[0]?.trim(),value:columns[1]?.trim()};
      }).filter(row=>row.period||row.value);
      // Aceptamos encabezados como "Período / Valor" sin contarlos como datos.
      const values=entries.filter(e=>!/^per[ií]odo$|^fecha$|^a[nñ]o$|^mes$/i.test(String(e.period||'')));
      stageMany(app,values);
    });
    async function loadFile(file){
      if(!file)return;
      const valid=/\.(xlsx|xls|xlsm|csv|tsv|txt)$/i.test(file.name);
      if(!valid){app.toast('Selecciona un Excel o un archivo CSV.');return;}
      const id=app.state.updateId;
      try{
        const content=await new Promise((resolve,reject)=>{
          const reader=new FileReader();
          reader.onload=()=>resolve(String(reader.result).split(',')[1]);
          reader.onerror=()=>reject(new Error('No se pudo leer el archivo.'));
          reader.readAsDataURL(file);
        });
        const result=await app.api('/api/import',{filename:file.name,content,id});
        stageMany(app,result.entries||[]);
      }catch(error){app.toast(error.message||'No se pudo importar el archivo.');}
    }
    document.getElementById('observations-file')?.addEventListener('change',event=>loadFile(event.target.files?.[0]));
    const dropZone=document.getElementById('observations-drop');
    if(dropZone){
      dropZone.addEventListener('dragover',e=>{e.preventDefault();dropZone.classList.add('dragging');});
      dropZone.addEventListener('dragleave',()=>dropZone.classList.remove('dragging'));
      dropZone.addEventListener('drop',e=>{e.preventDefault();dropZone.classList.remove('dragging');loadFile(e.dataTransfer?.files?.[0]);});
      dropZone.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();document.getElementById('observations-file')?.click();}});
    }
    document.getElementById('clear-update')?.addEventListener('click',()=>{app.state.entries=[];app.state.preview=null;app.state.manualReview=null;app.render();});
    document.querySelectorAll('[data-remove-id]').forEach(button=>button.addEventListener('click',()=>{
      app.state.entries=(app.state.entries||[]).filter(entry=>entry.id!==button.dataset.removeId||entry.period!==button.dataset.removePeriod);
      app.state.manualReview=null;app.render();
    }));
    document.getElementById('preview-update')?.addEventListener('click',async event=>{
      const button=event.currentTarget;button.disabled=true;button.textContent='Validando…';
      try{
        const result=await app.api('/api/update/preview',{entries:app.state.entries||[],changes:{}});
        app.state.manualReview={preview:result.preview||[]};
        app.render();document.getElementById('update-pending')?.scrollIntoView({block:'nearest'});
      }catch(error){button.disabled=false;button.textContent='Validar cambios';app.toast(error.message||'Error al validar. No se ha guardado nada.');}
    });
    document.getElementById('confirm-update')?.addEventListener('click',async event=>{
      const button=event.currentTarget;
      const review=app.state.manualReview;
      if(!review){app.toast('Primero valida los cambios.');return;}
      button.disabled=true;button.textContent='Aplicando…';
      try{
        const expected=review.preview.map(item=>({id:item.id,period:item.period,previous:item.previous}));
        const result=await app.api('/api/update/commit',{entries:app.state.entries||[],changes:{},expected});
        app.state.data=result.data?.models?result.data:result;
        comparisonRequest++;app.state.comparisonId='';app.state.comparisonModels=null;app.state.comparisonName='';app.state.comparisonBusy=false;
        app.state.preview=null;app.state.manualReview=null;app.state.entries=[];app.render();
        app.toast('Observaciones guardadas con respaldo. Pulsa Recalcular modelos para publicar los resultados.');
      }catch(error){button.disabled=false;button.textContent='Confirmar y guardar';app.state.manualReview=null;app.toast(error.message||'No se guardaron los cambios. Revalida los datos.');app.render();}
    });
  }
  window.IASPEPanels = {labHTML, bindLab, assumptionsHTML, comparisonHTML, bindScenarioControls, baselineModel, comparisonName, updateHTML, bindUpdate, modelCategory, scenarioCategories, orderedModels, RESULT_SECTIONS, BALANCE_SECTIONS};
})();
