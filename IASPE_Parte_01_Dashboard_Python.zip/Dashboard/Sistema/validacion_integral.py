"""Autodiagnóstico de IASPE, solo lectura. No descarga fuentes ni publica Excel.

Compara base física, fuente SBS y escenarios. Distingue controles
aprobados de rutas con transmisión parcial; nunca informa un OK global
como prueba de actualización online de SBS.
"""
from __future__ import annotations
import math
from datetime import datetime, timezone

import motor
from auditoria_calculos import verificar as verificar_calculos
from auditoria_fuentes import verificar_fuentes
from auditoria_persistencia import verificar_respaldo


def ejecutar():
    with motor.LOCK:
        checks=[]
        def add(name,passed,detail,partial=False):
            checks.append({'name':name,'status':'error' if not passed else 'parcial' if partial else 'ok',
                           'detail':detail})
        before=motor.fingerprint()
        base=motor.calculate()
        models={m['id']:m for m in base['models']}
        main=[m for m in models if len(m)==2 and m.isdigit()]
        add('Catálogo de modelos',len(main)==49,f'{len(main)} modelos principales y {len(models)} componentes en el motor.')
        pnl_audit=verificar_calculos(base,base)
        pnl_issues=[item for item in pnl_audit['findings'] if item['id']=='29']
        add('Cuadre absoluto de utilidad neta (M29)',not pnl_issues,
            f"6 ejercicios 2025-2030; {len(pnl_issues)} diferencias entre UAI, impuesto y utilidad neta.")
        source_audit=verificar_fuentes(motor.SOURCE)
        add('Integridad de fuentes y balances SBS',source_audit['passed'],f"{source_audit['checks']} controles; {len(source_audit['errors'])} errores.")
        physical=motor.load_base(refresh=True)[0]
        physical_active,physical_warnings=motor._run(physical,motor.macro_base_state().get('changes',{}),motor.all_observations())
        persisted=verificar_respaldo(base['models'],physical_active)
        if physical_warnings:persisted['passed']=False;persisted['errors']+=len(physical_warnings)
        add('Conciliación con los Excel de Output',persisted['passed'],f"{persisted['checks']} controles; {persisted['errors']} diferencias.")
        risks=['25','26','27']
        years=range(2026,2031)
        tested={}
        macro_tests={
            'PBI':{'pbi':{'2027':1.1,'2028':1.3}},
            'Inflación':{'inflacion':{'2027':6.2}},
            'Tasa de política monetaria':{'tpm':{'2027':6.5}},
            'Tipo de cambio':{'tc_cierre':{'2027':3.92}},
            'Desempleo':{'desempleo':{'2027':7.4}},
            'Estrés combinado':{'pbi':{'2027':1.2,'2028':1.4},'inflacion':{'2027':6.1},
                               'tpm':{'2027':6.0},'tc_cierre':{'2027':3.89},'desempleo':{'2027':7.0}}
        }
        # Confirmar respuesta de los canales causales, no solo consistencia
        # aritmética: una ruta congelada también podría cuadrar a cero.
        expected_driver_response={
            'PBI':[('16_disponible',2027),('19_terceros',2027),('06',2028)],
            'Inflación':[('12_entidades',2027),('19_impuestos',2027)],
            'Tasa de política monetaria':[('13',2027),('12_adeudos',2027)],
            'Tipo de cambio':[('08_me',2028)],
            'Desempleo':[('05',2027)],
            'Estrés combinado':[('06',2028),('29',2029)]
        }
        for label,changes in macro_tests.items():
            try:
                changed=motor.calculate(changes)
                audit=verificar_calculos(base,changed)
                revised={m['id']:m for m in changed['models']}
                stable=all(all(math.isclose(
                    next(v['value'] for v in models[k]['annual'] if v['year']==y),
                    next(v['value'] for v in revised[k]['annual'] if v['year']==y),abs_tol=1e-9)
                    for y in years) for k in risks)
                silent=[]
                for key,year in expected_driver_response[label]:
                    left=next((v['value'] for v in models[key]['annual'] if v['year']==year),None)
                    right=next((v['value'] for v in revised[key]['annual'] if v['year']==year),None)
                    if left is None or right is None or abs(float(right)-float(left))<=1e-7:
                        silent.append(f'{key}/{year}')
                passed=audit['passed'] and stable and len(revised)==len(models) and not silent
                # Base IASPE M47 llega a 2030; SBS estrés solo hasta 2028.
                differences=sum(1 for k in main for y in range(2027,2031)
                    if y in {r['year'] for r in models[k]['annual']}
                    and y in {r['year'] for r in revised[k]['annual']}
                    and abs(next(v['value'] for v in models[k]['annual'] if v['year']==y)
                           -next(v['value'] for v in revised[k]['annual'] if v['year']==y))>1e-7)
                incomplete=[k for k,m in revised.items() if m.get('status') in {'needs_input','error'}]
                partial=bool(changed.get('warnings') or incomplete)
                description=(f"{audit['checks']} controles; {differences} resultados de modelos principales modificados; "
                             f"Riesgos intacto; {len(incomplete)} componentes por revisar; "
                             f"{len(expected_driver_response[label])-len(silent)} canales causales activos."
                             + (f' Canales sin respuesta: {", ".join(silent)}.' if silent else ''))
                add('Simulación: '+label,passed,description,partial)
                tested[label]={'changedModelYears':differences,'partialModels':incomplete[:20],
                               'warnings':changed.get('warnings',[])[:5], 'checks':audit['checks'],
                               'errors':audit['errors']+len(silent),'silentDrivers':silent}
            except Exception as exc:
                add('Simulación: '+label,False,f'{type(exc).__name__}: {exc}')
                tested[label]={'errors':1,'message':str(exc)}
        latest=motor.pending_sources()
        add('Fuentes SBS por aplicar',True,
            f"{latest.get('observations',0)} observaciones pendientes; se publican exclusivamente con Recalcular modelos.",
            bool(latest.get('pending')))
        unchanged=before==motor.fingerprint()
        add('Protección de los archivos originales',unchanged,
            'No se modificó ningún archivo del árbol Modelos financieros durante la validación.' if unchanged
            else 'Los archivos de los modelos cambiaron durante el diagnóstico. Revisar actividad simultánea.')
        errors=sum(c['status']=='error' for c in checks)
        partial=sum(c['status']=='parcial' for c in checks)
        return {'checkedAt':datetime.now(timezone.utc).isoformat(), 'ok':not errors,
                'complete':not errors and not partial,'errors':errors,'partials':partial,
                'models':len(main),'components':len(models),'checks':checks,'macroTests':tested,
                'onlineSBSChecked':False,
                'notice':(('Los controles locales pasaron, pero existen rutas de escenarios parciales. '
                           if partial else 'Los controles locales de modelos, fuentes cargadas y escenarios pasaron. ')
                          + 'La descarga SBS real y la sincronización externa deben verificarse en el equipo Windows.'
                          if not errors else 'Se detectaron inconsistencias; revisa cada control antes de usar los resultados.')}
