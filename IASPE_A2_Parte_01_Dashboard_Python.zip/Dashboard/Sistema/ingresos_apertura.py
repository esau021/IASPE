"""Fichas de desglose de ingresos de créditos. No modifica modelos ni inputs.

Se aplica a cada resultado del motor (base, laboratorio, escenarios) antes de
publicarlo, utilizando exactamente las participaciones del archivo de apertura.
"""
from __future__ import annotations
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SHARES_FILE = HERE / 'data' / 'apertura_ingresos_creditos.json'
APERTURA = HERE.parent.parent / 'IASPE' / 'Modelos financieros' / 'Estado de Resultados' / '16_Ingresos_por_intereses_Falabella' / '05_Apertura_Revolving_No_Revolving'


def incorporar(registry: dict):
    if '16_creditos' not in registry:
        return
    split = json.loads(SHARES_FILE.read_text(encoding='utf-8'))
    sources = [str(APERTURA / 'Output' / 'Pronostico.xlsx'),
               str(APERTURA / 'Input' / 'Libro1.xlsx'),
               str(APERTURA / 'Script' / 'Apertura_ingresos_creditos.py'),
               str(SHARES_FILE)]
    main = registry['16_creditos']
    for mid, is_rev in [('16_rev', True), ('16_nrev', False)]:
        series = []
        for row in main['annual']:
            year = int(row['year'])
            if year < 2025 or str(year) not in split['shares'] or row['value'] is None:
                continue
            s = float(split['shares'][str(year)])
            credit = float(row['value'])
            rev = credit * s
            value = rev if is_rev else credit-rev
            # REV 2025 es un dato IASPE observado; NREV+otros 2025 es la
            # diferencia de dos cifras observadas (no equivale al NREV puro).
            status = 'observed' if year == 2025 else ('assumed' if year == 2026 else 'forecast')
            series.append(dict(year=year, date=f'{year}-12-31', value=value,
                               status=status,
                               observed=value if status=='observed' else None,
                               assumed=value if status=='assumed' else None,
                               forecast=value if status=='forecast' else None,
                               capitalShare=float(split['capital_shares'][str(year)]),
                               incomeShare=s, creditTotal=credit,
                               revIncome=rev, otherIncome=(float(split['iasc']['2025']['otros']) if year==2025 else None)))
        registry[mid] = {
            'id': mid,
            'name': ('Ingresos por créditos de consumo revolvente' if is_rev
                     else 'Ingresos por créditos de consumo no revolvente y residual'),
            'unit': 'S/ millones', 'frequency': 'annual', 'kind': 'calculated',
            'group': 'Estado de resultados', 'role': 'Componente',
            'method': 'Apertura calculada de M16 con participaciones de capital de Libro1.xlsx e ingresos observados del IASPE 2025; no es una regresión independiente',
            'annual': series, 'monthly': [], 'sourceFiles': sources,
            'dependencies': ['16_creditos'],
            'inputs': [{'id':'16_creditos', 'name':'Ingresos totales por créditos (Modelo 16)', 'lag':0},
                       {'name':'Participación revolvente anual, calculada desde Libro1.xlsx y el Anexo IASPE 2025', 'lag':0}],
            'coefficients': [], 'statistics': {}, 'status': main.get('status','ok'),
            'canUpdate': True, 'scenarioSupport': True, 'reestimated': False,
            'equationTex': (r'I_t^{REV}=I_t^{creditos}\,p_t^{REV}' if is_rev
                            else r'I_t^{NREV+otros}=I_t^{creditos}(1-p_t^{REV})'),
            'financialIdentityTex': '',
            'aperturaBase': {'capital2024': float(split['capital_shares']['2024']),
                             'capital2025': float(split['capital_shares']['2025']),
                             'capital2026': float(split['capital_shares']['2026']),
                             'ingreso2025': float(split['shares']['2025']),
                             'incrementoAnualPp': float(split['validation']['paso_anual_pp']),
                             'crecimientoRevolving2026': float(split['validation']['crecimiento_2026_revolving']),
                             'crecimientoCuotas2026': float(split['validation']['crecimiento_2026_cuotas']),
                             'otros2025': float(split['iasc']['2025']['otros'])},
            'economicRationale': ('Se distribuye el ingreso crediticio total a partir de la participación efectivamente observada en 2025, actualizada mediante los cambios en la composición de capital revolvente. No se estima una tasa por segmento.' if is_rev else
                                  'El residual se calcula como diferencia respecto de los ingresos revolventes para conservar exactamente la identidad del total. Incluye otros ingresos crediticios no desagregados y no representa un pronóstico econométrico autónomo.'),
            'differences': []
        }
