"""M49: apertura de amortizaciones TC, RappiCash y préstamos efectivos."""
from pathlib import Path
import json
import sys
from artifact_tool import Blob, SpreadsheetFile, Workbook

mod = Path(__file__).resolve().parent.parent
sistema = mod.parents[4] / 'Dashboard' / 'Sistema'
sys.path.insert(0, str(sistema))
import motor

# Histórico del Banco: únicamente movimientos observados, sin pronósticos comerciales.
source = SpreadsheetFile.import_xlsx(Blob.load(str(mod / 'Input' / 'Base_productos.xlsx')))
values = source.worksheets.get_item('Historico').get_range('A2:E7').values
hist = {int(r[0]): [float(v) for v in r[1:]] for r in values}
if sorted(hist) != list(range(2020, 2026)):
    raise ValueError('Se requieren los años 2020-2025 para reconstruir las salidas.')

scenario_file = sistema / 'data' / 'iasc_escenarios_2026_2028.json'
scenarios = json.loads(scenario_file.read_text(encoding='utf-8'))
macro = {'Base': {}, 'Estrés': scenarios['estres']['macro'],
         'Estrés severo': scenarios['estres_severo']['macro']}
models = {}
for label, changes in macro.items():
    result = motor.calculate(changes)
    if result.get('warnings'):
        raise RuntimeError(f'{label}: {result["warnings"]}')
    models[label] = {m['id']: m for m in result['models']}

def value(label, mid, year):
    return float(next(r['value'] for r in models[label][mid]['annual'] if int(r['year']) == year))

wb = Workbook.create()
s = wb.worksheets.add('Anual')
s.get_range('A1:P1').values = [[
    'Año','Condición','Compras TC (S/ MM)','Saldo TC (S/ MM)',
    'Disp. RC (S/ MM)','Saldo RC (S/ MM)','Salidas TC (S/ MM)',
    'Salidas RC (S/ MM)','Part. RC','Δ RC (pp)',
    'Amort. REV M49 (S/ MM)','Amort. TC (S/ MM)','Amort. RC (S/ MM)',
    'Amort. PE (S/ MM)','Total M49 (S/ MM)','Control (S/ MM)']]
rows = []
for year in range(2020, 2031):
    if year in hist:
        compras_tc, saldo_tc, disp_rc, saldo_rc = hist[year]
    else:
        compras_tc = saldo_tc = disp_rc = saldo_rc = None
    condition = 'Semilla histórica' if year == 2020 else 'Histórico' if year <= 2025 else 'Cierre estimado' if year == 2026 else 'Proyección IASPE'
    rows.append([year, condition, compras_tc, saldo_tc, disp_rc, saldo_rc,
                 None, None, None, None,
                 value('Base','49_rev',year) if year >= 2025 else None,
                 None, None,
                 value('Base','49_nrev',year) if year >= 2025 else None,
                 None, None])
s.get_range('A2:P12').values = rows
for year in range(2021, 2026):
    r = year - 2018
    s.get_range(f'G{r}').formulas = [[f'=D{r-1}+C{r}-D{r}']]
    s.get_range(f'H{r}').formulas = [[f'=F{r-1}+E{r}-F{r}']]
    s.get_range(f'I{r}').formulas = [[f'=H{r}/(G{r}+H{r})']]
    if year >= 2022:
        s.get_range(f'J{r}').formulas = [[f'=(I{r}-I{r-1})*100']]
for year in range(2026, 2031):
    r = year - 2018
    s.get_range(f'I{r}').formulas = [[f'=I{r-1}+AVERAGE($J$5:$J$7)/100']]
    s.get_range(f'J{r}').formulas = [[f'=(I{r}-I{r-1})*100']]
for year in range(2025, 2031):
    r = year - 2018
    s.get_range(f'L{r}').formulas = [[f'=K{r}*(1-I{r})']]
    s.get_range(f'M{r}').formulas = [[f'=K{r}-L{r}']]
    s.get_range(f'O{r}').formulas = [[f'=SUM(L{r}:N{r})']]
    s.get_range(f'P{r}').formulas = [[f'=O{r}-K{r}-N{r}']]

sc = wb.worksheets.add('Escenarios')
sc.get_range('A1:J1').values = [[
    'Escenario','Año','Part. RC','Amort. REV M49 (S/ MM)','Amort. TC (S/ MM)',
    'Amort. RC (S/ MM)','Amort. PE (S/ MM)','Total productos (S/ MM)',
    'Total M49 (S/ MM)','Control (S/ MM)']]
base_rows=[]
for label in macro:
    for year in range(2025, 2031):
        base_rows.append([label,year,None,value(label,'49_rev',year),None,None,
                          value(label,'49_nrev',year),None,value(label,'49',year),None])
sc.get_range(f'A2:J{len(base_rows)+1}').values = base_rows
for idx,(label,year, *_rest) in enumerate(base_rows,2):
    yr_row = year - 2018
    sc.get_range(f'C{idx}').formulas = [[f'=Anual!I{yr_row}']]
    sc.get_range(f'E{idx}').formulas = [[f'=D{idx}*(1-C{idx})']]
    sc.get_range(f'F{idx}').formulas = [[f'=D{idx}-E{idx}']]
    sc.get_range(f'H{idx}').formulas = [[f'=SUM(E{idx}:G{idx})']]
    sc.get_range(f'J{idx}').formulas = [[f'=H{idx}-I{idx}']]

# Formato común; los importes se muestran en S/ millones y los controles en cero.
for sh,limit,ends in [(s,12,'P'),(sc,len(base_rows)+1,'J')]:
    sh.get_range(f'A1:{ends}{limit}').format = {
        'font': {'name':'Calibri'}, 'horizontal_alignment':'justify','vertical_alignment':'center'}
    sh.get_range(f'A1:{ends}1').format = {
        'fill':'#F2F2F2','font':{'name':'Calibri','bold':True},
        'wrap_text':True,'row_height':37,'horizontal_alignment':'justify'}
    sh.freeze_panes.freeze_rows(1)
s.get_range('A:A').format.column_width = 11
s.get_range('B:B').format.column_width = 20
for c in 'CDEFGHKLMNOP':s.get_range(f'{c}:{c}').format.column_width = 21
s.get_range('I:I').format.column_width = 13
s.get_range('J:J').format.column_width = 14
s.get_range('B2:B12').format.horizontal_alignment = 'left'
s.get_range('C2:H12').set_number_format('#,##0.00;[Red](#,##0.00);–')
s.get_range('I3:I12').set_number_format('0.00%')
s.get_range('J4:J12').set_number_format('0.0000" pp"')
s.get_range('K2:P12').set_number_format('#,##0.00;[Red](#,##0.00);–')
sc.get_range('A:A').format.column_width = 22
sc.get_range('B:B').format.column_width = 11
for c in 'DEFGHIJ':sc.get_range(f'{c}:{c}').format.column_width = 23
sc.get_range('C:C').format.column_width = 14
sc.get_range(f'C2:C{len(base_rows)+1}').set_number_format('0.00%')
sc.get_range(f'D2:J{len(base_rows)+1}').set_number_format('#,##0.00;[Red](#,##0.00);–')

out = mod / 'Output' / 'Pronostico.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print('M49 por productos:', out)
