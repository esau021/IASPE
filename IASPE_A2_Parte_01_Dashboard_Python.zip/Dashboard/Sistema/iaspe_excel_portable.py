"""Adaptador XLSX local para la persistencia de IASPE en Windows.

Compatible con la pequeña superficie de SpreadsheetFile que utiliza IASPE:
no requiere artifact_tool, preserva fórmulas, estilos y cachés de resultados,
y modifica únicamente las celdas afectadas dentro de los XML originales.
La validación de negocio continúa siendo responsabilidad de persistencia_modelos.
"""
from __future__ import annotations

import ast
import io
import math
import os
import statistics
import zipfile
from collections import defaultdict
from pathlib import Path

from lxml import etree
from openpyxl import load_workbook
from openpyxl.formula import Tokenizer
from openpyxl.utils.cell import get_column_letter, range_boundaries

_MAIN = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
_REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
_PACKAGE = 'http://schemas.openxmlformats.org/package/2006/relationships'
_NS = '{'+_MAIN+'}'


def _numeric(v):
    if v is None or v == '':return 0
    return v


def _flatten(values):
    for x in values:
        if isinstance(x, (list,tuple)):
            yield from _flatten(x)
        elif isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x):
            yield x


def _translate(formula, sheet):
    parts=[]
    for item in Tokenizer(formula).items:
        t,kind,sub=item.value,item.type,item.subtype
        if kind=='OPERAND':
            if sub=='RANGE':
                if '!' in t:
                    name,ref=t.rsplit('!',1)
                    name=name.strip("'")
                else:name,ref=sheet,t
                if '[' in name or '#' in ref:
                    raise ValueError('Referencia externa sin cálculo local: '+t)
                ref=ref.replace('$','')
                parts.append(f'{"RNG" if ":" in ref else "REF"}({name!r},{ref!r})')
            elif sub=='TEXT':parts.append(repr(t[1:-1].replace('""','"')))
            elif sub=='LOGICAL':parts.append('True' if t.upper()=='TRUE' else 'False')
            elif sub=='NUMBER':parts.append(t)
            else:raise ValueError('Operando de Excel no admitido: '+t)
        elif kind=='FUNC':
            if sub=='OPEN':parts.append(t[:-1].upper()+'X(')
            else:parts.append(')')
        elif kind=='PAREN':parts.append(t)
        elif kind=='SEP':parts.append(',' if sub=='ARG' else ';')
        elif kind in ('OPERATOR-INFIX','OPERATOR-PREFIX'):
            parts.append({'=':'==','<>':'!=','^':'**','&':'+'}.get(t,t))
        else:raise ValueError('Token de Excel no admitido: '+t)
    return ''.join(parts)


class _SheetRange:
    def __init__(self,book,sheet,address):
        self.book,self.sheet,self.address=book,sheet,address
        c1,r1,c2,r2=range_boundaries(address)
        self.cells=[[(r,get_column_letter(c)+str(r)) for c in range(c1,c2+1)] for r in range(r1,r2+1)]

    @property
    def values(self):
        return [[self.book.value(self.sheet,addr) for _,addr in row] for row in self.cells]

    @values.setter
    def values(self,data):
        if len(data)!=len(self.cells) or any(len(a)!=len(b) for a,b in zip(data,self.cells)):
            raise ValueError('Dimensión de rango distinta de la tabla de valores.')
        for row, entries in zip(self.cells,data):
            for (_,addr),v in zip(row,entries):self.book.set(self.sheet,addr,v)

    @property
    def formulas(self):
        return [[(self.book.formula(self.sheet,addr) or '') for _,addr in row] for row in self.cells]

    @formulas.setter
    def formulas(self,data):
        if len(data)!=len(self.cells) or any(len(a)!=len(b) for a,b in zip(data,self.cells)):
            raise ValueError('Dimensión de fórmulas no coincide con rango.')
        for row,entries in zip(self.cells,data):
            for (_,addr),v in zip(row,entries):self.book.set(self.sheet,addr,str(v))

    def set_number_format(self,format_code):
        # La plantilla incluye el formato requerido en las filas previas. Cuando se
        # añaden meses se hereda el estilo de la misma columna y fila anterior.
        self.book.requested_formats[(self.sheet,self.address)]=format_code


class _Worksheet:
    def __init__(self,book,name):self.book,self.name=book,name
    def get_range(self,address):return _SheetRange(self.book,self.name,address)


class _Collection:
    def __init__(self,book):self.book=book
    @property
    def items(self):return [_Worksheet(self.book,n) for n in self.book.sheets]
    def get_item(self,name):
        if name not in self.book.sheets:raise KeyError(name)
        return _Worksheet(self.book,name)


class _Workbook:
    def __init__(self,path):
        self.path=Path(path)
        self.original=load_workbook(io.BytesIO(self.path.read_bytes()),read_only=False,data_only=False,keep_links=True)
        self.cached=load_workbook(io.BytesIO(self.path.read_bytes()),read_only=False,data_only=True,keep_links=True)
        self.sheets=set(self.original.sheetnames)
        self.worksheets=_Collection(self)
        self.overrides={}
        self.requested_formats={}
        self._calc_cache={}
        self._inprogress=set()
        self._formula_code={}
        self._cached_formulas={}

    def raw(self,sheet,addr):
        if (sheet,addr) in self.overrides:return self.overrides[sheet,addr]
        return self.original[sheet][addr].value

    def formula(self,sheet,addr):
        val=self.raw(sheet,addr)
        return val if isinstance(val,str) and val.startswith('=') else ''

    def set(self,sheet,addr,value):
        old=self.raw(sheet,addr)
        if old==value:return
        self.overrides[sheet,addr]=value
        self._calc_cache.clear()

    def value(self,sheet,addr):
        formula=self.formula(sheet,addr)
        if not formula:return self.raw(sheet,addr)
        key=(sheet,addr)
        if key in self._calc_cache:return self._calc_cache[key]
        if key in self._inprogress:raise ValueError(f'Referencia circular {sheet}!{addr}')
        cached=self.cached[sheet][addr].value
        if not self.overrides:return cached
        self._inprogress.add(key)
        try:
            try:value=self._evaluate(formula,sheet)
            except Exception as exc:
                if key in self.overrides or cached is None:raise ValueError(f'No se pudo recalcular {sheet}!{addr}: {exc}') from exc
                value=cached
            self._calc_cache[key]=value
            return value
        finally:self._inprogress.discard(key)

    def _evaluate(self,formula,sheet):
        code=self._formula_code.get((sheet,formula))
        if code is None:
            code=ast.parse(_translate(formula,sheet),mode='eval').body
            self._formula_code[sheet,formula]=code

        def REF(name,ref):
            if name not in self.sheets:raise ValueError('Hoja desconocida '+name)
            return _numeric(self.value(name,ref))

        def RNG(name,ref):
            if name not in self.sheets:raise ValueError('Hoja desconocida '+name)
            c1,r1,c2,r2=range_boundaries(ref)
            return [self.value(name,f'{get_column_letter(c)}{r}') for r in range(r1,r2+1) for c in range(c1,c2+1)]

        def averageif(items, criterion, values=None):
            other=items if values is None else values
            selected=[float(v) for k,v in zip(items,other)
                      if str(k or '').strip().casefold()==str(criterion or '').strip().casefold()
                      and isinstance(v,(float,int)) and not isinstance(v,bool)]
            if not selected:raise ValueError('AVERAGEIF: ningún dato coincide con el criterio')
            return statistics.mean(selected)

        functions={'REF':REF,'RNG':RNG,'AVERAGEIFX':averageif,
            'SUMX':lambda *a:sum(_flatten(a)),
            'AVERAGEX':lambda *a:statistics.mean(_flatten(a)),
            'MEDIANX':lambda *a:statistics.median(_flatten(a)),
            'MINX':lambda *a:min(_flatten(a)),
            'MAXX':lambda *a:max(_flatten(a)),
            'ABSX':abs,'EXPX':math.exp,'LNX':math.log,
            'ROUNDX':lambda v,n=0:math.copysign(math.floor(abs(float(v))*10**int(n)+0.5)/10**int(n),float(v))}

        def eva(node):
            if isinstance(node,ast.Constant):return node.value
            if isinstance(node,ast.UnaryOp):
                v=eva(node.operand)
                return +v if isinstance(node.op,ast.UAdd) else -v
            if isinstance(node,ast.BinOp):
                a,b=eva(node.left),eva(node.right)
                if isinstance(node.op,ast.Add):return a+b
                if isinstance(node.op,ast.Sub):return a-b
                if isinstance(node.op,ast.Mult):return a*b
                if isinstance(node.op,ast.Div):return a/b
                if isinstance(node.op,ast.Pow):return a**b
                raise ValueError('Operador')
            if isinstance(node,ast.Compare):
                a=eva(node.left)
                for op,term in zip(node.ops,node.comparators):
                    b=eva(term)
                    truth=(a>=b if isinstance(op,ast.GtE) else a<=b if isinstance(op,ast.LtE)
                           else a>b if isinstance(op,ast.Gt) else a<b if isinstance(op,ast.Lt)
                           else a==b if isinstance(op,ast.Eq) else a!=b)
                    if not truth:return False
                    a=b
                return True
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name):
                fun=node.func.id.upper()
                if fun=='COUNTX':
                    values=[]
                    for candidate in node.args:
                        # COUNT de una referencia vacía no cuenta el cero que
                        # REF utiliza exclusivamente para la aritmética.
                        if (isinstance(candidate,ast.Call) and isinstance(candidate.func,ast.Name)
                            and candidate.func.id=='REF' and len(candidate.args)==2):
                            name,ref=(eva(x) for x in candidate.args)
                            values.append(self.value(name,ref))
                        else:values.append(eva(candidate))
                    return sum(1 for _ in _flatten(values))
                if fun=='INDEXX':
                    if not 2<=len(node.args)<=3:raise ValueError('INDEX: número de argumentos no admitido')
                    candidate=node.args[0];values=eva(candidate)
                    if not isinstance(values,list):raise ValueError('INDEX requiere un rango')
                    nrows,ncols=len(values),1
                    if (isinstance(candidate,ast.Call) and isinstance(candidate.func,ast.Name)
                        and candidate.func.id=='RNG' and len(candidate.args)==2):
                        _,ref=(eva(x) for x in candidate.args)
                        c1,r1,c2,r2=range_boundaries(ref);nrows,ncols=r2-r1+1,c2-c1+1
                    row=eva(node.args[1]);col=eva(node.args[2]) if len(node.args)==3 else 1
                    if isinstance(row,bool) or isinstance(col,bool) or int(row)!=row or int(col)!=col:
                        raise ValueError('INDEX requiere índices enteros')
                    row,col=int(row),int(col)
                    if len(node.args)==2 and nrows==1:row,col=1,row
                    if not 1<=row<=nrows or not 1<=col<=ncols:
                        raise ValueError('INDEX fuera del rango')
                    return _numeric(values[(row-1)*ncols+col-1])
                if fun=='ISNUMBERX':
                    candidate=node.args[0]
                    # REF convierte blancos a cero para cálculos aritméticos.
                    # ISNUMBER debe conservar la distinción entre vacío y 0.
                    if (isinstance(candidate,ast.Call)
                        and isinstance(candidate.func,ast.Name)
                        and candidate.func.id=='REF'
                        and len(candidate.args)==2):
                        name,ref=(eva(x) for x in candidate.args)
                        tested=self.value(name,ref)
                    else:tested=eva(candidate)
                    return isinstance(tested,(float,int)) and not isinstance(tested,bool)
                if fun=='IFX':return eva(node.args[1]) if eva(node.args[0]) else eva(node.args[2])
                if fun=='IFERRORX':
                    try:return eva(node.args[0])
                    except (ArithmeticError,ValueError,TypeError,OverflowError):return eva(node.args[1])
                if fun in functions:return functions[fun](*(eva(x) for x in node.args))
            raise ValueError('Operación no soportada '+ast.dump(node)[:120])
        return eva(code)

    def close(self):
        self.original.close();self.cached.close()

    def save(self,destination):
        """Modificar XML del libro original, conservando fórmulas/estilos originales."""
        destination=Path(destination)
        # Identificar hojas en el archivo original.
        with zipfile.ZipFile(self.path,'r') as zin:
            root=etree.fromstring(zin.read('xl/workbook.xml'))
            rel=etree.fromstring(zin.read('xl/_rels/workbook.xml.rels'))
            relmap={r.get('Id'):r.get('Target') for r in rel.findall('{'+_PACKAGE+'}Relationship')}
            mapping={}
            for s in root.findall('.//'+_NS+'sheet'):
                target=relmap[s.get('{'+_REL+'}id')]
                mapping[s.get('name')]=target.lstrip('/') if target.startswith('/') else 'xl/'+target.lstrip('/')
            # Resolver rutas usuales ../ o carpetas a partir de xl/.
            mapping={k:os.path.normpath(v).replace('\\','/') for k,v in mapping.items()}
            by_sheet=defaultdict(dict)
            for (sheet,addr),value in self.overrides.items():by_sheet[sheet][addr]=value
            # Fórmulas: actualizar el cache si sus dependencias cambiaron.
            # Se evalúan al exportar, antes de publicar nada al usuario.
            for sheet in self.sheets:
                for row in self.original[sheet]:
                    for cell in row:
                        if cell.data_type!='f':continue
                        key=(sheet,cell.coordinate)
                        if key in self.overrides:continue
                        before=self.cached[sheet][cell.coordinate].value
                        try:after=self.value(sheet,cell.coordinate)
                        except (ValueError,ArithmeticError,TypeError):continue
                        if after!=before and (not isinstance(after,(int,float)) or not isinstance(before,(int,float)) or abs(float(after)-float(before))>1e-10):
                            by_sheet[sheet][cell.coordinate]=cell.value
            patches={mapping[sheet]:updates for sheet,updates in by_sheet.items() if updates}

            with zipfile.ZipFile(destination,'w') as zout:
                for info in zin.infolist():
                    data=zin.read(info.filename)
                    if info.filename in patches:
                        xml=etree.fromstring(data)
                        sheet=next(k for k,v in mapping.items() if v==info.filename)
                        updates=patches[info.filename]
                        sheetData=xml.find(_NS+'sheetData')
                        rows={int(r.get('r')):r for r in sheetData.findall(_NS+'row')}
                        for address,value in updates.items():
                            from openpyxl.utils.cell import coordinate_from_string
                            col,rownum=coordinate_from_string(address)
                            r=rows.get(rownum)
                            if r is None:
                                r=etree.Element(_NS+'row',r=str(rownum))
                                before=next((o for o in sheetData if o.tag==_NS+'row' and int(o.get('r'))>rownum),None)
                                if before is None:sheetData.append(r)
                                else:sheetData.insert(sheetData.index(before),r)
                                rows[rownum]=r
                            c=next((a for a in r if a.tag==_NS+'c' and a.get('r')==address),None)
                            if c is None:
                                c=etree.Element(_NS+'c',r=address)
                                # Estilo del mismo campo en la fila anterior.
                                precedent=rows.get(rownum-1)
                                sample=next((a for a in precedent if a.tag==_NS+'c' and a.get('r')==f'{col}{rownum-1}'),None) if precedent is not None else None
                                if sample is not None and sample.get('s') is not None:c.set('s',sample.get('s'))
                                ordinal=lambda a:range_boundaries(a+str(rownum))[0]
                                idx=next((i for i,other in enumerate(r) if other.tag==_NS+'c' and ordinal(other.get('r').rstrip('0123456789'))>ordinal(col)),len(r))
                                r.insert(idx,c)
                            for tag in (_NS+'f',_NS+'v',_NS+'is'):
                                for child in c.findall(tag):c.remove(child)
                            if isinstance(value,str) and value.startswith('='):
                                f=etree.SubElement(c,_NS+'f');f.text=value[1:]
                                val=self.value(sheet,address)
                                if isinstance(val,str):c.set('t','str')
                                else:c.attrib.pop('t',None)
                            else:
                                val=value
                                if isinstance(val,str):c.set('t','inlineStr');e=etree.SubElement(c,_NS+'is');etree.SubElement(e,_NS+'t').text=val;continue
                                elif isinstance(val,bool):c.set('t','b')
                                else:c.attrib.pop('t',None)
                            if val is not None:
                                v=etree.SubElement(c,_NS+'v')
                                if isinstance(val,bool):v.text='1' if val else '0'
                                elif isinstance(val,(int,float)):v.text=format(val,'.16g')
                                else:v.text=str(val)
                        data=etree.tostring(xml,encoding='utf-8',xml_declaration=True)
                    zout.writestr(info,data)
        return destination


class Blob:
    @staticmethod
    def load(path):return Path(path)


class SpreadsheetFile:
    @staticmethod
    def import_xlsx(path):return _Workbook(path)
    @staticmethod
    def export_xlsx(book):
        class _Exporter:
            def save(self,path):book.save(path)
        return _Exporter()
