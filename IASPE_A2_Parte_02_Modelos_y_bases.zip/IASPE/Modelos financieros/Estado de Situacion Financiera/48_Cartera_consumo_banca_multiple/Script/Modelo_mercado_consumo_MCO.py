"""IASPE: proyección anual de cartera de consumo de banca múltiple (MCO).

Requiere artefact_tool, numpy, statsmodels. Input exclusivamente histórico + cierre supuesto 2026.
Los supuestos macroeconómicos 2027–2030 se leen de Script/escenario_base.json,
que reproduce el escenario macroeconómico aprobado en los modelos M03/M05/M06.
El archivo original del Dashboard NO se modifica.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
import statsmodels.api as sm
from artifact_tool import Blob, SpreadsheetFile, Workbook

HERE = Path(__file__).resolve().parent
MOD = HERE.parent
IASPE = HERE.parents[3]
ORIG = IASPE / 'Modelos financieros' / 'Estado de Situacion Financiera'
INPUT = MOD / 'Input' / 'Base_modelo.xlsx'
OUT = MOD / 'Output'
OUT.mkdir(exist_ok=True)

base = SpreadsheetFile.import_xlsx(Blob.load(str(INPUT)))
annual_rows = base.worksheets.get_item('Anual').get_range('A2:H18').values
series = {}
for row in annual_rows:
    year = int(row[0]); series[year] = {'tc':float(row[1]),'nrev':float(row[2]),
        'total':float(row[3]),'pbi':float(row[4]),'desempleo':float(row[5]),'tpm':float(row[6])}
assert set(series) == set(range(2010,2027))
close_rows = base.worksheets.get_item('Cierre_2026').get_range('A2:F4').values
close_tc = float(close_rows[0][1]) * float(close_rows[0][3]) / float(close_rows[0][2])
close_nr = float(close_rows[1][1]) * float(close_rows[1][3]) / float(close_rows[1][2])
assert abs(close_tc-series[2026]['tc'])<1e-6
assert abs(close_nr-series[2026]['nrev'])<1e-6
assert abs(close_tc+close_nr-series[2026]['total'])<1e-6
for year in range(2010,2026):
    assert abs(series[year]['tc']+series[year]['nrev']-series[year]['total'])<1e-5

scen = json.loads((HERE/'escenario_base.json').read_text('utf-8'))
for sy, vals in scen['macros'].items():
    year = int(sy)
    series[year] = {'pbi':float(vals['pbi']), 'desempleo':float(vals['desempleo']),
                    'tpm':float(vals['tpm']), 'total': None}

def explanatory(y):
    return [1.0, series[y]['pbi'],
            series[y-1]['desempleo']-series[y-2]['desempleo'], series[y-1]['tpm']]

def g(y):
    return 100 * math.log(series[y]['total'] / series[y-1]['total'])

training_years = list(range(2012,2027))
X = np.asarray([explanatory(y) for y in training_years],float)
Y = np.asarray([g(y) for y in training_years],float)
fit = sm.OLS(Y,X).fit()
hac = fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
for year in range(2027,2031):
    gp = float(np.asarray(explanatory(year)) @ fit.params)
    series[year]['total']=float(series[year-1]['total']*math.exp(gp/100))

backtests=[]
for year in range(2022,2026):
    hist = list(range(2012,year))
    r = sm.OLS(np.asarray([g(k) for k in hist]),
               np.asarray([explanatory(k) for k in hist],float)).fit()
    pred_g = float(np.asarray(explanatory(year)) @ r.params)
    pred_s = series[year-1]['total'] * math.exp(pred_g/100)
    backtests.append((year,pred_s,series[year]['total'],abs(pred_s / series[year]['total']-1)))

bf = {}
for code, subdir in [('m05','05_Saldo_bruto_tarjetas_Falabella'),
                      ('m06','06_Prestamos_consumo_no_revolventes_Falabella')]:
    p = ORIG / subdir / 'Output' / 'Pronostico.xlsx'
    w = SpreadsheetFile.import_xlsx(Blob.load(str(p)))
    a = w.worksheets.get_item('Anual').get_range('A2:B17').values
    for row in a:
        if isinstance(row[0],(int,float)) and isinstance(row[1],(int,float)):
            bf.setdefault(int(row[0]),{})[code]=float(row[1])

# Salida 1, sin gráficos ni formatos adicionales.
wb = Workbook.create()
s = wb.worksheets.add('Anual')
s.get_range('A1:L1').values=[['Año','Condición','Consumo BM (S/ MM)', 'Crec. log (%)',
    'PBI real (%)','Δ desempleo t-1 (pp)','TPM t-1 (%)','BF M05 (S/ MM)',
    'BF M06 (S/ MM)','BF total (S/ MM)','Cuota BF (%)', 'BF con cuota 2025 fija (S/ MM)']]
for year in range(2010,2031):
    row = year-2008
    mark = 'Observado' if year<=2025 else 'Cierre supuesto' if year==2026 else 'MCO escenario base'
    ef = explanatory(year) if year>=2012 else [1,None,None,None]
    s.get_range(f'A{row}:L{row}').values=[[year, mark,series[year]['total'],None,
        ef[1],ef[2],ef[3],bf.get(year,{}).get('m05'),bf.get(year,{}).get('m06'), None,None,None]]
    if year>=2011:
        s.get_range(f'D{row}').formulas=[[f'=100*LN(C{row}/C{row-1})']]
    if year in bf and all(k in bf[year] for k in ['m05','m06']):
        s.get_range(f'J{row}').formulas=[[f'=SUM(H{row}:I{row})']]
        s.get_range(f'K{row}').formulas=[[f'=J{row}/C{row}']]
        s.get_range(f'L{row}').formulas=[[f'=C{row}*$K$17']]
s.get_range('A1:L1').format={'font':{'bold':True},'fill':'#EEEEEE','row_height':32,'vertical_alignment':'center','wrap_text':True}
s.get_range('A1:A22').format.column_width=10
s.get_range('B1:B22').format.column_width=24
s.get_range('C1:C22').format.column_width=22
s.get_range('D1:G22').format.column_width=20
s.get_range('H1:J22').format.column_width=19
s.get_range('K1:L22').format.column_width=22
s.get_range('C2:C22').set_number_format('#,##0.00;[Red](#,##0.00);-')
s.get_range('H2:J22').set_number_format('#,##0.00;[Red](#,##0.00);-')
s.get_range('L2:L22').set_number_format('#,##0.00;[Red](#,##0.00);-')
s.get_range('D2:G22').set_number_format('0.00;[Red](0.00);-')
s.get_range('K2:K22').set_number_format('0.00%')
s.freeze_panes.freeze_rows(1)
# Formato estándar IASPE: Calibri y justificación; solo Condición a la izquierda.
s.get_range('A1:L22').format={'font':{'name':'Calibri'},'horizontal_alignment':'justify','vertical_alignment':'center'}
s.get_range('B2:B22').format.horizontal_alignment='left'
s.get_range('A1:L1').format={'fill':'#F2F2F2','font':{'name':'Calibri','bold':True},'horizontal_alignment':'justify','vertical_alignment':'center'}
SpreadsheetFile.export_xlsx(wb).save(str(OUT/'Pronostico.xlsx'))

# Salida 2: resultados y comprobación mínima en una única hoja.
wb2 = Workbook.create();ss=wb2.worksheets.add('MCO')
ss.get_range('A1:B10').values=[['Indicador','Valor'],['Muestra','2012–2026 (cierre supuesto 2026)'],
    ['Observaciones',int(fit.nobs)],['R²',float(fit.rsquared)],
    ['R² ajustado',float(fit.rsquared_adj)],['AIC',float(fit.aic)],
    ['BIC',float(fit.bic)],['Durbin-Watson',float(sm.stats.stattools.durbin_watson(fit.resid))],
    ['MAPE retrospectivo 2022–2025',float(np.mean([p[3] for p in backtests]))],
    ['Fuente','SBS B-2389; BCRP e IASPE M03']]
ss.get_range('A12:F12').values=[['Variable','Coeficiente','Error estándar MCO','p-valor MCO','Error estándar HAC(1)','p-valor HAC(1)']]
labels=['Constante','PBI real contemporáneo (%)','Δ desempleo t−1 (pp)','TPM diciembre t−1 (%)']
for i,name in enumerate(labels):
 ss.get_range(f'A{13+i}:F{13+i}').values=[[name,float(fit.params[i]),float(fit.bse[i]),float(fit.pvalues[i]),float(hac.bse[i]),float(hac.pvalues[i])]]
ss.get_range('A19:D19').values=[['Año evaluación','Pronóstico con datos hasta t−1','Observado','Error absoluto (%)']]
for i,(year,pred,actual,err) in enumerate(backtests):
 ss.get_range(f'A{20+i}:D{20+i}').values=[[year,float(pred),float(actual),float(100*err)]]
for r in ['A1:B1','A12:F12','A19:D19']:
 ss.get_range(r).format={'font':{'bold':True},'fill':'#EEEEEE','wrap_text':True,'row_height':27}
ss.get_range('A1:A24').format.column_width=37
ss.get_range('B1:B24').format.column_width=39
ss.get_range('C1:D24').format.column_width=24
ss.get_range('E1:F24').format.column_width=24
ss.get_range('B4:B9').set_number_format('0.0000')
ss.get_range('B13:F16').set_number_format('0.0000;[Red](0.0000);-')
ss.get_range('B20:D23').set_number_format('#,##0.00;[Red](#,##0.00);-')
ss.freeze_panes.freeze_rows(1)
ss.get_range('A1:F23').format={'font':{'name':'Calibri'},'horizontal_alignment':'justify','vertical_alignment':'center'}
for h in ('A1:B1','A12:F12','A19:D19'):
 ss.get_range(h).format={'fill':'#F2F2F2','font':{'name':'Calibri','bold':True},'horizontal_alignment':'justify','vertical_alignment':'center'}
SpreadsheetFile.export_xlsx(wb2).save(str(OUT/'Resultados_MCO.xlsx'))

check = SpreadsheetFile.import_xlsx(Blob.load(str(OUT/'Pronostico.xlsx')))
sl=check.worksheets.get_item('Anual')
for y in [2025,2026,2027,2030]:
    row=y-2008
    v=sl.get_range(f'A{row}:L{row}').values[0]
    assert abs(v[2]-series[y]['total'])<1e-5
    assert v[9] is not None and v[10] is not None
    assert abs(v[10]-v[9]/v[2])<1e-9
    print(y,'mercado',round(v[2],2),'BF',round(v[9],2),'cuota',round(v[10]*100,3))
print('n=',len(training_years),'MAPE_rolling',round(100*np.mean([z[3] for z in backtests]),3),
      'R2_adj',round(fit.rsquared_adj,4),'p_values',np.round(fit.pvalues,5))
