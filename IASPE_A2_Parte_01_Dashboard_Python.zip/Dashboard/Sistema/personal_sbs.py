"""Personal SBS B-2305. Serie mensual por entidad y categoría laboral."""
from __future__ import annotations
import csv
import os
from pathlib import Path
from functools import lru_cache
import math
from instituciones_sbs import BANKS, category_at, entity_metadata, match_entity

ROOT=Path(__file__).resolve().parent
DATA='personal_banca_mensual.csv'
FINANCE='personal_financieras.csv'
RURAL='personal_rurales.csv'
COLUMNS=('personal_total','gerentes','funcionarios','empleados','otros')


def _count(value):
    if value is None or str(value).strip() in ('','-','—'):
        return None
    number=float(value)
    if not math.isfinite(number) or number<0 or not number.is_integer():
        raise ValueError('Conteo de personal no válido')
    return int(number)

def source_path():
    custom=os.getenv('IASPE_PERSONAL_CSV','').strip()
    if custom and Path(custom).is_file(): return Path(custom)
    for p in (ROOT,*list(ROOT.parents)[:4]):
        for rel in [('IASPE','Scraper','Numero_trabajadores','output',DATA),('Scraper','Numero_trabajadores','output',DATA)]:
            candidate=p.joinpath(*rel)
            if candidate.is_file(): return candidate
    return None

@lru_cache(maxsize=3)
def _parse(path,mtime,size,history_mtime,history_size,finance_mtime,finance_size,rural_mtime=0,rural_size=0):
    companies={b:entity_metadata(b) for b in BANKS}
    record=[];seen={};classification_omitted=[]
    historical=Path(path).with_name('personal_historico_2012_2015.csv')
    financial=Path(path).with_name(FINANCE)
    rural=Path(path).with_name(RURAL)
    sources=[Path(path)]+([historical] if historical.is_file() else [])+([financial] if financial.is_file() else [])+([rural] if rural.is_file() else [])
    for file in sources:
      with file.open(encoding='utf-8-sig',newline='') as f:
        for raw in csv.DictReader(f):
            bank=match_entity(raw['banco']);period=raw['periodo']
            if not bank or not (len(period)==7 and period[4]=='-'):continue
            reported=raw.get('sistema','').lower()
            archivo=raw.get('archivo','').upper()
            source_category=('Bancos' if 'B-2305' in archivo else
                             'Empresas financieras' if 'B-3202' in archivo else
                             'Cajas rurales' if 'C-2202' in archivo else
                             'Empresas financieras' if 'financiera' in reported else
                             'Cajas rurales' if 'rural' in reported else None)
            if source_category and source_category!=category_at(bank,period):
                classification_omitted.append({'banco':bank,'periodo':period,'source_category':source_category})
                continue
            try:values={k:_count(raw.get(k)) for k in COLUMNS}
            except (KeyError,TypeError,ValueError):continue
            if values['personal_total'] is None:continue
            if all(values[x] is not None for x in COLUMNS[1:]) and sum(values[x] for x in COLUMNS[1:])!=values['personal_total']:continue
            if (bank,period) in seen:
                if seen[(bank,period)]!=values:
                    raise ValueError(f'Personal SBS ambiguo: {bank}/{period}')
                continue
            seen[(bank,period)]=values
            record.append({'banco':bank,'periodo':period,**values,'fuente':raw.get('archivo',''),
                           'nombre_sbs':raw.get('nombre_sbs',''),
                           'category':category_at(bank,period),'reported_system':raw.get('sistema',''),
                           'hoja':raw.get('hoja',''),'fila_excel':raw.get('fila_excel','')})
    record.sort(key=lambda r:(r['periodo'],r['banco']))
    for b in companies.values():
        rbank=[r for r in record if r['banco']==b['id']]
        b['registros']=len(rbank)
        b['periodo_inicio']=min((r['periodo'] for r in rbank),default=None)
        b['periodo_fin']=max((r['periodo'] for r in rbank),default=None)
        if b['periodo_fin']:
            b.update(entity_metadata(b['id'],b['periodo_fin']))
    return {'ready':bool(record),'periodo_fin':max((r['periodo'] for r in record),default=None),
            'periodo_inicio':min((r['periodo'] for r in record),default=None),
            'bancos':list(companies.values()),'registros':record,
            'fuente':'SBS B-2305 (Banca Múltiple), B-3202 (Empresas Financieras) y C-2202 (Cajas Rurales) · Personal por categoría laboral',
            'unidad':'personas','classification_omitted':classification_omitted,
            'revision':':'.join(map(str,(mtime,size,history_mtime,history_size,finance_mtime,finance_size,rural_mtime,rural_size)))}

def catalog():
    src=source_path()
    if src is None:return {'ready':False,'message':'No se encontró el consolidado de personal SBS en IASPE/Scraper/Numero_trabajadores/output.'}
    stat=src.stat()
    historical=src.with_name('personal_historico_2012_2015.csv')
    old=historical.stat() if historical.is_file() else None
    financial=src.with_name(FINANCE)
    fin=financial.stat() if financial.is_file() else None
    rural=src.with_name(RURAL)
    rur=rural.stat() if rural.is_file() else None
    return _parse(str(src),stat.st_mtime_ns,stat.st_size,old.st_mtime_ns if old else 0,old.st_size if old else 0,fin.st_mtime_ns if fin else 0,fin.st_size if fin else 0,rur.st_mtime_ns if rur else 0,rur.st_size if rur else 0)
