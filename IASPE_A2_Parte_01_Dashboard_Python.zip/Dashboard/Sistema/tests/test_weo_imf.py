"""Tests sin red ni cambios de modelos: WEO Perú, vintage y recuperación de fallos."""
import hashlib
import csv
from io import BytesIO
from io import StringIO
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

from openpyxl import Workbook, load_workbook

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))
import weo_imf as w
import proyecciones_externas as p
from test_proyecciones_externas import Response


def synthetic_release(year, month, *, revision=0, change=None):
    """Fixture controlada, NO publicación real ni evidencia de acceso futuro."""
    wb = Workbook()
    ws = wb.active
    ws.title = 'Countries'
    columns = ['COUNTRY.ID', 'COUNTRY', 'INDICATOR.ID', 'INDICATOR',
               'FREQUENCY', 'SCALE', 'UNIT', 'PUBLICATION_DATE',
               'LATEST_ACTUAL_ANNUAL_DATA', *range(year - 1, year + 6)]
    ws.append(columns)
    for index, code in enumerate(w.CODES):
        values = {key: '' for key in columns}
        values.update({'COUNTRY.ID': 'PER', 'COUNTRY': 'Peru',
                       'INDICATOR.ID': code, 'INDICATOR': code,
                       'FREQUENCY': 'Annual',
                       'SCALE': 'Millions' if code == 'LP' else 'Units',
                       'UNIT': 'Percent' if code in ('NGDP_RPCH', 'PCPIEPCH') else '',
                       'PUBLICATION_DATE': f'{year}-{month:02d}-13T02:00:00Z',
                       'LATEST_ACTUAL_ANNUAL_DATA': 2017 if code == 'LP' else year - 1})
        for target in range(year - 1, year + 6):
            values[target] = (34 if code == 'LP' else index + 2) + (target - year) / 100 + revision / 1000
        # Precisión de origen: el lector no debe redondear el almacenamiento.
        values[year] += 0.000000789
        if change and change[0] == code:
            values[change[1]] = change[2]
        ws.append([values[key] for key in columns])
    output = BytesIO()
    wb.save(output)
    url = f'https://data.imf.org/-/media/test/WEO{"Apr" if month == 4 else "Oct"}{year}all.xlsx'
    return url, output.getvalue()


def synthetic_sdmx(*, mutation=None):
    """CSV de metadatos sintético; no afirma datos reales de ediciones futuras."""
    columns = ['COUNTRY', 'INDICATOR', 'FREQUENCY', 'TIME_PERIOD', 'OBS_VALUE',
               'PUBLICATION_DATE', 'LATEST_ACTUAL_ANNUAL_DATA', 'SCALE', 'UNIT']
    output = StringIO()
    writer = csv.DictWriter(output, fieldnames=columns)
    writer.writeheader()
    for code in w.CODES:
        for year in range(2027, 2033):
            row = {'COUNTRY': 'PER', 'INDICATOR': code, 'FREQUENCY': 'A',
                   'TIME_PERIOD': str(year), 'OBS_VALUE': '35000000' if code == 'LP' else '3.123456789',
                   'PUBLICATION_DATE': '2027-04-13T02:00:00Z',
                   'LATEST_ACTUAL_ANNUAL_DATA': '2017' if code == 'LP' else '2026',
                   'SCALE': '6' if code == 'LP' else '0',
                   'UNIT': 'PT' if code in ('NGDP_RPCH', 'PCPIEPCH') else ''}
            if mutation:
                row = mutation(row)
            if row is not None:
                writer.writerow(row)
    return output.getvalue().encode()


class SdmxMetadataTests(unittest.TestCase):
    def fetcher(self, csv_body, version='10.0.0'):
        structure = json.dumps({'data': {'dataflows': [
            {'agencyID': 'IMF.RES', 'id': 'WEO', 'version': version}]}}).encode()
        calls = []
        def fetch(url, **kwargs):
            calls.append(url)
            return structure if url == w.SDMX_STRUCTURE_URL else csv_body
        return fetch, calls

    def test_discovers_version_and_complete_publication_metadata_without_fixed_year(self):
        fetch, calls = self.fetcher(synthetic_sdmx())
        metadata = w.latest_sdmx(fetch)
        self.assertEqual(metadata['edition'], '2027-04')
        self.assertEqual(metadata['published'], '2027-04-13')
        self.assertEqual(metadata['flow_version'], '10.0.0')
        self.assertEqual(metadata['latest_actual'], {'NGDP_RPCH': 2026, 'PCPIEPCH': 2026,
                                                    'LUR': 2026, 'LP': 2017})
        self.assertEqual(calls, [w.SDMX_STRUCTURE_URL,
            'https://api.imf.org/external/sdmx/2.1/data/IMF.RES,WEO,10.0.0/PER.NGDP_RPCH+PCPIEPCH+LUR+LP.A'])
        self.assertNotIn('years', metadata)  # La API identifica; Excel conserva las cifras.

    def test_rejects_foreign_country_incomplete_horizon_and_mixed_publication(self):
        mutations = [lambda row: None if row['INDICATOR'] == 'LP' else row,
                     lambda row: None if row['INDICATOR'] == 'LUR' and row['TIME_PERIOD'] == '2032' else row,
                     lambda row: dict(row, COUNTRY='CHL') if row['INDICATOR'] == 'LP' else row,
                     lambda row: dict(row, PUBLICATION_DATE='2027-10-13T02:00:00Z') if row['INDICATOR'] == 'LP' else row,
                     lambda row: dict(row, PUBLICATION_DATE='2027-01-13T02:00:00Z')]
        for index, mutation in enumerate(mutations):
            with self.subTest(index=index):
                fetch, _ = self.fetcher(synthetic_sdmx(mutation=mutation))
                with self.assertRaises(ValueError):
                    w.latest_sdmx(fetch)

    def test_rejects_invalid_metadata_response(self):
        with self.assertRaises(ValueError):
            w.latest_sdmx(lambda *args, **kwargs: b'<html>temporary error</html>')
        fetch, _ = self.fetcher(synthetic_sdmx(), version='malformed-version')
        with self.assertRaises(ValueError):
            w.latest_sdmx(fetch)


class ImfTransportAdapterTests(unittest.TestCase):
    def raw_response(self, body=b'official body', status=200, headers=None):
        response = BytesIO(body)
        response.getcode = lambda: status
        response.headers = headers or {'Content-Type': 'text/html'}
        return response

    def test_public_request_keeps_headers_and_disables_automatic_redirects(self):
        raw = self.raw_response()
        opener = Mock()
        opener.open.return_value = raw
        headers = {'User-Agent': p.HEADERS['User-Agent'], 'Accept': 'text/html'}
        with patch.object(p, 'build_opener', return_value=opener) as factory:
            with p._open_http(w.PORTAL, headers, 25) as response:
                self.assertEqual(response.status_code, 200)
                self.assertEqual(b''.join(response.iter_content(4)), b'official body')
        request = opener.open.call_args.args[0]
        self.assertEqual(request.full_url, w.PORTAL)
        self.assertEqual(request.get_header('User-agent'), p.HEADERS['User-Agent'])
        self.assertEqual(request.get_header('Accept'), 'text/html')
        self.assertEqual(opener.open.call_args.kwargs['timeout'], 25)
        handler = factory.call_args.args[0]
        self.assertIsInstance(handler, p.HTTPRedirectHandler)
        self.assertIsNone(handler.redirect_request(request, None, 302, '', {}, 'https://foreign.example/'))
        self.assertTrue(raw.closed)

    def test_redirect_and_forbidden_status_remain_visible_to_http_validator(self):
        for status in (302, 403):
            with self.subTest(status=status):
                error = p.HTTPError(w.PORTAL, status, 'official status',
                                    {'Content-Type': 'text/html', 'Location': w.INITIAL_URL},
                                    BytesIO(b'official status body'))
                opener = Mock()
                opener.open.side_effect = error
                with patch.object(p, 'build_opener', return_value=opener):
                    with p._open_http(w.PORTAL, {}, 25) as response:
                        self.assertEqual(response.status_code, status)
                        self.assertEqual(b''.join(response.iter_content(1024)), b'official status body')
                        if status == 403:
                            with self.assertRaises(p.requests.HTTPError):
                                response.raise_for_status()

    def test_connection_failure_is_translated_without_second_transport_attempt(self):
        opener = Mock()
        opener.open.side_effect = p.URLError('network unavailable')
        with patch.object(p, 'build_opener', return_value=opener), \
             patch.object(p.requests, 'get') as other_client:
            with self.assertRaises(p.requests.RequestException):
                p._open_http(w.PORTAL, {}, 25)
        other_client.assert_not_called()

    def test_other_sources_keep_existing_requests_transport(self):
        with patch.object(p.requests, 'get', return_value=Response()) as getter, \
             patch.object(p, 'build_opener') as imf_client:
            with p._open_http(p.BCRP_XLSX_PBI, {'User-Agent': 'IASPE-test'}, 14):
                pass
        self.assertEqual(getter.call_args.args[0], p.BCRP_XLSX_PBI)
        imf_client.assert_not_called()


class WeoPeruTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        state = json.loads((HERE/'data/proyecciones_externas/historial.json').read_text(encoding='utf-8'))
        release = next(e for e in state['editions'] if e['source']==w.SOURCE)
        cls.body = (HERE/'data/proyecciones_externas/documentos'/release['file']).read_bytes()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='iaspe_weo_')
        self.path = Path(self.temp.name)
        self.original = {k:getattr(p,k) for k in ('DIR','STATE','DOCS','HTTP_CACHE')}
        p.DIR=self.path
        p.STATE=self.path/'historial.json'
        p.DOCS=self.path/'documentos'
        p.HTTP_CACHE=self.path/'http_cache.json'
        p.LOCAL.events=[]
        p.LOCAL.metadata={}
        p.BLOCKED_HOSTS.clear()
        self.api_unavailable = patch.object(w, 'latest_sdmx',
            side_effect=ValueError('API no disponible en esta prueba sin red'), create=True)
        self.api_unavailable.start()

    def tearDown(self):
        self.api_unavailable.stop()
        for k,v in self.original.items():setattr(p,k,v)
        self.temp.cleanup()

    def test_four_series_peru_2026_2031(self):
        edition, parsed = w.parse_workbook(self.body,w.INITIAL_URL)
        self.assertEqual(edition,'2026-10')
        self.assertEqual(set(parsed),set(w.CODES))
        self.assertEqual(len(parsed['NGDP_RPCH']['years']),6)
        self.assertAlmostEqual(parsed['NGDP_RPCH']['years'][2026],2.997)
        self.assertAlmostEqual(parsed['PCPIEPCH']['years'][2026],4.383)
        self.assertAlmostEqual(parsed['LUR']['years'][2031],5.5)
        self.assertAlmostEqual(parsed['LP']['years'][2030],36.164)
        self.assertEqual(parsed['LP']['last_actual'],2017)

    def test_discovery_chooses_latest_official_complete_link(self):
        old=w.INITIAL_URL
        newer='https://data.imf.org/fmi/external/WEOApr2027all.xlsx'
        malicious='https://untrusted.example/WEOOct2030all.xlsx'
        html=f'<a href="{old}">October</a><a href="{newer}">April</a><a href="{malicious}">other</a>'
        self.assertEqual(w.discover(html),newer)
        with self.assertRaises(ValueError): w.discover('<a href="https://not-imf.org/WEOOct2035all.xlsx">fake</a>')

    def test_discovery_reads_official_sitecore_document_card(self):
        relative = '/-/media/iData/External-Storage/Documents/EXAMPLE/en/WEOApr2027all.xlsx'
        card = {'fields': {'title': {'value': 'April 2027 WEO Entire Dataset in Excel'},
                           'date': {'value': '2027-04-13T04:00:00Z'},
                           'url': {'value': {'href': relative}}}}
        # Estructura observada del portal; URL/edición futura son sintéticas.
        state = {'props': {'pageProps': {'layoutData': {'sitecore': {'route': {
            'placeholders': {'documentCards': [card]}}}}}}}
        html = (f'<a href="{w.INITIAL_URL}">Older edition</a>'
                '<script id="__NEXT_DATA__" type="application/json">'
                + json.dumps(state) + '</script>')
        self.assertEqual(w.discover(html), 'https://data.imf.org' + relative)

    def test_discovery_ignores_interim_foreign_and_insecure_files(self):
        body = (f'<a href="{w.INITIAL_URL}">Complete</a>'
                '<a href="https://data.imf.org/WEOJan2027all.xlsx">Update</a>'
                '<a href="http://data.imf.org/WEOApr2027all.xlsx">HTTP</a>'
                '<a href="https://data.imf.org.evil.example/WEOOct2028all.xlsx">Foreign</a>')
        self.assertEqual(w.discover(body), w.INITIAL_URL)

    def test_one_click_update_consistent_and_idempotent(self):
        html=f'<a href="{w.INITIAL_URL}">FMI WEO October 2026</a>'.encode()
        def mock_get(url,**kwargs):
            body=html if url==w.PORTAL else self.body
            p._trace(dict(url=url,body_hash=hashlib.sha256(body).hexdigest(),
                          downloaded=True,downloaded_at=p._utc(),checked_at=p._utc(),
                          http_status=200,consulted=True,content_type='text/html' if url==w.PORTAL else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'))
            return body
        with patch.object(p,'_get',side_effect=mock_get):
            first=p.update(scope='imf')
            second=p.update(scope='imf')
        self.assertEqual(first['updateResult']['added'],24)
        self.assertEqual(second['updateResult']['added'],0)
        self.assertEqual(second['updateResult']['errors'],[])
        self.assertEqual(len([r for r in second['current_records'] if r['source']==w.SOURCE]),24)
        self.assertTrue(all(r['transport_verified'] for r in second['current_records'] if r['source']==w.SOURCE))
        self.assertEqual(len([e for e in second['editions'] if e.get('source')==w.SOURCE]),1)
        release = next(e for e in second['editions'] if e.get('source') == w.SOURCE)
        self.assertTrue(release['publication_evidence_hash'])
        self.assertIsNone(release.get('publication_evidence_file'))

    def test_failed_download_keeps_existing_history(self):
        rows, docs=p._parse_weo_xlsx(self.body,w.INITIAL_URL,origin='document_imported')
        p._merge(p._load(),[],[])  # no side effects
        initial=p._load()
        p._merge(initial,rows,docs)
        p._save(initial)
        def failed(url,**kwargs):
            if url == w.PORTAL:return f'<a href="{w.INITIAL_URL}"></a>'.encode()
            raise ValueError('HTTP 503: no disponible')
        with patch.object(p,'_get',side_effect=failed):
            result=p.update(scope='imf')
        self.assertEqual(len([r for r in result['current_records'] if r['source']==w.SOURCE]),24)
        self.assertTrue(any('HTTP 503' in e for e in result['updateResult']['errors']))
        self.assertEqual(result['updateResult']['added'],0)

    def test_rejects_html_instead_of_excel(self):
        with self.assertRaises(ValueError): w.parse_workbook(b'<html>blocked</html>',w.INITIAL_URL)

    def test_all_archived_values_match_independent_excel_reader(self):
        _, parsed = w.parse_workbook(self.body, w.INITIAL_URL)
        wb = load_workbook(BytesIO(self.body), read_only=True, data_only=True)
        try:
            rows = wb['Countries'].iter_rows(values_only=True)
            header = next(rows)
            expected = {}
            for raw in rows:
                row = dict(zip(header, raw))
                code = row.get('INDICATOR.ID')
                if row.get('COUNTRY.ID') == 'PER' and code in w.CODES:
                    expected[code] = {year: float(row[year]) for year in range(2026, 2032)}
            self.assertEqual(set(expected), set(w.CODES))
            self.assertEqual({code: data['years'] for code, data in parsed.items()}, expected)
        finally:
            wb.close()

    def test_preserves_source_precision_in_parser_and_records(self):
        url, body = synthetic_release(2027, 4)
        _, parsed = w.parse_workbook(body, url)
        wb = load_workbook(BytesIO(body), read_only=True, data_only=True)
        try:
            expected = next(wb['Countries'].iter_rows(min_row=2, max_row=2, values_only=True))[10]
        finally:
            wb.close()
        rows, _ = p._parse_weo_xlsx(body, url)
        row = next(r for r in rows if r['variable'] == 'pbi' and r['year'] == '2027')
        self.assertEqual(parsed['NGDP_RPCH']['years'][2027], expected)
        self.assertEqual(row['value'], expected)

    def test_failed_discovery_never_uses_fixed_historical_url(self):
        rows, docs = p._parse_weo_xlsx(self.body, w.INITIAL_URL, origin='document_imported')
        original = p._load()
        p._merge(original, rows, docs)
        p._save(original)
        with patch.object(p, '_get', side_effect=ValueError('HTTP 503 catálogo FMI')) as getter:
            result = p.update(scope='imf')
        self.assertEqual([call.args[0] for call in getter.call_args_list], [w.PORTAL])
        self.assertEqual(result['records'], original['records'])
        self.assertEqual(result['updateResult']['added'], 0)
        self.assertTrue(any('503' in error for error in result['updateResult']['errors']))
        self.assertFalse(any(value.get('latest_confirmed') for value in p._load().get('confirmations', {}).values()))

    def test_invalid_catalogue_does_not_revalidate_old_release(self):
        with patch.object(p, '_get', return_value=b'<html>Portal sin publicacion completa</html>') as getter:
            result = p.update(scope='imf')
        self.assertEqual([call.args[0] for call in getter.call_args_list], [w.PORTAL])
        self.assertTrue(result['updateResult']['errors'])
        self.assertEqual(result['updateResult']['added'], 0)

    def test_future_complete_editions_and_revision_preserve_history(self):
        apr_url, april = synthetic_release(2027, 4)
        oct_url, october = synthetic_release(2027, 10)
        _, revised = synthetic_release(2027, 10, revision=1)
        releases = [(w.INITIAL_URL, self.body), (apr_url, april),
                    (oct_url, october), (oct_url, revised)]
        active = [0]
        def getter(url, **kwargs):
            target, body = releases[active[0]]
            if url == w.PORTAL:
                # Incluye la edición anterior: se debe escoger la última completa.
                body = (f'<a href="{w.INITIAL_URL}">October</a>'
                        f'<a href="{target}">Entire Dataset in Excel</a>').encode()
            else:
                self.assertEqual(url, target)
            p._trace(dict(url=url, body_hash=hashlib.sha256(body).hexdigest(),
                          downloaded=True, downloaded_at=p._utc(), checked_at=p._utc(),
                          http_status=200, consulted=True,
                          content_type='text/html' if url == w.PORTAL else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'))
            return body
        with patch.object(p, '_get', side_effect=getter):
            for index in range(4):
                active[0] = index
                result = p.update(scope='imf')
                self.assertEqual(result['updateResult']['errors'], [])
                self.assertEqual(result['updateResult']['added'], 24)
                self.assertEqual(result['updateResult']['new_editions'], 0 if index == 3 else 1)
                self.assertEqual(result['updateResult']['revisions'], 1 if index == 3 else 0)
                self.assertEqual(len(result['records']), (index + 1) * 24)
                self.assertEqual(len(result['current_records']), 24)
            repeat = p.update(scope='imf')
        self.assertEqual(repeat['updateResult']['added'], 0)
        self.assertEqual(len(p._load()['editions']), 4)
        self.assertEqual({r['edition'] for r in repeat['current_records']}, {'2027-10'})
        original = p._load()['editions'][0]
        self.assertEqual((p.DOCS / original['file']).read_bytes(), self.body)
        self.assertIn('2032', {r['year'] for r in repeat['current_records']})

    def test_rejects_changed_unit_scale_publication_and_missing_forecast(self):
        changes = [('NGDP_RPCH', 'UNIT', 'US Dollars'),
                   ('NGDP_RPCH', 'SCALE', 'Millions'),
                   ('LP', 'SCALE', 'Units'),
                   ('LUR', 'FREQUENCY', 'Quarterly'),
                   ('PCPIEPCH', 'PUBLICATION_DATE', '2026-10-13T02:00:00Z'),
                   ('NGDP_RPCH', 2032, None)]
        for change in changes:
            with self.subTest(change=change):
                url, body = synthetic_release(2027, 4, change=change)
                with self.assertRaises(ValueError):
                    w.parse_workbook(body, url)

    def test_invalid_latest_workbook_keeps_previous_publication(self):
        rows, docs = p._parse_weo_xlsx(self.body, w.INITIAL_URL, origin='document_imported')
        original = p._load()
        p._merge(original, rows, docs)
        p._save(original)
        url, _ = synthetic_release(2027, 4)
        def getter(target, **kwargs):
            if target == w.PORTAL:
                return f'<a href="{url}">Entire Dataset</a>'.encode()
            return b'<html>service unavailable</html>'
        with patch.object(p, '_get', side_effect=getter):
            result = p.update(scope='imf')
        self.assertEqual(result['records'], original['records'])
        self.assertEqual(result['updateResult']['added'], 0)
        self.assertTrue(result['updateResult']['errors'])
        self.assertEqual((p.DOCS / docs[0]['file']).read_bytes(), self.body)

    def test_api_newer_than_catalogue_does_not_download_previous_edition(self):
        metadata = {'edition': '2027-04', 'published': '2027-04-13',
                    'latest_actual': {code: 2026 for code in w.CODES}}
        html = f'<a href="{w.INITIAL_URL}">Older complete WEO</a>'.encode()
        with patch.object(w, 'latest_sdmx', return_value=metadata), \
             patch.object(p, '_get', return_value=html) as getter:
            result = p.update(scope='imf')
        self.assertEqual([call.args[0] for call in getter.call_args_list], [w.PORTAL])
        self.assertTrue(result['updateResult']['errors'])
        self.assertEqual(result['updateResult']['added'], 0)
        self.assertFalse(result['records'])

    def test_api_excel_metadata_disagreement_rejects_incorporation(self):
        url, body = synthetic_release(2027, 4)
        metadata = {'edition': '2027-04', 'published': '2027-04-12',
                    'latest_actual': {code: 2026 for code in w.CODES}}
        def getter(target, **kwargs):
            return f'<a href="{url}">Entire Dataset</a>'.encode() if target == w.PORTAL else body
        with patch.object(w, 'latest_sdmx', return_value=metadata), \
             patch.object(p, '_get', side_effect=getter):
            result = p.update(scope='imf')
        self.assertTrue(result['updateResult']['errors'])
        self.assertEqual(result['records'], [])

    def test_http_negotiates_resource_with_truthful_client_identity(self):
        targets = [(w.PORTAL, 'text/html'),
                   (w.INITIAL_URL, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                   ('https://api.imf.org/external/sdmx/3.0/structure/dataflow/IMF.RES/WEO/latest',
                    'application/vnd.sdmx.structure+json;version=2.0.0'),
                   ('https://api.imf.org/external/sdmx/2.1/data/IMF.RES,WEO,1.0.0/PER.NGDP_RPCH', 'text/csv')]
        for url, accept in targets:
            with self.subTest(url=url), patch.object(p, '_open_http', return_value=Response()) as getter:
                self.assertEqual(p._get(url, refresh=True), b'contenido')
                sent = getter.call_args.args[1]
                self.assertEqual(sent['Accept'], accept)
                self.assertTrue(sent['User-Agent'].startswith('IASPE-'))
                self.assertNotIn('Cookie', sent)

    def test_refresh_revalidates_cached_body_instead_of_claiming_new_download(self):
        first = Response(b'official catalogue', headers={'Content-Type': 'text/html',
                         'Cache-Control': 'max-age=900', 'ETag': '"test-catalogue"'})
        unchanged = Response(b'', status=304, headers={'Content-Type': 'text/html'})
        with patch.object(p, '_open_http', side_effect=[first, unchanged]) as getter:
            self.assertEqual(p._get(w.PORTAL), b'official catalogue')
            self.assertEqual(p._get(w.PORTAL, refresh=True), b'official catalogue')
        self.assertEqual(getter.call_count, 2)
        self.assertEqual(getter.call_args.args[1]['If-None-Match'], '"test-catalogue"')
        self.assertEqual(p.LOCAL.events[-1]['cache'], 'revalidated')
        self.assertEqual(p.LOCAL.events[-1]['http_status'], 304)
        self.assertFalse(p.LOCAL.events[-1]['downloaded'])

    def test_imf_redirect_must_remain_at_imf_even_if_other_provider_is_allowed(self):
        redirect = Response(b'', status=302, headers={'Location': p.BCRP_XLSX_PBI})
        with patch.object(p, '_open_http', return_value=redirect) as getter:
            with self.assertRaises(ValueError):
                p._get(w.INITIAL_URL, refresh=True)
        self.assertEqual(getter.call_count, 1)

    def test_complete_future_release_keeps_forecasts_beyond_2035(self):
        url, body = synthetic_release(2031, 4)
        rows, docs = p._parse_weo_xlsx(body, url)
        self.assertEqual(len(rows), 24)
        self.assertEqual({row['year'] for row in rows}, {str(year) for year in range(2031, 2037)})
        self.assertEqual(docs[0]['edition'], '2031-04')
        self.assertEqual({row['code_weo'] for row in rows if row['year'] == '2036'}, set(w.CODES))

    def test_same_second_revisions_select_last_incorporated_document(self):
        url, original = synthetic_release(2027, 4)
        _, revised = synthetic_release(2027, 4, revision=1)
        state = p._load()
        releases = []
        for body in (original, revised):
            rows, docs = p._parse_weo_xlsx(body, url)
            event = {'url': url, 'body_hash': hashlib.sha256(body).hexdigest(),
                     'downloaded': True, 'downloaded_at': '2027-04-13T12:00:00+00:00',
                     'checked_at': '2027-04-13T12:00:00+00:00', 'http_status': 200,
                     'consulted': True, 'content_type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}
            p._enrich(rows, docs, [event])
            p._merge(state, rows, docs)
            releases.append((rows, docs))
        self.assertEqual(len(state['records']), 48)
        self.assertEqual(len(state['editions']), 2)
        self.assertEqual({row['document_id'] for row in p._current_records(state)}, {releases[1][1][0]['id']})
        # Reincorporar el primer respaldo idéntico no lo convierte en otra revisión.
        self.assertEqual(p._merge(state, *releases[0]), 0)
        current = p._current_records(state)
        self.assertEqual(len(current), 24)
        self.assertEqual({row['document_id'] for row in current}, {releases[1][1][0]['id']})
        self.assertEqual({(row['variable'], row['year']): row['value'] for row in current},
                         {(row['variable'], row['year']): row['value'] for row in releases[1][0]})


if __name__=='__main__': unittest.main()
