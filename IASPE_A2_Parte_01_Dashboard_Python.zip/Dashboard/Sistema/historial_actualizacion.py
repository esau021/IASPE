"""Versiones de pronósticos publicadas por la transacción existente."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json


def _fingerprint(value):
    body = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(body.encode('utf-8')).hexdigest()


def _snapshot(models, sources, macro_base):
    series = {}
    for identifier, model in sorted(models.items()):
        item = {key:deepcopy(model[key]) for key in ('name', 'unit', 'method', 'status') if key in model}
        for frequency in ('annual', 'monthly'):
            rows = []
            for row in model.get(frequency, []):
                year = str(row.get('year') or row.get('date') or '')[:4]
                if year.isdigit() and 2026 <= int(year) <= 2030:
                    rows.append(deepcopy(row))
            item[frequency] = rows
        series[identifier] = item
    return {'models':series, 'sources':deepcopy(sources), 'macroBase':deepcopy(macro_base),
            'scope':'Pronósticos físicos 2026–2030 y observaciones de su versión; sin nueva estimación.'}


def prepare(history, previous, updated, *, previous_sources, updated_sources, macro_base, published_at=None):
    """Prepara ambos extremos; el llamante los publica con los estados y Excel."""
    result = deepcopy(history or {})
    versions = result.setdefault('versions', [])
    publications = result.setdefault('publications', [])
    if not isinstance(versions, list) or not isinstance(publications, list):
        raise ValueError('Historial de pronósticos no válido; no se sobrescribe')
    timestamp = published_at or datetime.now(timezone.utc).isoformat()
    ids = []
    for models, sources, kind in ((previous, previous_sources, 'previous'), (updated, updated_sources, 'published')):
        payload = _snapshot(models, sources, macro_base)
        identifier = _fingerprint(payload)
        ids.append(identifier)
        if not any(item.get('id') == identifier for item in versions):
            versions.append({'id':identifier, 'archivedAt':timestamp, 'kind':kind, **payload})
    publication = {'publishedAt':timestamp, 'previousVersion':ids[0], 'version':ids[1],
                   'ok':True, 'status':'published', 'basis':'Excel y estados conciliados en aplicar_transaccion'}
    if not publications or any(publications[-1].get(key) != publication[key]
                               for key in ('previousVersion', 'version', 'publishedAt')):
        publications.append(publication)
    result['schemaVersion'] = 1
    return result
