"""Participación observada de Falabella sobre agregados SBS completos.

Solo lectura: reutiliza el panel B-2389 y los originales B-2363/B-2201.
Las proyecciones pertenecen a los modelos del escenario activo del Dashboard.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta
from functools import lru_cache
import hashlib
import importlib.util
import io
import math
from pathlib import Path
import re
import sys
import unicodedata
from xml.etree import ElementTree as ET
from zipfile import ZipFile

import benchmark_eeff
import cartera_consumo_bancos

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SCRAPER=ROOT/'IASPE/Scraper'
CARDS=SCRAPER/'Numero_tarjetas/fuentes'
BALANCES=SCRAPER/'EEFF_Benchmark/fuentes/B-2201'
CONSUMPTION=SCRAPER/'Cartera_consumo_mercado/fuentes'
MONTHS=dict(zip(('en','fe','ma','ab','my','jn','jl','ag','se','oc','no','di'),range(1,13)))
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
SOURCE_URL='https://www.sbs.gob.pe/estadisticas-y-publicaciones/estadisticas-/sistema-financiero_'


def norm(value):
    return ' '.join(''.join(c for c in unicodedata.normalize('NFKD',str(value or '')).lower()
                           if not unicodedata.combining(c)).replace('*','').split())


def numeric(value,integer=False):
    if value is None or isinstance(value,str) and (not value.strip() or value.strip() in ('-','—')):return None
    if type(value) not in (int,float) or not math.isfinite(value) or value<0 or integer and int(value)!=value:
        raise ValueError('Valor SBS no numérico, negativo o incompatible con la unidad')
    return int(value) if integer else float(value)


def cell(row,column):
    letters='';column+=1
    while column:column,remainder=divmod(column-1,26);letters=chr(65+remainder)+letters
    return letters+str(row+1)


@lru_cache(maxsize=1)
def bank_reader():
    path=SCRAPER/'Cartera_consumo_mercado/script/construir_panel_bancos.py'
    spec=importlib.util.spec_from_file_location('iaspe_market_existing_bank_reader',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def bank_id(label):
    clean=norm(label)
    if re.search(r'\bgnb\b',clean):return 'gnb'
    if 'del trabajo' in clean:return 'trabajo'
    return bank_reader().bank_id(label)


def first_sheet(body):
    """Conserva posiciones y cachés; no guarda ni recalcula los libros."""
    if body.startswith(b'PK'):
        with ZipFile(io.BytesIO(body)) as book:
            shared=[]
            if 'xl/sharedStrings.xml' in book.namelist():
                shared=[''.join(t.text or '' for t in item.findall('.//m:t',NS))
                        for item in ET.fromstring(book.read('xl/sharedStrings.xml')).findall('m:si',NS)]
            first=ET.fromstring(book.read('xl/workbook.xml')).find('m:sheets/m:sheet',NS)
            rid=first.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
            target=next(item.attrib['Target'] for item in ET.fromstring(book.read('xl/_rels/workbook.xml.rels')) if item.attrib['Id']==rid)
            target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
            rows=[]
            for row in ET.fromstring(book.read(target)).findall('m:sheetData/m:row',NS):
                index=int(row.attrib['r'])-1
                while len(rows)<=index:rows.append([])
                values=rows[index]
                for item in row.findall('m:c',NS):
                    column=0
                    for letter in re.match('[A-Z]+',item.attrib['r'])[0]:column=column*26+ord(letter)-64
                    column-=1
                    while len(values)<=column:values.append(None)
                    text=item.find('m:v',NS);kind=item.attrib.get('t')
                    if kind=='inlineStr':value=''.join(t.text or '' for t in item.findall('.//m:t',NS))
                    elif text is None:value=None
                    elif kind=='s':value=shared[int(text.text)]
                    elif kind in ('str','e'):value=text.text
                    elif kind=='b':value=text.text=='1'
                    else:
                        try:value=float(text.text)
                        except (ValueError,TypeError):value=text.text
                    values[column]=value
            return first.attrib['name'],rows
    if not body.startswith(b'\xd0\xcf\x11\xe0'):raise ValueError('El original SBS no es un libro Excel reconocido')
    try:import xlrd
    except ImportError:
        sys.path.insert(0,str(HERE/'vendor'));import xlrd
    book=xlrd.open_workbook(file_contents=body,on_demand=True)
    try:
        sheet=book.sheet_by_index(0);rows=[]
        for row in range(sheet.nrows):
            values=[]
            for column in range(sheet.ncols):
                entry=sheet.cell(row,column)
                if entry.ctype in (xlrd.XL_CELL_EMPTY,xlrd.XL_CELL_BLANK):value=None
                elif entry.ctype==xlrd.XL_CELL_DATE:value=xlrd.xldate_as_datetime(entry.value,book.datemode)
                else:value=entry.value
                values.append(value)
            rows.append(values)
        return sheet.name,rows
    finally:book.release_resources()


def internal_date(rows,period):
    found=set()
    names=('enero','febrero','marzo','abril','mayo','junio','julio','agosto','setiembre','octubre','noviembre','diciembre')
    for row in rows[:7]:
        for value in row[:12]:
            if isinstance(value,datetime):found.add(value.strftime('%Y-%m'))
            elif type(value) in (float,int) and 30_000<value<70_000:
                found.add((datetime(1899,12,30)+timedelta(days=value)).strftime('%Y-%m'))
            elif isinstance(value,str):
                text=norm(value)
                for month,name in enumerate(names,1):
                    for match in re.finditer(r'\b'+name+r'\s+(?:de\s+)?(20\d{2})\b',text):found.add(f'{match[1]}-{month:02}')
    if period not in found:raise ValueError('La fecha interna SBS no coincide con el periodo del archivo')


def provenance(path,body,sheet,period,report,**extra):
    return {'report':report,'file':path.relative_to(ROOT).as_posix(),'sheet':sheet,
            'sha256':hashlib.sha256(body).hexdigest(),'url':source_url(report,period),**extra}


def source_url(report,period):
    year,month=map(int,period.split('-'));abbr=next(key for key,value in MONTHS.items() if value==month)
    name=('Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Setiembre','Octubre','Noviembre','Diciembre')[month-1]
    return f'https://intranet2.sbs.gob.pe/estadistica/financiera/{year}/{name}/{report}-{abbr}{year}.XLS'


def parse_cards(body,period):
    sheet,rows=first_sheet(body);internal_date(rows,period)
    header=next((i for i,row in enumerate(rows[:15]) if any(norm(v)=='empresas' for v in row)
                 and any(norm(v).startswith('total') for v in row)),None)
    if header is None:
        # Formato2008–2010: crédito y débito, cada uno con dos años.
        credit=[(r,c) for r,row in enumerate(rows[:8]) for c,v in enumerate(row)
                if 'tarjetas de credito' in norm(v) and 'debito' not in norm(v) and len(norm(v))<40]
        if len(credit)!=1:raise ValueError('B-2363: bloque de tarjetas de crédito no unívoco')
        r,start=credit[0];dated=[]
        for c,v in enumerate(rows[r+1]):
            if c>=start and isinstance(v,datetime) and v.strftime('%Y-%m')==period:dated.append(c)
        if len(dated)!=1:raise ValueError('B-2363: columna del mes de crédito no unívoca')
        column=dated[0];header=r+1
        labels=[c for row in rows for c,v in enumerate(row) if norm(v).startswith('total banca multiple')]
        if len(labels)!=1:raise ValueError('B-2363: total de banca múltiple ambiguo')
        entity_column=labels[0]
    else:
        totals=[i for i,v in enumerate(rows[header]) if norm(v).startswith('total')]
        if len(totals)!=1:raise ValueError('B-2363: columna total ambigua')
        column=totals[0];entity_column=next(c for c,v in enumerate(rows[header]) if norm(v)=='empresas')
    values={};locations={};market=None;market_cell=None
    for r,row in enumerate(rows[header+1:],header+1):
        label=row[entity_column] if entity_column<len(row) else None
        if not isinstance(label,str) or not label.strip():continue
        value=numeric(row[column] if column<len(row) else None,integer=True)
        if norm(label).startswith('total banca multiple'):
            market=value;market_cell=cell(r,column);break
        identifier=bank_id(label)
        if identifier is None:continue
        if identifier in values:raise ValueError('B-2363: empresa duplicada')
        values[identifier]=value;locations[identifier]=cell(r,column)
    if market is None or market<=0 or 'falabella' not in values:raise ValueError('B-2363: falta Falabella o el total oficial')
    if all(value is not None for value in values.values()) and sum(values.values())!=market:
        raise ValueError('B-2363: las empresas no concilian con el total oficial')
    return {'sheet':sheet,'values':values,'market':market,'cells':locations,'marketCell':market_cell,
            'concept':'Número de tarjetas de crédito: TOTAL de tipos de crédito, no saldo ni sólo consumo'}


def parse_obligations(body,period,detail=None):
    sheet,rows=first_sheet(body);internal_date(rows,period)
    if not any('miles de soles' in norm(v) for row in rows[:6] for v in row):raise ValueError('B-2201: unidad no acreditada')
    # La cuenta de pasivo es mayúscula y sin sangría; no confundir su rótulo
    # con el desglose de gastos o cuentas por pagar del mismo libro.
    target=[r for r,row in enumerate(rows) if any(isinstance(v,str) and v==v.strip()
            and v.isupper() and norm(v)=='obligaciones con el publico' for v in row)]
    if len(target)!=1:raise ValueError('B-2201: cuenta principal de obligaciones no unívoca')
    target=target[0]
    if detail is not None:
        allowed={'depositos_vista':'depositos a la vista','depositos_ahorro':'depositos de ahorro',
                 'depositos_plazo':'depositos a plazo','depositos_cts':'c.t.s.'}
        if detail not in allowed:raise ValueError('Desglose B-2201 no reconocido')
        # Filas hijas de obligaciones con el público, no depósitos interbancarios.
        sector_end=next((i for i in range(target+1,len(rows))
                         if isinstance(rows[i][0],str) and rows[i][0]==rows[i][0].strip()
                         and rows[i][0].isupper() and norm(rows[i][0])!='obligaciones con el publico'),len(rows))
        matches=[i for i in range(target+1,sector_end)
                 if isinstance(rows[i][0],str) and norm(rows[i][0])==allowed[detail]]
        if len(matches)!=1:raise ValueError(f'B-2201: {detail} no es un renglón único de obligaciones al público')
        target=matches[0]
    headers=[r for r,row in enumerate(rows[:target]) if any(norm(v)=='total banca multiple' for v in row)]
    if not headers:raise ValueError('B-2201: falta el agregado doméstico de banca múltiple')
    header=headers[-1];entries=[(i,v) for i,v in enumerate(rows[header]) if isinstance(v,str) and v.strip()]
    values={};locations={};market=None;market_cell=None
    for index,(start,label) in enumerate(entries):
        clean=norm(label)
        if clean in ('activo','pasivo y patrimonio','pasivo','patrimonio'):continue
        if 'exterior' in clean:continue
        aggregate=clean=='total banca multiple'
        identifier=None if aggregate else bank_id(label)
        if not aggregate and identifier is None:continue
        stop=entries[index+1][0] if index+1<len(entries) else len(rows[header])
        currency=[column for r in range(header+1,min(header+4,len(rows))) for column in range(start,stop)
                  if column<len(rows[r]) and norm(rows[r][column])=='total']
        if len(currency)!=1:raise ValueError('B-2201: total MN+ME ambiguo para una empresa')
        column=currency[0];raw=rows[target][column] if column<len(rows[target]) else None
        amount=numeric(raw);amount=amount/1000 if amount is not None else None
        if aggregate:market=amount;market_cell=cell(target,column)
        else:
            if identifier in values:raise ValueError('B-2201: empresa doméstica duplicada')
            values[identifier]=amount;locations[identifier]=cell(target,column)
    if market is None or market<=0 or 'falabella' not in values:raise ValueError('B-2201: falta Falabella o el total oficial doméstico')
    complete=all(value is not None for value in values.values())
    difference=sum(value for value in values.values() if value is not None)-market
    if not complete or abs(difference)>0.0001:raise ValueError('B-2201: universo doméstico incompleto o sin conciliación')
    return {'sheet':sheet,'values':values,'market':market,'cells':locations,'marketCell':market_cell,
            'concept':('OBLIGACIONES CON EL PÚBLICO, cuenta principal del pasivo; TOTAL MN+ME' if detail is None else f'{detail}: subcuenta de obligaciones con el público, TOTAL MN+ME'),
            'reconciliation':{'companySum':sum(values.values()),'officialTotal':market,'difference':difference,'tolerance':0.0001}}


@lru_cache(maxsize=350)
def read_deposit_original(path,mtime,size,period,kind):
    path=Path(path);body=path.read_bytes();raw=parse_obligations(body,period,kind)
    raw['source']=provenance(path,body,raw.pop('sheet'),period,'B-2201',
        marketCell=raw.pop('marketCell'),institutionCells=raw.pop('cells'),concept=raw.pop('concept'))
    return raw

def parse_consumption_total(body,period):
    """Lee el padre SBS completo, sin sustituirlo por el universo del M48."""
    sheet,rows=first_sheet(body);internal_date(rows,period)
    parent,label_column=next((r,c) for r,row in enumerate(rows) for c,v in enumerate(row) if norm(v)=='creditos de consumo')
    label=lambda row:norm(row[label_column]) if label_column<len(row) else ''
    end=next((r for r in range(parent+1,len(rows)) if label(rows[r]).startswith('creditos ')),len(rows))
    section={label(rows[r]):r for r in range(parent+1,end) if label(rows[r])}
    required={'tarjetas':'tarjetas de credito','prestamos_no_revolventes':'prestamos no revolventes',
              'prestamos_revolventes':'prestamos revolventes','arrendamiento':'arrendamiento financiero y lease-back'}
    indices={key:section[value] for key,value in required.items()}
    indices['otros']=next(r for name,r in section.items() if name.startswith('otros '))
    direct=next(r for r,row in enumerate(rows) if label(row).startswith('total creditos directos'))
    if 'miles' not in label(rows[direct]):raise ValueError('B-2389: unidad de créditos directos no acreditada')
    header=next(row for row in rows[:15] if any('total banca multiple' in norm(v) for v in row))
    values={};locations={};components={};market=None;market_cell=None;market_components=None;signed=[]
    def amount(r,column):
        raw=rows[r][column] if column<len(rows[r]) else None
        # Ajustes netos negativos publicados en Otros/arrendamiento se conservan
        # en la identidad; nunca se convierten a cero ni cambian el padre SBS.
        if r in (indices['otros'],indices['arrendamiento']) and type(raw) in (int,float) and math.isfinite(raw):
            percentage=float(raw)
        else:percentage=numeric(raw)
        balance=numeric(rows[direct][column] if column<len(rows[direct]) else None)
        return percentage*balance/100000 if percentage is not None and balance is not None else None
    for column,name in enumerate(header):
        if not isinstance(name,str) or not name.strip() or norm(name)=='concepto':continue
        aggregate='total banca multiple' in norm(name)
        identifier=None if aggregate else bank_id(name)
        if identifier is None and not aggregate:continue
        total=amount(parent,column);parts={key:amount(r,column) for key,r in indices.items()}
        for key,value in parts.items():
            if value is not None and value<0:signed.append({'entity':identifier,'component':key,'value':value,'percentageCell':cell(indices[key],column)})
        other_keys=('prestamos_revolventes','arrendamiento','otros')
        parts['otras_modalidades']=sum(parts[key] for key in other_keys) if all(parts[key] is not None for key in other_keys) else None
        reconciled=None
        if total is not None and all(value is not None for value in parts.values()):
            reconciled=abs(total-parts['tarjetas']-parts['prestamos_no_revolventes']-parts['otras_modalidades'])<=0.000001
            if not reconciled:raise ValueError('B-2389: el consumo padre no concilia con sus modalidades')
        parts.update(total=total,reconciled=reconciled)
        if aggregate:market=total;market_cell=cell(parent,column);market_components=parts
        else:
            if identifier in values:raise ValueError('B-2389: empresa duplicada en consumo total')
            values[identifier]=total;components[identifier]=parts;locations[identifier]=cell(parent,column)
    if market is None or market<=0 or 'falabella' not in values:raise ValueError('B-2389: falta el consumo total oficial o Falabella')
    if all(value is not None for value in values.values()) and abs(sum(values.values())-market)>0.04:
        raise ValueError('B-2389: el consumo total de empresas no concilia con el agregado')
    return {'sheet':sheet,'values':values,'market':market,'cells':locations,'marketCell':market_cell,
        'concept':'Créditos de consumo: fila padre completa, incluye otras modalidades',
        'components':{'falabella':components['falabella'],'market':market_components},
        'modalitiesSource':{'percentRows':{key:r+1 for key,r in indices.items()},'directBalanceRow':direct+1,
            'signedPublishedComponents':signed,
            'excludedFromAddition':'Préstamos autos es una subcuenta de préstamos no revolventes; no se suma dos veces'}}


@lru_cache(maxsize=300)
def read_original(path,mtime,size,report,period):
    path=Path(path);body=path.read_bytes()
    data={'B-2363':parse_cards,'B-2201':parse_obligations,'B-2389':parse_consumption_total}[report](body,period)
    data['source']=provenance(path,body,data.pop('sheet'),period,report,
        marketCell=data.pop('marketCell'),institutionCells=data.pop('cells'),concept=data.pop('concept'))
    if 'modalitiesSource' in data:data['source']['modalities']=data.pop('modalitiesSource')
    return data


def observed_row(period,values,market,names,source):
    market=numeric(market);falabella=numeric(values.get('falabella'))
    if market is not None and market<=0:market=None
    known={key:numeric(value) for key,value in values.items() if value is not None}
    if market is not None and any(value>market+0.04 for value in known.values()):raise ValueError('Una empresa supera el total del mercado comparable')
    complete=len(known)==len(values);ordered=sorted(values,key=lambda key:(values[key] is None,-(values[key] or 0),names.get(key,key)))
    ranks={};previous=None;position=0
    for order,key in enumerate(ordered,1):
        if values[key] is None:continue
        if previous!=values[key]:position=order
        ranks[key]=position;previous=values[key]
    ranking=[{'id':key,'name':names.get(key,key),'value':numeric(values[key]),
              'share':100*values[key]/market if values[key] is not None and market else None,
              'rank':ranks.get(key) if complete else None,'universe':'banca_multiple'} for key in ordered]
    return {'date':period,'status':'observed','falabella':falabella,'market':market,
            'share':100*falabella/market if falabella is not None and market else None,'changeYoyPp':None,
            'rank':ranks.get('falabella') if complete else None,'rankingComplete':complete,
            'rankingCoverage':{'known':len(known),'expected':len(values)},'ranking':ranking,'source':source}


def product(identifier,name,unit,definition,report,rows,limitations,scope,unavailable=None,latest_source=None):
    rows=sorted(rows,key=lambda row:row['date']);previous={row['date']:row for row in rows}
    for row in rows:
        past=previous.get(f"{int(row['date'][:4])-1:04}{row['date'][4:]}")
        if past and past['share'] is not None and row['share'] is not None:row['changeYoyPp']=row['share']-past['share']
    dates=set(previous);missing=[]
    if dates:
        year,month=map(int,min(dates).split('-'))
        while f'{year:04}-{month:02}'<=max(dates):
            current=f'{year:04}-{month:02}'
            if current not in dates:missing.append(current)
            year,month=(year+1,1) if month==12 else (year,month+1)
    coverage={'consumo':'Consumo total SBS: todas las modalidades de la fila padre',
              'consumo_comparable':'Solo tarjetas de consumo y préstamos de consumo no revolventes; excluye las demás modalidades',
              'tarjetas_saldo':'Solo saldo de tarjetas de crédito de consumo',
              'prestamos_no_revolventes':'Solo préstamos de consumo no revolventes',
              'tarjetas_numero':'Número total de tarjetas de crédito de todos los tipos de crédito',
              'obligaciones_publico':'Cuenta principal de obligaciones con el público, MN+ME',
              'depositos_vista':'Depósitos a la vista dentro de obligaciones con el público, MN+ME',
              'depositos_ahorro':'Depósitos de ahorro dentro de obligaciones con el público, MN+ME',
              'depositos_plazo':'Depósitos a plazo dentro de obligaciones con el público, MN+ME (incluye CTS)',
              'depositos_cts':'Subcuenta C.T.S. de depósitos a plazo; NO sumar otra vez a plazo'}[identifier]
    return {'id':identifier,'name':name,'unit':unit,'universe':{'id':'banca_multiple','name':'Banca múltiple',
        'denominator':'official_sbs_sector_total','scope':scope,'productCoverage':coverage},'definition':definition,
        'source':{'report':report,'name':'SBS','url':SOURCE_URL},'periods':[row['date'] for row in rows],
        'first':rows[0]['date'] if rows else None,'latestPeriod':rows[-1]['date'] if rows else None,
        'rows':rows,'available':bool(rows),'projection':{'available':False,
            'modelIds':['07','48'] if identifier=='consumo_comparable' else [],
            'reason':'Usar los modelos 07 y 48 del escenario activo' if identifier=='consumo_comparable' else
                'El Modelo 48 cubre tarjetas y préstamos no revolventes, no el consumo total SBS' if identifier=='consumo' else
                'No hay una proyección homogénea validada para este producto'},
        'availability':{'missingPeriods':missing,'unavailablePeriods':unavailable or [],
                        'latestSourcePeriod':latest_source or (rows[-1]['date'] if rows else None)},'limitations':limitations}


def signature():
    paths=[cartera_consumo_bancos.PANEL,benchmark_eeff.DATA_PATH,*sorted(CONSUMPTION.glob('B-2389-*.XLS')),
           *sorted(CARDS.glob('B-2363_????_??.xls')),*sorted(BALANCES.glob('B-2201-*.XLS'))]
    return tuple((str(path),path.stat().st_mtime_ns,path.stat().st_size) for path in paths if path.is_file())


@lru_cache(maxsize=2)
def build(revision):
    panel=cartera_consumo_bancos.historical();names={bank['id']:bank['name'] for bank in panel['banks']}
    names.update(bank_reader().NAMES);names['trabajo']='Banco del Trabajo'
    result=[]
    total_rows=[];total_limitations=[];total_unavailable=[]
    for path in sorted(CONSUMPTION.glob('B-2389-*.XLS')):
        match=re.fullmatch(r'B-2389-([a-z]{2})(\d{4})',path.stem,re.I)
        if not match:continue
        period=f'{match[2]}-{MONTHS[match[1].lower()]:02}';stat=path.stat()
        try:
            raw=read_original(str(path),stat.st_mtime_ns,stat.st_size,'B-2389',period)
            row=observed_row(period,raw['values'],raw['market'],names,raw['source'])
            row['components']=raw['components'];total_rows.append(row)
        except (ValueError,StopIteration,KeyError,IndexError) as error:
            total_unavailable.append({'period':period,'reason':str(error)})
            total_limitations.append(f'B-2389/{period}: consumo total no disponible: {error}')
    total_limitations.append('El consumo total SBS incluye préstamos revolventes, arrendamiento y otros; los préstamos autos ya están dentro de no revolventes. Su universo difiere del Modelo 48.')
    total_limitations.append('Se conservan los pequeños ajustes negativos que la SBS publica en otras modalidades históricas; no se recortan a cero ni alteran el total padre.')
    result.append(product('consumo','Cartera total de consumo SBS','S/ millones',
        'Saldo bruto de la fila padre Créditos de consumo, todas sus modalidades. Otras modalidades = préstamos revolventes + arrendamiento + otros publicados.',
        'B-2389',total_rows,total_limitations,'Universo reportado B-2389, con sucursales en el exterior cuando lo indica la SBS',
        total_unavailable,panel['cutoff']))
    for identifier,key,name in (('consumo_comparable','cartera','Consumo comparable: tarjetas + préstamos no revolventes'),('tarjetas_saldo','tarjetas','Cartera de tarjetas de crédito de consumo'),
                                ('prestamos_no_revolventes','prestamos','Préstamos de consumo no revolventes')):
        rows=[]
        for observation in panel['rows']:
            period=observation['date'];values={bank:data.get(key) for bank,data in observation['bancos'].items()}
            for bank in panel['banks']:
                if bank.get('first','9999')<=period<=bank.get('last','0000'):values.setdefault(bank['id'],None)
            for data in [observation['mercado'],*observation['bancos'].values()]:
                if all(numeric(data.get(k)) is not None for k in ('tarjetas','prestamos','cartera')):
                    if abs(data['tarjetas']+data['prestamos']-data['cartera'])>0.000001:raise ValueError('B-2389: tarjetas y préstamos no concilian con consumo')
            source={'report':'B-2389','file':cartera_consumo_bancos.PANEL.relative_to(ROOT).as_posix(),
                    'url':source_url('B-2389',period),'concept':key,'processedRevision':panel.get('revision')}
            raw=CONSUMPTION/Path(source['url']).name
            if raw.is_file():source.update(rawFile=raw.relative_to(ROOT).as_posix(),rawSha256=hashlib.sha256(raw.read_bytes()).hexdigest())
            row=observed_row(period,values,observation['mercado'].get(key),names,source)
            if row['rankingComplete'] and abs(sum(value for value in values.values())-row['market'])>0.04:
                raise ValueError('B-2389: las empresas no concilian con el agregado oficial')
            rows.append(row)
        result.append(product(identifier,name,'S/ millones',panel['definition'] if identifier=='consumo_comparable' else
            'Saldo bruto de '+('tarjetas de crédito de consumo' if identifier=='tarjetas_saldo' else 'préstamos de consumo no revolventes')+', ambas monedas.',
            'B-2389',rows,[panel['note'],'El agregado corresponde al universo publicado B-2389, con sucursales en el exterior cuando así lo indica la SBS.'],
            'Universo reportado en B-2389; no sumar empresas financieras ni cajas rurales'))
    for identifier,name,unit,report,files in (
        ('tarjetas_numero','Número de tarjetas de crédito (total)','tarjetas','B-2363',sorted(CARDS.glob('B-2363_????_??.xls'))),
        ('obligaciones_publico','Obligaciones con el público','S/ millones','B-2201',sorted(BALANCES.glob('B-2201-*.XLS')))):
        rows=[];limitations=[];unavailable=[];source_periods=[]
        for path in files:
            match=re.fullmatch(r'B-2363_(\d{4})_(\d{2})',path.stem,re.I) if report=='B-2363' else re.fullmatch(r'B-2201-([a-z]{2})(\d{4})',path.stem,re.I)
            if not match:continue
            period=f'{match[1]}-{match[2]}' if report=='B-2363' else f'{match[2]}-{MONTHS[match[1].lower()]:02}'
            source_periods.append(period)
            stat=path.stat()
            try:
                raw=read_original(str(path),stat.st_mtime_ns,stat.st_size,report,period)
                rows.append(observed_row(period,raw['values'],raw['market'],names,raw['source']))
            except (ValueError,StopIteration,KeyError,IndexError) as error:
                limitations.append(f'{report}/{period}: {error}; no se fabrica una observación.')
                unavailable.append({'period':period,'reason':str(error)})
        if report=='B-2201':
            limitations.append('Historia limitada a originales B-2201 completos presentes en IASPE; las ausencias no se completan con la suma del benchmark de 17 entidades.')
            # Comparación con el lector existente de Falabella; nunca usar su
            # agregado seleccionado como denominador de mercado.
            benchmark=benchmark_eeff.account_data('balance:042')
            reference={row['date']:row['banks'].get('05') for row in benchmark['rows']}
            for row in rows:
                expected=reference.get(row['date'])
                if expected is not None and row['falabella'] is not None and abs(expected-row['falabella'])>0.000001:
                    raise ValueError('B-2201: obligaciones de Falabella difieren del benchmark observado')
        definition=('Número total de tarjetas de crédito de todos los tipos de crédito del reporte B-2363. No es el número sólo de consumo ni el saldo de tarjetas.'
                    if report=='B-2363' else 'Cuenta principal OBLIGACIONES CON EL PÚBLICO del pasivo, TOTAL MN+ME. No equivale sólo a depósitos de ahorro o a plazo.')
        scope=('Universo B-2363, con sucursales en el exterior cuando lo indica la SBS' if report=='B-2363' else
               'Banca múltiple doméstica; excluye los bloques adicionales de BCP y banca múltiple con sucursales en el exterior')
        result.append(product(identifier,name,unit,definition,report,rows,limitations,scope,unavailable,max(source_periods,default=None)))
    # Desglose comercial de captaciones: no sustituye ni altera B-2201 principal.
    # Cada subcuenta se extrae del mismo original, usando el mismo total de
    # banca múltiple doméstica por producto y verificando la conciliación.
    deposit_files=sorted(BALANCES.glob('B-2201-*.XLS'))
    deposits=(('depositos_ahorro','Depósitos de ahorro'),
              ('depositos_plazo','Depósitos a plazo (incluye CTS)'),
              ('depositos_vista','Depósitos a la vista'),
              ('depositos_cts','Depósitos CTS (dentro de plazo)'))
    for identifier,name in deposits:
        rows=[];limitations=[];unavailable=[];source_periods=[]
        for path in deposit_files:
            match=re.fullmatch(r'B-2201-([a-z]{2})(\d{4})',path.stem,re.I)
            if not match:continue
            period=f'{match[2]}-{MONTHS[match[1].lower()]:02}'
            source_periods.append(period)
            stat=path.stat()
            try:
                raw=read_deposit_original(str(path),stat.st_mtime_ns,stat.st_size,period,identifier)
                rows.append(observed_row(period,raw['values'],raw['market'],names,raw['source']))
            except (ValueError,StopIteration,KeyError,IndexError) as error:
                limitations.append(f'B-2201/{period}: {error}; sin imputación.')
                unavailable.append({'period':period,'reason':str(error)})
        definition=('Depósitos de ahorro del público, MN+ME, cuenta subordinada a obligaciones con el público.' if identifier=='depositos_ahorro' else
                    'Depósitos a plazo del público, MN+ME. Incluye CTS: no sumar ambos indicadores.' if identifier=='depositos_plazo' else
                    'Depósitos a la vista del público, MN+ME, cuenta subordinada a obligaciones con el público.' if identifier=='depositos_vista' else
                    'Depósitos C.T.S. del público, MN+ME. Subcuenta incluida dentro de depósitos a plazo; no es adicional.')
        result.append(product(identifier,name,'S/ millones',definition,'B-2201',rows,
            limitations+['La cobertura histórica depende de los originales B-2201 disponibles; las fechas sin archivo no se imputan.'],
            'Banca múltiple doméstica, sin sucursales en el exterior; TOTAL MN+ME',unavailable,max(source_periods,default=None)))
    return {'ready':any(item['rows'] for item in result),'revision':hashlib.sha256(repr(revision).encode()).hexdigest(),
            'latestPeriod':max((item['latestPeriod'] for item in result if item['latestPeriod']),default=None),
            'products':result,'institutions':[{'id':key,'name':value,'universe':'banca_multiple'} for key,value in names.items()],
            'limitations':['Los denominadores son agregados oficiales de banca múltiple por producto; no son la suma de las 17 entidades del benchmark.',
                           'No hay un universo completo validado de estos productos para financieras y cajas rurales en estas bases; no se mezclan sus agregados con banca múltiple.',
                           'Un mes o competidor ausente permanece sin dato. Las variaciones requieren exactamente el mismo mes del año anterior.']}


def catalog():
    """Invalida por rutas/mtime/tamaño; no consulta red ni ejecuta modelos."""
    return deepcopy(build(signature()))
