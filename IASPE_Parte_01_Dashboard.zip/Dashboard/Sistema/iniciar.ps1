﻿param([int]$Port = 8953)
$ErrorActionPreference = 'Stop'
$ProjectDirectory = [System.IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\','/')
$Release = 'IASPE-20261121-monitor-participacion-v1'

function Get-IaspeStatus([int]$CheckPort) {
    try {
        return Invoke-RestMethod -Uri "http://127.0.0.1:$CheckPort/api/status" -TimeoutSec 2
    } catch { return $null }
}

function Test-MatchingServer([int]$CheckPort) {
    $Result = Get-IaspeStatus $CheckPort
    if ($null -eq $Result) { return $false }
    if ($Result.app -ne 'IASPE' -or $Result.status -ne 'ok' -or $Result.release -ne $Release) { return $false }
    $OtherDirectory = [string]$Result.root
    return [string]::Equals($OtherDirectory.TrimEnd('\','/'), $ProjectDirectory, [System.StringComparison]::OrdinalIgnoreCase)
}

function Test-FreePort([int]$CheckPort) {
    $Listener = $null
    try {
        $Listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $CheckPort)
        $Listener.Start()
        return $true
    } catch { return $false }
    finally { if ($null -ne $Listener) { try { $Listener.Stop() } catch {} } }
}

try {
    # Si el usuario conserva una instancia antigua, elegir otro puerto. No usar su estado cacheado.
    $ChosenPort = 0
    $AlreadyStarted = $false
    foreach ($Candidate in ($Port .. ($Port + 20))) {
        if (Test-MatchingServer $Candidate) {
            $ChosenPort = $Candidate
            $AlreadyStarted = $true
            break
        }
        if (Test-FreePort $Candidate) {
            $ChosenPort = $Candidate
            break
        }
    }
    if ($ChosenPort -eq 0) { throw 'No hay un puerto local disponible para iniciar IASPE.' }

    # Validar que se hayan extraido las dos carpetas del proyecto al mismo nivel.
    $IASPEModels = [System.IO.Path]::GetFullPath((Join-Path $ProjectDirectory '..\..\IASPE\Modelos financieros'))
    if (-not (Test-Path -LiteralPath $IASPEModels -PathType Container)) {
        throw "No se encontro IASPE\Modelos financieros junto a Dashboard. Extraiga ambas carpetas en la misma ubicacion. Ruta buscada: $IASPEModels"
    }

    if (-not $AlreadyStarted) {
        $env:PYTHONIOENCODING = 'utf-8:backslashreplace'
        $PythonExecutable = (& python -c 'import sys; print(sys.executable)').Trim()
        if (-not (Test-Path -LiteralPath $PythonExecutable)) { throw 'No se encuentra Python.' }
        & $PythonExecutable -c 'import numpy, pandas, scipy, statsmodels, openpyxl, xlrd, xlsxwriter'
        if ($LASTEXITCODE -ne 0) { throw 'Faltan paquetes de Python. Revise requirements.txt.' }

        $ServerScript = Join-Path $ProjectDirectory 'servidor.py'
        $ServerArguments = @('-B', '-u', ('"' + $ServerScript + '"'), '--port', [string]$ChosenPort)
        $LogOut = Join-Path $ProjectDirectory "servidor_$ChosenPort.log"
        $LogErr = Join-Path $ProjectDirectory "servidor_$ChosenPort`_error.log"
        Start-Process -FilePath $PythonExecutable -ArgumentList $ServerArguments -WorkingDirectory $ProjectDirectory -WindowStyle Hidden -RedirectStandardOutput $LogOut -RedirectStandardError $LogErr | Out-Null
        for ($Attempt = 0; $Attempt -lt 60; $Attempt++) {
            Start-Sleep -Milliseconds 500
            if (Test-MatchingServer $ChosenPort) { break }
        }
        if (-not (Test-MatchingServer $ChosenPort)) {
            $Cause = ''
            if (Test-Path $LogErr) { $Cause = ((Get-Content $LogErr -Tail 7 -ErrorAction SilentlyContinue) -join "`n") }
            throw "No se pudo abrir el servidor IASPE. $Cause"
        }
    }

    $LocalUrl = "http://127.0.0.1:$ChosenPort"
    try {
        $State = Invoke-RestMethod -Uri "$LocalUrl/api/state" -TimeoutSec 120 -ErrorAction Stop
    } catch {
        $ResponseText = [string]$_.ErrorDetails.Message
        if (-not $ResponseText -and $null -ne $_.Exception.Response) {
            try {
                $Stream = $_.Exception.Response.GetResponseStream()
                if ($null -ne $Stream) {
                    $Reader = New-Object System.IO.StreamReader($Stream)
                    $ResponseText = $Reader.ReadToEnd()
                }
            } catch {}
        }
        $Reason = [string]$_.Exception.Message
        if ($ResponseText) {
            try {
                $Payload = $ResponseText | ConvertFrom-Json -ErrorAction Stop
                if ($Payload.error) { $Reason = [string]$Payload.error }
                else { $Reason = $ResponseText }
            } catch { $Reason = $ResponseText }
        }
        $LogErr = Join-Path $ProjectDirectory "servidor_$ChosenPort`_error.log"
        $LastTrace = ''
        if (Test-Path -LiteralPath $LogErr) {
            $LastTrace = ((Get-Content -LiteralPath $LogErr -Tail 12 -ErrorAction SilentlyContinue) -join "`n")
        }
        $Detail = "ERROR DE CARGA IASPE. $Reason`nURL local: $LocalUrl`nArchivo de diagnostico: $LogErr"
        if ($LastTrace) { $Detail += "`nDetalle del servidor:`n$LastTrace" }
        throw $Detail
    }
    if (-not $State.meta -or -not $State.models) { throw 'El servidor no devolvio el catalogo de modelos. Revise los Excel de Modelos financieros.' }

    $Expected = @(1..32 | ForEach-Object { '{0:00}' -f $_ })
    $Loaded = @($State.models | ForEach-Object { [string]$_.id })
    $Missing = @($Expected | Where-Object { $_ -notin $Loaded })
    if ($Missing.Count -gt 0) {
        throw "Faltan modelos: $($Missing -join ', '). Compruebe que IASPE/Modelos financieros contiene los modelos 01 al 32."
    }
    if ([int]$State.meta.modelCount -lt 32) {
        throw "Solo se reconocen $($State.meta.modelCount) modelos principales. Se esperaban al menos 32."
    }
    $OpenUrl = "$LocalUrl/#catalogo"
    Write-Host "Plataforma IASPE disponible en: $OpenUrl" -ForegroundColor Green
    try {
        Start-Process -FilePath $OpenUrl -ErrorAction Stop | Out-Null
    } catch {
        try { Start-Process -FilePath 'explorer.exe' -ArgumentList $OpenUrl -ErrorAction Stop | Out-Null }
        catch { Write-Host "No se pudo abrir el navegador. Copia esta dirección: $OpenUrl" -ForegroundColor Yellow }
    }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
