#!/usr/bin/env python3
"""Genera un panel de balances/resultados SBS observado de los XLSX locales.

No modifica las fuentes. Utiliza un lector OOXML con biblioteca estándar,
sin necesidad de Excel, pandas u otras dependencias adicionales.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import gzip
import hashlib
import json
from pathlib import Path
import re
import unicodedata
import sys
from xml.etree import ElementTree as ET
from zipfile import ZipFile

NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
    'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
REL_NS='{http://schemas.openxmlformats.org/package/2006/relationships}'
XLS_NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
SHEET_NAMES={'balance':'SITUACION_FINANCIERA', 'er_acumulado':'ESTADO_RESULTADOS', 'er_mensual':'ER_MENSUAL'}
LABELS={'balance':'Estado de situación financiera','er_acumulado':'Estado de resultados acumulado','er_mensual':'Estado de resultados mensual'}
SBS_URL='https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c=ED-00001'

def normalize(s):
    return ' '.join(''.join(x for x in unicodedata.normalize('NFKD',str(s or '')).lower() if not unicodedata.combining(x)).split())

def col_index(ref):
    letters=re.match(r'[A-Z]+',ref)
    n=0
    for x in letters.group():n=n*26+ord(x)-64
    return n-1

def book_sheet_values(path):
    """Devuelve solo las tres hojas publicadas; celdas vacías permanecen como None."""
    with ZipFile(path) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            for item in root.findall('m:si',NS):
                shared.append(''.join(x.text or '' for x in item.iter(XLS_NS+'t')))
        book=ET.fromstring(z.read('xl/workbook.xml'))
        relroot=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets={r.attrib.get('Id'):r.attrib.get('Target','') for r in relroot}
        sheets={}
        for sh in book.findall('m:sheets/m:sheet',NS):
            name=sh.attrib.get('name')
            if name not in SHEET_NAMES.values():continue
            rid=sh.attrib.get('{%s}id'%NS['r'])
            target=targets[rid].lstrip('/')
            if not target.startswith('xl/'):target='xl/'+target
            target=target.replace('xl/../','')
            rows=[]
            xml=ET.fromstring(z.read(target))
            for row in xml.findall('m:sheetData/m:row',NS):
                index=int(row.attrib['r'])
                if index<6:continue
                cells={}
                for cell in row.findall('m:c',NS):
                    col=col_index(cell.attrib['r']);t=cell.attrib.get('t')
                    v=cell.find('m:v',NS)
                    if v is not None and v.text is not None:
                        if t=='s':
                            value=shared[int(v.text)]
                        elif t in ('str','e'):value=v.text
                        elif t=='b':value=(v.text=='1')
                        else:
                            try:value=float(v.text)
                            except ValueError:value=v.text
                    else:
                        isv=cell.find('m:is',NS)
                        value=''.join(x.text or '' for x in isv.iter(XLS_NS+'t')) if isv is not None else None
                    if value is not None:cells[col]=value
                rows.append((index,cells))
            sheets[name]=rows
        return sheets

def excel_date(value):
    if not isinstance(value,(int,float)):
        raise ValueError(f'fecha XLSX inesperada: {value!r}')
    return (datetime(1899,12,30)+timedelta(days=value)).strftime('%Y-%m')

def source_row(sheet):
    header=next((v for row,v in sheet if row==6),None)
    if header is None:raise ValueError('No existe la fila 6 con los periodos')
    months=[]
    for i in sorted(x for x in header if x>0):
        value=header[i]
        if isinstance(value,(float,int)):
            months.append((i,excel_date(value)))
    if not months:raise ValueError('No hay meses en encabezado')
    if len(set(m for _,m in months))!=len(months):raise ValueError('Meses duplicados')
    return months

def build(root, out):
    sys.path.insert(0,str(root.parent/'Dashboard'/'Sistema'))
    from instituciones_sbs import BANKS, entity_metadata
    base=root/'Estados financieros banca'/'SBS tal cual'
    sources=sorted(base.glob('*/*.xlsx'))
    if not sources:raise FileNotFoundError(f'No se encontraron EEFF en {base}')
    banks=[]; raw={}; audits=[]
    for source in sources:
        bankid=source.parent.name.split(' ',1)[0]
        if bankid not in BANKS:raise ValueError(f'Entidad no catalogada: {source}')
        if any(b['id']==bankid for b in banks):raise ValueError(f'Entidad duplicada: {bankid}')
        # Los nombres de directorio son ASCII; las etiquetas oficiales conservan sus tildes.
        bancos_oficiales = {
            '01': 'Banco de Crédito del Perú', '03': 'BBVA Perú',
            '04': 'Scotiabank Perú', '05': 'Banco Falabella Perú',
        }
        bankname = BANKS[bankid]
        sheets=book_sheet_values(source)
        if set(sheets)!=set(SHEET_NAMES.values()):raise ValueError(f'Hojas incompletas: {source}')
        b={**entity_metadata(bankid),'name':bankname,'source':str(source.relative_to(root)).replace('\\','/'),
           'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
        banks.append(b)
        for k,name in SHEET_NAMES.items():
            months=source_row(sheets[name]); values={}
            for row,cells in sheets[name]:
                if row<7 or 0 not in cells:continue
                label=cells[0]
                if not isinstance(label,str) or not label.strip():continue
                values[row]={'label':label.strip(),'indent':len(label)-len(label.lstrip()),
                             'values':{date: (cells.get(col)/1000 if isinstance(cells.get(col),(int,float)) and not isinstance(cells.get(col),bool) else None)
                                       for col,date in months}}
            # El lector nativo conserva variantes de posición/estilo históricas.
            # Estos totales tienen el mismo rótulo; se unen solo si sus meses
            # no se solapan. Los rótulos ambiguos (p. ej. Otros) quedan separados.
            totals={'total activo','total pasivo','total patrimonio','total pasivo y patrimonio',
                    'resultado neto del ejercicio','ingresos financieros','gastos financieros'}
            first_rows={}
            for row,meta in list(values.items()):
                label=normalize(meta['label'])
                if label not in totals:continue
                active={p:v for p,v in meta['values'].items() if v is not None}
                if label in first_rows:
                    previous=values[first_rows[label]]
                    prior={p:v for p,v in previous['values'].items() if v is not None}
                    if set(active)&set(prior):
                        raise ValueError(f'Total duplicado en el mismo mes: {bankid}/{name}/{label}')
                    previous['values'].update(active)
                    del values[row]
                else:first_rows[label]=row
            raw[bankid,k]=values
            audits.append({'bank':bankid,'sheet':k,'accounts':len(values),'months':len(months),'first':months[0][1],'last':months[-1][1]})
    # La SBS muestra algunas filas adicionales en determinados bancos. Por ello,
    # no se homologan por número de fila. Se vinculan por etiqueta literal
    # normalizada y orden de aparición, conservando las cuentas propias de cada banco.
    # Dos rótulos iguales dentro de un estado representan cuentas diferentes:
    # el ordinal evita mezclar, por ejemplo, "Otros" de diferentes bloques.
    reference=next(b for b in banks if b['id']=='05')
    catalog=[]; series={}; keys={}; warnings=[]
    target=out/'panel_eeff_16_bancos.json.gz'
    prior_ids={}
    if target.is_file():
        with gzip.open(target,'rt',encoding='utf-8') as fp:previous=json.load(fp)
        prior_ids={(x['section'],normalize(x['name']),x.get('occurrence',1)):x['id']
                   for x in previous['meta']['accounts']}
    used_ids=set(prior_ids.values())
    next_id=max((int(x.rsplit(':',1)[1]) for x in used_ids),default=-1)+1
    # Las cuentas nuevas de una institución no desplazan los IDs de las cuentas
    # existentes, que también se utilizan para vincular observaciones a modelos.
    established=[reference]+[b for b in banks if b['id'] not in (reference['id'],'crac_18')]
    newcomers=[b for b in banks if b['id']=='crac_18']
    for selected_banks in (established,newcomers):
      for section in SHEET_NAMES:
        for bank in selected_banks:
            counts=Counter();group='General'
            for row,meta in raw[bank['id'],section].items():
                norm=normalize(meta['label']);counts[norm]+=1
                key=(section,norm,counts[norm])
                if meta['indent']==0:group=meta['label']
                if key not in keys:
                    if key in prior_ids:id=prior_ids[key]
                    else:
                        id=f'{section}:{next_id:03d}';next_id+=1
                    keys[key]=id
                    catalog.append({'id':id,'section':section,'name':meta['label'],
                                    'group':group,'occurrence':counts[norm],
                                    'indent':meta['indent'],'source_row':row})
                    series[id]={}
                id=keys[key]
                if bank['id'] in series[id]:raise AssertionError('Filas distintas de un mismo banco unidas')
                series[id][bank['id']]={month:round(v,8) for month,v in meta['values'].items() if v is not None}
    for account in catalog:
        account['banks_available']=sum(bool(values) for values in series[account['id']].values())
    mismatches=[]
    # Informar cuentas exclusivas o variantes no compartidas con la entidad base.
    for account in catalog:
        if account['banks_available']<len(banks):
            mismatches.append({'account':account['id'],'label':account['name'],
                               'banks_with_data':account['banks_available']})
    # No agregamos fuentes ajenas al conjunto seleccionado ni imputamos faltantes.
    allmonths=sorted({month for bankseries in series.values() for values in bankseries.values() for month in values})
    meta={'format':'iaspe_eeff_benchmark_v1','unit':'S/ millones','value_type':'observed',
          'source_name':'SBS · Balance General y Estado de Ganancias y Pérdidas', 'source_url':SBS_URL,
          'source_note':'Fuentes locales SBS tal cual. Total en miles de soles convertido a S/ millones; conserva signos y vacíos. No contiene datos proyectados.',
          'market_note':'El agregado suma las instituciones seleccionadas con cifras del periodo. Puede reunir bancos, financieras y cajas rurales; no es un total sectorial oficial. La cobertura varía por mes.',
          'income_note':'El estado de resultados acumulado es de enero al cierre del mes; el mensual corresponde a diferencia entre acumulados dentro del mismo año. No sumar acumulados entre meses.',
          'coverage_note':'Solo se incorporan bancos y meses presentes en los archivos SBS locales. Se preservan faltantes; no se interpretan como cero.',
          'banks':banks,'sections':[{'id':id,'name':LABELS[id]} for id in SHEET_NAMES],
          'accounts':catalog,'months':allmonths,'first':allmonths[0], 'last':allmonths[-1],
          'audit':{'files':audits,'unmatched_accounts':mismatches}}
    output={'meta':meta,'series':series}
    out.mkdir(parents=True,exist_ok=True)
    target=out/'panel_eeff_16_bancos.json.gz'
    with gzip.open(target,'wt',encoding='utf8',compresslevel=7) as f:json.dump(output,f,ensure_ascii=False,separators=(',',':'))
    (out/'auditoria_panel.json').write_text(json.dumps({'files':audits,'unmatched_accounts':mismatches},ensure_ascii=False,indent=2),encoding='utf8')
    print('bancos',len(banks),'cuentas',len(catalog),'rango',allmonths[0],allmonths[-1],'desalineaciones',len(mismatches),'output',target,target.stat().st_size)
    for it in audits[::3]:print(it)
    if mismatches:print('Primeras diferencias:',mismatches[:12])
    return output

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--iaspe',type=Path,default=Path(__file__).resolve().parents[2])
    args=parser.parse_args()
    build(args.iaspe,Path(__file__).resolve().parents[1]/'output')
