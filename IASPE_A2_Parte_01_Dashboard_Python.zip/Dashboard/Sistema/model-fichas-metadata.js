/* Fichas técnicas basadas en los coeficientes del motor y en las reglas de cierre 2026. */
(() => {
  'use strict';
  const finite = n => typeof n === 'number' && Number.isFinite(n);
  const num = n => finite(n) ? Number(n.toPrecision(7)).toString() : null;
  const combine = (c, terms) => {
    if (!c || c.length !== terms.length+1 || !c.every(x => finite(x?.value ?? x?.estimate))) return '';
    const values = c.map(x => x.value ?? x.estimate);
    return num(values[0]) + terms.map((term,i) => (values[i+1] >= 0 ? '+' : '') + num(values[i+1]) + term).join('');
  };
  const eq = (lhs,coeff,terms,ending='') => {
    const expression = combine(coeff,terms);
    return expression ? lhs + '=' + expression + ending : '';
  };
  const closure = {
    '01':'Cierre 2026 provisional a partir de la información de tarjetas disponible hasta agosto; el stock de diciembre es estimado, no observado.',
    '02':'El cierre 2026 se toma de la serie anual del modelo original, como supuesto hasta contar con diciembre observado.',
    '03':'Cierre 2026 = compras observadas de enero a julio + compras estimadas de agosto a diciembre mediante los patrones de crecimiento mensual del modelo.',
    '04':'Cierre 2026: septiembre–diciembre se estiman aplicando a cada mes de 2025 la media interanual observada de enero–agosto de 2026; diciembre es el stock anual.',
    '05':'Cierre 2026: septiembre–diciembre se estiman con el mismo mes de 2025 y la media interanual observada de enero–agosto de 2026; se utiliza el saldo de diciembre.',
    '06':'El saldo de diciembre de 2026 es el cierre supuesto del Output original, utilizado como punto de partida de la regresión anual de variaciones.',
    '07':'Cierre diciembre 2026 = colocaciones revolventes de diciembre + colocaciones no revolventes de diciembre.',
    '08':'Cierre 2026 = saldo de ahorro en moneda nacional + saldo en moneda extranjera, ambos tomados de sus cierres supuestos.',
    '08_mn':'Cierre 2026 supuesto del Output de ahorro en moneda nacional; desde 2027 la regresión aplica el crecimiento anual estimado al saldo de cierre anterior.',
    '08_me':'Cierre 2026 supuesto del Output de ahorro en moneda extranjera; desde 2027 la regresión aplica la variación logarítmica al saldo de cierre anterior.',
    '09':'Cierre diciembre 2026 = depósitos a plazo ordinarios + depósitos CTS, según los dos componentes del Output.',
    '09_plazo':'Se toma el saldo observado de agosto de 2026 y se proyectan septiembre–diciembre con la variación restante estimada por la MCO estacional; el cierre es diciembre, no un promedio mensual.',
    '09_cts':'El saldo de diciembre de 2026 se obtiene de la trayectoria mensual de CTS con datos observados hasta agosto y cierres supuestos de septiembre–diciembre.',
    '10':'Cierre 2026 = ahorro + plazo + depósitos restringidos + otras obligaciones, utilizando sus saldos de diciembre.',
    '10_restringidos':'Diciembre 2025 multiplicado por la razón entre el promedio junio–agosto 2026 y el promedio junio–agosto 2025; desde 2027 mantiene su participación en ahorro + plazo.',
    '10_otras':'Diciembre 2025 multiplicado por la razón entre el promedio junio–agosto 2026 y el promedio junio–agosto 2025; desde 2027 mantiene su participación en ahorro + plazo.',
    '11':"Cierre 2026: se conserva la última tasa implícita mensual disponible. Desde 2027, MCO del costo con TPM e inflación del escenario vigente y participación de depósitos a plazo del año anterior; estimación 2016–2026, incluido cierre supuesto.",
    '12':'Gasto de 2026 = gastos anuales por obligaciones con el público + depósitos de entidades financieras + adeudos + otras fuentes.',
    '12_entidades':'Gasto 2026 = suma enero–agosto observado + cuatro meses septiembre–diciembre iguales al último gasto mensual observado (agosto). La regresión modela el logaritmo de Gasto + 0,05.',
    '12_adeudos':'Gasto 2026 = suma enero–agosto observado + cuatro meses septiembre–diciembre con el último gasto mensual observado (agosto). La regresión se estima en niveles.',
    '12_otras':'Gasto 2026 = suma enero–agosto observado + cuatro meses septiembre–diciembre con el último gasto mensual observado (agosto). La regresión usa ln(1 + Gasto).',
    '12_obligaciones':'Gasto 2026 = enero–agosto observado + cuatro meses supuestos al gasto mensual de agosto. El factor de calibración utiliza 2015–2026 y sí incorpora 2026 como cierre supuesto, no observado. Desde 2027: obligaciones promedio × costo implícito promedio × factor histórico.',
    '13':'Tasa de cierre 2026 igual a la última tasa mensual observada (agosto), mantenida de septiembre a diciembre.',
    '14':'Tasa de cierre 2026 igual a la última tasa mensual observada (agosto), mantenida de septiembre a diciembre.',
    '15':'Tasa de cierre 2026 igual a la última tasa mensual observada (agosto), mantenida de septiembre a diciembre.',
    '16':'Ingresos 2026 = ingresos por créditos, inversiones, disponibilidades y fondos interbancarios, sumados como flujos anuales.',
    '16_creditos':'Ingresos 2026 = enero–agosto observado + cuatro veces el ingreso mensual de agosto. Desde 2027 se utiliza el rendimiento estimado multiplicado por la cartera promedio.',
    '16_disponible':'Ingresos 2026 = enero–agosto observado + cuatro veces el ingreso mensual de agosto. Desde 2027 se proyecta el logaritmo del flujo anual.',
    '16_interbancarios':'Ingresos 2026 = enero–agosto observado + cuatro veces el ingreso mensual de agosto. Desde 2027 se proyecta el logaritmo del flujo anual.',
    '16_inversiones':'Ingresos 2026 = enero–agosto observado + cuatro veces el ingreso mensual de agosto. Su rendimiento implícito 2026 se aplica a inversiones promedio de los años siguientes.',
    '17':'Disponible 2026 = caja + bancos y corresponsales + canje + otros disponibles, con sus respectivos saldos de diciembre.',
    '17_caja':'Con datos mensuales observados hasta agosto de 2026, la MCO mensual autorregresiva genera septiembre–diciembre; el saldo anual se toma de diciembre.',
    '17_canje':'La proyección de septiembre–diciembre mantiene el último saldo observado de agosto de 2026; el cierre se mide en diciembre.',
    '17_otros':'La proyección de septiembre–diciembre mantiene el último saldo observado de agosto de 2026; el cierre se mide en diciembre.',
    '17_bancos':'El saldo 2026 se obtiene como cuenta residual de la conciliación de activos, pasivos y patrimonio; no constituye una proyección autónoma de liquidez.',
    '18':'Resultado neto 2026 = ingresos diversos + otros ingresos − gastos diversos − otros gastos, según el consolidado.',
    '18_diversos':'El ingreso acumulado a agosto de 2026 se multiplica por el cociente entre diciembre y agosto de 2025 (332,77/215,82). El cierre estimado de 2026 ancla las dos trayectorias MCO desde 2027.',
    '18_gastos_div':'Se conserva el gasto supuesto 2026; desde 2027 se aplica la proporción gasto/ingreso diverso de ese cierre a los ingresos diversos proyectados.',
    '19':'Gasto administrativo 2026 = personal + directorio + servicios de terceros + impuestos/contribuciones del consolidado.',
    '19_personal':'El gasto acumulado a agosto de 2026 se divide entre la mediana de los factores agosto/diciembre de 2023–2025 (0,638406). Así se estima el cierre 2026; desde 2027, la dotación proyectada por MCO y la inflación actualizan el gasto.',
    '19_terceros':'El gasto acumulado a agosto de 2026 se divide entre la mediana agosto/diciembre de 2023–2025 (0,610821). Las dos MCO parten del cierre estimado y se combinan desde 2027 con ponderaciones 75% y 25%.',
    '19_directorio':'Se conserva el gasto de directorio de 2026 y se mantiene su nivel en los años posteriores.',
    '19_impuestos':'Se conserva el gasto supuesto 2026; desde 2027 el gasto se actualiza con la inflación anual prevista.',
    '20':'Resultado de operaciones financieras 2026 = suma de los seis componentes financieros del consolidado.',
    '20_tc':'Se conserva el cierre supuesto 2026 de diferencia de cambio y derivados. Su importe conjunto, dividido por compras del mercado de 2026, fija la intensidad para 2027–2030.',
    '21':'Inversiones financieras 2026 = inversiones disponibles para la venta + subsidiarias + otras inversiones.',
    '21_venta':'Se mantiene el presupuesto de Tesorería aprobado para el cierre 2026; los años siguientes se toman del plan de inversiones.',
    '22':'Se usa el saldo supuesto de fondos interbancarios a diciembre de 2026 procedente del Output.',
    '22_interbancarios':'Se usa el saldo supuesto de fondos interbancarios a diciembre de 2026 procedente del Output.',
    '23':'Margen financiero bruto 2026 = ingresos por intereses y gastos financieros, conforme a la identidad del Estado de Resultados.',
    '24':'Se mantiene el cierre 2026 de otros ingresos y gastos del escenario IASPE aprobado, sin una regresión adicional.',
    '25':"Cierre 2026: provisiones acumuladas SBS al último mes observado más los meses faltantes multiplicados por el promedio de los tres últimos flujos mensuales observados. A septiembre: 247.995 + 93.461 = 341.456 millones. Desde 2027, inputs de Riesgos sin cambios.",
    '26':'Cierre 2026 del IASC: nueve meses observados y tres meses de cierre supuesto (9+3).',
    '27':'Cierre 2026 del IASC: nueve meses observados y tres meses de cierre supuesto (9+3).',
    '28':'Cierre 2026 del IASC: nueve meses observados y tres meses de cierre supuesto (9+3).',
    '29':'Resultado neto 2026 conforme a las partidas del Estado de Resultados del IASPE; el cierre incorpora sus supuestos 2026.',
    '30':'Se conserva el cierre 2026 de líneas no utilizadas del Output; desde 2027 se calcula la media de tres años de líneas por tarjeta y se multiplica por las tarjetas previstas.',
    '31':'El cierre 2026 de cuentas por cobrar se toma del Output como saldo supuesto; desde 2027 la MCO determina el crecimiento logarítmico anual.',
    '32':'El cierre 2026 de rendimientos por cobrar se toma del Output como saldo supuesto; desde 2027 la MCO explica su variación con el cambio de ingresos por créditos.',
    '33':'Se utiliza el cierre supuesto 2026 de activo fijo, incorporando el CAPEX y la depreciación del presupuesto; desde 2027 se aplica su movimiento contable.',
    '34':'Se mantiene el cierre 2026 de otros activos del Output, con sus componentes presupuestados; el activo operativo de 2029–2030 crece con cartera.',
    '35':'Depósitos del sistema financiero: cierre 2026 del presupuesto de la cuenta y su saldo SBS de referencia.',
    '36':'Obligaciones en circulación: cierre 2026 según el presupuesto del Banco y el saldo contable utilizado por IASPE.',
    '37':'Cuentas por pagar: cierre supuesto 2026 de la hoja Output de la cuenta; desde 2027 se mantienen los drivers de la proyección aprobada.',
    '38':'Intereses y gastos por pagar: cierre 2026 calculado sobre las obligaciones y cuentas de fondeo, con los factores de la hoja Drivers_Base.',
    '39':'Otros pasivos: cierre supuesto 2026 de la hoja Output, ancla para su proyección anual.',
    '40':'Provisiones del pasivo: cierre 2026 con provisiones de créditos indirectos y otras provisiones; las otras provisiones siguen el gasto de personal.',
    '41':'Capital social 2026 procedente del presupuesto y del saldo SBS adoptado en el modelo.',
    '42':'Capital adicional 2026 procedente del presupuesto y del saldo SBS adoptado en el modelo.',
    '43':'Reservas 2026 procedentes del presupuesto y del saldo SBS adoptado en el modelo.',
    '44':'Ajustes al patrimonio 2026 según el cierre supuesto contable del Output.',
    '45':'Resultados acumulados 2026 del cierre aprobado: saldo anterior + utilidad aplicable − transferencias a reservas − dividendos; los dividendos quedan limitados a resultados disponibles.',
    '46':'El resultado neto de 2026 se traslada desde el Estado de Resultados al patrimonio, sin reestimación.',
    '47':'Balance 2026 conciliado por la identidad Activos = Pasivos + Patrimonio; bancos y corresponsales absorbe el ajuste residual.',
    '48':'Cartera 2026: el cierre de diciembre 2025 se multiplica por el crecimiento interanual del saldo SBS al último mes comparable de 2026 (agosto). El modelo anual se estima con ese cierre supuesto.',
    '48_cuota':'Cuota 2026 = cartera de consumo de Falabella (revolvente + no revolvente) dividida entre cartera total de consumo de la banca múltiple.',
    '49':'Amortización 2026 implícita: saldo inicial + compras con tarjetas + disposiciones RappiCash + desembolsos no revolventes − saldo final − castigos, separados por modalidad.'
  };
  const future = {
    '08_mn':'2027–2030: variación porcentual anual MCO, aplicada al saldo del año anterior.',
    '08_me':'2027–2030: crecimiento logarítmico anual MCO, reconstruido desde el saldo del año anterior.',
    '09_plazo':'2027–2028: la senda MCO incorpora separadamente el ajuste del plan IASC de captaciones; desde 2029 retorna a su crecimiento MCO.',
    '09_cts':'2027–2030: crecimiento anual de CTS según la regresión y su indicador histórico de 2021.',
    '11':'2027–2030: MCO con TPM e inflación contemporáneas y participación a plazo rezagada.',
    '12_entidades':'2027–2030: el pronóstico de gasto se reconstruye mediante exp(predicción logarítmica) − 0,05.',
    '12_otras':'2027–2030: el pronóstico de gasto se reconstruye mediante exp(predicción logarítmica) − 1.',
    '12_adeudos':'2027–2030: gasto anual en niveles vinculado a la TPM; se restringe a cero si el pronóstico fuera negativo.',
    '16_disponible':'2027–2030: ingresos en niveles obtenidos como exponencial de la MCO logarítmica.',
    '16_interbancarios':'2027–2030: ingresos en niveles obtenidos como exponencial de la MCO logarítmica.',
    '17_caja':'2027–2030: proyección mensual autorregresiva; el saldo anual es diciembre.',
    '18_diversos':'2027–2030: 75% de la senda MCO con inflación y 25% de la senda MCO con compras; la combinación se realiza en niveles.',
    '19_terceros':'2027–2030: 75% de la senda MCO de crecimiento logarítmico con PBI y 25% de la senda MCO en niveles con gasto rezagado.',
    '19_personal':'2027–2030: gasto anterior × variación de trabajadores promedio × (1 + inflación/100).'
  };
  const rationales = {"08_mn": "Regresión del crecimiento porcentual anual del ahorro en moneda nacional con PBI e inflación rezagados y un indicador de los años 2024–2025. El saldo futuro se reconstruye desde el cierre anterior.", "08_me": "Regresión del crecimiento logarítmico del ahorro en moneda extranjera con el cambio rezagado del tipo de cambio de cierre. El crecimiento estimado se aplica al saldo previo.", "09_plazo": "Regresión de la variación porcentual anual de depósitos a plazo ordinarios con PBI, inflación y cambio de TPM. El plan IASC de captaciones se incorpora como ajuste separado, no como coeficiente.", "09_cts": "Regresión del crecimiento anual del saldo CTS, con un indicador para la ruptura de 2021. La ecuación describe el patrón histórico; no representa un crecimiento fijo.", "11": "La TPM representa las condiciones monetarias; la inflación recoge el entorno nominal y la participación a plazo rezagada refleja la composición previa del fondeo. La relación es predictiva, no causal.", "12_entidades": "Regresión del logaritmo del gasto anual por depósitos de entidades financieras más 0,05, con tasa de referencia BCRP e inflación. Para obtener el gasto se invierte la transformación exponencial.", "12_adeudos": "Regresión del gasto anual por adeudos en niveles, con tasa de referencia BCRP y control temporal de 2020–2021.", "12_otras": "Regresión del logaritmo de uno más el gasto anual por otras fuentes, con tasa de política monetaria rezagada.", "16_disponible": "Regresión del logaritmo de los ingresos anuales por disponibilidades, explicada por PBI y el ingreso logarítmico del año anterior.", "16_interbancarios": "Regresión del logaritmo de ingresos anuales de fondos interbancarios con indicador de 2020–2021. Se recuperan montos mediante la transformación exponencial.", "17_caja": "Regresión autorregresiva mensual del saldo de caja: cada mes se estima con el saldo del mes previo. El valor anual se toma del mes de diciembre.", "18_diversos": "Dos MCO del crecimiento de ingresos diversos: la primera relaciona inflación e indicadores históricos y la segunda relaciona crecimiento de compras con tarjetas. Cada ecuación genera una senda de ingresos desde 2026; después se combinan 75% y 25% en niveles.", "19_terceros": "Dos regresiones distintas: una explica el crecimiento logarítmico anual de servicios de terceros mediante el PBI; la otra explica el nivel de gasto mediante el PBI y su propio rezago. Las dos trayectorias se combinan 75% y 25%.", "19_personal": "La dotación se proyecta con una regresión del crecimiento logarítmico de trabajadores frente al PBI y un indicador 2020–2021. El gasto de personal posterior incorpora trabajadores promedio e inflación, sin una segunda regresión del gasto.", "31": "Regresión del crecimiento logarítmico de cuentas por cobrar netas mediante el PBI real anual; el saldo se recupera desde el cierre anterior.", "32": "Regresión de la variación anual de rendimientos por cobrar frente al cambio anual de ingresos por créditos."};
  function identifyClosure(model) {
    if (closure[model.id]) return closure[model.id];
    if (model.id.startsWith('47_')) return 'Cierre 2026 calculado como componente de la conciliación contable del balance; se toma el saldo del modelo de Estado de Situación Financiera.';
    if (model.id.startsWith('49_')) return 'Cierre 2026 derivado de las amortizaciones de consumo y su distribución por tarjetas, RappiCash y préstamos; no se estima una regresión adicional.';
    const r=(model.annual||[]).find(row => Number(row.year)===2026);
    if (!r) return 'No hay un cierre 2026 registrado en la serie anual.';
    if (r.status==='observed') return 'El cierre diciembre 2026 es observado y procede de la fuente contable.';
    return `El cierre 2026 es el valor supuesto del Output del modelo; la fuente no identifica en esta ficha una regla mensual reproducible. No equivale a diciembre observado.`;
  }
  function getEquation(model) {
    const c=model.coefficients||[], id=model.id;
    const simple={
      '08_mn':()=>eq('\\widehat g_t',c,['\\,PBI_{t-1}','\\,\\pi_{t-1}','\\,D_{2024,2025;t}'],',\\quad g_t=100(S_t/S_{t-1}-1)'),
      '08_me':()=>eq('\\widehat g_t',c,['\\,(TC_{t-1}-TC_{t-2})'],',\\quad g_t=100\\ln(S_t/S_{t-1})'),
      '09_plazo':()=>eq('\\widehat g_t',c,['\\,PBI_{t-1}','\\,\\pi_{t-1}','\\,(TPM_t-TPM_{t-1})'],',\\quad g_t=100(S_t/S_{t-1}-1)'),
      '09_cts':()=>eq('\\widehat g_t',c,['\\,D_{2021,t}'],',\\quad g_t=100(S_t/S_{t-1}-1)'),
      '11':()=>eq('\\widehat c_t',c,['\\,TPM_t','\\,\\pi_t','\\,p^{plazo}_{t-1}']),
      '12_entidades':()=>eq('\\widehat z_t',c,['\\,TPM_t','\\,\\pi_t'],',\\quad z_t=\\ln(G_t+0.05)'),
      '12_adeudos':()=>eq('\\widehat G_t',c,['\\,TPM_t','\\,D_{2020,2021;t}']),
      '12_otras':()=>eq('\\widehat z_t',c,['\\,TPM_{t-1}'],',\\quad z_t=\\ln(1+G_t)'),
      '16_disponible':()=>eq('\\widehat z_t',c,['\\,PBI_t','\\,\\ln(I_{t-1})'],',\\quad z_t=\\ln(I_t)'),
      '16_interbancarios':()=>eq('\\widehat z_t',c,['\\,D_{2020,2021;t}'],',\\quad z_t=\\ln(I_t)'),
      '17_caja':()=>eq('\\widehat{Caja}_m',c,['\\,Caja_{m-1}']),
      '31':()=>eq('\\widehat g_t',c,['\\,PBI_t'],',\\quad g_t=100\\ln(CxC_t/CxC_{t-1})'),
      '32':()=>eq('\\widehat{\\Delta R}_t',c,['\\,\\Delta I^{creditos}_t'])
    };
    if (simple[id]) return simple[id]();
    if (id==='18_diversos' && c.length>=4) {
      return [eq('\\widehat g_t^{\\pi}',c.slice(0,4),['\\,\\pi_t','\\,D_{2018,t}','\\,D_{2020,2021;t}']),
        c.length>=6?eq('\\widehat g_t^{compras}',c.slice(4,6),['\\,g_t^{compras}']):String.raw`\widehat g_t^{compras}=\alpha_C+\beta_C g_t^{compras}`,
        String.raw`\widehat I_t=0.75\widehat I_t^{\pi}+0.25\widehat I_t^{compras}`].join(';\\quad ');
    }
    if (id==='19_terceros' && c.length===5) {
      return [eq('\\widehat g_t^{PBI}',c.slice(0,2),['\\,PBI_t'],',\\quad g_t=100\\ln(G_t/G_{t-1})'),
        eq('\\widehat G_t^{rezago}',c.slice(2),['\\,PBI_t','\\,G_{t-1}']),
        String.raw`\widehat G_t=0.75\widehat G_t^{PBI}+0.25\widehat G_t^{rezago}`].join(';\\quad ');
    }
    const ledger={
      '08':String.raw`Ahorro_t=Ahorro_{MN,t}+Ahorro_{ME,t}`,
      '09':String.raw`Plazo_t=PlazoOrd_t+CTS_t`,
      '10':String.raw`Obligaciones_t=Ahorro_t+Plazo_t+Restringidos_t+Otras_t`,
      '12':String.raw`GastosFin_t=GOblig_t+GEntidades_t+GAdeudos_t+GOtras_t`,
      '12_obligaciones':String.raw`GOblig_t=\frac{Oblig_t+Oblig_{t-1}}{2}\,\frac{Costo_t+Costo_{t-1}}{2}\,\frac{Factor}{100}`, 
      '16':String.raw`IngresosFin_t=ICreditos_t+IInversiones_t+IDisponible_t+IInterb_t`,
      '17':String.raw`Disponible_t=Caja_t+Bancos_t+Canje_t+Otros_t`,
      '18':String.raw`ResultadoServicios_t=IngresosDiversos_t+OtrosIngresos_t-GastosDiversos_t-OtrosGastos_t`,
      '19':String.raw`GastosAdministrativos_t=Personal_t+Directorio_t+Terceros_t+Impuestos_t`,
      '20':String.raw`ResultadoFinanciero_t=\sum_j Componente_{j,t}`,
      '21':String.raw`Inversiones_t=DisponiblesVenta_t+Subsidiarias_t+Otras_t`,
      '22':String.raw`Interbancarios_t=FondosInterbancarios_t`,
      '23':String.raw`MargenFinancieroBruto_t=IngresosIntereses_t-GastosIntereses_t`,
      '30':String.raw`Lineas_t=Tarjetas_t\,\overline{(Lineas/Tarjetas)}_{t-3:t-1}`,
      '45':String.raw`Acumulados_t=Acumulados_{t-1}+Utilidad_{t-1}-ReservasTransferidas_t-Dividendos_t`,
      '46':String.raw`ResultadoPatrimonio_t=ResultadoNeto_t`,
      '47':String.raw`Activo_t=Pasivo_t+Patrimonio_t`,
      '48':String.raw`100\ln\left(\frac{C_t}{C_{t-1}}\right)=\alpha+\beta_1 PBI_t+\beta_2(Des_{t-1}-Des_{t-2})+\beta_3 TPM_{t-1}+\varepsilon_t`,
      '48_cuota':String.raw`Cuota_t=100\frac{ConsumoFalabella_t}{ConsumoBanca_t}`, 
      '49':String.raw`Amortizacion_t=Saldo_{t-1}+Compras_t+DisposicionesRC_t+Desembolsos_t-Saldo_t-Castigos_t`
    };

    /* Notación matemática de identidades documentadas. No reemplaza ecuaciones estimadas. */
    const precise={
      '07':String.raw`S_t^{cons}=S_t^{rev}+S_t^{nrev}`,
      '08':String.raw`A_t=A_t^{MN}+A_t^{ME}`,
      '09':String.raw`P_t=P_t^{ord}+CTS_t`,
      '10':String.raw`O_t=A_t+P_t+R_t+X_t`,
      '12':String.raw`G_t^{int}=G_t^{obl}+G_t^{ent}+G_t^{ade}+G_t^{otr}`,
      '16':String.raw`I_t^{fin}=I_t^{cred}+I_t^{inv}+I_t^{disp}+I_t^{interb}`,
      '17':String.raw`D_t=Caja_t+Bancos_t+Canje_t+Otros_t`,
      '18':String.raw`R_t^{serv}=I_t^{div}+I_t^{otr}-G_t^{div}-G_t^{otr}`,
      '19':String.raw`G_t^{adm}=G_t^{pers}+G_t^{dir}+G_t^{terc}+G_t^{imp}`,
      '20':String.raw`R_t^{op.fin}=\sum_{j=1}^{6} R_{j,t}`,
      '21':String.raw`Inv_t=Inv_t^{venta}+Inv_t^{sub}+Inv_t^{otr}`,
      '22':String.raw`F_t^{activo}=F_t^{interb}`,
      '23':String.raw`M_t^{fin}=I_t^{intereses}-G_t^{intereses}`,
      '30':String.raw`L_t=N_t\left(\frac{1}{3}\sum_{j=1}^{3}\frac{L_{t-j}}{N_{t-j}}\right)`,
      '45':String.raw`RA_t=RA_{t-1}+U_{t-1}^{aplicable}-TR_t-DIV_t`,
      '46':String.raw`U_t^{patrimonio}=U_t^{resultados}`,
      '47':String.raw`A_t=P_t+K_t`,
      '47_pasivo':String.raw`P_t=\sum_j P_{j,t}`,
      '47_patrimonio':String.raw`K_t=\sum_j K_{j,t}`,
      '47_control':String.raw`\Delta_t^{balance}=A_t-P_t-K_t`,
      '47_disponible':String.raw`D_t^{conc}=D_t^{previo}+\Delta B_t`,
      '47_bancos':String.raw`B_t^{conc}=P_t+K_t-A_t^{sin\ bancos}`,
      '47_creditos_netos':String.raw`C_t^{netos}=C_t^{brutos}-Prov_t`,
      '47_disponible_previo':String.raw`D_t^{previo}=Caja_t+B_t^{previo}+Canje_t+Otros_t`,
      '47_ajuste_bancos':String.raw`\Delta B_t=B_t^{conc}-B_t^{previo}`,
      '48_cuota':String.raw`q_t^{cons}=100\frac{S_t^{Falabella,rev}+S_t^{Falabella,nrev}}{S_t^{banca,cons}}`,
      '49':String.raw`\mathrm{Amort}_t=S_{t-1}+C_t+R_t+D_t-S_t-K_t`,
      '49_rev':String.raw`\mathrm{Amort}_t^{rev}=S_{t-1}^{rev}+C_t+R_t-S_t^{rev}-K_t^{rev}`,
      '49_nrev':String.raw`\mathrm{Amort}_t^{nrev}=S_{t-1}^{nrev}+D_t-S_t^{nrev}-K_t^{nrev}`,
      '49_tasa_rev':String.raw`q_t^{rev}=100\frac{\mathrm{Amort}_t^{rev}}{S_{t-1}^{rev}+C_t+R_t}`,
      '49_tasa_nrev':String.raw`q_t^{nrev}=100\frac{\mathrm{Amort}_t^{nrev}}{S_{t-1}^{nrev}+D_t}`,
      '49_tc':String.raw`\mathrm{Amort}_t^{tarj}=\mathrm{Amort}_t^{rev}(1-w_t^{Rappi})`,
      '49_rc':String.raw`\mathrm{Amort}_t^{Rappi}=\mathrm{Amort}_t^{rev}w_t^{Rappi}`,
      '49_pe':String.raw`\mathrm{Amort}_t^{prest}=\mathrm{Amort}_t^{nrev}`,
      '49_compras':String.raw`C_t^{BF}=C_t^{merc}\frac{N_t^{BF}}{N_t^{merc}}f_{2025}`,
      '49_desembolsos':String.raw`D_t^{PE}=S_t^{nrev}\frac{D_{2025}^{PE}}{S_{2025}^{nrev}}`,
      '49_disposiciones_rc':String.raw`R_t^{RC}=C_t^{BF}\left(\frac{1}{2}\sum_{y=2024}^{2025}\frac{R_y^{RC}}{C_y^{BF}}\right)`,
      '49_part_rc':String.raw`w_t^{RC}=\frac{S_{t-1}^{RC}+R_t^{RC}-S_t^{RC}}{(S_{t-1}^{TC}+C_t^{TC}-S_t^{TC})+(S_{t-1}^{RC}+R_t^{RC}-S_t^{RC})};\quad w_t^{RC}=w_{t-1}^{RC}+\frac{w_{2025}^{RC}-w_{2022}^{RC}}{3}\ (t\geq 2026)`,
    };
    return precise[id]||ledger[id]||'';
  }
  function enrich(origin) {
    const model={...origin};
    if (model.id==='18_diversos' && (model.coefficients||[]).length===4) {
      model.coefficients=[...model.coefficients,
        {name:'MCO compras · constante',value:2.71048923,se:5.17880821,pValue:0.614893095},
        {name:'MCO compras · crecimiento de compras',value:0.84404419,se:0.12960676,pValue:0.000185673801}];
    }

    const marketMeta=(window.IASPEMarketModelMetadata||{})[model.id];
    if (model.id==='48' && marketMeta){
      model.estimatedEquationTex=marketMeta.estimatedEquationTex;
      model.equationTex=marketMeta.equationTex;
      model.coefficients=marketMeta.coefficients;
      model.statistics=marketMeta.statistics;
      model.economicRationale=marketMeta.economicRationale;
    } else {
      const equation=getEquation(model);
      if (equation && (!model.estimatedEquationTex || model.id==='18_diversos' || model.id==='19_terceros')) model.estimatedEquationTex=equation;
    }
    if (model.id==='19_personal' && !model.equationTex) {
      model.estimatedEquationTex=eq('\\widehat g_t^{trab}',model.coefficients,['\\,PBI_t','\\,D_{2020,2021;t}']) + ';\\quad ' + String.raw`G_t=G_{t-1}\frac{TrabProm_t}{TrabProm_{t-1}}(1+\pi_t/100)`;
      model.equationTex=String.raw`g_t^{trab}=\alpha+\beta PBI_t+\delta D_{2020,2021;t};\quad G_t=G_{t-1}\frac{TrabProm_t}{TrabProm_{t-1}}(1+\pi_t/100)`;
    }
    if (rationales[model.id]) model.economicRationale=rationales[model.id];
    model.closingRule=identifyClosure(model);
    model.updateRule=future[model.id]||'';
    const bad=/Los resultados proceden del Excel original|No se inventa un recálculo|sin implementar|No se inventan|Los originales son/;
    model.limitations=(Array.isArray(origin.limitations)?origin.limitations:origin.limitations?[origin.limitations]:[]).filter(x=>!bad.test(String(x)));
    return model;
  }
  window.IASPEModelFichas={enrich};
})();
