/* Extensión autónoma: no sustituye ni modifica controles actuales del Dashboard. */
'use strict';
window.IASPEControlSBS={
 async render(App){
  const root=document.getElementById('workspace');if(!root)return;
  root.innerHTML='<div class="sbs-control-loading">Calculando indicadores y consultando pendientes SBS…</div>';
  try{const d=await App.api('/api/iaspe/control');
   if(location.hash.slice(1)!=='control-sbs')return;
   const esc=App.escape,fmt=App.fmt;
   const n=(v,d=2)=>v===null||v===undefined?'—':fmt(v,d);
   const pct=v=>v===null||v===undefined?'—':fmt(100*v,2)+'%';
   const years=d.years.filter(y=>y.year>=2026);
   const last=years.find(x=>x.year===2030)||years[years.length-1];
   const countLoaded=d.catalog.reduce((s,r)=>s+r.loaded,0);const stressLoaded=Object.values(d.scenarioCoverage||{}).reduce((a,b)=>a+b,0);
   const key=(title,val,sub)=>`<article class="sbs-control-kpi"><div class="sbs-control-klabel">${esc(title)}</div><div class="sbs-control-kvalue">${esc(val)}</div><div class="sbs-control-kmeta">${esc(sub)}</div></article>`;
   const stats=key('Ajuste a Bancos '+last.year,'S/ '+n(last.banksAdjustment)+' MM','M47: diferencia vs M17 previo')+
    key('Disponible '+last.year,'S/ '+n(last.cashReconciled)+' MM','Activos de liquidez después del encaje')+
    key('Colocaciones consumo '+last.year,'S/ '+n(last.loansConsumption)+' MM','M05 revolvente + M06 no revolvente')+
    key('Insumos registrados',String(countLoaded),'Base · otros escenarios: '+stressLoaded);
   const graph=this.chart(years,esc,fmt);
   const rows=years.map(x=>`<tr><td>${x.year}</td><td>${n(x.assets)}</td><td>${n(x.liabilities)}</td><td>${n(x.equity)}</td><td>${n(x.difference,6)}</td><td>${n(x.cashForecast)}</td><td>${n(x.cashReconciled)}</td><td class="${x.banksAdjustment<-150?'sbs-warning':''}">${n(x.banksAdjustment)}</td><td>${pct(x.cashAdjustmentPct)}</td><td>${pct(x.roa)}</td><td>${pct(x.roe)}</td></tr>`).join('');
   const capitalRows=years.map(x=>`<tr><td>${x.year}</td><td>${n(x.arrears)}</td><td>${n(x.highRisk)}</td><td>${pct(x.delinquency)}</td><td>${pct(x.highRiskRatio)}</td><td>${n(x.stockFromSegments)}</td><td>${pct(x.coverageArrears)}</td><td>${n(x.aprTotal)}</td><td>${n(x.peTotal)}</td><td>${pct(x.capitalRatio)}</td><td>${n(x.interestReconciliation)}</td><td>${n(x.expenseReconciliation)}</td></tr>`).join('');
   const models=[['M05 / M06','Proyección separada por producto','Ya estimado','Regresiones separadas; agregado M07'],
   ['Cartera atrasada 1405+1406','Revolvente / no revolvente','Pendiente','Crear dos modelos con historia por producto'],
   ['Cartera refinanciada 1403+1404','Revolvente / no revolvente','Pendiente','Crear dos modelos con historia por producto'],
   ['Provisiones acumuladas 1409','Revolvente / no revolvente','Pendiente','Stock IASC Base aplicado; apertura por producto pendiente'],
   ['Ingreso por intereses 5104+5107','Revolvente / no revolvente','Pendiente de dato BF','Reconciliar con M16; NO dividir por cartera sin sustento'],
   ['Gasto por incobrabilidad 4302','Revolvente / no revolvente','Dato externo','Mantener M25 total; exigir aperturas validadas'],
   ['APR / PE / colchones','Crédito, mercado, operacional y capital','Dato regulatorio','Conectar después de recibir reportes por escenario'],
   ['M17 / M47','Liquidez residual y conciliación','Control explícito','No es una regresión que cierre el balance'],
   ['M20','Resultado de operaciones financieras','Reestimar / validar','FX, derivados y consorcios requieren mecanismo y fuente']];
   const ready= models.map(m=>`<tr>${m.map((v,i)=>`<td${i===2?' class="sbs-control-tag"':''}>${esc(v)}</td>`).join('')}</tr>`).join('');
   const inputs=d.catalog.map(r=>{const info=Object.keys(r.years).filter(y=>r.years[y]?.value!==undefined).join(', ')||'Sin dato cargado';return `<tr><td><code>${esc(r.codigo)}</code></td><td>${esc(r.cuenta)}</td><td>${esc(r.responsable)}</td><td>${esc(r.tipo)}</td><td>${esc(info)}</td></tr>`}).join('');
   root.innerHTML=`<section class="sbs-control">
    <div class="page-heading"><div><div class="eyebrow">IASPE / Control del escenario Base</div><h1>Balance, indicadores y exigencias SBS</h1><p>Seguimiento de conciliación y fuentes. No sustituye los reportes regulatorios ni supone una aprobación de los supuestos del Banco.</p></div></div>
    <div class="sbs-control-kpis">${stats}</div>
    <section class="sbs-control-section"><div class="sbs-control-subhead"><h2>Conciliación y liquidez residual</h2><small>S/ millones · escenarios Base</small></div><p>El balance cuadra porque la cuenta <b>Bancos y corresponsales</b> se calcula como pasivos + patrimonio menos los otros activos. Por eso, una diferencia contable de cero no demuestra suficiencia de liquidez.</p>${graph}<div class="sbs-control-scroll"><table class="sbs-control-table"><thead><tr><th>Año</th><th>Activos</th><th>Pasivos</th><th>Patrimonio</th><th>Diferencia</th><th>Disponible previo</th><th>Disponible final</th><th>Ajuste a bancos</th><th>Ajuste / previo</th><th>ROA</th><th>ROE</th></tr></thead><tbody>${rows}</tbody></table></div></section>
    <section class="sbs-control-section"><div class="sbs-control-subhead"><h2>Ratios por producto y capital regulatorio</h2><small>Solo calculados si los componentes están cargados íntegramente</small></div><p>La morosidad y la cobertura requieren información de ambos productos. El ratio de capital solo se calcula si se cargan APR crédito revolvente, no revolvente y otros, mercado, operacional y PE elegible (CO-N1, CA-N1, N2). <b>—</b> significa sin dato suficiente, nunca cero.</p><div class="sbs-control-scroll"><table class="sbs-control-table"><thead><tr><th>Año</th><th>Atrasada</th><th>Alto riesgo</th><th>Morosidad</th><th>Alto riesgo / bruto</th><th>1409 por producto</th><th>Cobertura atrasada</th><th>APR total</th><th>PE total</th><th>Ratio capital</th><th>Diferencia interés / M16</th><th>Diferencia gasto / M25</th></tr></thead><tbody>${capitalRows}</tbody></table></div></section>
    <section class="sbs-control-section"><div class="sbs-control-subhead"><h2>Modelos por reestimar y cuentas por desagregar</h2><small>Estado de cobertura, no resultados fabricados</small></div><div class="sbs-control-scroll"><table class="sbs-control-table"><thead><tr><th>Modelo / bloque</th><th>Desagregación exigida</th><th>Estado</th><th>Siguiente acción</th></tr></thead><tbody>${ready}</tbody></table></div></section>
    <section class="sbs-control-section"><div class="sbs-control-subhead"><h2>Carga de insumos del Banco</h2><small>Fuente obligatoria · años 2026–2030</small></div><p>Importa un CSV con encabezados <code>codigo;anio;valor;fuente;escenario</code> o pega varias líneas. Escenarios: BASE, ESTRES, ESTRES_SEVERO y SENSIBILIDAD. Solo M24–M27 del Base se incorporan al recálculo actual; los restantes datos quedan registrados sin alterar el motor.</p>
    <div class="sbs-control-actions"><button type="button" id="sbs-template">Descargar plantilla CSV</button><label class="sbs-control-upload">Elegir CSV<input type="file" accept=".csv,.txt" id="sbs-csv" /></label></div>
    <textarea id="sbs-inputs" spellcheck="false" rows="4" aria-label="Insumos del Banco" placeholder="codigo;anio;valor;fuente;escenario\nM25;2027;528.37;Presupuesto aprobado de Riesgos;BASE\nAPR_CRED_REV;2027;900;Reporte APR de Riesgos;ESTRES"></textarea>
    <div class="sbs-control-actions"><button type="button" id="sbs-commit">Validar y guardar insumos</button><span class="sbs-control-feedback" id="sbs-feedback"></span></div>
    <details><summary>Ver el catálogo de ${d.catalog.length} datos solicitados</summary><div class="sbs-control-scroll"><table class="sbs-control-table"><thead><tr><th>Código</th><th>Cuenta</th><th>Área responsable</th><th>Tratamiento</th><th>Estado</th></tr></thead><tbody>${inputs}</tbody></table></div></details></section>
    <p class="sbs-control-disclaimer"><b>Limitación vigente:</b> los ratios de morosidad, cartera de alto riesgo y cobertura no se muestran como resultados propios cuando falta la apertura por producto. El gasto M25 se conserva como exógeno. Los APR y el patrimonio efectivo requieren modelos regulatorios o reportes confirmados.</p>
   </section>`;
   document.getElementById('sbs-template').onclick=()=>{
     const data=['codigo;anio;valor;fuente;escenario',...d.catalog.map(r=>`${r.codigo};2027;;${r.responsable};BASE`)].join('\r\n');
     const blob=new Blob(['\ufeff'+data],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='IASPE_Plantilla_Datos_BF_SBS.csv';a.click();URL.revokeObjectURL(url);
   };
   document.getElementById('sbs-csv').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;document.getElementById('sbs-inputs').value=await f.text();};
   document.getElementById('sbs-commit').onclick=async()=>{
    const feedback=document.getElementById('sbs-feedback'), btn=document.getElementById('sbs-commit');
    try{
     const raw=document.getElementById('sbs-inputs').value.trim();if(!raw)throw Error('Ingresa al menos una fila con valor y fuente.');
     const lines=raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean),out=[];
     for(const [i,line] of lines.entries()){
       const pieces=line.includes(';')?line.split(';'):line.split(',');
       if(i===0&&pieces[0].trim().toLowerCase()==='codigo')continue;
       if(pieces.length<4)throw Error('Fila '+(i+1)+': se requiere código, año, valor y fuente.');
       const [codigo,anio,valor,fuente,escenario='BASE']=pieces; if(!valor.trim())continue;
       out.push({codigo:codigo.trim().toUpperCase(),anio:anio.trim(),valor:Number(valor.trim().replace(',','.')),fuente:String(fuente||'').trim(),escenario:String(escenario||'BASE').trim()});
     }
     if(!out.length)throw Error('No se encontraron observaciones con valor.');
     btn.disabled=true;feedback.textContent='Validando…';
     const done=await App.api('/api/iaspe/inputs',{entries:out});feedback.textContent=`${done.saved} registros guardados. ${done.appliedToMotor.length} recalculados, ${done.stagedOnly.length} pendientes de integrar.`;
     await App.calculate();App.toast(`${done.saved} insumos recibidos: ${done.appliedToMotor.length} aplicados al motor y ${done.stagedOnly.length} registrados pendientes de integrar.`);
    }catch(err){feedback.textContent=err.message;}finally{btn.disabled=false}
   };
  }catch(e){root.innerHTML=`<div class="sbs-control-error">Error al abrir el control SBS: ${App.escape(e.message)}</div>`}
 },
 chart(points,esc,fmt){
  const W=960,H=245,L=68,R=30,T=20,B=45;
  const vals=points.flatMap(x=>[x.cashForecast,x.cashReconciled]).filter(x=>Number.isFinite(x));
  if(vals.length<2)return '';
  let min=Math.min(0,...vals),max=Math.max(...vals)*1.15;if(max<=min)max=min+1;
  const x=i=>L+(W-L-R)*i/(points.length-1),y=v=>T+(max-v)*(H-T-B)/(max-min);
  const make=k=>points.map((r,i)=>`${i===0?'M':'L'}${x(i).toFixed(1)},${y(r[k]).toFixed(1)}`).join(' ');
  return `<div class="sbs-control-legend"><span><i class="sbs-control-dot one"></i>Disponible previo M17</span><span><i class="sbs-control-dot two"></i>Disponible conciliado M47</span></div><svg class="sbs-control-graph" viewBox="0 0 ${W} ${H}" role="img" aria-label="Disponible antes y después del cierre de balance 2026 a 2030">${[0,.25,.5,.75,1].map(q=>{const val=min+(max-min)*q;return `<line x1="${L}" x2="${W-R}" y1="${y(val)}" y2="${y(val)}" stroke="#e4eae4"/><text x="${L-8}" y="${y(val)+4}" text-anchor="end" font-size="12" fill="#66786c">${esc(fmt(val,0))}</text>`}).join('')}<path d="${make('cashForecast')}" fill="none" stroke="#477755" stroke-width="3"/><path d="${make('cashReconciled')}" fill="none" stroke="#c18b35" stroke-width="3"/>${points.map((p,i)=>`<circle cx="${x(i)}" cy="${y(p.cashForecast)}" r="4" fill="#477755"/><circle cx="${x(i)}" cy="${y(p.cashReconciled)}" r="4" fill="#c18b35"/><text x="${x(i)}" y="${H-15}" text-anchor="middle" font-size="13" fill="#47604d">${p.year}</text>`).join('')}</svg>`;
 }
};
