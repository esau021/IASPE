/* Benchmark IASPE de EEFF SBS: entidades supervisadas, datos históricos sin proyecciones. */
(() => {
  'use strict';
  const MONTHS=['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
  const $=s=>document.querySelector(s);
  const $$=s=>Array.from(document.querySelectorAll(s));
  const finite=n=>typeof n==='number'&&Number.isFinite(n);
  const per=s=>`${MONTHS[+s.slice(5,7)-1]} ${s.slice(0,4)}`;
  const yearMonth=s=>+s.slice(0,4)*12+(+s.slice(5,7)-1);
  const safe=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const value=(row,id)=>row?.banks?.[id];
  const fmt=(app,n,d=2)=>finite(n)?app.fmt(n,d):'—';
  let meta=null, metaPromise=null, account=null, cached=new Map(), appLast=null, seq=0, resize;
  const state={section:'balance',account:'balance:042',banks:['02'],frequency:'monthly',mode:'balances',panel:'chart',search:''};

  function filteredAccounts(){
    return meta.accounts.filter(a=>a.section===state.section && (!state.search || safe(a.name+' '+a.group).includes(safe(state.search))));
  }
  function chooseAccount(){
    const list=meta.accounts.filter(a=>a.section===state.section);
    if(!list.some(a=>a.id===state.account))state.account=list.find(a=>a.banks_available===meta.banks.length)?.id||list[0]?.id;
  }
  function annualize(rows){
    if(state.frequency!=='annual')return rows;
    if(state.section!=='er_mensual')return rows.filter(r=>r.date.endsWith('-12'));
    // Los flujos se anualizan por suma de los doce meses de cada banco.
    // No se anualizan ejercicios parciales y los faltantes nunca valen cero.
    const years=new Map();
    rows.forEach(r=>{const y=r.date.slice(0,4);if(!years.has(y))years.set(y,[]);years.get(y).push(r)});
    return [...years].filter(([,r])=>r.length===12&&r.every(x=>x.date.slice(5,7)!=='00')).map(([year,periods])=>{
      const banks={};
      for(const b of meta.banks){
        const amounts=periods.map(r=>value(r,b.id));
        if(amounts.length===12&&amounts.every(finite))banks[b.id]=amounts.reduce((a,b)=>a+b,0);
      }
      const vals=Object.values(banks);
      return {date:year+'-12',banks,coverage:vals.length,expected:meta.banks.length,
              aggregate:vals.length?vals.reduce((a,b)=>a+b,0):null};
    });
  }
  function growth(rows,bankid){
    const current=rows.at(-1),prev=rows.find(r=>yearMonth(r.date)===yearMonth(current.date)-12);
    const v=value(current,bankid),prior=value(prev,bankid);
    return finite(v)&&finite(prior)&&prior!==0?100*(v/prior-1):null;
  }
  function percent(app,p){return finite(p)?(p>0?'+':'')+app.fmt(p,2)+'%':'—'}
  function name(bankId){return meta.banks.find(b=>b.id===bankId)?.name||bankId;}
  function selectedBanks(){return [...new Set(state.banks)].filter(id=>id!=='05'&&meta.banks.some(b=>b.id===id));}
  function bankOptions(period){const selected=new Set(selectedBanks());return window.IASPEInstitutionGroups.html(meta.banks.filter(b=>b.id!=='05'),period,b=>`<label class="eeff-bank-choice"><input type="checkbox" value="${appLast.escape(b.id)}" ${selected.has(b.id)?'checked':''}/>${appLast.escape(b.name)}</label>`);}
  function accountOptions(){
    const accounts=filteredAccounts();const groups=new Map();
    for(const a of accounts){if(!groups.has(a.group))groups.set(a.group,[]);groups.get(a.group).push(a)}
    return [...groups].map(([g,items])=>`<optgroup label="${appLast.escape(g)}">${items.map(a=>`<option value="${a.id}" ${state.account===a.id?'selected':''}>${appLast.escape(a.name)}</option>`).join('')}</optgroup>`).join('');
  }
  function graph(app,rows,series,options={}){
    if(rows.length<2)return '<div class="eeff-empty">Sin suficientes datos para representar la serie.</div>';
    const W=Math.max(640,Math.min(1450,($('#workspace')?.clientWidth||1100)-68)),H=options.height||330,L=76,R=30,T=24,B=48;
    const minx=yearMonth(rows[0].date),span=Math.max(1,yearMonth(rows.at(-1).date)-minx);
    const xx=r=>L+(yearMonth(r.date)-minx)*(W-L-R)/span;
    const nums=rows.flatMap(r=>series.map(s=>s.get(r))).filter(finite);
    if(!nums.length)return '<div class="eeff-empty">Sin datos observados para este gráfico.</div>';
    let ymin=Math.min(...nums),ymax=Math.max(...nums),pad=(ymax-ymin)*0.09||Math.abs(ymax)*0.1||1;
    ymin=Math.min(ymin,0)-pad;ymax=Math.max(ymax,0)+pad;
    const yy=v=>T+(ymax-v)*(H-T-B)/(ymax-ymin);
    const interval=state.frequency==='annual'?12:1;
    const ticks=[...new Set(Array.from({length:6},(_,i)=>Math.round(i*(rows.length-1)/5)))];
    const path=ser=>{
      let d='',last=null;
      for(const r of rows){const v=ser.get(r);if(!finite(v)){last=null;continue}
        d+=`${last&&yearMonth(r.date)-yearMonth(last.date)===interval?'L':'M'}${xx(r).toFixed(1)} ${yy(v).toFixed(1)} `;last=r;}
      return d;
    };
    // Una misma escala vertical para las series comparadas. Los valores ausentes quedan como brechas.
    const bands=rows.map((r,i)=>{
      const x=xx(r),prev=i?xx(rows[i-1]):L,next=i<rows.length-1?xx(rows[i+1]):W-R;
      const x0=i?(prev+x)/2:L,x1=i<rows.length-1?(x+next)/2:W-R;
      const values=series.map(s=>{const v=s.get(r);return {name:s.name,color:s.color||'#245a77',value:finite(v)?v:null,y:finite(v)?yy(v):null,index:series.indexOf(s)};});
      return `<rect class="eeff-hit" x="${x0.toFixed(2)}" y="${T}" width="${Math.max(0.1,x1-x0).toFixed(2)}" height="${H-B-T}" data-eeff-date="${app.escape(r.date)}" data-eeff-x="${x.toFixed(2)}" data-eeff-series="${app.escape(JSON.stringify(values))}"/>`;
    });
    return `<div class="eeff-plot eeff-plot-interactive"><svg viewBox="0 0 ${W} ${H}" class="eeff-svg" role="img" aria-label="${app.escape(options.label||'Evolución y comparación de cuentas SBS')}">${[0,1,2,3].map(i=>{const v=ymin+(ymax-ymin)*i/3;return `<line x1="${L}" x2="${W-R}" y1="${yy(v)}" y2="${yy(v)}" class="eeff-grid"/><text x="${L-10}" y="${yy(v)+4}" text-anchor="end">${app.escape(fmt(app,v,1))}</text>`}).join('')}${ticks.map(i=>{const r=rows[i];return `<text x="${xx(r)}" y="${H-12}" text-anchor="middle">${app.escape(state.frequency==='annual'?r.date.slice(0,4):r.date.slice(0,4))}</text>`}).join('')}${series.map((s,i)=>`<path class="eeff-series eeff-series-${i}" style="stroke:${s.color||'#245a77'}" d="${path(s)}"/>`).join('')}<line class="eeff-cursor-line" x1="0" x2="0" y1="${T}" y2="${H-B}" visibility="hidden"/>${series.map((s,i)=>`<circle class="eeff-cursor-dot eeff-cursor-dot-${i}" style="fill:${s.color||'#245a77'}" r="4" visibility="hidden"/>`).join('')}${bands.join('')}</svg><div class="eeff-hover-tooltip" role="status" aria-live="off" hidden></div></div>`;
  }
  function setupGraphTooltips(app){
    $$('.eeff-plot-interactive').forEach(plot=>{
      const tip=plot.querySelector('.eeff-hover-tooltip');
      const svg=plot.querySelector('svg');
      const line=plot.querySelector('.eeff-cursor-line');
      const dots=Array.from(plot.querySelectorAll('.eeff-cursor-dot'));
      function hide(){tip.hidden=true;line.setAttribute('visibility','hidden');dots.forEach(dot=>dot.setAttribute('visibility','hidden'));}
      plot.querySelectorAll('.eeff-hit').forEach(hit=>{
        function show(){
          const names=JSON.parse(hit.dataset.eeffSeries||'[]');const date=hit.dataset.eeffDate;
          const x=Number(hit.dataset.eeffX);
          tip.innerHTML=`<strong>${app.escape(per(date))}</strong>`+names.slice().sort((a,b)=>(finite(b.value)?b.value:-Infinity)-(finite(a.value)?a.value:-Infinity)).map(v=>`<span><i class="eeff-tip-key" style="background:${v.color}"></i>${app.escape(v.name)} <b>${v.value===null?'Sin dato':app.escape(fmt(app,v.value))}</b></span>`).join('');
          tip.hidden=false;
          const svgWidth=svg.viewBox.baseVal.width;
          const pct=Math.max(0,Math.min(1,x/svgWidth));
          tip.style.left=`${Math.min(83,Math.max(17,pct*100))}%`;
          line.setAttribute('x1',x);line.setAttribute('x2',x);line.setAttribute('visibility','visible');
          dots.forEach((dot,i)=>{const v=names[i];if(v&&v.y!==null){dot.setAttribute('cx',x);dot.setAttribute('cy',v.y);dot.setAttribute('visibility','visible');}else dot.setAttribute('visibility','hidden');});
        }
        hit.addEventListener('pointerenter',show);hit.addEventListener('pointermove',show);hit.addEventListener('focus',show);
      });
      svg.addEventListener('pointerleave',hide);
    });
  }
  function infoMetric(app,label,v,detail){return `<div class="eeff-metric"><small>${app.escape(label)}</small><strong>${app.escape(v)}</strong><span>${app.escape(detail)}</span></div>`}
  function downloadCSV(app,rows){
    const head=['Mes',...meta.banks.map(b=>b.name),'Suma de entidades con dato; no es agregado sectorial','N. entidades con dato'];
    const escCell=s=>`"${String(s??'').replaceAll('"','""')}"`;
    const matrix=[head,...rows.map(r=>[r.date,...meta.banks.map(b=>finite(value(r,b.id))?value(r,b.id):''),finite(r.aggregate)?r.aggregate:'',r.coverage])];
    const csv='\ufeff'+matrix.map(line=>line.map(escCell).join(';')).join('\r\n');
    const a=document.createElement('a');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
    a.href=url;a.download='IASPE_SBS_'+state.account.replace(':','_')+'_'+state.frequency+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1200);
    app.toast('CSV exportado con las cifras observadas.');
  }
  function build(app,payload){
    const e=app.escape,a=payload.account,rows=annualize(payload.rows).filter(r=>r.coverage).sort((x,y)=>x.date.localeCompare(y.date)),peers=selectedBanks();
    if(!rows.length)return '<div class="eeff-empty">No hay datos observados para este estado financiero.</div>';
    const ids=['05',...peers];
    const palette=['#31875b','#b3783b','#8859aa','#4e80bb','#b86261','#85913c','#297f86','#a65a85','#96733a','#557f49','#7772b4','#9a734f','#3993a0','#8e676f','#4d97a2'];
    const colors=ids.map((id,i)=>i===0?'#245a77':palette[meta.banks.findIndex(b=>b.id===id)%palette.length]);
    const last=rows.at(-1),total=last.aggregate;
    const base=rows.find(r=>ids.every(id=>finite(value(r,id))&&value(r,id)>0));
    const byDate=new Map(rows.map(r=>[r.date,r]));
    const displayValue=(r,id)=>{
      const v=value(r,id);if(!finite(v))return null;
      if(state.mode==='balances')return v;
      if(state.mode==='index')return base&&finite(value(base,id))&&value(base,id)>0?100*v/value(base,id):null;
      const previous=byDate.get(`${+r.date.slice(0,4)-1}${r.date.slice(4)}`),den=value(previous,id);
      return finite(den)&&den!==0?100*(v/den-1):null;
    };
    const series=ids.map((id,i)=>({id,name:id==='05'?'Banco Falabella':name(id),color:colors[i%colors.length],get:r=>displayValue(r,id)}));
    const units=state.mode==='balances'?'S/ millones':state.mode==='index'?'Índice base 100':'% interanual';
    const capRows=state.mode==='index'&&base?rows.filter(r=>yearMonth(r.date)>=yearMonth(base.date)):rows;
    const headline=last.date;
    const chart=state.panel==='chart'?`<div class="eeff-chart-legend">${series.map(s=>`<span><i class="eeff-key" style="border-color:${s.color}"></i>${e(s.name)}</span>`).join('')}<small>${e(units)}</small></div>${graph(app,capRows,series,{height:340,label:a.name})}`:
      `<div class="eeff-table-wrap eeff-time-table"><table><thead><tr><th>Período</th>${series.map(s=>`<th>${e(s.name)}</th>`).join('')}</tr></thead><tbody>${[...capRows].sort((x,y)=>y.date.localeCompare(x.date)).map(r=>`<tr><td>${e(per(r.date))}</td>${series.map(s=>{const current=displayValue(r,s.id);return `<td>${finite(current)?e(fmt(app,current))+(state.mode==='yoy'?'%':''):'—'}</td>`}).join('')}</tr>`).join('')}</tbody></table></div>`;
    const compareValue=peers.length===1?value(last,peers[0]):null;
    const summary=`<div class="eeff-summary">${infoMetric(app,'Banco Falabella',fmt(app,value(last,'05')),'S/ millones · '+per(headline))}${infoMetric(app,peers.length===1?name(peers[0]):`${peers.length} entidades seleccionadas`,peers.length===1?fmt(app,compareValue):peers.length?`${peers.length} entidades`:'—','Valores históricos SBS')}${infoMetric(app,'Entidades disponibles',String(last.coverage),'Datos observados')}</div>`;
    return `<section class="eeff-workspace"><nav class="market-main-tabs"><a href="#benchmark/cartera">Cartera de consumo</a><a href="#benchmark/oficinas">Oficinas</a><a class="active" href="#benchmark/eeff" aria-current="page">Estados financieros</a><a href="#benchmark/ratios">Indicadores financieros</a><a href="#benchmark/personal">Personal</a></nav><div class="eeff-heading"><h1>Estados financieros</h1>${window.IASPESourceUpdates.control('eeff',meta.period_end||meta.periodo_fin||meta.months?.at(-1)||headline)}</div>
    <div class="eeff-filters"><label>Estado financiero<select id="eeff-section">${meta.sections.map(s=>`<option value="${s.id}" ${state.section===s.id?'selected':''}>${e(s.name)}</option>`).join('')}</select></label><div class="eeff-search-field"><label for="eeff-search">Buscar cuenta SBS</label><input type="search" id="eeff-search" placeholder="Buscar por nombre o grupo…" value="${e(state.search)}" autocomplete="off" role="combobox" aria-autocomplete="list" aria-controls="eeff-suggestions" aria-expanded="false"/><div id="eeff-suggestions" class="eeff-suggestions" role="listbox" hidden></div></div><label class="eeff-account-select">Cuenta SBS<select id="eeff-account">${accountOptions()}</select></label><div class="eeff-multi"><span>Comparar con</span><details id="eeff-bank-details"><summary>${peers.length===1?e(name(peers[0])):peers.length?peers.length+' entidades seleccionadas':'Seleccionar entidades'}</summary><div class="eeff-multi-menu"><input id="eeff-bank-search" type="search" placeholder="Buscar entidad…"/><div class="eeff-multi-list">${bankOptions(headline)}</div><div class="eeff-multi-bottom"><small>Selección inmediata · sin límite de entidades</small></div></div></details></div></div>
    ${summary}<section class="eeff-panel"><div class="eeff-panel-head"><div><h2>${e(a.name)}</h2><p>${e(a.group)} · ${e(units)}</p></div><div class="eeff-actions"><div class="segmented">${[['balances','Saldos'],['index','Base 100'],['yoy','Variación anual']].map(([mode,title])=>`<button type="button" data-eeff-mode="${mode}" class="${state.mode===mode?'active':''}">${title}</button>`).join('')}</div><div class="segmented"><button type="button" data-eeff-panel="chart" class="${state.panel==='chart'?'active':''}">Gráfico</button><button type="button" data-eeff-panel="table" class="${state.panel==='table'?'active':''}">Tabla</button></div><select id="eeff-frequency"><option value="monthly" ${state.frequency==='monthly'?'selected':''}>Mensual</option><option value="annual" ${state.frequency==='annual'?'selected':''}>${state.section==='er_mensual'?'Años completos':'Diciembre anual'}</option></select><button class="eeff-export" id="eeff-csv">CSV</button></div></div>${chart}</section>
    </section>`;
  }
  async function getAccount(app,id){
    if(!cached.has(id)) cached.set(id,app.api('/api/benchmark/eeff/account?account='+encodeURIComponent(id)));
    const waiting=cached.get(id);
    try{return await waiting}catch(error){if(cached.get(id)===waiting)cached.delete(id);throw error;}
  }
  function attach(app,payload){
    const e=app.escape;
    $('#eeff-section').onchange=x=>{state.section=x.target.value;state.search='';chooseAccount();render(app)};
    // Sugerencias instantáneas: no recalcular ni cargar una serie al teclear.
    const searchInput=$('#eeff-search'),suggestions=$('#eeff-suggestions');
    let activeSuggestion=0,shown=[];
    const closeSuggestions=()=>{suggestions.hidden=true;searchInput.setAttribute('aria-expanded','false');searchInput.removeAttribute('aria-activedescendant');};
    function chooseSuggestion(item){
      if(!item)return;
      state.section=item.section;state.account=item.id;state.search='';
      closeSuggestions();render(app);
    }
    function paintSuggestions(){
      const query=safe(searchInput.value.trim());
      const matches=meta.accounts.filter(a=>query?safe(a.name+' '+a.group).includes(query):a.section===state.section);
      if(query)matches.sort((a,b)=>{
        const rank=a=>safe(a.name).startsWith(query)?0:safe(a.name).includes(query)?1:2;
        return rank(a)-rank(b)||(a.section===state.section?0:1)-(b.section===state.section?0:1);
      });
      shown=matches.slice(0,14);
      activeSuggestion=Math.min(activeSuggestion,Math.max(0,shown.length-1));
      suggestions.innerHTML=shown.length?shown.map((a,i)=>`<button type="button" role="option" id="eeff-suggestion-${i}" aria-selected="${i===activeSuggestion}" class="eeff-suggestion ${i===activeSuggestion?'active':''}" data-suggest="${i}"><strong>${e(a.name)}</strong><small>${e(meta.sections.find(s=>s.id===a.section)?.name||'')} · ${e(a.group)}</small></button>`).join(''):'<div class="eeff-suggestion-empty">No hay cuentas con ese nombre.</div>';
      suggestions.hidden=false;searchInput.setAttribute('aria-expanded','true');
      if(shown.length)searchInput.setAttribute('aria-activedescendant',`eeff-suggestion-${activeSuggestion}`);
      suggestions.querySelectorAll('[data-suggest]').forEach(b=>b.onpointerdown=evt=>{evt.preventDefault();chooseSuggestion(shown[Number(b.dataset.suggest)]);});
    }
    searchInput.addEventListener('focus',()=>{activeSuggestion=0;paintSuggestions()});
    searchInput.addEventListener('input',()=>{activeSuggestion=0;paintSuggestions()});
    searchInput.addEventListener('keydown',evt=>{
      if(evt.key==='Escape'){closeSuggestions();return;}
      if(evt.key==='ArrowDown'||evt.key==='ArrowUp'){
        evt.preventDefault();if(suggestions.hidden)paintSuggestions();
        if(shown.length){activeSuggestion=(activeSuggestion+(evt.key==='ArrowDown'?1:-1)+shown.length)%shown.length;paintSuggestions();}
      }
      if(evt.key==='Enter'&&!suggestions.hidden){evt.preventDefault();chooseSuggestion(shown[activeSuggestion]);}
    });
    searchInput.addEventListener('blur',()=>{setTimeout(closeSuggestions,120)});
    $('#eeff-account').onchange=x=>{state.account=x.target.value;render(app)};
    $('#eeff-frequency').onchange=x=>{state.frequency=x.target.value;render(app)};
    $$('[data-eeff-mode]').forEach(x=>x.onclick=()=>{state.mode=x.dataset.eeffMode;render(app)});
    $$('[data-eeff-panel]').forEach(x=>x.onclick=()=>{state.panel=x.dataset.eeffPanel;render(app)});
    // La selección se refleja al instante en gráfico y tabla. No necesita aplicar ni guardar.
    function updateBankSelection(checkbox){
      const next=$$('.eeff-bank-choice input:checked').map(input=>input.value);
      const details=$('#eeff-bank-details');
      const open=Boolean(details?.open);
      const query=$('#eeff-bank-search')?.value||'';
      const scroll=$('.eeff-multi-list')?.scrollTop||0;
      state.banks=next;
      $('#workspace').innerHTML=build(app,payload);
      attach(app,payload);
      setupGraphTooltips(app);
      if(open&&$('#eeff-bank-details')){
        $('#eeff-bank-details').open=true;
        const search=$('#eeff-bank-search');
        search.value=query;
        search.dispatchEvent(new Event('input'));
        $('.eeff-multi-list').scrollTop=scroll;
      }
    }
    $$('.eeff-bank-choice input').forEach(input=>input.onchange=()=>updateBankSelection(input));
    const search=$('#eeff-bank-search');if(search)search.oninput=e=>window.IASPEInstitutionGroups.filter($('.eeff-multi-list'),'.eeff-bank-choice',e.target.value);
    $('#eeff-csv').onclick=()=>downloadCSV(app,annualize(payload.rows));
    window.IASPESourceUpdates.bind(app);
  }
  async function render(app){
    appLast=app;
    await window.IASPESourceUpdates.refresh(app).catch(()=>null);
  if(!location.hash.startsWith('#benchmark/eeff'))return;
    const token=++seq;
    $('#workspace').innerHTML='<div class="empty">Cargando estados financieros SBS…</div>';
    try{
      if(!meta){metaPromise ||=app.api('/api/benchmark/eeff');const loaded=await metaPromise;if(token!==seq)return;meta=loaded;}
      chooseAccount();
      const payload=await getAccount(app,state.account);
      if(token!==seq||!location.hash.startsWith('#benchmark/eeff'))return;
      $('#workspace').innerHTML=build(app,payload);
      attach(app,payload);
      setupGraphTooltips(app);
    }catch(error){
      if(token!==seq)return;
      metaPromise=null;
      if(token===seq&&location.hash.startsWith('#benchmark/eeff'))$('#workspace').innerHTML=`<div class="notice">${app.escape(error.message||'No se pudo cargar el panel SBS.')}</div>`;
    }
  }
  window.addEventListener('resize',()=>{clearTimeout(resize);if(location.hash.startsWith('#benchmark/eeff')&&appLast)resize=setTimeout(()=>render(appLast),180)});
  function invalidate(){seq++;meta=null;metaPromise=null;account=null;cached.clear();}
  window.IASPEBenchmarkEEFF={render,invalidate};
})();
