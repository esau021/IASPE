"""Especificación reproducible de modelos inferiores de deterioro de consumo.

No está calibrado ni conectado al motor IASPE en ausencia de datos históricos
por producto. Se ejecuta manualmente después de una carga revisada por Riesgos:
 python estimacion_calidad_consumo.py path/historico_calidad_consumo.csv

Archivo en S/ MM, frecuencia mensual: fecha AAAA-MM, cartera_rev, cartera_norev,
atrasada_rev, atrasada_norev, refinanciada_rev, refinanciada_norev,
provision_stock_rev, provision_stock_norev, pbi_yoy, desempleo.
Solo pronostica tasas de cartera atrasada y refinanciada; stock 1409 se
reconcilia con el puente de movimientos, sin regresión automática.
"""
from __future__ import annotations
import csv,math,json,sys
from pathlib import Path
from datetime import datetime

REQUIRED=['fecha','cartera_rev','cartera_norev','atrasada_rev','atrasada_norev','refinanciada_rev','refinanciada_norev','provision_stock_rev','provision_stock_norev','pbi_yoy','desempleo']
MIN_MONTHS=60

def load(path):
    with open(path,encoding='utf-8-sig',newline='') as f:
        first=f.readline();f.seek(0)
        reader=csv.DictReader(f,delimiter=';' if ';' in first else ',')
        missing=set(REQUIRED)-set(reader.fieldnames or [])
        if missing:raise ValueError('Faltan columnas: '+', '.join(sorted(missing)))
        out=[]
        for row in reader:
            if not str(row['fecha']).strip():continue
            date=datetime.strptime(row['fecha'].strip(),'%Y-%m')
            values={k:float(row[k]) for k in REQUIRED[1:]}
            if not all(math.isfinite(v) for v in values.values()):raise ValueError('Serie con valores no finitos.')
            if values['cartera_rev']<=0 or values['cartera_norev']<=0:raise ValueError('Cartera igual a cero.')
            for typ in ['rev','norev']:
                if any(values[f'{field}_{typ}']<0 or values[f'{field}_{typ}']>values[f'cartera_{typ}'] for field in ['atrasada','refinanciada']):
                    raise ValueError(f'Deterioro incompatible con saldo de cartera en {date:%Y-%m}/{typ}')
            out.append(dict(fecha=f'{date:%Y-%m}',**values))
        out.sort(key=lambda r:r['fecha'])
        if len(out)<MIN_MONTHS:raise ValueError('Se requieren al menos 60 meses sin vacíos; recibidos '+str(len(out)))
        for a,b in zip(out,out[1:]):
            ya,ma=map(int,a['fecha'].split('-'));yb,mb=map(int,b['fecha'].split('-'))
            if yb*12+mb != ya*12+ma+1:raise ValueError('La serie mensual tiene saltos o duplicados.')
        return out

def fit(path):
    import numpy as np
    import statsmodels.api as sm
    series=load(path)
    results=[]
    for typ in ['rev','norev']:
        for key in ['atrasada','refinanciada']:
            # Logit evita pronósticos negativos y tasas fuera de [0,1].
            ratio=np.array([r[f'{key}_{typ}']/r[f'cartera_{typ}'] for r in series])
            logit=np.log(np.clip(ratio,1e-5,1-1e-5)/(1-np.clip(ratio,1e-5,1-1e-5)))
            pbi=np.array([r['pbi_yoy'] for r in series]);unemp=np.array([r['desempleo'] for r in series])
            # Preferir términos de rezago y no usar macro datos futuros al estimar.
            lag=3
            Y=logit[lag:]
            X=np.column_stack([logit[lag-1:-1],pbi[:-lag],unemp[:-lag]])
            X=sm.add_constant(X)
            if not np.all(np.isfinite(X)) or not np.all(np.isfinite(Y)):raise ValueError('Datos incompletos.')
            train=len(Y)-12
            if train<36:raise ValueError('Historia insuficiente para backtesting fuera de muestra.')
            model=sm.OLS(Y[:train],X[:train]).fit(cov_type='HAC',cov_kwds={'maxlags':3})
            full=sm.OLS(Y,X).fit(cov_type='HAC',cov_kwds={'maxlags':3})
            out_sample=1/(1+np.exp(-np.clip(model.predict(X[train:]),-30,30)))
            actual=ratio[-12:];mae=float(np.mean(abs(out_sample-actual)))
            # Solo validación: estas ecuaciones NO sustituyen el motor antes de aprobación.
            results.append({'serie':f'{key}_{typ}', 'observaciones':len(Y),'train':train,'test':12,
                'coeficientes':dict(zip(['constante','ratio_rezagado','pbi_lag_3m','desempleo_lag_3m'],map(float,full.params))),
                'pvalues':dict(zip(['constante','ratio_rezagado','pbi_lag_3m','desempleo_lag_3m'],map(float,full.pvalues))),
                'r2':float(full.rsquared),'mae_test_ratio':mae,'ultimo_ratio_observado':float(ratio[-1]),
                'aprobado':False,'nota':'Especificación candidata; revisar autocorrelación, estabilidad, backtest y signos con Riesgos.'})
    return dict(source=str(path),nmonths=len(series),last=series[-1]['fecha'],modelos=results,
                notice='NO integrado al motor. Riesgo debe aprobar especificaciones y suministrar el escenario macro futuro antes de proyectar.')

def main():
    if len(sys.argv)<2:raise SystemExit('Indica un CSV histórico mensual por producto.')
    source=Path(sys.argv[1]);out=fit(source)
    target=source.with_name('diagnostico_modelos_calidad_consumo.json')
    target.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Diagnóstico creado:',target)

if __name__=='__main__':main()
