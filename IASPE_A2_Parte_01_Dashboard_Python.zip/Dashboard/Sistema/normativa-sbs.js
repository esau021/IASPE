/* Normativa SBS: tabla de cambios y consulta de PDF oficiales; no modifica el motor. */
(function(){
'use strict';
let payload=null,query='',detail=null,checking=false,started=false,busy=false,lastAutoCheck=0;
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
function official(url){return /^https:\/\/(?:[^/]+\.)?sbs\.gob\.pe\//.test(String(url||''))||/^https:\/\/(?:busquedas\.)?elperuano\.pe\//.test(String(url||''))?esc(url):'#normativa';}
const data=()=>payload?.catalogo||{cambios:[],documentos:[],manualPdf:'#normativa',manualLabel:'Sin comprobar'};
const alerts=()=>payload?.alertas||[];
function statusLine(){if(!payload?.lastCheck)return 'Versiones del Manual sujetas a verificación';let date='';try{date=new Date(payload.lastCheck).toLocaleString('es-PE',{dateStyle:'short',timeStyle:'short'});}catch(_){date='—'}return `${payload.checkErrors?.length?'No se pudieron verificar todas las fuentes · ': 'Comprobado con SBS · '}${date}`;}
function changes(){
 const items=(data().cambios||[]).slice().sort((a,b)=>String(b.fecha||'').split('/').reverse().join('-').localeCompare(String(a.fecha||'').split('/').reverse().join('-'))).filter(x=>norm(Object.values(x).join(' ')).includes(norm(query)));
 return `<div class="reg-table-scroll"><table class="reg-changes"><thead><tr><th>Publicación</th><th>Cuenta modificada</th><th>Ajuste SBS</th><th>Observaciones</th><th>Norma</th></tr></thead><tbody>${items.map(c=>`<tr class="reg-change-row" data-change-row="${esc(c.id)}"><td>${esc(c.fecha)}</td><td class="reg-account-name">${esc(c.cuenta)}</td><td><button class="reg-change-toggle" type="button" data-reg-detail="${esc(c.id)}" aria-expanded="${detail===c.id}">${esc(c.cambio)} <span aria-hidden="true">${detail===c.id?'−':'+'}</span></button></td><td><div class="reg-impact">${esc(c.impacto||'Revisar la comparabilidad antes de atribuir cambios económicos.')}</div><small>${esc(c.vigencia||'')}</small></td><td><a href="${official(c.url)}" target="_blank" rel="noopener noreferrer" title="Ver publicación oficial">${esc(c.norma)} ↗</a></td></tr>${detail===c.id?`<tr class="reg-before-after"><td colspan="5"><div class="reg-compare"><div><strong>Antes</strong><p>${esc(c.antes)}</p></div><div><strong>Ahora</strong><p>${esc(c.ahora)}</p></div><div><strong>Qué mirar en el IASPE</strong><p>${esc(c.impacto||'Revisar la serie antes de concluir que hubo un cambio económico real.')}</p></div></div></td></tr>`:''}`).join('')||'<tr><td colspan="5" class="reg-empty">No hay coincidencias.</td></tr>'}</tbody></table></div>`;
}
function render(){
 const root=$('#workspace');if(!root)return;
 if(!payload){root.innerHTML='<div class="reg-loading">Cargando normativa SBS…</div>';load().then(()=>{if(location.hash.startsWith('#normativa'))render()});return;}
 const catalogs=data();
 root.innerHTML=`<div class="reg-page">
   <div class="reg-heading"><div><div class="eyebrow">REFERENCIA CONTABLE · SBS</div><h1>Normativa SBS relevante para IASPE</h1><p>Altas, bajas y cambios de clasificación de cuentas SBS con vigencia efectiva en el periodo 2015–2026.</p></div>
   <div class="reg-heading-actions"><a class="reg-btn solid" id="reg-manual-direct" target="_blank" rel="noopener noreferrer" href="${official(catalogs.manualPdf)}" title="La SBS publica el Manual por capítulos. Este acceso abre el Capítulo IV, Descripción y Dinámica.">Abrir Manual SBS · Cap. IV (PDF) ↗</a></div></div>
   <div class="reg-toolbar"><input type="search" id="reg-search" placeholder="Buscar cuenta, resolución o palabra clave…" aria-label="Buscar contenido contable" value="${esc(query)}"><button type="button" class="reg-check" data-reg-check ${checking?'disabled':''}>${checking?'Comprobando…':'Comprobar actualizaciones'}</button></div>
   <p class="reg-caption">Solo modificaciones contables aplicadas: selecciona una cuenta para consultar el cambio y su efecto en la comparabilidad.</p>${changes()}
   <div class="reg-footer"><span>${esc(statusLine())}. Las normas no actualizan automáticamente los modelos IASPE.</span><a target="_blank" rel="noopener noreferrer" href="${official(catalogs.manualPortal)}">Todas las versiones en SBS ↗</a></div>
 </div>`;
 root.querySelectorAll('[data-reg-detail]').forEach(b=>b.onclick=()=>{detail=detail===b.dataset.regDetail?null:b.dataset.regDetail;render()});
 root.querySelector('[data-reg-check]')?.addEventListener('click',()=>check(false));
 const input=root.querySelector('#reg-search');input?.addEventListener('input',e=>{query=e.target.value;const caret=e.target.selectionStart;render();const next=$('#reg-search');next?.focus();if(caret!=null)next?.setSelectionRange(caret,caret)});
}
async function load(){if(busy)return;busy=true;try{const r=await fetch('/api/normativa/status',{cache:'no-store'});if(!r.ok)throw Error('Sin acceso a la biblioteca');payload=await r.json();window.dispatchEvent(new CustomEvent('iaspe:normativa-status',{detail:{unread:alerts().filter(x=>!x.reviewed).length}}));}catch(e){window.IASPEApp?.toast?.(e.message)}finally{busy=false}}
async function check(automatic){if(checking)return;checking=true;if(location.hash.startsWith('#normativa'))render();try{const r=await fetch('/api/normativa/check',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});if(!r.ok)throw Error('Servicio SBS no disponible');payload=await r.json();window.dispatchEvent(new CustomEvent('iaspe:normativa-status',{detail:{unread:alerts().filter(x=>!x.reviewed).length}}));if(!automatic)window.IASPEApp?.toast?.(payload.checkErrors?.length?'Hay fuentes SBS sin verificar. Se conservan los últimos vínculos conocidos.':'PDF del Manual comprobado con la SBS.');}catch(e){if(!automatic)window.IASPEApp?.toast?.(e.message)}finally{checking=false;lastAutoCheck=Date.now();if(location.hash.startsWith('#normativa'))render();}}
function start(){if(started)return;started=true;load().then(()=>{lastAutoCheck=Date.now();setTimeout(()=>check(true),6000)});window.addEventListener('focus',()=>{if(!checking&&Date.now()-lastAutoCheck>24*60*60*1000)check(true)});}
window.IASPENormativa={render,start,check,status:()=>payload,refresh:load};
})();
