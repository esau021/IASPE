"""Biblioteca versionada de proyecciones públicas BCRP y MEF.

LÍMITE DE SEGURIDAD: no importar motor, no modificar base_macro_aplicada,
supuestos_macro, modelos, escenarios ni ninguna proyección operativa IASPE.
"""
from __future__ import annotations
import base64
import hashlib
import io
import json
import re
import threading
import time
import math
import os
import secrets
import socket
from email.utils import parsedate_to_datetime
from concurrent.futures import ThreadPoolExecutor
import unicodedata
from datetime import date, datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urljoin, urlparse
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener

import requests
import weo_imf

ROOT = Path(__file__).resolve().parent
DIR = ROOT / 'data' / 'proyecciones_externas'
STATE = DIR / 'historial.json'
BASE_REVISIONS = DIR / 'revisiones_bcrp_base.json'
DOCS = DIR / 'documentos'
LOCK = threading.RLock()
UPDATE_LOCK = threading.Lock()
# Previsualizaciones en memoria: no modifican el historial ni guardan documentos.
PREVIEWS = {}
PREVIEW_TTL_SECONDS = 15 * 60
PREVIEW_LIMIT = 4
HEADERS = {'User-Agent': 'IASPE-ConsultaPublica/1.7 (+consulta de publicaciones oficiales; sin elusion de controles)', 'Accept': 'application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/html,application/json,*/*'}
SERIES = {
    'PD12912AM': ('inflacion', 'BCRP · encuesta a 12 meses', '%', 'Expectativa de inflación a 12 meses'),
    'PD38048AM': ('pbi', 'BCRP · encuesta a 12 meses', '%', 'Expectativa de PBI a 12 meses'),
    'PD38049AM': ('tc_cierre', 'BCRP · encuesta a 12 meses', 'S/ por USD', 'Expectativa de TC a 12 meses, no cierre anual'),
}
PORTAL_MEF='https://www.mef.gob.pe/es/?option=com_content&language=es-ES&Itemid=100869&lang=es-ES&view=article&id=3731'
PORTAL_BCRP='https://www.bcrp.gob.pe/estadisticas/encuesta-de-expectativas-macroeconomicas.html'
PORTAL_NOTAS='https://www.bcrp.gob.pe/publicaciones/notas-de-estudios.html'
PORTAL_RI='https://www.bcrp.gob.pe/publicaciones/reporte-de-inflacion.html'
# Serie anual de expectativas de cierre del BCRP: archivo Excel publicado y actualizado por la entidad.
BCRP_XLSX_TC='https://www.bcrp.gob.pe/docs/Estadisticas/Encuestas/expectativas-tipo-de-cambio.xlsx'
BCRP_XLSX_PBI='https://www.bcrp.gob.pe/docs/Estadisticas/Encuestas/expectativas-pbi.xlsx'
BCRP_XLSX_INFLACION='https://www.bcrp.gob.pe/docs/Estadisticas/Encuestas/expectativas-inflacion.xlsx'
# La disponibilidad de PBI/inflación se verifica en cada ejecución, no se presupone.
BCRP_XLSX_ENCUESTAS=(('tc_cierre',BCRP_XLSX_TC),('pbi',BCRP_XLSX_PBI),('inflacion',BCRP_XLSX_INFLACION))

VARIABLES=['pbi','inflacion','tc_cierre','tc_promedio','desempleo','poblacion','tpm']
DEFAULT = {'records': [], 'editions': [], 'checks': [], 'lastCheck': None}
MONTHS={'ene':1,'feb':2,'mar':3,'abr':4,'may':5,'jun':6,'jul':7,'ago':8,'sep':9,'set':9,'oct':10,'nov':11,'dic':12}

class FuenteProtegida(RuntimeError):
    """El sitio oficial impide recuperar su documento de forma automatizada."""



def _utc(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def _load():
    if not STATE.exists():
        return json.loads(json.dumps(DEFAULT))
    # Una base ilegible nunca se reemplaza por una base vacía.
    data = json.loads(STATE.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or not all(isinstance(data.get(k), list) for k in ('records', 'editions')):
        raise ValueError('El historial de fuentes externas está dañado; no se sobrescribe')
    data.setdefault('checks', [])
    data.setdefault('lastCheck', None)
    data.setdefault('lastChecks', {})
    return data


def _save(data):
    _atomic_json(STATE, data)


def _text(s):return unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode('ascii').lower().strip()
def _url_valid(url):
    try:
        parsed = urlparse(str(url))
        return (parsed.scheme == 'https' and not parsed.username and not parsed.password
                and parsed.port in (None, 443) and parsed.hostname in {
                    'www.bcrp.gob.pe', 'bcrp.gob.pe', 'estadisticas.bcrp.gob.pe',
                    'www.mef.gob.pe', 'mef.gob.pe', 'cdn.www.gob.pe', 'www.gob.pe',
                    'data.imf.org', 'api.imf.org'})
    except ValueError:
        return False


# Caché por URL, cuerpos verificables y trazas del transporte. No se usan
# proxies, navegadores de evasión, resolución de CAPTCHA ni cookies ajenas.
HTTP_CACHE = DIR / 'http_cache.json'
CACHE_LOCK = threading.RLock()
# Previsualizaciones en memoria: no modifican el historial ni guardan documentos.
PREVIEWS = {}
PREVIEW_TTL_SECONDS = 15 * 60
PREVIEW_LIMIT = 4
LOCAL = threading.local()
BLOCKED_HOSTS = {}
CHECK_INTERVAL = 900
FRESH_SECONDS = 86400
MAX_ATTEMPTS = 2


def _cache_load():
    try:
        obj = json.loads(HTTP_CACHE.read_text(encoding='utf-8'))
        return obj if isinstance(obj, dict) else {}
    except (OSError, ValueError):
        return {}


def _atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(tmp, path)


def _http_meta(url):
    return getattr(LOCAL, 'metadata', {}).get(url, {})


def _trace(meta):
    if not hasattr(LOCAL, 'events'):
        LOCAL.events = []
        LOCAL.metadata = {}
    LOCAL.events.append(dict(meta))
    LOCAL.metadata[meta['url']] = dict(meta)


def _cached_body(entry):
    filename = entry.get('cache_file', '')
    path = (DOCS / filename).resolve()
    if not filename or not path.is_relative_to(DOCS.resolve()):
        return None
    try:
        body = path.read_bytes()
        if hashlib.sha256(body).hexdigest() == entry.get('body_hash'):
            return body
    except OSError:
        pass
    return None


def _is_protection(body):
    head = body[:40000].lower()
    return any(x in head for x in (b'pardon our interruption', b'_incapsula_resource',
        b'incapsula incident', b'access denied', b'cf-chl-', b'captcha',
        b'bot detection', b'just a moment...', b'request unsuccessful'))


def _prune_http_bodies(cache):
    """La caché cambia; los respaldos de ediciones y evidencias se conservan."""
    keep = {entry.get('cache_file') for entry in cache.values() if isinstance(entry, dict)}
    keep.update(e.get('publication_evidence_file') for e in _load()['editions'])
    for path in DOCS.glob('*.http'):
        if re.fullmatch(r'[0-9a-f]{64}\.http', path.name) and path.name not in keep:
            path.unlink(missing_ok=True)


class _NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # _get valida cada destino antes de seguir la redirección.
        return None


def _http_network_error(error):
    reason = getattr(error, 'reason', error)
    if isinstance(reason, (socket.timeout, TimeoutError)):
        return requests.Timeout(str(reason))
    return requests.ConnectionError(str(reason))


class _UrllibResponse:
    """Adaptador mínimo del cliente estándar para las publicaciones del FMI."""
    def __init__(self, response):
        self.response = response
        self.status_code = response.getcode()
        self.headers = response.headers

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.response.close()

    def iter_content(self, chunk_size):
        try:
            while True:
                part = self.response.read(chunk_size)
                if not part:
                    break
                yield part
        except (URLError, OSError) as exc:
            raise _http_network_error(exc) from exc

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f'HTTP {self.status_code}: {self.response.reason}')


def _open_http(url, headers, timeout):
    if urlparse(url).hostname not in ('data.imf.org', 'api.imf.org'):
        return requests.get(url, headers=headers, timeout=(5, timeout),
                            allow_redirects=False, stream=True)
    # Cliente primario estándar, sin cookies ni identidad de navegador. Un 403
    # se devuelve al control existente; nunca provoca cambio de cliente/reintento.
    opener = build_opener(_NoRedirects())
    try:
        response = opener.open(Request(url, headers=headers), timeout=timeout)
    except HTTPError as exc:
        response = exc
    except (URLError, OSError) as exc:
        raise _http_network_error(exc) from exc
    return _UrllibResponse(response)


def _get(url, limit=13_000_000, timeout=14, *, refresh=False):
    """GET público acotado. Un 200 HTML anti-bot nunca es un documento.

    Se siguen redirecciones solo después de validar cada destino. Máximo dos
    intentos para errores transitorios; 401/403/429 y desafíos no se reintentan.
    No se devuelve caché vencida silenciosamente ante un fallo de conexión.
    """
    if not _url_valid(url):
        raise ValueError('Enlace externo no autorizado')
    checked = _utc()
    started = time.monotonic()
    host = urlparse(url).hostname
    meta = {'url': url, 'checked_at': checked, 'http_status': None,
            'content_type': None, 'consulted': False, 'downloaded': False}
    with CACHE_LOCK:
        persisted_block = _cache_load().get('_blocked_hosts', {}).get(host, 0)
    if max(BLOCKED_HOSTS.get(host, 0), persisted_block) > time.time():
        meta['error'] = 'Consulta suspendida temporalmente por protección o límite del servidor'
        meta['blocked'] = True
        _trace(meta)
        raise FuenteProtegida(meta['error'])
    with CACHE_LOCK:
        entry = _cache_load().get(url, {})
    cached = _cached_body(entry)
    if not refresh and cached is not None and entry.get('next_check', 0) > time.time():
        meta.update({k: entry.get(k) for k in ('content_type', 'downloaded_at', 'body_hash', 'etag', 'last_modified', 'final_url')})
        meta['cache'] = 'fresh'
        _trace(meta)
        return cached
    def request_headers(target):
        headers = dict(HEADERS)
        # Negociar el recurso solicitado, sin cookies ni identidad de navegador.
        if urlparse(target).hostname in ('data.imf.org', 'api.imf.org'):
            path = urlparse(target).path.lower()
            if '/structure/' in path:
                accept = 'application/vnd.sdmx.structure+json;version=2.0.0'
            elif '/2.1/data/' in path:
                accept = 'text/csv'
            elif path.endswith('.xlsx'):
                accept = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            else:
                accept = 'text/html'
            headers['Accept'] = accept
        return headers
    headers = request_headers(url)
    if cached is not None:
        if entry.get('etag'):
            headers['If-None-Match'] = entry['etag']
        if entry.get('last_modified'):
            headers['If-Modified-Since'] = entry['last_modified']
    for attempt in range(1, MAX_ATTEMPTS + 1):
        current = url
        meta.pop('error', None)
        meta.pop('retry', None)
        try:
            for redirect in range(6):
                meta['transport'] = ('urllib' if urlparse(current).hostname in
                                     ('data.imf.org', 'api.imf.org') else 'requests')
                with _open_http(current, headers, timeout) as response:
                    meta.update(http_status=response.status_code,
                                content_type=response.headers.get('Content-Type', ''),
                                consulted=True, attempt=attempt, final_url=current)
                    if response.status_code in (301, 302, 303, 307, 308):
                        target = urljoin(current, response.headers.get('Location', ''))
                        imf_redirect = (host in ('data.imf.org', 'api.imf.org')
                                        and urlparse(target).hostname not in ('data.imf.org', 'api.imf.org'))
                        if redirect == 5 or not _url_valid(target) or imf_redirect:
                            raise ValueError('Redirección no autorizada o excesiva')
                        current = target
                        # No enviar validadores a un recurso distinto.
                        headers = request_headers(current)
                        continue
                    if response.status_code == 304:
                        if cached is None:
                            raise ValueError('HTTP 304 sin caché íntegra')
                        meta.update({k: entry.get(k) for k in ('content_type', 'downloaded_at', 'body_hash', 'etag', 'last_modified')})
                        meta['cache'] = 'revalidated'
                        control = response.headers.get('Cache-Control', entry.get('cache_control', '')).lower()
                        max_age = re.search(r'max-age=(\d+)', control)
                        interval = min(CHECK_INTERVAL, int(max_age[1])) if max_age else CHECK_INTERVAL
                        if 'no-cache' in control:
                            interval = 0
                        for field, header in (('etag', 'ETag'), ('last_modified', 'Last-Modified')):
                            if response.headers.get(header):
                                entry[field] = response.headers[header]; meta[field] = entry[field]
                        entry.update(checked_at=checked, next_check=time.time()+interval, cache_control=control)
                        with CACHE_LOCK:
                            all_cache = _cache_load()
                            if 'no-store' in control:
                                all_cache.pop(url, None)
                            else:
                                all_cache[url] = entry
                            _atomic_json(HTTP_CACHE, all_cache)
                        _trace(meta)
                        return cached
                    body = bytearray()
                    for part in response.iter_content(65536):
                        if time.monotonic()-started > 60:
                            raise requests.Timeout('Se agotó el tiempo total de descarga')
                        body.extend(part)
                        if len(body) > limit:
                            raise ValueError('Respuesta supera el límite de descarga')
                    body = bytes(body)
                    meta.update(bytes=len(body), body_hash=hashlib.sha256(body).hexdigest())
                    if _is_protection(body) or response.status_code in (401, 403, 429):
                        retry_after = response.headers.get('Retry-After', '')
                        cooldown = 3600
                        try:
                            cooldown = max(3600, int(retry_after))
                        except ValueError:
                            try:
                                cooldown = max(3600, (parsedate_to_datetime(retry_after)-datetime.now(timezone.utc)).total_seconds())
                            except (ValueError, TypeError):
                                pass
                        BLOCKED_HOSTS[host] = time.time() + cooldown
                        with CACHE_LOCK:
                            all_cache = _cache_load()
                            all_cache.setdefault('_blocked_hosts', {})[host] = BLOCKED_HOSTS[host]
                            _atomic_json(HTTP_CACHE, all_cache)
                        meta.update(blocked=True, retry_after=retry_after)
                        raise FuenteProtegida(f'Protección o límite de la fuente (HTTP {response.status_code}, {meta["content_type"]}); no se intentó eludir')
                    if response.status_code in (502, 503, 504) and attempt < MAX_ATTEMPTS:
                        meta['retry'] = True
                        _trace(meta)
                        time.sleep(0.5)
                        break
                    response.raise_for_status()
                    if not body:
                        raise ValueError('Respuesta vacía')
                    meta.update(downloaded=True, downloaded_at=checked,
                                etag=response.headers.get('ETag'),
                                last_modified=response.headers.get('Last-Modified'))
                    control = response.headers.get('Cache-Control', '').lower()
                    if 'no-store' not in control:
                        DOCS.mkdir(parents=True, exist_ok=True)
                        cache_file = meta['body_hash'] + '.http'
                        (DOCS / cache_file).write_bytes(body)
                        max_age = re.search(r'max-age=(\d+)', control)
                        interval = min(CHECK_INTERVAL, int(max_age[1])) if max_age else CHECK_INTERVAL
                        if 'no-cache' in control:
                            interval = 0
                        cached_meta = dict(meta, cache_file=cache_file, next_check=time.time()+interval, cache_control=control)
                        with CACHE_LOCK:
                            all_cache = _cache_load(); all_cache[url] = cached_meta
                            _atomic_json(HTTP_CACHE, all_cache)
                            _prune_http_bodies(all_cache)
                    else:
                        with CACHE_LOCK:
                            all_cache = _cache_load(); all_cache.pop(url, None)
                            _atomic_json(HTTP_CACHE, all_cache)
                    _trace(meta)
                    return body
        except (requests.Timeout, requests.ConnectionError) as error:
            meta['error'] = f'{type(error).__name__}: {str(error)[:200]}'
            _trace(meta)
            if attempt < MAX_ATTEMPTS:
                time.sleep(0.5)
                continue
            raise
        except Exception as error:
            meta['error'] = str(error)[:300]
            _trace(meta)
            raise
    raise ValueError('No se completó la consulta oficial')


def _add_record(new, *, source,edition,var,year,value, group='',date_published='', url='',kind='anual',unit=None,document_id='',cell='',note=''):
    if var not in VARIABLES or year is None:return
    try: value=float(value)
    except (ValueError,TypeError):return
    valid_year = (bool(re.fullmatch(r'20\d{2}', str(year))) if source == weo_imf.SOURCE
                  else 2015 <= int(str(year)[:4]) <= 2035)
    if not math.isfinite(value) or not -100<value<1000 or not valid_year:return
    if var in {'pbi','inflacion','desempleo','tpm'} and not -30<=value<=100:return
    if var == 'poblacion' and not 0 < value < 500: return
    if var.startswith('tc_') and not 1.0<=value<=20.0:return
    new.append({'source':source,'edition':edition,'variable':var,'year':str(year),'value':round(value,6),'group':group,'published':date_published,'url':url,'kind':kind,'unit':unit or ('S/ por USD' if var.startswith('tc_') else '%'),'document_id':document_id,'cell':cell,'note':note})

def _period(s):
    # BCRPData usa Ene.2026, Jan.2026, 2026-10 o Ene-2026
    s=str(s).strip();m=re.search(r'(20\d{2})[-/](\d{1,2})',s)
    if m:return f'{int(m[1]):04d}-{int(m[2]):02d}'
    m=re.search(r'([a-zA-ZáéíóúÁÉÍÓÚ]{3,})[. /-]*(20\d{2})',s)
    if m:
        mon=MONTHS.get(_text(m[1])[:3])
        if mon:return f'{int(m[2]):04d}-{mon:02d}'
    return None

def parse_bcrp_api(code, body):
    result=json.loads(body.decode('utf-8-sig'))
    if not isinstance(result,dict) or not isinstance(result.get('periods'),list):raise ValueError('Formato BCRPData no reconocido')
    if code not in SERIES:raise ValueError('Código de serie no permitido')
    variable,source,unit,note=SERIES[code]
    new=[]
    for row in result['periods']:
        period=_period(row.get('name'))
        values=row.get('values') or []
        if not period or not values or values[0] in (None,'n.d.','—',''):continue
        try: value=float(str(values[0]).replace(',','.'))
        except ValueError: continue
        _add_record(new,source=source,edition=code,var=variable,year=period,value=value,
                    url=f'https://estadisticas.bcrp.gob.pe/estadisticas/series/mensuales/resultados/{code}',
                    kind='12_meses',unit=unit,note=note)
    if not new:raise ValueError(f'BCRPData {code} no devolvió observaciones numéricas')
    return new


def _store_document(body, source, edition, extension):
    sha = hashlib.sha256(body).hexdigest()
    namespace = 'FMI' if source.startswith('FMI') else 'MEF' if source.startswith('MEF') else 'BCRP'
    ident = hashlib.sha1(f'{namespace}/{edition}/{sha}'.encode()).hexdigest()[:20]
    filename = ident + extension
    # Compatibilidad con IDs de la v1.7: el mismo respaldo no es otra revisión.
    for existing in _load()['editions']:
        if (existing.get('hash') == sha and existing.get('edition') == edition
                and str(existing.get('source', '')).startswith(namespace) and existing.get('file')):
            path = (DOCS / existing['file']).resolve()
            if path.is_relative_to(DOCS.resolve()):
                ident, filename = existing['id'], existing['file']
                break
    DOCS.mkdir(parents=True, exist_ok=True)
    path = DOCS / filename
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != sha:
        temporary = path.with_name(path.name + f'.{threading.get_ident()}.tmp')
        temporary.write_bytes(body); os.replace(temporary, path)
    # La caché reutiliza el respaldo: no guarda una segunda copia del Excel/PDF.
    with CACHE_LOCK:
        cache = _cache_load()
        changed = False
        for entry in cache.values():
            if isinstance(entry, dict) and entry.get('body_hash') == sha:
                entry['cache_file'] = filename; changed = True
        if changed:
            _atomic_json(HTTP_CACHE, cache)
            _prune_http_bodies(cache)
    return ident, filename, sha


def _pdf_reader(body):
    """Lector PDF incluido en el Dashboard; no exige pip ni conexión de red."""
    if not body.startswith(b'%PDF'):
        _pdf_text(body)  # diagnóstico de HTML/bloqueo
        raise ValueError('El archivo seleccionado no es PDF')
    try:
        from pypdf import PdfReader
    except ImportError:
        import sys
        library = str(ROOT / '_vendor')
        if library not in sys.path:
            sys.path.insert(0, library)
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise ValueError('No se pudo cargar el lector PDF integrado; revisa la integridad de la carpeta Dashboard') from exc
    return PdfReader(io.BytesIO(body))


def _pdf_text(body):
    if not body.startswith(b'%PDF'):
        head=body[:10000].lower()
        if any(x in head for x in (b'incapsula',b'_incapsula_resource',b'access denied',b'captcha',b'robot',b'bot detection',b'challenge')):
            raise FuenteProtegida('El portal BCRP bloqueó la descarga automática; importa el PDF obtenido por una vía oficial')
        if b'<html' in head or b'<iframe' in head or b'<!doctype html' in head:
            raise FuenteProtegida('El servidor devolvió HTML en lugar del PDF')
        raise ValueError('El archivo seleccionado no es un PDF válido')
    reader=_pdf_reader(body)
    if len(reader.pages)>250:raise ValueError('PDF inusualmente extenso')
    return '\n'.join((page.extract_text(extraction_mode='layout') or '') for page in reader.pages)


def _parse_eem_text(text, edition, publication, url, document_id=''):
    """Compatibilidad obsoleta: no asignar celdas sin las coordenadas del PDF."""
    raise ValueError('Se requiere el PDF original y el lector compartido bcrp_documents')


def _parse_ri_text(text, edition, publication, url, document_id=''):
    """El texto lineal no acredita columnas; no produce pronósticos."""
    return []


def _shared_bcrp_pdf(body, filename='', url='', document_id=''):
    """Un único lector geométrico para el servidor y el notebook."""
    from bcrp_documents import parse_document, dashboard_records
    parsed = parse_document(body, document_name=filename, source_url=url)
    return parsed, dashboard_records(parsed, url=url, document_id=document_id)


def _parse_ri_summary_pdf(body, edition, publication, url, document_id=''):
    """Compatibilidad: columnas identificadas por año y revisión, sin ancho fijo."""
    parsed, rows = _shared_bcrp_pdf(body, url=url, document_id=document_id)
    if parsed['document']['type'] != 'inflation_report':
        raise ValueError('El PDF no corresponde a un Reporte de Inflación')
    return rows


def _mef_valid_value(variable, value):
    """No confundir PBI en miles de millones o IPC índice con tasas anuales."""
    if not isinstance(value,(int,float)) or isinstance(value,bool):return False
    if variable=='pbi':return -15 <= value <= 20
    if variable=='inflacion':return -10 <= value <= 30
    if variable.startswith('tc_'):return 1 <= value <= 20
    if variable=='desempleo':return 0 <= value <= 40
    return False


def _links_from_html(url):
    body=_get(url,limit=5_000_000)
    from lxml import html
    root=html.fromstring(body)
    links=[]
    for a in root.xpath('//a[@href]'):
        href=urljoin(url,a.get('href'))
        if _url_valid(href):links.append((' '.join(a.itertext()).strip(),href))
    return links


# Integrar en proyecciones_externas.py: usa imports y helpers existentes.
MEF_COLLECTION = 'https://www.gob.pe/institucion/mef/colecciones/21-marco-macroeconomico-multianual-mmm'
# Hecho documentado; no se infiere la fecha a partir del horizonte.
MEF_PUBLICATION_FACTS = {
    'IAPM 2026–2029': {
        'published': '2026-04', 'publication_precision': 'month',
        'publication_evidence_url': 'https://www.gob.pe/institucion/mef/noticias/1385927-mef-proyecta-crecimiento-economico-promedio-de-3-2-entre-2027-2029-por-mayores-inversiones-exportaciones-dinamicas-y-mejoras-productivas',
        'publication_note': 'La nota MEF del 30/04/2026 confirma la publicación; no se acredita el día exacto de primera publicación del Excel.'
    }
}


def _mef_edition(label, url=''):
    name = _text((str(label) + ' ' + str(url)).replace('\u2013', '-').replace('\u2014', '-'))
    match = re.search(r'\b(mmm|iapm)[\s_-]*(20\d{2})[\s_-]+(20\d{2})\b', name)
    if not match:
        return None
    kind, first, last = match[1].upper(), int(match[2]), int(match[3])
    if last-first != 3 or not 2015 <= first <= date.today().year+1:
        return None
    return kind, first, last


def _mef_html(body):
    from lxml import html
    return html.fromstring(body.decode('utf-8-sig', errors='replace'))


def _candidate_mef():
    """Descubre adjuntos en el compendio MEF de Gob.pe, sin enumerar IDs/URLs.

    La ficha de un MMM puede incorporar el IAPM posterior sin cambiar su fecha.
    Su fecha de cabecera nunca se asigna automáticamente al adjunto IAPM.
    """
    root = _mef_html(_get(MEF_COLLECTION, limit=5_000_000))
    pages = {}
    for anchor in root.xpath('//a[@href]'):
        label = ' '.join(anchor.itertext()).strip()
        link = urljoin(MEF_COLLECTION, anchor.get('href'))
        years = re.search(r'(20\d{2})\s*[-–]\s*(20\d{2})', label)
        if not years or not _url_valid(link) or '/institucion/mef/informes-publicaciones/' not in link:
            continue
        first, last = int(years[1]), int(years[2])
        if last-first == 3 and first <= date.today().year+1:
            pages[(first, last)] = link
    if not pages:
        raise ValueError('El compendio oficial MEF no contiene fichas MMM reconocibles')
    candidates = {}
    # Dos fichas permiten descubrir tanto un nuevo MMM como el IAPM incorporado
    # en la ficha vigente. No se rastrea el archivo histórico entero.
    for (page_first, page_last), page_url in sorted(pages.items(), reverse=True)[:2]:
        page = _mef_html(_get(page_url, limit=5_000_000))
        publication = ''
        for paragraph in page.xpath('//*[contains(@class,"institution-document__header")]//p'):
            when = _survey_date(' '.join(paragraph.itertext()))
            if when:
                publication = when.isoformat()
                break
        pdf_links = {}
        xlsx_links = {}
        for anchor in page.xpath('//a[@href]'):
            label = ' '.join(anchor.itertext()).strip()
            link = urljoin(page_url, anchor.get('href'))
            if not _url_valid(link):
                continue
            parsed = _mef_edition(label, link)
            if not parsed:
                continue
            path = urlparse(link).path.lower()
            if path.endswith('.pdf'):
                pdf_links.setdefault(parsed, link)
            if path.endswith('.xlsx') and 'cuadros' in _text(label + ' ' + link):
                xlsx_links.setdefault(parsed, link)
        for (kind, first, last), link in xlsx_links.items():
            edition = f'{kind} {first}–{last}'
            item = {'edition': edition, 'url': link, 'landing_url': page_url,
                    'pdf_url': pdf_links.get((kind, first, last), ''),
                    'published': '', 'publication_precision': 'unknown',
                    'publication_evidence_url': page_url}
            if kind == 'MMM' and first == page_first and last == page_last and publication:
                # El año debe corresponder a la edición de la ficha, no al adjunto.
                if int(publication[:4]) == first-1:
                    item.update(published=publication, publication_precision='day')
            if edition in MEF_PUBLICATION_FACTS:
                item.update(MEF_PUBLICATION_FACTS[edition])
            candidates[edition] = item
    if not candidates:
        raise ValueError('Las fichas oficiales MEF no enlazan cuadros XLSX reconocibles')
    return sorted(candidates.values(), key=lambda x: (
        int(re.search(r'20\d{2}', x['edition'])[0]),
        x['edition'].startswith('IAPM')), reverse=True)[:2]


def _mef_variable(label):
    """Solo rótulos exactos de la tabla de indicadores principales del Perú."""
    label = re.sub(r'\s+', ' ', _text(label)).strip()
    if re.fullmatch(r'producto bruto interno \(variacion porcentual real\)\s*\d*', label):
        return 'pbi'
    if re.fullmatch(r'(?:precios|inflacion) \(variacion porcentual acumulada\)\s*\d*', label):
        return 'inflacion'
    if re.fullmatch(r'tipo de cambio promedio \(soles por us dolar\)\s*\d*', label):
        return 'tc_promedio'
    if re.fullmatch(r'tipo de cambio fin de(?:l)? periodo \(soles por us dolar\)\s*\d*', label):
        return 'tc_cierre'
    return None


def _parse_mef_xlsx(body, edition, publication, url, document_id=''):
    """Lee la tabla principal oficial; conserva cifras, unidades, celdas y notas.

    Excluye el año histórico anterior a la publicación. No usa promedios del
    horizonte, tablas sectoriales ni anexos de revisiones como nuevos pronósticos.
    Un cambio ambiguo de estructura falla explícitamente y conserva la base.
    """
    _validate_xlsx(body)
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter
    import math
    parsed = _mef_edition(edition)
    if not parsed:
        raise ValueError('Edición MMM/IAPM no reconocida')
    kind, first, last = parsed
    first_forecast = first-1 if kind == 'MMM' else first
    required_years = set(range(first_forecast, last+1))
    wb = load_workbook(io.BytesIO(body), read_only=True, data_only=True)
    matches = []
    try:
        for ws in wb.worksheets:
            if (ws.max_row or 0) > 1000:
                continue
            rows = list(ws.iter_rows(max_row=min(ws.max_row or 1, 250),
                                    max_col=min(ws.max_column or 1, 85), values_only=True))
            title = ' '.join(_text(cell) for row in rows[:8] for cell in row if isinstance(cell, str))
            if 'principales indicadores macroeconomicos' in title:
                matches.append((ws.title, rows))
        if len(matches) != 1:
            raise ValueError('No se identificó una única tabla MEF de indicadores macroeconómicos principales')
        sheet_name, rows = matches[0]
        year_rows = []
        for ridx, row in enumerate(rows[:15]):
            positions = [(col, int(val)) for col, val in enumerate(row)
                         if isinstance(val, (int, float)) and not isinstance(val, bool)
                         and math.isfinite(float(val)) and int(val) == val and 2015 <= val <= 2040]
            if required_years.issubset({year for col, year in positions}) and max(year for col, year in positions) == last:
                year_rows.append((ridx, positions))
        if len(year_rows) != 1:
            raise ValueError('Encabezados MEF ambiguos o no corresponden al horizonte de la edición')
        header_index, year_positions = year_rows[0]
        years = {col: year for col, year in year_positions if year in required_years}
        if len(years) != len(required_years):
            raise ValueError('La tabla MEF contiene años duplicados')
        first_year_col = min(col for col, year in year_positions)
        note = ' '.join(str(cell).strip() for row in rows for cell in row
                        if isinstance(cell, str) and (
                            re.match(r'^\d+/', cell.strip()) or _text(cell).startswith('fuente:')
                            or _text(cell).startswith('memo:')))
        records = []
        found_variables = set()
        for ridx, row in enumerate(rows[header_index+1:], header_index+2):
            label = ' '.join(str(cell).strip() for cell in row[:first_year_col] if cell is not None)
            variable = _mef_variable(label)
            if variable is None:
                continue
            if variable in found_variables:
                raise ValueError(f'La tabla MEF duplica la variable {variable}')
            found_variables.add(variable)
            for col, year in years.items():
                value = row[col] if col < len(row) else None
                if not _mef_valid_value(variable, value) or not math.isfinite(float(value)):
                    raise ValueError(f'Valor MEF ausente o inválido en {sheet_name}!{get_column_letter(col+1)}{ridx}')
                _add_record(records, source='MEF · MMM/IAPM', edition=edition,
                            var=variable, year=year, value=value, date_published=publication,
                            url=url, document_id=document_id,
                            cell=f'{sheet_name}!{get_column_letter(col+1)}{ridx}',
                            note=note or 'Cuadro de indicadores macroeconómicos principales del MEF')
                records[-1]['definition'] = label
                records[-1]['coverage'] = 'Perú; año calendario'
                # Mantener la precisión numérica que entrega el propio Excel.
                records[-1]['value'] = float(value)
        if found_variables != {'pbi', 'inflacion', 'tc_promedio', 'tc_cierre'}:
            raise ValueError('El cuadro MEF está incompleto o cambió su estructura; no se reemplaza la edición válida')
        return records
    finally:
        wb.close()


def _parse_weo_xlsx(body, url, *, origin='official'):
    """Cuatro pronósticos de Perú con vintage único, respaldo y último año real."""
    edition, series = weo_imf.parse_workbook(body, url, provenance=origin)
    published = next(iter(series.values()))['published']
    if any(item['published'] != published for item in series.values()):
        raise ValueError('Fechas de publicación heterogéneas dentro del mismo WEO')
    ident, filename, sha = _store_document(body, weo_imf.SOURCE, edition, '.xlsx')
    rows = []
    for code, item in series.items():
        variable, unit = weo_imf.CODES[code]
        for year, value in item['years'].items():
            _add_record(rows, source=weo_imf.SOURCE, edition=edition, var=variable,
                        year=year, value=value, date_published=published,
                        url=url, unit=unit, document_id=ident,
                        cell=f"Countries!{item['row']}",
                        note=f"WEO {code}; último dato observado FMI: {item['last_actual']}; "
                             'solo Perú; frecuencia anual; sin estimación IASPE')
    if len(rows) != sum(len(x['years']) for x in series.values()):
        raise ValueError('No se conservaron todas las cifras WEO verificadas')
    doc = {'id':ident, 'source':weo_imf.SOURCE, 'edition':edition,
           'title':f'WEO {edition} · Perú', 'published':published,
           'url':url, 'hash':sha, 'file':filename, 'kind':'xlsx',
           'rows':len(rows), 'origin':origin, 'extractor_verified':True,
           'catalogue_url':weo_imf.PORTAL,
           'codes':list(series), 'latest_actual':{code:series[code]['last_actual'] for code in series}}
    for row in rows:
        row['origin'] = origin
        row['code_weo'] = next(code for code, (variable, _) in weo_imf.CODES.items() if variable == row['variable'])
        row['last_actual'] = series[row['code_weo']]['last_actual']
        # Conservar la precisión original del Excel WEO.
        row['value'] = series[row['code_weo']]['years'][int(row['year'])]
    return rows, [doc]


def _update_weo():
    """Actualiza WEO desde el catálogo oficial y valida su edición con SDMX."""
    warnings = []
    api = None
    try:
        api = weo_imf.latest_sdmx(lambda url, **kw: _get(url, refresh=True, **kw))
    except (ValueError, requests.RequestException, FuenteProtegida) as exc:
        warnings.append('SDMX no disponible; se verificó el catálogo oficial: ' + str(exc)[:180])
    index = _get(weo_imf.PORTAL, limit=3_000_000, timeout=25, refresh=True)
    url = weo_imf.discover(index)
    if api and api['edition'] > weo_imf._vintage(url):
        raise ValueError('La API anuncia una edición WEO más reciente que el Excel del catálogo; no se incorpora una edición anterior')
    stored = [e['edition'] for e in _load()['editions']
              if e.get('source') == weo_imf.SOURCE and e.get('file')]
    if stored and weo_imf._vintage(url) < max(stored):
        raise ValueError('El catálogo WEO devuelve una edición anterior a la almacenada; no se presenta como nueva')
    body = _get(url, limit=35_000_000, timeout=25, refresh=True)
    rows, docs = _parse_weo_xlsx(body, url)
    if api and api['edition'] == docs[0]['edition']:
        if api['published'] != docs[0]['published'] or api['latest_actual'] != docs[0]['latest_actual']:
            raise ValueError('Los metadatos de la edición WEO discrepan entre SDMX y Excel')
    docs[0].update(discovery_verified=True, publication_evidence_url=weo_imf.PORTAL,
                   discovery_method='sdmx_and_catalogue' if api else 'official_catalogue',
                   sdmx_metadata=api, warnings=warnings,
                   provenance_note='Cifras originales del Excel oficial; descubrimiento y transporte verificados en la consulta registrada')
    return rows, docs


def _update_mef():
    results, editions = [], []
    try:
        candidates = _candidate_mef()
    except Exception as exc:
        return [], [{'id': 'mef-discovery-error', 'source': 'MEF · MMM/IAPM',
                     'edition': 'Descubrimiento', 'url': MEF_COLLECTION,
                     'error': str(exc)[:250], 'blocked': isinstance(exc, FuenteProtegida)}]
    for candidate in candidates:
        edition, url = candidate['edition'], candidate['url']
        try:
            body = _get(url, limit=24_000_000, timeout=14)
            new = _parse_mef_xlsx(body, edition, candidate['published'], url)
            ident, filename, sha = _store_document(body, 'MEF', edition, '.xlsx')
            meta = {key: candidate.get(key, '') for key in (
                'landing_url', 'publication_precision', 'publication_evidence_url', 'publication_note')}
            for row in new:
                row.update(document_id=ident, origin='official', **meta)
            results.extend(new)
            editions.append({'id': ident, 'source': 'MEF · MMM/IAPM', 'edition': edition,
                             'title': 'Cuadros estadísticos ' + edition,
                             'published': candidate['published'], 'url': url, 'hash': sha,
                             'file': filename, 'kind': 'xlsx', 'rows': len(new),
                             'origin': 'official', **meta})
        except Exception as exc:
            editions.append({'id': 'mef-error-' + _text(edition).replace(' ', '-'),
                             'source': 'MEF · MMM/IAPM', 'edition': edition, 'url': url,
                             'error': str(exc)[:250], 'blocked': isinstance(exc, FuenteProtegida)})
    return results, editions


def _update_ri():
    """Descubre el RI vigente en el índice oficial, sin adivinar rutas futuras."""
    source = 'BCRP · Reporte de Inflación'
    edition = 'Descubrimiento'; url = PORTAL_RI
    try:
        candidates = []
        for label, link in _links_from_html(PORTAL_RI):
            match = re.search(r'/Reporte-Inflacion/(20\d{2})/(marzo|junio|setiembre|septiembre|diciembre)/reporte-de-inflacion-[^/]+\.pdf$', urlparse(link).path, re.I)
            if match:
                month = MONTHS.get(_text(match[2])[:3])
                candidates.append((int(match[1]), month, match[2].title(), link))
        if not candidates:
            raise ValueError('El índice oficial no enlaza un Reporte de Inflación reconocible')
        year, month, name, url = max(candidates)
        edition = f'{name} {year}'
        body = _get(url, limit=26_000_000)
        parsed, rows = _shared_bcrp_pdf(body, url=url)
        if parsed['document']['type'] != 'inflation_report':
            raise ValueError('El PDF no identifica un Reporte de Inflación')
        edition = parsed['document']['edition']
        published = parsed['document'].get('published') or f'{year}-{month:02d}'
        if not rows:
            raise ValueError('PDF descargado sin cuadros inequívocos; no se incorporó una edición vacía')
        ident, filename, sha = _store_document(body, 'BCRP RI', edition, '.pdf')
        for row in rows:
            row.update(document_id=ident, origin='official')
        return rows, [{'id': ident, 'source': source, 'edition': edition, 'published': published,
                       'published_precision': 'month', 'publication_evidence_url': url,
                       'title': 'Reporte de Inflación ' + edition, 'url': url, 'hash': sha,
                       'file': filename, 'kind': 'pdf', 'rows': len(rows), 'origin': 'official',
                        'extractor_verified': True, 'history': parsed['records']}]
    except Exception as exc:
        return [], [{'id': 'ri-error', 'source': source, 'edition': edition, 'url': url,
                     'error': str(exc)[:300], 'blocked': isinstance(exc, FuenteProtegida)}]


def _survey_date(value):
    """Convierte la fecha de cada encuesta del Excel BCRP (no año pronosticado)."""
    if isinstance(value,datetime):return value.date()
    if isinstance(value,date):return value
    txt=_text(str(value or ''))
    m=re.search(r'(?<!\d)(\d{1,2})\s+de\s+([a-z]+)\s+(?:de|del)\s+(20\d{2})(?!\d)',txt)
    if not m:return None
    month=MONTHS.get(m[2][:3])
    if not month:return None
    try:return date(int(m[3]),month,int(m[1]))
    except ValueError:return None


def _validate_xlsx(body):
    import zipfile
    if not body.startswith(b'PK'):
        raise ValueError('La respuesta no es un Excel XLSX')
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        entries = archive.infolist()
        if len(entries) > 3000 or sum(x.file_size for x in entries) > 120_000_000:
            raise ValueError('Excel excede los límites de descompresión')
        if '[Content_Types].xml' not in archive.namelist() or 'xl/workbook.xml' not in archive.namelist():
            raise ValueError('ZIP sin estructura XLSX')


def _parse_bcrp_excel(body, variable, url='', document_id='', history_sink=None):
    """Selecciona una encuesta completa; fecha de encuesta != publicación.

    Los encabezados identifican cada grupo; no se asumen posiciones. El Excel
    debe declarar años calendario y los tres grupos para cada año seleccionado.
    """
    _validate_xlsx(body)
    if len(body) > 11_000_000 or variable not in ('tc_cierre', 'pbi', 'inflacion'):
        raise ValueError('Encuesta Excel no admitida')
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(body), data_only=True, read_only=True)
    groups = ('Analistas económicos', 'Sistema financiero', 'Empresas no financieras')
    found = []
    try:
        for ws in wb.worksheets:
            if (ws.max_row or 0) > 12000 or (ws.max_column or 0) > 80:
                continue
            rows = list(ws.iter_rows(values_only=True))
            header_text = ' '.join(_text(v) for row in rows[:8] for v in row if v is not None)
            expected = {'tc_cierre': ('tipo de cambio',), 'pbi': ('pbi', 'producto bruto interno'),
                        'inflacion': ('inflacion',)}[variable]
            if not any(x in header_text for x in expected):
                continue
            columns = {}
            for col in range(min(ws.max_column or 0, 80)):
                label = ' '.join(_text(row[col]) for row in rows[2:6] if len(row)>col and row[col] is not None)
                if 'analistas' in label and 'economicos' in label:
                    columns[groups[0]] = col
                elif 'sistema' in label and 'financiero' in label:
                    columns[groups[1]] = col
                elif 'empresas' in label and 'financieras' in label:
                    columns[groups[2]] = col
            if set(columns) != set(groups):
                raise ValueError('No se identificaron los encabezados de los tres encuestados')
            forecast_year = None
            for ridx, row in enumerate(rows, 1):
                first = str(row[0] or '').strip()
                label = _text(first)
                m = re.match(r'^expectativas\s+anuales\s+(?:de|del)\s+(20\d{2})\b', label)
                if m:
                    forecast_year = int(m[1]); continue
                if 'expectativas' in label and ('12 meses' in label or 'doce meses' in label):
                    forecast_year = None
                when = _survey_date(row[0])
                if not forecast_year or not when or when > date.today():
                    continue
                if not when.year <= forecast_year <= when.year + 3:
                    continue
                for group, col in columns.items():
                    raw = row[col] if col < len(row) else None
                    if raw is None or isinstance(raw, bool):
                        continue
                    try:
                        value = float(str(raw).replace(',', '.'))
                    except (ValueError, TypeError):
                        continue
                    if not math.isfinite(value):
                        continue
                    if variable == 'tc_cierre' and not 1 <= value <= 20:
                        continue
                    if variable in ('pbi', 'inflacion') and not -20 <= value <= 100:
                        continue
                    from openpyxl.utils import get_column_letter
                    found.append((when, forecast_year, group, value, f'{ws.title}!{get_column_letter(col+1)}{ridx}'))
    finally:
        wb.close()
    if not found:
        raise ValueError('No se reconocieron expectativas por año calendario')
    # En los Excel oficiales, inflación y PBI suelen almacenarse como
    # fracciones (0.044 = 4.4 %); TC ya está expresado en S/ por USD.
    # Nunca trasladar 0.044 como 0.044 % al Dashboard.
    if variable in ('inflacion', 'pbi'):
        found = [(when, yr, g, v * 100 if abs(v) < 1 else v, cell)
                 for when, yr, g, v, cell in found]
    if history_sink is not None:
        for when, yr, group, value, cell in found:
            if when >= date(2025, 1, 1) and 2026 <= yr <= 2030:
                history_sink.append({'variable': variable, 'year': yr, 'group': group,
                                     'survey_date': when.isoformat(), 'value': round(value, 6),
                                     'unit': '%' if variable in ('pbi', 'inflacion') else 'S/ por USD',
                                     'cell': cell, 'origin': 'documento incorporado', 'url': url})
    latest = max(r[0] for r in found)
    chosen = {}
    for when, year, group, value, cell in found:
        if when != latest:
            continue
        key = (year, group)
        if key in chosen and chosen[key][0] != value:
            raise ValueError('Valores contradictorios para una misma encuesta')
        chosen[key] = (value, cell)
    years = {year for year, group in chosen}
    if len(years) < 2 or set(chosen) != {(year, group) for year in years for group in groups}:
        raise ValueError('La última encuesta está incompleta; no se reemplaza la edición vigente')
    edition = latest.strftime('%Y-%m')
    items = []
    for (year, group), (value, cell) in sorted(chosen.items()):
        _add_record(items, source='BCRP · encuesta anual', edition=edition, var=variable,
                    year=year, value=value, group=group, date_published=None, url=url,
                    document_id=document_id, cell=cell,
                    note='Mediana por encuestado y año calendario; el libro no acredita fecha de publicación')
        items[-1].update(survey_date=latest.isoformat(), published_precision='unknown',
                         publication_status='Fecha de encuesta conocida; publicación no acreditada')
    return items, edition


def _update_eem_excel():
    """Intenta los XLSX oficiales por variable, sin inventar observaciones."""
    all_rows=[];all_editions=[]
    for variable,url in BCRP_XLSX_ENCUESTAS:
        try:
            body=_get(url,limit=11_000_000,timeout=14)
            if not body.startswith(b'PK'):
                _pdf_text(body)  # identificar si es un bloqueo HTML/captcha
                raise ValueError('El servidor BCRP no devolvió un Excel XLSX')
            full_history=[]
            rows,edition=_parse_bcrp_excel(body,variable,url,history_sink=full_history)
            ident,filename,sha=_store_document(body,'BCRP EEM XLSX '+variable,edition,'.xlsx')
            for r in rows:r['document_id']=ident;r['origin']='official'
            all_rows.extend(rows)
            all_editions.append({'id':ident,'source':'BCRP · encuesta anual','edition':edition,
                         'title':'Expectativas anuales '+variable+' · '+edition,'variable':variable,
                         'published':None,'published_precision':'unknown','url':url,'file':filename,'hash':sha,
                         'kind':'xlsx','rows':len(rows),'origin':'official','history':full_history})
        except FuenteProtegida as e:
            all_editions.append({'id':'eem-xlsx-bloqueado-'+variable,'source':'BCRP · encuesta anual',
                        'edition':'Excel '+variable,'variable':variable,'url':url,'error':str(e),'blocked':True})
            # Las tres planillas son independientes: si un archivo falla,
            # continuar con las otras dos permite una actualización parcial.
            continue
        except Exception as e:
            all_editions.append({'id':'eem-xlsx-error-'+variable,'source':'BCRP · encuesta anual',
                        'edition':'Excel '+variable,'variable':variable,'url':url,'error':str(e)[:220]})
    return all_rows,all_editions


def _update_eem():
    # Preferimos documentos oficiales que identifiquen claramente la encuesta
    # anual por fecha de edición; no confundimos series móviles a 12 meses.
    results=[];editions=[];seen=set()
    candidates=[]
    # Consulta de índices del BCRP. Si cambian su estructura, se informa fallo;
    # nunca se registra una edición supuesta.
    for portal in [PORTAL_NOTAS,f'https://www.bcrp.gob.pe/publicaciones/notas-de-estudios/{date.today().year}.html']:
        try:
            for label,url in _links_from_html(portal):
                if 'notas-estudios' not in _text(url) or not url.lower().endswith('.pdf'):continue
                if not any(x in _text(label) for x in ('encuesta','expectativa')):continue
                if url not in seen:seen.add(url);candidates.append((label,url))
        except Exception as e:
            editions.append({'id':'eem-portal-'+str(len(editions)),'source':'BCRP · encuesta anual',
                             'edition':'Descubrimiento','url':portal,'error':str(e)[:180]})
    candidates = sorted(dict((url, (label, url)) for label, url in candidates).values(),
                        key=lambda pair: tuple(reversed(tuple(map(int, re.search(r'nota-de-estudios-(\d+)-(20\d{2})', pair[1]).groups())))) if re.search(r'nota-de-estudios-(\d+)-(20\d{2})', pair[1]) else (0, 0), reverse=True)[:2]
    for label,url in candidates:
        try:
            body=_get(url,limit=17_000_000)
            parsed, new = _shared_bcrp_pdf(body, url=url)
            if parsed['document']['type'] != 'survey':
                raise ValueError('PDF sin tablas verificables de encuesta BCRP')
            edition = parsed['document']['edition']
            ident,filename,sha=_store_document(body,'BCRP EEM',edition,'.pdf')
            for r in new:r['document_id']=ident;r['origin']='official'
            results.extend(new)
            editions.append({'id':ident,'source':'BCRP · encuesta anual','edition':edition,'title':'Encuesta mensual '+edition,
                             'published':parsed['document'].get('published'),'published_precision':'day','url':url,'hash':sha,'file':filename,'kind':'pdf','rows':len(new),'origin':'official',
                             'extractor_verified':True,'history':parsed['records']})
            if new:break
        except FuenteProtegida as e:
            editions.append({'id':'eem-bloqueado','source':'BCRP · encuesta anual','edition':label,
                             'url':url,'error':str(e),'blocked':True})
            break
        except Exception as e:
            editions.append({'id':'eem-'+hashlib.sha1(url.encode()).hexdigest()[:10],
                             'source':'BCRP · encuesta anual','edition':label,'url':url,'error':str(e)[:220]})
    return results,editions


def _edition_key(item):
    edition = str(item.get('edition', ''))
    match = re.fullmatch(r'(20\d{2})-(\d{2})', edition)
    if match:
        return int(match[1]), int(match[2])
    match = re.search(r'(MMM|IAPM)\s*(20\d{2})', edition, re.I)
    if match:
        first = int(match[2])
        return (first-1, 8) if match[1].upper() == 'MMM' else (first, 4)
    for name, month in MONTHS.items():
        if _text(edition).startswith(name):
            year = re.search(r'20\d{2}', edition)
            if year:
                return int(year[0]), month
    published = str(item.get('published') or '')
    if re.match(r'^20\d{2}-\d{2}', published):
        return int(published[:4]), int(published[5:7])
    return 0, 0


def _enrich(records, editions, events):
    """Vincula cada cifra al cuerpo realmente recibido, sin fabricar fechas."""
    metadata = {event['url']: event for event in events if event.get('body_hash') and not event.get('error')}
    documents = {}
    for item in editions:
        if not item.get('file'):
            continue
        meta = metadata.get(item.get('url'), {})
        item['institution'] = 'FMI' if item.get('source', '').startswith('FMI') else 'MEF' if item.get('source', '').startswith('MEF') else 'BCRP'
        item['downloaded_at'] = meta.get('downloaded_at')
        item['checked_at'] = meta.get('checked_at')
        item['http_status'] = meta.get('http_status')
        item['content_type'] = meta.get('content_type')
        item['document_hash'] = item.get('hash')
        evidence = metadata.get(item.get('publication_evidence_url'), {})
        if evidence.get('body_hash'):
            item['publication_evidence_hash'] = evidence['body_hash']
            item['publication_evidence_file'] = evidence['body_hash'] + '.http'
            # Un catálogo no-store deja traza/hash, pero no un archivo de caché.
            if item.get('source') == weo_imf.SOURCE and not (DOCS / item['publication_evidence_file']).is_file():
                item['publication_evidence_file'] = None
        item['published_precision'] = item.get('publication_precision') or item.get('published_precision') or (
            'day' if re.fullmatch(r'20\d{2}-\d{2}-\d{2}', str(item.get('published'))) else 'month' if re.fullmatch(r'20\d{2}-\d{2}', str(item.get('published'))) else 'unknown')
        item['transport_verified'] = bool(meta.get('body_hash') == item.get('hash') and meta.get('downloaded_at'))
        item['extractor_verified'] = item.get('extractor_verified', item.get('kind') == 'xlsx')
        documents[item['id']] = item
    for row in records:
        item = documents.get(row.get('document_id'), {})
        for key in ('institution', 'downloaded_at', 'checked_at', 'document_hash', 'published_precision', 'transport_verified', 'extractor_verified', 'publication_evidence_hash', 'publication_evidence_file'):
            row[key] = item.get(key)
        row['publication_evidence_url'] = item.get('publication_evidence_url', '')
    return records, editions


def _record_key(row):
    if row.get('source') == 'BCRP · Reporte de Inflación' and row.get('kind') == 'anual':
        return (row['source'], _edition_key(row), row['variable'], str(row['year']), row.get('group', ''))
    return (row['source'], row['edition'], row['variable'], str(row['year']),
            row.get('group', ''), row.get('document_id', ''))


def _record_evidence(row):
    evidence = list(row.get('evidence', []))
    if row.get('document_id'):
        item = {key: row.get(key) for key in ('document_id', 'document_hash', 'document_edition',
                'document', 'page', 'bbox', 'value_text', 'url') if row.get(key) is not None}
        if item not in evidence:
            evidence.append(item)
    return evidence


def _merge(state, items, editions):
    """Historial inmutable por documento; una revisión conserva el respaldo previo."""
    previous = {e.get('id'): e for e in state['editions'] if e.get('file')}
    info = {'new_editions': 0, 'revisions': 0, 'repeated': 0, 'documents': {}}
    for item in editions:
        if not item.get('file') or not item.get('rows'):
            continue
        peers = [e for e in previous.values() if e.get('source') == item.get('source')
                 and e.get('edition') == item.get('edition') and e.get('variable') == item.get('variable')]
        if item['id'] in previous:
            kind = 'repeated'
        elif any(e.get('hash') for e in peers):
            kind = 'revisions'
        else:
            kind = 'new_editions'
        info[kind] += 1
        info['documents'][item['id']] = kind
    previous_editions = {(e.get('source'), e.get('edition')) for e in previous.values()}
    info['new_editions'] = len({(e.get('source'), e.get('edition')) for e in editions if info['documents'].get(e.get('id')) == 'new_editions' and (e.get('source'), e.get('edition')) not in previous_editions})
    keys = {}
    retained = []
    for old in state['records']:
        key = _record_key(old)
        if key in keys:
            previous_row = retained[keys[key]]
            if previous_row['value'] != old['value']:
                raise ValueError('El historial contiene cifras contradictorias para una misma revisión')
            evidence = _record_evidence(previous_row)
            evidence.extend(e for e in _record_evidence(old) if e not in evidence)
            # Conservar el respaldo verificable sobre una referencia sin documento.
            if old.get('document_id') and not previous_row.get('document_id'):
                previous_row = dict(previous_row, **old)
                retained[keys[key]] = previous_row
            if evidence:
                previous_row['evidence'] = evidence
        else:
            keys[key] = len(retained)
            retained.append(old)
    state['records'] = retained
    added = 0
    for item in items:
        if not isinstance(item.get('value'), (int, float)) or not math.isfinite(item['value']):
            raise ValueError('Se rechazó un pronóstico vacío o no finito')
        key = _record_key(item)
        if key in keys:
            old = state['records'][keys[key]]
            if old['value'] != item['value']:
                raise ValueError('Una misma revisión produjo valores diferentes; no se sobrescribe')
            evidence = _record_evidence(old)
            evidence.extend(e for e in _record_evidence(item) if e not in evidence)
            # Una reproducción conserva el vintage y sus evidencias, sin contarse otra vez.
            if old.get('origin') == 'official' and item.get('origin') != 'official':
                # Añadir trazabilidad geométrica sin degradar una verificación HTTP previa.
                if item.get('document_hash') == old.get('document_hash'):
                    for field in ('page', 'bbox', 'revision', 'document_edition', 'document',
                                  'sha256', 'value_text', 'is_current_column'):
                        if field in item and field not in old:
                            old[field] = item[field]
                if evidence:
                    old['evidence'] = evidence
                continue
            updated = dict(old, **item)
            if evidence:
                updated['evidence'] = evidence
            state['records'][keys[key]] = updated
        else:
            keys[key] = len(state['records']); state['records'].append(item); added += 1
    known = {e.get('id'): i for i, e in enumerate(state['editions'])}
    for item in editions:
        if item.get('id') in known:
            old = state['editions'][known[item['id']]]
            if old.get('origin') == 'official' and item.get('origin') == 'document_imported':
                continue
            if item.get('file') or not old.get('file'):
                state['editions'][known[item['id']]] = dict(old, **item)
        else:
            known[item.get('id')] = len(state['editions']); state['editions'].append(item)
    LOCAL.merge_info = info
    return added


def _current_records(state):
    # MEF conserva su cohorte; EEM su cohorte por variable y tres grupos.
    # RI conserva el vintage más reciente de cada variable y año pronosticado.
    cohorts = {}
    weo_order = {e.get('id'): i for i, e in enumerate(state['editions'])
                 if e.get('source') == weo_imf.SOURCE}
    for row in state['records']:
        if row.get('kind') != 'anual':
            continue
        key = (row['source'], row['variable'] if row['source'] == 'BCRP · encuesta anual' else '')
        document = next((e for e in state['editions'] if e.get('id') == row.get('document_id')), {})
        rank = (_edition_key(row), str(row.get('survey_date') or ''),
                bool(row.get('extractor_verified') or document.get('extractor_verified')),
                row.get('origin') == 'official',
                row.get('downloaded_at') or document.get('downloaded_at') or
                row.get('imported_at') or document.get('imported_at') or '',
                bool(row.get('document_id')),
                weo_order.get(row.get('document_id'), -1) if row['source'] == weo_imf.SOURCE else -1)
        if key not in cohorts or rank > cohorts[key][0]:
            cohorts[key] = (rank, row)
    ri_latest = {}
    for row in state['records']:
        if row.get('source') != 'BCRP · Reporte de Inflación' or row.get('kind') != 'anual':
            continue
        key = (row['variable'], str(row['year']))
        rank = (_edition_key(row), bool(row.get('sha256') or row.get('document_hash')),
                bool(row.get('document_id')), row.get('origin') == 'official')
        if key not in ri_latest or rank > ri_latest[key][0]:
            ri_latest[key] = (rank, row)
    result = [pair[1] for pair in ri_latest.values()]
    for row in state['records']:
        if row.get('source') == 'BCRP · Reporte de Inflación':
            continue
        key = (row['source'], row['variable'] if row['source'] == 'BCRP · encuesta anual' else '')
        if key not in cohorts or row.get('kind') != 'anual':
            continue
        anchor = cohorts[key][1]
        if row['edition'] == anchor['edition'] and row.get('document_id', '') == anchor.get('document_id', ''):
            result.append(row)
    return result


def _freshness(state, current):
    confirmations = state.get('confirmations', {})
    result = []
    now = datetime.now(timezone.utc)
    for source, variable in sorted({(r['source'], r['variable']) for r in current}):
        rows = [r for r in current if r['source'] == source and r['variable'] == variable]
        row = max(rows, key=_edition_key)
        confirmed = confirmations.get(source + '|' + variable, {})
        reason = 'No se ha comprobado la última publicación oficial y su documento de respaldo'
        ok = False
        try:
            age = (now-datetime.fromisoformat(confirmed.get('confirmed_at', ''))).total_seconds()
            recent = 0 <= age <= FRESH_SECONDS
        except (ValueError, TypeError):
            recent = False
        if confirmed.get('edition') and _edition_key(confirmed) > _edition_key(row):
            reason = 'Se detectó una edición posterior que todavía no pudo incorporarse'
        elif row.get('origin') != 'official' or not row.get('transport_verified'):
            reason = 'Referencia o documento importado sin cotejo automatizado con la fuente oficial'
        elif not row.get('extractor_verified'):
            reason = 'El lector PDF no ha podido contrastarse con una descarga oficial real de esta estructura'
        elif not row.get('published'):
            reason = 'La fecha de publicación no está acreditada; la fecha de encuesta se conserva por separado'
        elif not recent:
            reason = 'La última comprobación oficial tiene más de 24 horas o no está acreditada'
        elif confirmed.get('document_id') != row.get('document_id') or not confirmed.get('latest_confirmed'):
            reason = 'No se ha confirmado que este documento corresponda a la última publicación'
        else:
            try:
                body, _ = get_document(row['document_id'])
                ok = hashlib.sha256(body).hexdigest() == row.get('document_hash')
                reason = 'Última edición oficial comprobada; respaldo y fecha de publicación disponibles' if ok else 'El respaldo no coincide con su hash'
            except (OSError, ValueError):
                reason = 'El documento de respaldo no está disponible o está alterado'
        result.append({'source': source, 'variable': variable, 'edition': row['edition'],
                       'document_id': row.get('document_id'), 'up_to_date': ok, 'reason': reason})
    return result


def _survey_revisions(state):
    """Historial por fecha, variable, año y encuestado, con tipos normalizados."""
    rows = {}
    def normalized(raw):
        item = dict(raw)
        for field in ('variable', 'year', 'group', 'survey_date'):
            item[field] = str(item.get(field) or '')
        return item
    def key(row):
        return row['variable'], row['year'], row['group'], row['survey_date']
    if BASE_REVISIONS.exists():
        base = json.loads(BASE_REVISIONS.read_text(encoding='utf-8'))
        for raw in base.get('records', []):
            row = normalized(raw)
            rows[key(row)] = row
    for doc in state.get('editions', []):
        if not doc.get('file') or doc.get('source') != 'BCRP · encuesta anual':
            continue
        for raw in doc.get('history', []):
            entry = normalized(raw)
            rows[key(entry)] = dict(entry, file_sha256=doc.get('hash', entry.get('file_sha256')),
                                   document_id=doc.get('id'), origin=doc.get('origin'))
    return sorted(rows.values(), key=key)


def _snapshot_state(state):
    current = _current_records(state)
    return dict(state, latest=current, current_records=current,
                survey_history=_survey_revisions(state), freshness=_freshness(state, current),
                checks=state['checks'][-50:],
                sources={'fmi': weo_imf.PORTAL, 'encuesta': PORTAL_BCRP, 'bcrpdata': 'https://estadisticas.bcrp.gob.pe/estadisticas/series/mensuales/expectativas-macroeconomicas',
                         'reporte': PORTAL_RI, 'mef': MEF_COLLECTION},
                auto_update={'running': bool(AUTO_THREAD and AUTO_THREAD.is_alive()), 'interval_seconds': AUTO_INTERVAL})


def snapshot():
    with LOCK:
        return _snapshot_state(_load())


def _run_source(fn, source):
    LOCAL.events = []; LOCAL.metadata = {}
    try:
        records, editions = fn()
    except Exception as exc:
        records, editions = [], [{'id': 'error-' + getattr(fn, '__name__', source), 'source': source, 'error': str(exc)[:300]}]
    events = list(LOCAL.events)
    _enrich(records, editions, events)
    return records, editions, events


def update(*, include_bcrp=False, scope='mef'):
    """Una consulta a la vez, incluso con varias pestañas del navegador."""
    if not UPDATE_LOCK.acquire(blocking=False):
        raise ValueError('Ya hay una consulta en curso. Intenta nuevamente cuando termine.')
    try:
        return _update_scoped(include_bcrp=include_bcrp, scope=scope)
    finally:
        UPDATE_LOCK.release()


def _update_scoped(*, include_bcrp=False, scope='mef'):
    """Actualiza la fuente indicada sin modificar los modelos financieros."""
    if scope not in ('mef', 'imf', 'all'):
        raise ValueError('Fuente de actualización desconocida')
    records = []; editions = []; events = []
    jobs = ()
    if scope in ('mef','all'):
        jobs += ((_update_mef, 'MEF · MMM/IAPM'),)
    if scope in ('imf','all'):
        jobs += ((_update_weo, weo_imf.SOURCE),)
    if include_bcrp:
        jobs += ((_update_eem_excel, 'BCRP · encuesta anual'),
                 (_update_ri, 'BCRP · Reporte de Inflación'))
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix='iaspe-externas') as pool:
        futures = [pool.submit(_run_source, fn, source) for fn, source in jobs]
        for future in futures:
            part, documents, traces = future.result()
            records.extend(part); editions.extend(documents); events.extend(traces)
    # Respaldo PDF solo si no hay desafío ni datos suficientes; no se usa una
    # nota fija histórica como si fuera la última edición del portal.
    excel_variables = {r['variable'] for r in records if r['source'] == 'BCRP · encuesta anual'}
    blocked = any(e.get('blocked') for e in editions if e.get('source') == 'BCRP · encuesta anual')
    if include_bcrp and len(excel_variables) < 3 and not blocked:
        part, documents, traces = _run_source(_update_eem, 'BCRP · encuesta anual')
        # No sobreescribir una variable obtenida por Excel con otra edición PDF.
        missing = [r for r in part if r['variable'] not in excel_variables]
        records.extend(missing); editions.extend(documents); events.extend(traces)
    # La red puede tardar: no bloquear confirmaciones locales mientras consulta el MEF.
    with LOCK:
        state = _load()
        # Transacción por fuente: un dato inconsistente tampoco aborta las otras.
        added = 0
        merged = {'new_editions': 0, 'revisions': 0, 'repeated': 0, 'documents': {}}
        for source in sorted({e.get('source', '') for e in editions} | {r['source'] for r in records}):
            part = [r for r in records if r['source'] == source]
            documents = [e for e in editions if e.get('source') == source]
            trial = json.loads(json.dumps(state))
            try:
                count = _merge(trial, part, documents)
                stats = LOCAL.merge_info
                state = trial; added += count
                for key in ('new_editions', 'revisions', 'repeated'):
                    merged[key] += stats[key]
                merged['documents'].update(stats['documents'])
            except (ValueError, TypeError, KeyError) as exc:
                records = [r for r in records if r['source'] != source]
                editions = [e for e in editions if e.get('source') != source]
                detected = max(documents, key=_edition_key) if documents else {}
                editions.append({'id': 'integrity-' + source, 'source': source, 'edition': detected.get('edition'),
                                 'error': 'Incorporación rechazada por integridad: ' + str(exc)[:250]})
        confirmed = state.setdefault('confirmations', {})
        for source in {e.get('source') for e in editions}:
            docs = [e for e in editions if e.get('source') == source and _edition_key(e) != (0, 0)]
            if source == 'BCRP · encuesta anual':
                variables = {r['variable'] for r in records if r['source'] == source}
            else:
                variables = {r['variable'] for r in state['records'] if r['source'] == source}
            for variable in variables:
                candidates = [e for e in docs if not e.get('variable') or e['variable'] == variable]
                if not candidates:
                    continue
                latest = max(candidates, key=_edition_key)
                key = source + '|' + variable
                old = confirmed.get(key, {})
                if _edition_key(latest) < _edition_key(old):
                    continue
                confirmed[key] = {'edition': latest.get('edition'), 'document_id': latest.get('id') if latest.get('file') else None,
                                  'confirmed_at': latest.get('checked_at'),
                                  'latest_confirmed': bool(latest.get('transport_verified') and latest.get('rows') and not latest.get('error')
                                                           and (source != weo_imf.SOURCE or latest.get('discovery_verified')))}
        labels = {'BCRP · encuesta anual': 'Encuesta BCRP', 'BCRP · Reporte de Inflación': 'Reporte de Inflación', 'MEF · MMM/IAPM': 'MEF — MMM/IAPM', 'FMI · WEO': 'FMI — WEO'}
        summaries = {}
        for source, label in labels.items():
            docs = [e for e in editions if e.get('source') == source]
            if not docs and source not in [r.get('source') for r in records] and source!='MEF · MMM/IAPM':
                continue
            urls = {e.get('url') for e in docs}
            traces = [event for event in events if event.get('url') in urls]
            summary = {'consulted': sum(bool(x.get('consulted')) for x in traces),
                       'downloaded': sum(bool(e.get('file') and _event_downloaded(e, events)) for e in docs),
                       'incorporated': sum(merged['documents'].get(e.get('id')) == 'new_editions' for e in docs),
                       'repeated': sum(merged['documents'].get(e.get('id')) == 'repeated' for e in docs),
                       'new_data': any(merged['documents'].get(e.get('id')) in ('new_editions', 'revisions') for e in docs),
                       'blocked': any(e.get('blocked') for e in docs), 'errors': [e['error'] for e in docs if e.get('error')],
                       'variables': {}}
            for document in docs:
                if document.get('variable'):
                    summary['variables'][document['variable']] = {'ok': bool(document.get('rows')), 'blocked': bool(document.get('blocked')),
                                                                 'error': document.get('error'), 'edition': document.get('edition')}
            summaries[label] = summary
        failures = [e.get('source', 'Fuente') + ': ' + e['error'] for e in editions if e.get('error')]
        check = {'date': _utc(), 'scope': scope,
                 'status': 'error' if failures else 'updated' if merged['new_editions'] or merged['revisions'] else 'unchanged',
                 'warnings': [warning for e in editions for warning in e.get('warnings', [])],
                 'added': added, 'consulted': sum(bool(e.get('consulted')) for e in events),
                 'downloads': sum(bool(e.get('file') and _event_downloaded(e, events)) for e in editions),
                 'new_editions': merged['new_editions'], 'revisions': merged['revisions'], 'repeated': merged['repeated'],
                 'errors': failures, 'source_summary': summaries, 'http_events': events}
        state['lastCheck'] = check['date']; state['checks'].append(check)
        if scope in ('mef', 'imf'):
            state.setdefault('lastChecks', {})[scope] = check
        state['checks'] = state['checks'][-50:]
        _save(state)
        return dict(snapshot(), updateResult=check)


def _event_downloaded(document, events):
    return any(e.get('url') == document.get('url') and e.get('body_hash') == document.get('hash') and e.get('downloaded') for e in events)


def _identify_pdf_publication(body, filename):
    """La identidad y edición proceden del mismo lector de tablas validado."""
    parsed, _ = _shared_bcrp_pdf(body, filename)
    doc = parsed['document']
    source = ('BCRP · Reporte de Inflación' if doc['type'] == 'inflation_report'
              else 'BCRP · encuesta anual')
    published = doc.get('published') or ''
    precision = 'day' if re.fullmatch(r'20\d{2}-\d{2}-\d{2}', published) else 'month' if published else 'unknown'
    return source, doc['edition'], published, precision, None


def _identify_excel_publication(body, filename):
    """Detecta el único formato BCRP o MEF verificable, sin pedir edición."""
    _validate_xlsx(body)
    from openpyxl import load_workbook
    wb=load_workbook(io.BytesIO(body),read_only=True,data_only=True)
    try:
        header = ' '.join(_text(c) for sh in wb.worksheets[:8] for row in
                          sh.iter_rows(min_row=1,max_row=min(sh.max_row or 1,8),max_col=min(sh.max_column or 1,35),values_only=True)
                          for c in row if isinstance(c,str))
        mef_sheets=[]
        for sh in wb.worksheets[:15]:
            sample=' '.join(_text(c) for row in sh.iter_rows(min_row=1,max_row=min(sh.max_row or 1,8),max_col=min(sh.max_column or 1,30),values_only=True)
                            for c in row if isinstance(c,str))
            if 'principales indicadores macroeconomicos' not in sample:
                continue
            rows=list(sh.iter_rows(max_row=min(sh.max_row or 1,16), max_col=min(sh.max_column or 1,70),values_only=True))
            year_sets=[]
            for row in rows:
                years=sorted({int(v) for v in row if isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and int(v)==v and 2015<=v<=2040})
                if len(years)>=4:year_sets.append(years)
            if len(year_sets)!=1:raise ValueError('La tabla del MEF tiene encabezados de años ambiguos')
            mef_sheets.append(year_sets[0])
        if mef_sheets:
            if len(mef_sheets)!=1:raise ValueError('Se encontraron varias tablas MEF ambiguas')
            years=mef_sheets[0]
            if not (all(b==a+1 for a,b in zip(years,years[1:])) and len(years) in (5,6)):
                raise ValueError('Horizonte de años MEF no reconocido')
            # La primera columna numérica representa el año histórico.
            # MMM tiene histórico + año de edición + cuatro proyecciones;
            # IAPM tiene histórico + cuatro proyecciones.
            if len(years)==6:
                edition=f'MMM {years[2]}–{years[-1]}'
                publication=f'{years[1]}-08'
            else:
                edition=f'IAPM {years[1]}–{years[-1]}'
                publication=f'{years[1]}-04'
            # Mes de calendario habitual (no día exacto acreditado).
            return 'MEF · MMM/IAPM',edition,publication,'month_estimated'
    finally:
        wb.close()
    candidates=[]
    for variable in ('tc_cierre','pbi','inflacion'):
        try:
            history=[]
            rows,edition=_parse_bcrp_excel(body,variable,history_sink=history)
            if rows:candidates.append((variable,edition,rows,history))
        except ValueError:
            pass
    if len(candidates)!=1:
        raise ValueError('No se identificó un único Excel oficial de expectativas BCRP o MEF')
    variable,edition,rows,history=candidates[0]
    return 'BCRP · encuesta anual',edition,'','unknown'


def _analyze_import(source=None, edition='', filename='', encoded='', source_url='', published=''):
    """Importación mínima: PDF/Excel, archivo y URL oficial opcional.

    Conserva compatibilidad con llamadas anteriores. La clasificación y edición
    del archivo SIEMPRE priman sobre campos proporcionados por el navegador.
    """
    if not isinstance(encoded,str) or len(encoded)>15_000_000:
        raise ValueError('El archivo supera el tamaño permitido')
    try:body=base64.b64decode(encoded,validate=True)
    except Exception as exc:raise ValueError('El archivo está codificado incorrectamente') from exc
    if not 0<len(body)<=11_000_000:
        raise ValueError('Archivo vacío o mayor de 11 MB')
    ext=Path(str(filename)).suffix.lower()
    if ext not in ('.pdf','.xlsx'):
        raise ValueError('Selecciona un PDF o Excel (.xlsx)')
    parsed_pdf = None
    if ext=='.pdf':
        parsed_pdf, _ = _shared_bcrp_pdf(body, str(filename))
        metadata = parsed_pdf['document']
        detected_source = ('BCRP · Reporte de Inflación' if metadata['type'] == 'inflation_report'
                           else 'BCRP · encuesta anual')
        detected_edition = metadata['edition']
        detected_published = metadata.get('published') or ''
        precision = ('day' if re.fullmatch(r'20\d{2}-\d{2}-\d{2}', detected_published)
                     else 'month' if detected_published else 'unknown')
        document_text = None
    else:
        detected_source,detected_edition,detected_published,precision=_identify_excel_publication(body,filename)
        document_text=None
    # Un campo heredado no puede forzar la clasificación hacia otra institución.
    if source and source!='auto' and source!=detected_source:
        raise ValueError('El documento no corresponde a la publicación seleccionada')
    if edition and str(edition).strip()!=detected_edition:
        equivalent_ri = (detected_source == 'BCRP · Reporte de Inflación'
                         and _edition_key({'edition': str(edition)}) == _edition_key({'edition': detected_edition})
                         and _edition_key({'edition': detected_edition}) != (0, 0))
        if not equivalent_ri:
            raise ValueError('La edición indicada no coincide con la que aparece en el archivo')
    if published and detected_published:
        declared=str(published)
        # Compatibilidad histórica: una fecha con día puede corresponder al mes
        # identificado por el libro MEF. No convierte un día declarado en verificado.
        compatible=(declared==detected_published or
                    (precision in ('month','month_estimated') and
                     declared.startswith(detected_published+'-')))
        if not compatible:
            raise ValueError('La fecha indicada no coincide con la que figura en el documento')
    if not detected_published and published:
        try:
            candidate=date.fromisoformat(str(published))
            if candidate>date.today():raise ValueError('Fecha futura')
            detected_published=candidate.isoformat();precision='day_declared'
        except (ValueError,TypeError) as exc:raise ValueError('La fecha indicada no es válida') from exc
    if source_url:
        if not _url_valid(source_url):raise ValueError('El enlace debe pertenecer al sitio oficial del BCRP o MEF y usar HTTPS')
        host=urlparse(source_url).hostname or ''
        expected={'www.bcrp.gob.pe','bcrp.gob.pe','estadisticas.bcrp.gob.pe'} if detected_source.startswith('BCRP') else {'www.mef.gob.pe','mef.gob.pe','cdn.www.gob.pe','www.gob.pe'}
        if host not in expected:raise ValueError('El enlace no corresponde a la institución del archivo')
    # Sin enlace, guardar la página de publicación como REFERENCIA, no como URL
    # del documento que no ha sido verificada en red.
    reference=source_url or {'BCRP · encuesta anual':PORTAL_BCRP,'BCRP · Reporte de Inflación':PORTAL_RI,'MEF · MMM/IAPM':PORTAL_MEF}[detected_source]
    history=[]
    if detected_source=='BCRP · encuesta anual' and ext=='.xlsx':
        for variable in ('tc_cierre','pbi','inflacion'):
            try:
                trial=[]
                records,check=_parse_bcrp_excel(body,variable,reference,history_sink=trial)
                if check==detected_edition:
                    history=trial;break
            except ValueError:continue
        else:raise ValueError('No se pudo extraer la encuesta completa del Excel')
    elif parsed_pdf is not None:
        from bcrp_documents import dashboard_records
        records = dashboard_records(parsed_pdf, url=reference)
        history = parsed_pdf['records']

    else:
        records=_parse_mef_xlsx(body,detected_edition,detected_published,reference)
    if not records:raise ValueError('El documento no contiene pronósticos anuales verificables')
    sha = hashlib.sha256(body).hexdigest()
    namespace = 'MEF' if detected_source.startswith('MEF') else 'BCRP'
    ident = hashlib.sha1(f'{namespace}/{detected_edition}/{sha}'.encode()).hexdigest()[:20]
    stored = ident + ext
    imported_at=_utc()
    for row in records:
        row.update(document_id=ident,document_hash=sha,origin='document_imported',
                   published=detected_published or None,published_precision=precision,
                   institution='MEF' if detected_source.startswith('MEF') else 'BCRP',
                   url=reference,imported_at=imported_at,downloaded_at=None,
                   transport_verified=False,extractor_verified=bool(parsed_pdf),
                   publication_status='Metadatos detectados en el documento; enlace oficial declarado' if source_url else
                   'Metadatos detectados en el documento; enlace institucional de referencia')
    document={'id':ident,'source':detected_source,'edition':detected_edition,
              'title':str(filename)[:120],'published':detected_published or None,
              'published_precision':precision,'url':reference,'url_is_document':bool(source_url),
              'hash':sha,'file':stored,'kind':ext[1:], 'rows':len(records),
              'origin':'document_imported','imported_at':imported_at,
              'downloaded_at':None,'transport_verified':False,
              'extractor_verified': bool(parsed_pdf),
              'parser': parsed_pdf.get('parser') if parsed_pdf else None}
    if history:
        document['history']=[dict(row,file_sha256=sha) for row in history]
    variables={r['variable'] for r in records}
    if len(variables)==1:document['variable']=next(iter(variables))
    return {'body': body, 'records': records, 'document': document, 'stored': stored,
            'ident': ident, 'imported_at': imported_at, 'detected_source': detected_source,
            'detected_edition': detected_edition, 'detected_published': detected_published, 'source_url': source_url}


def _commit_analyzed_import(prepared):
    body = prepared['body']
    sha = prepared['document']['hash']
    records = prepared['records']
    document = prepared['document']
    stored = prepared['stored']
    ident = prepared['ident']
    detected_source = prepared['detected_source']
    detected_edition = prepared['detected_edition']
    detected_published = prepared['detected_published']
    source_url = prepared['source_url']
    imported_at = prepared['imported_at']
    namespace = 'MEF' if detected_source.startswith('MEF') else 'BCRP'
    with LOCK:
        state = _load()
        # Compatibilidad con respaldos previamente importados en esta misma edición.
        old_document = next((item for item in state['editions']
                             if item.get('hash') == sha
                             and (item.get('edition') == detected_edition or
                                  (detected_source == 'BCRP · Reporte de Inflación' and
                                   _edition_key(item) == _edition_key({'edition': detected_edition})))
                             and item.get('source', '').startswith(namespace) and item.get('file')), None)
        if old_document:
            candidate = (DOCS / old_document['file']).resolve()
            if not candidate.is_relative_to(DOCS.resolve()):
                raise ValueError('Ruta de respaldo fuera del directorio permitido')
            ident, stored = old_document['id'], old_document['file']
            document.update(id=ident, file=stored)
            for row in records:
                row['document_id'] = ident
        added = _merge(state,records,[document])
        state.setdefault('imports',[]).append({'imported_at':imported_at,'document_id':ident,
                     'source_url':source_url or None,'published_detected':detected_published or None,
                     'added':added})
        state['imports']=state['imports'][-100:]
        response = {'added': added, 'document': document, 'state': _snapshot_state(state)}
        # Serializar y validar toda la respuesta antes de publicar documento o registros.
        json.dumps(response, ensure_ascii=False, allow_nan=False)
        _commit_import(body, stored, state)
    return response



def import_document(source=None, edition='', filename='', encoded='', source_url='', published=''):
    """Compatibilidad con importación directa de utilitarios internos; la UI usa preview/confirm."""
    prepared = _analyze_import(source, edition, filename, encoded, source_url, published)
    return _commit_analyzed_import(prepared)


def _preview_fingerprint(state):
    """Cambios en series oficiales invalidan una previsualización; simples consultas HTTP, no."""
    content = {'records': state['records'], 'editions': state['editions']}
    return hashlib.sha256(json.dumps(content, sort_keys=True, ensure_ascii=False,
                                      separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _preview_rows(state, records):
    current = {(r['source'], r['variable'], r.get('group', ''), str(r['year'])): r
               for r in _current_records(state) if r.get('kind') == 'anual'}
    report = []
    for item in sorted(records, key=lambda r: (r['variable'], r.get('group', ''), str(r['year']))):
        prior = current.get((item['source'], item['variable'], item.get('group', ''), str(item['year'])))
        before = prior.get('value') if prior else None
        older = bool(prior and _edition_key(prior) > _edition_key(item))
        changed = before is None or not math.isclose(float(before), float(item['value']), rel_tol=0, abs_tol=1e-9)
        status = 'anterior' if older else ('nuevo' if before is None else ('cambio' if changed else 'igual'))
        report.append({'variable': item['variable'], 'source': item['source'],
                       'group': item.get('group', ''), 'year': str(item['year']),
                       'unit': item.get('unit', ''), 'before': before,
                       'after': item['value'], 'status': status,
                       'will_update': not older and (changed or str(prior.get('edition')) != str(item['edition']) if prior else True)})
    return report


def preview_document(source=None, filename='', encoded=''):
    """Analiza y compara, sin modificar archivos, pronósticos ni consultar sitios externos."""
    prepared = _analyze_import(source=source, filename=filename, encoded=encoded)
    with LOCK:
        state = _load()
        # La misma validación del guardado detecta incompatibilidades antes de crear un token.
        trial = json.loads(json.dumps(state))
        _merge(trial, prepared['records'], [prepared['document']])
        rows = _preview_rows(state, prepared['records'])
        now = time.monotonic()
        for key in list(PREVIEWS):
            if PREVIEWS[key]['expires'] <= now:
                del PREVIEWS[key]
        while len(PREVIEWS) >= PREVIEW_LIMIT:
            PREVIEWS.pop(next(iter(PREVIEWS)))
        token = secrets.token_urlsafe(32)
        PREVIEWS[token] = {'prepared': prepared, 'fingerprint': _preview_fingerprint(state),
                           'expires': now + PREVIEW_TTL_SECONDS}
    return {'token': token, 'document': {k: prepared['document'].get(k) for k in
            ('source', 'edition', 'title', 'published', 'kind', 'hash', 'rows')},
            'records': rows, 'history_count': len(prepared['document'].get('history', [])),
            'changes': sum(r['will_update'] for r in rows),
            'current': sum(r['status'] != 'anterior' for r in rows),
            'expires_in_minutes': PREVIEW_TTL_SECONDS // 60}


def confirm_document(token):
    """Confirmación explícita con protección frente a ediciones concurrentes."""
    if not isinstance(token, str) or len(token) < 32:
        raise ValueError('Previsualización inválida. Selecciona el documento de nuevo.')
    with LOCK:
        entry = PREVIEWS.get(token)
        if not entry or entry['expires'] <= time.monotonic():
            PREVIEWS.pop(token, None)
            raise ValueError('La previsualización caducó. Vuelve a revisar el documento.')
        if _preview_fingerprint(_load()) != entry['fingerprint']:
            PREVIEWS.pop(token, None)
            raise ValueError('Los datos cambiaron desde la previsualización. Vuelve a revisar antes de confirmar.')
        response = _commit_analyzed_import(entry['prepared'])
        PREVIEWS.pop(token, None)
        return response


def _commit_import(body, filename, state):
    """Publicación indivisible ante errores de escritura; no deja registros parciales."""
    DOCS.mkdir(parents=True, exist_ok=True)
    target = (DOCS / filename).resolve()
    if not target.is_relative_to(DOCS.resolve()):
        raise ValueError('Ruta de respaldo inválida')
    prior_document = target.read_bytes() if target.exists() else None
    prior_state = STATE.read_bytes() if STATE.exists() else None
    staged = target.with_name(target.name + f'.{threading.get_ident()}.tmp')
    state_tmp = STATE.with_name(STATE.name + '.tmp')
    try:
        staged.write_bytes(body)
        if hashlib.sha256(staged.read_bytes()).digest() != hashlib.sha256(body).digest():
            raise OSError('El documento temporal no supera la verificación SHA-256')
        os.replace(staged, target)
        _save(state)
    except Exception:
        # Incluso si una escritura falló después de reemplazar el historial, se revierte.
        if prior_document is None:
            target.unlink(missing_ok=True)
        else:
            staged.write_bytes(prior_document)
            os.replace(staged, target)
        if prior_state is None:
            STATE.unlink(missing_ok=True)
        else:
            state_tmp.write_bytes(prior_state)
            os.replace(state_tmp, STATE)
        raise
    finally:
        staged.unlink(missing_ok=True)
        state_tmp.unlink(missing_ok=True)



def get_document(docid):
    with LOCK:
        state = _load()
        item = next((e for e in state['editions'] if e.get('id') == docid and e.get('file')), None)
        if item is None:
            raise ValueError('Documento no encontrado')
        path = (DOCS / item['file']).resolve()
        if not path.is_relative_to(DOCS.resolve()) or not path.is_file():
            raise ValueError('Documento no disponible')
        body = path.read_bytes()
        if hashlib.sha256(body).hexdigest() != item.get('hash'):
            raise ValueError('El hash del documento no coincide; no se entrega un respaldo alterado')
        return body, path.name


AUTO_INTERVAL = 21600
AUTO_STOP = threading.Event()
AUTO_THREAD = None


def start_auto_update():
    """Un comprobador en el servidor existente; no crea servicios paralelos."""
    global AUTO_THREAD
    if AUTO_THREAD and AUTO_THREAD.is_alive():
        return
    AUTO_STOP.clear()
    def run():
        if AUTO_STOP.wait(3):
            return
        while not AUTO_STOP.is_set():
            try:
                last = _load().get('lastCheck')
                due = not last or (datetime.now(timezone.utc)-datetime.fromisoformat(last)).total_seconds() >= AUTO_INTERVAL
                if due:
                    update()
            except Exception as exc:
                # Base dañada o fallo de almacenamiento: registrar, jamás vaciarla.
                print(f'IASPE fuentes externas: {type(exc).__name__}: {exc}', flush=True)
            AUTO_STOP.wait(60)
    AUTO_THREAD = threading.Thread(target=run, name='iaspe-publicaciones-externas', daemon=True)
    AUTO_THREAD.start()


def stop_auto_update():
    AUTO_STOP.set()
