"""Escenarios IASC 2026-2028; sin extrapolación de inputs.

Referencias: IASC pp.23, 33-34 y 42-43. Sólo utiliza cifras declaradas.
"""
from __future__ import annotations
from pathlib import Path
import json,copy

FILE=Path(__file__).resolve().parent/'data'/'iasc_escenarios_2026_2028.json'

def plan():
    return json.loads(FILE.read_text(encoding='utf-8'))

def identify(changes):
    if not isinstance(changes,dict) or not changes:
        return None
    source=plan()
    valid={k:v for k,v in changes.items() if not str(k).startswith('__')}
    for label in ('estres','estres_severo'):
        expected=source[label]['macro']
        if set(valid)!=set(expected):
            continue
        if all(set(valid[k])==set(expected[k]) and all(abs(float(valid[k][y])-float(v))<1e-9 for y,v in expected[k].items()) for k in expected):
            return label
    return None

def observations_for(label, base_models, original_observations):
    """Carga la provisión IASC tal como se publica para cada escenario SBS.

    La tabla IASC denomina la partida «Provisiones para incobrabilidad
    de créditos». Se toma como supuesto de gestión del Banco, sin deducir
    recuperaciones, sin fórmulas de conversión ni extrapolación. El Base
    IASPE original (M25, serie histórica neta) permanece independiente.
    """
    source = plan()
    if label not in ('base','estres','estres_severo'):
        raise ValueError('Escenario IASC desconocido')
    obs = copy.deepcopy(original_observations)
    obs.setdefault('25', {}).update({str(y): float(source[label]['provisiones_gasto_reportado_iasc'][str(y)])
                                     for y in (2026,2027,2028)})
    return obs

def input_stock(label):
    return dict(plan()[label]['provisiones_stock'])
