/* Control de cierres provisionales de 2026; no altera observaciones ni modelos. */
(()=>{
'use strict';
const $=selector=>document.querySelector(selector);
const MONTHS=['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
// Entradas y cuentas directamente actualizadas. Se excluyen saldos derivados,
// impuestos, provisiones y auxiliares cuyo 2026 no depende del corte SBS/BCRP.
const TRACKED=new Set(['01','02','03','04','05','06','08','09','10','12','13','14','15','16','17','18','19','20','21','22','24','30','32']);
const state={query:'',group:'all',modal:null};
let app,data,pending,request=0;
const finite=n=>typeof n==='number'&&Number.isFinite(n);
const escape=value=>app.escape(String(value??''));
const num=(value,unit='')=>finite(value)?app.fmt(value,/tarjetas|personas|oficinas/i.test(unit)?0:2):'—';
const fmtPeriod=v=>v?String(v):'—';
const date=v=>{const d=new Date(v);return v&&!isNaN(d.getTime())?d.toLocaleString('es-PE',{timeZone:'America/Lima',day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}):'—';};
const monthNum=p=>/^2026-(0[1-9]|1[0-2])$/.test(p||'')?Number(p.slice(5)):null;
const lastMonth=model=>monthNum(model.lastIncorporatedPeriod||model.lastObservedPeriod);
const closing=model=>model.closing2026||{};
function monitored(model){return TRACKED.has(model.id)&&!model.isComponent&&lastMonth(model)!==null&&closing(model).status==='estimated'&&finite(closing(model).value);}
function family(model){return ['01','02','03','13','14','15'].includes(model.id)?'mercado':'falabella';}
function synopsis(model){
 const k=model.id,raw=String(closing(model).method||'');
 if(k==='01')return 'Promedio geométrico de las variaciones interanuales de los meses observados de 2026, aplicado a los mismos meses de 2025 para completar el cierre.';
 if(['04','05'].includes(k))return 'Promedio aritmético de las variaciones interanuales de los meses observados de 2026, aplicado a los mismos meses de 2025 para completar el cierre.';
 if(k==='03')return 'Meses faltantes imputados con el patrón del modelo de compras; se sustituyen cuando llega el dato.';
 if(['13','14','15'].includes(k))return 'Se mantiene la última tasa observada como cierre provisional hasta diciembre.';
 if(['08','09','10','17','21','22'].includes(k))return 'Se toma el último saldo SBS observado como stock provisional de diciembre.';
 if(k==='30')return 'Último saldo observado + media de las diferencias diciembre/septiembre de 2021–2025.';
 if(k==='32')return 'Último saldo observado + mediana histórica de las diferencias diciembre/mes de corte.';
 if(['12','16'].includes(k))return 'Acumulado observado + flujo estimado de los meses restantes.';
 if(['18','19','20'].includes(k))return 'Proporción interanual acumulada aplicada al cierre de 2026.';
 if(k==='24')return 'Mediana histórica de la relación diciembre / mes observado (2022–2025).';
 if(k==='06')return 'Cierre anual actualizado por crecimiento interanual; no existe una senda mensual.';
 if(k==='02')return 'Cierre anual provisional según los insumos disponibles; sin desglose mensual.';
 return raw||'No se documentó una regla de cierre independiente.';
}
function monthsToClose(model){const end=lastMonth(model)||12;return end<12?`${MONTHS[end]}–Dic · ${12-end} ${12-end===1?'mes':'meses'}`:'Cierre observado';}
// La tabla y la proyección leen el histórico del mismo snapshot que los meses 2026.
// El fallback conserva compatibilidad con versiones anteriores del endpoint.
function geometricGrowth(model,observed){
 if(model.id!=='01')return null;
 const source=Array.isArray(model.monthly2025)?model.monthly2025:(app.model?.('01')?.monthly||[]);
 const history=new Map(source.map(row=>[String(row.period||row.date||'').slice(0,7),row]));
 const matched=[];
 for(let i=1;i<=12;i++){
  const month=String(i).padStart(2,'0'),now=observed.get(`2026-${month}`),prior=history.get(`2025-${month}`);
  if(now?.status==='observed'&&finite(now.value)&&finite(prior?.value)&&prior.value>0&&now.value>0){
   matched.push({month:i,now:now.value,prior:prior.value,ratio:now.value/prior.value});
  }
 }
 // La misma regla del motor requiere al menos 7 pares observados.
 if(matched.length<7)return null;
 const factor=Math.exp(matched.reduce((sum,row)=>sum+Math.log(row.ratio),0)/matched.length);
 return {history,factor,count:matched.length,matched};
}
function seriesMonths(model){
 const observed=new Map((model.monthly2026||[]).map(row=>[String(row.period),{...row}]));
 // Los meses sin dato del M01 se reconstruyen solo para consulta, sin modificar el motor.
 const growth=geometricGrowth(model,observed);
 if(growth){
  for(let i=1;i<=12;i++){
   const key=`2026-${String(i).padStart(2,'0')}`;
   // Solo se estiman meses futuros, nunca vacíos dentro de la historia observada.
   if(i<=(lastMonth(model)||0)||observed.has(key)&&observed.get(key)?.status!=='missing')continue;
   const prior=growth.history.get(`2025-${String(i).padStart(2,'0')}`);
   if(finite(prior?.value))observed.set(key,{period:key,value:Math.round(prior.value*growth.factor),status:'estimated',displayOnly:true});
  }
 }
 return Array.from({length:12},(_,i)=>{
  const p=`2026-${String(i+1).padStart(2,'0')}`;
  if(observed.has(p)&&observed.get(p)?.status!=='missing')return observed.get(p);
  const end=lastMonth(model),isFuture=i+1>(end||0);
  // En series anuales no existe una imputación por mes: mostrar el cierre solo
  // en diciembre. Nunca repartir el total entre octubre y noviembre.
  if(!Array.isArray(model.monthly2026))return {period:p,status:isFuture?'annual_only':'unreported',value:isFuture&&i===11?closing(model).value:null,annualClose:isFuture&&i===11};
  return {period:p,status:'missing',value:null};
 });
}
// Todas las reglas de cierre usan ejemplos tabulados. El detalle nunca inventa
// desagregaciones que el motor no conserva, ni modifica la estimación persistida.
function tableExample(columns,rows,foot=''){
 const head=columns.map(x=>`<th scope="col">${escape(x)}</th>`).join('');
 const body=rows.map(row=>`<tr class="${row.emphasis?'ma-example-estimated':''}">${row.cells.map((cell,i)=>`<${i?'td':'th scope="row"'}>${escape(cell)}</${i?'td':'th'}>`).join('')}</tr>`).join('');
 return `<div class="ma-example-scroll"><table class="ma-example-table ${columns[0]==='Componente'?'ma-table-components':''}"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>${foot?`<small>${foot}</small>`:''}`;
}
function exampleBlock(body){return `<details class="ma-example"><summary>Ver ejemplo de cálculo</summary><div class="ma-example-body">${body}</div></details>`;}
function history2025(model){const source=Array.isArray(model.monthly2025)?model.monthly2025:(app.model?.(model.id)?.monthly||[]);return new Map(source.map(row=>[String(row.period||row.date||'').slice(0,7),row]));}
function yoyExample(model,monthRows){
 const past=history2025(model),observed=[];
 for(const row of monthRows){
  const prior=past.get('2025-'+String(row.period).slice(5));
  if(row.status==='observed'&&finite(row.value)&&finite(prior?.value)&&prior.value>0&&row.value>0){
   observed.push({period:row.period,current:row.value,prior:prior.value,ratio:row.value/prior.value});
  }
 }
 if(observed.length===0)return null;
 const geometric=model.id==='01';
 const factor=geometric?Math.exp(observed.reduce((a,b)=>a+Math.log(b.ratio),0)/observed.length):observed.reduce((a,b)=>a+b.ratio,0)/observed.length;
 const decimals=/tarjetas|personas/i.test(model.unit||'')?0:2;
 const rows=[];
 for(let i=1;i<=12;i++){
  const month=`${String(i).padStart(2,'0')}`;
  const prior=past.get(`2025-${month}`),row=monthRows[i-1];
  if(!finite(prior?.value)||!row)continue;
  const isObserved=row.status==='observed',hasPersisted=row.status==='estimated'&&finite(row.value);
  const isEstimated=!isObserved&&(hasPersisted||i>(lastMonth(model)||0));
  const current=isObserved||hasPersisted?row.value:isEstimated?prior.value*factor:null;
  if(!finite(current))continue;
  const shown=model.id==='01'&&isEstimated?Math.round(prior.value*factor):current;
  rows.push({emphasis:isEstimated,cells:[MONTHS[i-1],num(prior.value,model.unit),num(shown,model.unit),`${app.fmt((isObserved?current/prior.value:factor)-1,4).replace(/^/, '')}`,isObserved?'Observado':'Estimado']});
  rows[rows.length-1].cells[3]=`${app.fmt(((isObserved?current/prior.value:factor)-1)*100,2)}%`;
 }
 const last=rows[rows.length-1],actualClose=last&&finite(model.closing2026?.value)?Number(model.closing2026.value):null;
 const december=rows.find(x=>x.cells[0]==='Dic');
 const calcClose=finite(past.get('2025-12')?.value)?past.get('2025-12').value*factor:null;
 const same=finite(calcClose)&&finite(actualClose)&&(Math.abs(actualClose-(decimals===0?Math.round(calcClose):calcClose))<=(decimals===0?1:0.02));
 const detail=`${observed.length} meses observados. promedio ${geometric?'geométrico':'aritmético'} de los cambios interanuales equivalente a <strong>${escape(app.fmt((factor-1)*100,4))}%</strong>.`;
 const check=same?'El cierre calculado coincide con el valor guardado en el modelo.':'El cierre de la tabla procede del modelo persistido; revisar cualquier diferencia frente al factor mostrado antes de actualizar.';
 const labels=model.id==='01'?['Mes','Tarjetas 2025','Tarjetas 2026','Variación interanual','Condición 2026']:['Mes',`Dato 2025`,`Dato 2026`,'Variación interanual','Condición 2026'];
 return exampleBlock(`<p>${detail}</p>${tableExample(labels,rows,`Para los meses faltantes se aplica el factor calculado al mismo mes de 2025. ${check}`)}`);
}
function flowExample(model,monthRows){
 const rows=[];let total=0,observedSum=0,estimatedSum=0;
 for(let i=0;i<12;i++){
  const row=monthRows[i];if(!row||!finite(row.value))continue;
  const obs=row.status==='observed';total+=row.value;
  if(obs)observedSum+=row.value;else estimatedSum+=row.value;
  rows.push({emphasis:!obs,cells:[MONTHS[i],num(row.value,model.unit),obs?'Observado':'Estimado']});
 }
 if(!rows.length)return null;
 rows.push({emphasis:true,cells:['Total anual',num(total,model.unit),'Suma de los 12 meses']});
 const matches=Math.abs(total-model.closing2026.value)<=0.02;
 return exampleBlock(tableExample(['Mes','Compras del mes','Condición'],rows,`Total observado ${escape(num(observedSum,model.unit))}; total estimado ${escape(num(estimatedSum,model.unit))}. ${matches?'El total coincide con el cierre anual guardado.':'Atención. El total de meses no coincide con el cierre anual guardado.'}`));
}
function carryExample(model,monthRows){
 const obs=monthRows.filter(r=>r.status==='observed'&&finite(r.value));
 const last=obs[obs.length-1];if(!last)return null;
 const rows=[{cells:[`${MONTHS[Number(last.period.slice(5))-1]} 2026`,num(last.value,model.unit),'Observado']}];
 for(const r of monthRows){
  if(r.period>last.period&&finite(r.value))rows.push({emphasis:true,cells:[`${MONTHS[Number(r.period.slice(5))-1]} 2026`,num(r.value,model.unit),'Estimado, último dato observado']});
 }
 rows.push({emphasis:true,cells:['Cierre 2026',num(model.closing2026.value,model.unit),'Cierre provisional']});
 return exampleBlock(tableExample(['Periodo','Tasa o valor','Condición'],rows,'El último dato mensual observado se mantiene como supuesto hasta conocer diciembre.'));
}
function componentExample(model){
 const items=model.components2026||[];if(!items.length)return null;
 let total=0;
 const rows=items.map(x=>{
  const value=x.value*(x.sign||1);total+=value;
  return {cells:[x.name,(x.sign||1)<0?'Se resta':'Se suma',num(value,model.unit)]};
 });
 rows.push({emphasis:true,cells:['Cierre 2026','Total',num(model.closing2026.value,model.unit)]});
 const agrees=Math.abs(total-model.closing2026.value)<0.021;
 const note=`${agrees?'Las partidas concilian con el cierre guardado.':'Atención. Las partidas no concilian con el cierre guardado.'} Las partidas ya incorporan sus respectivos supuestos de cierre.`;
 return exampleBlock(tableExample(['Componente','Operación','Aporte al cierre'],rows,note));
}
function tracedExample(model){
 const t=model.closingTrace;if(!t)return null;
 const closing=num(model.closing2026.value,model.unit),label=MONTHS[Number(t.sourceMonth.slice(5))-1];
 if(t.kind==='last_flow'){
  const rows=[
   {cells:[`Acumulado a ${MONTHS[Number(t.sourceMonth.slice(5))-2]} 2026`,num(t.previous,model.unit),'Dato SBS']},
   {cells:[`Acumulado a ${label} 2026`,num(t.current,model.unit),'Dato SBS']},
   {cells:[`Flujo exclusivo de ${label}`,num(t.monthlyFlow,model.unit),'Acumulado actual menos anterior']},
   {cells:['Meses pendientes',String(t.remaining),'Hasta diciembre']},
   {cells:['Intereses de meses pendientes',num(t.adjustment,model.unit),'Flujo mensual por meses pendientes']},
   {emphasis:true,cells:['Cierre 2026',closing,'Acumulado más meses pendientes']},
  ];
  return exampleBlock(tableExample(['Paso','Importe','Cómo se obtiene'],rows,'Esta regla supone que el último flujo mensual observado se repite en los meses faltantes.'));
 }
 if(t.kind==='median_factor'){
  const rows=t.history.map(item=>({cells:[String(item.year),num(item.comparable,model.unit),num(item.december,model.unit),`${app.fmt(item.stat,4)}`]}));
  rows.push({cells:['Mediana histórica','—','—',app.fmt(t.statistic,4)]});
  rows.push({cells:[`${label} 2026`,num(t.current,model.unit),'Dato SBS','—']});
  rows.push({emphasis:true,cells:['Cierre 2026',closing,'Estimado','Dato del mes por mediana']});
  return exampleBlock(tableExample(['Año','Acumulado al corte','Acumulado diciembre','Factor cierre'],rows,'Cada factor es el acumulado de diciembre dividido entre el acumulado del mismo mes. Se aplica la mediana histórica al acumulado de 2026.'));
 }
 const rows=t.history.map(item=>({cells:[String(item.year),num(item.comparable,model.unit),num(item.december,model.unit),num(item.stat,model.unit)]}));
 rows.push({cells:[t.kind==='mean_difference'?'Promedio histórico':'Mediana histórica','—','—',num(t.statistic,model.unit)]});
 rows.push({cells:[`${label} 2026`,num(t.current,model.unit),'Dato SBS','—']});
 rows.push({emphasis:true,cells:['Cierre 2026',closing,'Estimado','Saldo al corte más ajuste']});
 return exampleBlock(tableExample(['Año','Saldo al corte','Saldo en diciembre','Diferencia'],rows,`El ajuste corresponde a la ${t.kind==='mean_difference'?'media':'mediana'} de las diferencias diciembre menos mes de corte de los cinco años anteriores.`));
}
function annualExample(model){
 const close=model.closing2026,prev=model.annual2025;
 const rows=[];
 if(finite(prev?.value))rows.push({cells:['Diciembre 2025',num(prev.value,model.unit),'Observado']});
 if(finite(close.value))rows.push({emphasis:true,cells:['Diciembre 2026',num(close.value,model.unit),'Supuesto del modelo']});
 if(finite(prev?.value)&&finite(close.value)&&prev.value!==0){
  rows.push({cells:['Variación 2026 frente a 2025',`${app.fmt((close.value/prev.value-1)*100,2)}%`,'Comparación, no fórmula de cierre']});
 }
 const source=close.sourceMonth?`Corte de insumos ${escape(close.sourceMonth)}. `:'';
 const explanation=escape(close.method||synopsis(model));
 return exampleBlock(tableExample(['Periodo','Valor','Condición'],rows,`${source}${explanation}. Este modelo no guarda todos los insumos de su regla de cierre en el monitor; la comparación anual no sustituye esa regla.`));
}
function exampleFor(model,monthRows){
 if(!finite(model.closing2026?.value))return '';
 if(['01','04','05'].includes(model.id)){
  const table=yoyExample(model,monthRows);if(table)return table;
 }
 if(model.id==='03'){
  const table=flowExample(model,monthRows);if(table)return table;
 }
 if(['13','14','15'].includes(model.id)){
  const table=carryExample(model,monthRows);if(table)return table;
 }
 if(['12','16','24','30','32'].includes(model.id)){
  const table=tracedExample(model);if(table)return table;
 }
 if(['08','09','10','12','16','17','18','19','20','21','22'].includes(model.id)&&(model.components2026||[]).length){
  const table=componentExample(model);if(table)return table;
 }
 return annualExample(model);
}

function monthPanel(model){
 const monthRows=seriesMonths(model),c=closing(model),hasMonthly=Array.isArray(model.monthly2026);
 const cards=monthRows.map((row,i)=>{
  const status=row.status==='observed'?'observed':row.status==='annual_only'?'annual_only':row.status==='estimated'?'estimated':row.status==='unreported'?'unreported':'missing';
  const label=row.status==='observed'?'Observado':row.displayOnly?'Estimado':status==='estimated'?'Estimado':row.annualClose?'Cierre anual':status==='annual_only'?'Sin reparto mensual':status==='unreported'?'Sin serie mensual':'Sin dato';
  return `<div class="ma-month ${status}" data-month="${row.period}" data-kind="${row.displayOnly?'reconstructed':status}"><b>${MONTHS[i]}</b><strong>${escape(num(row.value,model.unit))}</strong><span>${escape(label)}</span></div>`;
 }).join('');
 return `<div class="ma-modal-head"><div><small>${escape(model.id)} · ${family(model)==='mercado'?'Mercado':'Banco Falabella'}</small><h2 id="ma-dialog-title">${escape(model.name)}</h2><span>Último observado: ${escape(fmtPeriod(model.lastIncorporatedPeriod||model.lastObservedPeriod))}</span></div><button id="ma-modal-close" type="button" aria-label="Cerrar detalle"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5L19 19M19 5L5 19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button></div>
 <div class="ma-dialog-method"><b>Regla de cierre 2026</b><p>${escape(synopsis(model))}</p>${exampleFor(model,monthRows)}</div>
 <div class="ma-months">${cards}</div>
 <div class="ma-month-legend"><span><i class="observed"></i>Observado SBS/BCRP</span><span><i class="estimated"></i>Estimado</span><span><i class="reconstructed"></i>Estimado mediante regla</span><span><i class="annual_only"></i>Sin serie mensual</span></div>
 <div class="ma-dialog-footer"><div><small>Cierre supuesto a diciembre de 2026</small><strong>${escape(num(c.value,model.unit))}</strong><span>${escape(model.unit||'')}</span></div><small>${hasMonthly?'Los meses estimados se distinguen de los datos observados.':'El motor guarda un cierre anual, no valores mensuales para cada mes. No se han inventado importes de octubre o noviembre.'}</small></div>`;
}
function filtered(models){
 const query=state.query.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
 return models.filter(m=>(state.group==='all'||family(m)===state.group)&&(!query||`${m.id} ${m.name}`.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(query)));
}
function rows(models){
 return models.map(model=>{
  const months=seriesMonths(model),obs=months.filter(x=>x.status==='observed').length,ass=months.filter(x=>x.status==='estimated').length;
  const last=fmtPeriod(model.lastIncorporatedPeriod||model.lastObservedPeriod);
  return `<tr><th scope="row"><span class="ma-id">${escape(model.id)}</span> ${escape(model.name)}</th><td><b>${escape(last)}</b><small>${obs?obs+' meses observados':'Corte de insumos SBS'}</small></td><td><strong>${escape(num(closing(model).value,model.unit))}</strong><small>${escape(model.unit||'')}</small></td><td><span>${escape(synopsis(model))}</span></td><td><b>${escape(monthsToClose(model))}</b><small>${ass?ass+' meses estimados':model.monthly2026?'Sin imputación registrada':'Cierre anual'}</small></td><td><button type="button" class="ma-detail-button" data-monitor-model="${escape(model.id)}">Ver meses <span aria-hidden="true">↗</span></button></td></tr>`;
 }).join('');
}
function showModal(id){
 const selected=(data.models||[]).find(m=>m.id===id),dialog=$('#ma-dialog');if(!selected||!dialog)return;
 dialog.innerHTML=monthPanel(selected);state.modal=id;
 dialog.querySelector('#ma-modal-close').onclick=()=>dialog.close();
 dialog.onclick=event=>{if(event.target===dialog)dialog.close();};
 dialog.onclose=()=>{state.modal=null;};
 if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');
}
function paint(){
 const host=$('#workspace');if(!host||!data)return;
 const models=(data.models||[]).filter(monitored),visible=filtered(models);
 host.innerHTML=`<section class="update-workspace ma-workspace"><header class="work-heading update-page-heading"><div><h1>Monitor de cierre 2026</h1><p class="quiet">Variables con un cierre provisional basado en observaciones SBS o BCRP de 2026.</p></div><button type="button" class="button secondary" id="ma-refresh">Actualizar vista</button></header>
 <div class="ma-mini-summary"><div><small>Variables con cierre provisional</small><strong>${models.length}</strong></div><div><small>Corte de información</small><strong>${escape(models.reduce((a,m)=>(m.lastIncorporatedPeriod||'')>a?m.lastIncorporatedPeriod:a,'')||'—')}</strong></div><div><small>Última consulta del monitor</small><strong>${escape(date(data.generatedAt))}</strong></div></div>
 ${data.lastRecalculation?.ok===false?'<p class="ma-notice" role="status">El último recálculo tuvo incidencias. Se conserva la última versión válida.</p>':''}
 <section class="ma-section"><div class="ma-section-heading"><h2>Variables y metodología de cierre</h2></div><div class="ma-filterbar"><label>Buscar variable<input type="search" id="ma-query" placeholder="Código o nombre" value="${escape(state.query)}" autocomplete="off"></label><label>Ámbito<select id="ma-group"><option value="all" ${state.group==='all'?'selected':''}>Todas</option><option value="falabella" ${state.group==='falabella'?'selected':''}>Banco Falabella</option><option value="mercado" ${state.group==='mercado'?'selected':''}>Mercado</option></select></label><small id="ma-count" aria-live="polite">${visible.length} variables</small></div><div class="ma-table-wrap"><table class="ma-model-table"><thead><tr><th>Variable</th><th>Último observado</th><th>Cierre 2026</th><th>Metodología aplicada</th><th>Meses por cerrar</th><th>Detalle</th></tr></thead><tbody>${visible.length?rows(visible):'<tr><td colspan="6" class="ma-no-results">No se encontraron variables con esos filtros.</td></tr>'}</tbody></table></div></section>
 <dialog class="ma-modal" id="ma-dialog" aria-labelledby="ma-dialog-title"></dialog></section>`;
 const bind=()=>document.querySelectorAll('[data-monitor-model]').forEach(button=>button.onclick=()=>showModal(button.dataset.monitorModel));bind();
 const update=()=>{const visible=filtered(models);$('.ma-model-table tbody').innerHTML=visible.length?rows(visible):'<tr><td colspan="6" class="ma-no-results">No se encontraron variables con esos filtros.</td></tr>';$('#ma-count').textContent=`${visible.length} variables`;bind();};
 $('#ma-query').oninput=e=>{state.query=e.target.value;update();};
 $('#ma-group').onchange=e=>{state.group=e.target.value;update();};
 $('#ma-refresh').onclick=()=>{invalidate();render(app);};
}
async function render(application){
 app=application;
 if(!location.hash.startsWith('#monitor'))return;
 const token=++request,host=$('#workspace');host.innerHTML='<div class="empty">Consultando cierres de 2026…</div>';
 try{pending||=app.api('/api/monitor/actualizacion');const result=await pending;if(token!==request||!location.hash.startsWith('#monitor'))return;data=result;paint();}
 catch(error){pending=null;if(token===request&&location.hash.startsWith('#monitor'))host.innerHTML=`<section class="ma-workspace"><h1>Monitor de cierre 2026</h1><p class="ma-notice" role="status">${escape(error.message||'No se pudo consultar el monitor.')}</p></section>`;}
}
function invalidate(){request++;pending=null;data=null;}
window.addEventListener('iaspe:monitor-updated',()=>{invalidate();if(app&&location.hash.startsWith('#monitor'))render(app);});
window.IASPEMonitorActualizacion={render,invalidate};
})();
