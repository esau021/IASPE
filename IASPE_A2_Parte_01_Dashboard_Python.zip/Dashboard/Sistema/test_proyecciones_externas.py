"""Pruebas aisladas del módulo externo. No consultan red ni cambian IASPE.
Ejecutar: python -m unittest -v test_proyecciones_externas
Las pruebas Reales leen los documentos oficiales archivados por el conector.
"""
import base64
import copy
import hashlib
import io
import json
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import patch

import requests
from openpyxl import Workbook
import proyecciones_externas as p

ORIGINAL_DIR = p.DIR


def workbook_survey(month=10, incomplete=False, reverse=False):
    wb = Workbook(); ws = wb.active; ws.title = 'PBI'
    ws['A2'] = 'Encuesta de Expectativas Macroeconómicas de PBI'
    groups = [('Analistas', 'Económicos'), ('Sistema', 'Financiero'), ('Empresas', 'No financieras')]
    if reverse: groups.reverse()
    for col, (a, b) in enumerate(groups, 2): ws.cell(4, col, a); ws.cell(5, col, b)
    ws['A4'] = 'Fecha'; ws['A5'] = 'de encuesta'
    ridx = 7
    for year in (2026, 2027, 2028):
        ws.cell(ridx, 1, f'Expectativas anuales de {year}'); ridx += 1
        ws.cell(ridx, 1, f'30 de {"octubre" if month == 10 else "setiembre"} de 2026')
        for col, (a, _) in enumerate(groups, 2):
            if incomplete and year == 2028 and col == 4: continue
            ws.cell(ridx, col, {'Analistas': 3.1, 'Sistema': 3.2, 'Empresas': 3.3}[a])
        ridx += 2
    # Un bloque 12m no puede atribuirse al último año calendario.
    ws.cell(ridx, 1, 'Expectativas a 12 meses'); ws.cell(ridx+1, 1, '30 de octubre de 2026'); ws.cell(ridx+1, 2, 99)
    wb.properties.created=datetime(2026,1,1);wb.properties.modified=datetime(2026,1,1)
    stream=io.BytesIO();wb.save(stream)
    import zipfile
    result=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(stream.getvalue())) as original,zipfile.ZipFile(result,'w',zipfile.ZIP_DEFLATED) as stable:
        for name in original.namelist():
            info=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0));stable.writestr(info,original.read(name))
    return result.getvalue()


class Response:
    def __init__(self, body=b'contenido', status=200, headers=None):
        self.body=body; self.status_code=status; self.headers=headers or {'Content-Type':'text/plain'}
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def iter_content(self, size): yield self.body
    def raise_for_status(self):
        if self.status_code >= 400: raise requests.HTTPError(str(self.status_code))


class ExternalTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='iaspe_test_'); self.root=Path(self.temp.name)
        self.originals={k:getattr(p,k) for k in ('DIR','STATE','DOCS','HTTP_CACHE')}
        p.DIR=self.root; p.STATE=self.root/'historial.json'; p.DOCS=self.root/'documentos'; p.HTTP_CACHE=self.root/'http_cache.json'
        p.BLOCKED_HOSTS.clear(); p.LOCAL.events=[]; p.LOCAL.metadata={}
    def tearDown(self):
        for k,v in self.originals.items(): setattr(p,k,v)
        p.BLOCKED_HOSTS.clear(); self.temp.cleanup()
    def document(self, body=None, edition='2026-10'):
        body=body or workbook_survey()
        rows, detected=p._parse_bcrp_excel(body,'pbi',p.BCRP_XLSX_PBI)
        ident, filename, sha=p._store_document(body,'BCRP',edition,'.xlsx')
        for r in rows: r.update(document_id=ident,origin='official',edition=edition)
        doc={'id':ident,'file':filename,'hash':sha,'source':'BCRP · encuesta anual','variable':'pbi','edition':edition,'rows':len(rows),'kind':'xlsx','url':p.BCRP_XLSX_PBI,'published':'2026-11-05','origin':'official'}
        event={'url':p.BCRP_XLSX_PBI,'body_hash':sha,'downloaded_at':p._utc(),'checked_at':p._utc(),'http_status':200,'content_type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','consulted':True,'downloaded':True}
        p._enrich(rows,[doc],[event]); return rows,doc,event
    def test_calendar_groups_and_column_order(self):
        rows,_=p._parse_bcrp_excel(workbook_survey(reverse=True),'pbi')
        self.assertEqual(len(rows),9);self.assertEqual({r['year'] for r in rows},{'2026','2027','2028'})
        self.assertEqual({r['value'] for r in rows if r['group']=='Analistas económicos'},{3.1})
        self.assertNotIn(99,{r['value'] for r in rows});self.assertTrue(all(r['published'] is None for r in rows))
    def test_incomplete_survey_rejected(self):
        with self.assertRaises(ValueError):p._parse_bcrp_excel(workbook_survey(incomplete=True),'pbi')
    def test_wrong_variable_rejected(self):
        with self.assertRaises(ValueError):p._parse_bcrp_excel(workbook_survey(),'inflacion')
    def test_invalid_excel_rejected(self):
        for data in (b'<html>no</html>',b'PKfake',b''):
            with self.assertRaises(Exception):p._parse_bcrp_excel(data,'pbi')
    def test_api_12_months_stays_separate(self):
        rows=p.parse_bcrp_api('PD38048AM',json.dumps({'periods':[{'name':'Oct.2026','values':['3.2']}]}).encode())
        self.assertEqual(rows[0]['kind'],'12_meses');self.assertEqual(rows[0]['year'],'2026-10')
        self.assertEqual(p._current_records({'records':rows,'editions':[]}),[])
    def test_nonfinite_not_added(self):
        rows=[]
        for value in (float('nan'),float('inf')):p._add_record(rows,source='X',edition='X',var='pbi',year=2026,value=value)
        self.assertEqual(rows,[])
    def test_blocked_200_html_stops_and_persists(self):
        with patch.object(p.requests,'get',return_value=Response(b'<html>Pardon Our Interruption</html>',200,{'Content-Type':'text/html'})) as get:
            with self.assertRaises(p.FuenteProtegida):p._get(p.BCRP_XLSX_PBI)
            p.BLOCKED_HOSTS.clear()
            with self.assertRaises(p.FuenteProtegida):p._get(p.BCRP_XLSX_INFLACION)
            self.assertEqual(get.call_count,1)
        self.assertEqual(p.LOCAL.events[0]['http_status'],200); self.assertFalse(p.LOCAL.events[0]['downloaded'])
    def test_403_and_429_not_retried(self):
        for status in (403,429):
            p.BLOCKED_HOSTS.clear();p.HTTP_CACHE.unlink(missing_ok=True)
            with patch.object(p.requests,'get',return_value=Response(b'blocked',status,{'Content-Type':'text/plain','Retry-After':'7200'})) as get:
                with self.assertRaises(p.FuenteProtegida):p._get(p.BCRP_XLSX_PBI)
                self.assertEqual(get.call_count,1)
    def test_timeout_limited_retry(self):
        with patch.object(p.requests,'get',side_effect=requests.Timeout('offline')) as get,patch.object(p.time,'sleep'):
            with self.assertRaises(requests.Timeout):p._get(p.BCRP_XLSX_PBI)
            self.assertEqual(get.call_count,2)
    def test_temporary_connection_recovers(self):
        with patch.object(p.requests,'get',side_effect=[requests.ConnectionError('offline'),Response(b'ok')]) as get,patch.object(p.time,'sleep'):
            self.assertEqual(p._get(p.BCRP_XLSX_PBI),b'ok');self.assertEqual(get.call_count,2)
    def test_503_limited_retry(self):
        with patch.object(p.requests,'get',side_effect=[Response(b'unavailable',503),Response(b'ok')]) as get,patch.object(p.time,'sleep'):
            self.assertEqual(p._get(p.BCRP_XLSX_PBI),b'ok');self.assertEqual(get.call_count,2)
    def test_redirect_validated_before_request(self):
        with patch.object(p.requests,'get',return_value=Response(b'',302,{'Location':'http://127.0.0.1/private'})) as get:
            with self.assertRaises(ValueError):p._get(p.BCRP_XLSX_PBI)
            self.assertEqual(get.call_count,1)
    def test_urls_reject_credentials_ports_and_lookalikes(self):
        for url in ('https://www.bcrp.gob.pe@evil.test/a','https://evil.test/bcrp.gob.pe/a','http://www.bcrp.gob.pe/a','https://www.bcrp.gob.pe:999/a','https://www.bcrp.gob.pe:bad/a'):
            self.assertFalse(p._url_valid(url))
    def test_size_limit(self):
        with patch.object(p.requests,'get',return_value=Response(b'12345')):
            with self.assertRaises(ValueError):p._get(p.BCRP_XLSX_PBI,limit=4)
    def test_cache_and_conditional_304(self):
        response=Response(b'validbody',headers={'Content-Type':'text/plain','ETag':'"v1"','Last-Modified':'Wed, 18 Nov 2026 00:00:00 GMT'})
        with patch.object(p.requests,'get',return_value=response) as get:
            self.assertEqual(p._get(p.BCRP_XLSX_PBI),b'validbody');p._get(p.BCRP_XLSX_PBI);self.assertEqual(get.call_count,1)
        cache=p._cache_load();cache[p.BCRP_XLSX_PBI]['next_check']=0;p._atomic_json(p.HTTP_CACHE,cache)
        with patch.object(p.requests,'get',return_value=Response(b'',304)) as get:
            self.assertEqual(p._get(p.BCRP_XLSX_PBI),b'validbody')
            self.assertEqual(get.call_args.kwargs['headers']['If-None-Match'],'"v1"')
            self.assertFalse(p.LOCAL.events[-1]['downloaded'])
    def test_304_without_cache_rejected(self):
        with patch.object(p.requests,'get',return_value=Response(b'',304)):
            with self.assertRaises(ValueError):p._get(p.BCRP_XLSX_PBI)
    def test_corrupted_cache_not_reused(self):
        with patch.object(p.requests,'get',return_value=Response(b'original',headers={'ETag':'v1'})):p._get(p.BCRP_XLSX_PBI)
        entry=p._cache_load()[p.BCRP_XLSX_PBI];(p.DOCS/entry['cache_file']).write_bytes(b'altered')
        with patch.object(p.requests,'get',return_value=Response(b'new')) as get:
            self.assertEqual(p._get(p.BCRP_XLSX_PBI),b'new');self.assertNotIn('If-None-Match',get.call_args.kwargs['headers'])
    def test_repeat_new_edition_and_revision(self):
        state=p._load();rows,doc,_=self.document();self.assertEqual(p._merge(state,rows,[doc]),9)
        self.assertEqual(p.LOCAL.merge_info['new_editions'],1)
        self.assertEqual(p._merge(state,copy.deepcopy(rows),[copy.deepcopy(doc)]),0);self.assertEqual(p.LOCAL.merge_info['repeated'],1)
        revised=workbook_survey(reverse=True);newrows,newdoc,_=self.document(revised)
        self.assertEqual(p._merge(state,newrows,[newdoc]),9);self.assertEqual(p.LOCAL.merge_info['revisions'],1)
        nextrows,nextdoc,_=self.document(edition='2026-11');p._merge(state,nextrows,[nextdoc]);self.assertEqual(p.LOCAL.merge_info['new_editions'],1)
        self.assertEqual(len(p._current_records(state)),9)
    def test_same_document_different_value_rejected(self):
        state=p._load();rows,doc,_=self.document();p._merge(state,rows,[doc]);rows=copy.deepcopy(rows);rows[0]['value']+=1
        with self.assertRaises(ValueError):p._merge(state,rows,[doc])
    def test_new_cohort_does_not_fill_from_old(self):
        rows,doc,_=self.document();state={'records':copy.deepcopy(rows),'editions':[doc]}
        newer=copy.deepcopy(rows[:3]);
        for r in newer:r.update(edition='2026-11',document_id='newer')
        state['records']+=newer
        self.assertEqual(p._current_records(state),newer)
    def test_failed_sources_preserve_valid_and_process_other(self):
        rows,doc,event=self.document();p._save(p._load())
        with patch.object(p,'_update_eem_excel',return_value=(rows,[doc])),patch.object(p,'_update_ri',side_effect=requests.ConnectionError('offline')),patch.object(p,'_update_mef',side_effect=ValueError('invalid')),patch.object(p,'_update_eem',return_value=([],[])):
            # En este ensayo no existe HTTP real: no se certifica procedencia.
            result=p.update(include_bcrp=True)
        self.assertEqual(len(result['records']),9);self.assertEqual(len(result['updateResult']['errors']),2)
        original_values=[r['value'] for r in result['records']]
        with patch.object(p,'_update_eem_excel',side_effect=requests.Timeout('offline')),patch.object(p,'_update_ri',return_value=([],[])),patch.object(p,'_update_mef',return_value=([],[])),patch.object(p,'_update_eem',return_value=([],[])):
            after=p.update(include_bcrp=True)
        self.assertEqual([r['value'] for r in after['records']],original_values)
    def test_automatic_update_mef_only_by_default(self):
        with patch.object(p,'_update_eem_excel',side_effect=AssertionError('BCRP no debe consultarse')) as eem, \
             patch.object(p,'_update_ri',side_effect=AssertionError('RI no debe consultarse')) as ri, \
             patch.object(p,'_update_mef',return_value=([],[])) as mef:
            result=p.update()
        eem.assert_not_called();ri.assert_not_called();mef.assert_called_once()
        self.assertEqual(result['updateResult']['source_summary']['MEF — MMM/IAPM']['consulted'],0)
        self.assertNotIn('Encuesta BCRP',result['updateResult']['source_summary'])

    def test_corrupt_state_never_overwritten(self):
        p.STATE.write_text('broken',encoding='utf-8')
        with self.assertRaises(ValueError):p.update()
        self.assertEqual(p.STATE.read_text(),'broken')
    def test_hash_verified_on_document_delivery(self):
        rows,doc,_=self.document();state=p._load();p._merge(state,rows,[doc]);p._save(state)
        p.get_document(doc['id']);(p.DOCS/doc['file']).write_bytes(b'altered')
        with self.assertRaises(ValueError):p.get_document(doc['id'])
    def test_freshness_requires_latest_date_and_hash(self):
        rows,doc,_=self.document();
        for r in rows:r['published']='2026-11-05'
        state=p._load();p._merge(state,rows,[doc]);state['confirmations']={'BCRP · encuesta anual|pbi':{'edition':'2026-10','document_id':doc['id'],'confirmed_at':p._utc(),'latest_confirmed':True}};p._save(state)
        self.assertTrue(p.snapshot()['freshness'][0]['up_to_date'])
        state['confirmations']['BCRP · encuesta anual|pbi']['edition']='2026-11';state['confirmations']['BCRP · encuesta anual|pbi']['document_id']=None;p._save(state)
        self.assertFalse(p.snapshot()['freshness'][0]['up_to_date'])
    def test_unknown_publication_never_certified(self):
        rows,doc,_=self.document();state=p._load();p._merge(state,rows,[doc]);p._save(state)
        self.assertFalse(p.snapshot()['freshness'][0]['up_to_date'])
    def test_manual_import_trace_not_automatic_certification(self):
        result=p.import_document('BCRP · encuesta anual','','source.xlsx',base64.b64encode(workbook_survey()).decode(),p.BCRP_XLSX_PBI,'2026-11-05')
        self.assertIsNone(result['document']['downloaded_at']);self.assertTrue(result['document']['imported_at'])
        self.assertFalse(result['state']['freshness'][0]['up_to_date'])
    def test_manual_import_without_url_date_or_edition(self):
        obj=p.import_document('auto','','a.xlsx',base64.b64encode(workbook_survey()).decode())
        self.assertEqual(obj['document']['edition'],'2026-10')
        self.assertEqual(obj['document']['source'],'BCRP · encuesta anual')
        self.assertIsNone(obj['document']['published'])
        self.assertEqual(obj['added'],9)
        self.assertFalse(obj['document']['transport_verified'])

    def test_import_rejects_unofficial_url_without_touching_database(self):
        with self.assertRaises(ValueError):
            p.import_document('auto','','source.xlsx',base64.b64encode(workbook_survey()).decode(), 'https://ejemplo.com/fuente')
        self.assertFalse(p.STATE.exists())

    def test_import_detects_mef_workbooks_from_local_archives(self):
        docs=ORIGINAL_DIR/'documentos'
        for filename,edition,expected in (('348f534a9cceec2b78e7.xlsx','MMM 2027–2030',20),
                                          ('4ec20fc21fe6fb722679.xlsx','IAPM 2026–2029',16)):
            f=docs/filename
            if not f.exists():self.skipTest('Sin archivo MEF archivado')
            obj=p.import_document('auto','','oficial.xlsx',base64.b64encode(f.read_bytes()).decode())
            self.assertEqual(obj['document']['edition'],edition)
            self.assertEqual(obj['document']['rows'],expected)

    def test_fake_pdf_rejected_without_mutation(self):
        with self.assertRaises(ValueError):
            p.import_document('auto','','nota.pdf',base64.b64encode(b'<html>no es PDF</html>').decode())
        self.assertFalse(p.STATE.exists())

    def test_recovered_download_metadata_has_no_stale_error(self):
        with patch.object(p.requests,'get',side_effect=[requests.Timeout('offline'),Response(b'good')]),patch.object(p.time,'sleep'):
            p._get(p.BCRP_XLSX_PBI)
        self.assertNotIn('error',p.LOCAL.events[-1]);self.assertTrue(p.LOCAL.events[-1]['downloaded_at'])
    def test_manual_repeat_preserves_official_metadata(self):
        rows,doc,_=self.document();state=p._load();p._merge(state,rows,[doc]);p._save(state)
        result=p.import_document('BCRP · encuesta anual','','source.xlsx',base64.b64encode(workbook_survey()).decode(),p.BCRP_XLSX_PBI,'2026-11-05')
        self.assertEqual(result['added'],0);self.assertEqual(len(result['state']['records']),9)
        self.assertTrue(all(r['transport_verified'] and r['origin']=='official' for r in result['state']['records']))
    def test_corrupt_document_repaired_from_same_good_body(self):
        rows,doc,_=self.document();state=p._load();p._merge(state,rows,[doc]);p._save(state)
        (p.DOCS/doc['file']).write_bytes(b'broken')
        ident,filename,sha=p._store_document(workbook_survey(),'BCRP · encuesta anual','2026-10','.xlsx')
        self.assertEqual(ident,doc['id']);self.assertEqual(hashlib.sha256((p.DOCS/filename).read_bytes()).hexdigest(),sha)
    def test_pdf_rejects_wrong_definitions_and_partial_groups(self):
        text='Proyecciones\n2026 2027\nCrecimiento del PBI potencial 3.5 3.4\nInflacion subyacente variacion 2.8 2.5'
        self.assertEqual(p._parse_ri_text(text,'Marzo 2026','2026-03',''),[])
        text='Encuesta de Expectativas Macroeconomicas crecimiento del PBI\nAnalistas economicos\n2026 3.0 3.1\nEncuesta de Expectativas Macroeconomicas inflacion\nAnalistas economicos\n2026 2.0 2.1\n2027 2.0 2.1\n2028 2.0 2.1'
        with self.assertRaises(ValueError):p._parse_eem_text(text,'2026-10',None,'')
    def test_no_cache_revalidates_and_no_store_evicts(self):
        with patch.object(p.requests,'get',return_value=Response(b'ok',headers={'Cache-Control':'no-cache','ETag':'v1'})) as get:
            p._get(p.BCRP_XLSX_PBI);p._get(p.BCRP_XLSX_PBI);self.assertEqual(get.call_count,2)
        with patch.object(p.requests,'get',return_value=Response(b'new',headers={'Cache-Control':'no-store'})):
            p._get(p.BCRP_XLSX_PBI)
        self.assertNotIn(p.BCRP_XLSX_PBI,p._cache_load())

    def test_no_cache_survives_304_revalidation(self):
        with patch.object(p.requests,'get',return_value=Response(b'ok',headers={'Cache-Control':'no-cache','ETag':'v1'})):
            p._get(p.BCRP_XLSX_PBI)
        with patch.object(p.requests,'get',return_value=Response(b'',304)) as get:
            p._get(p.BCRP_XLSX_PBI);p._get(p.BCRP_XLSX_PBI)
            self.assertEqual(get.call_count,2)

    def test_integrity_failure_in_one_source_isolated(self):
        rows,doc,_=self.document();p._save(p._load())
        bad=copy.deepcopy(rows);bad[0]['source']='MEF · MMM/IAPM';bad[0]['value']=float('nan')
        baddoc=dict(doc,id='bad',source='MEF · MMM/IAPM')
        with patch.object(p,'_update_eem_excel',return_value=(rows,[doc])),patch.object(p,'_update_ri',return_value=([],[])),patch.object(p,'_update_mef',return_value=([bad[0]],[baddoc])),patch.object(p,'_update_eem',return_value=([],[])):
            result=p.update(include_bcrp=True)
        self.assertEqual(len(result['records']),9)
        self.assertTrue(any('integridad' in message for message in result['updateResult']['errors']))


class RealArchivedDocumentsTests(unittest.TestCase):
    def test_official_mef_books_and_coverage(self):
        state=json.loads((ORIGINAL_DIR/'historial.json').read_text(encoding='utf-8'))
        docs=[e for e in state['editions'] if e.get('source')=='MEF · MMM/IAPM' and e.get('file') and e.get('origin')=='official']
        if len(docs)<2:self.skipTest('Ejecutar primero una actualización real del conector')
        for doc in docs:
            body=(ORIGINAL_DIR/'documentos'/doc['file']).read_bytes()
            self.assertEqual(hashlib.sha256(body).hexdigest(),doc['hash'])
            rows=p._parse_mef_xlsx(body,doc['edition'],doc['published'],doc['url'])
            expected=20 if doc['edition'].startswith('MMM') else 16
            self.assertEqual(len(rows),expected);self.assertNotIn('2025',{r['year'] for r in rows})
            self.assertEqual({r['variable'] for r in rows},{'pbi','inflacion','tc_promedio','tc_cierre'})
            wrong='MMM 2026–2029' if doc['edition'].startswith('MMM') else 'IAPM 2027–2030'
            with self.assertRaises(ValueError):p._parse_mef_xlsx(body,wrong,doc['published'],doc['url'])


if __name__=='__main__':unittest.main(verbosity=2)
