"""Actualización aislada: fallos, concurrencia, historial y formatos."""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from openpyxl import Workbook, load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import actualizador_sbs as a
import motor
import persistencia_modelos as persistence


PERSONAL = ['periodo','banco','personal_total','gerentes','funcionarios','empleados','otros']


def write_csv(path, columns, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def staff(period, total=10):
    return dict(zip(PERSONAL, [period, a.BANKS['05'], total, 1, 2, total-3, 0]))


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='iaspe_pipeline_test_')
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def manager(self):
        with patch.object(a, 'OUTPUT', self.root/'state'):
            return a.Actualizador()

    def test_download_rejected_while_recalculation_owns_operation(self):
        manager = self.manager()
        with a.operation('recalculation'), patch.object(motor, 'freeze_sources') as freeze:
            with self.assertRaises(a.Ocupado):
                manager.begin(['personal_banca'])
            self.assertEqual(a.operation_status()['kind'], 'recalculation')
        freeze.assert_not_called()
        self.assertFalse(a.operation_status()['running'])

    def test_recalculation_rejected_while_download_owns_operation(self):
        with a.operation('download'):
            with self.assertRaises(a.Ocupado):
                with a.operation('recalculation'):
                    self.fail('No debe iniciar una segunda operación')

    def test_partial_personal_download_preserves_missing_months(self):
        previous, current = self.root/'old.csv', self.root/'new.csv'
        write_csv(previous, PERSONAL, [staff('2026-08'), staff('2026-09')])
        write_csv(current, PERSONAL, [staff('2026-09', 12)])
        a.Actualizador._merge_personal_rows(current, previous, ['05'])
        with current.open(encoding='utf-8-sig', newline='') as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual({row['periodo']: row['personal_total'] for row in rows},
                         {'2026-08': '10', '2026-09': '12'})

    def test_personal_11_to_12_columns_preserves_order_metadata_and_missing_category(self):
        columns=PERSONAL+['nombre_sbs','archivo','hoja','fila_excel']
        previous, current=self.root/'old.csv',self.root/'new.csv'
        old=dict(staff('2026-08'),nombre_sbs='Falabella',archivo='old.XLS',hoja='1',fila_excel='8')
        new=dict(staff('2026-09',12),nombre_sbs='Falabella Perú',archivo='new.XLS',hoja='2',fila_excel='15',sistema='Banca Múltiple')
        new['funcionarios']=None
        write_csv(previous,columns,[old])
        before=previous.read_bytes()
        # El proveedor puede reordenar columnas; los valores se mapean por nombre.
        write_csv(current,list(reversed(columns+['sistema'])),[new])
        a.Actualizador._merge_personal_rows(current,previous,['05'])
        with current.open(encoding='utf-8-sig',newline='') as stream:
            reader=csv.DictReader(stream);rows=list(reader)
            self.assertEqual(reader.fieldnames,columns+['sistema'])
        self.assertEqual(rows[0],{**{key:str(value) for key,value in old.items()},'sistema':''})
        self.assertEqual(rows[1]['funcionarios'],'')
        self.assertEqual(rows[1]['personal_total'],'12')
        self.assertEqual(rows[1]['archivo'],'new.XLS')
        self.assertEqual(rows[1]['sistema'],'Banca Múltiple')
        self.assertEqual(previous.read_bytes(),before)

    def test_personal_incompatible_new_column_is_rejected_before_replacing_csv(self):
        previous,current=self.root/'old.csv',self.root/'new.csv'
        write_csv(previous,PERSONAL,[staff('2026-08')])
        write_csv(current,PERSONAL+['unknown_measure'],[dict(staff('2026-09'),unknown_measure=5)])
        before=current.read_bytes()
        with self.assertRaises(ValueError):
            a.Actualizador._merge_personal_rows(current,previous,['05'])
        self.assertEqual(current.read_bytes(),before)

    def test_partial_ratios_download_preserves_other_months_and_entities(self):
        columns = ['periodo_fuente','banco_id','reporte','categoria','indicador_sbs','fecha_indicador','valor']
        row = dict(zip(columns, ['2026-08','05','B-2401','Rentabilidad','ROE','2026-08-31','3']))
        previous, current = self.root/'old.csv', self.root/'new.csv'
        write_csv(previous, columns, [row, dict(row, periodo_fuente='2026-09'), dict(row,banco_id='01')])
        write_csv(current, columns, [dict(row, periodo_fuente='2026-09', valor='4')])
        a.Actualizador._merge_ratio_rows(current, previous, ['Rentabilidad'], ['05'])
        with current.open(encoding='utf-8-sig', newline='') as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(len(rows), 3)
        self.assertEqual(next(r['valor'] for r in rows if r['periodo_fuente']=='2026-09'), '4')

    def test_file_publication_failure_rolls_back_every_previous_replacement(self):
        stage, active, backup = (self.root/name for name in ('stage','active','backup'))
        for directory in (stage, active, backup):
            directory.mkdir()
        for index in range(2):
            (stage/str(index)).write_text('new')
            (active/str(index)).write_text('old')
        original_replace = os.replace
        def replace(source, target):
            if Path(target) == active/'1' and str(source).endswith('.actualizando'):
                raise OSError('simulated disk failure')
            return original_replace(source, target)
        with patch.object(a.os, 'replace', side_effect=replace):
            with self.assertRaises(OSError):
                a.Actualizador._publish_files([(stage/str(i),active/str(i)) for i in range(2)],backup)
        self.assertEqual([(active/str(i)).read_text() for i in range(2)], ['old','old'])
        self.assertFalse(list(active.glob('*.actualizando')))

    def test_state_bundle_failure_preserves_both_applied_photographs(self):
        data = self.root/'data'
        data.mkdir()
        for name in ('fuentes_aplicadas.json','observaciones_aplicadas.json'):
            (data/name).write_text('{"old":true}')
        original_replace = os.replace
        failed = [False]
        def replace(source, target):
            if Path(target).name == 'observaciones_aplicadas.json' and not failed[0]:
                failed[0] = True
                raise OSError('simulated commit failure')
            return original_replace(source, target)
        with patch.object(motor, 'DATA', data), patch.object(os, 'replace', side_effect=replace):
            with self.assertRaises(OSError):
                motor.write_states({'fuentes_aplicadas.json': {'new': 1},
                                    'observaciones_aplicadas.json': {'new': 2}})
        for name in ('fuentes_aplicadas.json','observaciones_aplicadas.json'):
            self.assertEqual(json.loads((data/name).read_text()), {'old': True})

    def test_personal_validation_rejects_nonreconciling_total(self):
        manager = self.manager()
        target = self.root/a.BACKUP['personal_banca'][0]
        bad = staff('2026-09')
        bad['personal_total'] = 15
        write_csv(target, PERSONAL, [bad])
        with self.assertRaises(ValueError):
            manager._validate('personal_banca', self.root)

    def test_personal_total_is_valid_when_sbs_omits_a_category_without_imputing_zero(self):
        manager = self.manager()
        target = self.root/a.BACKUP['personal_banca'][0]
        write_csv(target, PERSONAL, [staff('2026-09')])
        previous = manager._validate('personal_banca', self.root)
        current = staff('2026-09')
        current['funcionarios'] = None
        write_csv(target, PERSONAL, [current])
        updated = manager._validate('personal_banca', self.root)
        self.assertEqual(updated['missingCategoryValues'], 1)
        self.assertEqual(updated['_values'][(a.BANKS['05']+'|personal_total','2026-09')],10)
        self.assertNotIn((a.BANKS['05']+'|funcionarios','2026-09'),updated['_values'])
        self.assertTrue(updated['dataNotes'])
        a.Actualizador._preserves_history(previous,updated)
        with target.open(encoding='utf-8-sig', newline='') as stream:
            self.assertEqual(next(csv.DictReader(stream))['funcionarios'],'')

    def test_missing_previously_observed_record_rejected(self):
        with self.assertRaises(ValueError):
            a.Actualizador._preserves_history({'_values': {('balance','2026-08'): 1}},
                                              {'_values': {('balance','2026-09'): 2}})

    def test_staged_processing_does_not_expose_partial_csv(self):
        project, system = self.root/'IASPE', self.root/'Dashboard/Sistema'
        system.mkdir(parents=True)
        (system/'actualizador_sbs.py').write_text('# isolated test')
        active = project/a.BACKUP['personal_banca'][0]
        write_csv(active, PERSONAL, [staff('2026-08')])
        before = active.read_bytes()
        manager = self.manager()
        manager.banks = ['05']
        def execute(task):
            self.assertEqual(active.read_bytes(), before)
            current = manager._active_project/a.BACKUP[task][0]
            write_csv(current, PERSONAL, [staff('2026-08'), staff('2026-09',12)])
            self.assertEqual(active.read_bytes(), before)
        def link(*args, **kwargs):
            self.assertEqual(active.read_bytes(), before)
            return json.dumps({'detalle': 'Fixture validada'})
        with patch.object(a, 'PROJECT', project), patch.object(a, '__file__', str(system/'actualizador_sbs.py')), \
             patch.object(manager, '_execute', side_effect=execute), patch.object(manager, '_subprocess', side_effect=link):
            result = manager._run_task('personal_banca')
        self.assertEqual(result['validation']['latestPeriod'], '2026-09')
        self.assertTrue(result['changed'])
        self.assertNotEqual(active.read_bytes(), before)

    def test_failed_staged_processing_preserves_original_bytes(self):
        project, system = self.root/'IASPE', self.root/'Dashboard/Sistema'
        system.mkdir(parents=True)
        active = project/a.BACKUP['personal_banca'][0]
        write_csv(active, PERSONAL, [staff('2026-08')])
        before = active.read_bytes()
        manager = self.manager()
        def execute(task):
            (manager._active_project/a.BACKUP[task][0]).write_bytes(b'partial download')
            raise OSError('network interrupted')
        with patch.object(a, 'PROJECT', project), patch.object(a, '__file__', str(system/'actualizador_sbs.py')), \
             patch.object(manager, '_execute', side_effect=execute):
            with self.assertRaises(OSError):
                manager._run_task('personal_banca')
        self.assertEqual(active.read_bytes(), before)

    def test_excel_data_changes_preserve_layout_and_style_changes_are_rejected(self):
        original, updated = self.root/'original.xlsx', self.root/'updated.xlsx'
        book = Workbook()
        sheet = book.active
        sheet['A1'] = 'Año'
        sheet['B2'] = 123.456
        sheet['B2'].number_format = '#,##0.000'
        sheet.column_dimensions['B'].width = 18
        sheet.freeze_panes = 'A2'
        book.save(original)
        book['Sheet']['B2'] = 789.123
        book.save(updated)
        persistence._verify_layout(original, updated)
        book['Sheet']['B2'].number_format = '0.0%'
        book.save(updated)
        with self.assertRaises(ValueError):
            persistence._verify_layout(original, updated)

    def test_excel_publication_rolls_back_if_applied_state_cannot_commit(self):
        source = self.root/'IASPE/Modelos financieros'
        source.mkdir(parents=True)
        original = source/'Book.xlsx'
        book = Workbook()
        book.active['A1'] = 1
        book.save(original)
        before = original.read_bytes()
        def generate(stage, previous, updated, observations):
            output = stage/'Book.xlsx'
            new = load_workbook(output)
            new.active['A1'] = 2
            temporary = output.with_suffix('.writing')
            new.save(temporary)
            os.replace(temporary, output)
            return {'files': ['Book.xlsx']}
        passed = {'passed': True, 'checks': 1}
        with patch.object(persistence, 'generar', side_effect=generate), \
             patch.object(motor, 'load_base', return_value=({}, [])), \
             patch.object(motor, '_run', return_value=({}, [])), \
             patch.object(motor, 'write_states', side_effect=OSError('state commit failed')):
            with self.assertRaises(OSError):
                persistence.aplicar_transaccion(source, {}, {}, lambda: {}, lambda *args: passed,
                                                lambda *args: passed, threading.RLock(),
                                                observations={}, state_updates={'fuentes_aplicadas.json': {}})
        self.assertEqual(original.read_bytes(), before)

    def test_http_recalculation_returns_conflict_during_download(self):
        import servidor
        server = servidor.Server(('127.0.0.1', 0), servidor.Handler)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            url = f'http://127.0.0.1:{server.server_address[1]}/api/models/recalculate'
            request = Request(url, data=b'{}', headers={'Content-Type':'application/json'})
            with a.operation('download'), patch.object(motor, 'recalculate_sources') as recalculate:
                with self.assertRaises(HTTPError) as caught:
                    urlopen(request, timeout=5)
                self.assertEqual(caught.exception.code, 409)
                response = json.loads(caught.exception.read())
                self.assertEqual(response['operation']['kind'], 'download')
            recalculate.assert_not_called()
        finally:
            server.shutdown()
            server.server_close()
            worker.join(timeout=5)


if __name__ == '__main__':
    unittest.main()
