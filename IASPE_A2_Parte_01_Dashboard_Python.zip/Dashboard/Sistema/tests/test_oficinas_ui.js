'use strict';
/* Interfaz territorial: selección, comparación y refresco; no ejecuta descargas. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'..');
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function runtime(){
 const host={innerHTML:''},elements=new Map(),events=[];
 const context={window:{addEventListener(){},dispatchEvent:event=>events.push(event)},document:{querySelector:selector=>selector==='#workspace'?host:selector==='.office-map'||selector==='.office-ranking-list'?null:(elements.has(selector)?elements.get(selector):elements.set(selector,{}).get(selector)),querySelectorAll:()=>[],getElementById:()=>null},location:{hash:'#benchmark/oficinas'},Intl,Date,Map,Set,URL,Blob,console,CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},setTimeout:()=>1,clearTimeout(){}};
 vm.createContext(context);return {context,host,events};
}
const load=(rt,file,transform=s=>s)=>vm.runInContext(transform(fs.readFileSync(path.join(root,file),'utf8')),rt.context,{filename:file});
const departments=Array.from({length:25},(_,i)=>({code:String(i+1).padStart(2,'0'),name:i===6?'Callao':i===14?'Lima':`Departamento ${String(i+1).padStart(2,'0')}`}));
const observed=overrides=>{const counts=Object.fromEntries(departments.map(item=>[item.code,0]));Object.assign(counts,overrides);return {counts,total:Object.values(counts).reduce((a,b)=>a+(b??0),0)};};
const geometryPath=path.resolve(root,'../../IASPE/Scraper/Oficinas/output/departamentos.geojson');
const geometry=fs.existsSync(geometryPath)?JSON.parse(fs.readFileSync(geometryPath,'utf8')):null;
const names={'01':'Banco de Crédito del Perú','05':'Banco Falabella','10':'InFinance XP','11':'Banco Ripley','15':'Banco Efectiva',crac_18:'Caja Cencosud Scotia'};
const institutions=[...Array.from({length:16},(_,i)=>String(i+1).padStart(2,'0')),'crac_18'].map(id=>({id,name:names[id]||`Entidad ${id}`,category:id==='10'?'Empresas financieras':id==='crac_18'?'Cajas rurales':'Bancos'}));
institutions.find(item=>item.id==='15').category_history=[{from:'2000-01',to:'2026-05',category:'Empresas financieras',name:'Financiera Efectiva'},{from:'2026-06',to:null,category:'Bancos',name:'Banco Efectiva'}];
const partial=observed({'15':45,'04':19});for(const code of ['16','17','18'])partial.counts[code]=null;
const bcp={...observed({'15':168,'07':143}),sourceTotal:313,outsidePeru:2};
const data={ready:true,departments,geometry,institutions,series:{'05':{'2025-12':observed({'15':28,'07':2,'01':23}),'2026-05':observed({'15':25,'07':3,'01':2}),'2026-09':observed({'15':25,'07':3,'01':2})},'11':{'2026-09':observed({'15':17,'01':14})},'01':{'2026-09':bcp},'10':{'2026-09':observed({'15':48,'01':43})},'15':{'2026-05':observed({'15':40,'01':136}),'2026-09':observed({'15':42,'01':135})},crac_18:{'2025-12':partial,'2026-09':observed({'15':45,'04':19})}},limitations:[]};
(async()=>{
 const rt=runtime();load(rt,'workspace-panels.js');rt.context.window.IASPESourceUpdates={refresh:async()=>({}),control:()=>'',bind(){}};
 load(rt,'oficinas-sbs.js',source=>source.replace('window.IASPEOficinasSBS={render,invalidate};','globalThis.probe={state,territoryRows,indicators,sortedRows,fill,geographicPaths,paint,adoptData,cache:()=>({db,pending}),set:(application,source,changes={})=>{app=application;db=source;Object.assign(state,changes)}};window.IASPEOficinasSBS={render,invalidate};'));
 const p=rt.context.probe,app={escape,state:{data:{}},toast(){}};
 p.set(app,data);p.paint();assert.equal(p.state.institution,'05');assert.equal(p.state.period,'2026-09');
 assert.equal((rt.host.innerHTML.match(/<option value="/g)||[]).length,20); //17 entidades y 3 períodos.
 assert(rt.host.innerHTML.includes('data-office-kpi="total">30'));
 assert(!rt.host.innerHTML.includes('Resumen institucional'));
 assert(!rt.host.innerHTML.match(/<details id="office-detail"[^>]*>/)[0].includes(' open'));
 const rows=p.territoryRows(departments,data.series['05']['2026-09'],partial);
 assert.equal(rows.find(item=>item.code==='16').comparator,null);assert.equal(rows.find(item=>item.code==='16').difference,null);
 assert.equal(rows.find(item=>item.code==='02').offices,0);assert.notEqual(p.fill(null,25),p.fill(0,25));
 assert.equal(p.sortedRows(rows,'comparator',1).at(-1).comparator,null);
 assert.equal(p.indicators(departments,partial).concentration,null);assert.equal(p.indicators(departments,partial).leader,null);
 rt.context.document.querySelector('#office-institution').onchange({target:{value:'11'}});
 assert.equal(p.state.institutionA,'11','La principal se conserva como institución A al alternar.');
 assert.equal(p.state.period,'2026-09');assert(rt.host.innerHTML.includes('data-office-kpi="total">31'));assert(rt.host.innerHTML.includes('data-office-kpi="concentration">54.8 %'));
 const mapPart=rt.host.innerHTML.slice(rt.host.innerHTML.indexOf('<div class="office-kpis"'),rt.host.innerHTML.indexOf('<footer'));
 assert(!mapPart.includes('Banco Falabella'));assert(mapPart.includes('Banco Ripley'));
 rt.context.document.querySelector('#office-institution').onchange({target:{value:'01'}});assert(rt.host.innerHTML.includes('data-office-kpi="total">311'));assert(rt.host.innerHTML.includes('total de la fuente 313; oficinas en el exterior 2'));
 rt.context.document.querySelector('#office-institution').onchange({target:{value:'10'}});assert(rt.host.innerHTML.includes('data-office-kpi="total">91'));assert(rt.host.innerHTML.includes('InFinance XP'));
 rt.context.document.querySelector('#office-period').onchange({target:{value:'2026-05'}});rt.context.document.querySelector('#office-institution').onchange({target:{value:'11'}});
 assert.equal(p.state.period,'2026-05');assert(rt.host.innerHTML.includes('data-office-kpi="total">—'));assert(rt.host.innerHTML.includes('Sin información de Banco Ripley para Mayo 2026'));
 p.set(app,data,{mode:'compare',institution:'01',institutionA:'01',institutionB:'05',period:'2026-09'});p.paint();
 assert(!rt.host.innerHTML.includes('<svg'));assert(!rt.host.innerHTML.includes('office-kpis'));assert.equal((rt.host.innerHTML.match(/data-office-comparison-row=/g)||[]).length,25);
 assert(rt.host.innerHTML.includes('<tr data-office-national><th scope="row">Perú</th><td>311</td><td>30</td><td>+281</td>'));
 assert(rt.host.innerHTML.includes('data-office-sort="difference"'));assert(rt.host.innerHTML.includes('office-cell-bar'));
 p.state.period='2025-12';rt.context.document.querySelector('#office-a').onchange({target:{value:'crac_18'}});p.state.institutionB='05';p.paint();
 assert(rt.host.innerHTML.includes('<tr data-office-national><th scope="row">Perú</th><td>64</td><td>53</td><td>+11</td>'));
 for(const code of ['16','17','18'])assert(rt.host.innerHTML.match(new RegExp('<tr data-office-comparison-row="'+code+'"[\\s\\S]*?<\\/tr>'))[0].includes('<td>—</td>'));
 assert(rt.host.innerHTML.includes('Hay territorios sin información'));
 assert(rt.host.innerHTML.includes('Cobertura: —'));
 p.state.period='2026-05';p.paint();assert(rt.host.innerHTML.includes('No existe información homogénea para Mayo 2026'));assert(rt.host.innerHTML.includes('<tr data-office-national><th scope="row">Perú</th><td>—</td><td>30</td><td>—</td>'));
 const retained={institution:p.state.institution,institutionA:p.state.institutionA,institutionB:p.state.institutionB,period:p.state.period};
 p.state.mode='map';p.paint();assert.equal(p.state.period,retained.period);p.state.mode='compare';p.paint();for(const [key,value] of Object.entries(retained))assert.equal(p.state[key],value);
 rt.context.document.querySelector('#office-a').onchange({target:{value:'15'}});assert(rt.host.innerHTML.includes('Financiera Efectiva'));assert(rt.host.innerHTML.includes('label="Empresas financieras"'));
 assert.equal(p.state.institution,'15','Cambiar A también actualiza la principal del mapa.');
 const selectedB=p.state.institutionB,selectedPeriod=p.state.period;p.state.mode='map';p.paint();assert.equal(p.state.institution,'15');assert.equal(p.state.institutionB,selectedB);assert.equal(p.state.period,selectedPeriod);p.state.mode='compare';p.paint();
 // Avanzar al nuevo último sólo al recibir una publicación, nunca en selectores/modos.
 p.set(app,data,{mode:'map',institution:'11',period:'2026-09',detailOpen:true});rt.context.window.IASPEOficinasSBS.invalidate();
 const newer=structuredClone(data);newer.series['11']['2026-10']=observed({'15':18,'01':14});p.adoptData(newer);p.paint();assert.equal(p.state.institution,'11');assert.equal(p.state.period,'2026-10');assert.equal(p.state.detailOpen,true);assert(rt.host.innerHTML.includes('data-office-kpi="total">32'));
 p.set(app,data,{mode:'compare',institution:'05',institutionA:'05',institutionB:'15',period:'2025-12'});rt.context.window.IASPEOficinasSBS.invalidate();p.adoptData(newer);p.paint();assert.equal(p.state.mode,'compare');assert.equal(p.state.institutionA,'05');assert.equal(p.state.institutionB,'15');assert.equal(p.state.period,'2025-12');
 p.set(app,data,{mode:'map',institution:'05',period:'2026-09'});rt.context.window.IASPEOficinasSBS.invalidate();p.state.period='2026-05';const newerFal=structuredClone(data);newerFal.series['05']['2026-10']=observed({'15':27});p.adoptData(newerFal);assert.equal(p.state.period,'2026-05','Una selección durante la respuesta pendiente prevalece.');
 if(geometry){const shapes=p.geographicPaths(geometry);assert.equal(shapes.length,25);assert.equal(new Set(shapes.map(shape=>shape.code)).size,25);assert(shapes.every(shape=>shape.path&&!/NaN|Infinity/.test(shape.path)));}
 // La caché anterior no puede reaparecer después de invalidar o abandonar la vista.
 let resolve;app.api=()=>new Promise(done=>resolve=done);const loading=rt.context.window.IASPEOficinasSBS.render(app);for(let tick=0;tick<8;tick++)await Promise.resolve();rt.context.window.IASPEOficinasSBS.invalidate();rt.context.location.hash='#other';resolve(data);await loading;assert.equal(p.cache().db,null);assert.equal(p.cache().pending,null);
 console.log('Oficinas UI: 17 instituciones, dos modos, comparación de 25 territorios y Perú, ausencias, período y selección conservados, refresco protegido: OK');
})().catch(error=>{console.error(error);process.exitCode=1;});
