/* Personal SBS por entidad y categoría laboral. */
(()=>{
'use strict';
const $=s=>document.querySelector(s);
const FAL='05';
const COLORS=['#347b59','#98744e','#755aa2','#5985ab','#b66a60','#7f8c4e'];
const MONTHS=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
const CATS=[['personal_total','Personal total'],['gerentes','Gerentes'],['funcionarios','Funcionarios'],['empleados','Empleados'],['otros','Otros']];
const state={category:'personal_total',peers:['02'],annual:false,showAll:false,mode:'level',panel:'chart'};
let app,db,pending,request=0;
const safe=v=>app.escape(String(v??''));
const fmt=v=>!Number.isFinite(v)?'—':new Intl.NumberFormat('es-PE').format(v);
const dt=s=>/^\d{4}-\d{2}$/.test(s||'')?`${MONTHS[Number(s.slice(5))-1]} ${s.slice(0,4)}`:s||'—';
const bank=id=>db.bancos.find(b=>b.id===id);
const validPeers=()=>state.peers.filter(id=>id!==FAL&&bank(id)?.registros);
const getRows=(id)=>db.registros.filter(r=>r.banco===id&&(!state.annual||r.periodo.endsWith('-12')));
const values=id=>new Map(getRows(id).map(r=>[r.periodo,r[state.category]]));
function plotValues(id){
 const base=values(id);if(state.mode==='level')return base;
 const history=new Map(db.registros.filter(r=>r.banco===id).map(r=>[r.periodo,r[state.category]]));
 return new Map([...base].map(([date,v])=>{const prior=history.get(`${+date.slice(0,4)-1}${date.slice(4)}`);return [date,Number.isFinite(v)&&Number.isFinite(prior)&&prior!==0?100*(v/prior-1):null];}));
}
function historicalTable(){
 const ids=[FAL,...validPeers()];const maps=ids.map(id=>({id,name:id===FAL?'Banco Falabella':bank(id)?.nombre||id,records:plotValues(id)}));
 const dates=[...new Set(maps.flatMap(r=>[...r.records.keys()]))].sort().reverse();
 return `<div class="person-table person-history-table"><table><thead><tr><th>Período</th>${maps.map(s=>`<th>${safe(s.name)}</th>`).join('')}</tr></thead><tbody>${dates.map(date=>`<tr><td>${safe(dt(date))}</td>${maps.map(s=>{const v=s.records.get(date);return `<td>${Number.isFinite(v)?state.mode==='level'?safe(fmt(v)):safe(v.toFixed(2))+'%':'—'}</td>`;}).join('')}</tr>`).join('')}</tbody></table></div>`;
}

function lastDate(){const fal=values(FAL);return [...fal.keys()].sort().at(-1)||db.periodo_fin;}
function comparableDate(){
 const ids=[FAL,...validPeers()];let dates=[...values(FAL).keys()];
 for(const id of ids.slice(1)){const map=values(id);dates=dates.filter(d=>map.has(d));}
 return dates.sort().at(-1)||lastDate();
}
function plot(){
 const datasets=[{id:FAL,name:'Falabella',color:'#214e68'},...validPeers().map((id,i)=>({id,name:bank(id)?.nombre||id,color:COLORS[i%COLORS.length]}))];
 const series=datasets.map(s=>({...s,map:plotValues(s.id)}));
 const dates=[...new Set(series.flatMap(x=>[...x.map.keys()]))].filter(d=>state.annual||d>='2016-01').sort();
 const nums=series.flatMap(x=>[...x.map.values()]).filter(Number.isFinite);
 if(dates.length<2||!nums.length)return '<div class="person-empty">No hay datos suficientes para mostrar la evolución.</div>';
 let low=state.mode==='level'?Math.min(0,...nums):Math.min(...nums),high=Math.max(...nums);const pad=Math.max(1,(high-low)*.09);if(state.mode==='level'){high*=1.08;}else{low-=pad;high+=pad;}if(high===low)high=low+1;
 const W=930,H=340,L=60,R=14,T=22,B=50,w=W-L-R,h=H-T-B;
 const x=i=>L+i*w/(dates.length-1),y=n=>T+(high-n)*h/(high-low);
 const grid=Array.from({length:5},(_,i)=>{const n=low+(high-low)*i/4,yy=y(n);return `<line x1="${L}" x2="${W-R}" y1="${yy}" y2="${yy}"/><text x="${L-12}" y="${yy+4}" text-anchor="end">${safe(fmt(Math.round(n)))}</text>`}).join('');
 const steps=[...new Set(Array.from({length:6},(_,i)=>Math.round((dates.length-1)*i/5)))];
 const ticks=steps.map(i=>`<text x="${x(i)}" y="${H-12}" text-anchor="middle">${safe(state.annual?dates[i].slice(0,4):dt(dates[i]).replace(/^(.{3})[^ ]* /,'$1 '))}</text>`).join('');
 const lines=series.map(s=>{let d='',prev=-2;const pts=[];dates.forEach((t,i)=>{const n=s.map.get(t);if(!Number.isFinite(n))return;d+=(prev===i-1?'L':'M')+x(i).toFixed(1)+','+y(n).toFixed(1)+' ';prev=i;pts.push({i,n})});const markers=pts.length<dates.length*.45?pts.map(p=>`<circle cx="${x(p.i).toFixed(1)}" cy="${y(p.n).toFixed(1)}" r="3.2" fill="${s.color}" />`).join(''):'';return `<path d="${d}" stroke="${s.color}"/>${markers}`}).join('');
 const hits=dates.map((t,i)=>{const a=i?(x(i-1)+x(i))/2:L,b=i<dates.length-1?(x(i)+x(i+1))/2:W-R;return `<rect tabindex="0" class="person-hit" data-date="${t}" x="${a}" y="${T}" width="${b-a}" height="${h}"/>`}).join('');
 const legend=series.map(s=>`<span><i style="background:${s.color}"></i>${safe(s.name)}</span>`).join('');
 return `<div class="person-legend">${legend}</div><div class="person-plot"><svg viewBox="0 0 ${W} ${H}" aria-label="Serie histórica de personal">${grid}${ticks}${lines}${hits}</svg><div class="person-tooltip" hidden></div></div>`;
}
function bindPlot(){
 const plot=$('.person-plot');if(!plot)return;
 const tip=plot.querySelector('.person-tooltip'),ids=[FAL,...validPeers()];
 plot.querySelectorAll('.person-hit').forEach(rect=>{
   const show=()=>{const d=rect.dataset.date;const parts=ids.map(id=>({name:id===FAL?'Falabella':bank(id)?.nombre,value:plotValues(id).get(d)})).sort((a,b)=>(Number.isFinite(b.value)?b.value:-Infinity)-(Number.isFinite(a.value)?a.value:-Infinity)).map(row=>`<div><span>${safe(row.name)}</span><b>${Number.isFinite(row.value)?state.mode==='level'?safe(fmt(row.value)):safe(row.value.toFixed(2))+'%':'—'}</b></div>`).join('');
    tip.innerHTML=`<strong>${safe(dt(d))}</strong>${parts}`;tip.style.left=Math.max(12,Math.min(83,((+rect.getAttribute('x'))/930)*100))+'%';tip.hidden=false;
   };
   rect.addEventListener('pointerenter',show);rect.addEventListener('pointermove',show);rect.addEventListener('focus',show);rect.addEventListener('blur',()=>tip.hidden=true);
 });
 plot.addEventListener('pointerleave',()=>tip.hidden=true);
}
function download(){
 const ids=[FAL,...validPeers()];const rows=db.registros.filter(r=>ids.includes(r.banco));
 const head=['Periodo','Entidad','Gerentes','Funcionarios','Empleados','Otros','Total','Reporte SBS'];
 const out=[head,...rows.map(r=>[r.periodo,bank(r.banco)?.nombre,r.gerentes,r.funcionarios,r.empleados,r.otros,r.personal_total,r.fuente])];
 const str='\ufeff'+out.map(row=>row.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(';')).join('\r\n');
 const uri=URL.createObjectURL(new Blob([str],{type:'text/csv;charset=utf-8'}));const el=document.createElement('a');el.href=uri;el.download='Personal_SBS_IASPE.csv';el.click();setTimeout(()=>URL.revokeObjectURL(uri),1000);
}
function paint(){
 const host=$('#workspace');if(!host||!db)return;
 const current=lastDate(),date=comparableDate(),active=db.registros.filter(r=>r.periodo===date);
 const data=active.filter(r=>Number.isFinite(r[state.category])).map(r=>({...r,name:bank(r.banco)?.nombre||'Entidad'})).sort((a,b)=>b[state.category]-a[state.category]);
 const fal=data.find(x=>x.banco===FAL);
 const selectedPeer=validPeers().length===1?validPeers()[0]:null;
 const peer=selectedPeer?{...active.find(row=>row.banco===selectedPeer),banco:selectedPeer,name:bank(selectedPeer)?.nombre||selectedPeer}:null;
 const reference=peer||data.filter(x=>x.banco!==FAL).sort((a,b)=>b[state.category]-a[state.category])[0];
 const prev=db.registros.find(r=>r.periodo===`${+date.slice(0,4)-1}${date.slice(4)}`&&r.banco===FAL);
 const yoy=Number.isFinite(prev?.[state.category])&&Number.isFinite(fal?.[state.category])&&prev[state.category]!==0?100*(fal[state.category]/prev[state.category]-1):null;
 const options=CATS.map(([id,label])=>`<option value="${id}" ${id===state.category?'selected':''}>${safe(label)}</option>`).join('');
 const peerOptions=window.IASPEInstitutionGroups.html(db.bancos.filter(b=>b.id!==FAL),date,b=>`<label class="person-check ${b.registros?'':'is-missing'}"><input type="checkbox" value="${b.id}" ${state.peers.includes(b.id)?'checked':''} ${b.registros?'':'disabled'}/><span>${safe(b.name)}${b.registros?'':' · sin datos'}</span></label>`);
 const selected=validPeers().map(id=>bank(id)?.nombre).join(', ');
 const rows=(state.showAll?data:data.slice(0,6)).slice();
 if(!rows.some(r=>r.banco===FAL)&&fal)rows.push(fal);
 const max=Math.max(1,...data.map(x=>x[state.category]));
 const ranking=rows.map(r=>`<div class="person-rank ${r.banco===FAL?'is-fal':''}"><span>${safe(r.name)}</span><i><b style="width:${Math.max(2,r[state.category]/max*100)}%"></b></i><strong>${safe(fmt(r[state.category]))}</strong></div>`).join('');
 const detail=db.bancos.map(b=>{const r=active.find(x=>x.banco===b.id);return `<tr class="${b.id===FAL?'is-fal':''}"><td>${safe(b.nombre)}</td>${['gerentes','funcionarios','empleados','otros','personal_total'].map(k=>`<td>${r?safe(fmt(r[k])):'—'}</td>`).join('')}</tr>`}).join('');
 host.innerHTML=`<section class="person-workspace"><nav class="market-main-tabs"><a href="#benchmark/cartera">Cartera de consumo</a><a href="#benchmark/oficinas">Oficinas</a><a href="#benchmark/eeff">Estados financieros</a><a href="#benchmark/ratios">Indicadores financieros</a><a class="active" href="#benchmark/personal" aria-current="page">Personal</a></nav>
 <header class="person-heading"><h1>Personal</h1>${window.IASPESourceUpdates.control('personal',db.periodo_fin||current)}</header>
 <div class="person-controls"><label>Desagregación<select id="person-category">${options}</select></label><div class="person-compare"><label>Comparar con</label><details id="person-options"><summary>${safe(validPeers().length===1?selected:`${validPeers().length} entidades seleccionadas`)}</summary><div class="person-options"><input type="search" id="person-search" placeholder="Buscar entidad…"/><div class="person-options-list">${peerOptions}</div><button id="person-apply" type="button">Cerrar</button></div></details></div><label>Frecuencia<select id="person-frequency"><option value="m" ${state.annual?'':'selected'}>Mensual</option><option value="a" ${state.annual?'selected':''}>Diciembre</option></select></label><button class="person-csv" id="person-csv">CSV</button></div>
 <div class="person-summary"><div><small>Falabella</small><strong>${safe(fmt(fal?.[state.category]))}</strong><span>Personas · ${safe(dt(date))}</span></div><div><small>${safe(peer?.name||'Entidad de referencia')}</small><strong>${safe(fmt(reference?.[state.category]))}</strong><span>${safe(peer?'Comparación seleccionada':reference?.name||'Sin comparación')}</span></div><div><small>Variación anual · Falabella</small><strong>${yoy!=null?(yoy>0?'+':'')+safe(yoy.toFixed(1))+' %':'—'}</strong><span>Respecto al mismo mes del año anterior</span></div><div><small>Entidades con información</small><strong>${data.length} de ${db.bancos.length}</strong><span>${safe(dt(date))}</span></div></div>
 <div class="person-main"><div class="person-panel"><h2>Evolución de ${safe(CATS.find(c=>c[0]===state.category)[1].toLowerCase())}</h2><div class="person-view-tools"><div class="segmented"><button type="button" data-person-mode="level" class="${state.mode==='level'?'active':''}">Cantidad</button><button type="button" data-person-mode="growth" class="${state.mode==='growth'?'active':''}">Variación interanual</button></div><div class="segmented"><button type="button" data-person-panel="chart" class="${state.panel==='chart'?'active':''}">Gráfico</button><button type="button" data-person-panel="table" class="${state.panel==='table'?'active':''}">Tabla</button></div></div>${state.panel==='chart'?plot():historicalTable()}</div><aside class="person-panel person-aside"><div class="person-aside-title"><h2>Personal por entidad</h2><small>${safe(dt(date))}</small></div>${ranking}<button type="button" id="person-toggle">${state.showAll?'Mostrar menos':`Ver todas las entidades con datos`}</button></aside></div>
 <section class="person-panel person-detail"><div class="person-aside-title"><h2>Composición del personal</h2><small>${safe(dt(date))}</small></div><div class="person-table"><table><thead><tr><th>Entidad</th><th>Gerentes</th><th>Funcionarios</th><th>Empleados</th><th>Otros</th><th>Total</th></tr></thead><tbody>${detail}</tbody></table></div></section>
 </section>`;
 $('#person-category').onchange=e=>{state.category=e.target.value;paint()};
 $('#person-frequency').onchange=e=>{state.annual=e.target.value==='a';paint()};
 $('#person-toggle').onclick=()=>{state.showAll=!state.showAll;paint()};
 $('#person-csv').onclick=download;
 document.querySelectorAll('[data-person-mode]').forEach(btn=>btn.onclick=()=>{state.mode=btn.dataset.personMode;paint()});
 document.querySelectorAll('[data-person-panel]').forEach(btn=>btn.onclick=()=>{state.panel=btn.dataset.personPanel;paint()});
 const search=$('#person-search');if(search)search.oninput=e=>window.IASPEInstitutionGroups.filter($('.person-options-list'),'.person-check',e.target.value);
 document.querySelectorAll('.person-check input').forEach(checkbox=>checkbox.onchange=()=>{
   const selected=[...document.querySelectorAll('.person-check input:checked')].map(x=>x.value);
   if(!selected.length){checkbox.checked=true;app.toast('Selecciona al menos una entidad.');return;}
   const query=$('#person-search')?.value||'';
   const scroll=$('.person-options-list')?.scrollTop||0;
   state.peers=selected;
   paint();
   $('#person-options').open=true;
   $('#person-search').value=query;
   $('#person-search').dispatchEvent(new Event('input'));
   $('.person-options-list').scrollTop=scroll;
 });
 $('#person-apply').onclick=()=>{$('#person-options').open=false;};
 if(state.panel==='chart')bindPlot();
 window.IASPESourceUpdates.bind(app);
}
async function render(newApp){
 app=newApp;await window.IASPESourceUpdates.refresh(app).catch(()=>null);
  if(!location.hash.startsWith('#benchmark/personal'))return;
 const token=++request;$('#workspace').innerHTML='<div class="empty">Cargando personal SBS…</div>';
 try{pending||=app.api('/api/benchmark/personal');const loaded=await pending;if(token!==request||!location.hash.startsWith('#benchmark/personal'))return;db=loaded;if(!db.ready)throw Error(db.message||'No hay información SBS de personal.');paint();}
 catch(e){if(token!==request)return;pending=null;if(location.hash.startsWith('#benchmark/personal'))$('#workspace').innerHTML=`<div class="notice">${safe(e.message)}</div>`;}
}
function invalidate(){request++;db=null;pending=null;}
window.IASPEPersonalSBS={render,invalidate};
})();
