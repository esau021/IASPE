/* Ecuación, interpretación y resultados del modelo seleccionado. */
(() => {
  'use strict';
  let activeClose = null;
  const isNumber = value => typeof value === 'number' && Number.isFinite(value);
  const valueOf = coefficient => coefficient.value ?? coefficient.estimate;
  const rationales = {
    '01':'La actividad económica constituye una referencia para proyectar la evolución del número de tarjetas del mercado.',
    '02':'La expansión del crédito al consumo y el ritmo de actividad económica se incorporan mediante una relación de crecimiento anual.',
    '03':"El PBI aproxima el ciclo del consumo; la inflación recoge el componente nominal y la dicotómica 2020–2021 distingue la pandemia.",
    '04':'La evolución de las tarjetas propias del banco se estima con condiciones macroeconómicas, sin imponer una participación fija en el mercado.',
    '05':"El crecimiento contemporáneo de las compras transmite la actividad de tarjetas al saldo revolvente. La dicotómica de 2021 controla la discontinuidad de clasificación SBS.",
    '06':'La cartera no revolvente se proyecta mediante sus variaciones anuales, incorporando actividad, compras del mercado y la discontinuidad regulatoria de 2021.',
    '07':'El crédito de consumo total reúne las dos modalidades de colocaciones y permite evaluar su evolución conjunta.',
    '08':'El ahorro total se obtiene consolidando los saldos de captación por moneda y sus distintas dinámicas.',
    '09':'La captación a plazo reúne los depósitos ordinarios y la compensación por tiempo de servicios, con proyecciones diferenciadas.',
    '10':'La composición de las obligaciones con el público determina el volumen de fondeo y la participación de los depósitos a plazo.',
    '11':"La TPM representa las condiciones monetarias; la inflación recoge el entorno nominal y la participación a plazo rezagada refleja la composición previa del fondeo. La relación es predictiva, no causal.",
    '12':'La agregación de los distintos gastos de fondeo permite identificar el costo financiero total sin confundir partidas de origen distinto.',
    '13':'El nivel anterior de la tasa de tarjetas y el entorno monetario y económico proporcionan referencias para su evolución anual.',
    '14':'La tasa de crédito de consumo de mayor plazo se estima con la persistencia de su precio y la referencia monetaria.',
    '15':'La tasa pasiva incorpora la referencia monetaria vigente y el entorno de inflación del año anterior.',
    '16':'Los ingresos financieros se calculan a partir de los rendimientos y flujos de sus distintas fuentes de activos.',
    '17':'El disponible refleja partidas de liquidez con tratamientos propios y requiere consistencia con el balance completo.',
    '18':'Los ingresos y gastos asociados a servicios financieros se presentan netos para determinar su contribución al resultado.',
    '19':'Los gastos de administración integran dotación y contratación de servicios junto con otros conceptos operativos.',
    '20':'El resultado de operaciones financieras reúne fuentes de ingreso y gasto de mercado y negocios financieros.',
    '21':'La inversión financiera total refleja distintas clases de activos, incluidas las posiciones presupuestadas por Tesorería.',
    '22':'Los fondos interbancarios forman parte del activo financiero y se incorporan con su saldo previsto.',
    '23':'La diferencia entre ingresos y gastos financieros permite determinar el margen bruto del negocio.',
    '24':'Esta partida se mantiene según los supuestos financieros originales para integrar el resultado contable.',
    '25':"Cierre 2026: provisiones acumuladas SBS al último mes observado más los meses faltantes multiplicados por el promedio de los tres últimos flujos mensuales observados. A septiembre: 247.995 + 93.461 = 341.456 millones. Desde 2027, inputs de Riesgos sin cambios.",
    '26':'La depreciación y amortización recoge el reconocimiento contable del consumo de activos en el resultado.',
    '27':'Las valuaciones y otras provisiones se incluyen por su efecto en el resultado neto del ejercicio.',
    '28':'El impuesto a la renta permite pasar del resultado previo a impuestos al resultado neto.',
    '29':'El resultado neto sintetiza las cuentas del estado de resultados y conecta con la evolución del patrimonio.',
    '30':'Las líneas de crédito no utilizadas relacionan la exposición contingente con la cantidad prevista de tarjetas.',
    '31':'La actividad económica se incorpora para proyectar el crecimiento de las cuentas por cobrar netas.',
    '32':'La evolución de los ingresos de cartera aporta una referencia para el saldo de rendimientos pendientes de cobro.',
    '33':'Los activos fijos evolucionan con la inversión en capital y la depreciación prevista.',
    '34':'Los otros activos siguen los supuestos presupuestarios de sus componentes y su relación con la operación.',
    '35':'Los depósitos del sistema financiero se incorporan de acuerdo con la planificación de las fuentes de financiamiento.',
    '36':'Las obligaciones en circulación son una fuente de fondeo que debe reflejar sus montos presupuestados.',
    '37':'Las cuentas por pagar representan compromisos pendientes y se integran al financiamiento del balance.',
    '38':'Los intereses y gastos devengados por pagar completan el reconocimiento de obligaciones financieras.',
    '39':'Los otros pasivos se incorporan para reflejar las obligaciones presupuestadas fuera de las partidas específicas.',
    '40':'Las provisiones del pasivo incorporan compromisos estimados y su relación con partidas operativas.',
    '41':'El capital social forma parte de los fondos propios y se toma de las decisiones presupuestadas de capital.',
    '42':'El capital adicional integra los fondos patrimoniales según los saldos previstos.',
    '43':'Las reservas acumulan parte del patrimonio y sus movimientos afectan los resultados acumulados.',
    '44':'Los ajustes al patrimonio recogen variaciones patrimoniales específicas de la fuente contable.',
    '45':'La evolución de los resultados acumulados requiere conciliar la utilidad disponible, las reservas y los dividendos.',
    '46':'El resultado del ejercicio debe coincidir con la utilidad neta obtenida en el estado de resultados.',
    '47':'La identidad entre activo, pasivo y patrimonio permite verificar la consistencia del balance proyectado.',
    '48':'La actividad económica, el desempleo y la tasa monetaria previa permiten proyectar el conjunto del crédito de consumo de la banca.',
    '49':'Las amortizaciones se obtienen conciliando los movimientos de la cartera y permiten distinguir los productos de consumo.'
  };
  function rationale(model) {
    const id=String(model.id);
    const precision=window.IASPEPrecision?.rationales?.[id];
    if (precision) return precision;
    if (rationales[id]) return rationales[id];
    const specific=(model.economicRationale||model.rationale||'').trim();
    if(specific && !/^(MCO|Pronóstico original|Modelo IASPE Base|Consolidación original)/i.test(specific)) {
      return specific.replace(/;.*$/,'').replace(/\bMCO\b/g,'regresión por mínimos cuadrados ordinarios');
    }
    if (id.startsWith('47_')) return 'Esta partida permite verificar o completar los componentes del estado de situación financiera mediante la conciliación contable.';
    if (id.startsWith('49_')) return 'Este indicador permite identificar los movimientos de la cartera de consumo y distribuirlos entre sus productos.';
    if (id.startsWith('45_')) return 'Este movimiento permite conciliar los resultados disponibles con las variaciones patrimoniales.';
    if (id.startsWith('16_')) return 'Este componente permite identificar una fuente específica de ingresos por intereses dentro del resultado financiero.';
    if (id.startsWith('12_')) return 'Este componente permite identificar por separado el costo asociado a una fuente particular de financiamiento.';
    if (id.startsWith('18_')) return 'Este componente permite distinguir los ingresos y gastos que conforman el resultado por servicios financieros.';
    if (id.startsWith('19_')) return 'Este componente permite proyectar por separado una partida de los gastos de administración.';
    if (id.startsWith('20_')) return 'Esta partida permite identificar una fuente específica del resultado de operaciones financieras.';
    if (id.startsWith('21_')) return 'Esta partida representa una categoría de inversión que forma parte del activo financiero.';
    if (id.startsWith('08_') || id.startsWith('09_') || id.startsWith('10_')) return 'La proyección diferenciada de esta fuente de captación permite explicar la composición de las obligaciones con el público.';
    return 'El componente se incorpora a la proyección financiera conforme a su metodología y a la información de origen.';
  }

  function statPairs(model) {
    const s = model.statistics || {};
    const candidates = [
      ['Observaciones', s.nobs ?? s.observations ?? s.n, 0],
      ['R² ajustado', s.adjustedR2 ?? s.adjustedRSquared ?? s.rSquaredAdj ?? s.rsquared_adj, 4],
      ['R²', s.r2 ?? s.rSquared ?? s.rsquared, 4],
      ['AIC', s.aic, 3],
      ['BIC', s.bic, 3],
      ['Durbin–Watson', s.durbinWatson, 3],
      ['MAPE retrospectivo (%)', s.mapeRolling, 2],
      ['Período de estimación', s.period ?? s.calibrationPeriod ?? model.estimationPeriod],
      ['Inferencia', s.inference ?? s.covariance ?? s.covType],
      ['Ventana mensual', s.window, 0],
      ['Años de calibración', s.calibrationObservations, 0],
      ['Factor de calibración', s.calibrationFactor, 4]
    ];
    return candidates.filter(([, value]) => value !== undefined && value !== null && value !== '');
  }

  function renderableEquation(tex) {
    return String(tex || '')
      .replace(/\\ln\(\s*([^()]+?)\s*\/\s*([^()]+?)\s*\)/g, (_,a,b)=>String.raw`\ln\left(\frac{${a}}{${b}}\right)`)
      .replace(/(?<!\\)(PBI|TPM|Compras|Saldo|Caja|Bancos|Canje|Otros|RappiCash)(?=_|\b)/g, (_,x)=>String.raw`\mathrm{${x}}`);
  }

  function equations(model) {
    const main = model.estimatedEquationTex || model.equationTex || model.equationLatex || '';
    const parts = main.split(/;\s*\\quad\s*|,\s*\\quad\s*/).map(part=>part.trim()).filter(Boolean);
    const symbolic = model.equationTex || '';
    if (model.estimatedEquationTex && symbolic !== main && symbolic.includes('100\\ln')) {
      const transform = symbolic.split(/,\\quad\s*/).slice(1).join(',\\quad ');
      if (transform) parts.push(transform);
    }
    if (model.financialIdentityTex && !parts.includes(model.financialIdentityTex)) parts.push(model.financialIdentityTex);
    return parts.map(renderableEquation);
  }

  function periodText(value) {
    if (Array.isArray(value)) return value.join(' – ');
    if (value && typeof value === 'object') return [value.start, value.end].filter(Boolean).join(' – ');
    return String(value);
  }

  function coefficientExplanation(model, coefficient) {
    if (coefficient.interpretation || coefficient.description) return coefficient.interpretation || coefficient.description;
    const name = String(coefficient.name || coefficient.variable || '').toLowerCase();
    if (name.includes('constante')) return 'Intercepto de la ecuación estimada. Su interpretación depende de las transformaciones y del resto de regresoras.';
    if (model.id === '16') {
      if (name.includes('rezagado')) return 'Relaciona un punto porcentual adicional de rendimiento en el año anterior con el rendimiento previsto del año actual, manteniendo las demás regresoras.';
      if (name.includes('variación') || name.includes('variacion')) return 'Relaciona un punto porcentual adicional de variación anual en la tasa de tarjetas del mercado con el rendimiento propio previsto. No convierte esa tasa de mercado en el rendimiento del banco.';
      if (name.includes('dicotómica') || name.includes('dicotomica')) return 'El indicador toma uno en 2020 y 2021 y cero en los demás años. El coeficiente recoge la diferencia condicional asociada a esos períodos.';
    }
    const inputs = model.inputs || [];
    const key = coefficient.variable;
    const input = inputs.find(x => x.variable === key || x.id === key) || inputs.find(x => {
      const term = String(x.name || '').toLowerCase();
      return term && (name.includes(term) || term.includes(name));
    });
    if (input?.interpretation) return input.interpretation;
    if (name.includes('2024') && name.includes('2025')) return 'El indicador toma uno en 2024 y 2025 y cero fuera de esos años. El coeficiente recoge una diferencia de crecimiento en esos períodos.';
    if (model.id === '11' && name.includes('participación')) return 'Relaciona un punto porcentual adicional de participación de los depósitos a plazo con el costo implícito previsto, dadas la TPM y la inflación del año actual.';
    if (model.id === '11' && name.includes('rezagado')) return 'Recoge la composición de depósitos del año anterior.';
    return 'El coeficiente relaciona una unidad adicional de esta regresora con la variable dependiente, dadas las demás entradas. La unidad y el rezago se leen en el nombre de la variable y en la ecuación.';
  }

  function statisticsHTML(app, model) {
    const e = app.escape, coefficients = model.coefficients || [];
    const pairs = statPairs(model);
    const interval = coefficients.some(c => isNumber(c.ciLow ?? c.lower) && isNumber(c.ciHigh ?? c.upper));
    const numeric = (value, digits = 6) => isNumber(value) ? app.fmt(value, digits) : '—';
    const pValue = value => isNumber(value) ? value < 0.0001 ? '&lt; 0.0001' : app.fmt(value, 4) : '—';
    const heading = coefficients.length ? 'Resultados estadísticos' : model.statistics?.calibrationFactor !== undefined ? 'Calibración' : 'Detalle del método';
    if (!pairs.length && !coefficients.length) return '';
    return `<details class="iaspe-spec-fold" data-spec-statistics><summary>${heading}</summary><div class="iaspe-spec-stat-list">${pairs.map(([name, value, digits]) => `<div><dt>${e(name)}</dt><dd>${isNumber(value) ? app.fmt(value, digits ?? 4) : e(periodText(value))}</dd></div>`).join('')}</div>${coefficients.length ? `<div class="iaspe-spec-table-wrap"><table class="iaspe-spec-table"><thead><tr><th>Variable</th><th>Coeficiente</th><th>Error estándar</th><th>Valor p</th>${interval ? '<th>IC 95%</th>' : ''}</tr></thead><tbody>${coefficients.map((c, i) => `<tr><td><button type="button" class="iaspe-spec-coefficient" data-spec-coefficient="${i}">${e(window.IASPEExplanations?.label(model,i)||c.name||c.variable||c.term)}</button></td><td title="${e(valueOf(c))}">${numeric(valueOf(c))}${c.significance ? `<sup>${e(c.significance)}</sup>` : ''}</td><td>${numeric(c.se ?? c.stdError)}</td><td title="${e(c.pValue ?? c.p_value)}">${pValue(c.pValue ?? c.p_value)}</td>${interval ? `<td>${isNumber(c.ciLow ?? c.lower) && isNumber(c.ciHigh ?? c.upper) ? `[${numeric(c.ciLow ?? c.lower, 4)}; ${numeric(c.ciHigh ?? c.upper, 4)}]` : '—'}</td>` : ''}</tr>`).join('')}</tbody></table></div><div class="iaspe-spec-coefficient-detail" data-spec-coefficient-detail hidden></div>` : ''}</details>`;
  }

  const noteLabels = new Map([
    ['Las proyecciones desde 2027 son anuales; no se reparte el flujo entre meses.', 'Proyecciones anuales desde 2027.'],
    ['La proyección MCO es anual; no se fabrica un perfil mensual desde 2027.', 'Proyección MCO anual desde 2027.'],
    ['Los pronósticos de 2027–2030 son cierres anuales; no existe una distribución mensual autorizada.', 'Cierres anuales de 2027 a 2030.'],
    ['Pronóstico anual. No existe una distribución mensual proyectada desde 2027.', 'Pronóstico anual desde 2027.'],
    ['La consolidación futura es anual: no se interpolan ahorro ni plazo.', 'Consolidación de los cierres anuales.'],
    ['Suma de los cierres anuales de los Modelos 05 y 06. No se suman meses ni se inventa la senda mensual del Modelo 05.', 'Suma del saldo bruto de tarjetas y de los préstamos de consumo no revolventes al cierre de cada año.'],
    ['La ruta de participación fija del libro Participacion_Falabella es distinta de esta regresión propia.', 'La proyección utiliza una regresión propia del número de tarjetas de Falabella.'],
    ['El Modelo 06 utiliza directamente el PBI real anual; no se generan trayectorias mensuales.', 'La muestra 2016–2026 incluye el cierre supuesto de 2026 y la discontinuidad SBS de 2021; contrastar la sensibilidad de los coeficientes al excluir 2026.'],
    ['La participación de plazo se calcula al cierre, no con promedios mensuales.', 'La participación de plazo utiliza los saldos al cierre.'],
    ['La reversión utiliza promedios de dos cierres anuales, no saldos diarios.', 'El cálculo utiliza el promedio de dos cierres anuales.'],
    ['Cierre de 2026 igual a la última tasa mensual observada; agosto en el input original.', 'El cierre de 2026 utiliza la última tasa mensual observada.']
  ]);
  function presentationNote(value) {
    const text = String(value ?? '').trim();
    if (!text || text.startsWith('No se inventan') || text === 'No se distribuyen los ingresos pronosticados anuales en meses.') return '';
    return (noteLabels.get(text) || text)
      .replace('; no se crea una senda mensual futura.', '.')
      .replace('El cierre es diciembre, no la suma mensual.', 'El saldo anual corresponde a diciembre.');
  }

  function contentHTML(app, model) {
    // Para las aperturas contables M49 no existen coeficientes ni inferencia estadística.
    // Compartimos el mismo encabezado y los desplegables del resto de las fichas.
    if (window.IASPEComplementarios?.isAmortization?.(model.id)) {
      const e = app.escape;
      return `<header class="iaspe-spec-header"><div><span class="iaspe-spec-label">Ecuación y sustento</span><h2 id="iaspe-spec-title">${e(model.name)}</h2><p>Identidad contable y apertura por producto</p></div><button type="button" class="iaspe-spec-close" aria-label="Cerrar ecuación y sustento">×</button></header><div class="iaspe-spec-content">${window.IASPEComplementarios.amortizationSpec(app,model)}</div>`;
    }
    const e = app.escape, formulas = equations(model);
    const motive = rationale(model);
    const formulaHTML = formulas.length
      ? `<section class="iaspe-spec-formula" aria-label="Ecuación del modelo">${formulas.map((tex, i) => `<div class="iaspe-spec-math ${i ? 'iaspe-spec-math-secondary' : ''}" data-spec-tex="${e(tex)}"></div>`).join('')}</section>`
      : `<section class="iaspe-spec-formula" aria-label="Metodología del modelo"><p class="iaspe-spec-method-only">${e(window.IASPEMethodLabel?.(model)||model.method||"Regla de proyección registrada en la fuente")}</p></section>`;
    // Explicación breve del factor en la MISMA ficha de gastos por obligaciones;
    // es la mediana histórica, no un coeficiente estimado en una regresión.
    const factorBrief=String(model.id)==='12_obligaciones'
      ? `<p><strong>Factor histórico (0,9764):</strong> para cada año, <span data-spec-inline-tex="${e(String.raw`f_t=\frac{G_t}{\bar O_t\,\bar C_t/100}`)}"></span>, donde G es el gasto anual, O el saldo medio y C el costo medio. Aplicamos la <strong>mediana de 2015 a 2026</strong>; el dato de 2026 es un cierre supuesto.</p>`
      : '';
    const motiveHTML = `<section class="iaspe-spec-rationale"><h3>Sustento</h3><p>${e(motive)}</p>${factorBrief}</section>`;
    const note=window.IASPEModelNotes?.note(model)||'';
    const closureHTML=note?`<details class="iaspe-spec-fold iaspe-spec-note-fold" data-spec-closure><summary>Nota sobre el cierre de 2026 y la proyección posterior</summary><div class="iaspe-spec-closing"><p>${e(note)}</p></div></details>`:'';
    return `<header class="iaspe-spec-header"><div><span class="iaspe-spec-label">Ecuación y sustento</span><h2 id="iaspe-spec-title">${e(model.name)}</h2><p>${e(window.IASPEMethodLabel?.(model) || model.role || '')}</p></div><button type="button" class="iaspe-spec-close" aria-label="Cerrar ecuación y sustento">×</button></header><div class="iaspe-spec-content">${formulaHTML}${motiveHTML}${window.IASPEExplanations?.render(app,model)||''}${statisticsHTML(app,model)}${closureHTML}</div>`;
  }

  function open(app, id) {
    const source = app.model(id);
    const model = source && window.IASPEModelFichas?.enrich(source);
    if (!model) { app.toast?.('Selecciona un modelo.'); return null; }
    if (activeClose) activeClose(false);
    const previousFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    const overlay = document.createElement('div');
    overlay.className = 'iaspe-spec-overlay';
    overlay.innerHTML = `<section class="iaspe-spec-dialog" role="dialog" aria-modal="true" aria-labelledby="iaspe-spec-title" tabindex="-1">${contentHTML(app, model)}</section>`;
    document.body.appendChild(overlay);
    document.body.style.overflow = 'hidden';
    const dialog = overlay.querySelector('.iaspe-spec-dialog');
    const closeButton = overlay.querySelector('.iaspe-spec-close');
    const close = (restoreFocus = true) => {
      if (!overlay.isConnected) return;
      overlay.remove();
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', keydown, true);
      window.removeEventListener('hashchange', hashchange);
      activeClose = null;
      if (restoreFocus && previousFocus?.isConnected) previousFocus.focus({preventScroll: true});
    };
    const keydown = event => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); close(); return; }
      if (event.key === 'Tab') {
        const focusable = [...dialog.querySelectorAll('button,summary,[href],input,select,textarea,[tabindex="0"]')]
          .filter(element => !element.disabled && element.getClientRects().length);
        const first = focusable[0], last = focusable.at(-1);
        if (!first) { event.preventDefault(); dialog.focus(); }
        else if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    const openHash=window.location.hash;
    const hashchange = () => {if(window.location.hash!==openHash)close(false);};
    closeButton.addEventListener('click', () => close());
    overlay.addEventListener('click', event => { if (event.target === overlay) close(); });
    document.addEventListener('keydown', keydown, true);
    window.addEventListener('hashchange', hashchange);
    overlay.querySelectorAll('[data-spec-tex], [data-spec-inline-tex]').forEach(element => {
      const display=element.hasAttribute('data-spec-tex');
      const tex=display?element.dataset.specTex:element.dataset.specInlineTex;
      if (window.katex) window.katex.render(tex, element, {displayMode:display, throwOnError:false, trust:false, strict:'ignore'});
      else element.textContent=tex;
    });
    overlay.querySelectorAll('[data-spec-coefficient]').forEach(button => button.addEventListener('click', () => {
      const coefficient = model.coefficients[Number(button.dataset.specCoefficient)], value = valueOf(coefficient);
      const detail = overlay.querySelector('[data-spec-coefficient-detail]');
      overlay.querySelectorAll('[data-spec-coefficient]').forEach(other => other.setAttribute('aria-expanded', String(other === button)));
      detail.hidden = false;
      const index=Number(button.dataset.specCoefficient);
      const interpretation=window.IASPEFichaInteractions?.interpretation?.(model,coefficient,index);
      const fallback=coefficientExplanation(model,coefficient);
      const refs=window.IASPEFichaInteractions?.links?.(app,model,index,window.IASPEExplanations?.terms?.(model)?.[index])||[];
      detail.innerHTML = `<h4>${app.escape(window.IASPEExplanations?.label(model,index)||coefficient.name||coefficient.variable)}</h4><p>${window.IASPEExplanations?.inline?.(app,interpretation||fallback)||app.escape(fallback)}</p>${refs.length?`<div class="iaspe-coefficient-source">${refs.map(id=>`<button type="button" class="iaspe-model-source-link" data-spec-source-model="${app.escape(id)}">Ver modelo ${app.escape(id)} ↗</button>`).join('')}</div>`:''}`;
      detail.querySelectorAll('[data-spec-inline-tex]').forEach(element => {if(window.katex) window.katex.render(element.dataset.specInlineTex,element,{displayMode:false,throwOnError:false,trust:false,strict:'ignore'});else element.textContent=element.dataset.specInlineTex;});
      detail.scrollIntoView({block: 'nearest', behavior: 'smooth'});
    }));
    overlay.addEventListener('click', event=>{
      const target=event.target.closest('[data-spec-source-model]');
      if(!target || !overlay.contains(target))return;
      event.preventDefault();
      const sourceId=target.dataset.specSourceModel;
      if(!sourceId || !app.model?.(sourceId))return;
      close(false);
      app.navigate?.(sourceId==='48'?'benchmark/cartera':'modelo/'+sourceId);
      // Route changes update the underlying model page first; then open its ficha.
      setTimeout(()=>{
        const hash=String(window.location.hash||'');
        if(sourceId==='48' ? !hash.startsWith('#benchmark/cartera') : !hash.startsWith('#modelo/'+sourceId))return;
        window.IASPESpec?.open?.(app,sourceId);
      },90);
    });
    closeButton.focus({preventScroll: true});
    activeClose = close;
    return {close};
  }

  window.IASPESpec = {open, presentationNote};
})();
