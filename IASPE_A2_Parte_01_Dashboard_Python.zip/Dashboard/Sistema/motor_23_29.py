"""Importación fiel del P&L original y transmisión de variaciones verificadas.

Los resultados base se obtienen de los Excel sin modificar sus celdas. Los
impactos de insumos recalculados se propagan mediante identidades del P&L.
"""
from __future__ import annotations
from pathlib import Path
import math
from functools import lru_cache
from openpyxl import load_workbook
from rutas import buscar_modelo

NAMES = {
 '23':'Margen financiero bruto de Falabella',
 '24':'Otros ingresos y gastos de Falabella',
 '25':'Provisiones para créditos directos de Falabella',
 '26':'Depreciación y amortización de Falabella',
 '27':'Valuación de activos y otras provisiones de Falabella',
 '28':'Impuesto a la renta de Falabella',
 '29':'Resultado neto del ejercicio de Falabella',
}
DEPENDENCIES = {
 '23':['16','12','18','20'],
 '29':['23','24','25','26','27','28','18','19','20'],
}


def _folder(root, number):
    return buscar_modelo(root, number, opcional=True)


def _sheet(path, name=None):
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        sh = wb[name] if name and name in wb.sheetnames else wb.worksheets[0]
        return [list(row) for row in sh.values]
    finally:
        wb.close()


def _status(raw, year):
    text=str(raw or '').lower()
    if any(k in text for k in ('supuesto', 'imput', 'mixto')) or ('cierre' in text and 'observ' not in text): return 'assumed'
    if 'observ' in text or 'audit' in text: return 'observed'
    if 'pron' in text or 'proyec' in text: return 'forecast'
    return 'observed' if year <= 2025 else 'assumed' if year == 2026 else 'forecast'


def _records_rows(rows, val_col, status_col, start_index=1):
    out=[]
    for line in rows[start_index:]:
        if not line or not isinstance(line[0], (float,int)) or isinstance(line[0], bool): continue
        year=int(line[0])
        if not 1995<=year<=2045 or len(line)<=val_col:continue
        value=line[val_col]
        if not isinstance(value, (float,int)) or isinstance(value,bool):continue
        flag=line[status_col] if status_col is not None and len(line)>status_col else None
        out.append({'year':year,'value':float(value),'status':_status(flag,year),
                    'conditionSource':str(flag).strip() if flag is not None else ''})
    return sorted(out,key=lambda x:x['year'])


def _result_29(rows):
    if not rows: return []
    head=rows[0]
    final=next((r for r in rows[1:] if r and 'RESULTADO NETO DEL EJERCICIO' in str(r[0]).upper()),None)
    if final is None: return []
    series=[]
    for year,val in zip(head[1:],final[1:]):
        if not isinstance(year,(float,int)) or not isinstance(val,(float,int)):continue
        y=int(year)
        series.append({'year':y,'value':float(val),'status':_status('',y)})
    return series


def build_registry(root):
    result=[]
    for mid,title in NAMES.items():
        folder=_folder(root,mid)
        if folder is None: continue
        if mid=='23':
            path=folder/'Consolidado.xlsx';tab='Anual'
            if not path.is_file():continue
            series=_records_rows(_sheet(path,tab),8,11,start_index=3)
            method='Consolidación contable original (Excel)'
        elif mid=='24':
            path=folder/'Output'/'Pronostico.xlsx';tab='Anual'
            if not path.is_file():continue
            series=_records_rows(_sheet(path,tab),4,5,start_index=3)
            method='Pronóstico original (Excel)'
        elif mid=='29':
            path=folder/'Output'/'Pronostico.xlsx';tab='P&L SBS'
            if not path.is_file():continue
            series=_result_29(_sheet(path,tab))
            method='Cierre contable original del P&L (Excel)'
        else:
            path=folder/'Output'/'Pronostico.xlsx';tab='Anual'
            if not path.is_file():continue
            series=_records_rows(_sheet(path,tab),1,2,start_index=1)
            method='Pronóstico original (Excel)'
        if not series:continue
        result.append({
            'id':mid,'name':title,'unit':'S/ millones','frequency':'annual','kind':'flow',
            'annual':series,'monthly':[],'sourceFiles':[str(path)],
            'method':method,'status':'ok','canUpdate':mid in {'24', '25', '26', '27'},'scenarioSupport':False,
            'coefficients':[],'statistics':{},'equationTex':'',
            'dependencies':DEPENDENCIES.get(mid,[]),
            'inputs':[{'id':k,'lag':0} for k in DEPENDENCIES.get(mid,[])],
            'limitations':['Serie tomada del archivo original del modelo. Los resultados no se recalculan con cambios de supuestos macroeconómicos en esta versión.'],
            'closingRule':('Cierre provisional 2026 = acumulado SBS al último mes + meses restantes por promedio de los tres últimos flujos mensuales; 2027–2030 son inputs recibidos del banco.' if mid=='25' else 'Las observaciones proceden de SBS; las proyecciones futuras se incorporan de las áreas responsables.') if mid in {'24','25','26','27'} else 'Se respeta la condición de cada cierre del Excel original.',
        })
    return result


def recalculate(context,changes=None,observations=None):
    """Propagación contable a 23 y 29 usando las identidades SBS del original.

    No altera los Excel: trabaja sobre el registro de proyecciones en memoria.
    Los insumos con modelo de solo lectura permanecen idénticos a su fuente.
    """
    observations=observations or {}
    recibidos = {'24', '25', '26', '27'}
    forbidden = [mid for mid in NAMES if mid not in recibidos and observations.get(mid)]
    if forbidden:
        raise ValueError('Actualiza los componentes de los modelos: ' + ', '.join(forbidden))
    upstream = context.get('models') or {}
    original = context.get('original_models') or {}
    for mid in recibidos:
        for periodo, valor in observations.get(mid, {}).items():
            if len(str(periodo)) != 4 or not str(periodo).isdigit():
                raise ValueError('Las proyecciones recibidas se cargan por año.')
            year = int(periodo)
            if mid not in upstream:
                raise ValueError('No se encontró el Modelo ' + mid)
            fila = next((r for r in upstream[mid]['annual'] if r['year'] == year), None)
            if fila is None:
                raise ValueError('No existe el período solicitado para el Modelo ' + mid)
            if not isinstance(valor, (int, float)) or not math.isfinite(float(valor)):
                raise ValueError('Importe recibido no válido para Modelo ' + mid)
            if mid in {'25', '26'} and float(valor) < 0:
                raise ValueError('El importe del Modelo ' + mid + ' no puede ser negativo.')
            status = fila['status']
            fila.update(value=float(valor), status=status,
                        observed=float(valor) if status=='observed' else None,
                        assumed=float(valor) if status=='assumed' else None,
                        forecast=float(valor) if status=='forecast' else None, external=True)
            upstream[mid]['reestimated'] = False
    def year(model_id,y,source):
        return next((float(r['value']) for r in source[model_id]['annual'] if r['year']==y),None)
    def diff(model_id,y):
        if model_id not in upstream or model_id not in original:
            return 0.
        now=year(model_id,y,upstream);before=year(model_id,y,original)
        return 0. if now is None or before is None else now-before
    def update(model_id,y,amount):
        if model_id not in upstream or model_id not in original:
            raise ValueError('El modelo de destino no está disponible: '+model_id)
        base=year(model_id,y,original)
        if base is None:raise ValueError('Falta proyección de '+model_id+' para '+str(y))
        target=next(r for r in upstream[model_id]['annual'] if r['year']==y)
        if abs(float(target['value'])-(base+amount))<=1e-8 and upstream[model_id].get('status')!='needs_input':
            return False
        target['value']=float(base+amount)
        upstream[model_id]['reestimated']=True
        # Estos tres rubros se recalculan mediante identidades verificables.
        # Un cierre SBS provisional no puede conservar el estado «pendiente»
        # después de que su identidad esté nuevamente aplicada y auditada.
        if model_id in {'23','28','29'}:
            upstream[model_id]['canUpdate']=True
            upstream[model_id]['status']='ok'
            upstream[model_id].pop('issues',None)
        return True
    if not upstream or not original:
        return {'models':[upstream[k] for k in NAMES if k in upstream]}
    # M23 = ingreso por intereses M16 + otros ingresos financieros de origen
    #        - gastos por intereses M12 - primas FSD - otros gastos financieros.
    # El componente de pérdidas de negocios conjuntos (Modelo 23 / gasto financiero)
    # es -M20_consorcios menos la participación de asociadas, que se conserva.
    margin_rows={int(row[0]):row for row in _sheet(_folder(context['source_root'],'23')/'Consolidado.xlsx','Anual')
                 if isinstance(row[0],(int,float)) and 2026<=int(row[0])<=2030}
    for y in range(2026,2031):
        row=margin_rows[y]
        # Evaluar la misma identidad del Consolidado físico. Sus drivers
        # cacheados pueden proceder de una estimación anterior de M12/M16;
        # reemplazar el insumo por el vigente no equivale a sumar un delta
        # contra un driver que ese libro todavía no contenía.
        target_margin=(year('16',y,upstream)+float(row[2])+diff('20_tc',y)+diff('20_derivados',y)
                       -year('12',y,upstream)-year('18_fsd',y,upstream)
                       -float(row[6])+diff('20_consorcios',y))
        margin_delta=target_margin-year('23',y,original)
        update('23',y,margin_delta)
        # La planilla P&L SBS del Modelo 29 aplica estas identidades:
        # UAI = M23-M25+M18-M19-M26-M27+M24+venta cartera (sin cambio).
        before_tax=(diff('23',y)-diff('25',y)+diff('18',y)-diff('19',y)
                    -diff('26',y)-diff('27',y)+diff('24',y))
        # En la proyección original M28 = 27% * UAI, sin modificar la tasa fiscal.
        update('28',y,0.27*before_tax)
        update('29',y,0.73*before_tax)

    # La hoja original M29 puede contener gastos de administración calculados
    # con una versión anterior de M19. Los M19 actuales se conservaron en su
    # propio Excel y NO deben perderse al cerrar el estado de resultados.
    # Conciliar sobre la UAI original y transmitir la diferencia a M28/M29
    # con la política fiscal del cierre 2027-2030 (27%); ningún input se altera.
    pnl = _sheet(_folder(context['source_root'], '29') / 'Output' / 'Pronostico.xlsx', 'P&L SBS')
    header = pnl[0]
    columns = {int(v): j for j, v in enumerate(header) if isinstance(v, (int, float)) and 2026 <= int(v) <= 2030}
    lines = {str(row[0]).strip(): row for row in pnl[1:] if row and row[0] is not None}
    def pnl_value(label, year):
        row = lines[label]
        value = row[columns[year]]
        if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
            raise ValueError(f'M29: importe original inválido de {label} / {year}')
        return float(value)
    for y in range(2026, 2031):
        if y not in columns:
            raise ValueError(f'M29: falta el año {y} de la hoja P&L SBS')
        original_uai = pnl_value('RESULTADO ANTES DE IMPUESTOS', y)
        sale = pnl_value('(+/−) Venta de cartera', y)
        current_uai = (year('23', y, upstream) - year('25', y, upstream)
                       + year('18', y, upstream) + sale - year('19', y, upstream)
                       - year('26', y, upstream) - year('27', y, upstream)
                       + year('24', y, upstream))
        difference = current_uai - original_uai
        original_tax = pnl_value('(−) Impuesto a la renta', y)
        original_net = pnl_value('RESULTADO NETO DEL EJERCICIO', y)
        target_tax = original_tax + .27 * difference
        target_net = original_net + .73 * difference
        if abs(current_uai - target_tax - target_net) > 1e-6:
            raise ValueError(f'M29: no concilia utilidad, impuesto y UAI en {y}')
        # Las observaciones SBS cerradas no se sustituyen por el mecanismo.
        if any((next((r for r in upstream[mid]['annual'] if r['year'] == y), {})
                .get('status') == 'observed') for mid in ('28','29') if y >= 2026):
            continue
        update('28', y, target_tax - year('28', y, original))
        update('29', y, target_net - year('29', y, original))
    return {'models':[upstream[k] for k in NAMES if k in upstream]}
