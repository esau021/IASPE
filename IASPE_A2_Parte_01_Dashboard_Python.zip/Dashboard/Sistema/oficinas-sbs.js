/* Cobertura territorial de oficinas SBS. Geometría departamental original, sin dependencias. */
(()=>{
'use strict';
const $=selector=>document.querySelector(selector);
const FAL='05';
const MONTHS=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
const GROUPS=['Bancos','Empresas financieras','Cajas rurales'];
const GREENS=['#c7dfca','#96bf9d','#63a170','#347e49','#155632'];
const NAV='<nav class="market-main-tabs"><a href="#benchmark/cartera">Cartera de consumo</a><a class="active" href="#benchmark/oficinas" aria-current="page">Oficinas</a><a href="#benchmark/eeff">Estados financieros</a><a href="#benchmark/ratios">Indicadores financieros</a><a href="#benchmark/personal">Personal</a></nav>';
const state={mode:'map',institution:FAL,institutionA:FAL,institutionB:'11',period:null,selected:null,showAll:false,detailOpen:false,sort:'offices',direction:-1,compareSort:'offices',compareDirection:-1};
let app,db,pending,request=0,geometryReference,geometryShapes,refreshSelection=null;
const safe=value=>app.escape(String(value??''));
const number=value=>Number.isFinite(value)?new Intl.NumberFormat('es-PE').format(value):'—';
const percent=value=>Number.isFinite(value)?new Intl.NumberFormat('es-PE',{minimumFractionDigits:1,maximumFractionDigits:1}).format(value)+' %':'—';
const signed=value=>Number.isFinite(value)?(value>0?'+':'')+number(value):'—';
const month=value=>/^\d{4}-\d{2}$/.test(value||'')?`${MONTHS[Number(value.slice(5))-1]} ${value.slice(0,4)}`:value||'—';
const count=value=>Number.isInteger(value)&&value>=0?value:null;
const periods=id=>Object.keys(db?.series?.[id]||{}).filter(value=>/^\d{4}-\d{2}$/.test(value)).sort();
const record=id=>db.series?.[id]?.[state.period]||null;
const entity=id=>db.institutions.find(item=>item.id===id);
const entityName=id=>window.IASPEInstitutionGroups?.at(entity(id)||{id},state.period)?.name||entity(id)?.name||entity(id)?.nombre||id;
function territoryRows(departments,primary,peer){
 return departments.map(department=>{
  const a=count(primary?.counts?.[department.code]),b=count(peer?.counts?.[department.code]);
  const shareA=a!==null&&count(primary?.total)!==null&&primary.total>0?100*a/primary.total:null;
  const shareB=b!==null&&count(peer?.total)!==null&&peer.total>0?100*b/peer.total:null;
  return {...department,primary:a,comparator:b,offices:a,share:shareA,comparatorShare:shareB,difference:a!==null&&b!==null?a-b:null};
 });
}
function indicators(departments,observation){
 const rows=territoryRows(departments,observation,null),known=rows.filter(row=>row.offices!==null);
 const complete=known.length===departments.length,total=count(observation?.total);
 const top=complete?[...known].sort((a,b)=>b.offices-a.offices||a.name.localeCompare(b.name,'es'))[0]:null;
 return {total,known:known.length,presence:known.filter(row=>row.offices>0).length,complete,
  leader:top&&top.offices>0?top:null,concentration:top&&total>0?100*top.offices/total:null};
}
function sortedRows(rows,key,direction){
 return [...rows].sort((a,b)=>{
  if(key==='name')return direction*a.name.localeCompare(b.name,'es');
  if(a[key]===null&&b[key]!==null)return 1;if(b[key]===null&&a[key]!==null)return -1;
  return direction*((a[key]??0)-(b[key]??0))||a.name.localeCompare(b.name,'es');
 });
}
function fill(value,maximum){
 if(value===null)return 'url(#office-missing)';
 if(value===0)return '#f0f2ef';
 return GREENS[Math.min(4,Math.floor(value/Math.max(1,maximum)*5))];
}
function geographicPaths(geometry,width=600,height=570){
 const project=coordinate=>[coordinate[0]*Math.PI/180,-Math.log(Math.tan(Math.PI/4+coordinate[1]*Math.PI/360))];
 const coordinates=[];
 const visit=value=>{if(Array.isArray(value)&&typeof value[0]==='number'&&Number.isFinite(value[0])&&Number.isFinite(value[1]))coordinates.push(project(value));else if(Array.isArray(value))value.forEach(visit);};
 for(const feature of geometry?.features||[])visit(feature.geometry?.coordinates);
 if(!coordinates.length)return [];
 const bounds=coordinates.reduce((box,point)=>[Math.min(box[0],point[0]),Math.max(box[1],point[0]),Math.min(box[2],point[1]),Math.max(box[3],point[1])],[Infinity,-Infinity,Infinity,-Infinity]);
 const [xmin,xmax,ymin,ymax]=bounds;
 const scale=Math.min((width-36)/(xmax-xmin),(height-24)/(ymax-ymin));
 const offsetX=(width-(xmax-xmin)*scale)/2,offsetY=(height-(ymax-ymin)*scale)/2;
 const ring=points=>points.map((coordinate,index)=>{const p=project(coordinate);return `${index?'L':'M'}${(offsetX+(p[0]-xmin)*scale).toFixed(2)},${(offsetY+(p[1]-ymin)*scale).toFixed(2)}`;}).join('')+'Z';
 return (geometry?.features||[]).map(feature=>{
  const polygons=feature.geometry?.type==='Polygon'?[feature.geometry.coordinates]:feature.geometry?.type==='MultiPolygon'?feature.geometry.coordinates:[];
  const code=String(feature.properties?.code??feature.properties?.CCDD??'').padStart(2,'0');
  return {code,path:polygons.map(polygon=>polygon.map(ring).join('')).join('')};
 });
}
function activeInstitution(){return state.mode==='compare'?state.institutionA:state.institution;}
function allPeriods(){return [...new Set([...Object.values(db?.series||{}).flatMap(history=>Object.keys(history)),...(db?.periods||[]),...(state.period?[state.period]:[])])].filter(value=>/^\d{4}-\d{2}$/.test(value)).sort();}
function adoptData(loaded){
 const choice=refreshSelection;
 if(choice&&choice.mode===state.mode&&choice.id===activeInstitution()&&choice.period===state.period&&choice.latest===state.period){
  const latest=Object.keys(loaded.series?.[choice.id]||{}).sort().at(-1);
  if(latest&&latest>state.period)state.period=latest;
 }
 db=loaded;refreshSelection=null;
}
function options(selected){
 const groups=new Map(GROUPS.map(category=>[category,[]]));
 for(const item of db.institutions){const entry=window.IASPEInstitutionGroups?.at(item,state.period)||item;const category=entry.category||'Bancos';if(!groups.has(category))groups.set(category,[]);groups.get(category).push(entry);}
 return [...groups].filter(([,items])=>items.length).map(([category,items])=>`<optgroup label="${safe(category)}">${items.map(item=>`<option value="${safe(item.id)}" ${item.id===selected?'selected':''}>${safe(item.name||item.nombre||item.id)}</option>`).join('')}</optgroup>`).join('');
}
function periodOptions(){
 const values=allPeriods();return (!state.period?'<option value="" selected>Sin período seleccionado</option>':'')+values.reverse().map(value=>`<option value="${safe(value)}" ${value===state.period?'selected':''}>${safe(month(value))}</option>`).join('');
}
function mapHTML(rows,name){
 const maximum=Math.max(1,...rows.filter(row=>row.offices!==null).map(row=>row.offices));
 if(geometryReference!==db.geometry){geometryReference=db.geometry;geometryShapes=geographicPaths(db.geometry,440,570);}
 const paths=geometryShapes||[];
 const byCode=new Map(rows.map(row=>[row.code,row]));
 if(paths.length!==25||rows.length!==25||new Set(paths.map(path=>path.code)).size!==25||paths.some(path=>!byCode.has(path.code)))return '<div class="office-empty">La cartografía departamental no está disponible o no coincide con los 25 territorios.</div>';
 const shapes=paths.map(shape=>{const row=byCode.get(shape.code),label=`${row.name}: ${number(row.offices)} oficinas de ${name}${Number.isFinite(row.share)?', '+percent(row.share):''}`;return `<path d="${shape.path}" fill="${fill(row.offices,maximum)}" fill-rule="evenodd" data-office-department="${safe(row.code)}" role="button" tabindex="0" aria-label="${safe(label)}" aria-pressed="${row.code===state.selected}" class="${row.code===state.selected?'is-selected':''}"><title>${safe(label)}</title></path>`;}).join('');
 let scale;
 if(rows.some(row=>row.offices>0)){scale=`<span>1</span><i class="office-scale-green"></i><span>${safe(number(maximum))}</span>`;}
 else{scale=rows.some(row=>row.offices!==null)?'<span>Sin valores positivos en el periodo</span>':'<span>Sin información territorial disponible</span>';}
 return `<div class="office-map"><svg viewBox="0 0 440 570" role="group" aria-label="Mapa de oficinas de ${safe(name)}. 24 departamentos y Callao."><defs><pattern id="office-missing" width="7" height="7" patternUnits="userSpaceOnUse"><rect width="7" height="7" fill="#fafaf8"/><path d="M-2 2L2 -2M0 7L7 0M5 9L9 5" stroke="#c2c8c1" stroke-width="1"/></pattern></defs>${shapes}</svg><div class="office-tooltip" role="status" hidden></div></div><div class="office-legend"><span>Oficinas</span><div class="office-legend-scale">${scale}</div><span><i class="office-key-zero"></i>Sin oficinas</span><span><i class="office-key-missing"></i>Sin información</span></div>`;
}
function rankHTML(rows){
 const ordered=sortedRows(rows,'offices',-1),shown=state.showAll?ordered:ordered.slice(0,8);
 const maximum=Math.max(1,...rows.filter(row=>row.offices!==null).map(row=>Math.abs(row.offices)));
 return shown.map(row=>{
  const width=row.offices===null?0:row.offices/maximum*100;
  return `<button type="button" class="office-rank ${row.code===state.selected?'is-selected':''}" data-office-department="${safe(row.code)}" aria-pressed="${row.code===state.selected}"><span class="office-rank-name">${safe(row.name)}</span><strong>${safe(number(row.offices))}</strong><span class="office-rank-share">${safe(percent(row.share))}</span><span class="office-rank-track"><i style="width:${width}%;left:0%"></i></span></button>`;
 }).join('');
}
function tableHead(headers,comparison=false){
 const key=comparison?state.compareSort:state.sort,direction=comparison?state.compareDirection:state.direction;
 return `<thead><tr>${headers.map(([id,label])=>`<th scope="col" aria-sort="${key===id?(direction===1?'ascending':'descending'):'none'}"><button type="button" data-office-sort="${id}" data-office-sort-scope="${comparison?'compare':'map'}">${safe(label)}${key===id?(direction===1?' ↑':' ↓'):''}</button></th>`).join('')}</tr></thead>`;
}
function detailHTML(rows){
 const headers=[['name','Departamento'],['offices','Oficinas'],['share','Participación (%)']];
 return `<details id="office-detail" class="office-panel office-detail" ${state.detailOpen?'open':''}><summary><span>Detalle departamental</span><small>${safe(entityName(state.institution))} · ${safe(month(state.period))}</small></summary><div class="office-table"><table>${tableHead(headers)}<tbody>${sortedRows(rows,state.sort,state.direction).map(row=>`<tr data-office-row="${safe(row.code)}" class="${row.code===state.selected?'is-selected':''}"><th scope="row"><button type="button" data-office-department="${safe(row.code)}" aria-pressed="${row.code===state.selected}">${safe(row.name)}</button></th><td>${safe(number(row.offices))}</td><td>${Number.isFinite(row.share)?safe(new Intl.NumberFormat('es-PE',{minimumFractionDigits:1,maximumFractionDigits:1}).format(row.share)):'—'}</td></tr>`).join('')}</tbody></table></div></details>`;
}
function coverageText(observation){const stats=indicators(db.departments,observation);return observation&&stats.complete?`${stats.presence} de ${db.departments.length}`:'—';}
function compareHTML(){
 const a=record(state.institutionA),b=record(state.institutionB),nameA=entityName(state.institutionA),nameB=entityName(state.institutionB);
 const rows=territoryRows(db.departments,a,b),totalA=count(a?.total),totalB=count(b?.total),difference=totalA!==null&&totalB!==null?totalA-totalB:null;
 const maximum=Math.max(1,...rows.flatMap(row=>[row.offices,row.comparator]).filter(Number.isFinite));
 const cell=value=>`<span class="office-cell-value">${safe(number(value))}</span>${value!==null?`<i class="office-cell-bar" aria-hidden="true" style="width:${value/maximum*100}%"></i>`:''}`;
 const notice=!a||!b?`No existe información homogénea para ${month(state.period)}. ${!a?nameA:nameB}${!a&&!b?' y '+nameB:''} no ${!a&&!b?'tienen':'tiene'} datos de este período.`:rows.some(row=>row.primary===null||row.comparator===null)?'Hay territorios sin información. Las diferencias sólo se calculan donde ambas instituciones tienen datos.':'';
 return `<section class="office-panel office-comparison"><div class="office-panel-heading"><h2>Comparación departamental</h2><span>${safe(month(state.period))} · Diferencia A − B</span></div>${notice?`<p class="office-panel-caption office-comparison-notice" role="status">${safe(notice)}</p>`:''}<div class="office-coverage-summary"><span><b>${safe(nameA)}</b> · Cobertura: ${safe(coverageText(a))}</span><span><b>${safe(nameB)}</b> · Cobertura: ${safe(coverageText(b))}</span></div><div class="office-table office-comparison-table"><table class="office-dept-compare">${tableHead([['name','Departamento'],['offices',nameA],['comparator',nameB],['difference','Diferencia A − B']],true)}<tbody>${sortedRows(rows,state.compareSort,state.compareDirection).map(row=>`<tr data-office-comparison-row="${safe(row.code)}"><th scope="row">${safe(row.name)}</th><td>${cell(row.offices)}</td><td>${cell(row.comparator)}</td><td>${safe(signed(row.difference))}</td></tr>`).join('')}</tbody><tfoot><tr data-office-national><th scope="row">Perú</th><td>${safe(number(totalA))}</td><td>${safe(number(totalB))}</td><td>${safe(signed(difference))}</td></tr></tfoot></table></div></section>`;
}
function sourceInfo(){
 const ids=state.mode==='compare'?[state.institutionA,state.institutionB]:[state.institution];
 return `<footer class="office-sources"><span>Fuente: SBS · Información a ${safe(month(state.period))}</span><details class="office-source-info"><summary>Información de la fuente</summary><div><p>Ámbito: Perú, 24 departamentos y Callao. Excluye oficinas en el exterior, cajeros automáticos y corresponsales. La fila Perú utiliza los totales publicados; los territorios sin información permanecen ausentes.</p>${[...new Set(ids)].map(id=>{const observation=record(id),source=observation?.source;return `${count(observation?.outsidePeru)>0?`<p>${safe(entityName(id))}: total de la fuente ${safe(number(observation.sourceTotal))}; oficinas en el exterior ${safe(number(observation.outsidePeru))}.</p>`:''}${source?.url&&/^https:\/\//.test(source.url)?`<a href="${safe(source.url)}" target="_blank" rel="noopener noreferrer">${safe(source.report||'Reporte SBS')} · ${safe(entityName(id))}</a>`:''}`;}).join('')}${db.limitations?.length?'<p>Histórico con observaciones; se conservan las cifras individuales publicadas por la SBS.</p>':''}</div></details></footer>`;
}
function paint(){
 const host=$('#workspace');if(!host||!db)return;
 if(!state.period)state.period=periods(activeInstitution()).at(-1)||null;
 const name=entityName(state.institution),primary=record(state.institution),rows=territoryRows(db.departments,primary,null),stats=indicators(db.departments,primary);
 const modeControl=`<div class="office-mode" role="group" aria-label="Visualización de oficinas"><button type="button" data-office-mode="map" aria-pressed="${state.mode==='map'}" class="${state.mode==='map'?'active':''}">Mapa individual</button><button type="button" data-office-mode="compare" aria-pressed="${state.mode==='compare'}" class="${state.mode==='compare'?'active':''}">Comparar instituciones</button></div>`;
 const filters=state.mode==='map'?`<label>Institución financiera<select id="office-institution">${options(state.institution)}</select></label>`:`<label>Institución A<select id="office-a">${options(state.institutionA)}</select></label><label>Institución B<select id="office-b">${options(state.institutionB)}</select></label>`;
 const kpis=`<div class="office-kpis" aria-label="Indicadores de ${safe(name)}"><div><small>Oficinas</small><strong data-office-kpi="total">${safe(number(stats.total))}</strong><span>${safe(name)}</span></div><div><small>Cobertura</small><strong data-office-kpi="coverage">${primary&&stats.complete?`${stats.presence} de ${db.departments.length}`:'—'}</strong><span>${stats.complete?'24 departamentos y Callao':`${db.departments.length-stats.known} territorio${db.departments.length-stats.known===1?'':'s'} sin información`}</span></div><div><small>Mayor presencia</small><strong class="office-kpi-name" data-office-kpi="leader">${safe(stats.leader?.name||'—')}</strong><span>${stats.leader?number(stats.leader.offices)+' oficinas':stats.complete?'Sin oficinas registradas':'Información territorial incompleta'}</span></div><div><small>Concentración</small><strong data-office-kpi="concentration">${safe(percent(stats.concentration))}</strong><span>${safe(stats.leader?.name||'Departamento de mayor presencia')}</span></div></div>`;
 const individual=state.mode==='map'?`${kpis}${!db.ready||!primary?`<p class="office-notice" role="status">${safe(!db.ready?'No hay una base SBS validada de oficinas.':`Sin información de ${name} para ${month(state.period)}.`)}</p>`:''}<div class="office-main"><section class="office-panel office-geography"><div class="office-panel-heading"><h2>Distribución departamental</h2><span>${safe(name)}</span></div><p class="office-panel-caption">Número de oficinas · ${safe(month(state.period))}</p>${mapHTML(rows,name)}</section><aside class="office-panel office-ranking"><div class="office-panel-heading"><h2>Ranking departamental</h2><span>${state.showAll?'25 territorios':'8 de 25 territorios'}</span></div><p class="office-panel-caption">Oficinas y participación en ${safe(name)}</p><div class="office-ranking-list">${rankHTML(rows)}</div><button type="button" class="office-rank-toggle" id="office-rank-toggle">${state.showAll?'Mostrar los primeros 8':'Ver los 25 territorios'}</button></aside></div>${detailHTML(rows)}`:'';
 host.innerHTML=`<section class="office-workspace">${NAV}<header class="office-heading"><div><h1>Cobertura de oficinas</h1><p>${state.mode==='map'?`Distribución geográfica de oficinas de ${safe(name)}`:'Distribución departamental y comparación institucional'}</p></div>${window.IASPESourceUpdates.control('oficinas',periods(activeInstitution()).at(-1),true,db.checkedAt,db.lastCheck)}</header>${modeControl}<div class="office-controls ${state.mode==='compare'?'office-controls-compare':''}">${filters}<label>Periodo de información<select id="office-period">${periodOptions()}</select></label></div>${state.mode==='map'?individual:compareHTML()}${sourceInfo()}</section>`;
 $('#office-period').onchange=event=>{state.period=event.target.value;paint();};
 if(state.mode==='map'){
  $('#office-institution').onchange=event=>{state.institution=state.institutionA=event.target.value;paint();};
  $('#office-rank-toggle').onclick=()=>{state.showAll=!state.showAll;paint();};
  $('#office-detail').ontoggle=event=>{state.detailOpen=event.target.open;};
  bindDepartments(rows,name);revealRank();
 }else{
  $('#office-a').onchange=event=>{state.institutionA=state.institution=event.target.value;paint();};
  $('#office-b').onchange=event=>{state.institutionB=event.target.value;paint();};
 }
 document.querySelectorAll('[data-office-mode]').forEach(button=>button.onclick=()=>{state.mode=button.dataset.officeMode;paint();});
 document.querySelectorAll('[data-office-sort]').forEach(button=>button.onclick=()=>{const key=button.dataset.officeSort,comparison=button.dataset.officeSortScope==='compare',sort=comparison?'compareSort':'sort',direction=comparison?'compareDirection':'direction';state[direction]=key===state[sort]?-state[direction]:key==='name'?1:-1;state[sort]=key;paint();});
 window.IASPESourceUpdates.bind(app);
}
function revealRank(){
 const list=$('.office-ranking-list'),row=list?.querySelector(`[data-office-department="${state.selected}"]`);
 if(!row)return;
 const bounds=list.getBoundingClientRect(),selected=row.getBoundingClientRect();
 if(selected.top<bounds.top)list.scrollTop+=selected.top-bounds.top;
 else if(selected.bottom>bounds.bottom)list.scrollTop+=selected.bottom-bounds.bottom;
}
function selectDepartment(code){
 state.selected=state.selected===code?null:code;
 const ranking=$('.office-ranking-list');
 if(state.selected&&ranking&&!ranking.querySelector(`[data-office-department="${state.selected}"]`)){state.showAll=true;paint();return;}
 document.querySelectorAll('[data-office-department]').forEach(node=>{const selected=node.dataset.officeDepartment===state.selected;node.classList.toggle('is-selected',selected);node.setAttribute('aria-pressed',String(selected));});
 document.querySelectorAll('[data-office-row]').forEach(node=>node.classList.toggle('is-selected',node.dataset.officeRow===state.selected));
 revealRank();
}
function bindDepartments(rows,name){
 document.querySelectorAll('[data-office-department]').forEach(node=>{
  node.addEventListener('click',()=>selectDepartment(node.dataset.officeDepartment));
  if(node.tagName.toLowerCase()==='path')node.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();selectDepartment(node.dataset.officeDepartment);}});
 });
 const map=$('.office-map');if(!map)return;
 const tip=map.querySelector('.office-tooltip');
 map.querySelectorAll('[data-office-department]').forEach(path=>{
  const show=event=>{const row=rows.find(item=>item.code===path.dataset.officeDepartment);tip.innerHTML=`<strong>${safe(row.name)}</strong><span>${safe(row.offices===null?'Sin información':number(row.offices)+' oficinas de '+name)}</span><span>${Number.isFinite(row.share)?safe(percent(row.share)+' de '+name):'Participación no disponible'}</span>`;
   const box=map.getBoundingClientRect();tip.style.left=Math.max(8,Math.min(box.width-210,(event.clientX||box.left+box.width/2)-box.left+12))+'px';tip.style.top=Math.max(8,Math.min(box.height-94,(event.clientY||box.top+40)-box.top+12))+'px';tip.hidden=false;
  };
  path.addEventListener('pointerenter',show);path.addEventListener('pointermove',show);path.addEventListener('focus',show);path.addEventListener('pointerleave',()=>tip.hidden=true);path.addEventListener('blur',()=>tip.hidden=true);
 });
 map.addEventListener('pointerleave',()=>tip.hidden=true);
}
async function render(newApp){
 app=newApp;await window.IASPESourceUpdates.refresh(app).catch(()=>null);
 if(!location.hash.startsWith('#benchmark/oficinas'))return;
 const token=++request;const host=$('#workspace');host.innerHTML='<div class="empty">Cargando cobertura de oficinas SBS…</div>';
 try{pending||=app.api('/api/benchmark/oficinas');const loaded=await pending;if(token!==request||!location.hash.startsWith('#benchmark/oficinas'))return;adoptData(loaded);
  if(!db.ready&&!(db.geometry?.features?.length===25&&db.departments?.length===25&&db.institutions?.length))throw Error(db.message||'La base de oficinas SBS todavía no está disponible.');paint();
 }catch(error){if(token!==request)return;pending=null;if(location.hash.startsWith('#benchmark/oficinas'))host.innerHTML=`<section class="office-workspace">${NAV}<header class="office-heading"><div><h1>Cobertura de oficinas</h1><p>Distribución geográfica de oficinas del sistema financiero peruano</p></div>${window.IASPESourceUpdates.control('oficinas',periods(activeInstitution()).at(-1),true,db?.checkedAt,db?.lastCheck)}</header><p class="office-notice" role="status">${safe(error.message)}</p></section>`;window.IASPESourceUpdates.bind(app);}
}
function invalidate(){if(db)refreshSelection={mode:state.mode,id:activeInstitution(),period:state.period,latest:periods(activeInstitution()).at(-1)};request++;db=null;pending=null;}
window.IASPEOficinasSBS={render,invalidate};
})();
