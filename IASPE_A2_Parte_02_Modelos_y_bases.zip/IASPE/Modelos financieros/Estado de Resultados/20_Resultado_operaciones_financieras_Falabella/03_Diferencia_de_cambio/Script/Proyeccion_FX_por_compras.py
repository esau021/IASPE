"""Resultado cambiario ligado a actividad transaccional de tarjetas (M03)."""
from pathlib import Path
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[4]
M03 = ROOT / "Variables Operativas/03_Compras_tarjetas_mercado/Output/Pronostico.xlsx"
BASE = Path(__file__).resolve().parents[1] / "Output/Pronostico.xlsx"

def anual(path):
    book = load_workbook(path, read_only=True, data_only=True)
    try:
        values = {}
        for row in book["Anual"].iter_rows(min_row=2, values_only=True):
            if isinstance(row[0], (int, float)) and isinstance(row[1], (int, float)):
                values[int(row[0])] = float(row[1])
        return values
    finally:
        book.close()

def main():
    purchases = anual(M03)
    book = load_workbook(BASE, read_only=True, data_only=True)
    try:
        d = {int(r[0]): (r[1], r[2]) for r in book["Anual"].iter_rows(min_row=2, values_only=True) if isinstance(r[0],(int,float))}
    finally:
        book.close()
    fx26, derivatives26 = d[2026]
    ratio = (float(fx26)+float(derivatives26))/purchases[2026]
    for year in range(2027,2031):
        fx = ratio*purchases[year] - float(d[year][1])
        if abs(fx-float(d[year][0]))>0.001:
            raise ValueError(f"M20 no concilia en {year}: {fx:.6f}")
        print(year, round(fx,6))

if __name__ == "__main__":
    main()
