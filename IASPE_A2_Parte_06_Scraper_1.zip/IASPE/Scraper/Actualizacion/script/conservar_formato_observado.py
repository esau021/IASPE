"""Incorpora datos procesados en su plantilla XLSX sin rehacer la presentación."""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta
from decimal import Decimal
import hashlib
from io import BytesIO
import math
import os
from pathlib import Path
import re
import tempfile
import unicodedata
from zipfile import ZipFile

from lxml import etree as ET

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
PKG = '{http://schemas.openxmlformats.org/package/2006/relationships}'
KEYS = {'tarjetas': {'Mensual': ('anio', 'mes'), 'Anual': ('anio',), 'Fuentes': ('variable',)},
        'morosidad': {'Mensual': ('fecha',), 'Anual': ('ano',)}}


def _xml(body):
    return ET.fromstring(body, ET.XMLParser(resolve_entities=False, no_network=True))


def _normal(value):
    return ' '.join(unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().casefold().split())


def _column(reference):
    return re.match(r'[A-Z]+', reference)[0]


def _colnum(reference):
    value = 0
    for letter in _column(reference):
        value = value * 26 + ord(letter) - 64
    return value


class _Book:
    def __init__(self, body):
        with ZipFile(BytesIO(body)) as archive:
            self.entries = [(info, archive.read(info.filename)) for info in archive.infolist()]
        self.parts = {info.filename: data for info, data in self.entries}
        workbook = _xml(self.parts['xl/workbook.xml'])
        relations = _xml(self.parts['xl/_rels/workbook.xml.rels'])
        targets = {item.get('Id'): item.get('Target') for item in relations.findall(PKG + 'Relationship')}
        self.sheets = {}
        for sheet in workbook.findall(NS + 'sheets/' + NS + 'sheet'):
            target = targets[sheet.get(REL + 'id')].lstrip('/')
            self.sheets[sheet.get('name')] = target if target.startswith('xl/') else 'xl/' + target
        properties = workbook.find(NS + 'workbookPr')
        self.epoch = datetime(1904, 1, 1) if properties is not None and properties.get('date1904') in ('1', 'true') else datetime(1899, 12, 30)
        self.shared = []
        if 'xl/sharedStrings.xml' in self.parts:
            self.shared = [''.join(node.itertext()) for node in _xml(self.parts['xl/sharedStrings.xml']).findall(NS + 'si')]

    def value(self, cell):
        if cell is None:
            return None
        inline = cell.find(NS + 'is')
        if inline is not None:
            return ''.join(inline.itertext()) or None
        node = cell.find(NS + 'v')
        if node is None or node.text in (None, ''):
            if cell.find(NS + 'f') is not None:
                raise ValueError(f'Fórmula sin valor calculado en {cell.get("r")}')
            return None
        raw = node.text
        kind = cell.get('t', 'n')
        if kind == 's':
            return self.shared[int(raw)]
        if kind in ('str', 'inlineStr'):
            return raw
        if kind == 'b':
            return raw == '1'
        if kind == 'd':
            return datetime.fromisoformat(raw.replace('Z', '+00:00')).replace(tzinfo=None)
        if kind == 'e':
            raise ValueError(f'Celda con error Excel: {cell.get("r")}={raw}')
        number = Decimal(raw)
        if not number.is_finite():
            raise ValueError('Dato procesado no finito')
        return number


def _headers(book, root):
    first = root.find(NS + 'sheetData/' + NS + 'row')
    if first is None:
        raise ValueError('Hoja procesada sin encabezados')
    result = {}
    for cell in first.findall(NS + 'c'):
        value = book.value(cell)
        if value is None:
            continue
        name = _normal(value)
        if name in result:
            raise ValueError(f'Encabezado duplicado: {value}')
        result[name] = _column(cell.get('r'))
    return result


def _key(book, cells, headers, fields):
    values = [book.value(cells.get(headers[field])) for field in fields]
    if all(value is None for value in values):
        return None
    if any(value is None for value in values):
        raise ValueError('Clave mensual/anual incompleta')
    if fields == ('fecha',):
        value = values[0]
        if isinstance(value, Decimal):
            value = book.epoch + timedelta(days=float(value))
        elif not isinstance(value, datetime):
            value = datetime.fromisoformat(str(value)[:10])
        return value.year, value.month
    if fields[0] in ('anio', 'ano'):
        return tuple(int(value) for value in values)
    return tuple(str(value) for value in values)


def _rows(book, root, headers, fields):
    result = {}
    for row in root.findall(NS + 'sheetData/' + NS + 'row')[1:]:
        cells = {_column(cell.get('r')): cell for cell in row.findall(NS + 'c')}
        key = _key(book, cells, headers, fields)
        if key is None:
            continue
        if key in result:
            raise ValueError(f'Clave duplicada: {key}')
        result[key] = (row, cells)
    return result


def _equal(left, right):
    if isinstance(left, Decimal) and isinstance(right, Decimal):
        # Evita reemplazar precisión histórica por la serialización de pandas.
        return math.isclose(float(left), float(right), rel_tol=1e-14, abs_tol=1e-12)
    return left == right


def _put(cell, value, epoch):
    for child in list(cell):
        if child.tag in (NS + 'f', NS + 'v', NS + 'is'):
            cell.remove(child)
    cell.attrib.pop('t', None)
    if value is None:
        return
    if isinstance(value, datetime):
        value = Decimal(str((value - epoch).total_seconds() / 86400))
    if isinstance(value, bool):
        cell.set('t', 'b')
        ET.SubElement(cell, NS + 'v').text = '1' if value else '0'
    elif isinstance(value, Decimal):
        ET.SubElement(cell, NS + 'v').text = str(value)
    else:
        cell.set('t', 'inlineStr')
        text = ET.SubElement(ET.SubElement(cell, NS + 'is'), NS + 't')
        if str(value) != str(value).strip():
            text.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        text.text = str(value)


def _insert(parent, node, attribute, number):
    for index, child in enumerate(parent):
        key = child.get(attribute)
        if key is None:
            parent.insert(index, node)
            return
        current = int(key) if attribute == 'r' and key.isdigit() else _colnum(key)
        if current > number:
            parent.insert(index, node)
            return
    parent.append(node)


def _sheet(template, generated, name, fields):
    part = template.sheets[name]
    old = _xml(template.parts[part])
    source = _xml(generated.parts[generated.sheets[name]])
    headers, incoming = _headers(template, old), _headers(generated, source)
    if not set(headers).issubset(incoming) or not set(fields).issubset(headers):
        raise ValueError(f'{name}: cambiaron los encabezados o las claves originales')
    existing = _rows(template, old, headers, fields)
    additions = _rows(generated, source, incoming, fields)
    data = old.find(NS + 'sheetData')
    all_rows = {int(row.get('r')): row for row in data.findall(NS + 'row')}
    last = max((int(row.get('r')) for row, cells in existing.values()), default=1)
    last_cells = existing[max(existing)][1] if existing else {}
    added, changed, checks = 0, 0, 0
    for key in sorted(additions):
        original = existing.get(key)
        if original is None:
            if fields[0] in ('fecha', 'anio', 'ano') and existing and key < max(existing):
                raise ValueError(f'{name}: periodo histórico adicional requiere conservar la ordenación original')
            last += 1
            row = all_rows.get(last)
            if row is None:
                previous = all_rows[max(number for number in all_rows if number < last)]
                row = ET.Element(NS + 'row', dict(previous.attrib))
                row.set('r', str(last))
                _insert(data, row, 'r', last)
                all_rows[last] = row
            cells = {_column(cell.get('r')): cell for cell in row.findall(NS + 'c')}
            added += 1
        else:
            row, cells = original
        source_cells = additions[key][1]
        for header, column in headers.items():
            fresh = generated.value(source_cells.get(incoming[header]))
            cell = cells.get(column)
            before = template.value(cell) if cell is not None else None
            if original is not None and header in fields:
                checks += 1
                continue
            if before is not None and fresh is None:
                raise ValueError(f'{name}: la actualización vaciaría un dato válido ({column}{row.get("r")})')
            if not _equal(before, fresh):
                if cell is None:
                    attrs = {'r': column + row.get('r')}
                    if column in last_cells and last_cells[column].get('s') is not None:
                        attrs['s'] = last_cells[column].get('s')
                    cell = ET.Element(NS + 'c', attrs)
                    _insert(row, cell, 'r', _colnum(column))
                    cells[column] = cell
                if header == 'fecha' and isinstance(fresh, Decimal) and generated.epoch != template.epoch:
                    fresh = generated.epoch + timedelta(days=float(fresh))
                _put(cell, fresh, template.epoch)
                changed += 1
            checks += 1
        last_cells = cells
    max_row = max(all_rows, default=1)
    def expand(reference):
        match = re.fullmatch(r'(\$?[A-Z]+\$?\d+):(\$?[A-Z]+)(\$?)(\d+)', reference or '')
        if not match or int(match[4]) >= max_row:
            return reference
        return f'{match[1]}:{match[2]}{match[3]}{max_row}'
    for dimension in old.findall(NS + 'dimension'):
        dimension.set('ref', expand(dimension.get('ref')))
    for auto in old.findall(NS + 'autoFilter'):
        for node in auto.iter():
            if node.get('ref'):
                node.set('ref', expand(node.get('ref')))
    body = template.parts[part] if changed == 0 else ET.tostring(old, encoding='UTF-8', xml_declaration=True, standalone=True)
    return body, {'sheet': name, 'added_rows': added, 'updated_cells': changed,
                  'checked_cells': checks, 'compatible_columns': len(headers),
                  'ignored_extra_columns': sorted(set(incoming) - set(headers))}


def conservar_formato_observado(path, plantilla: bytes, *, tipo: str):
    """Restaura la presentación previa y conserva los datos del XLSX generado."""
    if tipo not in KEYS:
        raise ValueError('Tipo de procesado no reconocido')
    path = Path(path)
    if path.suffix.lower() != '.xlsx' or not path.is_file():
        raise ValueError('Falta el XLSX procesado que debe conservarse')
    generated_body = path.read_bytes()
    template, generated = _Book(plantilla), _Book(generated_body)
    required = KEYS[tipo]
    if not set(required).issubset(template.sheets) or not set(required).issubset(generated.sheets):
        raise ValueError('Faltan hojas originales del procesado')
    replacements, audit = {}, []
    for name, fields in required.items():
        replacements[template.sheets[name]], result = _sheet(template, generated, name, fields)
        audit.append(result)
    buffer = BytesIO()
    with ZipFile(buffer, 'w') as archive:
        for info, body in template.entries:
            archive.writestr(info, replacements.get(info.filename, body))
    repaired = buffer.getvalue()
    check = _Book(repaired)
    if list(check.sheets) != list(template.sheets):
        raise ValueError('Cambió el orden de hojas al conservar el formato')
    for name, fields in required.items():
        final_root = _xml(check.parts[check.sheets[name]])
        final_headers = _headers(check, final_root)
        final_rows = _rows(check, final_root, final_headers, fields)
        source_root = _xml(generated.parts[generated.sheets[name]])
        source_headers = _headers(generated, source_root)
        for key, (row, cells) in _rows(generated, source_root, source_headers, fields).items():
            if key not in final_rows:
                raise ValueError(f'{name}: no se conservó el periodo {key}')
            for header in final_headers:
                if header in fields:
                    continue
                expected = generated.value(cells.get(source_headers[header]))
                actual = check.value(final_rows[key][1].get(final_headers[header]))
                if not _equal(actual, expected):
                    raise ValueError(f'{name}: dato diferente después de conservar formato ({key}/{header})')
    temp = None
    try:
        with tempfile.NamedTemporaryFile(prefix='.' + path.stem + '.', suffix='.tmp', dir=path.parent, delete=False) as handle:
            temp = Path(handle.name)
            handle.write(repaired)
        os.replace(temp, path)
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)
    return {'status': 'preserved', 'type': tipo,
            'templateSha256': hashlib.sha256(plantilla).hexdigest(),
            'generatedSha256': hashlib.sha256(generated_body).hexdigest(),
            'finalSha256': hashlib.sha256(repaired).hexdigest(),
            'sheets': audit, 'ignoredExtraSheets': sorted(set(generated.sheets) - set(template.sheets)),
            'numericComparisonTolerance': {'relative': 1e-14, 'absolute': 1e-12}}
