"""Strict, coordinate-based readers of official BCRP PDF tables.

No network, storage, model estimation or Dashboard dependency. Every number is
associated with a geometric cell and independently checked with PyMuPDF.
"""
from __future__ import annotations

import hashlib
import io
import math
import re
import unicodedata
from decimal import Decimal, InvalidOperation
from pathlib import Path

SCHEMA_VERSION = "1.0"
MONTHS = {"ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6,
          "jul": 7, "ago": 8, "sep": 9, "set": 9, "oct": 10, "nov": 11, "dic": 12}
NUMBER = re.compile(r"[-−]?\d+(?:[,.]\d+)?\Z")


class BCRPExtractionError(ValueError):
    """Unidentified, ambiguous, incomplete, or conflicting document/table."""


def _norm(text):
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().lower()


def _decimal(token):
    if not NUMBER.fullmatch(token):
        raise BCRPExtractionError(f"Non-numeric table cell: {token!r}")
    try:
        return Decimal(token.replace("−", "-").replace(",", "."))
    except InvalidOperation as exc:
        raise BCRPExtractionError(f"Invalid number: {token!r}") from exc


def _visible_words(page):
    # Some BCRP print PDFs retain neighbouring sheets OUTSIDE MediaBox. These
    # words include stale edition labels and duplicate tables; never read them.
    return [w for w in page.extract_words(x_tolerance=2, y_tolerance=2)
            if 0 <= w["x0"] < w["x1"] <= page.width
            and 0 <= w["top"] < w["bottom"] <= page.height]


def _lines(words, tolerance=2):
    lines = []
    for word in sorted(words, key=lambda w: ((w["top"]+w["bottom"])/2, w["x0"])):
        cy = (word["top"] + word["bottom"]) / 2
        candidates = [line for line in lines if abs(line["cy"] - cy) <= tolerance]
        # Different font sizes in surrounding prose can overlap baseline bands.
        # This only reconstructs candidate labels. Cell uniqueness and grid
        # membership are validated separately before any value is accepted.
        candidates.sort(key=lambda line: abs(line["cy"]-cy))
        if candidates:
            candidates[0]["words"].append(word)
        else:
            lines.append({"cy": cy, "words": [word]})
    for line in lines:
        line["words"].sort(key=lambda w: w["x0"])
        line["text"] = " ".join(w["text"] for w in line["words"])
    return lines


def _bbox(words):
    return [min(w["x0"] for w in words), min(w["top"] for w in words),
            max(w["x1"] for w in words), max(w["bottom"] for w in words)]


def _cluster(values, tolerance=.8):
    out = []
    for value in sorted(values):
        if not out or value - out[-1][-1] > tolerance:
            out.append([value])
        else:
            out[-1].append(value)
    return [sum(group) / len(group) for group in out]


def _cover_edition(page):
    """Read an isolated visible month/year title, not prose dates or filename."""
    matches = []
    for line in _lines(_visible_words(page)):
        match = re.fullmatch(r"(enero|febrero|marzo|abril|mayo|junio|julio|agosto|"
                             r"setiembre|septiembre|octubre|noviembre|diciembre) (20\d{2})",
                             _norm(line["text"]))
        if match:
            matches.append((f"{match[2]}-{MONTHS[match[1][:3]]:02d}", _bbox(line["words"])))
    if len(matches) != 1:
        raise BCRPExtractionError("RI cover does not identify one visible edition")
    return matches[0]


def _ri_table(page, page_no, edition, fitz_page, name, sha, source_url):
    words = _visible_words(page)
    if "resumen de las proyecciones" not in _norm(" ".join(w["text"] for w in words)):
        return None
    lines = _lines(words)
    titles = [line for line in lines if _norm(line["text"]) == "resumen de las proyecciones"]
    if not titles:
        return None
    if len(titles) != 1:
        raise BCRPExtractionError("Multiple visible RI summary tables on a page")
    title = titles[0]
    pbi = [line for line in lines if re.match(r"^\d+\.\s+producto bruto interno\b", _norm(line["text"]))
           and line["cy"] > title["cy"]]
    inf = [line for line in lines if re.match(r"^\d+\.\s+inflaci\w* \(fin de periodo\)", _norm(line["text"]))
           and line["cy"] > title["cy"]]
    if len(pbi) != 1 or len(inf) != 1:
        raise BCRPExtractionError(f"Page {page_no}: incomplete/ambiguous PBI and inflation rows")
    header = [w for w in words if title["cy"] < w["top"] and w["bottom"] < pbi[0]["cy"]]
    year_words = [w for w in header if re.fullmatch(r"20\d{2}\*?", w["text"])]
    if not year_words or len({w["text"] for w in year_words}) != len(year_words):
        raise BCRPExtractionError("Missing or duplicated RI year headers")
    rev_words = [w for w in header if re.fullmatch(r"[A-Za-z]{3,}\.\s*\d{2,4}", w["text"])]
    revisions = []
    for word in rev_words:
        nearby = [w for w in header if w["text"] == "RI" and
                  abs((w["top"]+w["bottom"]-word["top"]-word["bottom"])/2) < 2
                  and 0 <= word["x0"]-w["x1"] < 12]
        if len(nearby) != 1:
            raise BCRPExtractionError("Revision header lacks a unique RI label")
        match = re.fullmatch(r"([A-Za-z]+)\.\s*(\d{2,4})", word["text"])
        month = MONTHS.get(match[1].lower()[:3])
        if not month:
            raise BCRPExtractionError("Unrecognized RI revision month")
        year = int(match[2]) + (2000 if len(match[2]) == 2 else 0)
        revision = f"{year:04d}-{month:02d}"
        if revision > edition:
            raise BCRPExtractionError("Revision postdates the containing RI edition")
        revisions.append({"revision": revision, "label": "RI " + word["text"],
                          "bbox": _bbox([nearby[0], word])})
    if not revisions:
        raise BCRPExtractionError("No dated RI revision headers")
    # Grid lines, not ordinal columns, establish each header's parent year and
    # each numeric cell. The count of revisions per year is unrestricted.
    horizontals = [e for e in page.edges if e.get("orientation") == "h"
                   and title["cy"] < e["top"] < pbi[0]["cy"] and e["width"] > 10
                   and 0 <= e["x0"] < e["x1"] <= page.width]
    if not horizontals:
        raise BCRPExtractionError("RI table lacks geometric horizontal bounds")
    left = min(e["x0"] for e in horizontals)
    right = max(e["x1"] for e in horizontals)
    if right-left < page.width/2:
        raise BCRPExtractionError("RI horizontal segments do not delimit a complete table")
    verticals = [e for e in page.edges if e.get("orientation") == "v"
                 and left <= e["x0"] <= right and e["top"] < pbi[0]["cy"]
                 and e["bottom"] > min(w["top"] for w in year_words)]
    for word in year_words:
        cy = (word["top"]+word["bottom"])/2
        bounds = _cluster([left, right] + [e["x0"] for e in verticals if e["top"] <= cy <= e["bottom"]])
        cx = (word["x0"]+word["x1"])/2
        spans = [(lo, hi) for lo, hi in zip(bounds, bounds[1:]) if lo < cx < hi]
        if len(spans) != 1:
            raise BCRPExtractionError("Year header has ambiguous geometric bounds")
        word["span"] = spans[0]
    rev_cy = sum((r["bbox"][1]+r["bbox"][3])/2 for r in revisions)/len(revisions)
    cell_edges = _cluster([left, right] + [e["x0"] for e in verticals if e["top"] <= rev_cy <= e["bottom"]])
    columns = []
    for lo, hi in zip(cell_edges, cell_edges[1:]):
        rs = [r for r in revisions if lo < (r["bbox"][0]+r["bbox"][2])/2 < hi]
        hs = [y for y in year_words if "*" not in y["text"] and lo < (y["x0"]+y["x1"])/2 < hi]
        if not rs and not hs:
            continue  # label column
        if len(rs)+len(hs) != 1:
            raise BCRPExtractionError("Ambiguous RI numeric column")
        cx = (lo+hi)/2
        parents = [y for y in year_words if y["span"][0] < cx < y["span"][1]]
        if len(parents) != 1:
            raise BCRPExtractionError("Revision cannot be assigned to a unique year")
        parent = parents[0]
        forecast = "*" in parent["text"]
        if forecast != bool(rs):
            raise BCRPExtractionError("Historical/forecast header conflict")
        columns.append({"year": parent["text"].rstrip("*"), "kind": "anual" if forecast else "historical",
                        "revision": rs[0]["revision"] if rs else None,
                        "revision_label": rs[0]["label"] if rs else None,
                        "x_bounds": [lo, hi], "year_bbox": _bbox([parent]),
                        "revision_bbox": rs[0]["bbox"] if rs else None})
    if len(columns) != len(revisions)+sum("*" not in w["text"] for w in year_words):
        raise BCRPExtractionError("Incomplete RI header grid")
    for year in {c["year"] for c in columns if c["kind"] == "anual"}:
        rs = [c["revision"] for c in columns if c["year"] == year]
        if len(rs) != len(set(rs)) or max(rs) != edition:
            raise BCRPExtractionError("Each forecast year must have one column of the document edition")
    records = []
    fitz_words = fitz_page.get_text("words")
    for variable, row in (("pbi", pbi[0]), ("inflacion", inf[0])):
        row_box = _bbox(row["words"])
        numeric = [w for w in row["words"] if NUMBER.fullmatch(w["text"]) and
                   (w["x0"]+w["x1"])/2 > columns[0]["x_bounds"][0]]
        if len(numeric) != len(columns):
            raise BCRPExtractionError(f"Page {page_no}: incomplete {variable} row")
        for col in columns:
            lo, hi = col["x_bounds"]
            matches = [w for w in numeric if lo < (w["x0"]+w["x1"])/2 < hi]
            if len(matches) != 1:
                raise BCRPExtractionError("Missing or ambiguous RI cell")
            word = matches[0]
            independent = [w[4] for w in fitz_words if lo < (w[0]+w[2])/2 < hi
                           and row_box[1]-3 < (w[1]+w[3])/2 < row_box[3]+3
                           and NUMBER.fullmatch(w[4])]
            if len(independent) != 1 or _decimal(independent[0]) != _decimal(word["text"]):
                raise BCRPExtractionError(f"Page {page_no}: PyMuPDF/pdfplumber cell disagreement")
            records.append({"source": "BCRP · Reporte de Inflación", "variable": variable,
                            "edition": edition, "document_edition": edition, "year": col["year"],
                            "revision": col["revision"], "revision_label": col["revision_label"],
                            "group": "", "kind": col["kind"], "value": float(_decimal(word["text"])),
                            "value_text": word["text"], "unit": "%", "page": page_no,
                            "bbox": _bbox([word]), "cell_bbox": [lo,row_box[1]-2,hi,row_box[3]+2],
                            "document": name, "sha256": sha, "source_url": source_url,
                            "is_current_column": col["revision"] == edition,
                            "engines_verified": ["pdfplumber", "PyMuPDF"]})
    footer = [line["cy"] for line in lines if line["cy"] > inf[0]["cy"]
              and re.match(r"^ri:\s*reporte", _norm(line["text"]))]
    body_limit = min(footer) if footer else page.height
    body_edges = [e["top"] for e in page.edges if e.get("orientation") == "h"
                  and inf[0]["cy"] < e["top"] < body_limit
                  and left-.8 <= e["x0"] < e["x1"] <= right+.8 and e["width"] > 10]
    if not body_edges:
        raise BCRPExtractionError("RI table lacks a lower geometric bound")
    return {"page": page_no, "title": title["text"],
            "bbox": [left, min(w["top"] for w in title["words"]), right, max(body_edges)],
            "rows": [{"variable": "pbi", "bbox": _bbox(pbi[0]["words"])},
                     {"variable": "inflacion", "bbox": _bbox(inf[0]["words"])}],
            "columns": columns, "records": records,
            "pdfplumber_detected_tables": [list(t.bbox) for t in page.find_tables()
                                            if 0 <= t.bbox[0] < t.bbox[2] <= page.width]}


def parse_inflation_report(body, document_name="", source_url=""):
    import pdfplumber
    import pymupdf
    sha = hashlib.sha256(body).hexdigest()
    with pdfplumber.open(io.BytesIO(body)) as pdf, pymupdf.open(stream=body, filetype="pdf") as independent:
        edition, edition_bbox = _cover_edition(pdf.pages[0])
        tables = []
        for index, page in enumerate(pdf.pages):
            table = _ri_table(page, index+1, edition, independent[index], document_name, sha, source_url)
            if table:
                tables.append(table)
        if len(tables) != 1:
            raise BCRPExtractionError(f"Expected one visible RI summary; found {len(tables)}")
        records = tables[0].pop("records")
        result = {"schema_version": SCHEMA_VERSION,
                  "parser": "bcrp_documents/"+SCHEMA_VERSION,
                  "document": {"type": "inflation_report", "source": "BCRP · Reporte de Inflación",
                               "edition": edition, "published": edition, "published_precision": "month",
                               "document": document_name, "sha256": sha, "pages": len(pdf.pages),
                               "edition_page": 1, "edition_bbox": edition_bbox, "source_url": source_url,
                               "page_dimensions": [[p.width, p.height] for p in pdf.pages]},
                  "records": records, "tables": tables,
                  "validation": {"status": "passed", "engines": ["pdfplumber", "PyMuPDF"],
                                 "numeric_cells": len(records), "all_cells_cross_checked": True,
                                 "visible_page_bounds_only": True}}
        validate_document(result)
        return result


def parse_document(pdf, document_name="", source_url=""):
    """Parse bytes or a path. Document content, never its filename, determines type."""
    import pdfplumber
    if isinstance(pdf, (str, Path)):
        path = Path(pdf)
        body = path.read_bytes()
        document_name = document_name or path.name
    elif isinstance(pdf, (bytes, bytearray)):
        body = bytes(pdf)
    else:
        raise TypeError("PDF must be a path or bytes")
    if not body.startswith(b"%PDF"):
        raise BCRPExtractionError("Not a PDF document")
    try:
        with pdfplumber.open(io.BytesIO(body)) as document:
            if not 1 <= len(document.pages) <= 250:
                raise BCRPExtractionError("PDF page count outside limits")
            cover_words = _visible_words(document.pages[0])
            cover = _norm(" ".join(w["text"] for w in cover_words))
            has_summary = any("resumen de las proyecciones" in _norm(" ".join(w["text"] for w in _visible_words(page)))
                              for page in document.pages)
        if has_summary:
            return parse_inflation_report(body, document_name, source_url)
        if "nota" in cover and "estudios" in cover and "expectativas" in cover:
            result = parse_survey_pdf(body, document_name=document_name, source_url=source_url)
            result.setdefault("schema_version", SCHEMA_VERSION)
            result.setdefault("parser", "bcrp_documents/"+SCHEMA_VERSION)
            validate_document(result)
            return result
        raise BCRPExtractionError("Unsupported BCRP publication or missing summary table")
    except BCRPExtractionError:
        raise
    except Exception as exc:
        raise BCRPExtractionError(f"BCRP PDF rejected: {exc}") from exc


def validate_document(result):
    """Validate normalized completeness and exact decimal equivalence; no filling."""
    doc = result.get("document", {})
    records = result.get("records", [])
    if not records or not re.fullmatch(r"[0-9a-f]{64}", doc.get("sha256", "")):
        raise BCRPExtractionError("Missing records or document SHA-256")
    sources = {"inflation_report": "BCRP · Reporte de Inflación", "survey": "BCRP · encuesta anual"}
    if doc.get("type") not in sources or doc.get("source") != sources[doc["type"]]:
        raise BCRPExtractionError("Missing or inconsistent publication identity")
    dimensions = doc.get("page_dimensions", [])
    if not dimensions or len(dimensions) != doc.get("pages", doc.get("page_count")):
        raise BCRPExtractionError("Missing PDF page dimensions")
    seen = set()
    for row in records:
        key = (row["variable"], str(row["year"]), row.get("group", ""),
               row.get("survey_date") or row.get("revision"), row.get("kind", "anual"))
        if key in seen:
            raise BCRPExtractionError(f"Duplicated table cell {key}")
        seen.add(key)
        if Decimal(str(row["value"])) != _decimal(row["value_text"]):
            raise BCRPExtractionError("Normalized value differs from printed decimal")
        if row.get("sha256") != doc["sha256"] or not row.get("page") or len(row.get("bbox", [])) != 4:
            raise BCRPExtractionError("Missing cell provenance")
        if (row.get("source") != doc["source"] or row.get("document") != doc.get("document")
                or row.get("edition") != doc.get("edition")
                or row.get("document_edition", doc["edition"]) != doc["edition"]):
            raise BCRPExtractionError("Inconsistent cell publication metadata")
        page = row["page"]
        box = row["bbox"]
        if (not isinstance(page, int) or isinstance(page, bool) or not 1 <= page <= len(dimensions)
                or not all(isinstance(v, (float, int)) and math.isfinite(v) for v in box)):
            raise BCRPExtractionError("Invalid cell page/coordinates")
        width, height = dimensions[page-1]
        if not (0 <= box[0] < box[2] <= width and 0 <= box[1] < box[3] <= height):
            raise BCRPExtractionError("Cell lies outside visible PDF page")
    expected = set()
    for table in result.get("tables", []):
        if doc.get("type") == "inflation_report":
            for col in table["columns"]:
                for var in ("pbi", "inflacion"):
                    expected.add((var, str(col["year"]), "", col["revision"], col["kind"]))
        elif doc.get("type") == "survey":
            for row in table["rows"]:
                for col in table["columns"]:
                    # Full survey dates identify columns, including two
                    # surveys held within one calendar month.
                    expected.add((table["variable"], str(row["year"]), row["group"], col["survey_date"], "anual"))
    actual = {(r["variable"], str(r["year"]), r.get("group", ""),
               r.get("survey_date") or r.get("revision"), r.get("kind", "anual")) for r in records}
    if not expected or actual != expected:
        raise BCRPExtractionError("Extracted cells do not match the complete table grid")
    return {"status": "passed", "records": len(records), "document_sha256": doc["sha256"]}


def current_forecasts(records):
    """Latest review per source/variable/target/group, excluding observed history.

    Reproduction of a vintage is one forecast with several documentary citations.
    Contradictory reproductions are rejected instead of choosing an approximation.
    """
    unique = {}
    for row in records:
        if row.get("kind", "anual") != "anual":
            continue
        vintage = row.get("survey_date") or row.get("revision") or row["edition"]
        key = (row["source"], row["variable"], str(row["year"]), row.get("group", ""), vintage)
        if key in unique and Decimal(str(unique[key]["value"])) != Decimal(str(row["value"])):
            raise BCRPExtractionError(f"Conflicting publication of the same vintage: {key}")
        if key not in unique:
            unique[key] = dict(row)
        retained = unique[key]
        evidence = list(retained.get("evidence", []))
        for citation in (retained, row):
            item = {field: citation[field] for field in ("document", "sha256", "document_edition", "edition",
                    "page", "bbox", "value_text") if field in citation}
            if item not in evidence:
                evidence.append(item)
        retained["evidence"] = evidence
    latest = {}
    for key, row in unique.items():
        series, vintage = key[:-1], key[-1]
        if series not in latest or vintage > latest[series][0]:
            latest[series] = (vintage, row)
    return [dict(v[1]) for _, v in sorted(latest.items())]


def dashboard_records(parsed, url="", document_id=""):
    """Translate the shared reader to IASPE's existing public-record schema."""
    validate_document(parsed)
    doc = parsed["document"]
    out = []
    for extracted in parsed["records"]:
        if extracted.get("kind", "anual") != "anual":
            continue
        if doc["type"] == "survey" and not extracted.get("is_current_column"):
            continue
        row = dict(extracted)
        row.update(edition=extracted.get("revision") or doc["edition"],
                   document_edition=doc["edition"], document_id=document_id,
                   document_hash=doc["sha256"], url=url or doc.get("source_url", ""),
                   published=doc.get("published"), published_precision=doc.get("published_precision", "month"),
                   kind="anual", extractor_verified=True,
                   cell=f"Página {row['page']} · {row.get('revision_label') or row.get('survey_date', '')}",
                   note="Celda geométrica cotejada con pdfplumber y PyMuPDF")
        out.append(row)
    if not out:
        raise BCRPExtractionError("Document has no complete annual forecasts")
    return out


# Annual survey tables: same public module and extraction contract.
"""Coordinate reader for the three annual BCRP survey matrices.

Values are located by table titles, group labels, target-year row labels and
survey-date column headers. Text-only regular expressions never assign cells.
Both independent PDF engines must read the same number inside each cell.
"""

import hashlib
import io
import re
import unicodedata
from datetime import date
from decimal import Decimal


_SURVEY_MONTHS = {
    "ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6,
    "jul": 7, "ago": 8, "set": 9, "sep": 9, "oct": 10, "nov": 11, "dic": 12,
}
_SURVEY_GROUPS = {
    "analistas economicos": "Analistas económicos",
    "sistema financiero": "Sistema financiero",
    "empresas no financieras": "Empresas no financieras",
}
_SURVEY_NUMBER = re.compile(r"-?\d+(?:[.,]\d+)?\Z")


def _survey_norm(text):
    return unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode().lower().strip()


def _survey_decimal(text):
    if not _SURVEY_NUMBER.fullmatch(text):
        raise ValueError(f"Celda no numérica de encuesta: {text!r}")
    return Decimal(text.replace(",", "."))


def _survey_box(words):
    return [min(w["x0"] for w in words), min(w["top"] for w in words),
            max(w["x1"] for w in words), max(w["bottom"] for w in words)]


def _survey_lines(words):
    """Cluster baselines geometrically, including superscript group footnotes."""
    rows = []
    for word in sorted(words, key=lambda w: ((w["top"] + w["bottom"]) / 2, w["x0"])):
        center = (word["top"] + word["bottom"]) / 2
        matches = [r for r in rows if abs(r["center"] - center) <= 2.6]
        if len(matches) > 1:
            raise ValueError("Filas geométricas ambiguas en la encuesta")
        if matches:
            matches[0]["words"].append(word)
        else:
            rows.append({"center": center, "words": [word]})
    for row in rows:
        row["words"].sort(key=lambda w: w["x0"])
        row["text"] = " ".join(w["text"] for w in row["words"])
        row["bbox"] = _survey_box(row["words"])
    return sorted(rows, key=lambda r: r["center"])


def _survey_identity(first_page_text):
    text = _survey_norm(first_page_text)
    if "notas de estudios del bcrp" not in text or not re.search(
            r"encuesta\s+mensual\s+de\s+expectativas\s+macroeconomicas", text):
        raise ValueError("El PDF no identifica una Nota de Estudios de encuesta BCRP")
    cover = text.split("expectativas de inflacion")[0]
    periods = re.findall(r"\b([a-z]+)\s+(20\d{2})(?:1)?\b", cover)
    # The publication header has 'noviembre de 2026', so cannot be mistaken for
    # the separate survey-period title 'Octubre 2026'.
    editions = {(int(year), _SURVEY_MONTHS[month[:3]]) for month, year in periods
                if month[:3] in _SURVEY_MONTHS}
    if len(editions) != 1:
        raise ValueError("La edición mensual de la encuesta es ambigua o falta")
    year, month = next(iter(editions))
    publication = re.search(r"no\.\s*(\d+)\s*[–—-]?\s*(\d{1,2})\s+de\s+([a-z]+)\s+de\s+(20\d{2})", text)
    if not publication or publication[3][:3] not in _SURVEY_MONTHS:
        raise ValueError("No se identifica número y fecha de publicación de la Nota")
    published = date(int(publication[4]), _SURVEY_MONTHS[publication[3][:3]], int(publication[2]))
    return {"type": "survey", "edition": f"{year:04d}-{month:02d}",
            "published": published.isoformat(), "published_precision": "day",
            "note_number": int(publication[1]), "institution": "BCRP"}


def _survey_headers(row, edition):
    words = row["words"]
    headers = []
    consumed = set()
    for i in range(len(words) - 2):
        triple = words[i:i+3]
        if not (re.fullmatch(r"\d{1,2}", triple[0]["text"]) and
                _survey_norm(triple[1]["text"]) == "de"):
            continue
        month = _SURVEY_MONTHS.get(_survey_norm(triple[2]["text"])[:3])
        if month is None:
            continue
        year = int(edition[:4]) - int(month > int(edition[5:7]))
        survey_date = date(year, month, int(triple[0]["text"])).isoformat()
        box = _survey_box(triple)
        headers.append({"survey_date": survey_date, "bbox": box,
                        "center": (box[0] + box[2])/2,
                        "label": " ".join(w["text"] for w in triple)})
        consumed.update(range(i, i+3))
    if len(headers) < 1 or len({h["survey_date"] for h in headers}) != len(headers):
        raise ValueError("Fechas de columnas de encuesta ausentes o duplicadas")
    if consumed != set(range(len(words))):
        raise ValueError("Cabecera de fechas de encuesta incompleta o ambigua")
    if [h["survey_date"] for h in headers] != sorted(h["survey_date"] for h in headers):
        raise ValueError("Las fechas de encuesta no tienen un orden inequívoco")
    if headers[-1]["survey_date"][:7] != edition:
        raise ValueError("La última encuesta no corresponde a la edición del documento")
    # No fixed column widths: derive disjoint intervals from header centers.
    centers = [h["center"] for h in headers]
    if len(centers) == 1:
        raise ValueError("Una única columna no permite verificar límites de la matriz")
    for i, header in enumerate(headers):
        header["x0"] = ((centers[i-1]+centers[i])/2 if i else
                         centers[0]-(centers[1]-centers[0])/2)
        header["x1"] = ((centers[i]+centers[i+1])/2 if i+1 < len(centers) else
                         centers[-1]+(centers[-1]-centers[-2])/2)
    return headers


def _survey_crosscheck(word, fitz_words):
    """Independent engine, same physical cell; disagreement always rejects."""
    cx, cy = (word["x0"]+word["x1"])/2, (word["top"]+word["bottom"])/2
    candidates = [w for w in fitz_words if
                  word["x0"]-1 <= (w[0]+w[2])/2 <= word["x1"]+1 and
                  abs((w[1]+w[3])/2-cy) <= max(4, (word["bottom"]-word["top"])/2) and
                  _SURVEY_NUMBER.fullmatch(w[4])]
    if len(candidates) != 1 or _survey_decimal(candidates[0][4]) != _survey_decimal(word["text"]):
        raise ValueError(f"PyMuPDF y pdfplumber no concuerdan en la celda {word['text']!r}")
    return [float(v) for v in candidates[0][:4]]


def _survey_parse_table(page, fitz_page, rows, title_index, identity, document_name, source_url, sha):
    following = rows[title_index+1:title_index+5]
    variable_rows = [(r, "inflacion" if "inflacion" in _survey_norm(r["text"]) else
                        "pbi" if "crecimiento del pbi" in _survey_norm(r["text"]) else
                        "tc_cierre" if "tipo de cambio" in _survey_norm(r["text"]) and
                        "12 meses" not in _survey_norm(r["text"]) else None) for r in following]
    labeled = [(r, v) for r, v in variable_rows if v]
    if not labeled:
        return None
    if len(labeled) != 1:
        raise ValueError("La variable de la matriz de encuesta es ambigua")
    var_row, variable = labeled[0]
    title_y = rows[title_index]["center"]
    next_titles = [r["center"] for r in rows[title_index+1:] if
                   "encuesta de expectativas macroeconomicas" in _survey_norm(r["text"])]
    end_y = min(next_titles, default=page.height)
    section = [r for r in rows if var_row["center"] < r["center"] < end_y]
    header_markers = [r for r in section if "encuesta realizada al" in _survey_norm(r["text"])]
    if len(header_markers) != 1:
        raise ValueError(f"{variable}: falta una cabecera única de fechas")
    marker = header_markers[0]
    after_marker = [r for r in section if r["center"] > marker["center"]]
    if not after_marker:
        raise ValueError(f"{variable}: no hay fechas de encuesta")
    date_row = after_marker[0]
    headers = _survey_headers(date_row, identity["edition"])
    latest = max(h["survey_date"] for h in headers)

    group_rows = []
    for r in section:
        matches = [group for normalized, group in _SURVEY_GROUPS.items()
                   if _survey_norm(r["text"]).startswith(normalized)]
        if len(matches) == 1:
            group_rows.append((r, matches[0]))
    if len(group_rows) != 3 or {g for _, g in group_rows} != set(_SURVEY_GROUPS.values()):
        raise ValueError(f"{variable}: no se identifican inequívocamente los tres grupos")

    # Detect physical outer table bounds with pdfplumber. Its default cell
    # segmentation merges several rows in this real document; only outer bounds
    # are useful. Semantic row/column coordinates supply the actual grid.
    outer = [t.bbox for t in page.find_tables() if
             t.bbox[1]-4 <= date_row["center"] <= t.bbox[3]+4 and
             all(t.bbox[1]-4 <= r["center"] <= t.bbox[3]+4 for r, _ in group_rows)]
    if len(outer) > 1:
        raise ValueError(f"{variable}: hay varios límites de tabla candidatos")
    table_box = list(outer[0]) if outer else [
        min(r["bbox"][0] for r, _ in group_rows), rows[title_index]["bbox"][1],
        headers[-1]["x1"], end_y]
    fitz_words = fitz_page.get_text("words")
    records = []
    target_sets = []
    row_descriptors = []
    for i, (group_row, group) in enumerate(group_rows):
        next_y = group_rows[i+1][0]["center"] if i+1 < len(group_rows) else min(end_y, table_box[3]+1)
        data_rows = [r for r in section if group_row["center"] < r["center"] < next_y and
                     r["words"] and re.fullmatch(r"20\d{2}", r["words"][0]["text"])]
        if len(data_rows) < 2:
            raise ValueError(f"{variable}/{group}: menos de dos años objetivo")
        targets = []
        for row in data_rows:
            year_word = row["words"][0]
            if year_word["x1"] >= headers[0]["x0"]:
                raise ValueError(f"{variable}: el año se superpone con una columna de valores")
            target = year_word["text"]
            if target in targets:
                raise ValueError(f"{variable}/{group}: año objetivo repetido")
            targets.append(target)
            numeric = [w for w in row["words"][1:] if _SURVEY_NUMBER.fullmatch(w["text"])]
            if len(numeric) != len(headers):
                raise ValueError(f"{variable}/{group}/{target}: fila de valores incompleta")
            assigned = set()
            for header in headers:
                in_cell = [w for w in numeric if header["x0"] < (w["x0"]+w["x1"])/2 < header["x1"]]
                if len(in_cell) != 1:
                    raise ValueError(f"{variable}/{group}/{target}: columna {header['label']} ambigua")
                word = in_cell[0]
                assigned.add(id(word))
                fitz_box = _survey_crosscheck(word, fitz_words)
                exact = _survey_decimal(word["text"])
                if variable == "tc_cierre" and not Decimal(1) < exact < Decimal(20):
                    raise ValueError("Tipo de cambio fuera de la unidad declarada")
                if variable != "tc_cierre" and not Decimal(-100) < exact < Decimal(100):
                    raise ValueError("Tasa de encuesta fuera de la unidad declarada")
                records.append({"source": "BCRP · encuesta anual", "variable": variable,
                    "edition": identity["edition"], "year": target, "group": group,
                    "value": float(exact), "value_text": word["text"],
                    "survey_date": header["survey_date"], "is_current_column": header["survey_date"] == latest,
                    "page": page.page_number, "bbox": [float(v) for v in _survey_box([word])],
                    "crosscheck_bbox": fitz_box, "document": document_name, "sha256": sha,
                    "document_hash": sha, "url": source_url, "published": identity["published"],
                    "unit": "S/ por USD" if variable == "tc_cierre" else "%",
                    "kind": "anual", "status": "forecast", "revision": header["survey_date"][:7],
                    "cell": f"Página {page.page_number} · {group} · {target} · {header['label']}"})
            if len(assigned) != len(numeric):
                raise ValueError("Una cifra se asignó a más de una columna de encuesta")
            row_descriptors.append({"group": group, "year": target, "bbox": row["bbox"]})
        target_sets.append(set(targets))
    if any(targets != target_sets[0] for targets in target_sets):
        raise ValueError(f"{variable}: los grupos no tienen los mismos años objetivo")
    if variable == "tc_cierre":
        section_text = _survey_norm(" ".join(r["text"] for r in section))
        if "tipo de cambio al cierre del ano" not in section_text:
            raise ValueError("El tipo de cambio no acredita ser de cierre anual")
    return {"variable": variable, "page": page.page_number, "bbox": [float(v) for v in table_box],
            "boundary_method": "pdfplumber.find_tables" if outer else "semantic_coordinates",
            "columns": headers, "rows": row_descriptors, "survey_date": latest,
            "years": sorted(target_sets[0]), "records": records}


def parse_survey_pdf(body: bytes, document_name="", source_url=""):
    """Parse all survey-date cells; mark the latest header explicitly.

    All three annual variables, all three named groups, matching target years,
    complete date columns and dual-engine cell agreement are mandatory.
    No filesystem writes or network requests occur in this function.
    """
    try:
        import pymupdf as fitz
        import pdfplumber
    except ImportError as exc:
        raise ValueError("El lector BCRP requiere PyMuPDF y pdfplumber instalados") from exc
    if not isinstance(body, bytes) or not body.startswith(b"%PDF"):
        raise ValueError("El documento de encuesta no es un PDF")
    sha = hashlib.sha256(body).hexdigest()
    with fitz.open(stream=body, filetype="pdf") as mupdf, pdfplumber.open(io.BytesIO(body)) as plumber:
        if not 1 <= len(mupdf) <= 250 or len(mupdf) != len(plumber.pages):
            raise ValueError("Número de páginas inválido o distinto entre lectores")
        identity = _survey_identity(mupdf[0].get_text())
        tables = []
        for pno, mupdf_page in enumerate(mupdf):
            quick = _survey_norm(mupdf_page.get_text())
            if "encuesta de expectativas macroeconomicas" not in quick:
                continue
            page = plumber.pages[pno]
            rows = _survey_lines(page.extract_words())
            title_indices = [i for i, r in enumerate(rows) if
                             "encuesta de expectativas macroeconomicas" in _survey_norm(r["text"])]
            for title_index in title_indices:
                table = _survey_parse_table(page, mupdf_page, rows, title_index, identity,
                                            document_name, source_url, sha)
                if table is not None:
                    tables.append(table)
        if len(tables) != 3 or {t["variable"] for t in tables} != {"pbi", "inflacion", "tc_cierre"}:
            raise ValueError("Se requieren exactamente las tres matrices anuales completas de inflación, PBI y tipo de cambio")
        if len({t["survey_date"] for t in tables}) != 1 or len({tuple(t["years"]) for t in tables}) != 1:
            raise ValueError("Las tres tablas no comparten fecha de encuesta y años objetivo")
        records = [r for table in tables for r in table.pop("records")]
        identity.update({"survey_date": tables[0]["survey_date"], "document": document_name,
                         "source": "BCRP · encuesta anual",
                         "sha256": sha, "page_count": len(mupdf),
                         "page_dimensions": [[p.width, p.height] for p in plumber.pages]})
        return {"document": identity, "records": records, "tables": tables,
                "validation": {"complete": True, "engines_agree": True,
                               "engines": ["pdfplumber", "PyMuPDF"],
                               "records": len(records), "current_records": sum(r["is_current_column"] for r in records)}}
