"""Adaptadores de tasas de mercado e ingresos. Lee los modelos sin modificarlos."""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime
from pathlib import Path
import math

import numpy as np
import statsmodels.api as sm
from openpyxl import load_workbook
from rutas import buscar_modelo


CONFIG = {
    '13': {'name': 'Tasa activa de tarjetas del mercado', 'unit': 'TEA, %',
           'variables': ['tasa_rezago', 'tpm', 'pbi_rezago'], 'dependencies': ['tpm', 'pbi'],
           'columns': {'pbi': 2, 'tpm': 3}},
    '14': {'name': 'Tasa activa de préstamos de consumo del mercado >360 días', 'unit': 'TEA, %',
           'variables': ['tasa_rezago', 'tpm'], 'dependencies': ['tpm'],
           'columns': {'tpm': 2}},
    '15': {'name': 'Tasa pasiva del mercado a 181–360 días', 'unit': 'TEA, %',
           'variables': ['tpm', 'inflacion_rezago'], 'dependencies': ['tpm', 'inflacion'],
           'columns': {'tpm': 2, 'inflacion': 3}},
}
LABELS = {'tasa_rezago': 'Tasa de mercado rezagada', 'tpm': 'TPM de diciembre',
          'pbi_rezago': 'Crecimiento del PBI rezagado', 'inflacion_rezago': 'Inflación rezagada'}
INTERPRETATIONS = {
    'tasa_rezago': 'Un punto porcentual adicional en la tasa del año anterior cambia la tasa prevista en el coeficiente estimado. Recoge persistencia, sin identificar causalidad.',
    'tpm': 'Un punto porcentual adicional en la TPM de diciembre cambia la tasa prevista en el coeficiente estimado, dadas las otras regresoras.',
    'pbi_rezago': 'Un punto porcentual adicional de crecimiento del PBI del año anterior cambia la tasa prevista en el coeficiente estimado. Es una relación estimada, no un efecto causal identificado.',
    'inflacion_rezago': 'Un punto porcentual adicional de inflación del año anterior cambia la tasa prevista en el coeficiente estimado, manteniendo fija la TPM.',
}


def _folder(root, mid):
    return buscar_modelo(root, mid)


def _sheets(path):
    book = load_workbook(path, read_only=True, data_only=True)
    result = {s.title: [list(r) for r in s.values] for s in book}
    book.close()
    return result


def _is_number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _state(text):
    text = str(text or '').lower()
    if 'supuesto' in text:
        return 'assumed'
    return 'observed' if 'observ' in text or 'real' == text else 'forecast'


def _point(year, value, status, **extra):
    value = float(value) if _is_number(value) else None
    return {'year': int(year), 'value': value, 'status': status,
            'observed': value if status == 'observed' else None,
            'assumed': value if status == 'assumed' else None,
            'forecast': value if status == 'forecast' else None, **extra}


def _month(value):
    return value.strftime('%Y-%m') if isinstance(value, (datetime, date)) else str(value)[:7]


def _updates(observations, mid):
    return {str(k): float(v) for k, v in (observations or {}).get(mid, {}).items() if _is_number(v)}


def _override(values, key, year, default):
    data = (values or {}).get(key, {})
    value = data.get(str(year), data.get(year, default))
    return float(value) if _is_number(value) else default


def _sources(folder):
    return [str(folder / 'Input' / 'Base_modelo.xlsx'),
            str(next(folder.glob('Script/*.ipynb'))),
            str(folder / 'Output' / 'Resultados_MCO.xlsx'),
            str(folder / 'Output' / 'Pronostico.xlsx')]


def _rate_source(root, mid):
    folder = _folder(root, mid)
    sheets = _sheets(folder / 'Input' / 'Base_modelo.xlsx')
    config = CONFIG[mid]
    info = {}
    for row in sheets['Anual'][1:]:
        if not _is_number(row[0]):
            continue
        year = int(row[0])
        info[year] = {'value': row[1], 'status': _state(row[-1])}
        for key, column in config['columns'].items():
            info[year][key] = float(row[column])
    monthly = {_month(r[0]): {'value': float(r[1]), 'status': _state(r[2])}
               for r in sheets['Mensual'][1:] if r[0] is not None and _is_number(r[1])}
    # El cierre vigente procede del Input anual; tras cada actualización mensual
    # puede ser posterior a agosto sin modificar los demás años.
    return folder, info, monthly


def _rate_stats(folder, config):
    sheets = _sheets(folder / 'Output' / 'Resultados_MCO.xlsx')
    ordinary, robust = sheets['MCO'], sheets['HAC']
    rows = [r for r in ordinary[6:] if r[0] is not None and _is_number(r[1])]
    robust_rows = [r for r in robust[6:] if r[0] is not None and _is_number(r[1])]
    coefficients = []
    for i, (row, hrow) in enumerate(zip(rows, robust_rows)):
        var = 'const' if i == 0 else config['variables'][i - 1]
        coefficients.append({'name': 'Constante' if i == 0 else LABELS[var], 'variable': var,
                             'value': float(row[1]), 'se': float(hrow[2]), 'pValue': float(hrow[4]),
                             'seOLS': float(row[2]), 'pValueOLS': float(row[4]),
                             't': float(hrow[3]), 'lag': 1 if 'rezago' in var else 0,
                             'interpretation': INTERPRETATIONS.get(var, 'Intercepto de la regresión estimada.')})
    metrics = {str(r[0]): r[1] for r in ordinary[1:5]}
    return coefficients, {'n': int(metrics['Observaciones']), 'adjustedR2': metrics['R² ajustado'],
                          'durbinWatson': metrics['Durbin-Watson'], 'period': '2011–2026',
                          'inference': 'HAC(1), referencia t', 'includesAssumed2026': True}


def _fit_stats(fit, names, period):
    robust = fit.get_robustcov_results(cov_type='HAC', maxlags=1)
    coefficients = []
    for i, variable in enumerate(['const'] + names):
        coefficients.append({'name': 'Constante' if i == 0 else LABELS.get(variable, variable),
                             'variable': variable, 'value': float(fit.params[i]),
                             'se': float(robust.bse[i]), 'pValue': float(robust.pvalues[i]),
                             't': float(robust.tvalues[i]), 'seOLS': float(fit.bse[i]),
                             'pValueOLS': float(fit.pvalues[i]), 'lag': int('rezago' in variable),
                             'interpretation': INTERPRETATIONS.get(variable, '')})
    return coefficients, {'n': int(fit.nobs), 'adjustedR2': float(fit.rsquared_adj),
                          'durbinWatson': float(sm.stats.stattools.durbin_watson(fit.resid)),
                          'period': period, 'inference': 'HAC(1), referencia t'}


def _rate_x(info, year, variables):
    data = {'tasa_rezago': info[year - 1]['value'], 'tpm': info[year].get('tpm'),
            'pbi_rezago': info[year - 1].get('pbi'),
            'inflacion_rezago': info[year - 1].get('inflacion')}
    return [1.0] + [float(data[v]) for v in variables]


def _apply_rate_observations(info, monthly, updates):
    annual_updates = {int(k): v for k, v in updates.items() if len(k) == 4}
    touched = set()
    for key, value in updates.items():
        if len(key) == 7:
            monthly[key] = {'value': value, 'status': 'observed'}
            touched.add(int(key[:4]))
    for year in touched:
        observed = sorted((k, p) for k, p in monthly.items() if k.startswith(str(year)) and p['status'] == 'observed')
        if not observed or year not in info:
            continue
        if year >= 2026:
            last_key, last = observed[-1]
            for key, point in monthly.items():
                if key.startswith(str(year)) and key > last_key and point['status'] != 'observed':
                    point['value'] = last['value']
            info[year]['value'] = last['value']
            info[year]['status'] = 'observed' if last_key.endswith('-12') else 'assumed'
        elif f'{year}-12' in updates:
            info[year]['value'] = updates[f'{year}-12']
    for year, value in annual_updates.items():
        if year in info:
            info[year]['value'] = value
            info[year]['status'] = 'observed'


def _rate_model(root, mid, scenarios, observations):
    config = CONFIG[mid]
    folder, original, monthly = _rate_source(root, mid)
    info = deepcopy(original)
    _apply_rate_observations(info, monthly, _updates(observations, mid))
    for year, point in info.items():
        for macro in config['columns']:
            point[macro] = _override(observations, macro, year, point[macro])
    coefficients, statistics = _rate_stats(folder, config)
    # Nunca incorporar a la muestra un año intermedio que sigue pronosticado.
    train_end=2026
    for year in range(2027,2031):
        if info[year]['status']=='observed' and info[year]['value'] is not None:
            train_end=year
        else:
            break
    train = list(range(2011, train_end + 1))
    x = np.array([_rate_x(info, y, config['variables']) for y in train])
    target = np.array([info[y]['value'] for y in train], dtype=float)
    old_x = np.array([_rate_x(original, y, config['variables']) for y in range(2011, 2027)])
    old_y = np.array([original[y]['value'] for y in range(2011, 2027)], dtype=float)
    reestimated = x.shape != old_x.shape or not np.array_equal(x, old_x) or not np.array_equal(target, old_y)
    if reestimated:
        fit = sm.OLS(target, x).fit()
        coefficients, statistics = _fit_stats(fit, config['variables'], f'2011–{train_end}')
    parameters = np.array([c['value'] for c in coefficients])
    for year, point in info.items():
        for macro in config['columns']:
            point[macro] = _override(scenarios, macro, year, point[macro])
    for year in range(train_end + 1, 2031):
        if info[year]['status']=='observed':
            continue  # cierre oficial aislado; ancla años posteriores sin entrar al MCO
        # Un mes observado durante 2027+ actúa como tasa de cierre provisional;
        # solo diciembre o el cierre anual hacen observada la tasa anual.
        has_monthly = any(k.startswith(f'{year}-') for k in _updates(observations, mid) if len(k)==7)
        if info[year]['status']=='assumed' and has_monthly:
            continue
        info[year]['value'] = float(parameters @ np.array(_rate_x(info, year, config['variables'])))
        info[year]['status'] = 'forecast'
    tex_variables = {'tasa_rezago': r'r_{t-1}', 'tpm': r'\mathrm{TPM}_{t}',
                     'pbi_rezago': r'g^{PBI}_{t-1}', 'inflacion_rezago': r'\pi_{t-1}'}
    terms = [f'{parameters[0]:.6g}']
    for value, variable in zip(parameters[1:], config['variables']):
        terms.append(('+' if value >= 0 else '-') + f'{abs(value):.6g}' + tex_variables[variable])
    return {'id': mid, 'name': config['name'], 'unit': config['unit'], 'frequency': 'annual',
            'kind': 'rate', 'method': 'MCO con constante', 'dependencies': config['dependencies'],
            'annual': [_point(y, info[y]['value'], info[y]['status']) for y in range(2011, 2031)],
            'monthly': [{'date': k, **p, 'observed': p['value'] if p['status'] == 'observed' else None,
                         'assumed': p['value'] if p['status'] == 'assumed' else None, 'forecast': None}
                        for k, p in sorted(monthly.items())],
            'coefficients': coefficients, 'statistics': statistics, 'equationTex': 'r_t=' + ''.join(terms) + r'+\varepsilon_t',
            'inputs': [{'id': {'tasa_rezago': mid, 'pbi_rezago': 'pbi', 'inflacion_rezago': 'inflacion', 'tpm': 'tpm'}[v],
                        'variable': v, 'name': LABELS[v], 'unit': '%' if v != 'pbi_rezago' else '% real anual',
                        'lag': int('rezago' in v),
                        'transformation': 'Nivel del año anterior' if 'rezago' in v else 'Nivel de diciembre'}
                       for v in config['variables']],
            'sourceFiles': _sources(folder), 'closingRule': 'El último dato mensual actúa como cierre provisional del año hasta que se publique diciembre; el input original usa agosto de 2026.',
            'updateRule': 'Una tasa mensual nueva actualiza el cierre provisional. Un diciembre oficial sustituye la estimación y reestima MCO y HAC(1) cuando se incorpora a la muestra.',
            'limitations': ['La muestra de estimación incluye el cierre supuesto de 2026.',
                            'Pronóstico anual. No existe una distribución mensual proyectada desde 2027.',
                            'Las asociaciones de la regresión no identifican efectos causales.'],
            'reestimated': reestimated, 'status': 'ok', 'issues': []}


def _upstream_annual(upstream, mid, field='value'):
    model = (upstream or {}).get(mid)
    if not model:
        return {}
    return {int(p['year']): float(p[field]) for p in model.get('annual', []) if p.get('year') is not None and _is_number(p.get(field))}


def _income_model(root, scenarios, observations, upstream, rate_model):
    folder = _folder(root, '16')
    source = _sheets(folder / 'Input' / 'Base_modelo.xlsx')
    names = ['tarjetas', 'prestamos', 'saldo_promedio', 'tasa_tarjetas', 'creditos', 'otros', 'ingresos', 'rendimiento', 'condicion']
    original = {int(r[0]): dict(zip(names, r[1:])) for r in source['Anual'][1:] if _is_number(r[0])}
    info = deepcopy(original)
    monthly = {_month(r[0]): {'value': float(r[3]), 'status': _state(r[4])}
               for r in source['Mensual'][1:] if r[0] is not None and _is_number(r[3])}
    updates = _updates(observations, '16')
    annual_observed = {int(k) for k in updates if len(k) == 4}
    pending_monthly_years = set()
    touched = set()
    for key, value in updates.items():
        if len(key) == 7:
            monthly[key] = {'value': value, 'status': 'observed'}
            touched.add(int(key[:4]))
    for year in touched:
        observed = sorted((k, p) for k, p in monthly.items() if k.startswith(str(year)) and p['status'] == 'observed')
        if year == 2026 and observed:
            last_key, last = observed[-1]
            for key, p in monthly.items():
                if key.startswith('2026') and key > last_key and p['status'] != 'observed':
                    p['value'] = last['value']
        year_months = [p for k, p in monthly.items() if k.startswith(str(year))]
        if year > 2026 and len(year_months) < 12 and year not in annual_observed:
            pending_monthly_years.add(year)
            continue
        if year in info:
            info[year]['ingresos'] = sum(p['value'] for k, p in monthly.items() if k.startswith(str(year)))
            info[year]['rendimiento'] = None
            if len(year_months) == 12 and all(p['status'] == 'observed' for p in year_months):
                annual_observed.add(year)
    for key, value in updates.items():
        if len(key) == 4 and int(key) in info:
            info[int(key)]['ingresos'] = value
            info[int(key)]['rendimiento'] = None
    rates = {int(p['year']): p['value'] for p in rate_model['annual']}
    cards = _upstream_annual(upstream, '05')
    loans = _upstream_annual(upstream, '06')
    for year, row in info.items():
        if year in cards:
            row['tarjetas'] = cards[year]
        if year in loans:
            row['prestamos'] = loans[year]
        if year in rates:
            row['tasa_tarjetas'] = rates[year]
    train_end=2026
    for year in range(2027,2031):
        if year in annual_observed:
            train_end=year
        else:
            break
    for year in range(2016, 2031):
        row = info[year]
        previous = info[year - 1]
        if cards or loans:
            average = (previous['tarjetas'] + row['tarjetas'] + previous['prestamos'] + row['prestamos']) / 2
            if not math.isclose(average, row['saldo_promedio'] or 0, rel_tol=0, abs_tol=1e-9):
                row['saldo_promedio'] = average
                if year <= train_end:
                    row['rendimiento'] = None
        elif row['saldo_promedio'] is None:
            row['saldo_promedio'] = (previous['tarjetas'] + row['tarjetas'] + previous['prestamos'] + row['prestamos']) / 2
        if (year <= train_end or year in annual_observed) and row['rendimiento'] is None:
            row['rendimiento'] = 100 * row['ingresos'] / row['saldo_promedio']
        row['shock'] = 1 if year in (2020, 2021) else 0
        if year >= 2017:
            row['variacion_tasa'] = row['tasa_tarjetas'] - previous['tasa_tarjetas']
    outputs = _sheets(folder / 'Output' / 'Resultados_MCO.xlsx')
    rows = outputs['Coeficientes'][1:]
    coefficients = [{'name': r[0], 'variable': v, 'value': float(r[1]), 'se': float(r[4]),
                     'pValue': float(r[5]), 'seOLS': float(r[2]), 'pValueOLS': float(r[3]),
                     'lag': 1 if i == 1 else 0} for i, (r, v) in enumerate(zip(rows, ['const', 'rendimiento_rezago', 'variacion_tasa', 'shock']))]
    diagnostic = {r[0]: r[1] for r in outputs['Diagnostico'][1:] if r[0]}
    statistics = {'n': 10, 'adjustedR2': diagnostic['R² ajustado'], 'period': '2017–2026',
                  'inference': 'HAC(1), referencia t', 'mae': diagnostic['MAE dinámico 2023–2025 (S/ MM)'],
                  'maeComparator': diagnostic['MAE original 2023–2025 (S/ MM)'], 'includesAssumed2026': True}
    reestimated = bool(updates) or any((upstream or {}).get(mid, {}).get('reestimated') for mid in ['05', '06']) or rate_model['reestimated']
    if reestimated:
        years = list(range(2017, train_end + 1))
        x = np.array([[1, info[y - 1]['rendimiento'], info[y]['variacion_tasa'], info[y]['shock']] for y in years], dtype=float)
        fit = sm.OLS([info[y]['rendimiento'] for y in years], x).fit()
        updated, stats = _fit_stats(fit, ['rendimiento_rezago', 'variacion_tasa', 'shock'], f'2017–{train_end}')
        for old, new in zip(coefficients, updated):
            old.update({k: v for k, v in new.items() if k != 'name'})
        statistics.update(stats)
        errors_dynamic, errors_original = [], []
        for year in range(2023, 2026):
            train_dynamic = range(2017, year)
            fit_dynamic = sm.OLS([info[t]['rendimiento'] for t in train_dynamic],
                                [[1, info[t - 1]['rendimiento'], info[t]['variacion_tasa'], info[t]['shock']]
                                 for t in train_dynamic]).fit()
            prediction_dynamic = float(np.dot(fit_dynamic.params,
                [1, info[year - 1]['rendimiento'], info[year]['variacion_tasa'], info[year]['shock']])) * info[year]['saldo_promedio'] / 100
            train_original = range(2016, year)
            fit_original = sm.OLS([info[t]['rendimiento'] for t in train_original],
                                 sm.add_constant([info[t]['tasa_tarjetas'] for t in train_original])).fit()
            prediction_original = float(fit_original.params[0] + fit_original.params[1] * info[year]['tasa_tarjetas']) * info[year]['saldo_promedio'] / 100
            errors_dynamic.append(abs(prediction_dynamic - info[year]['ingresos']))
            errors_original.append(abs(prediction_original - info[year]['ingresos']))
        statistics['mae'] = float(np.mean(errors_dynamic))
        statistics['maeComparator'] = float(np.mean(errors_original))
    parameters = [r['value'] for r in coefficients]
    c, rho, beta, dummy = parameters
    for year in range(train_end + 1, 2031):
        row = info[year]
        if year in annual_observed:
            continue  # un cierre oficial posterior no se reemplaza por una regresión
        row['rendimiento'] = c + rho * info[year - 1]['rendimiento'] + beta * row['variacion_tasa']
        row['ingresos'] = row['saldo_promedio'] * row['rendimiento'] / 100
    blocked = [mid for mid in ['05', '06', '13'] if (upstream or {}).get(mid, {}).get('status') in {'needs_input', 'blocked', 'error'}]
    annual = []
    for year in range(2016, 2031):
        row = info[year]
        state = 'observed' if year <= 2025 else ('assumed' if year == 2026 else 'forecast')
        if year in annual_observed:
            state = 'observed'
        value = None if (blocked and year >= 2026) or (pending_monthly_years and year >= min(pending_monthly_years)) else row['ingresos']
        annual.append(_point(year, value, state, yieldValue=row['rendimiento'],
                             averageBalance=row['saldo_promedio'], marketCardRate=row['tasa_tarjetas']))
    return {'id': '16', 'name': 'Ingresos por intereses de Falabella', 'unit': 'S/ millones por año',
            'frequency': 'annual', 'kind': 'flow', 'method': 'MCO dinámico del rendimiento e identidad financiera',
            'dependencies': ['05', '06', '13'], 'annual': annual,
            'monthly': [{'date': k, **p, 'observed': p['value'] if p['status'] == 'observed' else None,
                         'assumed': p['value'] if p['status'] == 'assumed' else None, 'forecast': None}
                        for k, p in sorted(monthly.items())],
            'coefficients': coefficients, 'statistics': statistics,
            'equationTex': rf'q_t={c:.6g}+{rho:.6g}q_{{t-1}}+{beta:.6g}\Delta r^{{TC}}_t{dummy:+.6g}D_{{2020,2021}};\quad I_t=\frac{{\bar S_tq_t}}{{100}}',
            'financialIdentityTex': r'\bar S_t=\frac{TC_{t-1}+PNR_{t-1}+TC_t+PNR_t}{2}',
            'inputs': [{'id': '05', 'name': 'Saldo de tarjetas de Falabella', 'unit': 'S/ millones', 'transformation': 'Promedio de cierres t y t−1'},
                       {'id': '06', 'name': 'Préstamos no revolventes de Falabella', 'unit': 'S/ millones', 'transformation': 'Promedio de cierres t y t−1'},
                       {'id': '13', 'name': 'Tasa de tarjetas del mercado', 'unit': 'puntos porcentuales', 'transformation': 'Diferencia anual t−(t−1)'}],
            'sourceFiles': _sources(folder),
            'closingRule': 'Ingresos de 2026: flujos mensuales observados más el último flujo observado en los meses restantes. Rendimiento = ingresos anuales / cartera promedio × 100.',
            'updateRule': 'Las sendas recalculadas de los saldos y de la tasa de tarjetas modifican la identidad y el rendimiento previsto con parámetros fijos. Actualizar historia reestima el MCO y HAC(1).',
            'limitations': ['Muestra de diez años que incluye el cierre supuesto de 2026.',
                            'La comparación retrospectiva 2023–2025 reutiliza períodos de desarrollo y el MCO dinámico tiene mayor MAE que el comparador.',
                            'La tasa del mercado es una regresora del rendimiento propio; no se iguala directamente a él.',
                            'No se distribuyen los ingresos pronosticados anuales en meses.'],
            'reestimated': reestimated, 'status': 'needs_input' if blocked or pending_monthly_years else 'ok',
            'issues': (['Se requieren sendas compatibles de: ' + ', '.join(blocked)] if blocked else []) +
                      (['El flujo anual requiere los doce meses o el cierre anual observado para ' + ', '.join(map(str, sorted(pending_monthly_years)))] if pending_monthly_years else [])}


def recalculate(context, scenarios=None, observations=None):
    root = context.get('source_root', context.get('sourceRoot'))
    scenarios, observations = scenarios or {}, observations or {}
    models = {mid: _rate_model(root, mid, scenarios, observations) for mid in CONFIG}
    upstream = dict(context.get('models', {}))
    upstream.update(context.get('upstream', {}))
    upstream.update(models)
    # El módulo 16 vigente es una consolidación de cuatro submodelos.
    # Su lectura se gestiona en motor_08_22 y no en el adaptador antiguo.
    return models


def build_registry(source_root):
    return list(recalculate({'source_root': source_root}, {}, {}).values())


def get_macros(source_root):
    _, cards, _ = _rate_source(source_root, '13')
    _, deposits, _ = _rate_source(source_root, '15')
    return [{'id': 'pbi', 'name': 'Crecimiento real del PBI', 'unit': '% anual', 'frequency': 'annual',
             'values': {str(y): v['pbi'] for y, v in cards.items()}, 'models': ['13']},
            {'id': 'tpm', 'name': 'TPM de diciembre', 'unit': '%', 'frequency': 'annual',
             'values': {str(y): v['tpm'] for y, v in cards.items()}, 'models': ['13', '14', '15']},
            {'id': 'inflacion', 'name': 'Inflación anual', 'unit': '% anual', 'frequency': 'annual',
             'values': {str(y): v['inflacion'] for y, v in deposits.items()}, 'models': ['15']}]
