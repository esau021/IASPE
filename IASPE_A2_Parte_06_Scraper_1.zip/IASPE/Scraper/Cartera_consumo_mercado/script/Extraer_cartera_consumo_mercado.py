"""Lee los XLS de fuentes y guarda un solo Excel en output.

Requiere xlrd, openpyxl y xlsxwriter. Ejecutar: python Extraer_cartera_consumo_mercado.py
"""
from pathlib import Path
from datetime import datetime
import re
import unicodedata
import xlrd
import xlsxwriter
from openpyxl import load_workbook

CARPETA = Path(__file__).resolve().parents[1]
MESES = dict(zip(
    ['en', 'fe', 'ma', 'ab', 'my', 'jn', 'jl', 'ag', 'se', 'oc', 'no', 'di'],
    range(1, 13),
))


def normalizar(valor):
    texto = unicodedata.normalize('NFD', str(valor or '').lower())
    return ' '.join(''.join(c for c in texto if not unicodedata.combining(c)).replace('*', '').split())


def fecha(archivo):
    mes, anio = re.fullmatch(r'B-2389-([a-z]{2})(\d{4})', archivo.stem, re.I).groups()
    return datetime(int(anio), MESES[mes.lower()], 1)


def extraer(archivo):
    if archivo.read_bytes()[:2] == b'PK':
        with archivo.open('rb') as entrada:
            libro = load_workbook(entrada, read_only=True, data_only=True)
            filas = list(libro.worksheets[0].values)
            libro.close()
    else:
        libro = xlrd.open_workbook(str(archivo))
        hoja = libro.sheet_by_index(0)
        filas = [hoja.row_values(i) for i in range(hoja.nrows)]
    consumo, columna = next((i, j) for i, fila in enumerate(filas)
                           for j, valor in enumerate(fila) if normalizar(valor) == 'creditos de consumo')
    etiquetas = [normalizar(fila[columna]) for fila in filas]
    encabezado = next(fila for fila in filas if any('total banca multiple' in normalizar(v) for v in fila))
    mercado = next(j for j, v in enumerate(encabezado) if 'total banca multiple' in normalizar(v))
    falabella = next(j for j, v in enumerate(encabezado) if 'falabella' in normalizar(v))
    fin = next(i for i in range(consumo + 1, len(filas)) if etiquetas[i].startswith('creditos '))
    tarjetas = next(i for i in range(consumo + 1, fin) if etiquetas[i] == 'tarjetas de credito')
    prestamos = next(i for i in range(consumo + 1, fin) if etiquetas[i] == 'prestamos no revolventes')
    total = next(i for i, texto in enumerate(etiquetas) if texto.startswith('total creditos directos'))

    # La SBS publica porcentajes y el total de creditos directos en miles de soles.
    # Cada cuenta en millones = porcentaje * total / 100 / 1000.
    def saldo(fila, banco):
        return float(filas[fila][banco]) * float(filas[total][banco]) / 100 / 1000

    return fecha(archivo), saldo(tarjetas, mercado), saldo(prestamos, mercado), saldo(tarjetas, falabella), saldo(prestamos, falabella)


def main():
    archivos = sorted((CARPETA / 'fuentes').glob('*.XLS'), key=fecha)
    if not archivos:
        raise FileNotFoundError('No hay archivos XLS en fuentes.')
    datos = [extraer(archivo) for archivo in archivos]
    salida = CARPETA / 'output' / 'Cartera_consumo_banca_multiple.xlsx'
    salida.parent.mkdir(exist_ok=True)
    with xlsxwriter.Workbook(salida) as libro:
        hoja = libro.add_worksheet('Mensual')
        libro.set_properties({'title': 'Cartera de consumo de la banca multiple', 'author': ''})
        cabecera = libro.add_format({'font_name': 'Calibri', 'font_size': 11, 'bold': True,
                                     'text_wrap': True, 'align': 'center', 'valign': 'vcenter',
                                     'bottom': 1, 'bottom_color': '#BFBFBF'})
        mes = libro.add_format({'font_name': 'Calibri', 'font_size': 11, 'num_format': 'mmm-yyyy'})
        monto = libro.add_format({'font_name': 'Calibri', 'font_size': 11, 'num_format': '#,##0.000000'})
        cuota = libro.add_format({'font_name': 'Calibri', 'font_size': 11, 'num_format': '0.000000%'})
        titulos = ['Mes', 'Tarjetas de crédito de consumo\nBanca múltiple (S/ millones)',
                   'Préstamos de consumo no revolventes\nBanca múltiple (S/ millones)',
                   'Cartera de consumo\nBanca múltiple (S/ millones)',
                   'Tarjetas de crédito de consumo\nFalabella (S/ millones)',
                   'Préstamos de consumo no revolventes\nFalabella (S/ millones)',
                   'Cartera de consumo\nFalabella (S/ millones)', 'Participación de Falabella (%)']
        hoja.write_row(0, 0, titulos, cabecera)
        hoja.set_row(0, 58)
        hoja.set_column('A:A', 15)
        hoja.set_column('B:C', 34)
        hoja.set_column('D:D', 29)
        hoja.set_column('E:F', 34)
        hoja.set_column('G:G', 29)
        hoja.set_column('H:H', 26)
        hoja.freeze_panes(1, 1)
        hoja.hide_gridlines(2)
        for i, (dia, tm, pm, tf, pf) in enumerate(datos, 1):
            fila = i + 1
            mercado, falabella = tm + pm, tf + pf
            hoja.write_datetime(i, 0, dia, mes)
            hoja.write_number(i, 1, tm, monto)
            hoja.write_number(i, 2, pm, monto)
            hoja.write_formula(i, 3, f'=B{fila}+C{fila}', monto, mercado)
            hoja.write_number(i, 4, tf, monto)
            hoja.write_number(i, 5, pf, monto)
            hoja.write_formula(i, 6, f'=E{fila}+F{fila}', monto, falabella)
            # El total de banca multiple ya incluye a Banco Falabella.
            hoja.write_formula(i, 7, f'=G{fila}/D{fila}', cuota, falabella / mercado)
        hoja.autofilter(0, 0, len(datos), 7)
    print(f'{len(datos)} meses procesados. Excel guardado en {salida}')


if __name__ == '__main__':
    main()

