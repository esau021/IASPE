"""Control transparente de cierre IASPE / Anexo I SBS, sin modificar el motor de proyecciones.

Lo que no está desagregado NO se estima automáticamente. Los insumos externos
se almacenan con fuente/periodo; solo M24-M27 pueden recalcular el P&L existente.
"""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
import copy,math
import motor

# Identificadores estables, un catálogo sin duplicación contable.
CATALOG=[
 ('INT_REV','Ingresos por intereses - consumo revolvente','Comercial / Contabilidad','Intereses por créditos directos (5104+5107), consumo revolvente','Desagregación de M16 (reconcilia, NO altera M16)','CARGA'),
 ('INT_NOREV','Ingresos por intereses - consumo no revolvente','Comercial / Contabilidad','Intereses por créditos directos (5104+5107), consumo no revolvente','Desagregación de M16 (reconcilia, NO altera M16)','CARGA'),
 ('ATRA_REV','Cartera atrasada - consumo revolvente','Riesgo de Crédito','Saldos 1405+1406 por producto, historia mensual','Regresión propia pendiente de datos','MODELO'),
 ('ATRA_NOREV','Cartera atrasada - consumo no revolvente','Riesgo de Crédito','Saldos 1405+1406 por producto, historia mensual','Regresión propia pendiente de datos','MODELO'),
 ('REFI_REV','Cartera refinanciada y reestructurada - consumo revolvente','Riesgo de Crédito','Saldos 1403+1404 por producto, historia mensual','Regresión propia pendiente de datos','MODELO'),
 ('REFI_NOREV','Cartera refinanciada y reestructurada - consumo no revolvente','Riesgo de Crédito','Saldos 1403+1404 por producto, historia mensual','Regresión propia pendiente de datos','MODELO'),
 ('PROV_STOCK_REV','Provisiones acumuladas - consumo revolvente','Riesgo de Crédito / Contabilidad','Saldo 1409 por producto, historia mensual','Stock; requiere puente de provisiones','MODELO'),
 ('PROV_STOCK_NOREV','Provisiones acumuladas - consumo no revolvente','Riesgo de Crédito / Contabilidad','Saldo 1409 por producto, historia mensual','Stock; requiere puente de provisiones','MODELO'),
 ('GASTO_PROV_REV','Gasto por incobrabilidad - consumo revolvente','Riesgo de Crédito / Contabilidad','Flujo 4302 por producto, histórico y proyecciones','Exógeno por producto; concilia total M25','CARGA'),
 ('GASTO_PROV_NOREV','Gasto por incobrabilidad - consumo no revolvente','Riesgo de Crédito / Contabilidad','Flujo 4302 por producto, histórico y proyecciones','Exógeno por producto; concilia total M25','CARGA'),
 ('CASTIGOS_REV','Castigos y recuperaciones netos - consumo revolvente','Riesgo de Crédito','Movimientos mensuales de 1409, castigos, recuperos, FX','Puente contable de provisiones','CARGA'),
 ('CASTIGOS_NOREV','Castigos y recuperaciones netos - consumo no revolvente','Riesgo de Crédito','Movimientos mensuales de 1409, castigos, recuperos, FX','Puente contable de provisiones','CARGA'),
 ('APR_CRED_REV','APRC - consumo revolvente','Riesgo de Crédito','APRC por tipo de exposición','Regulatorio; insumo o modelo específico','CARGA'),
 ('APR_CRED_NOREV','APRC - consumo no revolvente','Riesgo de Crédito','APRC por tipo de exposición','Regulatorio; insumo o modelo específico','CARGA'),
 ('APR_CRED_OTROS','APRC - otras exposiciones','Riesgo de Crédito','APRC no consumo, garantías, ponderadores','Regulatorio; insumo','CARGA'),
 ('APR_MERC','APRM - mercado','Riesgo Financiero','APR mercado / tipo de cambio / trading book','Regulatorio; insumo','CARGA'),
 ('APR_OPER','APRO - operacional','Riesgo Operacional','APR operacional, método vigente','Regulatorio; insumo','CARGA'),
 ('PE_CET1','Patrimonio efectivo CO-N1','Contabilidad / Capital','Composición y deducciones CO-N1','Regulatorio; insumo','CARGA'),
 ('PE_AT1','Patrimonio efectivo CA-N1','Contabilidad / Capital','Componentes y deducciones CA-N1','Regulatorio; insumo','CARGA'),
 ('PE_N2','Patrimonio efectivo Nivel 2','Contabilidad / Capital','PE-N2, provisiones genéricas elegibles, deducciones','Regulatorio; insumo','CARGA'),
 ('COLCHON_CONS','Colchón de conservación','Gestión de Capital','Coeficiente regulatorio y APR aplicable','Cálculo normativo / control','CARGA'),
 ('COLCHON_CICLO','Colchón por ciclo económico','Gestión de Capital','Supuesto regulatorio por escenario y año','Exógeno condicionado a activación SBS','CARGA'),
 ('CAP_OBJETIVO','Patrimonio efectivo objetivo (S/ MM)','Gestión de Capital','Patrimonio objetivo y buffer de gestión, S/ MM','Política aprobada','CARGA'),
 ('RATIO_CAP_OBJ','Ratio de capital objetivo (decimal)','Gestión de Capital','Ratio objetivo; ejemplo 0.16 para 16%','Política aprobada','CARGA'),
 ('GER','GER (% patrimonio efectivo, decimal)','Riesgo Financiero / ALM','GER anual según metodología ALM','Insumo técnico de ALM','CARGA'),
 ('VPR','VPR (% patrimonio efectivo, decimal)','Riesgo Financiero / ALM','VPR anual según metodología ALM','Insumo técnico de ALM','CARGA'),
 ('REQ_CONC_SECTOR','PE por concentración sectorial','Riesgos / Capital','Requerimiento adicional sectorial anual','Insumo regulatorio SBS','CARGA'),
 ('FONDEO_INTER','Fondos interbancarios - pasivo','Tesorería','Presupuesto fondeo interbancario 2026-2030','Revisar supuesto M47 (S/ 60 MM)','VALIDAR'),
 ('DIVIDENDOS','Dividendos y transferencias a reservas','Finanzas / Capital','Política y presupuesto de dividendos y retenciones','Validar insumo M45','VALIDAR'),
 ('CRED_OTROS','Otros créditos residuales por tipo','Contabilidad','Apertura de cartera no consumo SBS y plan de cuentas','No reclasificar automáticamente','CARGA'),
 ('M24','Otros ingresos y gastos (total)','Contabilidad / Planeamiento','Proyección anual confirmada para M24','Actualiza modelo M24 y downstream','MOTOR'),
 ('M25','Provisiones créditos directos (total)','Riesgo de Crédito','Gasto anual 4302 confirmado para M25','Actualiza M25, impuesto y resultado','MOTOR'),
 ('M26','Depreciación y amortización (total)','Contabilidad / Planeamiento','Plan de amortizaciones e intangibles para M26','Actualiza M26, impuesto y resultado','MOTOR'),
 ('M27','Valuación activos / otras provisiones (total)','Contabilidad / Planeamiento','Proyección anual confirmada para M27','Actualiza M27, impuesto y resultado','MOTOR'),
]
COLUMNS=['codigo','cuenta','responsable','dato_solicitado','tratamiento','tipo']
INDEX={c[0]:dict(zip(COLUMNS,c)) for c in CATALOG}
YEARS=tuple(range(2026,2031))
SCENARIOS={'BASE','ESTRES','ESTRES_SEVERO','SENSIBILIDAD'}


def _f(models,mid,year):
    m=models.get(mid) or {}
    r=next((r for r in m.get('annual',[]) if r.get('year')==year),None)
    return float(r['value']) if r and r.get('value') is not None else None


def _safediv(a,b):
    return a/b if a is not None and b is not None and abs(b)>1e-9 else None


def snapshot(models=None):
    if models is None:
        models=motor.calculate()['models']
    models={m['id']:m for m in models} if isinstance(models,list) else models
    inputs=motor.read_state('insumos_bf_iaspe.json',{}) or {}
    records=[]
    for year in range(2025,2031):
        def f(mid):return _f(models,mid,year)
        a=f('47');p=f('47_pasivo');e=f('47_patrimonio');prev=f('47_disponible_previo');cash=f('47_disponible');offset=f('47_ajuste_bancos')
        rev=f('05');nr=f('06');gross=(rev+nr) if rev is not None and nr is not None else None
        from motor_47 import _source,provision_plan,provision_stock,provision_source
        if year == 2025:
            stock=281.817663
        elif 2026 <= year <= 2030:
            stock=provision_stock(provision_plan(_source(motor.SOURCE)),year)
        else:
            stock=None
        profit=f('29')
        prior=f('47') if year==2025 else _f(models,'47',year-1)
        patrprior=f('47_patrimonio') if year==2025 else _f(models,'47_patrimonio',year-1)
        def ext(code):
            v=inputs.get(code,{}).get(str(year),{})
            return v.get('value') if isinstance(v,dict) else None
        arrears=[ext('ATRA_REV'),ext('ATRA_NOREV')]
        refis=[ext('REFI_REV'),ext('REFI_NOREV')]
        arrears_total=sum(arrears) if all(x is not None for x in arrears) else None
        highrisk=arrears_total+sum(refis) if arrears_total is not None and all(x is not None for x in refis) else None
        ststocks=[ext('PROV_STOCK_REV'),ext('PROV_STOCK_NOREV')]
        stotal=sum(ststocks) if all(x is not None for x in ststocks) else None
        intrates=[ext('INT_REV'),ext('INT_NOREV')]
        interest_total=sum(intrates) if all(x is not None for x in intrates) else None
        expense_parts=[ext('GASTO_PROV_REV'),ext('GASTO_PROV_NOREV')]
        exp_total=sum(expense_parts) if all(x is not None for x in expense_parts) else None
        aprparts=[ext('APR_CRED_REV'),ext('APR_CRED_NOREV'),ext('APR_CRED_OTROS'),ext('APR_MERC'),ext('APR_OPER')]
        apr_total=sum(aprparts) if all(x is not None for x in aprparts) else None
        pe_parts=[ext('PE_CET1'),ext('PE_AT1'),ext('PE_N2')]
        pe_total=sum(pe_parts) if all(x is not None for x in pe_parts) else None
        records.append(dict(year=year,assets=a,liabilities=p,equity=e,difference=a-p-e if all(x is not None for x in [a,p,e]) else None,
            cashForecast=prev,cashReconciled=cash,banksAdjustment=offset,cashToDeposits=_safediv(cash,f('10')),
            cashAdjustmentPct=_safediv(offset,prev),loansRevolving=rev,loansNonRevolving=nr,loansConsumption=gross,
            loanLossExpense=f('25'),provisionStock=stock,loanLossStockMethod=('SBS histórico 2025' if year==2025 else provision_source(year)) + '; distinto del gasto M25',
            profit=profit,roa=_safediv(profit,(a+prior)/2 if a is not None and prior is not None else None) if year>2025 else None,
            roe=_safediv(profit,(e+patrprior)/2 if e is not None and patrprior is not None else None) if year>2025 else None,
            arrears=arrears_total,highRisk=highrisk,delinquency=_safediv(arrears_total,gross),highRiskRatio=_safediv(highrisk,gross),
            arrearsSource='Cargada por BF' if arrears_total is not None else 'Sin modelo por producto: NO se utiliza IASC como estimación',
            stockFromSegments=stotal,coverageArrears=_safediv(stotal,arrears_total),coverageHighRisk=_safediv(stotal,highrisk),
            interestByProduct=interest_total,interestReconciliation=(interest_total-f('16_creditos')) if interest_total is not None and f('16_creditos') is not None else None,
            expenseByProduct=exp_total,expenseReconciliation=exp_total-f('25') if exp_total is not None else None,
            aprTotal=apr_total,peTotal=pe_total,capitalRatio=_safediv(pe_total,apr_total),
            capitalSource='Solo reportes BF aprobados' if apr_total is not None and pe_total is not None else 'Pendiente de APR y/o PE completos'))
    fields=[]
    for c in CATALOG:
        detail=INDEX[c[0]]
        vals=inputs.get(c[0],{})
        years={str(y): vals.get(str(y),{}) for y in YEARS}
        fields.append(dict(detail,years=years,loaded=len([y for y in years.values() if isinstance(y,dict) and y.get('value') is not None])))
    scenarioCoverage={q:sum(len(v) for k,v in inputs.items() if k.startswith(q+':')) for q in SCENARIOS if q!='BASE'}
    return dict(years=records,catalog=fields,scenarioCoverage=scenarioCoverage,
        methodology={'balance':'Bancos y corresponsales = pasivo + patrimonio - activos distintos de bancos',
          'aperturas':'M05 y M06 son estimaciones separadas. Morosidad/provisiones por producto: pendientes de datos para estimar.',
          'ejecucion':'M24/M25/M26/M27 se aplican al motor. Resto queda en registro de insumos hasta implementar modelos especializados.',
          'warning':'El ajuste de liquidez iguala el balance POR CONSTRUCCIÓN; 0 en control no es verificación de caja ni de capital regulatorio.'})


def save(entries):
    if not isinstance(entries,list) or not entries or len(entries)>250:
        raise ValueError('La carga debe contener de 1 a 250 observaciones.')
    prepared=[]
    for r in entries:
        if not isinstance(r,dict):raise ValueError('Fila inválida.')
        code=str(r.get('codigo','')).strip().upper()
        if code not in INDEX:raise ValueError('Código de insumo desconocido: '+code)
        scenario=str(r.get('escenario','BASE') or 'BASE').strip().upper().replace('É','E').replace(' ','_')
        if scenario not in SCENARIOS:raise ValueError('Escenario inválido: '+scenario)
        try:year=int(str(r.get('anio','')))
        except:raise ValueError('Año inválido en '+code)
        if year not in YEARS:raise ValueError('Solo períodos 2026-2030: '+str(year))
        try:value=float(r.get('valor'))
        except:raise ValueError('Importe no numérico para '+code)
        if not math.isfinite(value):raise ValueError('Importe no finito para '+code)
        if code not in {'M24','M27','DIVIDENDOS'} and value < 0:raise ValueError('No admite importes negativos: '+code)
        if code in {'GER','VPR','RATIO_CAP_OBJ'} and not 0<=value<=1:raise ValueError('Los ratios deben ingresarse como decimales de 0 a 1: '+code)
        source=str(r.get('fuente','')).strip()
        if len(source)<6:raise ValueError('Indica fuente verificable para '+code+'/'+str(year))
        if len(source)>220:raise ValueError('Fuente demasiado extensa para '+code)
        prepared.append((code,str(year),value,source,scenario))
    with motor.LOCK:
        ext=copy.deepcopy(motor.read_state('insumos_bf_iaspe.json',{}) or {})
        manual=copy.deepcopy(motor.read_state('observaciones.json',{}) or {})
        applied=[];staged=[]
        timestamp=datetime.now(timezone.utc).isoformat()
        for code,year,value,source,scenario in prepared:
            codekey=code if scenario=='BASE' else scenario+':'+code
            ext.setdefault(codekey,{})[year]={'value':value,'source':source,'scenario':scenario,'loadedAt':timestamp}
            if INDEX[code]['tipo']=='MOTOR' and scenario=='BASE':
                modelid=code[1:]
                manual.setdefault(modelid,{})[year]=value
                applied.append(code+'/'+year)
            else:staged.append(scenario+'/'+code+'/'+year)
        # Nada se persiste hasta verificar que el motor acepta los datos directos.
        if applied:
            observed=motor.all_observations()
            for mid,v in manual.items():observed.setdefault(mid,{}).update(v)
            motor.calculate(observations=observed)
        motor.write_state('insumos_bf_iaspe.json',ext)
        if applied:motor.write_state('observaciones.json',manual)
    return {'saved':len(prepared),'appliedToMotor':applied,'stagedOnly':staged,'warning':'Solo los insumos M24-M27 de BASE se propagan al P&L. Datos de estrés/severo/sensibilidad se almacenan, pero NO impactan todavía el cálculo de escenarios.'}
