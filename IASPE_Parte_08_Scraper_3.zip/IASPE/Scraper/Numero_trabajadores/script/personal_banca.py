from __future__ import annotations

def actualizar_personal_banca():

    from pathlib import Path
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from datetime import datetime
    import csv
    import hashlib
    import os
    import re
    import time
    import unicodedata

    import requests
    import xlrd

    IASPE = Path(os.environ.get('IASPE_DIR', str(Path.home() / 'Desktop' / 'IASPE')))
    if not IASPE.is_dir():
        raise FileNotFoundError(f'No se encontró IASPE en {IASPE}. Modifica la variable IASPE.')
    BASE_LOCAL = IASPE / 'Scraper' / 'Numero_trabajadores'
    OUTPUT = BASE_LOCAL / 'output'
    XLS_DIR = BASE_LOCAL / 'fuentes' / 'B-2305'
    XLS_DIR.mkdir(parents=True, exist_ok=True)

    MODO = 'completo'
    ANIO_INICIO = 2016
    ANIO_FIN = datetime.now().year if datetime.now().month > 1 else datetime.now().year - 1
    ULTIMO_MES = datetime.now().month - 1 if datetime.now().month > 1 else 12

    MESES = {
      1: ('Enero','en'), 2: ('Febrero','fe'), 3: ('Marzo','ma'),
      4: ('Abril','ab'), 5: ('Mayo','my'), 6: ('Junio','jn'),
      7: ('Julio','jl'), 8: ('Agosto','ag'), 9: ('Setiembre','se'),
      10: ('Octubre','oc'), 11: ('Noviembre','no'), 12: ('Diciembre','di')
    }
    SBS_ROOT = 'https://intranet2.sbs.gob.pe/estadistica/financiera'
    REFERENCIA = 'https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c=B-2305'

    CORTES = [
        (anio,mes) for anio in range(ANIO_INICIO,ANIO_FIN+1)
        for mes in range(1, 13 if anio < ANIO_FIN else ULTIMO_MES+1)
        if MODO == 'completo' or mes == 12 or (anio == ANIO_FIN and mes == ULTIMO_MES)
    ]

    def url_sbs(anio, mes):
        nombre, sigla = MESES[mes]
        return f'{SBS_ROOT}/{anio}/{nombre}/B-2305-{sigla}{anio}.XLS'

    print('Carpeta:', BASE_LOCAL, flush=True)
    print('Períodos:', len(CORTES), '| desde', CORTES[0], 'hasta', CORTES[-1])
    print('Primer enlace:', url_sbs(*CORTES[0]))


    OLE = bytes.fromhex('D0CF11E0A1B11AE1')
    HEADERS = {
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/123.0 Safari/537.36',
        'Accept':'application/vnd.ms-excel,application/octet-stream,*/*',
        'Referer': REFERENCIA,
    }

    def excel_valido(data):
        return len(data) >= 512 and (data.startswith(OLE) or data.startswith(b'PK\x03\x04'))

    def obtener_archivo(corte):
        anio, mes = corte
        url = url_sbs(anio, mes)
        destino = XLS_DIR / url.rsplit('/',1)[-1]
        if destino.exists() and excel_valido(destino.read_bytes()):
            data = destino.read_bytes()
            return {'periodo': f'{anio}-{mes:02}', 'estado': 'existente', 'archivo':str(destino), 'url':url,
                    'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(), 'detalle':''}
        ultimo_error = ''
        for intento in range(2):
            try:
                with requests.Session() as sesion:
                    r = sesion.get(url, headers=HEADERS, timeout=(12,45), allow_redirects=True)
                r.raise_for_status()
                data = r.content
                if not excel_valido(data):
                    raise ValueError(f'Respuesta distinta de Excel (HTTP {r.status_code}, {r.headers.get("Content-Type")})')
                tmp = destino.with_suffix('.tmp')
                tmp.write_bytes(data)
                tmp.replace(destino)
                return {'periodo': f'{anio}-{mes:02}', 'estado': 'descargado', 'archivo':str(destino), 'url':url,
                        'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(), 'detalle':''}
            except (requests.RequestException, ValueError, OSError) as e:
                ultimo_error = f'{type(e).__name__}: {str(e)[:180]}'
                if '404' in ultimo_error:
                    break
                if intento == 0:
                    time.sleep(1)
        return {'periodo':f'{anio}-{mes:02}', 'estado':'error', 'archivo':'', 'url':url,
                'bytes':0, 'sha256':'', 'detalle':ultimo_error}

    DESCARGAS = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(obtener_archivo,corte):corte for corte in CORTES}
        for i,future in enumerate(as_completed(futures), 1):
            dato = future.result()
            DESCARGAS.append(dato)
            if dato['estado']=='error':
                print('ERROR', dato['periodo'], dato['detalle'])
            elif i % 12 == 0 or i == len(futures):
                print(f'[{i:03d}/{len(futures):03d}] B-2305 {dato["periodo"]}: {dato["estado"]}', flush=True)
    DESCARGAS.sort(key=lambda x:x['periodo'])
    print('Descargados:',sum(x['estado']=='descargado' for x in DESCARGAS),
          '| ya existentes:',sum(x['estado']=='existente' for x in DESCARGAS),
          '| errores:',sum(x['estado']=='error' for x in DESCARGAS))


    BANCOS = {
     'Banco de Crédito del Perú': ['banco de credito del peru','de credito del peru','banco de credito','bcp'],
     'Interbank': ['interbank','banco internacional del peru'],
     'BBVA Perú': ['bbva peru','bbva','banco continental','continental'],
     'Scotiabank Perú': ['scotiabank peru','scotiabank'],
     'Banco Falabella Perú': ['banco falabella peru','banco falabella','falabella'],
     'Santander Consumer Bank': ['santander consumer bank','santander consumer'],
     'Banco Pichincha': ['banco pichincha','banco financiero','pichincha','financiero'],
     'BanBif': ['banbif','banco interamericano de finanzas','interamericano de finanzas'],
     'Banco GNB': ['banco gnb','gnb'],
     'Banco Ripley': ['banco ripley','ripley'],
     'Banco de Comercio': ['banco de comercio','de comercio','bancom'],
     'Compartamos Banco': ['compartamos banco','compartamos'],
     'Alfin Banco': ['alfin banco','alfin','azteca peru'],
     'Banco Efectiva': ['banco efectiva','financiera efectiva','efectiva'],
     'Mibanco': ['mibanco','mi banco'],
    }

    def normalizar(v):
        t = unicodedata.normalize('NFKD', str(v).casefold())
        t = ''.join(c for c in t if not unicodedata.combining(c))
        t = re.sub(r'[^a-z0-9 ]+', ' ', t)
        return re.sub(r'\s+', ' ', t).strip()

    def identificar_banco(texto):
        t = normalizar(texto)
        if t.startswith('b '):
            t=t[2:]
        t=re.sub(r'\s+con sucursales en el exterior.*$', '', t).strip()
        if not t or t.startswith(('total','subtotal')):
            return None
        for banco, alias in BANCOS.items():
            for item in alias:
                q = normalizar(item)
                if t == q or (len(q) >= 7 and re.search(r'(?:^| )'+re.escape(q)+r'(?: |$)', t)):
                    return banco
        return None

    def numero(v):
        if isinstance(v, (int,float)) and not isinstance(v,bool):
            return float(v)
        t = str(v).strip().replace(' ','')
        if not t or t in ('-','--','n.d.','nan'):
            return None
        t=t.replace(',','')
        try:
            return float(t)
        except ValueError:
            return None

    def extraer_tabla(filas, archivo, periodo, hoja):
        if not filas:
            return [],'Hoja vacía'
        # El encabezado de la SBS incluye Empresas y Total.
        cabecera = None
        for i, fila in enumerate(filas[:min(24,len(filas))]):
            nombres=[normalizar(v) for v in fila]
            if any(x in ('empresas','entidades','bancos','empresa') for x in nombres) and 'total' in nombres:
                cabecera=i
                break
        if cabecera is None:
            return [],'No se encontraron columnas Empresas/Total'
        hdr=[normalizar(v) for v in filas[cabecera]]
        idx_total=hdr.index('total')
        idx_empresa=next(i for i,c in enumerate(hdr) if c in ('empresas','entidades','bancos','empresa'))
        # Reportes de cajas y bancos comparten estructura: validar el archivo antes de extraer.
        if not archivo.upper().startswith('B-2305-'):
            return [],'Código distinto de B-2305'
        result=[]
        for idx,row in enumerate(filas[cabecera+1:], start=cabecera+2):
            if idx_empresa>=len(row) or idx_total>=len(row):
                continue
            rawname=str(row[idx_empresa]).strip()
            banco=identificar_banco(rawname)
            if not banco:
                continue
            total=numero(row[idx_total])
            if total is None or total<0 or total != int(total):
                continue
            item={'periodo':periodo,'banco':banco,'personal_total':int(total),
                  'nombre_sbs':rawname,'archivo':archivo,'hoja':hoja,'fila_excel':idx}
            for field,pattern in [('gerentes','gerentes'),('funcionarios','funcionarios'),('empleados','empleados'),('otros','otros')]:
                found=next((i for i,name in enumerate(hdr) if name==pattern), None)
                val=numero(row[found]) if found is not None and found<len(row) else None
                item[field]=int(val) if val is not None and val >= 0 and val==int(val) else ''
            result.append(item)
        return result, '' if result else 'No se reconoció ninguna de las 16 entidades'

    print('Entidades configuradas:',len(BANCOS))


    REGISTROS=[]
    AUDITORIA=[]
    for d in DESCARGAS:
        if d['estado']=='error':
            AUDITORIA.append({'periodo':d['periodo'],'archivo':'','estado':'error_descarga','detalle':d['detalle']})
            continue
        p=Path(d['archivo'])
        try:
            libro=xlrd.open_workbook(str(p),on_demand=True)
            registros=[];notas=[]
            for sh in libro.sheets():
                filas=[sh.row_values(i) for i in range(sh.nrows)]
                data,msg=extraer_tabla(filas,p.name,d['periodo'],sh.name)
                registros.extend(data)
                if msg: notas.append(f'{sh.name}: {msg}')
            REGISTROS.extend(registros)
            AUDITORIA.append({'periodo':d['periodo'],'archivo':p.name,'estado':'leido' if registros else 'revisar_estructura',
                              'detalle':f'{len(registros)} coincidencias; '+('; '.join(notas[:3]) if notas else '')})
        except Exception as e:
            AUDITORIA.append({'periodo':d['periodo'],'archivo':p.name,'estado':'error_lectura',
                              'detalle':f'{type(e).__name__}: {str(e)[:140]}'})

    por_clave={}
    for r in REGISTROS:
        por_clave.setdefault((r['periodo'],r['banco']),[]).append(r)
    CONSOLIDADO=[]
    for (periodo,banco),items in sorted(por_clave.items()):
        valores=set(x['personal_total'] for x in items)
        if len(valores)>1:
            AUDITORIA.append({'periodo':periodo,'archivo':','.join(x['archivo'] for x in items),
                              'estado':'duplicado_conflictivo','detalle':f'{banco}: {sorted(valores)}'})
            continue
        CONSOLIDADO.append(items[0])

    campos=['periodo','banco','personal_total','gerentes','funcionarios','empleados','otros','nombre_sbs','archivo','hoja','fila_excel']
    with (OUTPUT/'personal_banca_mensual.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=campos);writer.writeheader();writer.writerows(CONSOLIDADO)
    with (OUTPUT/'auditoria.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=['periodo','archivo','estado','detalle']);writer.writeheader();writer.writerows(AUDITORIA)
    with (OUTPUT/'descargas.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=['periodo','estado','archivo','url','bytes','sha256','detalle']);writer.writeheader();writer.writerows([{**d,'archivo':'fuentes/B-2305/'+Path(d['archivo']).name if d['archivo'] else ''} for d in DESCARGAS])

    print('Filas consolidadas:',len(CONSOLIDADO))
    print('Períodos con datos:',len(set(r['periodo'] for r in CONSOLIDADO)))
    print('Entidades reconocidas:',len(set(r['banco'] for r in CONSOLIDADO)),'de',len(BANCOS))
    print('Alertas:',sum(r['estado'] not in ('leido',) for r in AUDITORIA))
    print('Últimas observaciones de Falabella:')
    for r in [x for x in CONSOLIDADO if x['banco']=='Banco Falabella Perú'][-8:]:
        print(r['periodo'],r['personal_total'],r['nombre_sbs'])
    print('Salida:', OUTPUT)


    print(f'{"Año":<8}{"Falabella":>14}{"Cobertura":>16}')
    ultimo = max((r['periodo'] for r in CONSOLIDADO), default='')
    for anio in range(ANIO_INICIO,ANIO_FIN+1):
        fecha=f'{anio}-12' if anio < ANIO_FIN else ultimo
        filas=[r for r in CONSOLIDADO if r['periodo']==fecha]
        f=next((r for r in filas if r['banco']=='Banco Falabella Perú'),None)
        print(f'{anio:<8}{f["personal_total"] if f else "—":>14}{str(len(filas))+" / 15":>16}')

    print('\nEntidades faltantes en el último mes configurado:')
    actual={r['banco'] for r in CONSOLIDADO if r['periodo']==ultimo}
    for b in BANCOS:
        if b not in actual:
            print('-',b)



if __name__ == "__main__":
    actualizar_personal_banca()
