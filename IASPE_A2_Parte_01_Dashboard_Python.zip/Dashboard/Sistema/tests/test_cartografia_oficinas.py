"""La cartografía conserva códigos, topología, islas y los límites de Lima/Callao."""
from pathlib import Path
import importlib.util,json,sys,tempfile,unittest,zipfile

BASE=Path(__file__).resolve().parents[3]/'IASPE/Scraper/Oficinas'
spec=importlib.util.spec_from_file_location('convertir_cartografia',BASE/'script/convertir_cartografia.py')
c=importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


class CartografiaOficinas(unittest.TestCase):
    def test_unknown_crs_is_rejected_before_replacing_an_existing_map(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_map_crs_') as temp:
            folder=Path(temp);original=BASE/'fuentes/Cartografia/Departamental.zip';source=folder/'invalid.zip'
            with zipfile.ZipFile(original) as before,zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as after:
                for name in before.namelist():
                    if Path(name).suffix.lower() in ('.shp','.shx','.dbf','.prj','.cpg'):
                        after.writestr(name,b'PROJCS["Unknown"]' if name.endswith('.prj') else before.read(name))
            output=folder/'departamentos.geojson';valid=(BASE/'output/departamentos.geojson').read_bytes();output.write_bytes(valid)
            with self.assertRaises(ValueError):c.convert(source,output)
            self.assertEqual(output.read_bytes(),valid)

    def test_real_asset_has_all_codes_rings_and_distinct_lima_callao(self):
        geo=json.loads((BASE/'output/departamentos.geojson').read_text(encoding='utf-8'))
        source,_,_=c.read_archive(BASE/'fuentes/Cartografia/Departamental.zip')
        indexed={feature['properties']['code']:feature for feature in geo['features']}
        self.assertEqual(set(indexed),{f'{n:02d}' for n in range(1,26)})
        for row in source:
            geometry=indexed[row['code']]['geometry']
            self.assertEqual(len(c.rings(geometry)),len(c.rings(row['geometry'])))
            self.assertTrue(c.shape(geometry).is_valid)
            if row['code'] in ('07','15'):
                self.assertEqual({p for r in c.rings(geometry) for p in r},
                                 {p for r in c.rings(row['geometry']) for p in r})
                self.assertTrue(c.shape(geometry).equals(c.shape(row['geometry'])))

    def test_shared_boundary_is_simplified_once_without_gap_or_overlap(self):
        boundary=[(-75.,-10.),(-75.0001,-9.9995),(-75.,-9.999)]
        left=[(-75.01,-10.),*boundary,(-75.01,-9.999),(-75.01,-10.)]
        right=[boundary[0],(-74.99,-10.),(-74.99,-9.999),*boundary[::-1]]
        rows=[{'code':code,'geometry':{'type':'Polygon','coordinates':[ring]}} for code,ring in [('01',left),('02',right)]]
        generated,stats=c.optimized(rows,100.)
        original=[c.shape(row['geometry']) for row in rows];new=[c.shape(g) for g in generated]
        self.assertTrue(new[0].union(new[1]).equals(original[0].union(original[1])))
        self.assertEqual(new[0].intersection(new[1]).area,0.)
        self.assertGreater(new[0].boundary.intersection(new[1].boundary).length,0.)
        self.assertTrue(all(point in {p for ring in c.rings(rows[index]['geometry']) for p in ring}
            for index,geometry in enumerate(generated) for ring in c.rings(geometry) for point in ring))

    def test_tiny_island_and_hole_are_kept_even_at_large_tolerance(self):
        main=[(-75.,-10.),(-74.,-10.),(-74.,-9.),(-75.,-9.),(-75.,-10.)]
        hole=[(-74.9,-9.9),(-74.9,-9.89999),(-74.89999,-9.89999),(-74.89999,-9.9),(-74.9,-9.9)]
        island=[(-75.1,-10.1),(-75.09999,-10.1),(-75.09999,-10.09999),(-75.1,-10.09999),(-75.1,-10.1)]
        rows=[{'code':'01','geometry':{'type':'MultiPolygon','coordinates':[[main,hole],[island]]}}]
        result,_=c.optimized(rows,100000.)
        self.assertEqual(len(c.rings(result[0])),3)
        self.assertTrue(c.shape(result[0]).equals(c.shape(rows[0]['geometry'])))


if __name__=='__main__':unittest.main()
