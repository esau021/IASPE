"""Catálogo compartido de comparables; los IDs IASPE no son códigos SBS.

Las fechas son el primer periodo mensual del tipo/nombre publicado por SBS,
que puede diferir de la fecha jurídica de autorización. No empalma valores.
"""
from __future__ import annotations

from copy import deepcopy
import re
import unicodedata

CENCOSUD_ID = 'crac_18'
CATEGORIES = ('Bancos', 'Empresas financieras', 'Cajas rurales')
BANKS = {
    '01': 'Banco de Crédito del Perú', '02': 'Interbank', '03': 'BBVA Perú',
    '04': 'Scotiabank Perú', '05': 'Banco Falabella Perú',
    '06': 'Santander Consumer Bank', '07': 'Banco Pichincha', '08': 'BanBif',
    '09': 'Banco GNB', '10': 'InFinance XP', '11': 'Banco Ripley',
    '12': 'Banco de Comercio', '13': 'Compartamos Banco', '14': 'Alfin Banco',
    '15': 'Banco Efectiva', '16': 'Mibanco',
    CENCOSUD_ID: 'Caja Rural de Ahorro y Crédito Cencosud Scotia Perú S.A.',
}
DIRECTORY = 'https://www.sbs.gob.pe/app/pp/empresasweb/Paginas/EmpCaptarDep.aspx'
REPORT = 'https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c='


def _period(start, end, category, name):
    return {'from': start, 'to': end, 'category': category, 'name': name}


HISTORY = {
    '03': [_period('2012-01', '2019-05', CATEGORIES[0], 'Banco Continental'),
           _period('2019-06', None, CATEGORIES[0], BANKS['03'])],
    '06': [_period('2012-01', '2025-02', CATEGORIES[1], 'CrediScotia Financiera'),
           _period('2025-03', '2025-05', CATEGORIES[1], 'Financiera Santander Consumer'),
           _period('2025-06', None, CATEGORIES[0], BANKS['06'])],
    '10': [_period('2012-01', '2016-05', CATEGORIES[1], 'Financiera UNO'),
           _period('2016-06', '2026-01', CATEGORIES[1], 'Financiera Oh!'),
           _period('2026-02', None, CATEGORIES[1], BANKS['10'])],
    '07': [_period('2012-01', '2018-07', CATEGORIES[0], 'Banco Financiero'),
           _period('2018-08', None, CATEGORIES[0], BANKS['07'])],
    '13': [_period('2012-01', '2024-12', CATEGORIES[1], 'Compartamos Financiera'),
           _period('2025-01', None, CATEGORIES[0], BANKS['13'])],
    '14': [_period('2012-01', '2021-10', CATEGORIES[0], 'Banco Azteca del Perú'),
           _period('2021-11', None, CATEGORIES[0], BANKS['14'])],
    '15': [_period('2012-01', '2026-05', CATEGORIES[1], 'Financiera Efectiva'),
           _period('2026-06', None, CATEGORIES[0], BANKS['15'])],
    CENCOSUD_ID: [_period('2012-01', '2019-02', CATEGORIES[0], 'Banco Cencosud'),
                  _period('2019-03', '2020-06', CATEGORIES[2], 'Caja Rural de Ahorro y Crédito CAT Perú'),
                  _period('2020-07', None, CATEGORIES[2], BANKS[CENCOSUD_ID])],
}
SOURCES = {
    '03': [REPORT + 'B-2305', DIRECTORY],
    '06': [REPORT + 'B-3101', REPORT + 'B-2201',
           'https://www.sbs.gob.pe/LinkClick.aspx?fileticket=qYTVWFtc-5c%3D&portalid=0'],
    '10': [REPORT + 'B-3202', DIRECTORY],
    '07': [REPORT + 'B-2305', DIRECTORY],
    '13': [REPORT + 'B-3101', REPORT + 'B-2201',
           'https://intranet2.sbs.gob.pe/estadistica/financiera/2025/Enero/SF-2102-en2025.PDF'],
    '15': [REPORT + 'B-3202', REPORT + 'B-2305',
           'https://busquedas.elperuano.pe/dispositivo/NL/2518126-1'],
    CENCOSUD_ID: [REPORT + 'B-2201', REPORT + 'C-2101', REPORT + 'C-2202', REPORT + 'C-2301',
                  'https://www.sbs.gob.pe/LinkClick.aspx?fileticket=qYTVWFtc-5c%3D&portalid=0'],
}
ALIASES = {
    '01': ('Banco de Crédito del Perú', 'B. Crédito del Perú', 'B. de Crédito del Perú', 'B. de Crédito', 'B. Crédito', 'BCP',
           'B. de Crédito del Perú (con sucursales en el exterior)',
           'Banco de Crédito del Perú (con sucursales en el exterior)'),
    '02': ('Interbank', 'B. Interbank', 'B. Internacional del Perú', 'Banco Internacional del Perú'),
    '03': ('BBVA Perú', 'Banco BBVA Perú', 'B. BBVA Perú', 'BBVA', 'Banco Continental', 'B. Continental'),
    '04': ('Scotiabank Perú', 'Scotiabank'),
    '05': ('Banco Falabella Perú', 'Banco Falabella', 'B. Falabella Perú', 'B. Falabella'),
    '06': ('Crediscotia Financiera', 'Financiera Santander Consumer', 'Santander Consumer Bank'),
    '10': ('Financiera UNO', 'Financiera Oh!', 'Financiera Oh', 'InFinance XP'),
    '07': ('Banco Pichincha', 'B. Pichincha', 'Banco Financiero', 'B. Financiero'),
    '08': ('BanBif', 'B. Interamericano de Finanzas', 'Banco Interamericano de Finanzas'),
    '09': ('Banco GNB', 'Banco GNB Perú', 'B. GNB', 'GNB Perú'),
    '11': ('Banco Ripley', 'B. Ripley'),
    '12': ('Banco de Comercio', 'B. Comercio', 'B. de Comercio', 'Bancom'),
    '13': ('Compartamos Financiera', 'Compartamos Banco'),
    '14': ('Banco Azteca Perú', 'B. Azteca Perú', 'Alfin Banco'),
    '15': ('Financiera Efectiva', 'Banco Efectiva', 'B. Efectiva'),
    CENCOSUD_ID: ('Banco Cencosud', 'B. Cencosud', 'CRAC CAT', 'Caja Rural CAT', 'CRAC Cencosud Scotia',
                  'CRAC Censosud Scotia', 'Cencosud Scotia', BANKS[CENCOSUD_ID]),
}


def _normalized_name(value):
    value = re.sub(r'\bS\.?\s*A\.?\s*(?:A\.?)?\s*$', '', str(value or ''), flags=re.I)
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z]', '', value)


def match_entity(name):
    normalized = _normalized_name(name)
    if not normalized:
        return None
    matches = [identifier for identifier, current in BANKS.items()
               if normalized in {_normalized_name(v) for v in (*ALIASES.get(identifier, ()), current)}]
    if len(matches) > 1:
        raise ValueError('Denominación SBS ambigua en el catálogo institucional')
    return matches[0] if matches else None


def category_at(identifier, period=None):
    history = HISTORY.get(identifier, [_period('2012-01', None, CATEGORIES[0], BANKS[identifier])])
    if not period:
        return history[-1]['category']
    month = str(period)[:7]
    for entry in history:
        if entry['from'] <= month and (entry['to'] is None or month <= entry['to']):
            return entry['category']
    return None


def entity_metadata(identifier, period=None):
    name = BANKS[identifier]
    history = deepcopy(HISTORY.get(identifier, [_period('2012-01', None, CATEGORIES[0], name)]))
    category = category_at(identifier, period)
    result = {'id': identifier, 'name': name, 'nombre': name, 'category': category,
              'category_history': history, 'aliases': list(ALIASES.get(identifier, (name,))),
              'classification_sources': SOURCES.get(identifier, [DIRECTORY]),
              'classification_basis': 'Periodo de publicación mensual SBS; no empalme de cifras',
              'sbs_type': {'Bancos': 'B', 'Empresas financieras': 'F', 'Cajas rurales': 'CR'}.get(category),
              'sbs_code': '18' if identifier == CENCOSUD_ID and category == CATEGORIES[2] else None}
    result['sistema'] = {'Bancos': 'Banca Múltiple', 'Empresas financieras': 'Financiera',
                         'Cajas rurales': 'Caja Rural'}.get(category)
    return result


def catalog(period=None):
    return [entity_metadata(identifier, period) for identifier in BANKS]
