"""Regresiones sobre originales SBS conservados por el actualizador, sin red."""
import importlib.util
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[3]
SPEC=importlib.util.spec_from_file_location('oficinas_real_sources_tests',ROOT/'IASPE/Scraper/Oficinas/script/actualizar_oficinas.py')
source=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(source)


class RealPublishedOfficesTests(unittest.TestCase):
    def body(self,report,period):
        path=ROOT/f'IASPE/Scraper/Oficinas/fuentes/{report}/{report}-{period}.XLS'
        if not path.is_file():self.skipTest('Original histórico todavía no adquirido: '+path.name)
        return path.read_bytes()

    def parse(self,report,period,**kwargs):
        return source.parse_workbook(self.body(report,period),report,period,**kwargs)

    def test_september_real_formats_separate_peru_exterior_and_license(self):
        rows={}
        for report in source.REPORTS:rows.update(self.parse(report,'2026-09'))
        self.assertEqual(len(rows),17)
        self.assertEqual(rows['05']['counts'],dict(zip((f'{n:02}' for n in range(1,26)),
            [0,1,0,2,0,1,3,2,0,1,3,1,4,2,28,1,0,0,0,3,0,0,1,0,1])))
        self.assertEqual((rows['05']['total'],rows['05']['coverage']),(54,15))
        self.assertEqual((rows['01']['total'],rows['01']['outsidePeru'],rows['01']['sourceTotal']),(311,2,313))
        self.assertEqual((rows['crac_18']['total'],rows['crac_18']['counts']['15'],rows['crac_18']['counts']['07']),(64,45,2))
        self.assertEqual(rows['15']['category'],'Bancos')
        self.assertTrue(all(row['sbsCode'] is None for row in rows.values()))

    def test_historical_printed_dash_has_both_margins_not_blank_imputation(self):
        rows=self.parse('B-3201','2012-01',strict=False)
        record=rows['10']
        self.assertTrue(record['source']['dashCertification']['grandTotalReconciled'])
        self.assertEqual(sum(record['counts'].values()),record['total'])
        self.assertTrue(record['source']['derivedZeroCells'])

    def test_unreported_rural_departments_remain_missing(self):
        record=self.parse('C-2201','2025-12',strict=False)['crac_18']
        self.assertEqual(record['total'],64)
        self.assertEqual(record['source']['unreportedDepartments'],['16','17','18'])
        self.assertTrue(all(record['counts'][code] is None for code in ('16','17','18')))
        self.assertIsNone(record['coverage'])

    def test_wrong_internal_month_is_rejected_without_reassignment(self):
        body=self.body('B-2303','2023-11')
        with self.assertRaisesRegex(ValueError,'fecha interna'):
            source.parse_workbook(body,'B-2303','2023-11',strict=False)

    def test_published_secondary_discrepancy_does_not_replace_national_rows(self):
        body=self.body('B-2303','2022-07')
        with self.assertRaises(ValueError):source.parse_workbook(body,'B-2303','2022-07')
        audit=[];rows=source.parse_workbook(body,'B-2303','2022-07',strict=False,audit=audit)
        self.assertTrue(audit)
        self.assertFalse(rows['05']['source']['sectorControl']['reconciled'])
        self.assertEqual(sum(rows['05']['counts'].values()),rows['05']['total'])

    def test_us_closing_dates_and_local_cat_identity_are_supported(self):
        for period in ('2020-12','2023-06'):
            self.assertIn('05',self.parse('B-2303',period,strict=False))
        self.assertIn('crac_18',self.parse('C-2201','2019-03',strict=False))
        self.assertEqual(self.parse('B-3201','2026-05',strict=False)['15']['category'],'Empresas financieras')
        self.assertEqual(self.parse('B-2303','2026-06',strict=False)['15']['category'],'Bancos')


if __name__=='__main__':unittest.main()
