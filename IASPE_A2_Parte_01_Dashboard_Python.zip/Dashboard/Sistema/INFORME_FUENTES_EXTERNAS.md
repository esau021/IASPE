# Fuentes de proyecciones externas

El panel consulta pronósticos oficiales de Perú y conserva las ediciones anteriores para comparación.

- **FMI — WEO:** https://data.imf.org/datasets/WEO. Se utilizan PBI real, inflación al cierre, desempleo y población. La actualización consulta el catálogo y verifica los metadatos oficiales; los valores proceden del Excel WEO de la edición correspondiente.
- **MEF — MMM/IAPM:** https://www.gob.pe/institucion/mef/colecciones/21-marco-macroeconomico-multianual-mmm. Se utilizan los cuadros de proyecciones macroeconómicas publicados.
- **BCRP:** https://www.bcrp.gob.pe/publicaciones/reporte-de-inflacion.html y https://www.bcrp.gob.pe/estadisticas/encuesta-de-expectativas-macroeconomicas.html. La descarga automática de algunos documentos puede estar limitada por el sitio oficial.

Los botones **Actualizar MEF** y **Actualizar FMI** consultan cada fuente por separado. Una descarga fallida no elimina el último dato válido. El historial registra fuente, edición, fecha, año, valor y documento de respaldo.

Las proyecciones externas no modifican directamente los modelos financieros ni los supuestos de cierre de 2026.
