"""Panel histórico por banco de cartera de consumo SBS (B-2389).

Solo datos observados. Estructura de créditos directos por tipo y modalidad:
Tarjetas de consumo + préstamos no revolventes de consumo.
No modifica los outputs ni los modelos oficiales IASPE.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime
import json
from pathlib import Path
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[4]
SCRAPER = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'Dashboard' / 'Sistema' / 'vendor'
sys.path.insert(0, str(VENDOR))
sys.path.insert(0,str(ROOT/'Dashboard'/'Sistema'))
from instituciones_sbs import match_entity, entity_metadata
import xlrd

SOURCE = SCRAPER / 'fuentes'
OUTPUT = ROOT / 'Dashboard' / 'Sistema' / 'data' / 'cartera_consumo_bancos.json'
MONTHS = dict(zip(('en','fe','ma','ab','my','jn','jl','ag','se','oc','no','di'),range(1,13)))


def norm(value):
    s = unicodedata.normalize('NFD', str(value or '').lower())
    return ' '.join(''.join(c for c in s if not unicodedata.combining(c)).replace('*','').replace('2/','').split())


def spreadsheet_rows(file):
    if file.read_bytes()[:2] != b'PK':
        book = xlrd.open_workbook(str(file))
        tab = book.sheet_by_index(0)
        return [tab.row_values(i) for i in range(tab.nrows)]
    # Tres archivos SBS con contenido OOXML a pesar de la extensión .XLS.
    ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
        'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    with zipfile.ZipFile(file) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            xml=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(x.text or '' for x in si.findall('.//x:t',ns)) for si in xml.findall('x:si',ns)]
        workbook=ET.fromstring(z.read('xl/workbook.xml'))
        first=workbook.find('x:sheets/x:sheet',ns)
        relation=first.attrib.get('{'+ns['r']+'}id')
        relns={'p':'http://schemas.openxmlformats.org/package/2006/relationships'}
        relroot=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target=next((r.attrib['Target'] for r in relroot.findall('p:Relationship',relns) if r.attrib.get('Id')==relation), 'worksheets/sheet1.xml')
        loc=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        loc=loc.replace('xl/xl/','xl/')
        tree=ET.fromstring(z.read(loc))
        result=[]
        for row in tree.findall('.//x:sheetData/x:row',ns):
            cells={}
            for c in row.findall('x:c',ns):
                addr=c.attrib.get('r','')
                letters=re.match(r'[A-Z]+',addr)
                if not letters:continue
                col=0
                for letter in letters.group(0):col=col*26+ord(letter)-64
                col-=1
                cell_type=c.attrib.get('t')
                v=c.find('x:v',ns)
                if cell_type=='inlineStr':
                    item=''.join(t.text or '' for t in c.findall('.//x:t',ns))
                elif v is not None:
                    raw=v.text or ''
                    if cell_type=='s':item=shared[int(raw)]
                    elif cell_type in ('str','e'):item=raw
                    else:
                        try:item=float(raw)
                        except ValueError:item=raw
                else:item=''
                cells[col]=item
            result.append([cells.get(i,'') for i in range(max(cells,default=-1)+1)])
        return result


# Mantener entidades distintas cuando la SBS las informa por separado.
NAMES = {
 'bbva':'BBVA Perú', 'bcp':'Banco de Crédito del Perú', 'interbank':'Interbank',
 'scotiabank':'Scotiabank Perú', 'falabella':'Banco Falabella', 'banbif':'BanBif',
 'pichincha':'Banco Pichincha', 'mibanco':'Mibanco', 'ripley':'Banco Ripley',
 'bancom':'Bancom / Banco de Comercio', 'gnb':'Banco GNB',
 'santander':'Banco Santander Perú', 'santander_consumer':'Santander Consumer Bank',
 'cencosud':'Banco Cencosud', 'azteca':'Banco Azteca Perú', 'alfin':'Alfin Banco',
 'bci':'Banco BCI Perú', 'compartamos':'Compartamos Banco',
 'efectiva':'Banco Efectiva', 'citibank':'Citibank Perú',
 'icbc':'ICBC Perú', 'china':'Bank of China', 'deutsche':'Deutsche Bank Perú',
 'hsbc':'HSBC Bank Perú'
}

def bank_id(name):
    n=norm(name)
    if not n or n=='concepto' or 'total banca multiple' in n:return None
    if 'falabella' in n:return 'falabella'
    if 'ripley' in n:return 'ripley'
    if 'interbank' in n:return 'interbank'
    if 'de credito del peru' in n:return 'bcp'
    if 'bbva' in n or 'continental' in n:return 'bbva'
    if 'scotiabank' in n:return 'scotiabank'
    if 'interamericano de finanzas' in n or 'banbif' in n:return 'banbif'
    if 'financiero' in n or 'pichincha' in n:return 'pichincha'
    if 'mibanco' in n:return 'mibanco'
    if 'de comercio' in n or 'bancom' in n:return 'bancom'
    if 'b. gnb' in n:return 'gnb'
    if 'santander consumer' in n:return 'santander_consumer'
    if 'santander' in n:return 'santander'
    if 'cencosud' in n:return 'cencosud'
    if 'azteca' in n:return 'azteca'
    if 'alfin' in n:return 'alfin'
    if 'bci' in n:return 'bci'
    if 'compartamos' in n:return 'compartamos'
    if 'efectiva' in n:return 'efectiva'
    if 'citibank' in n:return 'citibank'
    if 'icbc' in n:return 'icbc'
    if 'bank of china' in n:return 'china'
    if 'deutsche' in n:return 'deutsche'
    if 'hsbc' in n:return 'hsbc'
    raise ValueError(f'Entidad SBS no reconocida: {name!r}')


def read_month(file):
    rows=spreadsheet_rows(file)
    cons, labelcol = next((i,j) for i,row in enumerate(rows) for j,val in enumerate(row) if norm(val)=='creditos de consumo')
    headers = next(row for row in rows if any('total banca multiple' in norm(v) for v in row))
    mk = next(i for i,v in enumerate(headers) if 'total banca multiple' in norm(v))
    labels=[norm(row[labelcol]) if len(row)>labelcol else '' for row in rows]
    stop=next(i for i in range(cons+1,len(rows)) if labels[i].startswith('creditos '))
    cc=next(i for i in range(cons+1,stop) if labels[i]=='tarjetas de credito')
    loans=next(i for i in range(cons+1,stop) if labels[i]=='prestamos no revolventes')
    total=next(i for i,l in enumerate(labels) if l.startswith('total creditos directos'))
    def amount(col, idx):
        try:
            balance=float(rows[total][col]); value=rows[idx][col]
            if str(value).strip() in ('-','', '—'):return None
            percent=float(value)
            return percent*balance/100/1000
        except (TypeError,ValueError,IndexError):return None
    market_cc=amount(mk,cc); market_loans=amount(mk,loans)
    if market_cc is None or market_loans is None: raise ValueError('No hay total de banca múltiple comparable')
    banks={}
    for col,name in enumerate(headers):
        if col==mk:continue
        id=bank_id(name)
        if id is None:continue
        if id in banks:raise ValueError(f'Entidad duplicada: {id}')
        card=amount(col,cc);loan=amount(col,loans)
        if card is not None or loan is not None:
            banks[id]={'tarjetas':round(card,8) if card is not None else None,
                       'prestamos':round(loan,8) if loan is not None else None,
                       'cartera':round(card+loan,8) if card is not None and loan is not None else None}
    if 'falabella' not in banks:raise ValueError('Falta Banco Falabella')
    market={'tarjetas':round(market_cc,8),'prestamos':round(market_loans,8),'cartera':round(market_cc+market_loans,8)}
    # La suma de las entidades incluidas en B-2389 debe reproducir su TOTAL BANCA MÚLTIPLE.
    for k in ('tarjetas','prestamos','cartera'):
        if any(b[k] is None for b in banks.values()):continue
        discrepancy=sum(b[k] for b in banks.values())-market[k]
        if abs(discrepancy)>0.04:
            raise ValueError(f'No concilia {k}: {discrepancy:.5f} millones')
    return market,banks


def main():
    files=sorted(SOURCE.glob('B-2389-*.XLS'))
    if not files:raise FileNotFoundError('Faltan archivos SBS B-2389.')
    rows=[]
    for file in files:
        match=re.fullmatch(r'B-2389-([a-z]{2})(\d{4})',file.stem,re.I)
        if not match:raise ValueError(file.name)
        month=f'{match[2]}-{MONTHS[match[1].lower()]:02d}'
        
        try: market,banks=read_month(file)
        except Exception as error: raise ValueError(f"{file.name}: {error}") from error
        rows.append({'date':month,'mercado':market,'bancos':banks})
    rows.sort(key=lambda x:x['date'])
    if len({r['date'] for r in rows})!=len(rows):raise ValueError('Fechas duplicadas')
    # Se acepta el historial disponible, sin inventar datos faltantes.
    featured=['falabella','interbank','bcp','bbva','scotiabank','ripley','pichincha','banbif']
    bankIds=sorted({id for r in rows for id in r['bancos']},key=lambda x:(x not in featured,featured.index(x) if x in featured else 999,NAMES[x]))
    payload={
        'source':'SBS · Estructura de créditos directos por tipo y modalidad (B-2389)',
        'source_url':'https://www.sbs.gob.pe/estadisticas-y-publicaciones/estadisticas-/sistema-financiero_',
        'definition':'Cartera comparable = tarjetas de crédito de consumo + préstamos de consumo no revolventes. Saldos en S/ millones; porcentajes sobre créditos directos reportados por entidad.',
        'note':'Las comparaciones bancarias son exclusivamente históricas; la proyección de banca múltiple es agregada e independiente. Cambios de tipificación SBS pueden afectar la continuidad de algunas series.',
        'cutoff':rows[-1]['date'], 'first':rows[0]['date'],
        'banks':[{'id':id,'name':NAMES[id],'last':max((r['date'] for r in rows if id in r['bancos']), default=None)} for id in bankIds],
        'rows':rows
    }
    for bank in payload['banks']:
        bank['first']=min(r['date'] for r in rows if bank['id'] in r['bancos'])
        bank['historical_only']=bank['last']<payload['cutoff']
        internal=match_entity(bank['name'])
        if internal:
            metadata=entity_metadata(internal,bank['last'])
            bank.update(category=metadata['category'],category_history=metadata['category_history'],iaspe_id=internal)
        else:bank['category']='Bancos'
    payload['revision']=max(p.stat().st_mtime_ns for p in files)
    OUTPUT.write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    print(f'Panel: {len(rows)} meses, {len(bankIds)} bancos. {rows[0]["date"]}–{rows[-1]["date"]}; falabella {rows[-1]["bancos"]["falabella"]["cartera"]:.4f}; banca {rows[-1]["mercado"]["cartera"]:.4f}.')
    print(f'Guardado: {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)')

if __name__=='__main__':main()
