"""Inicio local de IASPE mediante Python, sin PowerShell."""
from pathlib import Path
import os
import runpy
import sys


def main():
    dashboard = Path(__file__).resolve().parent
    sistema = dashboard / "Sistema"
    servidor = sistema / "servidor.py"
    modelos = dashboard.parent / "IASPE" / "Modelos financieros"
    if not servidor.is_file() or not modelos.is_dir():
        raise SystemExit("Estructura incompleta. IASPE y Dashboard deben estar al mismo nivel.")
    os.chdir(sistema)
    sys.path.insert(0, str(sistema))
    args = sys.argv[1:]
    if not any(a == "--port" or a.startswith("--port=") for a in args):
        args = ["--port", "8954", *args]
    sys.argv = [str(servidor), *args]
    # Ejecutar el servidor original en primer plano, con sus controles intactos.
    runpy.run_path(str(servidor), run_name="__main__")


if __name__ == "__main__":
    main()
