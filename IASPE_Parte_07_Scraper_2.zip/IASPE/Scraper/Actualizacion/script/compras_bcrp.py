from __future__ import annotations
from datetime import date
import hashlib
import json
import math
from pathlib import Path
from urllib.request import Request, urlopen

SALIDA = Path(__file__).resolve().parents[1] / 'output' / 'compras_bcrp.json'
SERIE = 'PN09406SM'
MESES = {mes: i+1 for i,mes in enumerate(('Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'))}
REQUESTS = []


def ejecutar(solo_cache=False):
    if solo_cache:
        if not SALIDA.exists():
            raise FileNotFoundError('No existe una base observada local de compras BCRP')
        return json.loads(SALIDA.read_text(encoding='utf-8'))
    hoy=date.today()
    url=f'https://estadisticas.bcrp.gob.pe/estadisticas/series/api/{SERIE}/json/2026-8/{hoy.year}-{hoy.month}/esp'
    with urlopen(Request(url,headers={'User-Agent':'IASPE/1.0','Accept':'application/json'}),timeout=25) as respuesta:
        raw=respuesta.read(5_000_001)
        if len(raw)>5_000_000:raise ValueError('BCRP: respuesta excesiva')
        if not respuesta.geturl().startswith('https://estadisticas.bcrp.gob.pe/'):
            raise ValueError('BCRP: redirección fuera de la fuente oficial')
        datos=json.loads(raw.decode('utf-8'))
        REQUESTS.append({'report':SERIE,'url':url,'finalUrl':respuesta.geturl(),
            'httpStatus':respuesta.status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'status':'downloaded'})
        original=SALIDA.parent.parent/'fuentes'/'BCRP'/f'{SERIE}.json'
        original.parent.mkdir(parents=True,exist_ok=True)
        temporary=original.with_suffix('.tmp');temporary.write_bytes(raw);temporary.replace(original)
        REQUESTS[-1]['sourceFile']=str(original.relative_to(SALIDA.parents[3]))
    if not isinstance(datos.get('periods'),list):
        raise ValueError('BCRP: no se recibieron períodos de compras con tarjetas.')
    valores={}
    for punto in datos['periods']:
        nombre,anio=punto['name'].split('.')
        mes=MESES.get(nombre[:3])
        valor=punto.get('values',[None])[0]
        if mes is None or valor in (None,'','n.d.'):
            continue
        periodo=f'{int(anio):04d}-{mes:02d}'
        if not '2026-08'<=periodo<='2030-12':
            continue
        numero=float(valor.replace(',','') if isinstance(valor,str) else valor)
        if not math.isfinite(numero) or numero<=0:
            raise ValueError(f'BCRP: compras inválidas en {periodo}.')
        valores[periodo]=numero
    if not valores:
        raise ValueError('BCRP: compras con tarjetas no disponible aún.')
    previous=json.loads(SALIDA.read_text(encoding='utf-8')) if SALIDA.is_file() else {}
    output={'03':{**previous.get('03',{}),**valores}}
    SALIDA.parent.mkdir(parents=True,exist_ok=True)
    temporal=SALIDA.with_suffix('.tmp')
    temporal.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    temporal.replace(SALIDA)
    return output
