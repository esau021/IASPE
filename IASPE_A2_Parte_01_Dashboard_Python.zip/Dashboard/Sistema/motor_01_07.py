"""Adaptadores fieles a los modelos 01–07 de modelos financieros. Solo lectura de fuentes."""
from __future__ import annotations
from pathlib import Path
from functools import lru_cache
import math
import hashlib
import numpy as np
import pandas as pd
import statsmodels.api as sm
from openpyxl import load_workbook
from rutas import buscar_modelo

DEFAULT_ROOT = Path(__file__).resolve().parents[2] / 'IASPE' / 'Modelos financieros'
NAMES = {
 '01':'Número de tarjetas de crédito del mercado', '02':'Número de tarjetas de crédito de consumo del mercado',
 '03':'Compras con tarjetas de crédito del mercado', '04':'Número de tarjetas de crédito de Falabella',
 '05':'Colocaciones brutas - consumo revolvente', '06':'Colocaciones brutas - consumo no revolvente',
 '07':'Colocaciones brutas - consumo total',
}
UNITS = {k:('Tarjetas' if k in {'01','02','04'} else 'S/ millones') for k in NAMES}
MACRO_NAMES={'pbi':'Crecimiento real del PBI','inflacion':'Inflación anual','desempleo':'Desempleo anual','tpm':'Tasa de política monetaria al cierre','pbi_mensual':'PBI real mensual histórico, no utilizado por el Modelo 06 anual'}


def _folder(root, mid):
    return buscar_modelo(root, mid)


def _input(root, mid):
    return next(_folder(root,mid).rglob('Input/Base_modelo.xlsx'))


def _output(root,mid):
    return next(_folder(root,mid).rglob('Output/Pronostico.xlsx'))


def _rows(path,sheet):
    book=load_workbook(path,read_only=True,data_only=True)
    try:return list(book[sheet].values)[1:]
    finally:book.close()


def _annual(path,sheet='Anual'):
    return {int(r[0]):list(r) for r in _rows(path,sheet) if isinstance(r[0],(int,float)) and math.isfinite(r[0])}


def _month(value):
    if hasattr(value,'strftime'):return value.strftime('%Y-%m')
    if isinstance(value,(int,float)) and 15000<float(value)<90000:
        from datetime import datetime, timedelta
        return (datetime(1899,12,30)+timedelta(days=float(value))).strftime('%Y-%m')
    return str(value)[:7]


def _monthly(path,sheet):
    return {_month(r[0]):list(r) for r in _rows(path,sheet) if r[0] is not None}


def _valid(value):
    return isinstance(value,(int,float,np.number)) and math.isfinite(float(value))


def _updates(observations,key):
    return {str(k):float(v) for k,v in (observations or {}).get(key,{}).items() if _valid(v)}


def _apply(mapping,changes):
    result=dict(mapping)
    for k,v in changes.items():
        key=int(k[:4]) if mapping and isinstance(next(iter(mapping)),int) else k[:7]
        result[key]=v
    return result


def _macro(base,name,observations,scenarios=None):
    result=_apply(base,_updates(observations,name))
    if scenarios:result=_apply(result,_updates(scenarios,name))
    return result


def _point(period,value,status,frequency='annual'):
    value=float(value)
    result={'value':value,'status':status,'observed':None,'assumed':None,'forecast':None}
    result[status]=value
    if frequency=='annual':result.update(year=int(period),date=f'{int(period)}-12-01')
    else:result.update(date=str(period)+'-01',year=int(str(period)[:4]))
    return result


def _stats(model,names,hac=1):
    robust=model.get_robustcov_results(cov_type='HAC',maxlags=hac,use_t=True)
    ci=np.asarray(robust.conf_int())
    coefficients=[]
    for i,name in enumerate(names):
        p=float(robust.pvalues[i])
        coefficients.append({'name':name,'value':float(robust.params[i]),'se':float(robust.bse[i]),
          'pValue':p,'t':float(robust.tvalues[i]),'ciLow':float(ci[i,0]),'ciHigh':float(ci[i,1]),
          'significance':'***' if p<.01 else '**' if p<.05 else '*' if p<.1 else '',
          'interpretation':'Variación en puntos del crecimiento logarítmico ante una unidad de la regresora, manteniendo las demás constantes. No identifica causalidad.' if i else 'Intercepto del crecimiento logarítmico estimado; no es una tasa de equilibrio.'})
    statistics={'nobs':int(model.nobs),'r2':float(model.rsquared),'adjustedR2':float(model.rsquared_adj),
      'aic':float(model.aic),'bic':float(model.bic),'covariance':f'HAC / Newey–West, {hac} rezago'+('s' if hac!=1 else ''),
      'fStatistic':float(model.fvalue),'fPValue':float(model.f_pvalue),
      '_sampleSignature':hashlib.sha256(np.asarray(model.model.endog,dtype=float).tobytes()+np.asarray(model.model.exog,dtype=float).tobytes()).hexdigest()}
    return coefficients,statistics


def _fit(years,levels,regressors,names,hac=1):
    y=np.array([100*np.log(levels[y]/levels[y-1]) for y in years],dtype=float)
    X=np.array([regressors(y) for y in years],dtype=float)
    model=sm.OLS(y,X).fit()
    coefficients,statistics=_stats(model,names,hac)
    statistics['period']=f'{years[0]}–{years[-1]}'
    return model,coefficients,statistics


def _status(year,updates):
    if str(year) in updates or f'{year}-12' in updates or f'{year}-12-01' in updates:return 'observed'
    return 'observed' if year<=2025 else 'assumed' if year==2026 else 'forecast'


def _last_contiguous_year(observed_years, start=2026):
    """La reestimación no incorpora años pronosticados como observaciones."""
    last=start
    while last+1 in observed_years and last<2030:
        last+=1
    return last


def _monthly_state(day,original,updates):
    if day in updates or day+'-01' in updates or (day.endswith('-12') and day[:4] in updates):return 'observed'
    if int(day[:4])>=2027:return 'forecast'
    if 'imput' in str(original).lower() or 'supuesto' in str(original).lower():return 'assumed'
    return 'observed'


def _metadata(root,mid,annual,coefficients=None,statistics=None,monthly=None):
    folder=_folder(root,mid)
    saved={y:float(r[1] if mid!='07' else r[3]) for y,r in _annual(_output(root,mid)).items() if _valid(r[1])}
    by_year={p['year']:p['value'] for p in annual}
    error=max((abs(by_year[y]-v) for y,v in saved.items() if y in by_year),default=0.)
    return {'id':mid,'name':NAMES[mid],'unit':UNITS[mid],'frequency':'annual',
      'kind':'consolidation' if mid=='07' else 'econometric','method':'Suma de cierres de diciembre' if mid=='07' else ('MCO anual 2016–2026: variación de saldo, aceleración PBI t−1, dummy SBS 2021 y compras t−1; HAC(1)' if mid=='06' else 'MCO con constante e inferencia HAC'),
      'annual':annual,'monthly':monthly or [],'series':annual,'coefficients':coefficients or [],'statistics':statistics or {},
      'sourceFiles':[str(p.resolve()) for p in folder.rglob('*') if p.suffix.lower() in {'.xlsx','.ipynb'}],
      'status':'ready','issues':[],'warnings':[],'baselineMaxError':error,
      'definition':NAMES[mid]+'. '+('Stock al cierre de diciembre.' if mid!='03' else 'Flujo acumulado del año, en moneda nacional.'),
      'reestimated':False,'editableObservations':mid!='07','observationEnd':'2030-12'}


def _estimated_equation(mid, coefficients):
    terms = {
        '01': [None, r'PBI_t'], '02': [None, r'PBI_t'],
        '03': [None, r'PBI_t', r'\pi_t', r'D_{COVID,t}'],
        '04': [None, r'PBI_t', r'PBI_{t-1}', r'\pi_{t-1}'],
        '05': [None, r'g^{C}_t', r'D_{SBS,2021,t}'],
        '06': [None, r'(PBI_{t-1}-PBI_{t-2})', r'D_{SBS,2021,t}', r'Compras_{t-1}'],
    }
    response = {'03': r'\widehat{g}^{C}_t', '04': r'\widehat{g}^{N}_t', '05': r'\widehat{g}^{S}_t', '06':r'\widehat{\Delta S}_t'}.get(mid, r'\widehat{g}_t')
    pieces = []
    for i, (coefficient, term) in enumerate(zip(coefficients, terms[mid])):
        value = float(coefficient['value'])
        magnitude = f'{abs(value):.8g}'
        if 'e' in magnitude:
            mantissa, exponent = magnitude.split('e')
            magnitude = mantissa + r'\times 10^{' + str(int(exponent)) + '}'
        sign = '-' if value < 0 else ('+' if i else '')
        pieces.append(sign + magnitude + (r'\,' + term if term else ''))
    return response + '=' + ''.join(pieces)


def _dependency(mid,variable,unit,lag=0,transformation='',frequency='annual'):
    return {'id':mid,'source':mid,'variable':variable,'unit':unit,'lag':lag,'transformation':transformation,'frequency':frequency}


def _input_var(mid,lag=0,transform=''):
    return {'id':mid,'name':MACRO_NAMES.get(mid,mid),'unit':'Índice 2007=100' if mid=='pbi_mensual' else '%','lag':lag,'transformation':transform}


def get_macros(source_root=DEFAULT_ROOT):
    root=Path(source_root)
    one=_annual(_input(root,'01'),'Macros_anuales');three=_annual(_input(root,'03'));four=_annual(_input(root,'04'))
    values={'pbi':{y:float(r[1]) for y,r in one.items() if _valid(r[1])},
      'desempleo':{y:float(r[3]) for y,r in three.items() if _valid(r[3])},
      'tpm':{y:float(r[4]) for y,r in three.items() if _valid(r[4])},
      'inflacion':{y:float(r[3]) for y,r in four.items() if _valid(r[3])}}
    result=[{'id':k,'name':MACRO_NAMES[k],'unit':'%','frequency':'annual','values':{str(y):v for y,v in val.items()}} for k,val in values.items()]
    # Modelo 06 ahora usa PBI ANUAL. El índice mensual histórico no es un supuesto editable.
    return result


def recalculate(context,scenarios=None,observations=None):
    root=Path(context.get('source_root',DEFAULT_ROOT) if isinstance(context,dict) else context or DEFAULT_ROOT)
    scenarios=scenarios or {}; observations=observations or {}; result={}
    # El horizonte documentado llega a 2030. No aceptar años posteriores
    # sin que existan proyecciones macro y modelos dependientes para esos años.
    for mid in NAMES:
        for period,value in _updates(observations,mid).items():
            if not 1990 <= int(period[:4]) <= 2030:
                raise ValueError('El horizonte actual termina en 2030. Para años posteriores deben ampliarse los supuestos macroeconómicos y la cadena de modelos.')
            if value<=0:
                raise ValueError(f'{NAMES[mid]} requiere un nivel observado positivo.')
    macros={m['id']:{int(k) if m['frequency']=='annual' else k:v for k,v in m['values'].items()} for m in get_macros(root)}
    fitting={k:_macro(v,k,observations) for k,v in macros.items()}
    future={k:_macro(v,k,observations,scenarios) for k,v in macros.items()}
    pbi_fit,pbi_future=fitting['pbi'],future['pbi']
    for mid in ['01','02']:
        path=_input(root,mid)
        data=_annual(path,'Macros_anuales' if mid=='01' else 'Tarjetas_anuales')
        levels={y:float(r[3] if mid=='01' else r[1]) for y,r in data.items() if _valid(r[3] if mid=='01' else r[1])}
        changes=_updates(observations,mid)
        monthly={}
        if mid=='01':
            monthly={d:(float(r[1]),'observed') for d,r in _monthly(path,'Tarjetas_mensual').items() if _valid(r[1])}
        for period,val in changes.items():
            if val<=0:raise ValueError(f'{NAMES[mid]} requiere un stock positivo.')
            if len(period)>=7:monthly[period[:7]]=(val,'observed')
            if len(period)==4 or period[5:7]=='12':levels[int(period[:4])]=val
        # M01: un saldo de agosto no es el cierre de diciembre. Proyectar el
        # cierre 2026 con el crecimiento interanual LOGARÍTMICO medio de
        # los meses SBS disponibles; diciembre observado reemplaza la fórmula.
        if mid=='01' and '2026' not in changes and '2026-12' not in changes:
            if '2026-12' in monthly:
                levels[2026]=monthly['2026-12'][0]
            else:
                matched=[(monthly[f'2026-{m:02d}'][0],monthly[f'2025-{m:02d}'][0])
                         for m in range(1,13)
                         if f'2026-{m:02d}' in monthly and f'2025-{m:02d}' in monthly]
                if len(matched)>=7:
                    dec2025=monthly.get('2025-12')
                    if dec2025 is None or dec2025[0]<=0 or any(x<=0 or y<=0 for x,y in matched):
                        raise ValueError('M01: faltan saldos positivos para el cierre 2026.')
                    factor=float(np.exp(np.mean([np.log(x/y) for x,y in matched])))
                    levels[2026]=float(math.floor(dec2025[0]*factor+.5))
        elif mid=='02':
            # M02 no tiene aquí una trayectoria mensual desagregada propia.
            # Mantener su cierre explícito hasta que exista una observación.
            current=[(d,v[0]) for d,v in monthly.items() if d.startswith('2026-')]
            if current and '2026' not in changes and '2026-12' not in changes and any(k.startswith('2026-') for k in changes):
                levels[2026]=max(current)[1]
        full_years={int(k[:4]) for k in changes if len(k)==4 or k.endswith('-12')}
        assumed_years=set()
        for year in sorted({int(k[:4]) for k in changes if len(k)==7 and int(k[:4])>=2027}):
            if year in full_years:
                continue
            known=[(k,v) for k,v in changes.items() if k.startswith(str(year)+'-') and len(k)==7]
            if known:
                # Igual que en 2026: el último stock publicado ancla el
                # cierre provisional, pero NO es un diciembre observado.
                levels[year]=max(known)[1]
                assumed_years.add(year)
        start=2010 if mid=='01' else 2011
        train_end=_last_contiguous_year(full_years)
        model,coef,stats=_fit(list(range(start,train_end+1)),levels,lambda y:[1,pbi_fit[y]],['Constante','PBI real anual (%)'])
        for year in range(train_end+1,2031):
            if year not in full_years and year not in assumed_years:
                levels[year]=levels[year-1]*np.exp(float(np.dot(model.params,[1,pbi_future[year]]))/100)
        annual=[_point(y,v,'assumed' if y in assumed_years else _status(y,changes)) for y,v in sorted(levels.items())]
        item=_metadata(root,mid,annual,coef,stats,[_point(d,v,s,'monthly') for d,(v,s) in sorted(monthly.items())] if mid=='01' else [])
        item.update(equationTex=r'g_t=\alpha+\beta\,PBI_t+\varepsilon_t,\quad g_t=100\ln(N_t/N_{t-1})',
          dependencies=[],inputs=[_input_var('pbi')],closingRule=('Diciembre 2025 por la media geométrica de variaciones interanuales observadas de 2026; diciembre observado sustituye la estimación.' if mid=='01' else 'El cierre provisional usa la información anual disponible.'),
          updateRule='Cada mes SBS nuevo recalcula el cierre 2026; diciembre o cierre oficial lo reemplaza. Los cierres confirmados amplían la muestra MCO.',
          limitations=['La muestra de estimación incluye el cierre supuesto de 2026.'],reestimated=bool(changes or _updates(observations,'pbi')))
        result[mid]=item
    # 03. El cierre provisional exige al menos siete meses observados.
    mid='03';path=_input(root,mid);data=_annual(path);monthly=_monthly(path,'Compras_mensuales');changes=_updates(observations,mid)
    mlevels={d:float(r[1]) for d,r in monthly.items() if _valid(r[1])}
    original_states={d:str(r[2]).lower() for d,r in monthly.items()}
    for period,val in changes.items():
        if len(period)>=7:
            mlevels[period[:7]]=val
    levels={y:float(r[1]) for y,r in data.items() if _valid(r[1])}
    full_years={int(k) for k in changes if len(k)==4}
    assumed_years=set()
    monthly_estimates=set()
    for year in range(2026,2031):
        observed={m: mlevels[f'{year}-{m:02d}'] for m in range(1,13)
                  if (f'{year}-{m:02d}' in changes or
                      ('observ' in original_states.get(f'{year}-{m:02d}','')))
                  and _valid(mlevels.get(f'{year}-{m:02d}'))}
        if year in full_years:
            continue
        if len(observed)==12:
            levels[year]=sum(observed.values())
            full_years.add(year)
            continue
        if len(observed)<7 or not all(m in observed for m in range(1,8)):
            continue
        if year==2026:
            for m in range(1,13):
                if m in observed:
                    continue
                ratios=[mlevels[f'{y}-{m:02d}']/mlevels[f'{y-1}-{m:02d}']-1
                        for y in (2023,2024,2025)]
                mlevels[f'{year}-{m:02d}']=mlevels[f'2025-{m:02d}']*(1+float(np.mean(ratios)))
                monthly_estimates.add(f'{year}-{m:02d}')
        else:
            # Los meses comparables del año anterior deben ser observados.
            prior={m for m in range(1,13) if
                   f'{year-1}-{m:02d}' in changes or
                   'observ' in original_states.get(f'{year-1}-{m:02d}','')}
            if len(prior)!=12:
                continue
            ratios=[observed[m]/mlevels[f'{year-1}-{m:02d}']-1 for m in observed]
            ratio=float(np.mean(ratios))
            if 1+ratio<=0:
                continue
            for m in range(1,13):
                if m not in observed:
                    day=f'{year}-{m:02d}'
                    mlevels[day]=mlevels[f'{year-1}-{m:02d}']*(1+ratio)
                    monthly_estimates.add(day)
        if all(_valid(mlevels.get(f'{year}-{m:02d}')) for m in range(1,13)):
            levels[year]=sum(mlevels[f'{year}-{m:02d}'] for m in range(1,13))
            assumed_years.add(year)
    levels=_apply(levels,{k:v for k,v in changes.items() if len(k)==4})
    reg=lambda y,mat:[1,mat['pbi'][y],mat['inflacion'][y],float(y in (2020,2021))]
    train_end=_last_contiguous_year(full_years,start=2025)
    model,coef,stats=_fit(list(range(2014,train_end+1)),levels,lambda y:reg(y,fitting),['Constante','PBI real anual (%)','Inflación anual (%)','Dicotómica COVID 2020–2021'])
    stats['includesAssumed2026']=False
    stats['methodologyVersion']='IASPE-A2-M03'
    stats['regressorsByYear']={str(y):reg(y,fitting if y<=train_end else future) for y in range(2014,2031)}
    for y in range(max(2026,train_end)+1,2031):
        if y not in full_years and y not in assumed_years:
            levels[y]=levels[y-1]*np.exp(float(np.dot(model.params,reg(y,future)))/100)
    purchases_fit=levels.copy()
    item=_metadata(root,mid,[_point(y,v,'observed' if y in full_years else 'assumed' if y in assumed_years else _status(y,{})) for y,v in sorted(levels.items())],coef,stats,
      [_point(d,v,'assumed' if d in monthly_estimates else _monthly_state(d,monthly.get(d,[None,None,'Pronóstico'])[2],changes),'monthly') for d,v in sorted(mlevels.items())])
    item.update(equationTex=r'g_t^C=\alpha+\beta_1PBI_t+\beta_2\pi_t+\gamma D_{COVID,t}+\varepsilon_t,\quad g_t^C=100\ln(C_t/C_{t-1})',dependencies=[],
      inputs=[_input_var('pbi'),_input_var('inflacion')],
      closingRule='Con siete meses observados consecutivos se estima el cierre anual. Cada mes nuevo reemplaza su imputación; diciembre completa el año observado.',
      updateRule='MCO 2014–2025, ampliable solo con años completos observados. Cierre supuesto 2026 ancla el pronóstico desde 2027; COVID vale 1 en 2020–2021 y 0 fuera de esos años.',
      method='MCO anual: PBI, inflación y COVID; HAC(1)',
      limitations=['Cierre supuesto 2026 excluido de la estimación M03.','Muestra reducida; la inferencia del PBI y COVID es sensible a HC3.','Las proyecciones desde 2027 son anuales; no se reparte el flujo entre meses.'],reestimated=bool(changes or any(_updates(observations,k) for k in ['pbi','inflacion'])))
    result[mid]=item
    # 04 y 05: stocks anuales con cierres mensuales de 2026.
    for mid in ['04','05']:
        path=_input(root,mid);data=_annual(path);rawmonthly=_monthly(path,'Mensual');changes=_updates(observations,mid)
        monthly_levels={d:float(r[1]) for d,r in rawmonthly.items() if _valid(r[1])}
        monthly_levels=_apply(monthly_levels,{k:v for k,v in changes.items() if len(k)>=7})
        # Se conserva la media histórica ene–ago del cierre original; al
        # incorporar nuevos meses reales SBS, la ventana se amplía solo con
        # observaciones verificadas (sin tratar imputaciones como reales).
        observed_months = [m for m in range(1,13) if (m <= 8 or f'2026-{m:02d}' in changes or
            f'2026-{m:02d}-01' in changes or
            'observ' in str((rawmonthly if mid in ('04','05') else raw).get(f'2026-{m:02d}', [None,None,None,''])[3 if mid in ('04','05') else 8]).lower())]
        ratio=np.mean([monthly_levels[f'2026-{m:02d}']/monthly_levels[f'2025-{m:02d}']-1 for m in observed_months])
        for m in range(9,13):
            d=f'2026-{m:02d}'
            if d not in changes and d+'-01' not in changes and not 'observ' in str(rawmonthly.get(d, [None,None,None,''])[3]).lower():
                v=monthly_levels[f'2025-{m:02d}']*(1+ratio)
                monthly_levels[d]=float(math.floor(v+.5)) if mid=='04' else float(v)
        levels={y:float(r[1]) for y,r in data.items() if _valid(r[1])}
        levels[2026]=monthly_levels['2026-12']
        for d,v in changes.items():
            if len(d)==4 or d[5:7]=='12':levels[int(d[:4])]=v
        def regressors(y,mat,comp):
            if mid=='04':return [1,mat['pbi'][y],mat['pbi'][y-1],mat['inflacion'][y-1]]
            return [1,100*np.log(comp[y]/comp[y-1]),float(y==2021)]
        # El ajuste de saldo lee las compras históricas guardadas, como el notebook original.
        saved_comp={y:float(r[1]) for y,r in _annual(_output(root,'03')).items()}
        fit_comp=purchases_fit if mid=='05' or _updates(observations,'03') else saved_comp
        names=['Constante','PBI real anual (%)','PBI real t−1 (%)','Inflación t−1 (%)'] if mid=='04' else ['Constante','Crecimiento log de compras t (%)','Dicotómica reclasificación SBS 2021']
        full_years={int(k[:4]) for k in changes if len(k)==4 or k.endswith('-12')}
        assumed_years=set()
        for year in sorted({int(k[:4]) for k in changes if len(k)==7 and int(k[:4])>=2027}):
            if year in full_years:
                continue
            actual={int(k[5:7]):v for k,v in changes.items() if len(k)==7 and k.startswith(str(year)+'-')}
            ratios=[actual[m]/monthly_levels[f'{year-1}-{m:02d}']-1 for m in actual
                    if _valid(monthly_levels.get(f'{year-1}-{m:02d}')) and monthly_levels[f'{year-1}-{m:02d}']>0]
            prior_close=monthly_levels.get(f'{year-1}-12')
            if len(ratios)!=len(actual) or not ratios or not _valid(prior_close):
                continue
            provisional=prior_close*(1+float(np.mean(ratios)))
            if provisional<=0:continue
            levels[year]=float(math.floor(provisional+.5)) if mid=='04' else float(provisional)
            assumed_years.add(year)
        train_end=_last_contiguous_year(full_years)
        model,coef,stats=_fit(list(range(2011 if mid=='04' else 2017,train_end+1)),levels,lambda y:regressors(y,fitting,fit_comp),names)
        for y in range(train_end+1,2031):
            if y not in full_years and y not in assumed_years:
                levels[y]=levels[y-1]*np.exp(float(np.dot(model.params,regressors(y,future,purchases_fit)))/100)
        item=_metadata(root,mid,[_point(y,v,'assumed' if y in assumed_years else _status(y,changes)) for y,v in sorted(levels.items())],coef,stats,
          [_point(d,v,_monthly_state(d,rawmonthly.get(d,[None,None,None,'Observado'])[3],changes),'monthly') for d,v in sorted(monthly_levels.items())])
        item.update(equationTex=(r'g_t^N=\alpha+\beta_1PBI_t+\beta_2PBI_{t-1}+\beta_3\pi_{t-1}+\varepsilon_t,\quad g_t^N=100\ln(N_t/N_{t-1})' if mid=='04' else r'g_t^S=\alpha+\beta_1g_t^C+\gamma D_{SBS,2021,t}+\varepsilon_t,\quad g_t^S=100\ln(S_t/S_{t-1})'),
          dependencies=[] if mid=='04' else [_dependency('03','Crecimiento log anual de compras','%',0,'100 ln(Cₜ/Cₜ₋₁)')],
          inputs=[_input_var('pbi'),_input_var('pbi',1),_input_var('inflacion',1)] if mid=='04' else [],
          closingRule='Septiembre–diciembre de 2026: saldo del mismo mes de 2025 por 1 más la media IA de enero–agosto de 2026.'+(' Las tarjetas se redondean al entero.' if mid=='04' else ''),
          updateRule='Cada nuevo mes mueve el cierre provisional mediante la media interanual de meses publicados. Diciembre reemplaza la estimación por el cierre observado y permite reestimar MCO.',
          limitations=['La proyección MCO es anual; no se fabrica un perfil mensual desde 2027.']+(['La ruta de participación fija del libro Participacion_Falabella es distinta de esta regresión propia.'] if mid=='04' else []),
          reestimated=bool(changes or any(_updates(observations,k) for k in (['pbi','inflacion'] if mid=='04' else ['03']))))
        if mid=='05':
            item.update(method='MCO anual: crecimiento contemporáneo de M03 y dicotómica SBS 2021; HAC(1)', updateRule='Reestimar con cierre vigente (2017–2026) y compras M03 contemporáneas. Dicotómica 2021 solo en ese año.', limitations=item['limitations']+['El cierre 2026 supuesto participa en la estimación M05; validar estabilidad al excluirlo.'])
            stats['methodologyVersion']='IASPE-A2-M05'
            stats['regressorsByYear']={str(y):regressors(y,fitting,fit_comp if y<=train_end else purchases_fit) for y in range(2017,2031)}
        result[mid]=item
    # 06. Reestimación estrictamente ANUAL: saldos a diciembre y PBI real anual.
    # No convertir tasas anuales del PBI en niveles mensuales, no interpolar,
    # y no proyectar meses: el horizonte de IASPE es 2026–2030 anual.
    mid='06';changes=_updates(observations,mid)
    records=_annual(_input(root,mid),'Anual')
    levels={y:float(r[1]) for y,r in records.items() if _valid(r[1])}
    # Cierre supuesto original de 2026: conserva la cifra aprobada del Input.
    # Si llegan observaciones SBS mensuales más recientes, actualizar únicamente
    # la estimación de DICIEMBRE por tasa interanual observada, sin fabricar meses.
    monthly_source=_monthly(_input(root,mid),'Mensual')
    for key,val in changes.items():
        if len(key)==4 or (len(key)>=7 and key[5:7]=='12'):
            levels[int(key[:4])]=val
    latest_2026={int(d[5:7]):float(r[1]) for d,r in monthly_source.items()
                 if d.startswith('2026-') and _valid(r[1]) and
                 (int(d[5:7])<=8 or 'observ' in str(r[8] if len(r)>8 else '').lower())}
    for period,value in changes.items():
        if len(period)>=7 and period.startswith('2026-'):
            latest_2026[int(period[5:7])]=value
    has_annual_2026=('2026' in changes or '2026-12' in changes or '2026-12-01' in changes)
    if not has_annual_2026 and any(len(k)>=7 and k.startswith('2026-') for k in changes):
        yoy=[latest_2026[m]/float(monthly_source[f'2025-{m:02d}'][1])-1
             for m in sorted(latest_2026) if _valid(monthly_source.get(f'2025-{m:02d}',[None,None])[1])]
        if yoy:levels[2026]=float(monthly_source['2025-12'][1])*(1+float(np.mean(yoy)))
    # Solo incorporar cierres anuales o diciembres efectivamente observados en el MCO.
    full_years={int(k[:4]) for k in changes if len(k)==4 or (len(k)>=7 and k[5:7]=='12')}
    train_end=_last_contiguous_year(full_years)
    # Diciembre de 2015 proviene del histórico SBS ya incluido en IASPE.
    # No extrapolar ni introducir datos artificiales de ese ejercicio.
    historical=root.parent/'Scraper'/'Cartera_consumo_mercado'/'output'/'Cartera_consumo_banca_multiple.xlsx'
    if not historical.is_file():
        raise FileNotFoundError(f'Modelo 06: falta el cierre histórico SBS 2015: {historical}')
    from datetime import datetime, date
    historic_book=load_workbook(historical,read_only=True,data_only=True)
    historical_2015=None
    try:
        for row in historic_book['Mensual'].values:
            when=row[0]
            if isinstance(when,(datetime,date)) and when.year==2015 and when.month==12:
                historical_2015=float(row[5]);break
    finally:historic_book.close()
    if historical_2015 is None or historical_2015<=0:
        raise ValueError('Modelo 06: no se recuperó el saldo SBS de diciembre 2015.')
    levels[2015]=historical_2015
    sample=list(range(2016,train_end+1))
    if len(sample)<10:
        raise ValueError('Modelo 06: insuficientes cierres anuales para evaluar el quiebre SBS de 2021.')
    # La variable de compras pertenece al Modelo 03. Para estimación, se usa
    # la historia de su propio Output; para escenarios, los nuevos pronósticos.
    compras_historicas={y:float(r[1]) for y,r in _annual(_output(root,'03')).items() if y<=2026 and _valid(r[1])}
    compras_historicas.update({int(y):v for y,v in _updates(observations,'03').items()
                              if len(y)==4 and int(y)<=2026})
    # Si entraron compras mensuales BCRP de 2026, M03 acaba de recomponer
    # su cierre anual. M06 debe utilizar ESE cierre para su compra rezagada,
    # no el viejo valor físico de Output/M03 cargado antes del recálculo.
    if any(str(period).startswith('2026-') for period in _updates(observations,'03')):
        compras_historicas[2026]=float(next(r['value'] for r in result['03']['annual'] if r['year']==2026))
    compras_futuras={r['year']:float(r['value']) for r in result['03']['annual']}
    compras_futuras.update(compras_historicas if not scenarios else {y:v for y,v in compras_historicas.items() if y<=2025})
    reg=lambda y,pbi,compras:[1., pbi[y-1]-pbi[y-2], float(y==2021), compras[y-1]]
    yvals=np.array([levels[y]-levels[y-1] for y in sample],dtype=float)
    X=np.array([reg(y,pbi_fit,compras_historicas) for y in sample],dtype=float)
    model=sm.OLS(yvals,X).fit()
    coef,stats=_stats(model,['Constante','Aceleración PBI real t−1 (pp)',
                            'Dicotómica reclasificación SBS 2021','Compras mercado t−1 (S/ MM)'],hac=1)
    stats['period']=f'{sample[0]}–{sample[-1]}'
    for term in coef:
        term['interpretation']='Variación del saldo anual de préstamos (S/ millones) por unidad de la regresora, manteniendo las demás constantes. Asociación condicional, no efecto causal.'
    for year in range(train_end+1,2031):
        if year not in full_years:
            delta=float(np.dot(model.params,reg(year,pbi_future,compras_futuras)))
            levels[year]=levels[year-1]+delta
            if levels[year]<=0:raise ValueError(f'Modelo 06: pronóstico anual no positivo en {year}.')
    annual=[_point(y,levels[y],_status(y,changes)) for y in sorted(levels)]
    item=_metadata(root,mid,annual,coef,stats,monthly=[])
    item.update(equationTex=r'\Delta S_t=\alpha+\beta_1(PBI_{t-1}-PBI_{t-2})+\gamma D_{SBS,2021,t}+\beta_2 Compras_{t-1}+\varepsilon_t,\quad S_t=S_{t-1}+\widehat{\Delta S}_t',
      dependencies=[_dependency('03','Compras con tarjetas del mercado','S/ millones',1)],
      inputs=[_input_var('pbi',1,'Aceleración anual: PBI t−1 menos PBI t−2'),
              {'id':'sbs_2021','name':'Reclasificación contable SBS 2021','unit':'0/1','lag':0},
              {'id':'03','name':'Compras mercado t−1','unit':'S/ millones','lag':1}],
      closingRule='Saldo anual de diciembre. En 2026 se conserva el cierre supuesto original, actualizado solo ante nuevos meses SBS observados mediante su crecimiento interanual promedio; sin distribuir pronósticos por mes.',
      updateRule='Reestimar MCO de variación anual 2016–2026 (y nuevos diciembres SBS); proyectar año a año con PBI anual, compras anuales M03 y dicotómica de 2021 únicamente en el año de reclasificación.',
      limitations=['La cifra diciembre 2015 se lee del histórico SBS de cartera de consumo ya existente en el paquete.',
                   'El cierre 2026 es supuesto y participa en la regresión; verificar estabilidad al excluirlo.',
                   'La dicotómica 2021 recoge una discontinuidad contable; no identifica por sí misma causalidad.',
                   'No se genera ni se distribuye una trayectoria mensual para 2027–2030.'],
      reestimated=bool(changes or _updates(observations,'pbi') or _updates(observations,'03')),
      monthly=[],frequency='annual',status='ready',scenarioSupport=True)
    stats['includesAssumed2026']=2026 not in full_years
    stats['methodologyVersion']='anual-pbi-compras-sbs-20261109-v2'
    result[mid]=item
    # 07. Identidad de stocks al mismo cierre de diciembre; no implica totales mensuales.
    card={p['year']:p for p in result['05']['annual']};loan={p['year']:p for p in result['06']['annual']}
    annual=[_point(y,card[y]['value']+loan[y]['value'],
                   'observed' if card[y]['status']=='observed' and loan[y]['status']=='observed'
                   else 'assumed' if 'assumed' in (card[y]['status'],loan[y]['status']) else 'forecast')
            for y in sorted(card.keys()&loan.keys())]
    item=_metadata(root,'07',annual)
    item.update(equationTex=r'S_t^{consumo}=S_t^{tarjetas}+S_t^{no\ revolventes}',
      dependencies=[_dependency('05','Colocaciones brutas - consumo revolvente','S/ millones'),_dependency('06','Colocaciones brutas - consumo no revolvente','S/ millones')],inputs=[],
      closingRule='Suma de los cierres anuales de los Modelos 05 y 06. No se suman meses ni se inventa la senda mensual del Modelo 05.',
      updateRule='Recalcular la suma cuando cambie cualquiera de sus dos componentes.',limitations=['Consolidado de las dos modalidades seleccionadas; no equivale a todas las colocaciones brutas del banco.'],
      reestimated=False)
    if result['06']['status']!='ready':item['status']='needs_input';item['issues']=['El Modelo 06 anual presenta datos o estimación pendientes.'];item['warnings']=item['issues'][:]
    item['canUpdate']=False
    result['07']=item
    for mid,model in result.items():
        model['estimatedEquationTex']=_estimated_equation(mid,model['coefficients']) if model['coefficients'] and mid in ('01','02','03','04','05','06') else model['equationTex']
    if observations:
        baseline_signatures=_baseline_signatures(str(root))
        for model in result.values():
            signature=model.get('statistics',{}).get('_sampleSignature')
            if signature:model['reestimated']=signature!=baseline_signatures.get(model['id'])
    if scenarios or observations:
        for model in result.values():model['baselineMaxError']=None
    return result


@lru_cache(maxsize=4)
def _baseline_signatures(root):
    return {mid:model.get('statistics',{}).get('_sampleSignature') for mid,model in recalculate({'source_root':root}).items()}

def build_registry(source_root=DEFAULT_ROOT):
    return list(recalculate({'source_root':source_root}).values())
