'use strict';
/* Regresión de la jerarquía visual del menú: no modifica el motor de proyección. */
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'..');
const workspace=fs.readFileSync(path.join(root,'workspace.js'),'utf8');
const begin=workspace.indexOf('const IASPE_EXTRA_FICHAS='),end=workspace.indexOf('function shell(){');
assert(begin>=0&&end>begin,'Código de navegación no encontrado.');
const allIDs=[
  '01','02','03','04','13','14','15','30',
  '49','49_rev','49_nrev','49_tc','49_rc','49_pe','49_compras','49_desembolsos','49_disposiciones_rc','49_part_rc','49_tasa_rev','49_tasa_nrev'
];
const modelMap=new Map(allIDs.map(id=>[id,{id,name:`Nombre original de ${id}`} ]));
const injected=new Function('model','escape','S','window',workspace.slice(begin,end)+`\nreturn {thematicNavigation,OPERATIVE_NAV_SECTIONS,COMPLEMENTARY_NAV_SECTIONS};`);
const {thematicNavigation,OPERATIVE_NAV_SECTIONS,COMPLEMENTARY_NAV_SECTIONS}=injected(
  id=>modelMap.get(id)||null,
  s=>String(s).replace(/&/g,'&amp;'),
  {data:{models:[...modelMap.values()]}},
  {IASPEPanels:{}}
);
function validateSections(sections,expectedIDs,expectedNames){
  assert.strictEqual(sections.length,3);
  assert.deepStrictEqual(sections.map(s=>s.name),expectedNames);
  const html=thematicNavigation(sections);
  assert.strictEqual((html.match(/<details class="nav-pnl-stage nav-theme-stage">/g)||[]).length,3);
  const ids=[...html.matchAll(/href="#modelo\/([^\"]+)"/g)].map(match=>match[1]);
  assert.deepStrictEqual(ids,expectedIDs,'La agrupación alteró enlaces o el orden original.');
  assert.strictEqual(new Set(ids).size,expectedIDs.length,'Hay enlaces duplicados.');
  assert.strictEqual((html.match(/<\/details>/g)||[]).length,3);
  return html;
}
const operatives=['01','02','03','04','13','14','15','30'];
const complements=['49','49_rev','49_nrev','49_tc','49_rc','49_pe','49_compras','49_desembolsos','49_disposiciones_rc','49_part_rc','49_tasa_rev','49_tasa_nrev','transmision'];
const op=validateSections(OPERATIVE_NAV_SECTIONS,operatives,['Tarjetas y actividad de mercado','Tasas de interés del mercado','Líneas de crédito Falabella']);
const comp=validateSections(COMPLEMENTARY_NAV_SECTIONS,complements,['Amortizaciones por producto','Compras y desembolsos','Tasas y transmisión monetaria']);
assert(op.includes('<small>4</small>')&&op.includes('<small>3</small>')&&op.includes('<small>1</small>'));
assert(comp.includes('<small>6</small>')&&comp.includes('<small>3</small>')&&comp.includes('<small>4</small>'));
assert(comp.includes('href="#modelo/transmision"'));
assert(workspace.includes('if(group.id===\'operativas\')return thematicNavigation(OPERATIVE_NAV_SECTIONS)'));
assert(workspace.includes('if(group.id===\'complementarios\')return thematicNavigation(COMPLEMENTARY_NAV_SECTIONS)'));
console.log('OK: 3+3 subgrupos y 8+13 enlaces completos, sin renombrar, duplicar ni modificar rutas.');
