"""Conciliación cruzada de Excel fuente del escenario base (solo lectura).

Evita el error histórico de presentar un Output recalibrado mientras
Input y Consolidado siguen con importes antiguos. No reestima ni modifica
ningún modelo aprobado.
"""
from pathlib import Path
from openpyxl import load_workbook
from rutas import buscar_modelo

YEARS = range(2026, 2031)
TOL = 0.0001  # S/ millones


def verificar_fuentes(root):
    root = Path(root)
    issues = []
    checks = 0

    def get(book, tab, axis='row'):
        nonlocal checks
        file = Path(book)
        if not file.is_file():
            issues.append(f'No existe {file.name} ({file.parent.name}).')
            return {}
        wb = load_workbook(file, read_only=True, data_only=True)
        try:
            if tab not in wb.sheetnames:
                issues.append(f'No existe la hoja {tab} de {file}.')
                return {}
            sh = wb[tab]
            rows = list(sh.values)
            if axis == 'row':
                # {año: {índice de columna 0-based: valor}}
                return {int(r[0]): {i: v for i, v in enumerate(r)}
                        for r in rows if r and isinstance(r[0], (int, float)) and int(r[0]) in YEARS}
            # P&L: encabezados años y filas cuentas SBS.
            years = {i: int(v) for i, v in enumerate(rows[0]) if isinstance(v, (int, float)) and int(v) in YEARS}
            return {year: {i: rows[i][col] for i in range(1, min(len(rows), 18))
                           if col < len(rows[i])}
                    for col, year in years.items()}
        finally:
            wb.close()

    def check(label, x, y):
        nonlocal checks
        checks += 1
        if not isinstance(x, (int, float)) or not isinstance(y, (int, float)) or abs(x-y) > TOL:
            issues.append(f'{label}: {x} frente a {y} MM.')

    dirs = {mid: buscar_modelo(root, str(mid), opcional=True)
            for mid in (16, 18, 20, 23, 28, 29)}
    for mid, folder in dirs.items():
        if folder is None:
            issues.append(f'No se encontró la carpeta del Modelo {mid}.')
    if any(v is None for v in dirs.values()):
        return {'passed': False, 'checks': checks, 'errors': issues[:80]}

    a16 = get(dirs[16]/'Consolidado.xlsx', 'Anual')
    a18 = get(dirs[18]/'Consolidado.xlsx', 'Anual')
    a20 = get(dirs[20]/'Consolidado.xlsx', 'Anual')
    a23 = get(dirs[23]/'Consolidado.xlsx', 'Anual')
    taxes = {file: get(dirs[28]/file, 'Anual')
             for file in ('Input/Base_modelo.xlsx', 'Consolidado.xlsx', 'Output/Pronostico.xlsx')}
    pnl = {file: get(dirs[29]/file, 'P&L SBS', 'pnl')
           for file in ('Input/Base_modelo.xlsx', 'Consolidado.xlsx', 'Output/Pronostico.xlsx')}
    # Detecta desincronizaciones de inputs intermedios del Modelo 23.
    # Antes podía actualizarse Output/Consolidado y quedar Input con cifras viejas.
    m23_inputs = {}
    for folder, columns in (('01_Ingresos_por_intereses', (1, 2, 3, 4)),
                            ('02_Otros_ingresos_financieros', (1, 2, 3, 4, 5))):
        m23_inputs[folder] = (columns,
            get(dirs[23]/folder/'Input'/'Base_modelo.xlsx', 'Anual'),
            get(dirs[23]/folder/'Output'/'Pronostico.xlsx', 'Anual'))

    for year in YEARS:
        for folder, (columns, source, target) in m23_inputs.items():
            if year not in source or year not in target:
                issues.append(f'{year} M23 {folder}: falta fila Input u Output.')
                continue
            for col in columns:
                old, new = source[year].get(col), target[year].get(col)
                if isinstance(old, (float, int)) and isinstance(new, (float, int)):
                    check(f'{year} M23 {folder} Input/Output columna {col+1}',old,new)
                elif isinstance(old, (float,int)) != isinstance(new,(float,int)):
                    issues.append(f'{year} M23 {folder} columna {col+1}: dato numérico perdido.')
        try:
            # Columnas 0-based: A=0, B=1...; en el P&L: fila Excel = clave+1.
            x16, x18, x20, x23 = (a[year] for a in (a16, a18, a20, a23))
            tax = [t[year][1] for t in taxes.values()]
            pl = [p[year] for p in pnl.values()]
        except KeyError:
            issues.append(f'{year}: faltan insumos o cierre en los archivos fuente.')
            continue
        check(f'{year} M16, suma componentes', x16[5], sum(x16[i] for i in (1, 2, 3, 4)))
        check(f'{year} M20, consolidación ROF', x20[7], sum(x20[i] for i in range(1, 7)))
        check(f'{year} M18, ingresos servicios', x18[3], x18[1]+x18[2])
        check(f'{year} M18, gastos servicios', x18[7], x18[4]+x18[5])
        check(f'{year} M18, neto servicios', x18[8], x18[3]-x18[7])
        check(f'{year} M23, ingresos financieros', x23[3], x23[1]+x23[2])
        check(f'{year} M23, gastos financieros', x23[7], x23[4]+x23[5]+x23[6])
        check(f'{year} M23, margen', x23[8], x23[3]-x23[7])
        check(f'{year} M16 → M23', x23[1], x16[5])
        check(f'{year} M18 FSD → M23', x23[5], x18[6])
        for i in (1, 2):
            check(f'{year} M28 archivos {i}', tax[0], tax[i])
            for row in range(1, 18):
                check(f'{year} M29, fila {row+1}, archivo {i}', pl[0].get(row), pl[i].get(row))
        p = pl[0]
        check(f'{year} M23 ingresos → M29', p[1], x23[3])
        check(f'{year} M23 gastos → M29', p[2], x23[7])
        check(f'{year} M23 margen → M29', p[3], x23[8])
        check(f'{year} M28 impuesto → M29', p[16], tax[0])
        check(f'{year} M29 impuesto 27%', p[16], 0.27*p[15])
        check(f'{year} M29 utilidad neta', p[17], p[15]-p[16])
    return {'passed': not issues, 'checks': checks, 'errors': issues[:80]}
