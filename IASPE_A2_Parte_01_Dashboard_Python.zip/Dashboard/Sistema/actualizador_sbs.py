from __future__ import annotations

from collections import deque
from contextlib import contextmanager
import csv
import hashlib
import math
import re
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import traceback
import uuid

from instituciones_sbs import BANKS, CENCOSUD_ID, catalog as institution_catalog, category_at

# El mismo turno exclusivo protege descarga, cambios de base y recálculo.
OPERATION_LOCK = threading.Lock()
DATA_LOCK = threading.RLock()
_OPERATION = None


class Ocupado(RuntimeError):
    pass


def operation_status():
    return dict(_OPERATION) if _OPERATION else {'running': False, 'kind': None}


def _claim_operation(kind):
    global _OPERATION
    if not OPERATION_LOCK.acquire(blocking=False):
        raise Ocupado('Hay una descarga o un recálculo en curso; espera a que termine.')
    _OPERATION = {'running': True, 'kind': kind, 'startedAt': now()}


def _release_operation():
    global _OPERATION
    _OPERATION = None
    OPERATION_LOCK.release()


@contextmanager
def operation(kind):
    _claim_operation(kind)
    try:
        yield
    finally:
        _release_operation()

PROJECT = Path(__file__).resolve().parents[2] / 'IASPE'
SCRAPER = PROJECT / 'Scraper'
OUTPUT = SCRAPER / 'Actualizacion' / 'output'
SCRIPT = SCRAPER / 'Actualizacion' / 'script' / 'ejecutar_sbs.py'
LINK = SCRAPER / 'Actualizacion' / 'script' / 'vincular_modelos.py'
LINK_OUTPUT = SCRAPER / 'Actualizacion' / 'output'
SOURCES = (
    ('personal_banca', 'Personal · Banca Múltiple'),
    ('personal_financieras', 'Personal · Empresas Financieras'),
    ('personal_rurales', 'Personal · Cajas Rurales'),
    ('ratios', 'Indicadores financieros SBS'),
    ('tarjetas', 'Número de tarjetas de crédito'),
    ('morosidad', 'Morosidad de tarjetas'),
    ('cartera', 'Cartera de consumo'),
    ('estados_financieros', 'Estados financieros'),
    ('ahorro_moneda', 'Depósitos de ahorro MN y ME'),
    ('tasas_mercado', 'Series financieras BCRP'),
    ('oficinas', 'Oficinas SBS'),
)
BACKUP = {
    'personal_banca': ['Scraper/Numero_trabajadores/output/personal_banca_mensual.csv',
                       'Scraper/Numero_trabajadores/output/personal_mercado.csv'],
    'personal_financieras': ['Scraper/Numero_trabajadores/output/personal_financieras.csv',
                            'Scraper/Numero_trabajadores/output/personal_mercado.csv'],
    'personal_rurales': ['Scraper/Numero_trabajadores/output/personal_rurales.csv',
                        'Scraper/Numero_trabajadores/output/personal_mercado.csv'],
    'ratios': ['Scraper/Ratios_financieros_mercado/output/indicadores_16_entidades_principales.csv',
               'Scraper/Ratios_financieros_mercado/output/indicadores_16_entidades_todos.csv'],
    'tarjetas': ['Scraper/Numero_tarjetas/output/SBS_Tarjetas_Consumo_y_Total_Banca_Falabella_2008_2026.xlsx'],
    'morosidad': ['Scraper/Morosidad_tarjetas/output/Morosidad_tarjetas_consumo_banca_multiple.xlsx'],
    'cartera': ['Scraper/Cartera_consumo_mercado/output/Cartera_consumo_banca_multiple.xlsx'],
    'estados_financieros': ['Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz'],
    'ahorro_moneda': ['Scraper/Actualizacion/output/ahorro_moneda_sbs.json'],
    'tasas_mercado': ['Scraper/Actualizacion/output/tasas_mercado.json',
                     'Scraper/Actualizacion/output/compras_bcrp.json'],
    'oficinas': ['Scraper/Oficinas/output/oficinas_historico.json',
                 'Scraper/Oficinas/output/oficinas_departamentos.csv',
                 'Scraper/Oficinas/output/consulta_oficinas.json'],
}


def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


ACCOUNT_MODELS = {
    'ahorro': ('08', '08_mn', '08_me'),
    'plazo_cts': ('09', '09_plazo', '09_cts'),
    'obligaciones': ('10', '10_restringidos', '10_otras'),
    'disponible': ('17', '17_caja', '17_bancos', '17_canje', '17_otros'),
    'inversiones': ('21', '21_venta', '21_asociadas'),
    'interbancarios': ('22', '22_interbancarios'),
    'gastos_intereses': ('12', '12_obligaciones', '12_entidades', '12_adeudos', '12_otras'),
    'ingresos_intereses': ('16', '16_creditos', '16_inversiones', '16_disponible', '16_interbancarios'),
    'servicios': ('18', '18_diversos', '18_otros_ing', '18_gastos_div', '18_otros_gastos', '18_fsd'),
    'administracion': ('19', '19_personal', '19_directorio', '19_terceros', '19_impuestos'),
    'operaciones': ('20', '20_consorcios', '20_tc', '20_derivados', '20_inversiones', '20_otros'),
    'provisiones': ('25',),
    'depreciacion': ('26',),
    'margen': ('23',),
    'otros_resultados': ('24',),
    'otras_provisiones': ('27',),
    'impuesto_renta': ('28',),
    'resultado_neto': ('29',),
    'lineas_no_utilizadas': ('30',),
    'cuentas_cobrar': ('31',),
    'rendimientos_cobrar': ('32',),
}
ALL_ACCOUNTS = tuple(ACCOUNT_MODELS)
SOURCE_COMPONENTS = {
    'tarjetas': ('01', '02', '04'),
    'cartera': ('05', '06'),
    'tasas_mercado': ('03', '13', '14', '15'),
    'estados_financieros': tuple(dict.fromkeys(model for key, models in ACCOUNT_MODELS.items()
                                                if key != 'ahorro' for model in models)),
    'ahorro_moneda': ('08', '08_mn', '08_me'),
}
ALL_COMPONENTS = tuple(dict.fromkeys(model for models in SOURCE_COMPONENTS.values() for model in models))
RATIO_CATEGORIES = ('Liquidez', 'Calidad de activos', 'Eficiencia y gestión', 'Solvencia', 'Rentabilidad', 'Otros')
BANK_SOURCE_IDS = ('estados_financieros', 'ratios', 'personal_banca', 'personal_financieras', 'personal_rurales')


class Detenido(Exception):
    pass


OUTPUT_FOLDERS = {
    'personal_banca': 'Scraper/Numero_trabajadores/output',
    'personal_financieras': 'Scraper/Numero_trabajadores/output',
    'personal_rurales': 'Scraper/Numero_trabajadores/output',
    'ratios': 'Scraper/Ratios_financieros_mercado/output',
    'tarjetas': 'Scraper/Numero_tarjetas/output',
    'morosidad': 'Scraper/Morosidad_tarjetas/output',
    'cartera': 'Scraper/Cartera_consumo_mercado/output',
    'estados_financieros': 'Scraper/EEFF_Benchmark/output',
    'ahorro_moneda': 'Scraper/Actualizacion/output',
    'tasas_mercado': 'Scraper/Actualizacion/output',
    'oficinas': 'Scraper/Oficinas/output',
}

def paths(task, project=None):
    project = Path(project or PROJECT)
    folder = project / OUTPUT_FOLDERS[task]
    files = [project / p for p in BACKUP[task]]
    if task not in ('tasas_mercado', 'ahorro_moneda'):
        files.extend(p for p in folder.rglob('*') if p.is_file())
    if task == 'estados_financieros':
        files.extend(sorted((project / 'Estados financieros banca' / 'SBS tal cual').glob('*/*.xlsx')))
    output = project / 'Scraper/Actualizacion/output'
    if task != 'oficinas':
        files += [output / 'observaciones_modelos.json', output / 'vinculacion_modelos.json']
    return list(dict.fromkeys(files))


class Actualizador:
    def __init__(self):
        self.lock = threading.RLock()
        self.lines = deque(maxlen=120)
        self.tasks = [{'id': key, 'label': label, 'status': 'pendiente', 'detail': ''} for key, label in SOURCES]
        self.running = False
        self.stopping = False
        self._stop_event = threading.Event()
        self._process = None
        self.accounts = list(ALL_ACCOUNTS)
        self.components = list(ALL_COMPONENTS)
        self.ratio_categories = list(RATIO_CATEGORIES)
        self.banks = list(BANKS)
        self.selected = [k for k, _ in SOURCES]
        self.started = None
        self.ended = None
        self.run_id = None
        self.result = 'sin_ejecutar'
        self.summary = None
        self._before_observed = None
        self.generation = 0
        self.source_results = {}
        self._active_project = None
        self._last_download_report = {}
        self._last_valid_metrics = {}
        self._restore()

    def _restore(self):
        p = OUTPUT / 'ultima_ejecucion.json'
        if not p.is_file():
            return
        try:
            previous = json.loads(p.read_text(encoding='utf-8'))
            self.generation = int(previous.get('generation', 0))
            self.source_results = previous.get('sources', {})
            self.started = previous.get('started')
            self.ended = previous.get('ended')
            self.result = previous.get('result', 'sin_ejecutar')
            self.summary = previous.get('summary')
            previous_banks = previous.get('banks')
            if isinstance(previous_banks, list) and previous_banks and len(set(previous_banks)) == len(previous_banks) and all(b in BANKS for b in previous_banks):
                self.banks = [b for b in BANKS if b in previous_banks]
            previous_ratios = previous.get('ratioCategories')
            if isinstance(previous_ratios, list) and all(v in RATIO_CATEGORIES for v in previous_ratios):
                self.ratio_categories = previous_ratios
            previous_components = previous.get('components')
            if isinstance(previous_components, list) and all(m in ALL_COMPONENTS for m in previous_components):
                self.components = previous_components
            previous_accounts = previous.get('accounts')
            if isinstance(previous_accounts, list) and all(a in ACCOUNT_MODELS for a in previous_accounts):
                self.accounts = previous_accounts
            last_selected = previous.get('selected')
            if isinstance(last_selected, list):
                valid = {k for k, _ in SOURCES}
                self.selected = [k for k in last_selected if k in valid] or [k for k, _ in SOURCES]
            old = {t['id']: t for t in previous.get('tasks', [])}
            for task in self.tasks:
                if task['id'] in old:
                    task['status'] = old[task['id']].get('status', 'pendiente')
                    task['detail'] = old[task['id']].get('detail', '')
            self.lines.extend(previous.get('lines', [])[-100:])
            if self.result in ('en_curso', 'deteniendo'):
                self.result = 'interrumpido'
                for item in self.tasks:
                    if item['status'] == 'en_curso':
                        item['status'] = 'pendiente'
                        item['detail'] = 'Pendiente tras una interrupción.'
        except (ValueError, OSError, KeyError):
            pass

    def snapshot(self):
        with self.lock:
            return {'running': self.running, 'stopping': self.stopping, 'canResume': not self.running and self.result in ('detenido', 'interrumpido'), 'accounts': list(self.accounts), 'components': list(self.components), 'ratioCategories': list(self.ratio_categories), 'banks': list(self.banks), 'started': self.started, 'ended': self.ended,
                    'runId': self.run_id, 'result': self.result,
                    'tasks': [dict(t) for t in self.tasks], 'lines': list(self.lines),
                    'selected': list(self.selected),
                    'source': 'SBS', 'excluded': ['Supuestos macroeconómicos', 'MMM'],
                    'modelsLink': self.link_status(), 'summary': self.summary,
                    'generation': self.generation, 'revision': str(self.generation),
                    'benchmarksRevision': str(self.generation),
                    'latestPeriod': max((entry.get('latestPeriod') or '' for entry in self.source_results.values()),default='') or None,
                    'sources': dict(self.source_results), 'source_last_results': dict(self.source_results),
                    'operation': operation_status(), 'institutions': institution_catalog()}

    def link_status(self):
        path = LINK_OUTPUT / 'vinculacion_modelos.json'
        try:
            return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {'fuentes': {}}
        except (OSError, ValueError):
            return {'fuentes': {}}

    def _save(self):
        OUTPUT.mkdir(parents=True, exist_ok=True)
        target = OUTPUT / 'ultima_ejecucion.json'
        pending = target.with_suffix('.tmp')
        pending.write_text(json.dumps(self.snapshot(), ensure_ascii=False, indent=2), encoding='utf-8')
        pending.replace(target)

    def _log(self, message):
        line = f'{datetime.now().strftime("%H:%M:%S")}  {message}'
        with self.lock:
            self.lines.append(line)
        try:
            print(line, flush=True)
        except UnicodeEncodeError:
            print(line.encode('ascii', 'backslashreplace').decode('ascii'), flush=True)

    def _accounts(self, account_ids):
        if account_ids is None:
            return list(ALL_ACCOUNTS)
        if not isinstance(account_ids, list) or any(not isinstance(a, str) or a not in ACCOUNT_MODELS for a in account_ids):
            raise ValueError('Selección de cuentas no válida.')
        if len(set(account_ids)) != len(account_ids):
            raise ValueError('La selección de cuentas contiene duplicados.')
        return [a for a in ALL_ACCOUNTS if a in account_ids]

    def _components(self, values):
        if values is None:
            return list(ALL_COMPONENTS)
        if not isinstance(values, list) or any(not isinstance(value, str) or value not in ALL_COMPONENTS for value in values):
            raise ValueError('Selección de series no válida.')
        if len(values) != len(set(values)):
            raise ValueError('La selección de series contiene duplicados.')
        return [value for value in ALL_COMPONENTS if value in values]

    def begin(self, source_ids=None, account_ids=None, component_ids=None, ratio_categories=None, bank_ids=None):
        valid = [k for k, _ in SOURCES]
        if source_ids is None:
            selected = valid
        else:
            if not isinstance(source_ids, list) or not source_ids or any(not isinstance(x, str) for x in source_ids):
                raise ValueError('Selecciona al menos una fuente SBS.')
            if len(set(source_ids)) != len(source_ids) or any(x not in valid for x in source_ids):
                raise ValueError('La selección contiene fuentes desconocidas o repetidas.')
            selected = [k for k in valid if k in source_ids]
        if bank_ids is None:
            banks = list(BANKS)
        elif not isinstance(bank_ids, list) or any(not isinstance(b, str) or b not in BANKS for b in bank_ids) or len(set(bank_ids)) != len(bank_ids):
            raise ValueError('La selección de entidades no es válida.')
        else:
            banks = [b for b in BANKS if b in bank_ids]
        if not banks and any(source in BANK_SOURCE_IDS for source in selected):
            raise ValueError('Selecciona al menos una entidad para las fuentes por banco.')
        accounts = self._accounts(account_ids)
        components = self._components(component_ids)
        ratios = list(RATIO_CATEGORIES) if ratio_categories is None else ratio_categories
        if (not isinstance(ratios, list) or len(set(ratios)) != len(ratios)
                or any(not isinstance(value, str) or value not in RATIO_CATEGORIES for value in ratios)):
            raise ValueError('Selección de indicadores no válida.')
        if 'ratios' in selected and not ratios:
            raise ValueError('Selecciona al menos un indicador financiero.')
        for source in selected:
            if source in SOURCE_COMPONENTS and not set(components).intersection(SOURCE_COMPONENTS[source]):
                # Solo se admiten fuentes sin series cuando el panel general se usa para conciliar ahorro.
                if source != 'estados_financieros' or 'ahorro_moneda' not in selected:
                    raise ValueError(f'Selecciona al menos una serie de {dict(SOURCES)[source]}.')
        if 'estados_financieros' in selected and not any(a != 'ahorro' for a in accounts):
            if 'ahorro_moneda' not in selected:
                raise ValueError('Selecciona al menos una cuenta de estados financieros.')
        if 'ahorro_moneda' in selected and 'ahorro' not in accounts:
            raise ValueError('Selecciona depósitos de ahorro MN y ME.')
        with self.lock:
            if self.running:
                raise Ocupado('Ya hay una actualización SBS en ejecución.')
            if not SCRIPT.is_file():
                raise FileNotFoundError('No se encontró el ejecutor SBS en IASPE/Scraper/Actualizacion.')
            # Conserva los pronósticos actuales hasta que se pulse Recalcular.
            import motor
            _claim_operation('download')
            try:
                with motor.LOCK:
                    if any(source != 'oficinas' for source in selected):
                        motor.freeze_sources()
                    self._before_observed = motor.source_observations()
            except Exception:
                _release_operation()
                raise
            self.summary = None
            self.running = True
            self.stopping = False
            self._stop_event.clear()
            self.accounts = accounts
            self.components = components
            self.ratio_categories = ratios
            self.banks = banks
            self.selected = selected
            self.run_id = uuid.uuid4().hex[:12]
            self.started, self.ended, self.result = now(), None, 'en_curso'
            self.tasks = [{'id': id, 'label': name, 'status': 'pendiente' if id in selected else 'omitida', 'detail': ''} for id, name in SOURCES]
            self.lines.clear()
            worker = threading.Thread(target=self._run, daemon=True, name='IASPE-SBS')
            worker.start()
            return self.snapshot()

    def _kill(self, process):
        if process is None or process.poll() is not None:
            return
        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                               capture_output=True, timeout=15)
            else:
                os.killpg(process.pid, signal.SIGTERM)
        except (OSError, subprocess.SubprocessError):
            try:
                process.terminate()
            except OSError:
                pass

    def stop(self):
        with self.lock:
            if not self.running:
                raise ValueError('No hay una actualización activa.')
            self.stopping = True
            self.result = 'deteniendo'
            self._stop_event.set()
            process = self._process
        self._kill(process)
        return self.snapshot()

    def resume(self):
        with self.lock:
            if self.running:
                raise Ocupado('Ya hay una actualización SBS en ejecución.')
            if self.result not in ('detenido', 'interrumpido'):
                raise ValueError('No hay una actualización detenida para reanudar.')
            _claim_operation('download')
            self._stop_event.clear()
            self.stopping = False
            self.running = True
            self.result = 'en_curso'
            self.ended = None
            self.run_id = uuid.uuid4().hex[:12]
            for task in self.tasks:
                if task['id'] in self.selected and task['status'] != 'correcto':
                    task['status'] = 'pendiente'
                    task['detail'] = ''
            worker = threading.Thread(target=self._run, daemon=True, name='IASPE-SBS')
            worker.start()
            return self.snapshot()

    def _check_stop(self):
        if self._stop_event.is_set():
            raise Detenido('Actualización detenida por el usuario.')

    def _subprocess(self, cmd, *, capture=False, timeout=None):
        flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
        project = self._active_project or PROJECT
        arguments = dict(cwd=str(project),
                         env=dict(os.environ, IASPE_DIR=str(project), IASPE_ROOT=str(project),
                                  PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8:backslashreplace'),
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                         encoding='utf-8', errors='replace', bufsize=1,
                         creationflags=flags)
        if os.name != 'nt':
            arguments['start_new_session'] = True
        self._check_stop()
        with subprocess.Popen(cmd, **arguments) as process:
            with self.lock:
                self._process = process
            tail = deque(maxlen=12)
            try:
                self._check_stop()
                if capture:
                    # El vínculo suele acabar rápido; la espera sigue siendo cancelable.
                    import time
                    started = time.monotonic()
                    while True:
                        self._check_stop()
                        try:
                            output, _ = process.communicate(timeout=0.2)
                            break
                        except subprocess.TimeoutExpired:
                            if timeout and time.monotonic() - started > timeout:
                                self._kill(process)
                                raise RuntimeError('Tiempo de validación agotado.')
                    if process.returncode:
                        raise RuntimeError(f'Código {process.returncode}. {output[-900:]}')
                    self._check_stop()
                    return output
                for line in process.stdout:
                    self._check_stop()
                    message = line.rstrip()
                    if message:
                        tail.append(message)
                        self._log(message[:350])
                code = process.wait()
                self._check_stop()
                if code:
                    raise RuntimeError(f'Código {code}. ' + ' | '.join(tail)[-800:])
            finally:
                with self.lock:
                    if self._process is process:
                        self._process = None
                if self._stop_event.is_set():
                    self._kill(process)

    def _execute(self, task):
        project = self._active_project or PROJECT
        script = project / 'Scraper/Actualizacion/script/ejecutar_sbs.py'
        cmd = [sys.executable, '-B', '-u', str(script), task]
        if task == 'estados_financieros':
            cmd += ['--bancos', ','.join(self.banks)]
        if os.environ.get('IASPE_SBS_SOLO_CACHE') == '1':
            cmd.append('--solo-cache')
        self._subprocess(cmd)

    def _validate(self, task, project=None, *, require_selected=True):
        """Valida cifras y periodos del producto, antes de publicarlo."""
        project = Path(project or self._active_project or PROJECT)
        if task == 'oficinas':
            from oficinas_sbs import validation
            return validation(project)
        folder = project / OUTPUT_FOLDERS[task]
        required = [project / name for name in BACKUP[task]
                    if not name.endswith('personal_mercado.csv')]
        for path in required:
            if not path.is_file() or path.stat().st_size < 20:
                raise ValueError(f'La fuente no produjo un archivo válido: {path.name}')
        values = {}
        entities = set()
        missing_categories = 0
        def put(key, period, value):
            if not re.fullmatch(r'20\d{2}-(0[1-9]|1[0-2])', str(period)):
                raise ValueError(f'Periodo no válido: {period}')
            if str(period) > datetime.now(timezone.utc).strftime('%Y-%m'):
                raise ValueError(f'La fuente contiene un mes todavía no observado: {period}')
            if isinstance(value, bool) or not math.isfinite(float(value)):
                raise ValueError(f'Dato no finito en {period}')
            token = (str(key), str(period))
            if token in values and values[token] != float(value):
                raise ValueError(f'Datos contradictorios: {key}/{period}')
            values[token] = float(value)
        if task.startswith('personal_'):
            with required[0].open(encoding='utf-8-sig', newline='') as file:
                reader = csv.DictReader(file)
                needed = {'periodo','banco','personal_total','gerentes','funcionarios','empleados','otros'}
                if not needed.issubset(reader.fieldnames or []):
                    raise ValueError('Columnas de personal no reconocidas')
                for row in reader:
                    counts = [int(row['personal_total'])]
                    for key in ('gerentes','funcionarios','empleados','otros'):
                        raw = row.get(key)
                        missing = raw is None or str(raw).strip() in ('','-','–','—')
                        counts.append(None if missing else int(raw))
                        missing_categories += int(missing)
                    if any(value is not None and value < 0 for value in counts):
                        raise ValueError(f'Personal no concilia: {row["banco"]}/{row["periodo"]}')
                    if all(value is not None for value in counts[1:]) and counts[0] != sum(counts[1:]):
                        raise ValueError(f'Personal no concilia: {row["banco"]}/{row["periodo"]}')
                    entities.add(row['banco'])
                    for key, value in zip(('personal_total','gerentes','funcionarios','empleados','otros'), counts):
                        if value is not None:
                            put(row['banco']+'|'+key, row['periodo'], value)
        elif task == 'ratios':
            for path in required:
                with path.open(encoding='utf-8-sig', newline='') as file:
                    reader = csv.DictReader(file)
                    needed = {'periodo_fuente','banco_id','indicador_sbs','valor','reporte'}
                    if not needed.issubset(reader.fieldnames or []):
                        raise ValueError('Columnas de indicadores no reconocidas')
                    for row in reader:
                        if row['banco_id'] not in BANKS:
                            raise ValueError('Indicador con entidad no reconocida')
                        entities.add(row['banco_id'])
                        key = path.name+'|'+row['banco_id']+'|'+row['reporte']+'|'+row['indicador_sbs']+'|'+row.get('fecha_indicador','')
                        put(key, row['periodo_fuente'], row['valor'])
        elif task == 'estados_financieros':
            import gzip
            with gzip.open(required[0], 'rt', encoding='utf-8') as file:
                panel = json.load(file)
            banks = [item['id'] for item in panel['meta']['banks']]
            if len(banks) != len(set(banks)) or not set(banks).issubset(BANKS):
                raise ValueError('El panel de EEFF tiene entidades duplicadas o desconocidas')
            if require_selected and not set(self.banks).issubset(banks):
                raise ValueError('Faltan entidades seleccionadas en el panel de EEFF')
            for account, series in panel['series'].items():
                for bank, months in series.items():
                    if bank not in banks:
                        raise ValueError('El panel de EEFF contiene una entidad sin catálogo')
                    for period, value in months.items():
                        entities.add(bank)
                        put(account+'|'+bank, period, value)
        elif task in ('tarjetas','morosidad','cartera'):
            from openpyxl import load_workbook
            book = load_workbook(required[0], read_only=True, data_only=True)
            try:
                if 'Mensual' not in book:
                    raise ValueError('Falta la hoja Mensual')
                rows = book['Mensual'].iter_rows(values_only=True)
                header = next(rows)
                if task == 'tarjetas' and tuple(header[:5]) != ('anio','mes','banca_multiple','falabella','banca_total'):
                    raise ValueError('Cambió la estructura de tarjetas')
                for row in rows:
                    if row[0] is None:
                        continue
                    if task == 'tarjetas':
                        period = f'{int(row[0]):04d}-{int(row[1]):02d}'
                        offset = 2
                    else:
                        if not isinstance(row[0], datetime):
                            raise ValueError('Fecha mensual no reconocida')
                        period, offset = row[0].strftime('%Y-%m'), 1
                    for col in range(offset, min(len(row), 6 if task == 'tarjetas' else 7 if task == 'cartera' else 4)):
                        value = row[col]
                        if value is None:
                            continue
                        if float(value) < 0 or (task == 'morosidad' and float(value) > 100):
                            raise ValueError(f'Valor incompatible en {period}')
                        if task == 'tarjetas' and int(value) != value:
                            raise ValueError(f'El número de tarjetas no es entero: {period}')
                        put(str(header[col]), period, value)
                    if task == 'cartera':
                        if any(not isinstance(row[c], (int,float)) for c in range(1,7)):
                            raise ValueError(f'Cartera incompleta: {period}')
                        if abs(row[1]+row[2]-row[3]) > .0001 or abs(row[4]+row[5]-row[6]) > .0001:
                            raise ValueError(f'Cartera no concilia: {period}')
            finally:
                book.close()
        else:
            if task == 'ahorro_moneda':
                series = json.loads(required[0].read_text(encoding='utf-8')).get('series', {})
                if not series.get('08_mn') or set(series.get('08_mn', {})) != set(series.get('08_me', {})):
                    raise ValueError('No concilian los meses de ahorro MN/ME')
            else:
                series = json.loads(required[0].read_text(encoding='utf-8'))
                if not all(series.get(key) for key in ('13','14','15')):
                    raise ValueError('Faltan las tres tasas financieras BCRP')
                purchases = json.loads(required[1].read_text(encoding='utf-8'))
                if not purchases.get('03'):
                    raise ValueError('Faltan las compras observadas BCRP')
                series = dict(series, **purchases)
            for key, months in series.items():
                for period, value in months.items():
                    put(key, period, value['value'] if isinstance(value,dict) else value)
        if not values:
            raise ValueError('La fuente no contiene observaciones numéricas válidas')
        if task == 'estados_financieros' and require_selected and not set(self.banks).issubset(entities):
            raise ValueError('Faltan cifras de entidades seleccionadas en los EEFF')
        history = {key for key in values if not task.startswith('personal_') or key[0].endswith('|personal_total')}
        return {'latestPeriod': max(period for _, period in values),
                'records': len(values), 'entities': sorted(entities), '_values': values,
                '_history': history, 'missingCategoryValues': missing_categories,
                'dataNotes': ['La SBS no publica algunas categorías laborales; se conservan vacías y no se infieren ceros.'] if missing_categories else []}

    @staticmethod
    def _preserves_history(previous, updated):
        # El total laboral siempre debe conservarse. Una categoría que la SBS
        # deja vacía sigue vacía, aunque su cifra pudiera inferirse por resta.
        missing = set(previous.get('_history', previous.get('_values', {}))) - set(updated['_values'])
        if missing:
            raise ValueError(f'La actualización omite {len(missing)} datos previamente válidos; no se publica')

    @staticmethod
    def _merge_ratio_rows(current, previous, categories, banks):
        with current.open(encoding='utf-8-sig', newline='') as file:
            reader = csv.DictReader(file)
            headers = reader.fieldnames
            newest = list(reader)
        if not headers or 'categoria' not in headers or 'indicador_sbs' not in headers:
            raise ValueError('No se reconocieron las categorías del reporte SBS.')
        with previous.open(encoding='utf-8-sig', newline='') as file:
            reader = csv.DictReader(file)
            if reader.fieldnames != headers:
                raise ValueError('Cambió la estructura de los indicadores SBS.')
            historical = list(reader)
        selected = set(categories)
        selected_banks = set(banks)
        target = lambda row: (row.get('categoria') or 'Otros') in selected and row.get('banco_id') in selected_banks
        key = lambda row: (row.get('periodo_fuente'), row.get('banco_id'),
                           row.get('reporte'), row.get('indicador_sbs'), row.get('fecha_indicador'))
        # Una descarga parcial puede revisar filas, nunca borrar otras válidas.
        merged = {key(row): row for row in historical}
        merged.update({key(row): row for row in newest if target(row)})
        result = list(merged.values())
        result.sort(key=lambda row: (row.get('periodo_fuente', ''), row.get('banco_id', ''),
                                     row.get('categoria', ''), row.get('indicador_sbs', '')))
        temp = current.with_suffix('.tmp')
        with temp.open('w', encoding='utf-8-sig', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=headers)
            writer.writeheader()
            writer.writerows(result)
        temp.replace(current)

    @staticmethod
    def _merge_personal_rows(current, previous, banks):
        with current.open(encoding='utf-8-sig', newline='') as f:
            reader=csv.DictReader(f); headers=reader.fieldnames; newest=list(reader)
        with previous.open(encoding='utf-8-sig', newline='') as f:
            reader=csv.DictReader(f); old_headers=reader.fieldnames; historical=list(reader)
        required={'periodo','banco','personal_total','gerentes','funcionarios','empleados','otros'}
        if (not headers or not old_headers or len(headers)!=len(set(headers))
                or len(old_headers)!=len(set(old_headers))
                or not required.issubset(headers) or not required.issubset(old_headers)
                or (set(headers)^set(old_headers))-{'sistema'}):
            raise ValueError('Cambió la estructura del personal SBS.')
        # El orden histórico se conserva. La única ampliación compatible es
        # la clasificación declarada por la fuente; no altera cifras laborales.
        output_headers=list(old_headers)
        if 'sistema' in headers and 'sistema' not in output_headers:
            output_headers.append('sistema')
        selected={BANKS[id] for id in banks}
        merged={(row['periodo'],row['banco']):row for row in historical}
        for row in newest:
            if row['banco'] in selected:
                key=(row['periodo'],row['banco'])
                merged[key]=dict(merged.get(key,{}),**row)
        rows=list(merged.values())
        rows.sort(key=lambda r:(r['periodo'],r['banco']))
        temp=current.with_suffix('.tmp')
        with temp.open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=output_headers);writer.writeheader();writer.writerows(rows)
        temp.replace(current)

    @staticmethod
    def _rebuild_personal_mercado(project=None):
        folder=Path(project or PROJECT) / 'Scraper/Numero_trabajadores/output'
        columns=['periodo','banco','personal_total','gerentes','funcionarios','empleados','otros','nombre_sbs','archivo','hoja','fila_excel','sistema']
        data={}
        for name in ('personal_historico_2012_2015.csv','personal_banca_mensual.csv','personal_financieras.csv','personal_rurales.csv'):
            path=folder/name
            if not path.is_file():continue
            with path.open(encoding='utf-8-sig',newline='') as f:
                for row in csv.DictReader(f):
                    if not row.get('periodo') or not row.get('banco'):continue
                    result={k:row.get(k,'') for k in columns}
                    ident=next((key for key,name in BANKS.items() if name==row['banco']),None)
                    category=category_at(ident,row['periodo']) if ident else row.get('sistema','')
                    result['sistema']={'Bancos':'Banca Múltiple','Empresas financieras':'Empresas Financieras',
                                       'Cajas rurales':'Cajas Rurales'}.get(category,category)
                    data[row['periodo'],row['banco']]=result
        path=folder/'personal_mercado.csv'
        temp=path.with_suffix('.tmp')
        with temp.open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(data[k] for k in sorted(data))
        temp.replace(path)

    @staticmethod
    def _publish_files(pairs, backup):
        """Publicación por archivos reemplazables con reversión completa."""
        changed = []
        try:
            for index, (generated, target) in enumerate(pairs):
                if target.is_file() and hashlib.sha256(target.read_bytes()).digest() == hashlib.sha256(generated.read_bytes()).digest():
                    continue
                saved = backup / str(index)
                if target.exists():
                    shutil.copy2(target, saved)
                else:
                    saved = None
                target.parent.mkdir(parents=True, exist_ok=True)
                pending = target.with_name(target.name+'.actualizando')
                try:
                    shutil.copy2(generated, pending)
                    os.replace(pending, target)
                finally:
                    pending.unlink(missing_ok=True)
                changed.append((target, saved))
        except Exception:
            for target, saved in reversed(changed):
                if saved is None:
                    target.unlink(missing_ok=True)
                else:
                    restored = target.with_name(target.name+'.restaurando')
                    shutil.copy2(saved, restored)
                    os.replace(restored, target)
            raise
        return len(changed)

    def _run_task(self, task):
        self._check_stop()
        previous = {}
        primary = PROJECT / BACKUP[task][0]
        if primary.exists():
            previous = self._validate(task, PROJECT, require_selected=False)
        self._last_valid_metrics[task] = {key:value for key,value in previous.items() if not key.startswith('_')}
        # Los scrapers escriben en una copia real: ni los lectores del panel ni
        # los libros activos ven una descarga incompleta o un archivo truncado.
        with tempfile.TemporaryDirectory(prefix='iaspe_fuente_') as temporary:
            workspace = Path(temporary)
            staged = workspace / 'IASPE'
            shutil.copytree(PROJECT, staged,
                            ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.tmp','*.actualizando'))
            system = Path(__file__).resolve().parent
            shutil.copytree(system, workspace/'Dashboard/Sistema',
                            ignore=shutil.ignore_patterns('__pycache__','*.pyc','.pytest_cache','*.tmp'))
            self._active_project = staged
            try:
                self._check_stop()
                report_path = staged/f'Scraper/Actualizacion/output/descarga_{task}.json'
                try:
                    self._execute(task)
                finally:
                    try:
                        self._last_download_report[task] = (json.loads(report_path.read_text(encoding='utf-8'))
                                                            if report_path.exists() else {})
                    except (OSError, ValueError):
                        self._last_download_report[task] = {'status':'error', 'errors':['Informe de descarga incompleto']}
                self._check_stop()
                # Se superponen revisiones por clave, preservando filas ausentes
                # de una descarga parcial y las entidades no seleccionadas.
                if task == 'ratios':
                    for name in ('indicadores_16_entidades_principales.csv','indicadores_16_entidades_todos.csv'):
                        current = staged / OUTPUT_FOLDERS[task] / name
                        old = PROJECT / OUTPUT_FOLDERS[task] / name
                        if old.exists():
                            self._merge_ratio_rows(current, old, self.ratio_categories, self.banks)
                if task.startswith('personal_'):
                    current = staged / BACKUP[task][0]
                    old = PROJECT / BACKUP[task][0]
                    if old.exists():
                        self._merge_personal_rows(current, old, self.banks)
                    self._rebuild_personal_mercado(staged)
                metrics = self._validate(task, staged)
                self._preserves_history(previous, metrics)
                self._check_stop()
                if task == 'oficinas':
                    report = self._last_download_report.get(task, {})
                    linking = {'fuente': task, 'modelos': [], 'observaciones_nuevas': 0,
                               'detalle': report.get('detail', 'Cobertura territorial actualizada; no alimenta modelos financieros.')}
                else:
                    link = staged/'Scraper/Actualizacion/script/vincular_modelos.py'
                    command = [sys.executable, '-B', str(link), task]
                    if task in ('estados_financieros','ahorro_moneda'):
                        command += ['--cuentas', ','.join(self.accounts)]
                    if task in SOURCE_COMPONENTS:
                        command += ['--componentes', ','.join(self.components)]
                    linking = json.loads(self._subprocess(command, capture=True, timeout=180).strip())
                self._check_stop()
                candidates = set(paths(task, staged))
                module = (staged / OUTPUT_FOLDERS[task]).parent
                kinds = ('fuentes',) if task in ('ahorro_moneda','tasas_mercado') else ('fuentes','output')
                for kind in kinds:
                    candidates.update(path for path in (module/kind).rglob('*') if path.is_file())
                if task == 'ahorro_moneda':
                    # Las Formas A que respaldan MN/ME se conservan con el dato.
                    candidates.update(path for path in (staged/'Scraper/EEFF_Benchmark/fuentes/B-2201').rglob('*') if path.is_file())
                    for bank_folder in (staged/'Estados financieros banca/SBS tal cual').glob('05 Banco Falabella*'):
                        candidates.update(path for path in (bank_folder/'_fuentes').rglob('*') if path.is_file())
                report_path = staged/f'Scraper/Actualizacion/output/descarga_{task}.json'
                report = self._last_download_report.get(task, {})
                if report_path.exists():
                    candidates.add(report_path)
                pairs = [(path, PROJECT/path.relative_to(staged)) for path in sorted(candidates) if path.is_file()]
                # El comparativo de cartera es un derivado observado del mismo
                # scraper; se publica dentro del mismo bloqueo que su Excel.
                if task == 'cartera':
                    panel = workspace/'Dashboard/Sistema/data/cartera_consumo_bancos.json'
                    if panel.exists():
                        pairs.append((panel, system/'data/cartera_consumo_bancos.json'))
                import motor
                backup = workspace/'rollback'
                backup.mkdir()
                with motor.LOCK, DATA_LOCK:
                    count = self._publish_files(pairs, backup)
                linking['validation'] = {key:value for key,value in metrics.items() if not key.startswith('_')}
                linking['download'] = report
                if task == 'oficinas':
                    linking['changed'] = previous.get('valueRevision') != metrics.get('valueRevision')
                    linking['metadataChanged'] = bool(count)
                    if report.get('status') == 'local_only':
                        linking['detalle'] = 'Reprocesado local; no se consultó la SBS.'
                    elif not linking['changed']:
                        linking['detalle'] = 'Sin cambios; última publicación y base territorial verificadas.'
                else:
                    linking['changed'] = bool(count)
                return linking
            finally:
                self._active_project = None

    def _run(self):
        try:
            OUTPUT.mkdir(parents=True, exist_ok=True)
            self._log(f'Inicio de actualización SBS · {len(self.selected)} fuente(s)')
            for task in self.tasks:
                if task['id'] not in self.selected or task['status'] == 'correcto':
                    continue
                self._check_stop()
                if ((task['id']=='personal_financieras' and '10' not in self.banks) or
                    (task['id']=='personal_rurales' and CENCOSUD_ID not in self.banks) or
                    (task['id']=='personal_banca' and not any(b not in ('10',CENCOSUD_ID) for b in self.banks))):
                    with self.lock:
                        task['status']='omitida'
                        task['detail']='No hay entidades de esta fuente en la selección.'
                    self._log(f'Omitida {task["label"]}: sin entidades elegibles.')
                    self._save()
                    continue
                with self.lock:
                    task['status'] = 'en_curso'
                    task['detail'] = ''
                self._log(task['label'])
                try:
                    linking = self._run_task(task['id'])
                    with self.lock:
                        report = linking.get('download', {})
                        publications = list(report.get('reports',{}).values()) or [report]
                        incomplete = any(item.get('latestPublished') and
                                         (item.get('latestProcessed') or '') < item['latestPublished']
                                         for item in publications)
                        limited = bool(incomplete or report.get('errors') or report.get('limitations') or report.get('estado') in ('parcial','error') or report.get('status') in ('parcial','error')
                                       or (task['id'] == 'oficinas' and report.get('status') == 'local_only'))
                        task['status'] = 'parcial' if limited else 'correcto'
                        task['detail'] = linking.get('detalle', '')
                        if limited:
                            task['detail'] += ' La fuente conserva limitaciones de descarga; revisar el informe.'
                        if linking.get('changed') or linking.get('metadataChanged'):
                            self.generation += 1
                        self.source_results[task['id']] = {
                            'status': task['status'], 'checkedAt': now(), 'detail': task['detail'],
                            'latestPeriod': linking.get('validation',{}).get('latestPeriod'),
                            'generation': self.generation, 'revision': str(self.generation),
                            'changed': linking.get('changed', False), 'download': report,
                            'validation': linking.get('validation',{})}
                    self._log(f'Validado: {task["label"]} · {linking.get("detalle", "")[:160]}')
                except Detenido:
                    with self.lock:
                        task['status'] = 'pendiente'
                        task['detail'] = 'Pendiente para reanudar.'
                    raise
                except Exception as exc:
                    if self._stop_event.is_set():
                        with self.lock:
                            task['status'] = 'pendiente'
                            task['detail'] = 'Pendiente para reanudar.'
                        raise Detenido('Actualización detenida por el usuario.') from exc
                    with self.lock:
                        task['status'] = 'error'
                        task['detail'] = f'{type(exc).__name__}: {exc}'[:600]
                        previous = self.source_results.get(task['id'], {})
                        self.source_results[task['id']] = dict(previous, status='error', checkedAt=now(),
                                                               detail=task['detail'], changed=False,
                                                               latestPeriod=self._last_valid_metrics.get(task['id'],{}).get('latestPeriod',previous.get('latestPeriod')),
                                                               download=self._last_download_report.get(task['id'],{}))
                    report = self._last_download_report.get(task['id'])
                    if report:
                        # La evidencia del fallo se conserva sin incorporar las
                        # bases generadas por la ejecución que no fue validada.
                        destination = OUTPUT/f'descarga_{task["id"]}.json'
                        pending = destination.with_suffix('.writing')
                        pending.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                        os.replace(pending,destination)
                        if task['id'] == 'oficinas':
                            consultation = {'checkedAt': report.get('checkedAt', now()), 'status': 'error',
                                            'message': '; '.join(report.get('errors') or ['No se pudo verificar la publicación SBS.'])[:800],
                                            'latestPeriod': self.source_results[task['id']].get('latestPeriod'),
                                            'preservedPreviousBase': (PROJECT/BACKUP['oficinas'][0]).is_file()}
                            target = PROJECT/'Scraper/Oficinas/output/consulta_oficinas.json'
                            target.parent.mkdir(parents=True, exist_ok=True)
                            partial = target.with_suffix('.writing')
                            with DATA_LOCK:
                                partial.write_text(json.dumps(consultation,ensure_ascii=False,indent=2),encoding='utf-8')
                                partial.replace(target)
                    self._log(f'Error en {task["label"]}: {exc}')
                self._save()
            self._check_stop()
            with self.lock:
                fails = sum(task['status'] in ('error','parcial') for task in self.tasks)
                correct = sum(task['status'] in ('correcto','parcial') for task in self.tasks)
                self.result = 'parcial' if fails and correct else 'error' if fails else 'completo'
                self.ended = now()
            import motor
            with motor.LOCK:
                changed = motor.source_delta(self._before_observed or {}, motor.source_observations())
                self.summary = {'updated':len(changed),
                                'models':sorted({d['model'] for d in changed}),
                                'details':changed[:120], 'truncated':len(changed)>120,
                                'success':[t['label'] for t in self.tasks if t['status']=='correcto'],
                                'failed':[{'name':t['label'],'message':t['detail']} for t in self.tasks if t['status'] in ('error','parcial')],
                                'note': ('Consulta de oficinas finalizada; esta fuente no requiere recalcular modelos financieros.'
                                         if self.selected == ['oficinas'] else
                                         'Fuentes descargadas. Las proyecciones no se modifican hasta pulsar Recalcular modelos.')}
            self._log(f'Finalizado · {correct}/{len(self.selected)} fuentes correctas; {len(changed)} observaciones nuevas o modificadas')
        except Detenido:
            with self.lock:
                self.result = 'detenido'
                self.ended = now()
            self._log('Actualización detenida. Puedes reanudar las fuentes pendientes.')
        except Exception as exc:
            with self.lock:
                self.result = 'error'
                self.ended = now()
            self._log(f'Error general: {exc}')
            traceback.print_exc()
        finally:
            with self.lock:
                self.running = False
                self.stopping = False
                self._process = None
            try:
                self._save()
            finally:
                _release_operation()


MANAGER = Actualizador()
