'use strict';
const S={data:null,changes:{},laboratorioHorizon:2030,laboratorioYear:2030,scenarios:[],scenarioId:'',busy:false,mapSelected:'16',mapScope:'chain',mapZoom:null,view:'chart',frequency:'annual',modelMeasure:'level',spec:false,coefficient:0,labModel:'16',updateId:'01',entries:[],preview:null,search:'',recent:JSON.parse(localStorage.getItem('iaspe-recent')||'[]')};
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(n,d=2)=>n==null||!Number.isFinite(+n)?'—':new Intl.NumberFormat('es-PE',{minimumFractionDigits:d,maximumFractionDigits:d}).format(+n);
const compact=n=>Math.abs(n)>=1e6?fmt(n/1e6,1)+' M':Math.abs(n)>=1e3?fmt(n/1e3,1)+' mil':fmt(n,Math.abs(n)<20?1:0);
const model=id=>S.data?.models.find(m=>m.id===id)||window.IASPEExecutive?.accountModel?.(window.IASPEApp,id,false)||null;
const baseModel=id=>S.data?.baseline.find(m=>m.id===id)||window.IASPEExecutive?.accountModel?.(window.IASPEApp,id,true)||null;
const last=(m,year=2030)=>(m?.annual||[]).find(r=>r.year===year)?.value;
// En la lista se muestra el tipo de proyección; la especificación conserva el detalle econométrico.
const modelMethodHint=m=>{
 const label=String(m?.method||m?.role||'').toLowerCase();
 if(m?.status==='needs_input')return 'Este modelo conserva la proyección original mientras se verifica su recálculo automático.';
 if(label.includes('consolidaci'))return 'Se calcula con los resultados de los componentes disponibles.';
 if(label.includes('interanual')&&label.includes('proporcional'))return 'Cierre 2026 con variación interanual reciente; proyección proporcional a los depósitos de ahorro y plazo.';
 if(label.includes('pronóstico original')||label.includes('pronostico original'))return 'Proyección del archivo base; puede cambiar si recibe un ajuste validado de sus variables de origen.';
 if(label.includes('mco')||label.includes('regresi')||label.includes('econométr'))return 'Proyección econométrica con los parámetros calibrados en el modelo original. Consulta su ecuación en la ficha.';
 return 'Consulta la ficha del modelo para ver la metodología, variables y supuestos.';
};
const modelMethodLabel=m=>{
 const raw=String(m?.method||m?.role||'').toLowerCase();
 if(m?.status==='needs_input')return 'Pendiente de recalcular';
 if(raw.includes('recuperada'))return 'Serie histórica recuperada';
 if(raw.includes('dato del área'))return 'Dato del área';
 if(raw.includes('consolidaci'))return 'Calculado desde componentes';
 if(raw.includes('apertura calculada'))return 'Apertura calculada, sin regresión propia';
 if(raw.includes('interanual')&&raw.includes('proporcional'))return 'Regla histórica y proporcional';
 if(raw.includes('pronóstico original')||raw.includes('pronostico original'))return 'Pronóstico del archivo base';
 if(raw.includes('mco')||raw.includes('regresi')||raw.includes('econométr'))return 'Modelo econométrico';
 if(raw.includes('suma')||raw.includes('contable'))return 'Calculado desde cuentas contables';
 return m?.role||'Modelo de proyección';
};
window.IASPEMethodLabel=modelMethodLabel;
const ready=m=>!m?.status||['ready','ok','success'].includes(m.status);
const statusLabel=s=>({observed:'Observado',assumed:'Cierre supuesto',forecast:'Pronóstico'}[s]||s);
const rowValue=r=>r?.value??r?.observed??r?.assumed??r?.forecast;
const route=()=>decodeURIComponent(location.hash.slice(1)||'catalogo').replace(/^actualizar/,'datos');
const navigate=hash=>{location.hash=hash.startsWith('#')?hash:'#'+hash};
const toast=msg=>{let t=$('#toast');t.textContent=msg;t.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.hidden=true,4300)};
async function api(path,body){const r=await fetch(path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d.error||'No se pudo completar la operación.');return d}
async function calculate(changes=S.changes){const token=S.calcToken=(S.calcToken||0)+1;S.changes=structuredClone(changes);S.busy=true;updateStatus();try{const d=await api('/api/calculate',{changes:S.changes,horizon:route().startsWith('laboratorio')?S.laboratorioHorizon:2030});if(token!==S.calcToken)return;S.data=d;S.busy=false;render();if(d.warnings?.length)toast(d.warnings.join(' '))}catch(e){if(token!==S.calcToken)return;S.busy=false;updateStatus();toast(e.message)}}
function updateStatus(){const x=$('#engine-status');if(x)x.innerHTML=`<i class="status-dot ${S.busy?'busy':''}"></i>${S.busy?'Recalculando…':'Actualizado'}`}
function remember(id){S.recent=[id,...S.recent.filter(x=>x!==id)].slice(0,5);localStorage.setItem('iaspe-recent',JSON.stringify(S.recent))}
function scenarioName(){return S.scenarios.find(s=>s.id===S.scenarioId)?.name||(Object.keys(S.changes).length?'Cambios sin guardar':'Base')}
function heading(eyebrow,title,description,actions=''){return `<div class="page-heading"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1>${description?`<p>${description}</p>`:''}</div>${actions?`<div class="heading-actions">${actions}</div>`:''}</div>`}
/* Menús de acceso directo. Modelos y escenarios tienen funciones distintas. */
// Agrupación editorial. Las cuentas siguen enlazando a los modelos originales.
// Subfichas ya calculadas por el motor y fichas contables de la visión ejecutiva.
// No se incorporan estos elementos a los 111 modelos econométricos originales.
const IASPE_EXTRA_FICHAS={
 '08':['08_mn','08_me'],
 '09':['09_plazo','09_cts'],
 '10':['10_restringidos','10_otras'],
 '12':['ej_gastos_financieros','12_obligaciones','12_entidades','12_adeudos','12_otras'],
 '16':['ej_ingresos_financieros','16_creditos','16_rev','16_nrev','16_inversiones','16_disponible','16_interbancarios'],
 '17':['17_caja','17_bancos','17_canje','17_otros'],
 '18':['ej_ingresos_servicios','ej_gastos_servicios','ej_margen_operacional','18_diversos','18_otros_ing','18_gastos_div','18_otros_gastos','18_fsd'],
 '19':['ej_margen_operacional_neto','19_personal','19_terceros','19_directorio','19_impuestos'],
 '20':['20_consorcios','20_asociadas','20_tc','20_derivados','20_inversiones','20_otros'],
 '21':['21_venta','21_asociadas','21_otras'],
 '23':['ej_margen_financiero_neto'],
 '24':['ej_venta_cartera'],
 '29':['ej_resultado_antes_impuestos'],
 '45':['45_utilidad_aplicada','45_transferencias_reservas','45_dividendos'],
 '49':['49_rev','49_nrev','49_tc','49_rc','49_pe','49_compras','49_desembolsos','49_disposiciones_rc','49_part_rc','49_tasa_rev','49_tasa_nrev']
};
const extraFichas=id=>(IASPE_EXTRA_FICHAS[id]||[]).map(model).filter(Boolean);
const extraNavLinks=id=>extraFichas(id).map(m=>`<a href="#modelo/${escape(m.id)}">${escape(m.name)}</a>`).join('');
const extraCatalogueRows=(id,row)=>extraFichas(id).map(row).join('');
function financialNavigation(sections, models){
  let previousArea='';
  return sections.map(section=>{
    const found=section.ids.map(id=>models.find(m=>m.id===id)).filter(Boolean);
    if(!found.length)return '';
    const area=section.area&&section.area!==previousArea?`<div class="nav-model-area">${escape(section.area)}</div>`:'';
    if(section.area)previousArea=section.area;
    return `${area}<details class="nav-pnl-stage"><summary>${escape(section.name)} <small>${found.reduce((n,m)=>n+1+extraFichas(m.id).length,0)}</small></summary>${found.map(m=>`<a href="#modelo/${escape(m.id)}">${escape(m.name)}</a>${extraNavLinks(m.id)}`).join('')}</details>`;
  }).join('');
}
// Subgrupos visuales: solo reorganizan enlaces, sin alterar su identificación ni el motor.
const OPERATIVE_NAV_SECTIONS=[
  {name:'Tarjetas y actividad de mercado',ids:['01','02','03','04']},
  {name:'Tasas de interés del mercado',ids:['13','14','15']},
  {name:'Líneas de crédito Falabella',ids:['30']}
];
const COMPLEMENTARY_NAV_SECTIONS=[
  {name:'Amortizaciones por producto',ids:['49','49_rev','49_nrev','49_tc','49_rc','49_pe']},
  {name:'Compras y desembolsos',ids:['49_compras','49_desembolsos','49_disposiciones_rc']},
  {name:'Tasas y transmisión monetaria',ids:['49_part_rc','49_tasa_rev','49_tasa_nrev','transmision']}
];
function thematicNavigation(sections){
  return sections.map(section=>{
    const links=section.ids.map(id=>{
      if(id==='transmision')return '<a href="#modelo/transmision">Transmisión monetaria al costo del pasivo</a>';
      const m=model(id);
      return m?`<a href="#modelo/${escape(m.id)}">${escape(m.name)}</a>`:'';
    }).filter(Boolean);
    if(!links.length)return '';
    return `<details class="nav-pnl-stage nav-theme-stage"><summary>${escape(section.name)} <small>${links.length}</small></summary>${links.join('')}</details>`;
  }).join('');
}
function modelMenu(){
  const panels=window.IASPEPanels;
  const models=panels.orderedModels((S.data?.models||[]).filter(m=>/^\d{2}$/.test(m.id)&&!['47','48'].includes(m.id)));
  const categories=panels.scenarioCategories(models);
  const groupContent=group=>{
    if(group.id==='resultados')return financialNavigation(panels.RESULT_SECTIONS,models);
    if(group.id==='balance')return financialNavigation(panels.BALANCE_SECTIONS,models);
    if(group.id==='operativas')return thematicNavigation(OPERATIVE_NAV_SECTIONS);
    if(group.id==='complementarios')return thematicNavigation(COMPLEMENTARY_NAV_SECTIONS);
    const links=models.filter(m=>panels.modelCategory(m).id===group.id).map(m=>`<a href="#modelo/${escape(m.id)}">${escape(m.name)}</a>${extraNavLinks(m.id)}`).join('');
    return links+(group.id==='complementarios'?'<a href="#modelo/transmision">Transmisión monetaria al costo del pasivo</a>':'');
  };
  const mainGroups=categories.filter(g=>g.id!=='mercado').map(group=>{
    const content=groupContent(group);
    const count=models.filter(m=>panels.modelCategory(m).id===group.id).reduce((n,m)=>n+1+extraFichas(m.id).length,0)+(group.id==='complementarios'?1:0);
    return `<details class="nav-compact-group"><summary>${escape(group.name)}<small>${count}</small></summary><div class="nav-compact-links">${content}</div></details>`;
  }).join('');
  return `<div class="nav-flyout-top"><a href="#resumen">Visión ejecutiva</a><a href="#catalogo">Todos los modelos</a><a href="#mapa">Relaciones entre modelos</a></div>
    <div class="nav-model-compact">
      <a class="nav-compact-macros" href="#escenarios/16?editar=1">Variables macroeconómicas <small>Ver supuestos</small></a>
      ${mainGroups}
    </div>`;
}
function shell(){
  const r=route();
  const active=r.startsWith('normativa')?'normativa':r.startsWith('benchmark/')?'mercado':r.startsWith('laboratorio')?'laboratorio':r.startsWith('datos/proyecciones')?'macro':r.startsWith('monitor')||r.startsWith('datos/monitor')?'monitor':r.startsWith('escenarios')?'escenarios':r.startsWith('datos')?'data':'models';
  const activeId=r.startsWith('modelo/')?r.split('/')[1].split('?')[0]:S.labModel||'16';
  const scenarioHref='#escenarios/'+(/^\d{2}$/.test(activeId)?activeId:'16')+'?editar=1';
  return `<header class="topbar">
    <a class="brand" href="#catalogo" aria-label="Banco Falabella — Inicio del IASPE"><img src="assets/banco-falabella.svg" alt="Banco Falabella"></a>
    <nav class="main-nav" aria-label="Secciones de IASPE">
      <div class="nav-cluster nav-cluster-core" role="group" aria-label="Modelo IASPE">
        <span class="nav-cluster-caption" aria-hidden="true">MODELO</span>
        <div class="nav-cluster-links">
          <a class="topnav-link ${active==='monitor'?'active':''}" href="#monitor" ${active==='monitor'?'aria-current="page"':''}>Monitor</a>
          <div class="topnav-group topnav-group-models" data-topnav-menu>
            <a class="topnav-link ${active==='models'?'active':''}" href="#catalogo" ${active==='models'?'aria-current="page"':''}>Modelos</a>
            <button type="button" class="topnav-chevron" aria-label="Ver secciones de Modelos" aria-expanded="false" aria-controls="modelos-desplegable">⌄</button>
            <div class="topnav-flyout topnav-model-flyout" id="modelos-desplegable">${modelMenu()}</div>
          </div>
          <a class="topnav-link ${active==='data'?'active':''}" href="#datos" ${active==='data'?'aria-current="page"':''}>Datos observados</a>
          <a class="topnav-link ${active==='escenarios'?'active':''}" href="${scenarioHref}" ${active==='escenarios'?'aria-current="page"':''}>Escenarios</a>
        </div>
      </div>
      <div class="nav-cluster nav-cluster-context" role="group" aria-label="Fuentes de referencia">
        <span class="nav-cluster-caption" aria-hidden="true">REFERENCIAS</span>
        <div class="nav-cluster-links">
          <a class="topnav-link ${active==='macro'?'active':''}" href="#datos/proyecciones" ${active==='macro'?'aria-current="page"':''}>Proyecciones externas</a>
          <a class="topnav-link ${active==='normativa'?'active':''}" href="#normativa" ${active==='normativa'?'aria-current="page"':''}>Normativa SBS</a>
        </div>
      </div>
      <div class="nav-cluster nav-cluster-analysis" role="group" aria-label="Análisis comparativo">
        <span class="nav-cluster-caption" aria-hidden="true">ANÁLISIS</span>
        <div class="nav-cluster-links">
          <a class="topnav-link ${active==='laboratorio'?'active':''}" href="#laboratorio" ${active==='laboratorio'?'aria-current="page"':''}>Laboratorio</a>
          <div class="topnav-group topnav-group-market" data-topnav-menu>
            <a class="topnav-link ${active==='mercado'?'active':''}" href="#benchmark/eeff" ${active==='mercado'?'aria-current="page"':''}>Mercado</a>
            <button type="button" class="topnav-chevron" aria-label="Ver secciones de Mercado" aria-expanded="false" aria-controls="mercado-desplegable">⌄</button>
            <div class="topnav-flyout topnav-market-flyout" id="mercado-desplegable">
              <div class="nav-market-intro">Análisis comercial</div>
              <a href="#benchmark/cartera" ${r.startsWith('benchmark/cartera')?'aria-current="page"':''}><b>Cartera de consumo</b><span>Colocaciones y participación</span></a>
              <a href="#benchmark/oficinas" ${r.startsWith('benchmark/oficinas')?'aria-current="page"':''}><b>Oficinas</b><span>Cobertura geográfica</span></a>
              <div class="nav-market-intro">Comparación financiera</div>
              <a href="#benchmark/eeff" ${r.startsWith('benchmark/eeff')?'aria-current="page"':''}><b>Estados financieros</b><span>Comparación por entidad</span></a>
              <a href="#benchmark/ratios" ${r.startsWith('benchmark/ratios')?'aria-current="page"':''}><b>Indicadores financieros</b><span>Rentabilidad, solvencia y riesgo</span></a>
              <a href="#benchmark/personal" ${r.startsWith('benchmark/personal')?'aria-current="page"':''}><b>Personal</b><span>Estructura y evolución</span></a>
            </div>
          </div>
        </div>
      </div>
    </nav>
    <div class="top-tools">
      <div class="source-alert-area" id="source-alert-area">
        <button class="source-alert-trigger" type="button" id="source-alert-trigger" aria-label="Notificaciones de fuentes SBS y BCRP" title="Notificaciones de fuentes" aria-haspopup="dialog" aria-expanded="false" aria-controls="source-alert-panel">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg>
          <span class="source-alert-badge" id="source-alert-badge" hidden></span>
          <span class="source-alert-activity" id="source-alert-activity" hidden></span>
        </button>
        <div class="source-alert-panel" id="source-alert-panel" role="dialog" aria-label="Notificaciones de publicaciones" hidden></div>
      </div>
      <button class="search-button" id="search-open" aria-label="Buscar un modelo"><span>Buscar modelo</span><kbd>Ctrl K</kbd></button>
      <span class="scenario-base-label" aria-label="Escenario principal Base IASPE">Base</span>
    </div>
  </header><main class="shell" id="workspace"></main><div id="portal"></div>`;
}
function render(){
  if(!S.data)return;
  let r=route();
  if(r.startsWith('modelo/')){
    const [path,query='']=r.split('?');
    if(new URLSearchParams(query).get('supuestos')==='1'){
      const requested=path.split('/')[1];
      r='escenarios/'+(/^\d{2}$/.test(requested)?requested:'10')+'?editar=1';
      history.replaceState(null,'','#'+r);
    }
  }
  if(r.startsWith('escenarios')){
    const [path,query='']=r.split('?'),requested=path.split('/')[1];
    const fallback=/^\d{2}$/.test(S.labModel)&&model(S.labModel)?S.labModel:'16';
    S.labModel=/^\d{2}$/.test(requested)&&model(requested)?requested:requested?.startsWith('10_')?'10':fallback;
    S.labAssumptionsOpen=new URLSearchParams(query).get('editar')==='1';
    const canonical='escenarios/'+S.labModel+(S.labAssumptionsOpen?'?editar=1':'');
    if(r!==canonical){history.replaceState(null,'','#'+canonical);r=canonical}
  }
  $('#app').innerHTML=shell();
  if(r.startsWith('modelo/48')){navigate('benchmark/cartera');return;}
  if(r.startsWith('modelo/transmision'))window.IASPEComplementarios.renderTransmission(App);
  else if(r.startsWith('modelo/'))renderModel(r.split('/')[1].split('?')[0]);
  else if(r.startsWith('catalogo'))renderCatalogue();
  else if(r.startsWith('resumen'))window.IASPEExecutive.render(App);
  else if(r.startsWith('control-sbs'))window.IASPEControlSBS.render(App);
  else if(r.startsWith('normativa'))window.IASPENormativa.render(App);
  else if(r.startsWith('escenarios')){$('#workspace').innerHTML=window.IASPEPanels.labHTML(App);window.IASPEPanels.bindLab(App)}
  else if(r.startsWith('laboratorio')){$('#workspace').innerHTML=window.IASPELaboratorio.html(App);window.IASPELaboratorio.bind(App)}
  else if(r.startsWith('benchmark/participacion')||/^benchmark\/consumo(?:[/?]|$)/.test(r))navigate('benchmark/cartera');
  else if(/^benchmark\/depositos(?:[/?]|$)/.test(r))navigate('benchmark/cartera');
  else if(r.startsWith('benchmark/ratios'))window.IASPERatiosSBS.render(App);
  else if(r.startsWith('benchmark/personal'))window.IASPEPersonalSBS.render(App);
  else if(r.startsWith('benchmark/oficinas'))window.IASPEOficinasSBS.render(App);
  else if(r.startsWith('benchmark/eeff'))window.IASPEBenchmarkEEFF.render(App);
  else if(/^benchmark\/(cartera|tarjetas|prestamos)(?:[/?]|$)/.test(r))window.IASPECarteraConsumo.render(App);
  else if(r.startsWith('benchmark'))navigate('benchmark/cartera');
  else if(r.startsWith('datos/proyecciones'))window.IASPEMacroExternas.render();
  else if(r.startsWith('datos/monitor'))navigate('monitor');
  else if(r.startsWith('monitor'))window.IASPEMonitorActualizacion.render(App);
  else if(r.startsWith('datos')){$('#workspace').innerHTML=window.IASPEPanels.updateHTML(App);window.IASPEPanels.bindUpdate(App)}
  else renderMap(r.includes('impacto=1'));
  bindShell();bindCharts();renderMath();window.IASPEMonitor?.paint();window.IASPENormativa?.paintBell?.();
}
function bindShell(){
  $$('[data-topnav-menu]').forEach(menu=>{
    const toggle=menu.querySelector('.topnav-chevron');
    toggle.onclick=e=>{e.stopPropagation();const open=!menu.classList.contains('is-open');$$('[data-topnav-menu]').forEach(other=>{other.classList.remove('is-open');other.querySelector('.topnav-chevron').setAttribute('aria-expanded','false')});menu.classList.toggle('is-open',open);toggle.setAttribute('aria-expanded',String(open));};
    menu.addEventListener('keydown',e=>{if(e.key==='Escape'){menu.classList.remove('is-open');toggle.setAttribute('aria-expanded','false');toggle.focus()}});
  });
  $('#search-open').onclick=openSearch;$$('[data-nav]').forEach(x=>x.onclick=()=>navigate(x.dataset.nav));$$('[data-copy]').forEach(x=>x.onclick=()=>copyModel(x.dataset.copy));$$('[data-export]').forEach(x=>x.onclick=()=>exportModel(x.dataset.export));$$('[data-transmission]').forEach(x=>x.onclick=()=>{S.mapSelected=x.dataset.transmission;S.mapAnchor=x.dataset.transmission;S.mapScope='chain';navigate('mapa')})}
function renderMath(){$$('[data-tex]').forEach(el=>{try{window.katex.render(el.dataset.tex,el,{throwOnError:false,displayMode:true,trust:false})}catch(_){el.textContent=el.dataset.tex}})}
function renderMap(impact=false){window.IASPEMap.render(App,impact)}
function catalogueItems(group, models){
  const panels=window.IASPEPanels;
  const all=models.filter(m=>panels.modelCategory(m).id===group.id);
  const row=m=>`<a href="#modelo/${escape(m.id)}" class="catalogue-row" data-catalogue-name="${escape(m.name.toLowerCase())}"><span class="model-name">${escape(m.name)}</span><span class="model-method" title="${escape(modelMethodHint(m))}">${escape(modelMethodLabel(m))}</span><span class="model-value num">${ready(m)?fmt(last(m),m.unit.toLowerCase().includes('tarjetas')?0:2):'Pendiente'}</span><span class="model-unit">${escape(m.unit)}</span><span class="arrow">↗</span></a>`;
  const sections=group.id==='balance'?panels.BALANCE_SECTIONS:group.id==='resultados'?panels.RESULT_SECTIONS:null;
  if(!sections)return all.map(m=>row(m)+extraCatalogueRows(m.id,row)).join('')+(group.id==='complementarios'?'<a href="#modelo/transmision" class="catalogue-row" data-catalogue-name="transmisión monetaria al costo del pasivo"><span class="model-name">Transmisión monetaria al costo del pasivo</span><span class="model-method">Regresión mensual · rezagos distribuidos</span><span class="model-value num">DL(5)</span><span class="model-unit">Mensual</span><span class="arrow">↗</span></a>':'');
  let previousArea='';
  return sections.map(section=>{
    const found=section.ids.map(id=>all.find(m=>m.id===id)).filter(Boolean);
    if(!found.length)return '';
    const area=section.area&&section.area!==previousArea?`<div class="catalogue-area">${escape(section.area)}</div>`:'';
    if(section.area)previousArea=section.area;
    return `${area}<div class="catalogue-stage">${escape(section.name)}</div>${found.map(m=>row(m)+extraCatalogueRows(m.id,row)).join('')}`;
  }).join('');
}
function renderCatalogue(){
  const models=window.IASPEPanels.orderedModels(S.data.models.filter(m=>/^\d{2}$/.test(m.id)&&!['47','48'].includes(m.id)));
  const groups=window.IASPEPanels.scenarioCategories(models);
  S.catalogueCategory ||= 'all';
  if(!groups.some(g=>g.id===S.catalogueCategory))S.catalogueCategory='all';
  const tabs=[{id:'all',name:'Todos'},...groups];
  const selector=`<nav class="catalogue-filters" aria-label="Filtrar por estado financiero">${tabs.map(g=>`<button class="catalogue-filter-btn ${S.catalogueCategory===g.id?'is-active':''}" type="button" data-catalogue-group="${escape(g.id)}" aria-pressed="${S.catalogueCategory===g.id?'true':'false'}">${escape(g.name)}</button>`).join('')}</nav>`;
  $('#workspace').innerHTML=heading('Modelos','Modelos y resultados','',`<button data-nav="mapa">Abrir mapa de relaciones</button>`)
    +`<a class="executive-catalogue-entry" href="#resumen"><span><b>Visión ejecutiva de resultados</b><small>Estado de Resultados · Estado de Situación Financiera · Ratios SBS · Base IASPE</small></span><span class="executive-entry-arrow">Abrir resumen ↗</span></a>`
    +selector+`<div class="toolbar"><input id="catalogue-search" aria-label="Filtrar modelos" placeholder="Buscar un resultado…" style="width:min(100%,340px)"><span class="muted" style="font-size:11px">Cierres de 2030</span></div>`
    +`<div class="catalogue">${groups.map(group=>`<section class="catalogue-panel" data-catalogue-section="${escape(group.id)}"><div class="catalogue-group">${escape(group.name)}</div>${catalogueItems(group,models)}</section>`).join('')}</div>`;
  function refresh(){
    const query=$('#catalogue-search').value.trim().toLocaleLowerCase('es-PE');
    $$('[data-catalogue-section]').forEach(section=>{
      const categoryAllowed=S.catalogueCategory==='all'||section.dataset.catalogueSection===S.catalogueCategory;
      let visible=0;
      section.querySelectorAll('[data-catalogue-name]').forEach(row=>{
        const show=categoryAllowed&&row.dataset.catalogueName.includes(query);
        row.hidden=!show;
        if(show)visible++;
      });
      section.hidden=!categoryAllowed||(query.length>0&&visible===0);
      section.querySelectorAll('.catalogue-stage, .catalogue-area').forEach(stage=>{stage.hidden=query.length>0;});
    });
  }
  $$('[data-catalogue-group]').forEach(b=>b.onclick=()=>{
    S.catalogueCategory=b.dataset.catalogueGroup;
    $$('[data-catalogue-group]').forEach(c=>{
      const selected=c===b;c.classList.toggle('is-active',selected);c.setAttribute('aria-pressed',String(selected));
    });
    refresh();
  });
  $('#catalogue-search').oninput=refresh;
  refresh();
}

function chartHTML(m,opts={}){const frequency=opts.frequency||S.frequency,raw=m?.[frequency]||[],base=(opts.baseline||baseModel(m?.id))?.[frequency]||[],recent=raw.filter(r=>(r.year||+r.date.slice(0,4))>=2015),points=recent.length?recent:raw;const periods=[...new Set([...points,...base.filter(r=>(r.year||+r.date.slice(0,4))>=2015)].map(r=>frequency==='annual'?String(r.year):r.date.slice(0,7)))].sort();if(periods.length<2)return '<div class="empty">No hay suficientes observaciones para esta frecuencia.</div>';const modified=Object.keys(S.changes).length>0;const changed=opts.compare===true||(opts.compare!==false&&modified);const values=[...points.map(rowValue),...base.filter(r=>(r.year||+r.date.slice(0,4))>=2015).map(rowValue)].filter(x=>x!=null&&Number.isFinite(+x));let min=Math.min(...values),max=Math.max(...values),range=max-min||max*.1||1;min=min-range*.2;max+=range*.17;const W=1200,H=opts.height?Math.min(opts.height,Math.max(300,(window.innerHeight-365)*1200/Math.max(650,window.innerWidth-104))):365,L=64,R=40,T=28,B=40,x=p=>L+periods.indexOf(p)*(W-L-R)/(periods.length-1),y=v=>T+(max-v)*(H-T-B)/(max-min);const key=r=>frequency==='annual'?String(r.year):r.date.slice(0,7),pmap=new Map(points.map(r=>[key(r),r]));const pathFor=(rows,state)=>{let s='',on=false;rows.forEach((r,i)=>{if(r.status===state&&rowValue(r)!=null){if(!on&&i>0&&rowValue(rows[i-1])!=null)s+=`M${x(key(rows[i-1]))} ${y(rowValue(rows[i-1]))}`;s+=`${on?'L':s?'L':'M'}${x(key(r))} ${y(rowValue(r))}`;on=true}else on=false});return s};const axes=Array.from({length:5},(_,i)=>{const v=min+(max-min)*i/4;return `<line class="gridline" x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}"/><text x="${L-12}" y="${y(v)+3}" text-anchor="end">${escape(compact(v))}</text>`}).join('');const tickPeriods=periods.filter((p,i)=>i===0||i===periods.length-1||(frequency==='annual'?i%2===0:p.endsWith('-12')&&+p.slice(0,4)%2===0));const assumed=points.find(r=>r.status==='assumed'),forecast=points.find(r=>r.status==='forecast'),forecastX=forecast?x(key(forecast)):null;const bpath=base.filter(r=>(r.year||+r.date.slice(0,4))>=2015&&r.value!=null&&periods.includes(key(r))).map((r,i)=>`${i?'L':'M'}${x(key(r))} ${y(r.value)}`).join('');const plotId=`plot-${m.id}-${frequency}-${Math.random().toString(36).slice(2,7)}`;return `<div class="chart-legend"><span><i></i>Observado</span>${points.some(r=>r.status==='assumed')?'<span><i class="assumed"></i>Cierre supuesto</span>':''}<span><i class="forecast"></i>${modified?'Con cambios':'Pronóstico'}</span>${changed?`<span><i class="base"></i>${escape(opts.baseLabel||'Antes del cambio')}</span>`:''}</div><div class="plot-wrap" id="${plotId}" data-chart-model="${m.id}" data-compare="${changed}" data-frequency="${frequency}" data-baseline="${escape(JSON.stringify(base))}" data-base-label="${escape(opts.baseLabel||'Antes del cambio')}" data-periods="${escape(JSON.stringify(periods))}" data-points="${escape(JSON.stringify(points))}"><svg class="financial-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución de ${escape(m.name)}"><rect x="${L}" y="${T}" width="${W-L-R}" height="${H-T-B}" fill="#fff"/>${forecastX?`<rect x="${forecastX}" y="${T}" width="${W-R-forecastX}" height="${H-T-B}" fill="#f5f8ef"/><text x="${forecastX+10}" y="${T+14}" style="font-size:8px;letter-spacing:1.4px">PRONÓSTICO</text>`:''}${axes}${tickPeriods.map(p=>`<text x="${x(p)}" y="${H-14}" text-anchor="middle">${frequency==='annual'?p:p.slice(0,4)}</text>`).join('')}${changed?`<path class="baseline" d="${bpath}"/>`:''}<path class="observed" d="${pathFor(points,'observed')}"/><path class="assumed" d="${pathFor(points,'assumed')}"/><path class="forecast" d="${pathFor(points,'forecast')}"/><line class="plot-cursor" x1="0" x2="0" y1="${T}" y2="${H-B}" style="display:none"/><rect class="chart-hit" x="${L}" y="${T}" width="${W-L-R}" height="${H-T-B}" fill="transparent"/></svg><div class="plot-tooltip" hidden></div></div><div class="plot-footer"><span>${escape(m.unit)}</span><span>${periods[0]} — ${periods.at(-1)}</span></div>`}
function bindCharts(){$$('[data-chart-model]').forEach(w=>{const svg=w.querySelector('svg'),tooltip=w.querySelector('.plot-tooltip'),cursor=w.querySelector('.plot-cursor'),periods=JSON.parse(w.dataset.periods),points=JSON.parse(w.dataset.points),frequency=w.dataset.frequency,base=JSON.parse(w.dataset.baseline||'[]');svg.onpointermove=e=>{const rect=svg.getBoundingClientRect(),pos=(e.clientX-rect.left)/rect.width*1200,index=Math.max(0,Math.min(periods.length-1,Math.round((pos-64)/(1200-104)*(periods.length-1)))),p=periods[index],r=points.find(r=>(frequency==='annual'?String(r.year):r.date.slice(0,7))===p),b=base.find(r=>(frequency==='annual'?String(r.year):r.date.slice(0,7))===p);cursor.setAttribute('x1',64+index*(1200-104)/(periods.length-1));cursor.setAttribute('x2',cursor.getAttribute('x1'));cursor.style.display='';tooltip.hidden=false;tooltip.style.left=Math.max(5,Math.min(rect.width-220,e.clientX-rect.left+15))+'px';tooltip.innerHTML=`<strong>${p}</strong>${r?`<div><span>${statusLabel(r.status)}</span><b>${fmt(r.value,6)}</b></div>`:'<div>Requiere información</div>'}${w.dataset.compare==='true'&&b&&r&&Math.abs(b.value-r.value)>1e-8?`<div><span>${escape(w.dataset.baseLabel||'Antes del cambio')}</span><b>${fmt(b.value,6)}</b></div><div><span>Diferencia</span><b>${fmt(r.value-b.value,6)}</b></div>`:''}`};svg.onpointerleave=()=>{tooltip.hidden=true;cursor.style.display='none'}})}
function modelGrowthIsRate(m){return /(?:%|\bTEA\b|\bTNA\b|tasa|puntos porcentuales|\bpp\b)/i.test(String(m?.unit||''));}
function modelGrowthRows(m){
  const source=m?.annual||[], rate=modelGrowthIsRate(m),lookup=new Map(source.map(r=>[+r.year,r]));
  return source.map(row=>{
    const before=lookup.get(+row.year-1),v=row.value,old=before?.value;
    const growth=typeof v==='number'&&Number.isFinite(v)&&typeof old==='number'&&Number.isFinite(old)
      ?rate?v-old:old>0?100*(v/old-1):null:null;
    return {...row,value:growth,observed:row.status==='observed'?growth:null,assumed:row.status==='assumed'?growth:null,forecast:row.status==='forecast'?growth:null};
  });
}
function modelGrowthHTML(m,options){
  if(modelGrowthRows(m).filter(r=>typeof r.value==='number'&&Number.isFinite(r.value)).length<2)return '<div class="empty">No hay suficientes períodos comparables para calcular variaciones interanuales.</div>';
  const unit=modelGrowthIsRate(m)?'pp':'%';
  const transformed={...m,name:m.name+' · variación interanual',unit,annual:modelGrowthRows(m)};
  const original=options.baseline||baseModel(m.id);
  const baseline=original?{...original,annual:modelGrowthRows(original)}:null;
  return chartHTML(transformed,{...options,frequency:'annual',baseline});
}
function modelGrowthTable(m){
  const rows=modelGrowthRows(m),unit=modelGrowthIsRate(m)?'pp':'%';
  return `<div class="table-scroll panel"><table class="data-table"><thead><tr><th>Año</th><th>Variación interanual (${unit})</th><th>Condición</th></tr></thead><tbody>${[...rows].sort((a,b)=>b.year-a.year).map(row=>`<tr><td>${row.year}</td><td>${fmt(row.value,2)}</td><td>${escape(statusLabel(row.status))}</td></tr>`).join('')}</tbody></table></div>`;
}
function modelTable(m,opts={}){
  const rows=m[S.frequency]||[],base=(opts.baseline||baseModel(m.id))?.[S.frequency]||[],compare=!!opts.compare;
  const key=r=>S.frequency==='annual'?r.year:r.date,lookup=new Map(base.map(r=>[key(r),r]));
  return `<div class="table-scroll panel"><table class="data-table"><thead><tr><th>Período</th><th>Observado</th><th>Cierre supuesto</th><th>Pronóstico</th>${compare?`<th>${escape(opts.baseLabel||'Antes del cambio')}</th><th>Diferencia</th>`:''}</tr></thead><tbody>${[...rows].sort((a,b)=>String(key(b)).localeCompare(String(key(a)))).map(r=>{const old=lookup.get(key(r));return `<tr class="${r.status}"><td>${S.frequency==='annual'?r.year:r.date.slice(0,7)}</td><td>${fmt(r.observed,4)}</td><td>${fmt(r.assumed,4)}</td><td>${fmt(r.forecast,4)}</td>${compare?`<td>${fmt(old?.value,4)}</td><td>${old?.value!=null&&r.value!=null?fmt(r.value-old.value,4):'—'}</td>`:''}</tr>`}).join('')}</tbody></table></div>`;
}
function resultHeadingHTML(m,context='Explorar',comparison=null){
  const category=window.IASPEPanels.modelCategory(m),observed=m.annual.filter(r=>r.status==='observed');
  const assumed=m.annual.filter(r=>r.status==='assumed');
  const forecast=m.annual.filter(r=>r.status==='forecast');
  const yearsText=rs=>{const years=rs.map(r=>Number(r.year)).filter(Number.isFinite).sort((a,b)=>a-b);return years.length?years[0]===years.at(-1)?String(years[0]):`${years[0]}–${years.at(-1)}`:''};
  const periodSummary=[[observed,'observado'],[assumed,'cierre supuesto'],[forecast,'pronóstico']].filter(([rows])=>rows.length).map(([rows,label])=>`<span>${escape(yearsText(rows)+' '+label)}</span>`).join('');
  const year=2030,value=last(m,year),old=comparison?last(comparison,year):null;
  const benchmark={'05':'tarjetas','06':'prestamos','07':'cartera'}[m.id];
  return `<div class="page-heading model-heading result-heading"><div><div class="eyebrow">${escape(context)} / ${escape(category.name)}</div><h1>${escape(m.name)}</h1><div class="model-meta"><span>${escape(m.unit)}</span>${periodSummary}<span class="tag ${ready(m)?'green':'warning'}">${ready(m)?escape(scenarioName()):'Requiere información'}</span>${m.reestimated?'<span class="tag">Parámetros reestimados</span>':''}${benchmark?`<a class="result-market-link" href="#benchmark/${benchmark}">Frente al mercado ↗</a>`:''}</div></div><div class="closing-value"><span>Cierre ${year}</span><strong>${fmt(value,m.unit.toLowerCase().includes('tarjetas')?0:2)}</strong><small>${value!=null&&old!=null&&Math.abs(value-old)>1e-8?`Antes: ${fmt(old,2)}`:escape(m.unit)}</small></div></div>`;
}
function openModelAssumptions(id){
  S.labModel=model(id)?.scenarioModel||(['16_rev','16_nrev','16_creditos'].includes(id)?'16':(/^\d{2}$/.test(id)?id:'10'));
  S.labAssumptionsOpen=true;
  document.body.classList.remove('presenting');
  navigate('escenarios/'+S.labModel+'?editar=1');
}
// Indicador analitico de M16: no forma parte de las cuentas contables.
// Se calcula usando los resultados actuales del motor, incluso bajo escenarios.
function implicitCreditYieldHTML(){
  const credits=model('16_creditos'),portfolio=model('07');
  if(!credits||!portfolio)return '';
  const years=[2025,2026,2027,2028,2029,2030];
  const cells=years.map(year=>{
    const income=last(credits,year),initial=last(portfolio,year-1),final=last(portfolio,year);
    const average=initial!=null&&final!=null?(initial+final)/2:null;
    return income!=null&&average>0?fmt(100*income/average,2)+'%':'—';
  });
  return `<div class="model-bottom"><div class="fold"><div class="section-label">Rendimiento implícito de créditos (%)</div>
    <div class="table-scroll panel"><table class="data-table"><thead><tr><th>Indicador</th>${years.map(y=>`<th>${y}</th>`).join('')}</tr></thead>
    <tbody><tr><td>Tasa implícita</td>${cells.map(value=>`<td>${value}</td>`).join('')}</tr></tbody></table></div></div></div>`;
}
function renderModel(id){
  const m=model(id);if(!m){if(id.startsWith('ej_')){window.IASPEExecutive?.ensureSource?.().then(()=>render()).catch(e=>{$('#workspace').innerHTML=`<div class="empty">${escape(e.message)}</div>`});return;}navigate('catalogo');return}
  remember(id);if(!m.monthly.length)S.frequency='annual';
  const compare=Object.keys(S.changes).length>0,baseline=baseModel(id),baseLabel='Antes del cambio';
  const options={baseline,compare,baseLabel};
  const growth=S.frequency==='annual'&&S.modelMeasure==='growth';
  const edges=S.data.graph.edges,parents=edges.filter(e=>e.target===id),children=edges.filter(e=>e.source===id);
  const issues=m.issues||m.warnings||m.limitations||[];
  const related=[...new Map([...parents.map(e=>[e.source,S.data.graph.nodes.find(n=>n.id===e.source)]),...children.map(e=>[e.target,S.data.graph.nodes.find(n=>n.id===e.target)])]).values()].filter(Boolean);
  $('#workspace').innerHTML=`${resultHeadingHTML(m,'Modelos',compare?baseline:null)}
    ${!ready(m)?`<div class="notice" style="margin-bottom:18px">${escape(Array.isArray(issues)?issues.join(' '):issues||'Se necesita una senda compatible para completar el cálculo.')} <a class="text-link" id="model-review-inputs" href="#escenarios/${id}?editar=1">Editar supuestos macro ↗</a></div>`:''}
    ${m.scenarioSupport===false?'<p class="model-readonly-note">Pronóstico original del Excel. Este resultado aún no tiene sensibilidad a escenarios.</p>':''}
    <div class="toolbar model-toolbar">
      <div class="toolbar-group model-view-controls"><div class="segmented">${[['chart','Gráfico'],['table','Tabla'],['split','Combinada']].map(([v,t])=>`<button data-view="${v}" class="${S.view===v?'active':''}">${t}</button>`).join('')}</div>${S.frequency==='annual'?`<div class="segmented model-growth-switch"><button data-model-measure="level" class="${S.modelMeasure==='level'?'active':''}">Nivel</button><button data-model-measure="growth" class="${S.modelMeasure==='growth'?'active':''}">Variación anual</button></div>`:''}${m.monthly.length?`<select id="model-frequency" aria-label="Frecuencia de los resultados"><option value="annual" ${S.frequency==='annual'?'selected':''}>Anual</option><option value="monthly" ${S.frequency==='monthly'?'selected':''}>Mensual</option></select>`:''}</div>
      <div class="toolbar-group model-actions"><button id="model-equation" aria-haspopup="dialog">${m.estimatedEquationTex||m.equationTex||m.financialIdentityTex?'Ver ecuación':'Ficha técnica'}</button>${m.scenarioSupport===false?'':`<button class="primary" id="model-macro">Probar escenario</button>`}<details class="model-export"><summary>Exportar ▾</summary><div class="model-export-options"><button data-export="${id}">Excel</button><button id="download-chart">Gráfico SVG</button><button data-copy="${id}">Copiar datos</button></div></details><button id="presentation">${document.body.classList.contains('presenting')?'Volver':'Presentar'}</button></div>
    </div>
    <div class="model-workspace ${S.view==='split'?'split':''}">${S.view!=='table'?`<section class="model-chart-panel">${growth?modelGrowthHTML(m,options):chartHTML(m,options)}</section>`:''}${S.view!=='chart'?(growth?modelGrowthTable(m):modelTable(m,options)):''}</div>
    ${id==='16'||id==='16_creditos'?implicitCreditYieldHTML():''}
    ${window.IASPEIngresosApertura?.detalle(App,id)||''}
    ${window.IASPEExecutive?.accountDetail?.(App,id)||''}
    ${window.IASPEComplementarios?.amortizationDetail?.(App,id)||''}
    ${id==='49'?window.IASPEComplementarios.amortizationTable(App):''}
    <div class="model-bottom"><div class="fold"><div class="section-label">Relaciones del modelo</div><div class="related-links">${related.map(n=>`<a href="${n.kind==='model'?'#modelo/'+n.id:'#escenarios/'+id+'?editar=1'}">${escape(n.name)} ↗</a>`).join('')||'<span class="muted" style="font-size:12px">Modelo independiente de otras proyecciones internas.</span>'}</div><button class="ghost small" style="margin-top:10px;padding-left:0" data-transmission="${id}">Ver relaciones</button></div></div>`;
  $$('[data-view]').forEach(b=>b.onclick=()=>{S.view=b.dataset.view;render()});
  $$('[data-model-measure]').forEach(b=>b.onclick=()=>{S.modelMeasure=b.dataset.modelMeasure;render()});
  if($('#model-frequency'))$('#model-frequency').onchange=e=>{S.frequency=e.target.value;render()};
  $('#model-equation').onclick=()=>window.IASPESpec.open(App,id);
  if($('#model-macro'))$('#model-macro').onclick=()=>openModelAssumptions(id);
  $('#model-review-inputs')?.addEventListener('click',e=>{e.preventDefault();openModelAssumptions(id)});
  const exportMenu=$('.model-export');
  exportMenu.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{exportMenu.open=false}));
  exportMenu.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();exportMenu.open=false;exportMenu.querySelector('summary').focus()}});
  $('#presentation').onclick=()=>{document.body.classList.toggle('presenting');render()};
  $('#download-chart').onclick=()=>downloadChart(id);
}
async function copyModel(id,frequency=S.frequency){const m=model(id),rows=m[frequency]||[];const lines=[['Período','Observado','Cierre supuesto','Pronóstico'],...rows.map(r=>[frequency==='annual'?r.year:r.date.slice(0,7),r.observed??'',r.assumed??'',r.forecast??''])].map(r=>r.join('\t')).join('\n');try{await navigator.clipboard.writeText(lines);toast('Datos copiados para Excel.')}catch(_){toast('El navegador no permitió copiar los datos.')}}
async function exportModel(id,frequency=S.frequency){
  try{
    const inScenario=route().startsWith('escenarios'),compare=inScenario?!!S.labCompareEnabled:Object.keys(S.changes).length>0;
    const virtual=model(id);
    if(virtual?.derivedExecutive){
      const rows=(virtual.annual||[]).map(r=>[r.year,String(r.value).replace('.',','),statusLabel(r.status)]);
      const csv='sep=;\r\n'+[['Año','S/ millones','Condición'],...rows].map(row=>row.join(';')).join('\r\n');
      download(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}),`IASPE_${id}_consulta.csv`);
      return;
    }
    const r=await fetch('/api/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,frequency,changes:S.changes,compare,comparison:inScenario&&compare&&S.comparisonId?S.scenarios.find(x=>x.id===S.comparisonId)?.changes:null,comparisonLabel:inScenario?window.IASPEPanels.comparisonName(App):'Antes del cambio'})});
    if(!r.ok)throw Error((await r.json()).error);
    download(await r.blob(),`IASPE_${id}.xlsx`);
  }catch(e){toast(e.message)}
}
function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function downloadChart(id){const svg=$('.financial-chart');if(!svg){toast('Abre la vista gráfica para exportarla.');return}const clone=svg.cloneNode(true);const style=document.createElementNS('http://www.w3.org/2000/svg','style');style.textContent='.gridline{stroke:#e5eae4;stroke-width:1}text{fill:#71817b;font:10px Arial}.observed{fill:none;stroke:#244b60;stroke-width:2}.assumed{fill:none;stroke:#a7772e;stroke-width:2;stroke-dasharray:4 4}.forecast{fill:none;stroke:#007a33;stroke-width:2;stroke-dasharray:6 4}.baseline{fill:none;stroke:#a4b1a9;stroke-width:1.5;stroke-dasharray:3 5}.plot-cursor{display:none}';clone.prepend(style);download(new Blob([new XMLSerializer().serializeToString(clone)],{type:'image/svg+xml;charset=utf-8'}),`IASPE_${id}.svg`)}
function openSearch(){const extra=(window.IASPEExecutive?.executiveAccountIDs||[]).map(model).filter(Boolean).map(m=>({id:m.id,name:m.name,group:'Estado de resultados',unit:m.unit,kind:'model'}));const all=[...S.data.graph.nodes.filter(n => n.id!=='48'),...extra,{id:'transmision',name:'Transmisión monetaria al costo del pasivo',group:'Modelos complementarios',unit:'pp / pp BCRP',kind:'analysis'}];$('#portal').innerHTML=`<div class="overlay" id="search-overlay"><section class="search-dialog" role="dialog" aria-modal="true" aria-label="Buscar variables"><input id="search-field" placeholder="Busca una variable o un modelo…" aria-label="Texto de búsqueda"><div class="search-results" id="search-results"></div><div style="padding:10px 20px;color:var(--muted);font-size:10px;border-top:1px solid var(--line)">Esc para cerrar · Enter para abrir</div></section></div>`;const draw=q=>{const list=q?all.filter(n=>n.name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').includes(q.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,''))):[...S.recent.map(id=>all.find(n=>n.id===id)).filter(Boolean),...all.filter(n=>!S.recent.includes(n.id))];$('#search-results').innerHTML=list.map(n=>`<div class="search-result" role="button" tabindex="0" data-search-id="${n.id}" data-kind="${n.kind}"><div><b>${escape(n.name)}</b><small>${escape(n.group)} · ${escape(n.unit)}</small></div></div>`).join('')||'<div class="empty">No se encontraron variables.</div>';$$('[data-search-id]').forEach(x=>{x.onclick=()=>{$('#portal').innerHTML='';if(x.dataset.kind==='model'||x.dataset.kind==='analysis')navigate('modelo/'+x.dataset.searchId);else{S.mapSelected=x.dataset.searchId;S.mapAnchor=x.dataset.searchId;S.mapScope='direct';navigate('mapa');render()}};x.onkeydown=e=>{if(e.key==='Enter')x.click()}})};draw('');$('#search-field').focus();$('#search-field').oninput=e=>draw(e.target.value);$('#search-field').onkeydown=e=>{if(e.key==='Enter')$('[data-search-id]')?.click()};$('#search-overlay').onclick=e=>{if(e.target.id==='search-overlay')$('#portal').innerHTML=''}}
const App={state:S,model,fmt,escape,api,calculate,render,navigate,chartHTML,toast,baseModel,last,copyModel,exportModel,resultHeadingHTML};window.IASPEApp=App;
window.addEventListener('hashchange',()=>{if(!route().startsWith('laboratorio')&&S.data?.horizon&&S.data.horizon<2030){calculate(S.changes);return;}if(!route().startsWith('modelo/'))document.body.classList.remove('presenting');S.mapZoom=null;S.spec=false;S.coefficient=0;render();window.scrollTo(0,0)});
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openSearch()}if(e.key==='Escape'){if(document.body.classList.contains('presenting')){document.body.classList.remove('presenting');render()}else if($('#portal'))$('#portal').innerHTML=''}});
document.addEventListener('click',event=>{if(!event.target.closest('[data-topnav-menu]'))$$('[data-topnav-menu].is-open').forEach(menu=>{menu.classList.remove('is-open');menu.querySelector('.topnav-chevron').setAttribute('aria-expanded','false')});$$('details.model-export[open]').forEach(menu=>{if(!menu.contains(event.target))menu.open=false})});
window.addEventListener('resize',()=>{clearTimeout(window.resizeTimer);window.resizeTimer=setTimeout(()=>{if(route().startsWith('mapa')&&S.mapZoom==null)render()},200)});
(async()=>{try{const d=await api('/api/state');S.data=d;S.scenarios=d.scenarios||[];await window.IASPEExecutive?.ensureSource?.().catch(()=>{});render();window.IASPEMonitor?.start();window.IASPENormativa?.start()}catch(e){$('#app').innerHTML=`<div class="loading-screen"><img src="assets/banco-falabella.svg" alt="Banco Falabella"><h2>No se pudo abrir el sistema</h2><p>${escape(e.message)}</p><button onclick="location.reload()">Volver a cargar</button></div>`}})();
