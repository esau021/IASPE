/* Comparación histórica de consumo con la misma cobertura en ambos lados. */
(() => {
  'use strict';
  const MONTHS = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const FULL_MONTHS = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  let pending, data, request = 0, activeApp, resizeTimer;
  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const finite = value => typeof value === 'number' && Number.isFinite(value);
  const period = value => `${MONTHS[Number(value.slice(5, 7)) - 1]} ${value.slice(0, 4)}`;
  const fullPeriod = value => `${FULL_MONTHS[Number(value.slice(5, 7)) - 1]} ${value.slice(0, 4)}`;
  const monthNumber = value => Number(value.slice(0, 4)) * 12 + Number(value.slice(5, 7)) - 1;
  const short = (app, value) => Math.abs(value) >= 1000 ? app.fmt(value / 1000, 1) + ' mil' : app.fmt(value, value < 10 ? 1 : 0);
  const signed = (app, value) => finite(value) ? (value > 0 ? '+' : '') + app.fmt(value, 2) + ' %' : '—';

  function selected(app) {
    const id = decodeURIComponent(location.hash.slice(1)).split('/')[1]?.split('?')[0] || 'cartera';
    return data.components.find(component => component.id === id) || data.components.find(component => component.id === 'cartera');
  }
  function values(app, component) {
    return app.state.benchmarkFrequency === 'annual' ? component.rows.filter(row => row.date.endsWith('-12')) : component.rows;
  }
  function growth(component, row, key) {
    const previous = component.rows.find(item => monthNumber(item.date) === monthNumber(row.date) - 12);
    return previous && finite(previous[key]) && previous[key] !== 0 ? 100 * (row[key] / previous[key] - 1) : null;
  }
  function path(rows, value, x, y, interval) {
    let result = '', previous = null;
    for (const row of rows) {
      const amount = value(row);
      if (!finite(amount)) { previous = null; continue; }
      result += `${previous && monthNumber(row.date) - monthNumber(previous.date) === interval ? 'L' : 'M'}${x(row)} ${y(amount)}`;
      previous = row;
    }
    return result;
  }
  function graph(app, rows, series, options = {}) {
    const escape = app.escape, W = Math.max(600, ($('#workspace')?.clientWidth || innerWidth - 68) - 40);
    const H = options.height || 300, L = 65, R = 25, T = 20, B = 36;
    const first = monthNumber(rows[0].date), span = Math.max(1, monthNumber(rows.at(-1).date) - first);
    const x = row => L + (monthNumber(row.date) - first) * (W - L - R) / span;
    const allValues = rows.flatMap(row => series.map(item => item.value(row))).filter(finite);
    let low = options.zero ? 0 : Math.min(...allValues), high = Math.max(...allValues);
    const range = high - low || Math.abs(high) * .1 || 1;
    if (!options.zero) low = Math.max(0, low - range * .13);
    high += range * .13;
    const y = value => T + (high - value) * (H - T - B) / (high - low);
    const ticks = [...new Set(Array.from({length: 7}, (_, i) => Math.round(i * (rows.length - 1) / 6)))];
    const interval = app.state.benchmarkFrequency === 'annual' ? 12 : 1;
    const id = 'bm-plot-' + (options.id || 'main');
    return `<div class="bm-plot" id="${id}" data-bm-plot data-left="${L}" data-width="${W}" data-right="${R}"><svg class="bm-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="${escape(options.label || 'Comparación histórica')}" xmlns="http://www.w3.org/2000/svg">${Array.from({length: 4}, (_, i) => { const v = low + (high - low) * i / 3; return `<line class="bm-grid" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text x="${L - 12}" y="${y(v) + 4}" text-anchor="end">${escape(options.percent ? app.fmt(v, 1) + ' %' : short(app, v))}</text>`; }).join('')}${ticks.map(index => { const row = rows[index]; return `<text x="${x(row)}" y="${H - 9}" text-anchor="middle">${escape(rows.length <= 24 && interval === 1 ? period(row.date) : row.date.slice(0, 4))}</text>`; }).join('')}${series.map(item => `<path class="bm-line ${item.key}" d="${path(rows, item.value, x, y, interval)}"/>`).join('')}<line class="bm-cursor" data-bm-cursor x1="0" x2="0" y1="${T}" y2="${H - B}" style="display:none"/><rect x="${L}" y="${T}" width="${W - L - R}" height="${H - T - B}" fill="transparent"/></svg><div class="bm-tooltip" hidden></div></div>`;
  }
  function kpi(app, name, value, detail, extra = '') {
    return `<div class="bm-kpi ${extra}"><span>${app.escape(name)}</span><strong>${app.escape(value)}</strong><small>${app.escape(detail)}</small></div>`;
  }
  function html(app, component, rows) {
    const escape = app.escape, mode = app.state.benchmarkMode || 'index', annual = app.state.benchmarkFrequency === 'annual';
    const last = rows.at(-1), first = rows[0];
    const base = {falabella: first.falabella, market: first.market};
    const falabella = {key: 'falabella', value: row => mode === 'index' ? row.falabella / base.falabella * 100 : row.falabella};
    const market = {key: 'market', value: row => mode === 'index' ? row.market / base.market * 100 : row.market};
    const title = mode === 'balances' ? 'Saldos de cartera' : mode === 'index' ? 'Evolución relativa' : 'Participación de Falabella';
    const chart = mode === 'balances'
      ? `<div class="bm-balance-panel"><div class="bm-panel-label"><span><i class="bm-key market"></i>Banca múltiple</span><small>S/ millones</small></div>${graph(app, rows, [market], {height: 170, id: 'market', label: 'Saldo observado de la banca múltiple'})}</div><div class="bm-balance-panel"><div class="bm-panel-label"><span><i class="bm-key falabella"></i>Banco Falabella</span><small>S/ millones</small></div>${graph(app, rows, [falabella], {height: 170, id: 'falabella', label: 'Saldo observado de Banco Falabella'})}</div>`
      : mode === 'index'
        ? `<div class="bm-legend"><span><i class="bm-key market"></i>Banca múltiple</span><span><i class="bm-key falabella"></i>Banco Falabella</span><small>Base 100: ${escape(period(first.date))}</small></div>${graph(app, rows, [market, falabella], {height: 340, label: 'Índices base 100 de banca múltiple y Banco Falabella'})}`
        : `<div class="bm-legend"><span><i class="bm-key falabella"></i>Falabella / banca múltiple</span></div>${graph(app, rows, [{key: 'falabella', value: row => row.share}], {height: 340, percent: true, zero: true, label: 'Participación histórica de Banco Falabella'})}`;
    return `<section class="bm-workspace"><nav class="market-main-tabs"><a class="active" href="#benchmark/eeff">Estados financieros</a><a href="#benchmark/ratios">Indicadores financieros</a></nav><header class="bm-heading"><div><h1>Estados financieros</h1></div><div class="market-information-actions"><label class="market-information-switch">Información<select id="market-info-type"><option value="eeff">Cuentas contables</option><option value="cartera" selected>Cartera de consumo</option></select></label><a class="text-link" href="#modelo/${component.modelId}">Ver modelo</a></div></header><div class="bm-selection"><label>Cartera<select id="benchmark-component" aria-label="Cartera a comparar">${data.components.map(item => `<option value="${item.id}" ${item.id === component.id ? 'selected' : ''}>${escape(item.name)}</option>`).join('')}</select></label><span class="bm-cutoff">${escape(fullPeriod(last.date))}</span></div><div class="bm-summary">${kpi(app, 'Banca múltiple', app.fmt(last.market, 2), 'S/ millones')}${kpi(app, 'Falabella', app.fmt(last.falabella, 2), 'S/ millones')}${kpi(app, 'Var. anual · banca', signed(app, growth(component, last, 'market')), '')}${kpi(app, 'Var. anual · Falabella', signed(app, growth(component, last, 'falabella')), '')}${kpi(app, 'Participación', app.fmt(last.share, 2) + '%', '', 'bm-share')}</div><section class="bm-result"><div class="bm-result-heading"><div><h2>${title}</h2></div><div class="bm-controls"><div class="segmented" aria-label="Medida de comparación">${[['index', 'Base 100'], ['balances', 'Saldos'], ['share', 'Participación']].map(([id, name]) => `<button data-bm-mode="${id}" class="${mode === id ? 'active' : ''}">${name}</button>`).join('')}</div><select id="benchmark-frequency" aria-label="Frecuencia de comparación"><option value="monthly" ${!annual ? 'selected' : ''}>Mensual</option><option value="annual" ${annual ? 'selected' : ''}>Diciembre</option></select></div></div>${chart}</section></section>`;
  }
  function bind(app, component, rows) {
    $('#market-info-type').onchange = event => { if(event.target.value==='eeff')app.navigate('benchmark/eeff'); };
    $('#benchmark-component').onchange = event => app.navigate('benchmark/' + event.target.value);
    $('#benchmark-frequency').onchange = event => { app.state.benchmarkFrequency = event.target.value; app.render(); };
    $$('[data-bm-mode]').forEach(button => button.onclick = () => { app.state.benchmarkMode = button.dataset.bmMode; app.render(); });
    const mode = app.state.benchmarkMode || 'index', first = rows[0], start = monthNumber(first.date), span = Math.max(1, monthNumber(rows.at(-1).date) - start);
    $$('[data-bm-plot]').forEach(plot => {
      const svg = plot.querySelector('svg'), tooltip = plot.querySelector('.bm-tooltip');
      svg.onpointermove = event => {
        const rect = svg.getBoundingClientRect(), W = +plot.dataset.width, L = +plot.dataset.left, R = +plot.dataset.right;
        const x = (event.clientX - rect.left) / rect.width * W;
        const target = start + Math.max(0, Math.min(1, (x - L) / (W - L - R))) * span;
        const row = rows.reduce((a, b) => Math.abs(monthNumber(a.date) - target) < Math.abs(monthNumber(b.date) - target) ? a : b);
        const position = L + (monthNumber(row.date) - start) / span * (W - L - R);
        $$('[data-bm-cursor]').forEach(cursor => { cursor.setAttribute('x1', position); cursor.setAttribute('x2', position); cursor.style.display = ''; });
        const values = mode === 'share' ? [['Participación de Falabella', row.share, '%']] : mode === 'index' ? [['Banca múltiple', row.market / first.market * 100, ''], ['Banco Falabella', row.falabella / first.falabella * 100, '']] : [['Banca múltiple', row.market, 'S/ millones'], ['Banco Falabella', row.falabella, 'S/ millones']];
        tooltip.hidden = false;
        tooltip.style.left = Math.max(5, Math.min(rect.width - 300, event.clientX - rect.left + 16)) + 'px';
        tooltip.style.top = Math.max(10, Math.min(rect.height - 110, event.clientY - rect.top - 35)) + 'px';
        tooltip.innerHTML = `<strong>${app.escape(period(row.date))}</strong>${values.sort((a,b)=>b[1]-a[1]).map(([name, value, unit]) => `<div><span>${app.escape(name)}</span><b>${app.fmt(value, 6)} ${unit}</b></div>`).join('')}`;
      };
      svg.onpointerleave = () => { tooltip.hidden = true; $$('[data-bm-cursor]').forEach(cursor => cursor.style.display = 'none'); };
    });
  }
  async function render(app) {
    activeApp = app;
    const token = ++request;
    if (!data) {
      $('#workspace').innerHTML = '<div class="empty">Cargando comparación histórica…</div>';
      try { pending ||= app.api('/api/benchmark'); data = await pending; }
      catch (error) { pending = null; if (token === request && location.hash.startsWith('#benchmark')) $('#workspace').innerHTML = `<div class="notice">${app.escape(error.message || 'No se pudo leer la comparación histórica.')}</div>`; return; }
    }
    if (token !== request || !location.hash.startsWith('#benchmark')) return;
    const component = selected(app), rows = values(app, component);
    if (!rows.length) { $('#workspace').innerHTML = '<div class="empty">No hay cierres observados para esta selección.</div>'; return; }
    $('#workspace').innerHTML = html(app, component, rows);
    bind(app, component, rows);
  }
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    if (location.hash.startsWith('#benchmark') && activeApp) resizeTimer = setTimeout(() => render(activeApp), 150);
  });
  window.IASPEBenchmark = {render};
})();
