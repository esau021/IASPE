"""Persistencia verificada de las series anuales y sus consolidaciones.

Los resultados se preparan sobre copias aisladas. Nunca se declara una
actualización aplicada si los libros o las identidades financieras no cuadran.
"""
from __future__ import annotations

import math
import os
import shutil
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from iaspe_excel_portable import Blob, SpreadsheetFile

YEAR0, YEAR1 = 2026, 2030
TOL = 0.0005

# Correspondencia de componentes y columnas en los consolidados originales.
GROUPS = {
    '07': {'05': 'B', '06': 'C'},
    '08': {'08_mn': 'B', '08_me': 'C'},
    '09': {'09_plazo': 'B', '09_cts': 'C'},
    '12': {'12_obligaciones': 'B', '12_entidades': 'C', '12_adeudos': 'D', '12_otras': 'E'},
    '16': {'16_creditos': 'B', '16_inversiones': 'C', '16_disponible': 'D', '16_interbancarios': 'E'},
    '17': {'17_caja': 'B', '17_bancos': 'C', '17_canje': 'D', '17_otros': 'E'},
    '18': {'18_diversos': 'B', '18_otros_ing': 'C', '18_gastos_div': 'E', '18_otros_gastos': 'F', '18_fsd': 'G'},
    '19': {'19_personal': 'B', '19_directorio': 'C', '19_terceros': 'D', '19_impuestos': 'E'},
    '20': {'20_consorcios': 'B', '20_asociadas': 'C', '20_tc': 'D', '20_derivados': 'E', '20_inversiones': 'F', '20_otros': 'G'},
    '21': {'21_venta': 'B', '21_asociadas': 'C', '21_otras': 'D'},
}


def _annual(model):
    return {int(r['year']): r for r in model.get('annual', [])}


def _value(model, year):
    row = _annual(model).get(year)
    return None if row is None else float(row['value'])


def _changed(previous, updated):
    result = {}
    for mid, model in updated.items():
        if mid not in previous and mid in {'16_rev', '16_nrev'}:
            continue
        past = _annual(previous[mid])
        for year, row in _annual(model).items():
            if year < YEAR0 or year > YEAR1 or year not in past:
                continue
            if abs(float(row['value']) - float(past[year]['value'])) > 1e-7 or row.get('status') != past[year].get('status'):
                result.setdefault(mid, set()).add(year)
    return result


class _Books:
    def __init__(self, root):
        self.root = Path(root)
        self.books = {}
        self.dirty = set()

    def open(self, path):
        path = Path(path)
        if not path.is_file():
            raise ValueError(f'Archivo requerido no disponible: {path.relative_to(self.root)}')
        if path not in self.books:
            self.books[path] = SpreadsheetFile.import_xlsx(Blob.load(str(path)))
        return self.books[path]

    def sheet(self, path, name='Anual'):
        book = self.open(path)
        try:
            return book.worksheets.get_item(name)
        except Exception as exc:
            raise ValueError(f'Falta hoja {name} en {path.relative_to(self.root)}') from exc

    def cell(self, path, sheet, address, value, *, allow_formula=False):
        sh = self.sheet(path, sheet)
        r = sh.get_range(address)
        existing = r.values[0][0]
        formula = r.formulas[0][0]
        if existing == value or (isinstance(existing,(int,float)) and isinstance(value,(int,float)) and abs(float(existing)-float(value))<1e-8):
            return
        if formula and not allow_formula:
            raise ValueError(f'No se puede reemplazar fórmula: {path.relative_to(self.root)}, {sheet}!{address}')
        if isinstance(value, (int,float)) and not (isinstance(value, bool) or math.isfinite(float(value))):
            raise ValueError(f'Valor no finito en {address}')
        if existing != value:
            r.values = [[value]]
            self.dirty.add(path)

    def formula(self, path, sheet, address, value):
        sh=self.sheet(path,sheet)
        r=sh.get_range(address)
        if r.formulas[0][0] != value:
            r.formulas=[[value]]
            self.dirty.add(Path(path))

    def data(self, path, sheet='Anual', end=300, cols='P'):
        return self.sheet(path,sheet).get_range(f'A1:{cols}{end}').values

    def export(self):
        for file in sorted(self.dirty):
            target = file.with_name(file.name + '.writing')
            try:
                SpreadsheetFile.export_xlsx(self.books[file]).save(str(target))
                # Reimportar antes de reemplazar; la ruta original no se toca aún.
                check = SpreadsheetFile.import_xlsx(Blob.load(str(target)))
                if not check.worksheets.items:
                    raise ValueError(f'Exportación sin hojas: {file}')
                os.replace(target, file)
            finally:
                if target.exists(): target.unlink()
        return len(self.dirty)


def _row_indices(data, col=0):
    index = {}
    for i,row in enumerate(data,1):
        if col >= len(row): continue
        v = row[col]
        try:
            if isinstance(v, bool) or not 2016 <= int(v) <= YEAR1 or float(v) != int(v): continue
        except (TypeError, ValueError): continue
        index[int(v)] = i
    return index


def _cell_col(idx):
    text=''
    while idx:
        idx, rest = divmod(idx-1,26)
        text=chr(65+rest)+text
    return text


def _find_value_col(data, past, years):
    indices = _row_indices(data)
    tested = [y for y in (2026,2027,2028,2029,2030) if y in years and y in indices and y in past]
    if not tested:return None
    columns = []
    # No buscar columnas de notas o estadísticas lejanas; evitar falsas coincidencias.
    for c in range(1, min(13, len(data[0]))):
        fit=0
        for y in tested:
            row=data[indices[y]-1]
            x=row[c] if c<len(row) else None
            if isinstance(x,(int,float)) and not isinstance(x,bool):
                fit+=abs(float(x)-float(past[y]['value']))<TOL
        if fit==len(tested):columns.append(c)
    if columns:
        return columns[0]
    # En un libro anual de una única partida, la columna B es inequívoca.
    # El valor de referencia puede diferir del motor por cálculos dependientes
    # anteriores; se conserva el control de fórmulas en _write_series.
    names=[str(v or '').strip().lower() for v in data[0]]
    nonempty=[i for i, v in enumerate(names) if v]
    if (nonempty in ([0, 1], [0, 1, 2]) and names[0] in ('año', 'anio')
            and any(token in names[1] for token in ('resultado', 'importe', 'valor', 'saldo'))
            and all(isinstance(data[indices[y]-1][1], (int, float))
                    for y in tested)):
        return 1
    return None


def _condition(original, status):
    if status == 'observed':return 'Observado SBS' if 'SBS' in str(original) else 'Observado'
    if status == 'assumed':return 'Cierre supuesto'
    return 'Proyección MCO' if 'MCO' in str(original) else 'Proyección'


def _write_series(books, path, prev, now, years, *, required=True, sheet='Anual'):
    if not path.is_file():
        if required:raise ValueError(f'Falta archivo anual: {path}')
        return False
    try:
        data=books.data(path,sheet)
    except ValueError as exc:
        if not required and f'Falta hoja {sheet}' in str(exc):
            return False
        raise
    pos=_row_indices(data)
    col=_find_value_col(data,_annual(prev),years)
    if col is None:
        if required:raise ValueError(f'No se identificó con seguridad la columna de importe: {path}')
        return False
    headers=[str(v or '').strip().lower() for v in data[0]]
    status_cols=[i for i,name in enumerate(headers) if name == 'condición']
    for y in years:
        if y not in pos:raise ValueError(f'Falta período {y} en {path}')
        r=pos[y]
        old_row=_annual(prev)[y];new_row=_annual(now)[y]
        target=f'{_cell_col(col+1)}{r}'
        sh=books.sheet(path,sheet)
        formula=sh.get_range(target).formulas[0][0]
        if formula:
            if y==2026 and formula.upper().replace(' ','') == f'=E{r}+I{r}':
                if new_row.get('status')=='assumed':
                    last=sh.get_range(f'I{r}').values[0][0]
                    if not isinstance(last,(int,float)):
                        raise ValueError(f'No se encontró cuarto trimestre estimado: {path}')
                    books.cell(path,sheet,f'E{r}',float(new_row['value'])-float(last))
                elif new_row.get('status')=='observed' and str(new_row.get('sourceMonth',''))[:7] == '2026-12':
                    books.cell(path,sheet,target,float(new_row['value']),allow_formula=True)
                else:
                    raise ValueError(f'Cierre no trazable en {path}: {y}')
            elif abs(float(sh.get_range(target).values[0][0])-float(new_row['value']))>TOL:
                raise ValueError(f'La proyección calculada no cuadra con fórmula de {path}: {y}')
        else:
            books.cell(path,sheet,target,float(new_row['value']))
        if old_row.get('status')!=new_row.get('status') and status_cols:
            c=status_cols[0]
            old=data[r-1][c]
            books.cell(path,sheet,f'{_cell_col(c+1)}{r}',_condition(old,new_row['status']))
    return True


def _folder_for(model, origin, stage):
    for f in model.get('sourceFiles', []):
        f=Path(f)
        if not f.is_file() or f.suffix.lower()!='.xlsx':continue
        try:
            rel=f.relative_to(origin)
        except ValueError:
            # El registro conserva rutas absolutas de la instalación original.
            parts=f.parts
            positions=[i for i,item in enumerate(parts) if item == 'Modelos financieros']
            if not positions:continue
            rel=Path(*parts[positions[-1]+1:])
        candidate=stage/rel
        directory = candidate.parent.parent if candidate.parent.name in {'Input','Output','Script'} else candidate.parent
        if (directory/'Input').is_dir() or (directory/'Output').is_dir() or (directory/'Consolidado.xlsx').is_file():return directory
    return None


def _group_path(group, stage, previous):
    path = _folder_for(previous[group],stage,stage)
    if path is None:raise ValueError(f'Carpeta de consolidación no identificada: {group}')
    consolidated = path/'Consolidado.xlsx'
    if not consolidated.is_file():
        raise ValueError(f'Consolidado no encontrado: {group}')
    return consolidated


def _row_for_year(books, path, sheet='Anual'):
    return _row_indices(books.data(path,sheet))


GROUP_TOTAL_COLS = {
    '08': ('D', 'depósitos de ahorro'), '09': ('D', 'depósitos a plazo'),
    '12': ('F', 'gastos por intereses'), '16': ('F', 'ingresos por intereses'),
    '17': ('F', 'disponible total'), '18': ('I', 'resultado por servicios'),
    '19': ('F', 'total gastos'), '20': ('H', 'rof financiero'),
    '21': ('G', 'total inversiones'),
}


def _write_group(books, file, parent, mapping, original, updated, changes):
    data=books.data(file)
    pos=_row_indices(data)
    years=set().union(*(changes.get(k,set()) for k in mapping))
    explicit = GROUP_TOTAL_COLS.get(parent)
    if explicit:
        total_col, expected_header = explicit
        actual = str(data[0][ord(total_col)-ord('A')] or '').lower()
        if expected_header not in actual:
            raise ValueError(f'{parent}: cambió el encabezado de la columna total.')
    else:
        parent_col=_find_value_col(data,_annual(original[parent]),years)
        if parent_col is None:
            raise ValueError(f'{parent}: no se identificó el total del consolidado.')
        total_col=_cell_col(parent_col+1)
    for child,col in mapping.items():
        if child not in changes:continue
        for y in changes[child]:
            if y not in pos: raise ValueError(f'{file}: falta {y} para {child}')
            books.cell(file,'Anual',f'{col}{pos[y]}',float(_value(updated[child],y)))
    for y in sorted(years):
        target=f'{total_col}{pos[y]}'
        r=books.sheet(file).get_range(target)
        formula=r.formulas[0][0]
        expected=_value(updated[parent],y)
        if formula:
            got=r.values[0][0]
            if not isinstance(got,(int,float)) or abs(float(got)-expected)>TOL:
                raise ValueError(f'{parent}/{y}: fórmula del total no coincide con componentes.')
        else:
            books.cell(file,'Anual',target,expected)
    return True



def _write_group_external(file, parent, mapping, original, updated, changes):
    """Actualiza únicamente cachés de fórmulas en consolidados con vínculos externos.

    La estructura, los vínculos y las fórmulas originales de Excel se conservan.
    La importación estándar del editor no admite sus relaciones externas.
    """
    touched = set().union(*(changes.get(c, set()) for c in mapping))
    if not touched:
        return False
    ns = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
    sheetname = 'xl/worksheets/sheet1.xml'
    with zipfile.ZipFile(file, 'r') as zin:
        root = ET.fromstring(zin.read(sheetname))
        rows = {}
        for row in root.findall(f'.//{ns}sheetData/{ns}row'):
            cells = {c.get('r'): c for c in row.findall(f'{ns}c')}
            year_cell = cells.get(f'A{row.get("r")}')
            try:
                year = int(year_cell.findtext(f'{ns}v'))
            except (AttributeError, TypeError, ValueError):
                continue
            rows[year] = cells
        def cached(year, col, value):
            cell = rows.get(year, {}).get(f'{col}{year-2014}')
            if cell is None:
                raise ValueError(f'{parent}: falta la celda {col}/{year} en el consolidado con vínculos')
            existing = cell.find(f'{ns}f')
            if existing is None and col in tuple(mapping.values()) + ('D', 'E'):
                raise ValueError(f'{parent}: falta fórmula original {col}/{year}')
            v = cell.find(f'{ns}v')
            if v is None:
                v = ET.SubElement(cell, f'{ns}v')
            if not math.isfinite(float(value)):
                raise ValueError(f'{parent}: valor no finito en {year}')
            v.text = format(float(value), '.16g')
        for year in range(2026, 2031):
            if year not in rows:
                raise ValueError(f'{parent}: falta {year} en el consolidado externo')
            components = 0.0
            for child, col in mapping.items():
                val = _value(updated[child], year)
                components += val
                cached(year, col, val)
            total = _value(updated[parent], year)
            if abs(components-total) > TOL:
                raise ValueError(f'{parent}/{year}: total externo no coincide con componentes ({components} vs {total})')
            cached(year, 'D', total)
            prior = _value(updated[parent], year-1)
            if abs(prior) > 1e-12:
                cached(year, 'E', 100*(total/prior-1))
        ET.register_namespace('', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main')
        ET.register_namespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships')
        new_xml = ET.tostring(root, encoding='utf-8', xml_declaration=True)
        tmp=file.with_name(file.name+'.writing')
        try:
            with zipfile.ZipFile(tmp, 'w') as zout:
                for entry in zin.infolist():
                    zout.writestr(entry, new_xml if entry.filename == sheetname else zin.read(entry.filename))
        except BaseException:
            if tmp.exists():tmp.unlink()
            raise
    try:
        with zipfile.ZipFile(tmp) as check:
            if check.testzip() is not None:
                raise ValueError(f'{parent}: archivo temporal dañado')
            _ = ET.fromstring(check.read(sheetname))
        os.replace(tmp,file)
    finally:
        if tmp.exists():tmp.unlink()
    return True


def _servicios_diversos(books,root,original,updated,changes):
    """M18-01: reconstrucción 75/25 desde compras, sin sustituir fórmulas."""
    if '18_diversos' not in changes:return
    import numpy as np
    import statsmodels.api as sm
    folder=_folder_for(original['18_diversos'],root,root)
    inp=folder/'Input'/'Base_modelo.xlsx'
    out=folder/'Output'/'Pronostico.xlsx'
    mco=folder/'Output'/'Resultados_MCO.xlsx'
    inputrows=_row_for_year(books,inp)
    outrows=_row_for_year(books,out)
    if 2026 in changes['18_diversos']:
        # En el Input original, Anual!B12 = Cierre_2026!D2.
        # Registrar los acumulados SBS del período comparable mantiene esta
        # fórmula y evita que el libro restituya el cierre viejo de agosto.
        import gzip, json
        sbs=next((r.get('sourceMonth') for r in updated['18_diversos']['annual']
                  if r['year']==2026),None)
        month=str(sbs or '')[:7]
        if len(month)!=7 or not month.startswith('2026-'):
            raise ValueError('M18 ingresos: no se identificó el mes SBS que actualizó 2026.')
        panel_path=root.parent/'Scraper'/'EEFF_Benchmark'/'output'/'panel_eeff_16_bancos.json.gz'
        with gzip.open(panel_path,'rt',encoding='utf-8') as handle:
            panel=json.load(handle)
        series=panel['series']['er_acumulado:131']['05']
        comparable=f'2025-{month[-2:]}'
        previous_close=series.get('2025-12')
        current=series.get(month)
        comparison=series.get(comparable)
        if not all(isinstance(v,(float,int)) and math.isfinite(v)
                   for v in (previous_close,current,comparison)) or abs(comparison)<1e-10:
            raise ValueError('M18 ingresos: faltan acumulados SBS comparables para la estimación.')
        books.cell(inp,'Cierre_2026','A1','Cierre 2025 (S/ MM)')
        books.cell(inp,'Cierre_2026','B1',f'Acumulado {comparable} (S/ MM)')
        books.cell(inp,'Cierre_2026','C1',f'Acumulado {month} (S/ MM)')
        books.cell(inp,'Cierre_2026','A2',float(previous_close))
        books.cell(inp,'Cierre_2026','B2',float(comparison))
        books.cell(inp,'Cierre_2026','C2',float(current))
        books.formula(inp,'Cierre_2026','D2','=A2*C2/B2')
        calculated=books.sheet(inp,'Anual').get_range(f'B{inputrows[2026]}').values[0][0]
        if not isinstance(calculated,(float,int)) or abs(float(calculated)-_value(updated['18_diversos'],2026))>TOL:
            raise ValueError('M18 ingresos: el cierre SBS y la fórmula Cierre_2026 no coinciden.')
    purchases={y:_value(updated['03'],y) for y in range(2016,2031)}
    income={y:_value(updated['18_diversos'],y) for y in range(2016,2031)}
    if 2026 in changes['18_diversos']:
        # La hoja Output!Anual contiene el cierre literal del año supuesto;
        # actualizarlo junto con la fuente Cierre_2026 para que el cargador
        # y el cálculo recursivo 75/25 partan del mismo cierre validado.
        books.cell(out,'Anual',f'B{outrows[2026]}',income[2026])
    data=books.data(inp,'Anual',200,'K')
    sample=range(2017,2027)
    reg_y=[100*math.log(income[y]/income[y-1]) for y in sample]
    infl=[float(data[inputrows[y]-1][8]) for y in sample]
    fit_inf=sm.OLS(np.asarray(reg_y,float),np.asarray([[1.,v,float(y==2018),float(y in (2020,2021))] for y,v in zip(sample,infl)],float)).fit()
    fit_p=sm.OLS(np.asarray(reg_y,float),np.asarray([[1.,100*math.log(purchases[y]/purchases[y-1])] for y in sample],float)).fit()
    expected=updated['18_diversos'].get('coefficients',[])
    if len(expected)<4 or max(abs(float(a['value'])-float(v)) for a,v in zip(expected,fit_inf.params))>1e-4:
        raise ValueError('M18 ingresos: parámetros no concilian con el ajuste dinámico.')
    for year in range(2026,2031):
        row=inputrows[year]
        books.cell(inp,'Anual',f'C{row}',purchases[year])
        books.cell(inp,'Anual',f'E{row}',100*math.log(purchases[year]/purchases[year-1]))
        row=outrows[year]
        books.cell(out,'Anual',f'D{row}',100*math.log(purchases[year]/purchases[year-1]))
    for i,v in enumerate(fit_inf.params,2):books.cell(out,'Parametros',f'B{i}',float(v))
    for i,v in enumerate(fit_p.params,10):books.cell(out,'Parametros',f'B{i}',float(v))
    # Los dos senderos parten del cierre actualizado en SBS, no del valor
    # histórico congelado en la versión anterior del libro.
    anchor=income[2026]
    for col in ('B','C','D'):
        books.cell(out,'Combinacion_75_25',f'{col}2',anchor)
    # Se preservan las fórmulas de los tres senderos y sus ponderaciones.
    for year in range(2027,2031):
        row=year-2024
        books.cell(out,'Combinacion_75_25',f'E{row}',100*math.log(purchases[year]/purchases[year-1]))
        value=books.sheet(out,'Combinacion_75_25').get_range(f'D{row}').values[0][0]
        if not isinstance(value,(int,float)) or abs(float(value)-income[year])>TOL:
            raise ValueError(f'M18 ingresos/{year}: combinación 75/25 no concilia.')
    robust_inf=fit_inf.get_robustcov_results(cov_type='HC3',use_t=True)
    robust_p=fit_p.get_robustcov_results(cov_type='HC3',use_t=True)
    for sheet,fit,rob in (('Coeficientes',fit_inf,robust_inf),('Compras_MCO',fit_p,robust_p)):
        for i in range(len(fit.params)):
            for col,val in {'B':fit.params[i], 'C':fit.bse[i], 'D':fit.pvalues[i],
                            'E':rob.bse[i], 'F':rob.pvalues[i]}.items():
                books.cell(mco,sheet,f'{col}{i+2}',float(val))
    diag=books.data(mco,'Diagnostico',35,'B')
    for ix,row in enumerate(diag,1):
        key=str(row[0] or '').lower()
        val=(int(fit_inf.nobs) if 'observaciones' in key else
             float(fit_inf.rsquared_adj) if 'r² ajustado' in key else
             float(fit_inf.rsquared) if key=='r²' else
             float(fit_inf.aic) if key=='aic' else
             float(fit_inf.bic) if key=='bic' else None)
        if val is not None:books.cell(mco,'Diagnostico',f'B{ix}',val)



def _gastos_diversos_anuales(books, root, previous, updated, changes):
    """M18-03: conservar fórmulas y recalcular ratio usando el cierre SBS vigente."""
    if '18_gastos_div' not in changes and '18_diversos' not in changes:return
    folder=_folder_for(previous['18_gastos_div'],root,root)
    inp=folder/'Input'/'Base_modelo.xlsx'
    out=folder/'Output'/'Pronostico.xlsx'
    if 2026 in changes.get('18_gastos_div',set()):
        calculated=books.sheet(inp,'Cierre_2026').get_range('D2').values[0][0]
        if not isinstance(calculated,(int,float)) or abs(calculated-_value(updated['18_gastos_div'],2026))>TOL:
            raise ValueError('M18 gastos: la anualización original no concilia con el cierre')
    closing=_value(updated['18_gastos_div'],2026)
    inc26=_value(updated['18_diversos'],2026)
    if inc26<=0:raise ValueError('M18 gastos: ingresos de referencia 2026 no positivos.')
    ratio=closing/inc26
    for file in (inp,out):
        rows=_row_for_year(books,file)
        r2026=rows[2026]
        if file==out:
            books.cell(out,'Anual',f'B{r2026}',closing)
        else:
            # El Input mantiene B12 enlazada a Cierre_2026!D2.
            formula=books.sheet(inp,'Anual').get_range(f'B{r2026}').formulas[0][0]
            if not formula:raise ValueError('M18 gastos: desapareció la fórmula de cierre en Input.')
        books.cell(file,'Anual',f'C{r2026}',inc26)
        books.cell(file,'Anual',f'D{r2026}',ratio)
        for year in range(2027,2031):
            r=rows[year]
            books.cell(file,'Anual',f'C{r}',_value(updated['18_diversos'],year))
            books.formula(file,'Anual',f'B{r}',f'=$D$12*C{r}')
            observed=books.sheet(file,'Anual').get_range(f'B{r}').values[0][0]
            if not isinstance(observed,(int,float)) or abs(float(observed)-_value(updated['18_gastos_div'],year))>TOL:
                raise ValueError(f'M18 gastos/{year}: el vínculo gastos/ingresos no coincide con la proyección.')


def _terceros_ponderados(books,root,previous,updated,changes):
    """Reestima y conserva las dos MCO 75/25 con el cierre SBS vigente."""
    if '19_terceros' not in changes:return
    import gzip, json
    import numpy as np
    import statsmodels.api as sm
    folder=_folder_for(previous['19_terceros'],root,root)
    inp=folder/'Input'/'Base_modelo.xlsx'
    out=folder/'Output'/'Pronostico.xlsx'
    mco=folder/'Output'/'Resultados_MCO.xlsx'
    closing=_value(updated['19_terceros'],2026)
    source_month=next((str(r.get('sourceMonth') or '')[:7] for r in updated['19_terceros']['annual']
                       if r['year']==2026),'')
    if source_month and source_month > '2026-08':
        panel_path=root.parent/'Scraper'/'EEFF_Benchmark'/'output'/'panel_eeff_16_bancos.json.gz'
        with gzip.open(panel_path,'rt',encoding='utf-8') as file:panel=json.load(file)
        periods=panel['series']['er_acumulado:142']['05']
        if source_month not in periods:raise ValueError('M19 terceros: falta el acumulado SBS del mes actualizado.')
        if source_month.endswith('-12'):
            books.cell(inp,'Cierre_2026','B6',float(periods[source_month]))
            books.cell(inp,'Cierre_2026','B7',1.)
            books.cell(inp,'Cierre_2026','C7','Cierre diciembre observado')
        else:
            month=source_month[-2:]
            for y,row in ((2023,2),(2024,3),(2025,4)):
                key=f'{y}-{month}'
                if key not in periods:raise ValueError('M19 terceros: falta el mes comparable 2023–2025.')
                books.cell(inp,'Cierre_2026',f'B{row}',float(periods[key]))
            books.formula(inp,'Cierre_2026','B7','=MEDIAN(D2:D4)')
            books.cell(inp,'Cierre_2026','C7','Mediana estacional 2023–2025 (mes/diciembre)')
            books.cell(inp,'Cierre_2026','A1','Año')
            books.cell(inp,'Cierre_2026','B1',f'Acumulado mes {month} (S/ MM)')
            books.cell(inp,'Cierre_2026','A6',f'Mes {source_month} (S/ MM)')
            books.cell(inp,'Cierre_2026','B6',float(periods[source_month]))
        actual=books.sheet(inp,'Cierre_2026').get_range('B8').values[0][0]
        if not isinstance(actual,(int,float)) or abs(float(actual)-closing)>TOL:
            raise ValueError('M19 terceros: cierre SBS no coincide con factor interanual de origen.')
    inrows=_row_for_year(books,inp);outrows=_row_for_year(books,out)
    books.cell(inp,'Anual',f'B{inrows[2026]}',closing)
    books.cell(out,'Anual',f'B{outrows[2026]}',closing)
    years=list(range(2017,2027))
    gastos={y:_value(updated['19_terceros'],y) for y in range(2016,2031)}
    data=books.data(inp,'Anual',30,'F')
    import motor
    overrides=(motor.macro_base_state().get('changes') or {}).get('pbi',{})
    pbi={y:float(overrides.get(str(y),data[inrows[y]-1][2])) for y in range(2016,2031)}
    for y in range(2026,2031):
        if str(y) in overrides:
            books.cell(inp,'Anual',f'C{inrows[y]}',pbi[y])
            books.cell(out,'Anual',f'D{outrows[y]}',pbi[y])
    growth=[100*math.log(gastos[y]/gastos[y-1]) for y in years]
    fit_pbi=sm.OLS(np.asarray(growth,float),np.asarray([[1.,pbi[y]] for y in years],float)).fit()
    fit_lag=sm.OLS(np.asarray([gastos[y] for y in years],float),
                   np.asarray([[1.,pbi[y],gastos[y-1]] for y in years],float)).fit()
    robust_pbi=fit_pbi.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
    robust_lag=fit_lag.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
    # Los coeficientes deben ser exactamente los que el motor recalculó.
    expected=[float(x['value']) for x in updated['19_terceros']['coefficients']]
    calculated=[*map(float,robust_pbi.params),*map(float,robust_lag.params)]
    if len(expected)!=5 or max(abs(a-b) for a,b in zip(expected,calculated))>1e-5:
        raise ValueError('M19 terceros: coeficientes MCO del libro y motor no coinciden.')
    for i,val in enumerate(fit_pbi.params,2):books.cell(out,'Anual',f'I{i}',float(val))
    for i,val in enumerate(fit_lag.params,2):books.cell(out,'Anual',f'L{i}',float(val))
    books.cell(out,'Anual','I4',float(fit_pbi.rsquared_adj))
    books.cell(out,'Anual','L5',float(fit_lag.rsquared_adj))
    for tab,fit,rob in (('MCO',fit_pbi,robust_pbi),('MCO_rezago',fit_lag,robust_lag)):
        for i in range(len(fit.params)):
            for col,value in {'B':fit.params[i], 'C':fit.bse[i] if tab=='MCO' else rob.bse[i],
                              'D':fit.pvalues[i] if tab=='MCO' else rob.tvalues[i]}.items():
                books.cell(mco,tab,f'{col}{i+2}',float(value))
            if tab=='MCO_rezago':books.cell(mco,tab,f'E{i+2}',float(rob.pvalues[i]))
    for y in range(2026,2031):
        r=y-2024
        if y==2026:
            books.cell(out,'Comparacion',f'B{r}',closing)
            books.cell(out,'Comparacion',f'C{r}',closing)
        else:
            books.cell(out,'Comparacion',f'G{r}',0.75)
            books.cell(out,'Comparacion',f'H{r}',0.25)
            rr=outrows[y]
            books.cell(out,'Anual',f'F{rr}','Combinación MCO (75% PBI / 25% PBI + rezago)')
            forecast=books.sheet(out,'Anual').get_range(f'B{rr}').values[0][0]
            wanted=_value(updated['19_terceros'],y)
            if not isinstance(forecast,(int,float)) or abs(forecast-wanted)>TOL:
                raise ValueError(f'M19 terceros/{y}: la fórmula del escenario no concilia ({forecast} vs {wanted}).')
        books.cell(out,'Comparacion',f'L{r}',_value(updated['29'],y))


def _otros_servicios(books, root, previous, updated, changes):
    """Actualiza el cierre y la mediana de tres ejercicios de M18, sin fijar resultados."""
    for mid, sub, input_part, output_part in (
        ('18_otros_ing', '02_Otros_ingresos', 'C', 'C'),
        ('18_otros_gastos', '04_Otros_gastos', 'B', 'C'),
    ):
        if mid not in changes:
            continue
        folder = _folder_for(previous[mid],root,root)
        if folder is None or folder.name != sub:
            raise ValueError(f'M18: carpeta incorrecta para {mid}')
        inp, out = folder/'Input'/'Base_modelo.xlsx', folder/'Output'/'Pronostico.xlsx'
        inrows, outrows = _row_for_year(books,inp), _row_for_year(books,out)
        if 2026 in changes[mid]:
            for file, rows, primary, total in (
                (inp,inrows,input_part,'E'),(out,outrows,output_part,'B'),
            ):
                row=rows[2026]
                target=f'{primary}{row}'
                current=books.sheet(file).get_range(target).values[0][0]
                if not isinstance(current,(float,int)):
                    raise ValueError(f'M18: cierre sin componente numérico {file}')
                total_value=books.sheet(file).get_range(f'{total}{row}').values[0][0]
                if not isinstance(total_value,(int,float)):
                    raise ValueError('M18: total de cierre no numérico')
                delta=_value(updated[mid],2026)-float(total_value)
                if abs(delta)>TOL:
                    books.cell(file,'Anual',target,float(current)+delta)
                if total != primary:
                    books.cell(file,'Anual',f'{total}{row}',_value(updated[mid],2026))
        for year in range(2027,2031):
            if year not in changes[mid]: continue
            r=outrows[year]
            # Ventana literal aprobada: los tres cierres 2023–2025.
            books.formula(out,'Anual',f'C{r}', '=MEDIAN($B$9:$B$11)')
            if mid=='18_otros_gastos':
                books.formula(inp,'Anual',f'B{inrows[year]}','=MEDIAN($E$9:$E$11)')
            else:
                books.cell(inp,'Anual',f'C{inrows[year]}',_value(updated[mid],year))
                books.cell(inp,'Anual',f'E{inrows[year]}',_value(updated[mid],year))
            result=books.sheet(out).get_range(f'B{r}').values[0][0]
            if not isinstance(result,(int,float)) or abs(float(result)-_value(updated[mid],year))>TOL:
                raise ValueError(f'M18 {mid}/{year}: serie física no concilia con el motor')

def _personal_staff(books,root,original,updated,changes,observations):
    """Sincroniza B-2305 y gasto M19 sin confundir dotación con gastos."""
    headcount=(observations or {}).get('trabajadores_falabella',{})
    if not headcount and '19_personal' not in changes:return
    import numpy as np
    import statsmodels.api as sm
    folder=_folder_for(original['19_personal'],root,root)
    inp=folder/'Input'/'Base_modelo.xlsx'
    out=folder/'Output'/'Pronostico.xlsx'
    data=books.data(inp,'Anual',30,'K')
    index=_row_indices(data)
    if not changes.get('19_personal') and all(abs(float(v)-float(data[index[int(y)]-1][6]))<1e-8 for y,v in headcount.items() if str(y).isdigit() and int(y)<=2026):
        return
    source={int(k):float(v) for k,v in headcount.items() if str(k).isdigit() and int(k)<=2026}
    staff={y:source.get(y,float(data[index[y]-1][6])) for y in range(2016,2027)}
    annual={y:float(data[index[y]-1][2]) for y in range(2016,2031)}
    training=range(2017,2027)
    fit=sm.OLS(np.asarray([100*math.log(staff[y]/staff[y-1]) for y in training],float),
               np.asarray([[1.,annual[y],float(y in (2020,2021))] for y in training],float)).fit()
    for year in range(2027,2031):
        staff[year]=staff[year-1]*math.exp(float(np.dot(fit.params,[1.,annual[year],0]))/100)
    out_rows=_row_for_year(books,out)
    for year in range(2026,2031):
        row=index[year]
        books.cell(inp,'Anual',f'G{row}',staff[year])
        books.cell(inp,'Anual',f'H{row}',(staff[year-1]+staff[year])/2)
        books.cell(inp,'Anual',f'I{row}',100*math.log(staff[year]/staff[year-1]))
        target=out_rows[year]
        books.cell(out,'Anual',f'G{target}',staff[year])
        books.cell(out,'Anual',f'H{target}',(staff[year-1]+staff[year])/2)
        value=_value(updated['19_personal'],year)
        books.cell(out,'Anual',f'I{target}',value/((staff[year-1]+staff[year])/2))
        if year in changes.get('19_personal',set()):
            books.cell(out,'Anual',f'B{target}',value)
            if year>=2017:
                prev=_value(updated['19_personal'],year-1)
                books.cell(out,'Anual',f'C{target}',100*(value/prev-1))
        source_file=inp
        locs=_row_indices(books.data(source_file,'Fuente_personal',50,'D'))
        if year in locs:
            rr=locs[year]
            books.cell(source_file,'Fuente_personal',f'B{rr}',staff[year])
            if year==2026 and headcount:
                books.cell(source_file,'Fuente_personal',f'C{rr}','SBS B-2305 · cierre vigente')
                books.cell(source_file,'Fuente_personal',f'D{rr}','Dato observado o cierre estimado SBS')
    consolidated=folder.parent/'Consolidado.xlsx'
    if consolidated.is_file():
        idx=_row_for_year(books,consolidated,'Personal_dotacion')
        for year in range(2026,2031):
            if year in idx:
                books.cell(consolidated,'Personal_dotacion',f'B{idx[year]}',_value(updated['19_personal'],year))
                books.cell(consolidated,'Personal_dotacion',f'C{idx[year]}',staff[year])
                books.cell(consolidated,'Personal_dotacion',f'D{idx[year]}',(staff[year-1]+staff[year])/2)
    # La muestra incluye el cierre supuesto 2026; persistir las tres betas y
    # sus errores HAC si la dotación SBS se actualizó, sin añadir pestañas.
    fitted=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
    mco=folder/'Output'/'Resultados_MCO.xlsx'
    for i in range(3):
        for col,v in {'B':float(fit.params[i]),'C':float(fitted.bse[i]),
                      'D':float(fitted.pvalues[i])}.items():
            books.cell(mco,'Resultados_MCO',f'{col}{i+2}',v)
    books.cell(mco,'Resultados_MCO','B7',int(fit.nobs))
    books.cell(mco,'Resultados_MCO','B8','2017–2026 (cierre supuesto)')
    books.cell(mco,'Resultados_MCO','B9',float(fit.rsquared_adj))
    for i,v in enumerate(fit.params):
        books.cell(out,'Anual',f'N{i+2}',float(v))
    books.cell(out,'Anual','N5',float(fit.rsquared_adj))

def _saldo_bruto(books,root,original,updated,changes):
    if not any(k in changes for k in ('05','06','07')):return
    path=_folder_for(original['07'],root,root)/'Output'/'Pronostico.xlsx'
    rows=_row_for_year(books,path)
    years=set().union(*(changes.get(k,set()) for k in ('05','06','07')))
    for year in sorted(years):
        if year not in rows:raise ValueError(f'M07: falta el año {year}')
        ix=rows[year]
        books.cell(path,'Anual',f'B{ix}',_value(updated['05'],year))
        books.cell(path,'Anual',f'C{ix}',_value(updated['06'],year))
        cell=books.sheet(path).get_range(f'D{ix}')
        if cell.formulas[0][0]:
            value=cell.values[0][0]
            if not isinstance(value,(int,float)) or abs(value-_value(updated['07'],year))>TOL:
                raise ValueError(f'M07/{year}: fórmula del total no concilia con sus componentes.')
        else:
            books.cell(path,'Anual',f'D{ix}',_value(updated['07'],year))


def _consorcios(books,root,original,updated,changes):
    if not any(k in changes for k in ('05','20_consorcios')):return
    folder=_folder_for(original['20_consorcios'],root,root)
    years=set(changes.get('05',set()))|set(changes.get('20_consorcios',set()))
    inp=folder/'Input'/'Base_modelo.xlsx';out=folder/'Output'/'Pronostico.xlsx'
    if 2026 in changes.get('20_consorcios',set()):
        import statistics
        closing=_annual(updated['20_consorcios'])[2026]
        month=int(str(closing.get('sourceMonth','2026-08'))[-2:])
        associated=statistics.median(_value(updated['20_asociadas'],year) for year in (2023,2024,2025))
        source=(_value(updated['20_consorcios'],2026)+associated)*month/12
        books.cell(inp,'Anual','C12',source)
        books.cell(out,'Parametros','B2',source)
        books.cell(out,'Parametros','B3',12/month)
        books.cell(out,'Parametros','B4',associated)
    books.cell(out,'Parametros','B5',_value(updated['05'],2026))
    indices=_row_for_year(books,inp); rows=_row_for_year(books,out)
    for year in sorted(years):
        if year not in indices or year not in rows:raise ValueError(f'M20 consorcios: falta {year}')
        books.cell(inp,'Anual',f'D{indices[year]}',_value(updated['05'],year))
        books.cell(out,'Anual',f'C{rows[year]}',_value(updated['05'],year))
        value=books.sheet(out).get_range(f'B{rows[year]}').values[0][0]
        if not isinstance(value,(int,float)) or abs(value-_value(updated['20_consorcios'],year))>TOL:
            raise ValueError(f'M20 consorcios/{year}: Output no concilia.')

def _saldos_m10_sbs(books,root,previous,updated,changes):
    """Sincroniza la estimación interanual y la relación contable de M10."""
    if not any(mid in changes for mid in ('10_restringidos','10_otras')):return
    from rutas import buscar_modelo
    base=buscar_modelo(root,'10')
    for mid,sub in (('10_restringidos','01_Depositos_restringidos'),
                    ('10_otras','02_Otras_obligaciones')):
        if mid not in changes:continue
        folder=base/sub
        inp=folder/'Input'/'Base_modelo.xlsx'
        out=folder/'Output'/'Pronostico.xlsx'
        monthly={str(r.get('date'))[:7]:r for r in updated[mid].get('monthly',[])}
        outrows={str(r[0])[:7]:i for i,r in enumerate(books.data(out,'Mensual',230,'C'),1)
                 if isinstance(r[0],str)}
        inrows={str(r[0])[:7]:i for i,r in enumerate(books.data(inp,'Mensual',230,'C'),1)
                if isinstance(r[0],str)}
        observed_2026=[m for m,r in monthly.items() if m.startswith('2026-') and r['status']=='observed']
        last=max(observed_2026) if observed_2026 else '2026-08'
        for month,row in sorted(monthly.items()):
            if month<'2026-09':continue
            if month not in outrows:raise ValueError(f'{mid}: falta mes {month} en Output')
            tag='Observado SBS' if row['status']=='observed' else ('Cierre supuesto: interanual 3 meses' if row['status']=='assumed' else 'Proyección proporcional M08 + M09')
            if row['status']=='observed':
                books.cell(out,'Mensual',f'B{outrows[month]}',float(row['value']),allow_formula=True)
            elif month<'2027-01' and last>'2026-08':
                latest=outrows[last]
                factor=(int(month[-2:])-int(last[-2:]))/(12-int(last[-2:]))
                books.formula(out,'Mensual',f'B{outrows[month]}',f'=B{latest}+(Anual!$B$12-B{latest})*{factor:.16g}')
            books.cell(out,'Mensual',f'C{outrows[month]}',tag)
            if row['status']=='observed' and month not in inrows:
                r=max(inrows.values(),default=1)+1
                books.cell(inp,'Mensual',f'A{r}',month)
                books.cell(inp,'Mensual',f'B{r}',float(row['value']))
                books.cell(inp,'Mensual',f'C{r}','Observado SBS')
                inrows[month]=r
        years=_row_for_year(books,out)
        if last>'2026-08':
            if last=='2026-12':
                formula=f'=Mensual!B{outrows[last]}'
            else:
                m=int(last[-2:]);lo=m-2
                current=f'Mensual!B{outrows[f"2026-{lo:02d}"]}:B{outrows[last]}'
                previous=f'Mensual!B{outrows[f"2025-{lo:02d}"]}:B{outrows[f"2025-{m:02d}"]}'
                formula=f'=Mensual!B{outrows["2025-12"]}*AVERAGE({current})/AVERAGE({previous})'
            books.formula(out,'Anual',f'B{years[2026]}',formula)
        for year in range(2026,2031):
            value=_value(updated[mid],year)
            if f'{year}-12' not in monthly or abs(value-float(monthly[f'{year}-12']['value']))>TOL:
                raise ValueError(f'M10 {mid}/{year}: el cierre anual difiere de diciembre')
            books.cell(out,'Anual',f'D{years[year]}',_value(updated['08'],year)+_value(updated['09'],year))
            got=books.sheet(out,'Anual').get_range(f'B{years[year]}').values[0][0]
            if not isinstance(got,(int,float)) or abs(got-value)>TOL:
                raise ValueError(f'M10 {mid}/{year}: fórmula de saldo no concilia')
            books.cell(out,'Anual',f'C{years[year]}',
                       ('Observado SBS' if last=='2026-12' else 'Cierre supuesto: interanual jun-ago') if year==2026 else 'Proyección proporcional M08 + M09')


def _bancos_cierre_2026(books, root, folder, model, observations):
    """Conserva el stock fuente y guarda por separado el cierre conciliado."""
    import gzip, json
    raw=(observations or {}).get('sbs_contable',{}).get('17_bancos',{}).get('2026',{})
    month=str(raw.get('sourceMonth',''))[:7]
    closing=_annual(model)[2026]
    method=model.get('method','').lower()
    residual=('residual' in method or 'conciliación' in method) and closing.get('status')!='observed'
    target=float(closing['value'])
    if month.startswith('2026-') and len(month)==7 and month[-2:].isdigit() and 1<=int(month[-2:])<=12:
        panel_file=root.parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz'
        with gzip.open(panel_file,'rt',encoding='utf-8') as stream:
            rseries=json.load(stream)['series'].get('balance:002',{}).get('05',{})
        past=rseries.get(f'2025-{month[-2:]}')
        latest=rseries.get(month)
        source_value=raw.get('value')
        if (not isinstance(latest,(int,float)) or isinstance(latest,bool) or not math.isfinite(latest)
                or not isinstance(source_value,(int,float)) or isinstance(source_value,bool)
                or not math.isfinite(source_value) or abs(float(latest)-float(source_value))>0.005):
            raise ValueError('M17 Bancos: la observación de entrada no coincide con SBS balance:002')
        if raw.get('status')=='observed' and month!='2026-12':
            raise ValueError('M17 Bancos: un cierre observado requiere la fuente SBS de diciembre')
        # Diciembre observado debe coincidir con SBS. Un cierre provisional
        # residual M47 es otra magnitud y no reemplaza el dato mensual de Input.
        if (not residual or raw.get('status')=='observed') and abs(float(latest)-target)>0.005:
            raise ValueError('M17 Bancos: cierre observado/no residual no coincide con SBS balance:002')
        if not isinstance(past,(int,float)) or isinstance(past,bool) or not math.isfinite(past) or past==0:
            raise ValueError('M17 Bancos: falta saldo SBS del mes homólogo de 2025')
        inp=folder/'Input/Base_modelo.xlsx'
        row=1+int(month[-2:])
        books.cell(inp,'Cierre_2026',f'A{row}',int(month[-2:]))
        books.cell(inp,'Cierre_2026',f'B{row}',float(past))
        books.cell(inp,'Cierre_2026',f'C{row}',float(latest))
        books.formula(inp,'Cierre_2026',f'D{row}',f'=C{row}/B{row}-1')
        books.formula(inp,'Anual',f'B{_row_for_year(books,inp)[2026]}',f'=Cierre_2026!C{row}')
    elif raw or not residual:
        raise ValueError('M17 Bancos: no se identificó mes de fuente SBS para 2026')
    out=folder/'Output/Pronostico.xlsx'
    row=_row_for_year(books,out)[2026]
    books.cell(out,'Anual',f'B{row}',target)
    if residual:
        books.cell(out,'Anual',f'F{row}','Cierre residual M47')
    elif closing.get('status')=='observed':
        books.cell(out,'Anual',f'F{row}','Observado SBS')


def _dependencias_depositos(books, root, original, updated, changes, observations=None):
    """Actualiza saldos y regresoras de obligaciones sin alterar sus fórmulas."""
    if not any(k in changes for k in ('08','09','10','11','12_obligaciones','17_bancos')):
        return
    from rutas import buscar_modelo
    folder10=buscar_modelo(root,'10')
    cons=folder10/'03_Consolidacion_obligaciones'/'Obligaciones_con_el_publico.xlsx'
    rows=_row_for_year(books,cons)
    for year in range(2026,2031):
        if year not in rows:raise ValueError(f'M10: falta {year}.')
        row=rows[year]
        for mid,col in (('08','B'),('09','C'),('10_restringidos','D'),('10_otras','E')):
            if mid in updated:
                books.cell(cons,'Anual',f'{col}{row}',_value(updated[mid],year))
        total=books.sheet(cons).get_range(f'F{row}').values[0][0]
        if not isinstance(total,(int,float)) or abs(total-_value(updated['10'],year))>TOL:
            raise ValueError(f'M10 {year}: total de obligaciones no concilia.')
    folder11=_folder_for(original['11'],root,root)
    inp11=folder11/'Input'/'Base_modelo.xlsx';out11=folder11/'Output'/'Pronostico.xlsx'
    for file in (inp11,out11):
        rows=_row_for_year(books,file)
        for year in range(2026,2031):
            row=rows[year]
            share=100*_value(updated['09'],year)/_value(updated['10'],year)
            books.cell(file,'Anual',f'D{row}',float(share))
    rows11=_row_for_year(books,out11)
    coef11=updated['11'].get('coefficients',[])
    if len(coef11)!=4:raise ValueError('M11: faltan coeficientes.')
    betas=[float(x['value']) for x in coef11]
    for y in range(2027,2031):
        row=rows11[y]
        prev=rows11[y-1]
        books.formula(out11,'Anual',f'B{row}',
            f'={betas[0]:.16g}+({betas[1]:.16g})*B{prev}+({betas[2]:.16g})*C{row}+({betas[3]:.16g})*D{row}')
    for year in range(2027,2031):
        i=rows11[year];value=books.sheet(out11).get_range(f'B{i}').values[0][0]
        if not isinstance(value,(int,float)) or abs(value-_value(updated['11'],year))>TOL:
            raise ValueError(f'M11 {year}: costo de obligaciones no concilia con la fórmula.')
    folder12=_folder_for(original['12_obligaciones'],root,root)
    if 2026 in changes.get('12_obligaciones',set()):
        _monthly_flow_closing(books,folder12/'Input/Base_modelo.xlsx',root,
                              'er_acumulado:112',updated['12_obligaciones'],repeat_missing=True)
    for kind in ('Input/Base_modelo.xlsx','Output/Pronostico.xlsx'):
        f=folder12/kind;rows=_row_for_year(books,f)
        for year in range(2026,2031):
            i=rows[year]
            books.cell(f,'Anual',f'B{i}',_value(updated['10'],year))
            books.cell(f,'Anual',f'C{i}',_value(updated['11'],year))
    p12=folder12/'Output'/'Pronostico.xlsx'
    rows12=_row_for_year(books,p12)
    if 2026 in changes.get('12_obligaciones',set()):
        # Output contiene la estimación de cierre recibida de la actualización
        # SBS. G conserva su fórmula = D. El Input mensual histórico no se
        # altera ni se crean distribuciones mensuales artificiales.
        books.cell(p12,'Anual',f'D{rows12[2026]}',_value(updated['12_obligaciones'],2026))
        books.cell(p12,'Anual',f'H{rows12[2026]}','Cierre supuesto SBS')
    for year in range(2027,2031):
        value=books.sheet(p12).get_range(f'G{rows12[year]}').values[0][0]
        if not isinstance(value,(int,float)) or abs(value-_value(updated['12_obligaciones'],year))>TOL:
            raise ValueError(f'M12/{year}: gasto por intereses y obligaciones no concilia ({value} vs {_value(updated["12_obligaciones"],year)}).')
    folderfsd=_folder_for(original['18_fsd'],root,root)
    if folderfsd is not None:
        fsd2026=_value(updated['18_fsd'],2026)
        ratio=fsd2026/_value(updated['10'],2026)
        for kind in ('Input/Base_modelo.xlsx','Output/Pronostico.xlsx'):
            f=folderfsd/kind;rows=_row_for_year(books,f)
            for year in range(2026,2031):
                i=rows[year]
                books.cell(f,'Anual',f'C{i}',_value(updated['10'],year))
                if year==2026:
                    books.cell(f,'Anual',f'D{i}',ratio)
                if kind.startswith('Input') and year>2026:
                    books.cell(f,'Anual',f'D{i}',ratio)
                    books.cell(f,'Anual',f'B{i}',_value(updated['18_fsd'],year))
        f=folderfsd/'Output'/'Pronostico.xlsx';rows=_row_for_year(books,f)
        for year in range(2027,2031):
            value=books.sheet(f).get_range(f'B{rows[year]}').values[0][0]
            if not isinstance(value,(int,float)) or abs(value-_value(updated['18_fsd'],year))>TOL:
                raise ValueError(f'M18 FSD/{year}: fórmula incompatible con obligaciones.')
    folder17=_folder_for(original['17_bancos'],root,root)
    if 2026 in changes.get('17_bancos',set()):
        _bancos_cierre_2026(books,root,folder17,updated['17_bancos'],observations)
    for kind in ('Input/Base_modelo.xlsx','Output/Pronostico.xlsx'):
        f=folder17/kind;rows=_row_for_year(books,f)
        for year in range(2026,2031):
            books.cell(f,'Anual',f'C{rows[year]}',_value(updated['10'],year))
    out17=folder17/'Output'/'Pronostico.xlsx'
    params=updated['17_bancos'].get('coefficients',[])
    if len(params)==2:
        for j,item in enumerate(params,2):
            books.cell(out17,'Anual',f'I{j}',float(item['value']))
    elif not params and ('residual' in updated['17_bancos'].get('method','').lower() or
                         'conciliación' in updated['17_bancos'].get('method','').lower()):
        # M17 ahora se determina por la identidad de M47. No exigir
        # coeficientes de una regresión descontinuada ni restituir su fórmula.
        for year in range(2027,2031):
            i=_row_for_year(books,out17)[year]
            books.cell(out17,'Anual',f'B{i}',_value(updated['17_bancos'],year))
    else:
        raise ValueError('M17: falta una metodología válida para bancos y corresponsales.')
    for year in range(2027,2031):
        i=_row_for_year(books,out17)[year]
        val=books.sheet(out17).get_range(f'B{i}').values[0][0]
        if not isinstance(val,(float,int)) or abs(val-_value(updated['17_bancos'],year))>TOL:
            raise ValueError(f'M17 {year}: bancos y corresponsales no concilia ({val} vs {_value(updated["17_bancos"],year)}).')



def _sincronizar_driver_m33(books,root,previous,updated,changes):
    """Conservar CAPEX, calibración y fórmulas; transmitir la depreciación M26."""
    if not {'26','33'}.intersection(changes):return
    folder=_folder_for(previous['33'],root,root)
    file=folder/'Output/Pronostico.xlsx'
    rows=_row_for_year(books,file,'Depreciacion_M26')
    annual=_row_for_year(books,file)
    for year in range(2027,2031):
        if year not in rows or year not in annual:raise ValueError(f'M33: falta driver M26/{year}')
        books.cell(file,'Depreciacion_M26',f'D{rows[year]}',_value(updated['26'],year))
        value=books.sheet(file).get_range(f'B{annual[year]}').values[0][0]
        if not isinstance(value,(int,float)) or abs(float(value)-_value(updated['33'],year))>TOL:
            raise ValueError(f'M33/{year}: depreciación M26 no concilia con la fórmula')


def _sincronizar_drivers_m38(books, root, original, updated, changes):
    """Escalar los drivers M38 respecto a su propio presupuesto contractual.

    Los drivers M38 contienen anclas contables distintas de M12, por lo que
    reemplazarlos por el M12 absoluto alteraría la base preaprobada.
    Solo se transmite la variación relativa (nuevo/antiguo) de cada cuenta.
    """
    trigger={'10','35','36','12_obligaciones','12_entidades','38'}
    if not trigger.intersection(changes):return
    from rutas import buscar_modelo
    file=buscar_modelo(root,'38')/'Output'/'Pronostico.xlsx'
    rows=_row_for_year(books,file,'Drivers_Base')
    for year in range(2026,2031):
        i=rows[year]
        for col,mid in [('B','10'),('C','35'),('D','36'),('E','12_obligaciones'),('F','12_entidades')]:
            old=_value(original[mid],year)
            now=_value(updated[mid],year)
            base=books.sheet(file,'Drivers_Base').get_range(f'{col}{i}').values[0][0]
            if not isinstance(base,(int,float)) or not old or now is None:
                raise ValueError(f'M38: driver no válido {mid}/{year}')
            books.cell(file,'Drivers_Base',f'{col}{i}',base*now/old)
    rows_actual=_row_for_year(books,file,'Anual')
    for year in range(2026,2031):
        actual=books.sheet(file,'Anual').get_range(f'B{rows_actual[year]}').values[0][0]
        desired=_value(updated['38'],year)
        if not isinstance(actual,(int,float)) or abs(actual-desired)>TOL:
            raise ValueError(f'M38/{year}: fórmula física no concilia con el motor ({actual} vs {desired}).')


def _sincronizar_drivers_m39(books, root, updated, changes):
    """Actualizar M28 en M39 sin cambiar fórmulas de impuesto por pagar."""
    if not {'28','39'}.intersection(changes):return
    from rutas import buscar_modelo
    file=buscar_modelo(root,'39')/'Output'/'Pronostico.xlsx'
    rows=_row_for_year(books,file,'Drivers_Base')
    for year in range(2026,2031):
        books.cell(file,'Drivers_Base',f'B{rows[year]}',_value(updated['28'],year))
    outrows=_row_for_year(books,file,'Anual')
    for year in range(2026,2031):
        got=books.sheet(file,'Anual').get_range(f'B{outrows[year]}').values[0][0]
        exp=_value(updated['39'],year)
        if not isinstance(got,(int,float)) or abs(got-exp)>TOL:
            raise ValueError(f'M39/{year}: fórmula contable incongruente ({got} vs {exp})')


def _sincronizar_drivers_m45(books, root, updated, changes):
    """Llevar la utilidad M29 al movimiento patrimonial acumulado M45."""
    if not {'29','45','45_utilidad_aplicada'}.intersection(changes):return
    from rutas import buscar_modelo
    file=buscar_modelo(root,'45')/'Output'/'Pronostico.xlsx'
    rows=_row_for_year(books,file,'Drivers_Base')
    for year in range(2026,2031):
        books.cell(file,'Drivers_Base',f'C{rows[year]}',_value(updated['29'],year))
    outrows=_row_for_year(books,file,'Anual')
    # Forzar evaluación de topes de dividendos tras actualizar utilidades.
    for year in range(2027,2031):
        r=outrows[year]
        books.formula(file,'Anual',f'E{r}',f'=MIN(Drivers_Base!E{r},MAX(0,B{r-1}+D{r}-F{r}))+0')
        books.formula(file,'Anual',f'B{r}',f'=B{r-1}+D{r}-E{r}-F{r}+0')
    for year in range(2026,2031):
        actual=books.sheet(file,'Anual').get_range(f'B{outrows[year]}').values[0][0]
        expected=_value(updated['45'],year)
        if not isinstance(actual,(int,float)) or abs(actual-expected)>TOL:
            raise ValueError(f'M45/{year}: no concilia utilidad aplicada ({actual} vs {expected})')


def _sincronizar_drivers_m46(books, root, updated, changes):
    """Utilidad del balance M46 = resultado del ejercicio M29."""
    if not {'29','46'}.intersection(changes):return
    from rutas import buscar_modelo
    file=buscar_modelo(root,'46')/'Output'/'Pronostico.xlsx'
    rows=_row_for_year(books,file,'Drivers_Base')
    for year in range(2026,2031):
        books.cell(file,'Drivers_Base',f'C{rows[year]}',_value(updated['29'],year))
    outrows=_row_for_year(books,file,'Anual')
    for year in range(2026,2031):
        actual=books.sheet(file,'Anual').get_range(f'B{outrows[year]}').values[0][0]
        expected=_value(updated['46'],year)
        if not isinstance(actual,(int,float)) or abs(actual-expected)>TOL:
            raise ValueError(f'M46/{year}: no concilia con M29 ({actual} vs {expected})')


def _sincronizar_drivers_m47(books, root, updated, changes):
    """Actualizar únicamente los inputs del balance SBS; mantener todas sus fórmulas."""
    if not any(k.startswith('47') or k in {'10','38','39','45','46','17_bancos'} for k in changes):return
    from rutas import buscar_modelo
    file=buscar_modelo(root,'47')/'Output'/'Pronostico.xlsx'
    mapping={2:'17_caja',4:'17_canje',5:'17_otros',6:'22',7:'21',
             8:'07',12:'31',13:'32',15:'33',16:'34',17:'10',18:'35',
             21:'36',22:'37',23:'38',24:'39',25:'40',27:'41',
             28:'42',29:'43',30:'44',31:'45',32:'46'}
    for year, col in zip(range(2026,2031),'CDEFG'):
        for row,mid in mapping.items():
            books.cell(file,'Drivers_Base',f'{col}{row}',_value(updated[mid],year))
        # Row 3 preserves PRE-reconciliation bank cash.
        # El saldo de provisiones 2026-28 llega del IASC, no de la ratio SBS.
        # La fila 10 tiene fórmulas vinculadas a Parametros_Base; NO sustituirlas
        # por un número fijo cuando cambien las colocaciones o el escenario.
        other=float(books.sheet(file,'Parametros_Base').get_range('B2').values[0][0])
        deferred=float(books.sheet(file,'Parametros_Base').get_range('B4').values[0][0])
        credit=float(_value(updated['07'],year))
        books.cell(file,'Drivers_Base',f'{col}9',credit*other)
        books.cell(file,'Drivers_Base',f'{col}11',-credit*(1+other)*deferred)
        from motor_47 import provision_plan, provision_stock
        # La previsión física utiliza fórmulas; la validación usa el mismo plan.
        plan=provision_plan(file)
        expected=-provision_stock(plan,year,credit*(1+other))
        spot=books.sheet(file,'Drivers_Base').get_range(f'{col}10')
        if not spot.formulas[0][0]:
            raise ValueError(f'M47/{year}: se perdió la fórmula de provisiones acumuladas')
        value=spot.values[0][0]
        if not isinstance(value,(int,float)) or abs(value-expected)>TOL:
            raise ValueError(f'M47/{year}: provisiones en Excel {value} vs input IASC {expected}')
        for address,mid in [(f'{col}19','47_interbancario_pasivo')]:
            books.cell(file,'Drivers_Base',address,_value(updated[mid],year))
        actual=books.sheet(file,'Anual').get_range(f'B{year-2023}').values[0][0]
        bank=books.sheet(file,'Balance').get_range(f'{col}4').values[0][0]
        control=books.sheet(file,'Balance').get_range(f'{col}41').values[0][0]
        if any(not isinstance(x,(int,float)) for x in (actual,bank,control)):
            raise ValueError(f'M47/{year}: resultado no numérico')
        if (abs(actual-_value(updated['47'],year))>TOL or
            abs(bank-_value(updated['47_bancos'],year))>TOL or abs(control)>TOL):
            raise ValueError(f'M47/{year}: drivers no concilian con identidad SBS: A={actual}, Banco={bank}, Control={control}.')


def _monthly_flow_closing(books, file, root, account, model, *, repeat_missing):
    """Actualiza meses fuente sin reemplazar la fórmula anual aprobada."""
    import gzip, json
    from persistencia_mensual import month_key
    closing=_annual(model).get(2026,{})
    month=str(closing.get('sourceMonth',''))[:7]
    if not month.startswith('2026-'):
        return
    with gzip.open(Path(root).parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz','rt',encoding='utf-8') as stream:
        panel=json.load(stream)['series']
    accounts=account if isinstance(account,dict) else {account:1}
    def accumulated(key):
        values=[(panel.get(code,{}).get('05',{}).get(key),weight) for code,weight in accounts.items()]
        if any(not isinstance(value,(int,float)) for value,_ in values):
            return None
        return sum(float(value)*weight for value,weight in values)
    last=int(month[-2:])
    rows=books.data(file,'Mensual',350,'C')
    index={month_key(row[0]):i for i,row in enumerate(rows,1) if row and row[0] is not None}
    latest=None
    for m in range(1,last+1):
        key=f'2026-{m:02d}'
        current=accumulated(key)
        prior=0.0 if m==1 else accumulated(f'2026-{m-1:02d}')
        if not isinstance(current,(int,float)) or not isinstance(prior,(int,float)):
            raise ValueError(f'{model.get("id","Flujo SBS")}: falta acumulado mensual de {key}')
        if key not in index:
            position=max(index.values(),default=1)+1
            books.cell(file,'Mensual',f'A{position}',key)
            index[key]=position
        latest=float(current)-float(prior)
        previous_label=str(rows[index[key]-1][2] or '') if index[key]<=len(rows) else ''
        replace_assumed=any(label in previous_label.lower() for label in ('supuest','pendiente'))
        books.cell(file,'Mensual',f'B{index[key]}',latest,allow_formula=replace_assumed)
        books.cell(file,'Mensual',f'C{index[key]}','Observado')
    if repeat_missing:
        for m in range(last+1,13):
            key=f'2026-{m:02d}'
            if key not in index:
                raise ValueError(f'Falta la fila supuesta de {key}: {file.name}')
            formula=books.sheet(file,'Mensual').get_range(f'B{index[key]}').formulas[0][0]
            if formula:
                books.formula(file,'Mensual',f'B{index[key]}',f'=$B${index[month]}')
            else:
                books.cell(file,'Mensual',f'B{index[key]}',latest)
            books.cell(file,'Mensual',f'C{index[key]}','Supuesto')


def _credit_income(books, folder, original, updated, changes):
    """Publica la MCO aprobada M13 + dos COVID y la identidad B=D*C/100."""
    current=updated['16_creditos']
    params=current.get('coefficients',[])
    if len(params)!=4:raise ValueError('M16: faltan cuatro coeficientes de la MCO.')
    alpha,beta,gamma,delta=(float(p['value']) for p in params)
    for variant in ('Input/Base_modelo.xlsx','Output/Pronostico.xlsx'):
        file=folder/variant;pos=_row_indices(books.data(file))
        for year in sorted(changes['16_creditos']):
            if year not in pos:raise ValueError(f'M16: falta {year} en {variant}')
            row=pos[year]
            rate=_value(updated['13'],year)
            avg=(_value(updated['07'],year-1)+_value(updated['07'],year))/2
            books.cell(file,'Anual',f'D{row}',float(avg))
            books.cell(file,'Anual',f'E{row}',float(rate))
            if year==2026:
                tasa=100*_value(current,year)/avg
                books.cell(file,'Anual',f'B{row}',float(_value(current,year)))
                books.cell(file,'Anual',f'C{row}',float(tasa))
            elif variant.startswith('Output'):
                # En pronóstico 2027–2030 las variables COVID tienen valor cero.
                books.formula(file,'Anual',f'C{row}',f'={alpha:.15g}+({beta:.15g})*E{row}')
                formula=books.sheet(file).get_range(f'B{row}').formulas[0][0]
                if not formula:raise ValueError('M16: se perdió la fórmula B=D*C/100.')
                got=books.sheet(file).get_range(f'B{row}').values[0][0]
                if not isinstance(got,(int,float)) or abs(float(got)-_value(current,year))>TOL:
                    raise ValueError(f'M16 {year}: Excel {got} no concilia con cálculo {_value(current,year)}.')
            else:
                books.cell(file,'Anual',f'B{row}',float(_value(current,year)))
                books.cell(file,'Anual',f'C{row}',float(100*_value(current,year)/avg))


def _tax(books,folder,previous,updated,changes):
    path=folder/'Input'/'Base_modelo.xlsx'
    annual=books.data(path)
    pos=_row_indices(annual)
    for y in sorted(changes['28']):
        if y not in pos:raise ValueError(f'M28 no tiene {y}')
        row=pos[y]
        if y>=2026:
            rate=annual[row-1][2]
            if not isinstance(rate,(int,float)) or rate<=0:
                raise ValueError('M28: falta tasa de impuestos')
            books.cell(path,'Anual',f'D{row}',_value(updated['28'],y)/float(rate))
            computed=books.sheet(path).get_range(f'B{row}').values[0][0]
            if abs(float(computed)-_value(updated['28'],y))>TOL:
                raise ValueError(f'Impuesto M28 no concilia en {y}')
        else:books.cell(path,'Anual',f'B{row}',_value(updated['28'],y))
    for kind in ('Consolidado.xlsx','Output/Pronostico.xlsx'):
        file=folder/kind
        _write_series(books,file,previous['28'],updated['28'],changes['28'],required=True)


def _receivables_source_input(books,file,root,model):
    """Avanza la columna del mes comparable, manteniendo el cierre del notebook."""
    import gzip,json,statistics
    closing=_annual(model).get(2026,{})
    latest=str(closing.get('sourceMonth',''))[:7]
    if not latest.startswith('2026-'):return
    month=latest[-2:]
    with gzip.open(Path(root).parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz','rt',encoding='utf-8') as stream:
        series=json.load(stream)['series']['balance:032']['05']
    required=[f'{year}-{month}' for year in range(2021,2027)]
    if any(not isinstance(series.get(period),(int,float)) for period in required):
        raise ValueError('M32: falta el mes comparable para el cierre mediano aprobado')
    expected=series[latest]+statistics.median(series[f'{year}-12']-series[f'{year}-{month}'] for year in range(2021,2026))
    if abs(float(closing['value'])-expected)>TOL:
        raise ValueError('M32: cierre no coincide con la fuente y sus cinco diferencias históricas')
    for year,row in _row_for_year(books,file).items():
        period=f'{year}-{month}'
        if year<=2026 and period in series:books.cell(file,'Anual',f'G{row}',float(series[period]))
    books.cell(file,'Anual','G1',f'Rendimientos mes {month} (S/ MM)')
    books.cell(file,'Anual','A19',f'Cierre 2026: saldo SBS {latest} + mediana de diferencias diciembre/mes 2021–2025.')


def _receivables(books,folder,previous,updated,changes):
    model=updated['32']
    coeff=model.get('coefficients',[])
    if len(coeff)<2:raise ValueError('M32: faltan los parámetros MCO.')
    alpha,beta=float(coeff[0]['value']),float(coeff[1]['value'])
    file=folder/'Output'/'Pronostico.xlsx'
    rows=_row_for_year(books,file)
    for year in range(2026,2031):
        if year not in rows:raise ValueError(f'M32: falta {year} en Output')
        index=rows[year]
        books.cell(file,'Anual',f'E{index}',_value(updated['16_creditos'],year))
        if year==2026 and 2026 in changes.get('32',set()):
            # La regresión proyecta cambios respecto del cierre actualizado:
            # no utilizar el ancla congelada del Excel anterior.
            books.cell(file,'Anual',f'B{index}',_value(model,year))
            books.cell(file,'Anual',f'C{index}',_value(model,year)-_value(model,2025))
        if year>=2027:
            books.formula(file,'Anual',f'G{index}',f'={alpha:.15g}+({beta:.15g})*F{index}')
            got=books.sheet(file).get_range(f'B{index}').values[0][0]
            exp=_value(model,year)
            if not isinstance(got,(int,float)) or abs(float(got)-exp)>TOL:
                raise ValueError(f'M32: pronóstico físico no cuadra en {year}: {got} vs {exp}')
    input_file=folder/'Input'/'Base_modelo.xlsx'
    if input_file.is_file():
        if 2026 in changes.get('32',set()):
            _receivables_source_input(books,input_file,books.root,model)
        rows=_row_for_year(books,input_file)
        for year in range(2026,2031):
            if year in rows:books.cell(input_file,'Anual',f'C{rows[year]}',_value(updated['16_creditos'],year))


def _mco_ahorro(books, root, original, updated, changes):
    """Reconstruye las tablas MCO/HAC de ahorro sin alterar sus plantillas."""
    for mid in ('08_mn','08_me'):
        old=original[mid].get('coefficients',[])
        new=updated[mid].get('coefficients',[])
        if len(old)==len(new) and all(abs(float(a['value'])-float(b['value']))<1e-9
                                        for a,b in zip(old,new)):
            continue
        folder=_folder_for(original[mid],root,root)
        if folder is None:raise ValueError(f'{mid}: carpeta de origen no encontrada.')
        file=folder/'Output'/'Resultados_MCO.xlsx'
        if not file.is_file():raise ValueError(f'{mid}: no existe Resultados_MCO.xlsx.')
        snap=updated[mid].get('mcoSnapshot')
        if not snap:raise ValueError(f'{mid}: faltan las estimaciones y diagnósticos MCO.')
        inp=folder/'Input'/'Base_modelo.xlsx'
        out=folder/'Output'/'Pronostico.xlsx'
        rows_in=_row_for_year(books,inp)
        rows_out=_row_for_year(books,out)
        # Los coeficientes están incorporados en las fórmulas del Output.
        # Regenerarlas, conservando fórmulas, permite recalcular la cadena.
        for year in sorted(changes.get(mid,set())):
            if year<=2026:
                for target_file,where in ((inp,rows_in),(out,rows_out)):
                    index=where[year]
                    books.cell(target_file,'Anual',f'B{index}',_value(updated[mid],year))
                    # Los indicadores "Condición" existentes se preservan.
        beta=[float(p) for p in snap['mco']['params']]
        for year in range(2027,2031):
            row=rows_out[year]
            prev=row-1
            if mid=='08_mn':
                expr=(f'=B{prev}*(1+(({beta[0]:.16g})+({beta[1]:.16g})*D{row}+'
                      f'({beta[2]:.16g})*E{row}+({beta[3]:.16g})*F{row})/100)')
            else:
                expr=f'=B{prev}*EXP((({beta[0]:.16g})+({beta[1]:.16g})*D{row})/100)'
            books.formula(out,'Anual',f'B{row}',expr)
            got=books.sheet(out).get_range(f'B{row}').values[0][0]
            if not isinstance(got,(int,float)) or abs(float(got)-float(_value(updated[mid],year)))>TOL:
                raise ValueError(f'{mid}/{year}: proyección MCO no coincide con el cálculo.')
        for sheet,name in (('MCO','mco'),('HAC','hac')):
            result=snap[name]
            for j,(coef,se,t,p,ci) in enumerate(zip(result['params'],result['stderr'],
                                                     result['tvalues'],result['pvalues'],result['ci']),12):
                for col,value in zip('BCDEFG',(coef,se,t,p,ci[0],ci[1])):
                    books.cell(file,sheet,f'{col}{j}',float(value))
            for row,value in {4:snap['nobs'],5:snap['r2'],6:snap['adjusted_r2'],
                              7:snap['aic'],8:snap['bic'],9:snap['dw']}.items():
                books.cell(file,sheet,f'B{row}',float(value))


def _cierres_sbs_especiales(books, root, previous, updated, changes, observations):
    """Reconstruye cierres con imputación estacional desde cuentas SBS mensuales."""
    selected={'24','26','27'} & set(changes)
    selected={mid for mid in selected if 2026 in changes[mid]}
    if not selected:return
    import gzip, json, statistics
    file=root.parent/'Scraper'/'EEFF_Benchmark'/'output'/'panel_eeff_16_bancos.json.gz'
    if not file.is_file():
        raise ValueError('Falta panel SBS necesario para actualizar cierres estacionales')
    with gzip.open(file,'rt',encoding='utf-8') as stream:
        panel=json.load(stream)
    series=panel['series']
    def source(account, period):
        value=series.get(f'er_acumulado:{account}',{}).get('05',{}).get(period)
        if not isinstance(value,(float,int)) or not math.isfinite(value):
            raise ValueError(f'Falta dato SBS {account}/{period} para cierre estacional')
        return float(value)
    for mid in sorted(selected):
        raw=(observations or {}).get('sbs_contable',{}).get(mid,{}).get('2026')
        if not isinstance(raw,dict):
            raise ValueError(f'{mid}: falta origen de cuenta SBS para 2026')
        month=str(raw.get('sourceMonth',''))[:7]
        if not month.startswith('2026-') or not 8<=int(month[5:])<=12:
            raise ValueError(f'{mid}: mes SBS no válido {month}')
        folder=_folder_for(previous[mid],root,root)
        inp=folder/'Input'/'Base_modelo.xlsx'
        out=folder/'Output'/'Pronostico.xlsx'
        cons=folder/'Consolidado.xlsx'
        snap=updated[mid]
        val=_value(snap,2026)
        if mid=='24':
            annual=books.data(inp)
            year_idx=_row_indices(annual)
            out_idx=_row_for_year(books,out)
            cons_idx=_row_for_year(books,cons)
            for year in range(2022,2027):
                at=source(153,f'{year}-{month[5:]}')
                books.cell(inp,'Anual',f'C{year_idx[year]}',at)
                books.cell(out,'Anual',f'C{out_idx[year]}',at)
                books.cell(cons,'Anual',f'D{cons_idx[year]}',at)
                if year < 2026:
                    total=_value(updated[mid],year)
                    books.cell(inp,'Anual',f'D{year_idx[year]}',total/at)
            for kind,file,cell in [('Output',out,f'E{out_idx[2026]}'),('Consolidado',cons,f'B{cons_idx[2026]}')]:
                got=books.sheet(file).get_range(cell).values[0][0]
                if not isinstance(got,(float,int)) or abs(float(got)-val)>TOL:
                    raise ValueError(f'M24 {kind}: fórmula de cierre 2026 no coincide con SBS ({got} vs {val})')
        elif mid=='26':
            row=_row_for_year(books,inp)[2026]
            dep=source(151,month);amort=source(152,month)
            for year,index in ((2023,20),(2024,21),(2025,22)):
                dep_tail=source(151,f'{year}-12')-source(151,f'{year}-{month[5:]}')
                amort_tail=source(152,f'{year}-12')-source(152,f'{year}-{month[5:]}')
                books.cell(inp,'Anual',f'B{index}',dep_tail)
                books.cell(inp,'Anual',f'C{index}',amort_tail)
            books.cell(inp,'Anual',f'F{row}',dep)
            books.cell(inp,'Anual',f'G{row}',amort)
            result=books.sheet(inp).get_range(f'D{row}').values[0][0]
            if not isinstance(result,(float,int)) or abs(result-val)>TOL:
                raise ValueError(f'M26: proyección 2026 por subcuentas no concilia ({result} vs {val})')
        elif mid=='27':
            row=_row_for_year(books,inp)[2026]
            def val27(period):return source(145,period)-source(151,period)-source(152,period)
            books.cell(inp,'Anual',f'I{row}',val27(month))
            for year,col in ((2023,'J'),(2024,'K'),(2025,'L')):
                tail=val27(f'{year}-12')-val27(f'{year}-{month[5:]}')
                books.cell(inp,'Anual',f'{col}{row}',tail)
            result=books.sheet(inp).get_range(f'G{row}').values[0][0]
            if not isinstance(result,(float,int)) or abs(result-val)>TOL:
                raise ValueError(f'M27: proyección 2026 por meses pendientes no concilia ({result} vs {val})')
        if mid in {'26','27'}:
            for file in (cons,out):
                index=_row_for_year(books,file)[2026]
                books.cell(file,'Anual',f'B{index}',val)
        # Las notas existentes identifican el período del cierre, sin añadir hojas.
        if mid=='26':
            books.cell(inp,'Anual','F1',f'Real a {month}')
            books.cell(inp,'Anual','G1',f'Real a {month}')
            books.cell(inp,'Anual','H1','Meses pendientes: depreciación')
            books.cell(inp,'Anual','I1','Meses pendientes: amortización')
            books.cell(inp,'Anual','B19','Meses pendientes: depreciación')
            books.cell(inp,'Anual','C19','Meses pendientes: amortización')
            books.cell(inp,'Anual','J12',f'Promedio 2023–2025 de meses pendientes desde {month}')
        elif mid=='27':
            books.cell(inp,'Anual','I1',f'Real a {month}')
            for year,col in ((2023,'J'),(2024,'K'),(2025,'L')):
                books.cell(inp,'Anual',f'{col}1',f'Pendiente {year}')
            books.cell(inp,'Anual','M1','Meses pendientes estimados')
            books.cell(inp,'Anual','N12',f'Promedio 2023–2025 de meses pendientes desde {month}')
        if raw.get('status')=='observed':
            if mid=='24':
                books.cell(inp,'Anual',f'F{_row_for_year(books,inp)[2026]}','Observado SBS')
                books.cell(out,'Anual',f'F{_row_for_year(books,out)[2026]}','Observado SBS')
                books.cell(cons,'Anual',f'C{_row_for_year(books,cons)[2026]}','Observado SBS')
            else:
                r=_row_for_year(books,inp)[2026]
                books.cell(inp,'Anual',f'{"E" if mid=="26" else "H"}{r}','Observado SBS')
                for file in (cons,out):
                    books.cell(file,'Anual',f'C{_row_for_year(books,file)[2026]}','Observado SBS')






def _disponible_mensual(books,root,previous,updated,changes,monthly_changes=None):
    """Añade observados y conserva la constante aprobada de 2021–2025."""
    from persistencia_mensual import month_key
    for mid,dirname in (('17_canje','03_Canje'),('17_otros','04_Otros_disponibles')):
        if mid not in changes and mid not in (monthly_changes or {}):continue
        folder=_folder_for(previous[mid],root,root)
        if folder is None or folder.name!=dirname:raise ValueError(f'M17: ruta incorrecta para {mid}')
        inp=folder/'Input/Base_modelo.xlsx';out=folder/'Output/Pronostico.xlsx'
        input_data=books.data(inp,'Mensual',350,'C')
        output_data=books.data(out,'Mensual',350,'I')
        indices={month_key(row[0]):i for i,row in enumerate(input_data,1) if row and row[0] is not None}
        positions={month_key(row[0]):i for i,row in enumerate(output_data,1) if row and row[0] is not None}
        import statistics
        constant=statistics.median(_value(updated[mid],y) for y in range(2021,2026))
        books.cell(out,'Mensual','I2',constant)
        for row in updated[mid].get('monthly',[]):
            period=month_key(row.get('date'))
            if period<'2026-09':continue
            if period not in positions:raise ValueError(f'M17: falta {period} en Output de {mid}')
            location=positions[period]
            if row['status']=='observed':
                if period not in indices:
                    indices[period]=max(indices.values(),default=1)+1
                    books.cell(inp,'Mensual',f'A{indices[period]}',period)
                books.cell(inp,'Mensual',f'B{indices[period]}',float(row['value']))
                books.cell(inp,'Mensual',f'C{indices[period]}','Observado')
                books.cell(out,'Mensual',f'B{location}',float(row['value']),allow_formula=True)
                books.cell(out,'Mensual',f'C{location}','Observado')
            else:
                books.formula(out,'Mensual',f'B{location}','=$I$2')
        for y in changes.get(mid,set()):
            loc=_row_for_year(books,out)[y]
            value=books.sheet(out,'Anual').get_range(f'B{loc}').values[0][0]
            if not isinstance(value,(int,float)) or abs(float(value)-_value(updated[mid],y))>TOL:
                raise ValueError(f'M17/{mid}/{y}: saldo anual no concilia')


def _otras_cuentas_contables(books, root, previous, updated, changes):
    """Reconstruye fórmulas de cierre de FSD e inversiones con sus factores."""
    if '18_fsd' in changes:
        folder=_folder_for(previous['18_fsd'],root,root)
        inp=folder/'Input'/'Base_modelo.xlsx'
        out=folder/'Output'/'Pronostico.xlsx'
        closing=_value(updated['18_fsd'],2026)
        obligations=_value(updated['10'],2026)
        if not obligations or obligations<=0:raise ValueError('FSD: obligaciones 2026 no válidas')
        ratio=closing/obligations
        for file in (inp,out):
            pos=_row_for_year(books,file)
            for y in range(2026,2031):
                row=pos[y]
                books.cell(file,'Anual',f'C{row}',_value(updated['10'],y))
                if y==2026:
                    books.cell(file,'Anual',f'B{row}',closing)
                elif file==inp:
                    books.cell(file,'Anual',f'B{row}',_value(updated['18_fsd'],y))
                if file==inp or y==2026:
                    books.cell(file,'Anual',f'D{row}',ratio)
    if '21_venta' in changes:
        folder=_folder_for(previous['21_venta'],root,root)
        inp=folder/'Input'/'Base_modelo.xlsx'
        out=folder/'Output'/'Pronostico.xlsx'
        b=_value(updated['21_venta'],2026)
        books.cell(inp,'Anual','B12',b)
        factor=books.sheet(out,'Parametros').get_range('B5').values[0][0]
        if not isinstance(factor,(int,float)) or factor==0:raise ValueError('M21: factor estacional no válido')
        books.cell(out,'Parametros','B4',b/factor)
    if '21_asociadas' in changes:
        folder=_folder_for(previous['21_asociadas'],root,root)
        inp=folder/'Input'/'Base_modelo.xlsx'
        out=folder/'Output'/'Pronostico.xlsx'
        b=_value(updated['21_asociadas'],2026)
        books.cell(inp,'Anual','B12',b)
        factor=books.sheet(out,'Parametros').get_range('B3').values[0][0]
        if not isinstance(factor,(int,float)) or factor==0:raise ValueError('M21: factor estacional no válido')
        books.cell(out,'Parametros','B2',b/factor)
    if '22_interbancarios' in changes:
        folder=_folder_for(previous['22_interbancarios'],root,root)
        cons=folder.parent/'Consolidado.xlsx'
        books.cell(cons,'Anual','E12',_value(updated['22_interbancarios'],2026))
        books.cell(folder/'Output'/'Pronostico.xlsx','Anual','C12',_value(updated['22_interbancarios'],2026))

def _otras_operaciones(books, root, previous, updated, changes, observations):
    """Propaga los cierres SBS a las fórmulas existentes de ROF."""
    components={
        '20_derivados':('04_Derivados_de_negociacion','B2','B3'),
        '20_inversiones':('05_Inversiones','B2',None),
        '20_otros':('06_Otros_y_venta_cartera','B4',None),
    }
    for mid,(sub,param,fac) in components.items():
        if mid not in changes:continue
        folder=_folder_for(previous[mid],root,root)
        if folder is None or folder.name!=sub:
            raise ValueError(f'M20: directorio distinto al esperado para {mid}')
        inp=folder/'Input'/'Base_modelo.xlsx';out=folder/'Output'/'Pronostico.xlsx'
        if 2026 in changes[mid]:
            raw=(observations or {}).get('sbs_contable',{}).get(mid,{}).get('2026')
            month=str(raw.get('sourceMonth','2026-08'))[:7] if isinstance(raw,dict) else '2026-08'
            if not month.startswith('2026-') or int(month[-2:]) not in range(1,13):
                raise ValueError(f'M20: fecha SBS no válida: {month}')
            factor=12/int(month[-2:]) if fac else 1.0
            books.cell(out,'Parametros',param,_value(updated[mid],2026)/factor)
            if fac:books.cell(out,'Parametros',fac,factor)
            books.cell(inp,'Anual','C12',_value(updated[mid],2026)/factor)
        if mid=='20_derivados':
            books.formula(out,'Parametros','B4','=MEDIAN(B6:B8)')
        elif mid=='20_inversiones':
            books.formula(out,'Parametros','B6','=MEDIAN(B3:B5)')
        for year in changes[mid]:
            row=year-2014
            got=books.sheet(out).get_range(f'B{row}').values[0][0]
            if not isinstance(got,(float,int)) or abs(float(got)-_value(updated[mid],year))>TOL:
                raise ValueError(f'M20 {mid}/{year}: resultado de fórmula ({got}) no coincide con motor')

def _mco_cambiario(books, root, previous, updated, changes, observations):
    """FX y derivados desde relación 2026 con compras M03, sin tendencia temporal."""
    if not {'20_tc','03','20_derivados'}.intersection(changes):
        return
    folder=_folder_for(previous['20_tc'],root,root)
    if folder is None:
        raise ValueError('M20: directorio de diferencia de cambio no disponible')
    inp=folder/'Input'/'Base_modelo.xlsx'
    out=folder/'Output'/'Pronostico.xlsx'
    year0=2026
    ratio=(_value(updated['20_tc'],year0)+_value(updated['20_derivados'],year0))/_value(updated['03'],year0)
    if not math.isfinite(ratio) or ratio<0:
        raise ValueError('M20: ratio FX/operaciones inválido')
    if 2026 in changes.get('20_tc', set()):
        detail = (observations or {}).get('sbs_contable', {}).get('20_tc', {}).get('2026', {})
        month = str(detail.get('sourceMonth', '2026-08'))[:7]
        if not month.startswith('2026-') or not month[-2:].isdigit() or not 1 <= int(month[-2:]) <= 12:
            raise ValueError('M20: mes de origen cambiario no válido.')
        factor = 12 / int(month[-2:])
        books.cell(inp,'Anual','C12',_value(updated['20_tc'],2026)/factor)
        books.cell(out, 'Parametros', 'B2', _value(updated['20_tc'], 2026) / factor)
        books.cell(out, 'Parametros', 'B3', factor)
    books.cell(out, 'Anual', 'C12', _value(updated['20_derivados'], 2026))
    books.formula(out,'Parametros','B26','=(B9+Anual!C12)/B27')
    for y in range(2026,2031):
        r=27+(y-2026)
        books.cell(out,'Parametros',f'B{r}',_value(updated['03'],y))
        if y>=2027:
            books.cell(out,'Anual',f'C{y-2014}',_value(updated['20_derivados'],y))
    for y in range(2027,2031):
        row=y-2014
        got=books.sheet(out,'Anual').get_range(f'B{row}').values[0][0]
        exp=_value(updated['20_tc'],y)
        if not isinstance(got,(int,float)) or abs(got-exp)>TOL:
            raise ValueError(f'M20/{y}: FX por volumen {got} no concilia con {exp}')

def _mco_inversiones_disponibles(books,root,original,updated,changes):
    # M21 pasa a ser presupuesto exogeno. Actualizar solo cierres observados.
    mid='21_venta'
    if mid not in changes:return
    folder=_folder_for(original[mid],root,root)
    for path in (folder/'Input'/'Base_modelo.xlsx',folder/'Output'/'Pronostico.xlsx'):
        rows=_row_for_year(books,path)
        if 2026 in changes.get(mid,set()):
            books.cell(path,'Anual',f'C{rows[2026]}',_value(updated[mid],2026))
            if path.name=='Base_modelo.xlsx':
                books.cell(path,'Anual',f'B{rows[2026]}',_value(updated[mid],2026))
    # Los importes de 2027-2030 son decisiones presupuestarias inalteradas.


def _mco_inversiones(books,root,original,updated,changes):
    # M16 inversiones: proyeccion con saldo medio M21 x rendimiento persistente.
    mid='16_inversiones'
    if mid not in changes:return
    folder=_folder_for(original[mid],root,root)
    for name in ('Input/Base_modelo.xlsx','Output/Pronostico.xlsx'):
        path=folder/name
        rows=_row_for_year(books,path)
        # El cierre 2026 es el ancla del rendimiento; actualizarlo incluso
        # cuando solo hayan cambiado 2027+ ingresos por inversiones.
        for year in sorted(set(changes.get(mid,set())) | {2026}):
            if year<2026 or year not in rows:continue
            prev=_value(updated['21_venta'],year-1)
            curr=_value(updated['21_venta'],year)
            if prev is None or curr is None:raise ValueError(f'M16: falta M21 AFS {year}')
            books.cell(path,'Anual',f'G{rows[year]}',(prev+curr)/2)
            if year==2026:
                books.cell(path,'Anual',f'B{rows[year]}',_value(updated[mid],year))
            if name.startswith('Output') and year>=2027:
                books.cell(path,'Anual',f'F{rows[year]}','Pronosticado')
                valor=books.sheet(path,'Anual').get_range(f'B{rows[year]}').values[0][0]
                esperado=_value(updated[mid],year)
                if not isinstance(valor,(int,float)) or abs(valor-esperado)>1e-4:
                    raise ValueError(f'M16 inversiones {year}: {valor} no concilia con {esperado}')


def _mco_gastos_financieros(books, root, original, updated, changes):
    """Reestima y persiste las cuentas MCO de gastos por intereses."""
    targets={'12_entidades':'log005','12_adeudos':'level','12_otras':'log1p'}
    for mid, mode in targets.items():
        if mid not in changes:continue
        folder=_folder_for(original[mid],root,root)
        inp=folder/'Input'/'Base_modelo.xlsx'
        out=folder/'Output'/'Pronostico.xlsx'
        inrows=_row_for_year(books,inp)
        outrows=_row_for_year(books,out)
        for y in sorted(changes[mid]):
            value=_value(updated[mid],y)
            index=outrows[y]
            books.cell(out,'Anual',f'B{index}',value)
            if mode!='level':
                cvalue=math.log(value+0.05) if mode=='log005' else math.log1p(value)
                books.cell(out,'Anual',f'C{index}',cvalue)
            if y==2026:
                i=inrows[y]
                books.cell(inp,'Anual',f'B{i}',value)
                if mode!='level':books.cell(inp,'Anual',f'C{i}',cvalue)
        old=original[mid].get('coefficients',[])
        new=updated[mid].get('coefficients',[])
        if len(old)==len(new) and all(abs(float(a['value'])-float(b['value']))<1e-9 for a,b in zip(old,new)):
            continue
        snap=updated[mid].get('mcoSnapshot')
        if not snap:raise ValueError(f'{mid}: faltan resultados MCO/HAC')
        file=folder/'Output'/'Resultados_MCO.xlsx'
        m=snap['mco'];h=snap['hac']
        for j in range(len(m['params'])):
            for col,val in {'B':m['params'][j],'C':m['stderr'][j],
                            'D':m['pvalues'][j],'E':h['stderr'][j],
                            'F':h['pvalues'][j]}.items():
                books.cell(file,'Coeficientes',f'{col}{j+2}',float(val))
        for row,val in {3:snap['nobs'],4:snap['adjusted_r2'],
                        5:snap['aic'],6:snap['dw']}.items():
            books.cell(file,'Diagnostico',f'B{row}',float(val))


def _mco_plazo(books, root, original, updated, changes):
    """Persiste MCO y gestión IASC de plazo; ambos permanecen auditables.

    La gestión no es regresión ni techo regulatorio. 2026 es cierre
    estacional; 2027–28 = MCO escenario + desviación de gestión publicada,
    y 2029–30 heredan solo la tasa macro MCO desde el último saldo.
    """
    import json
    cfg_file=Path(root).parent/'Control_Supuestos'/'plan_captaciones_iasc.json'
    cfg=json.loads(cfg_file.read_text(encoding='utf-8')) if cfg_file.exists() else None
    for mid in ('09_plazo','09_cts'):
        if mid not in changes:
            continue
        folder=_folder_for(original[mid],root,root)
        if folder is None:
            raise ValueError(f'{mid}: carpeta no encontrada')
        inp=folder/'Input'/'Base_modelo.xlsx'
        out=folder/'Output'/'Pronostico.xlsx'
        rows_in=_row_for_year(books,inp)
        rows_out=_row_for_year(books,out)
        for year in sorted(changes[mid]):
            if year==2026:
                books.cell(inp,'Anual',f'B{rows_in[year]}',_value(updated[mid],year))
                books.cell(out,'Anual',f'B{rows_out[year]}',_value(updated[mid],year))
                if mid=='09_plazo':
                    prior=_value(updated[mid],year-1)
                    growth=100*(_value(updated[mid],year)/prior-1)
                    books.cell(out,'Anual',f'C{rows_out[year]}',growth)
                    books.cell(inp,'Anual',f'G{rows_in[year]}','Cierre supuesto')
                    # Registrar en Input todos los meses supuestos septiembre-diciembre.
                    monthly=updated[mid].get('monthly',[])
                    records={str(x.get('date',''))[:7]:x for x in monthly}
                    input_rows=books.data(inp,'Mensual',220,'D')
                    for ri,row in enumerate(input_rows,1):
                        key=str(row[0])[:7]
                        if key not in records or not key.startswith('2026-'):continue
                        item=records[key]
                        if item.get('status') not in ('assumed','observed'):continue
                        books.cell(inp,'Mensual',f'B{ri}',float(item['value']))
                        prior_value=records.get(f'2026-{int(key[-2:])-1:02d}',{}).get('value')
                        if prior_value is not None:
                            books.cell(inp,'Mensual',f'C{ri}',float(item['value'])/float(prior_value)-1)
                        books.cell(inp,'Mensual',f'D{ri}','Observado SBS' if item.get('status')=='observed' else 'Cierre supuesto')
        beta=[float(x['value']) for x in updated[mid]['coefficients']]
        if len(beta)!=(4 if mid=='09_plazo' else 2):
            raise ValueError(f'{mid}: número de regresores MCO no válido')
        if mid=='09_plazo' and cfg:
            import motor
            base= motor.macro_base_state()
            state=(base.get('changes') or {}) if isinstance(base,dict) else {}
            # El driver anual se actualiza según el escenario Base oficialmente aplicado.
            # En la hoja Output, D[t]=PBI[t-1], E[t]=inflación[t-1], F[t]=delta TPM[t].
            rows_input=_row_for_year(books,inp)
            original_macro={int(y):row for y,row in [(x[0],x) for x in books.data(inp,'Anual',40,'G')
                                        if isinstance(x[0],(int,float)) and 2015<=int(x[0])<=2030]}
            def m(var,year,col):
                override=state.get(var,{})
                val=override.get(str(year),override.get(year)) if isinstance(override,dict) else None
                if val is not None:return float(val)
                return float(original_macro[year][col])
            for y in range(2026,2031):
                r=rows_input[y]
                for col,var,idx in [('C','pbi',2),('D','inflacion',3),('E','tpm',4)]:
                    if state.get(var,{}).get(str(y)) is not None:
                        books.cell(inp,'Anual',f'{col}{r}',m(var,y,idx))
            for y in range(2027,2031):
                rr=rows_out[y]
                books.cell(out,'Anual',f'D{rr}',m('pbi',y-1,2))
                books.cell(out,'Anual',f'E{rr}',m('inflacion',y-1,3))
                books.cell(out,'Anual',f'F{rr}',m('tpm',y,4)-m('tpm',y-1,4))
            # Dos columnas auxiliares explícitas, sin nueva hoja y sin tocar
            # la estructura original de las columnas A:G.
            books.cell(out,'Anual','H1','MCO sin plan (S/ MM)')
            books.cell(out,'Anual','I1','Ajuste de gestión BF (S/ MM)')
            r2026=rows_out[2026]
            for y in range(2027,2031):
                annual_y=rows_out[y]
                item=cfg.get('plan_plazo_ordinario',{}).get(str(y))
                prior=f'B{r2026}' if y==2027 else f'H{annual_y-1}'
                growth=(f'(({beta[0]:.16g})+({beta[1]:.16g})*D{annual_y}+'
                        f'({beta[2]:.16g})*E{annual_y}+'
                        f'({beta[3]:.16g})*F{annual_y})/100')
                books.formula(out,'Anual',f'H{annual_y}',f'={prior}*(1+{growth})')
                if item:
                    books.cell(out,'Anual',f'I{annual_y}',float(item['ajuste_plan']))
                    formula=f'=H{annual_y}+I{annual_y}'
                else:
                    books.cell(out,'Anual',f'I{annual_y}',0)
                    formula=f'=B{annual_y-1}*(H{annual_y}/H{annual_y-1})'
                books.formula(out,'Anual',f'B{annual_y}',formula)
                got=books.sheet(out).get_range(f'B{annual_y}').values[0][0]
                expected=_value(updated[mid],y)
                if not isinstance(got,(float,int)) or abs(float(got)-expected)>TOL:
                    raise ValueError(f'{mid}/{y}: Excel {got} no concilia con motor {expected}')
        else:
            for y in range(2027,2031):
                row=rows_out[y]
                if mid=='09_plazo':
                    formula=(f'=B{row-1}*(1+(({beta[0]:.16g})+({beta[1]:.16g})*D{row}+'
                             f'({beta[2]:.16g})*E{row}+({beta[3]:.16g})*F{row})/100)')
                else:
                    formula=f'=B{row-1}*(1+(({beta[0]:.16g})+({beta[1]:.16g})*D{row})/100)'
                books.formula(out,'Anual',f'B{row}',formula)
                got=books.sheet(out).get_range(f'B{row}').values[0][0]
                if not isinstance(got,(float,int)) or abs(float(got)-_value(updated[mid],y))>TOL:
                    raise ValueError(f'{mid}/{y}: resultado físico {got} y proyección {_value(updated[mid],y)} no concilian')
        old=original[mid].get('coefficients',[])
        changed_coefs=(len(old)!=len(beta) or any(abs(float(p['value'])-v)>1e-9 for p,v in zip(old,beta)))
        if not changed_coefs:
            continue
        snap=updated[mid].get('mcoSnapshot')
        if not snap:raise ValueError(f'{mid}: sin resultados MCO/HAC recalculados')
        file=folder/'Output'/'Resultados_MCO.xlsx'
        for sh,key in (('MCO','mco'),('HAC','hac')):
            result=snap[key]
            for row,(coef,se,t,p,ci) in enumerate(zip(result['params'],result['stderr'],
                                            result['tvalues'],result['pvalues'],result['ci']),12):
                for col,v in zip('BCDEFG',(coef,se,t,p,ci[0],ci[1])):
                    books.cell(file,sh,f'{col}{row}',float(v))
            for row,val in {4:snap['nobs'],5:snap['r2'],6:snap['adjusted_r2'],
                            7:snap['aic'],8:snap['bic'],9:snap['dw']}.items():
                books.cell(file,sh,f'B{row}',float(val))


def _mco_depositos(books, root, original, updated, changes):
    """Reproduce los Resultados_MCO de los encadenamientos de depósitos."""
    for mid in ('11','17_bancos'):
        old=original[mid].get('coefficients',[])
        new=updated[mid].get('coefficients',[])
        if len(old)==len(new) and all(abs(float(a['value'])-float(b['value']))<1e-9
                                        for a,b in zip(old,new)):
            continue
        snap=updated[mid].get('mcoSnapshot')
        if not snap:raise ValueError(f'{mid}: falta el ajuste MCO/HAC.')
        folder=_folder_for(original[mid],root,root)
        file=folder/'Output'/'Resultados_MCO.xlsx'
        m=snap['mco'];h=snap['hac']
        if mid=='11':
            for i in range(len(m['params'])):
                for col,v in {'B':m['params'][i],'C':m['pvalues'][i],
                              'D':h['pvalues'][i]}.items():
                    books.cell(file,'Coeficientes',f'{col}{i+2}',float(v))
            for row,val in {3:snap['nobs'],5:snap['adjusted_r2'],6:snap['rmse']}.items():
                books.cell(file,'Resumen',f'B{row}',float(val))
            continue
        for i in range(len(m['params'])):
            for col,v in {'B':m['params'][i], 'C':m['stderr'][i],
                          'D':m['pvalues'][i],'E':h['stderr'][i],
                          'F':h['pvalues'][i]}.items():
                books.cell(file,'Coeficientes',f'{col}{i+2}',float(v))
        for row,val in {3:snap['nobs'],4:snap['adjusted_r2']}.items():
            books.cell(file,'Diagnostico',f'B{row}',float(val))


def _mco_caja_sbs(books, root, previous, updated, changes):
    """Reconstruye la MCO mensual original de Caja con meses SBS aplicados.

    Nunca cambia el dato fuente ni imputa PBI mensual. Usa solo la serie
    observada de caja y deja los pronósticos mensuales en fórmulas Excel.
    """
    import gzip, json
    import numpy as np
    import statsmodels.api as sm
    if '17_caja' not in changes:
        return set()
    model = updated['17_caja']
    snap = model.get('mcoSnapshot')
    coeff = model.get('coefficients') or []
    if not snap or len(coeff)!=2:
        raise ValueError('M17 Caja: faltan coeficientes o diagnóstico actualizado.')
    folder=_folder_for(previous['17_caja'],root,root)
    inp=folder/'Input'/'Base_modelo.xlsx'
    out=folder/'Output'/'Pronostico.xlsx'
    stats=folder/'Output'/'Resultados_MCO.xlsx'
    panel_path=root.parent/'Scraper'/'EEFF_Benchmark'/'output'/'panel_eeff_16_bancos.json.gz'
    with gzip.open(panel_path,'rt',encoding='utf-8') as f:
        panel=json.load(f)
    all_sbs=panel.get('series',{}).get('balance:001',{}).get('05',{})
    months=books.data(inp,'Mensual',400,'C')
    historical={str(r[0])[:7]:float(r[1]) for r in months if isinstance(r[0],str)
                and isinstance(r[1],(int,float)) and str(r[0])[:7]>='2016-01'}
    previously_observed=sorted(historical)
    first=previously_observed[-1]
    source=next((r.get('sourceMonth') for r in model['annual'] if r['year']==2026),None)
    last=str(source or first)[:7]
    if not first<=last<='2030-12':
        raise ValueError('M17 Caja: fecha SBS no válida para actualizar la MCO.')
    for month,val in sorted(all_sbs.items()):
        if first<month<=last and isinstance(val,(int,float)) and math.isfinite(val):
            historical[month]=float(val)
    dates=sorted(historical)
    # Reproducir exactamente la ventana del motor: empieza en 2017-02.
    nums=np.array([historical[d] for d in dates],float)
    if len(nums)<30:raise ValueError('M17 Caja: muestra histórica insuficiente.')
    fit=sm.OLS(nums[13:],np.array([[1.,nums[i-1]] for i in range(13,len(nums))])).fit()
    rob=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
    if max(abs(float(fit.params[i])-float(coeff[i]['value'])) for i in range(2))>1e-5:
        raise ValueError('M17 Caja: coeficientes publicados no coinciden con la regresión.')
    for year_month in sorted(d for d in historical if d>first):
        # El bloque Input es histórico observado; Output contiene la fórmula
        # para las fechas futuras, que se reemplaza solamente al observar el mes.
        for file in (inp,out):
            idx={str(r[0])[:7]:i for i,r in enumerate(books.data(file,'Mensual',400,'C'),1)
                 if isinstance(r[0],str) and len(str(r[0]))>=7}
            if year_month not in idx:
                if file != inp:
                    raise ValueError(f'M17 Caja: el Output no contempla el mes {year_month}.')
                r=max(idx.values())+1
                previous_month = max(idx)
                from datetime import date
                a,b=map(int,year_month.split('-'))
                expected=f'{a-1}-12' if b==1 else f'{a}-{b-1:02d}'
                if previous_month != expected:
                    raise ValueError(f'M17 Caja: falta mes intermedio entre {previous_month} y {year_month}.')
                books.cell(inp,'Mensual',f'A{r}',year_month)
            else:
                r=idx[year_month]
            books.cell(file,'Mensual',f'B{r}',historical[year_month],allow_formula=True)
            books.cell(file,'Mensual',f'C{r}','Observado SBS')
    books.cell(out,'Mensual','I2',float(fit.params[0]))
    books.cell(out,'Mensual','I3',float(fit.params[1]))
    for i in range(2):
        for col,val in {'B':fit.params[i],'C':fit.bse[i],'D':fit.pvalues[i],
                        'E':rob.bse[i],'F':rob.pvalues[i]}.items():
            books.cell(stats,'Coeficientes',f'{col}{i+2}',float(val))
    books.cell(stats,'Diagnostico','B2',f'2017-02–{last}')
    books.cell(stats,'Diagnostico','B3',float(fit.nobs))
    books.cell(stats,'Diagnostico','B4',float(fit.rsquared_adj))
    for year in (2021,2022,2023,2024,2025):
        november=f'{year}-11';december=f'{year}-12'
        if november not in historical or december not in historical:continue
        real=historical[december]
        pred=float(fit.params[0]+fit.params[1]*historical[november])
        row=year-2019
        books.cell(stats,'Validacion',f'C{row}',pred)
        books.cell(stats,'Validacion',f'E{row}',abs(real-pred))
    errs=[books.sheet(stats,'Validacion').get_range(f'E{year-2019}').values[0][0]
          for year in (2021,2022,2023,2024,2025)]
    books.cell(stats,'Diagnostico','B5',float(sum(errs)/len(errs)))
    # La fórmula del modelo debe reconstruir exactamente diciembre y el cierre
    # anual, sin copiar valores sobre los pronósticos formulados.
    for y in range(2026,2031):
        annual_index={int(r[0]):i for i,r in enumerate(books.data(out,'Anual',22,'C'),1)
                      if isinstance(r[0],(int,float))}
        got=books.sheet(out,'Anual').get_range(f'B{annual_index[y]}').values[0][0]
        if not isinstance(got,(int,float)) or abs(float(got)-_value(model,y))>TOL:
            raise ValueError(f'M17 Caja/{y}: cierre anual no concilia con la trayectoria mensual actualizada.')
    return {'17_caja'}


def _mco_ingresos_16(books, root, previous, updated, changes):
    """Persiste la MCO reestimada de ingresos por disponibilidades e interbancarios.

    Actualiza las tablas y los coeficientes de las fórmulas originales sin pegar
    importes sobre celdas formuladas ni cambiar la distribución Input/Output.
    """
    import numpy as np
    import statsmodels.api as sm
    specs = {
        '16_disponible': ('03_Disponibilidades', 3),
        '16_interbancarios': ('04_Interbancarios', 2),
    }
    supported = set()
    for mid, (sub, ncoeff) in specs.items():
        if mid not in changes:
            continue
        model = updated[mid]
        snap = model.get('mcoSnapshot')
        coeff = model.get('coefficients') or []
        if not snap or len(coeff) != ncoeff:
            raise ValueError(f'{mid}: no se recibieron coeficientes y diagnósticos de MCO/HAC.')
        folder = _folder_for(previous[mid], root, root)
        inp = folder / 'Input' / 'Base_modelo.xlsx'
        out = folder / 'Output' / 'Pronostico.xlsx'
        stats_file = folder / 'Output' / 'Resultados_MCO.xlsx'
        if not all(p.is_file() for p in (inp, out, stats_file)):
            raise ValueError(f'{mid}: faltan los libros originales para registrar la reestimación.')
        values = {year: _value(model, year) for year in range(2016, 2031)}
        old_input = books.data(inp, 'Anual', 25, 'F')
        source_rows = _row_indices(old_input)
        import motor
        state=(motor.macro_base_state().get('changes') or {})
        pbi_overrides=state.get('pbi',{}) if mid=='16_disponible' else {}
        def input_driver(y,row):
            return float(pbi_overrides.get(str(y),row[3])) if mid=='16_disponible' else float(row[3])
        sample = list(range(2017, 2027))
        X = []
        for y in sample:
            row = old_input[source_rows[y]-1]
            X.append([1., input_driver(y,row), math.log(values[y-1])] if mid == '16_disponible'
                     else [1., float(row[3])])
        Y = [math.log(values[y]) for y in sample]
        fit = sm.OLS(np.asarray(Y, float), np.asarray(X, float)).fit()
        robust = fit.get_robustcov_results(cov_type='HAC', maxlags=1, use_t=True)
        if max(abs(float(fit.params[i])-float(coeff[i]['value'])) for i in range(ncoeff)) > 1e-6:
            raise ValueError(f'{mid}: las estimaciones de la MCO no coinciden con el motor.')
        for y in range(2026, 2031):
            for file in (inp, out):
                rows = _row_for_year(books, file)
                r = rows[y]
                if mid=='16_disponible' and str(y) in pbi_overrides:
                    books.cell(file,'Anual',f'D{r}',float(pbi_overrides[str(y)]))
                if y == 2026:
                    books.cell(file, 'Anual', f'B{r}', values[y])
                    books.cell(file, 'Anual', f'C{r}', math.log(values[y]))
                    if mid == '16_disponible':
                        books.cell(file, 'Anual', f'E{r}', math.log(values[y-1]))
                elif file == out:
                    expr = (f'={float(fit.params[0]):.15g}+({float(fit.params[1]):.15g})*D{r}+'
                            f'({float(fit.params[2]):.15g})*LN(B{r-1})') if mid == '16_disponible' else (
                            f'={float(fit.params[0]):.15g}+({float(fit.params[1]):.15g})*D{r}')
                    books.formula(out, 'Anual', f'C{r}', expr)
                    if mid == '16_disponible':
                        books.cell(out, 'Anual', f'E{r}', math.log(values[y-1]))
                    calc = books.sheet(out,'Anual').get_range(f'B{r}').values[0][0]
                    if not isinstance(calc,(int,float)) or abs(float(calc)-values[y]) > TOL:
                        raise ValueError(f'{mid}/{y}: el pronóstico no coincide con la fórmula MCO.')
        for i in range(ncoeff):
            for col, value in {'B':fit.params[i], 'C':fit.bse[i], 'D':fit.pvalues[i],
                               'E':robust.bse[i], 'F':robust.pvalues[i]}.items():
                books.cell(stats_file, 'Coeficientes', f'{col}{i+2}', float(value))
        for row, val in {3:fit.nobs, 4:fit.rsquared_adj, 5:fit.aic,
                         6:sm.stats.stattools.durbin_watson(fit.resid)}.items():
            books.cell(stats_file, 'Diagnostico', f'B{row}', float(val))
        errors = []
        for y in (2023,2024,2025):
            xi = X[sample.index(y)]
            estimate = math.exp(float(np.dot(fit.params, xi)))
            errors.append(abs(values[y]-estimate))
            idx = {2023:2,2024:3,2025:4}[y]
            for col,val in {'C':estimate,'D':abs(values[y]-estimate)}.items():
                books.cell(stats_file,'Validacion',f'{col}{idx}',float(val))
        books.cell(stats_file,'Diagnostico','B7',float(sum(errors)/len(errors)))
        supported.add(mid)
    return supported


def _mco_resultados(books,root,previous,updated,changes):
    """Mantiene los dos Excel previstos en Output y las tablas de regresión."""
    import numpy as np
    import statsmodels.api as sm
    from statsmodels.stats.stattools import durbin_watson
    for mid in ('16_creditos','31','32'):
        if mid not in changes:continue
        old=previous[mid].get('coefficients',[])
        new=updated[mid].get('coefficients',[])
        if len(new)<2:raise ValueError(f'MCO {mid}: parámetros incompletos.')
        if len(old)>=2 and all(abs(float(old[i]['value'])-float(new[i]['value']))<1e-9 for i in range(2)):
            continue
        folder=_folder_for(previous[mid],root,root)
        path=folder/'Output'/'Resultados_MCO.xlsx'
        if mid=='16_creditos':
            inputs=books.data(folder/'Input'/'Base_modelo.xlsx')
            indexed=_row_indices(inputs)
            x=[];y=[]
            for year in range(2016,2027):
                entry=inputs[indexed[year]-1]
                avg=(_value(updated['07'],2025)+_value(updated['07'],2026))/2 if year==2026 else float(entry[3])
                yy=100*_value(updated[mid],year)/avg if year==2026 else float(entry[2])
                x.append([1.,_value(updated['13'],year),float(year==2020),float(year==2021)])
                y.append(yy)
            fit=sm.OLS(np.asarray(y,float),np.asarray(x,float)).fit()
            hac=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
            if len(new)!=4 or any(abs(float(fit.params[i])-float(new[i]['value']))>1e-5 for i in range(4)):
                raise ValueError('M16: parámetros del motor no coinciden con la MCO reestimada.')
            for i in range(4):
                row=i+2
                for c,v in {'B':fit.params[i],'C':fit.bse[i], 'D':fit.pvalues[i],
                            'E':hac.bse[i],'F':hac.pvalues[i]}.items():
                    books.cell(path,'Coeficientes',f'{c}{row}',float(v))
            for row,v in {3:fit.nobs,4:fit.rsquared_adj,5:fit.aic,6:durbin_watson(fit.resid),
                          9:y[-1]-float(np.dot(fit.params,x[-1]))}.items():
                books.cell(path,'Diagnostico',f'B{row}',float(v))
        if mid=='31':
            import math
            x=[];y=[]
            inp=books.data(folder/'Input'/'Base_modelo.xlsx')
            years=_row_indices(inp)
            for year in range(2017,2027):
                if year not in years: raise ValueError(f'M31: falta {year} en Input')
                value=_value(updated['31'],year)
                prior=_value(updated['31'],year-1)
                if value<=0 or prior<=0:raise ValueError('M31: saldos no positivos para MCO log')
                y.append(100*math.log(value/prior))
                x.append([1.,float(inp[years[year]-1][2])])
            fit=sm.OLS(np.asarray(y,float),np.asarray(x,float)).fit()
            hac=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
            if any(abs(float(fit.params[i])-float(new[i]['value']))>1e-5 for i in range(2)):
                raise ValueError('M31: coeficientes del motor diferentes de reestimación.')
            for i in range(2):
                row=i+2
                for c,v in {'B':fit.params[i],'C':hac.bse[i],'D':hac.tvalues[i],
                            'E':hac.pvalues[i]}.items():
                    books.cell(path,'Coeficientes',f'{c}{row}',float(v))
            for row,v in {2:fit.nobs,3:fit.rsquared,4:fit.rsquared_adj}.items():
                books.cell(path,'Diagnostico',f'B{row}',float(v))
        if mid=='32':
            x=[];y=[]
            for year in range(2017,2027):
                y.append(_value(updated['32'],year)-_value(updated['32'],year-1))
                x.append([1.,_value(updated['16_creditos'],year)-_value(updated['16_creditos'],year-1)])
            fit=sm.OLS(np.asarray(y,float),np.asarray(x,float)).fit()
            hac=fit.get_robustcov_results(cov_type='HAC',maxlags=1,use_t=True)
            if any(abs(float(fit.params[i])-float(new[i]['value']))>1e-5 for i in range(2)):
                raise ValueError('M32: coeficientes del motor diferentes de reestimación.')
            for i in (0,1):
                row=i+2
                for c,v in {'B':fit.params[i],'C':hac.bse[i], 'D':hac.tvalues[i],
                            'E':hac.pvalues[i]}.items():
                    books.cell(path,'Coeficientes',f'{c}{row}',float(v))
            for row,v in {2:fit.nobs,3:fit.rsquared,4:fit.rsquared_adj}.items():
                books.cell(path,'Diagnostico',f'B{row}',float(v))
            books.cell(path,'Diagnostico','B9','2017–2026')


def _m23(books, root, original, updated, changes):
    base=_folder_for(original['23'],root,root)
    if base is None:raise ValueError('No se encontró el Modelo 23.')
    cbase=base/'Consolidado.xlsx'
    data=books.data(cbase)
    pos=_row_indices(data)
    years=set().union(*(changes.get(key,set()) for key in ('12','16','18_fsd','20_consorcios','20_tc','20_derivados','23')))
    def delta(key,y):return _value(updated[key],y)-_value(original[key],y)
    for y in sorted(years):
        row=pos[y]
        if any(y in changes.get(k,set()) for k in ('16',)):
            books.cell(cbase,'Anual',f'B{row}',_value(updated['16'],y))
        if any(y in changes.get(k,set()) for k in ('20_tc','20_derivados')):
            books.cell(cbase,'Anual',f'C{row}',float(data[row-1][2])+delta('20_tc',y)+delta('20_derivados',y))
        if y in changes.get('12',set()):books.cell(cbase,'Anual',f'E{row}',_value(updated['12'],y))
        if y in changes.get('18_fsd',set()):books.cell(cbase,'Anual',f'F{row}',_value(updated['18_fsd'],y))
        if y in changes.get('20_consorcios',set()):
            books.cell(cbase,'Anual',f'G{row}',float(data[row-1][6])-delta('20_consorcios',y))
    # Mantener las tablas de respaldo que sirven como insumo de la consolidación.
    spec = [
        ('01_Ingresos_por_intereses',{'16_creditos':'B','16_inversiones':'C','16_disponible':'D','16_interbancarios':'E'}),
        ('02_Otros_ingresos_financieros',{'20_tc':'D','20_derivados':'E'}),
        ('03_Gastos_por_intereses',{'12_obligaciones':'B','12_entidades':'C','12_adeudos':'E','12_otras':'H'}),
        ('04_Primas_FSD',{'18_fsd':'B'}),
    ]
    for sub,mapping in spec:
        relevant={k:v for k,v in mapping.items() if k in changes}
        if not relevant:continue
        for kind in ('Input/Base_modelo.xlsx','Output/Pronostico.xlsx'):
            p=base/sub/kind
            if not p.is_file():raise ValueError(f'Archivo M23 inexistente {p}')
            pos=_row_for_year(books,p)
            for mid,col in relevant.items():
                for y in changes[mid]:
                    if y not in pos:raise ValueError(f'No figura {y} en {p}')
                    address=f'{col}{pos[y]}'
                    form=books.sheet(p).get_range(address).formulas[0][0]
                    if mid=='20_derivados' and form and 'MEDIAN' in form.upper():
                        # Mediana fija 2023–2025 del notebook y del Input v18.
                        books.formula(p,'Anual',address,'=MEDIAN($E$11:$E$13)')
                        got=books.sheet(p).get_range(address).values[0][0]
                        if not isinstance(got,(int,float)) or abs(float(got)-_value(updated[mid],y))>TOL:
                            raise ValueError(f'M23 derivados/{y}: mediana no concilia')
                    else:
                        books.cell(p,'Anual',address,_value(updated[mid],y))


def _m29(books, root, previous, updated, changes):
    if not (set(changes)&{'29','28','23','25','18','19','24','26','27'}):return
    base=_folder_for(previous['29'],root,root)
    if base is None:raise ValueError('No se encontró el Modelo 29.')
    p23=_folder_for(previous['23'],root,root)/'Consolidado.xlsx'
    p18=_folder_for(previous['18'],root,root)/'Consolidado.xlsx'
    c23=books.data(p23);i23=_row_indices(c23)
    c18=books.data(p18);i18=_row_indices(c18)
    years=sorted(set().union(*(changes.get(k,set()) for k in ('29','28','23','25','18','19','24','26','27'))))
    for kind in ('Input/Base_modelo.xlsx','Consolidado.xlsx','Output/Pronostico.xlsx'):
        book=base/kind
        if not book.is_file():raise ValueError(f'Archivo M29 no encontrado: {book}')
        pos=_row_for_year(books,book,'Insumos')
        for y in years:
            if y not in pos:raise ValueError(f'M29/Ins {y} inexistente')
            if y == 2026 and kind != 'Output/Pronostico.xlsx':
                for mid,cell in (('25','Q4'),('26','Q11'),('27','Q15')):
                    if y not in changes.get(mid,set()):continue
                    old=books.sheet(book,'Insumos').get_range(cell).values[0][0]
                    if not isinstance(old,(int,float)):
                        raise ValueError(f'M29: insumo 2026 {cell} no numérico.')
                    books.cell(book,'Insumos',cell,float(old)+_value(updated[mid],y)-_value(previous[mid],y))
            src23=c23[i23[y]-1];src18=c18[i18[y]-1]
            vals={
                'B':float(books.sheet(p23,'Anual').get_range(f'D{i23[y]}').values[0][0]),
                'C':float(books.sheet(p23,'Anual').get_range(f'H{i23[y]}').values[0][0]),
                'D':_value(updated['25'],y),
                'E':float(books.sheet(p18,'Anual').get_range(f'D{i18[y]}').values[0][0]),
                'F':float(books.sheet(p18,'Anual').get_range(f'H{i18[y]}').values[0][0]),
                'H':_value(updated['19'],y),
                'I':_value(updated['26'],y),
                'J':_value(updated['27'],y),
                'K':_value(updated['24'],y),
                'L':_value(updated['28'],y),
            }
            for col,val in vals.items():
                address=f'{col}{pos[y]}'
                form=books.sheet(book,'Insumos').get_range(address).formulas[0][0]
                if col=='L' and y>=2027 and form:
                    # El impuesto se deriva de la UAI, no se congela ni sobrescribe.
                    continue
                books.cell(book,'Insumos',address,float(val))
    # El pronóstico final se alimenta del P&L con fórmulas, nunca se inventan
    # valores de partidas independientes ni se reemplazan esas fórmulas.
    p_input=base/'Input'/'Base_modelo.xlsx'
    formula=books.sheet(p_input,'P&L SBS')
    outputs=[base/'Consolidado.xlsx',base/'Output'/'Pronostico.xlsx']
    years_header=formula.get_range('A1:P1').values[0]
    for y in years:
        col=next((i+1 for i,v in enumerate(years_header) if isinstance(v,(int,float)) and int(v)==y),None)
        if col is None:raise ValueError(f'Falta encabezado {y} P&L')
        addr=_cell_col(col)
        entries=formula.get_range(f'{addr}2:{addr}18').values
        for i,item in enumerate(entries,2):
            if not isinstance(item[0],(int,float)) or not math.isfinite(float(item[0])):
                raise ValueError(f'M29/2026-2030 fórmula incompleta: {addr}{i}')
            for destination in outputs:
                address=f'{addr}{i}'
                cell=books.sheet(destination,'P&L SBS').get_range(address)
                form=cell.formulas[0][0]
                if form:
                    got=cell.values[0][0]
                    if not isinstance(got,(int,float)) or abs(float(got)-float(item[0]))>TOL:
                        raise ValueError(f'M29/{y}: fórmula {address} desactualizada en {destination.name}')
                else:
                    books.cell(destination,'P&L SBS',address,float(item[0]))
        final=float(entries[-1][0]);expected=float(_value(updated['29'],y))
        if abs(final-expected)>TOL:
            raise ValueError(f'M29 {y}: cálculo P&L {final:.6f} vs motor {expected:.6f}')


def _graph(path, model):
    import matplotlib
    matplotlib.use('Agg')
    from matplotlib import pyplot as plt
    annual=[r for r in model.get('annual',[]) if 2016<=int(r['year'])<=2030]
    if not annual:return
    known=[r for r in annual if int(r['year'])<=2026]
    forecast=[r for r in annual if int(r['year'])>=2026]
    if not known or not forecast:return
    fig,ax=plt.subplots(figsize=(12.0,4.85),dpi=135)
    ax.plot([r['year'] for r in known],[r['value'] for r in known],marker='o',linewidth=2.2,label='Observado y cierre 2026')
    ax.plot([r['year'] for r in forecast],[r['value'] for r in forecast],marker='s',linestyle='--',linewidth=2.3,label='Proyección')
    ax.axvline(2026.5,linestyle=':',linewidth=1.1,alpha=.5)
    ax.grid(axis='y',alpha=.22)
    ax.set_title(model.get('name','Pronóstico'),fontweight='bold')
    ax.set_xlabel('Año');ax.set_ylabel(model.get('unit',''))
    ax.legend(loc='upper left',frameon=False)
    fig.tight_layout()
    output=path.with_name(path.name+'.writing')
    try:
        fig.savefig(output,format='png')
        os.replace(output,path)
    finally:
        if output.exists():output.unlink()
        plt.close(fig)


def _write_mercado_amortizaciones(books, root, updated, changes):
    """Publica M48/M49 con el mismo perímetro y escenario del motor.

    No modifica los modelos históricos 01–47 ni reemplaza fórmulas existentes.
    Las tasas de los Excel son fracciones; el motor las muestra en porcentaje.
    """
    affected = set(changes) & {'48','48_cuota','49','49_rev','49_nrev',
        '49_compras','49_desembolsos','49_tasa_rev','49_tasa_nrev','49_disposiciones_rc'}
    if not affected:
        return
    def spot(mid,year):
        return _value(updated[mid],year)
    from rutas import buscar_modelo
    f48=buscar_modelo(root,'48')/'Output'/'Pronostico.xlsx'
    f49=buscar_modelo(root,'49')/'Output'/'Pronostico.xlsx'
    rr48=_row_for_year(books,f48)
    rr49=_row_for_year(books,f49)
    # No alteramos los años históricos, que siguen siendo observados.
    for y in range(2026,2031):
        r=rr48[y]
        market=spot('48',y)
        prev=spot('48',y-1)
        bf_rev=spot('05',y)
        bf_nonrev=spot('06',y)
        values={'C':market,'D':100*math.log(market/prev),
                'H':bf_rev,'I':bf_nonrev,'J':bf_rev+bf_nonrev,
                'K':spot('48_cuota',y)/100.0}
        for col,value in values.items():
            books.cell(f48,'Anual',f'{col}{r}',value)
        r=rr49[y]
        rev=spot('05',y);nonrev=spot('06',y)
        buys=spot('49_compras',y)
        disb=spot('49_desembolsos',y)
        disp_rc=spot('49_disposiciones_rc',y)
        a_rev=spot('49_rev',y);a_nonrev=spot('49_nrev',y)
        # Recuperar castigos residualmente del mismo balance contable.
        k_rev=spot('05',y-1)+buys+disp_rc-rev-a_rev
        k_nonrev=spot('06',y-1)+disb-nonrev-a_nonrev
        values={'C':buys,'D':rev,'E':k_rev,'F':a_rev,
                'G':spot('49_tasa_rev',y)/100.0,
                'H':disb,'I':nonrev,'J':k_nonrev,'K':a_nonrev,
                'L':spot('49_tasa_nrev',y)/100.0,'M':disp_rc}
        for col,value in values.items():
            books.cell(f49,'Anual',f'{col}{r}',value)


def _apertura_creditos(books, root, updated, changes):
    """Sincroniza la apertura de ingresos con el total M16, sin tocar fórmulas."""
    if '16_creditos' not in changes:
        return
    file = (Path(root) / 'Estado de Resultados' /
            '16_Ingresos_por_intereses_Falabella' /
            '05_Apertura_Revolving_No_Revolving' / 'Output' / 'Pronostico.xlsx')
    rows = _row_for_year(books, file, 'Apertura')
    for year in range(2026, 2031):
        books.cell(file, 'Apertura', f'B{rows[year]}', _value(updated['16_creditos'], year))


def _cierres_fuente_inputs(books,root,previous,updated,changes):
    """Conserva las reglas explícitas de Cierre_2026 al avanzar el mes SBS."""
    import gzip,json,statistics
    specifications={
        '18_diversos':('er_acumulado:131','interanual'),
        '18_otros_ing':('er_acumulado:129','lineal'),
        '18_gastos_div':('er_acumulado:136','lineal'),
        '18_otros_gastos':('er_acumulado:133','lineal'),
        '18_fsd':('er_acumulado:120','lineal'),
        '19_personal':('er_acumulado:140','mediana'),
        '19_directorio':('er_acumulado:141','mediana'),
        '19_terceros':('er_acumulado:142','mediana'),
        '19_impuestos':('er_acumulado:143','mediana'),
        '21_asociadas':('balance:010','stock_mediano'),
    }
    selected={mid:spec for mid,spec in specifications.items() if 2026 in changes.get(mid,set())}
    if not selected:return
    with gzip.open(Path(root).parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz','rt',encoding='utf-8') as stream:
        panel=json.load(stream)['series']
    for mid,(account,rule) in selected.items():
        month=str(_annual(updated[mid])[2026].get('sourceMonth',''))[:7]
        if not month.startswith('2026-'):continue
        source=panel[account]['05']
        def value(period):
            result=source.get(period)
            if not isinstance(result,(int,float)) or not math.isfinite(result):
                raise ValueError(f'{mid}: falta la fuente de {period}')
            return float(result)
        folder=_folder_for(previous[mid],root,root);inp=folder/'Input/Base_modelo.xlsx'
        number=int(month[-2:])
        if rule in ('lineal','interanual'):
            books.cell(inp,'Cierre_2026','B2',value('2025-'+month[-2:]))
            books.cell(inp,'Cierre_2026','C2',value(month))
            books.cell(inp,'Cierre_2026','B1',f'Mes {month[-2:]} 2025 (S/ MM)')
            books.cell(inp,'Cierre_2026','C1',f'Mes {month[-2:]} 2026 (S/ MM)')
            books.formula(inp,'Cierre_2026','D2',f'=C2*12/{number}' if rule=='lineal' else '=A2*C2/B2')
        elif rule=='mediana':
            for year,row in ((2023,2),(2024,3),(2025,4)):
                books.cell(inp,'Cierre_2026',f'B{row}',value(f'{year}-{month[-2:]}'))
                books.cell(inp,'Cierre_2026',f'C{row}',value(f'{year}-12'))
            books.cell(inp,'Cierre_2026','B6',value(month))
            books.formula(inp,'Cierre_2026','B7','=MEDIAN(D2:D4)')
            books.cell(inp,'Cierre_2026','B1',f'Mes {month[-2:]} (S/ MM)')
            books.cell(inp,'Cierre_2026','A6',f'Mes {month} (S/ MM)')
        else:
            factors=[]
            for year,row in ((2023,2),(2024,3),(2025,4)):
                current,december=value(f'{year}-{month[-2:]}'),value(f'{year}-12')
                if current==0:raise ValueError(f'{mid}: factor estacional con denominador cero')
                factor=december/current;factors.append(factor)
                books.cell(inp,'Cierre_2026',f'B{row}',current)
                books.cell(inp,'Cierre_2026',f'C{row}',december)
                books.cell(inp,'Cierre_2026',f'D{row}',factor)
            factor=statistics.median(factors)
            books.cell(inp,'Cierre_2026','B5',value(month))
            books.cell(inp,'Cierre_2026','C5',value(month)*factor)
            books.cell(inp,'Cierre_2026','D5',factor)
            out=folder/'Output/Pronostico.xlsx'
            books.cell(out,'Parametros','B2',value(month))
            books.cell(out,'Parametros','B3',factor)
            books.cell(out,'Parametros','A2',f'Saldo {month} SBS (S/ MM)')
            books.cell(out,'Parametros','A3',f'Mediana factor Dic/mes {month[-2:]} 2023–2025')


def generar(root, previous, updated, observations=None):
    """Escribe una copia completa y devuelve el número de libros/gráficos tocados.

    ``root`` es el directorio raíz de los modelos en la copia de validación.
    Solo las diferencias económicas o de condición se guardan.
    """
    root=Path(root)
    from persistencia_mensual import month_deltas, persistir, MODELS
    changes=_changed(previous,updated)
    month_changes=month_deltas(previous,updated)
    headcount=(observations or {}).get('trabajadores_falabella',{})
    if not changes and not month_changes and not headcount:
        return {'workbooks':0,'charts':0,'models':[], 'files':[]}
    financial_months={'12_obligaciones','12_entidades','12_adeudos','12_otras',
                      '16_creditos','16_inversiones','16_disponible','16_interbancarios'}
    unknown_months=set(month_changes)-MODELS-financial_months-{"17_caja", "17_canje", "17_otros", "10_restringidos", "10_otras", "09_plazo"}
    if unknown_months:
        raise ValueError('No hay ruta mensual física validada para: '+', '.join(sorted(unknown_months)))
    for mid, new_model in updated.items():
        if mid not in previous and mid in {'16_rev', '16_nrev'}:
            continue
        if mid in MODELS or mid in ('17_caja','16_disponible','16_interbancarios','19_terceros','16_creditos','32','19_personal','18_diversos','20_tc','08_mn','08_me','09_plazo','09_cts','17_bancos','11','12_entidades','12_adeudos','12_otras','16_inversiones','21_venta'):
            continue
        old_coef=previous[mid].get('coefficients',[])
        new_coef=new_model.get('coefficients',[])
        if len(old_coef)!=len(new_coef) or any(
            abs(float(a['value'])-float(b['value']))>1e-8
            for a,b in zip(old_coef,new_coef)
        ):
            folder=_folder_for(previous[mid],root,root)
            if folder and (folder/'Output'/'Resultados_MCO.xlsx').is_file():
                raise ValueError(f'{mid}: cambió la MCO sin regeneración validada de sus parámetros.')
    books=_Books(root)
    _cierres_fuente_inputs(books,root,previous,updated,changes)
    # Los ocho cierres financieros de v18 completan los meses restantes con
    # el último flujo mensual. Primero actualizar su fuente mensual; así se
    # conservan las fórmulas anuales originales, incluidas SUM/COUNT/INDEX.
    monthly_accounts={
        '12_obligaciones':{'er_acumulado:112':1},
        '12_entidades':{'er_acumulado:113':1},
        '12_adeudos':{'er_acumulado:115':1},
        '12_otras':{f'er_acumulado:{index}':1 for index in (114,116,117)},
        '16_creditos':{'er_acumulado:105':1},
        '16_inversiones':{'er_acumulado:104':1},
        '16_disponible':{'er_acumulado:102':1},
        '16_interbancarios':{'er_acumulado:103':1},
    }
    for mid,accounts in monthly_accounts.items():
        if 2026 in changes.get(mid,set()) or any(str(month).startswith('2026-') for month in month_changes.get(mid,{})):
            folder=_folder_for(previous[mid],root,root)
            _monthly_flow_closing(books,folder/'Input/Base_modelo.xlsx',root,accounts,
                                  updated[mid],repeat_missing=mid.startswith('12'))
    supported=persistir(books,previous,updated,root,changes,month_changes,observations)
    _apertura_creditos(books, root, updated, changes)
    supported.update(_mco_ingresos_16(books,root,previous,updated,changes))
    supported.update(_mco_caja_sbs(books,root,previous,updated,changes))
    _gastos_diversos_anuales(books,root,previous,updated,changes)
    _terceros_ponderados(books,root,previous,updated,changes)
    supported.update({'18_gastos_div','19_terceros'} & set(changes))
    _mco_ahorro(books,root,previous,updated,changes)
    _mco_plazo(books,root,previous,updated,changes)
    _mco_gastos_financieros(books,root,previous,updated,changes)
    _mco_inversiones(books,root,previous,updated,changes)
    _otras_operaciones(books,root,previous,updated,changes,observations)
    _disponible_mensual(books,root,previous,updated,changes,month_changes)
    _otras_cuentas_contables(books,root,previous,updated,changes)
    _mco_cambiario(books,root,previous,updated,changes,observations)
    _mco_inversiones_disponibles(books,root,previous,updated,changes)
    _cierres_sbs_especiales(books,root,previous,updated,changes,observations)
    _mco_depositos(books,root,previous,updated,changes)
    _saldos_m10_sbs(books,root,previous,updated,changes)
    _dependencias_depositos(books,root,previous,updated,changes,observations)
    _sincronizar_driver_m33(books,root,previous,updated,changes)
    _sincronizar_drivers_m38(books,root,previous,updated,changes)
    _sincronizar_drivers_m39(books,root,updated,changes)
    _sincronizar_drivers_m45(books,root,updated,changes)
    _sincronizar_drivers_m46(books,root,updated,changes)
    _sincronizar_drivers_m47(books,root,updated,changes)
    # M34 incluye una hoja de insumos de cartera que debe acompañar a M07.
    if '07' in changes or '34' in changes:
        from rutas import buscar_modelo
        f34=buscar_modelo(root,'34')/'Output'/'Pronostico.xlsx'
        by_year=_row_for_year(books,f34,'M07_Consumo')
        for y in range(2026,2031):
            books.cell(f34,'M07_Consumo',f'B{by_year[y]}',_value(updated['07'],y))
        ann34=_row_for_year(books,f34,'Anual')
        for y in range(2026,2031):
            got=books.sheet(f34,'Anual').get_range(f'B{ann34[y]}').values[0][0]
            if not isinstance(got,(int,float)) or abs(got-_value(updated['34'],y))>TOL:
                raise ValueError(f'M34/{y}: cartera M07 no concilia con el motor.')
        supported.add('34')
    if {'01','03','04','37'}.intersection(changes):
        from rutas import buscar_modelo
        f37=buscar_modelo(root,'37')/'Output'/'Pronostico.xlsx'
        r37=_row_for_year(books,f37,'Drivers_Base')
        for y in range(2026,2031):
            for col,mid in [('B','03'),('C','01'),('D','04')]:
                books.cell(f37,'Drivers_Base',f'{col}{r37[y]}',_value(updated[mid],y))
        a37=_row_for_year(books,f37,'Anual')
        for y in range(2026,2031):
            got=books.sheet(f37,'Anual').get_range(f'B{a37[y]}').values[0][0]
            if not isinstance(got,(int,float)) or abs(got-_value(updated['37'],y))>TOL:
                raise ValueError(f'M37/{y}: drivers de compras no concilian con el motor ({got} vs {_value(updated["37"],y)}).')
        supported.add('37')
    if {'19_personal','40'}.intersection(changes):
        from rutas import buscar_modelo
        f40=buscar_modelo(root,'40')/'Output'/'Pronostico.xlsx'
        r40=_row_for_year(books,f40,'Drivers_Base')
        for y in range(2026,2031):
            books.cell(f40,'Drivers_Base',f'D{r40[y]}',_value(updated['19_personal'],y))
        a40=_row_for_year(books,f40,'Anual')
        for y in range(2026,2031):
            got=books.sheet(f40,'Anual').get_range(f'B{a40[y]}').values[0][0]
            if not isinstance(got,(int,float)) or abs(got-_value(updated['40'],y))>TOL:
                raise ValueError(f'M40/{y}: fórmula de provisiones de pasivo no concilia.')
        supported.add('40')
    _saldo_bruto(books,root,previous,updated,changes)
    _personal_staff(books,root,previous,updated,changes,observations)
    _servicios_diversos(books,root,previous,updated,changes)
    _otros_servicios(books,root,previous,updated,changes)
    _consorcios(books,root,previous,updated,changes)
    _write_mercado_amortizaciones(books,root,updated,changes)
    # 1. Actualizar series que poseen fila anual explícita, sin alterar fórmulas.
    for mid in sorted(changes):
        if mid in supported or mid.startswith('48') or mid.startswith('49') or mid in {'16_rev','16_nrev','23','29','07','20_consorcios','18_diversos','19_personal','08_mn','08_me','09_plazo','09_cts','11','17_bancos','12_entidades','12_adeudos','12_otras','16_inversiones','21_venta','10_otras','10_restringidos','12_obligaciones','18_fsd','18_otros_ing','18_otros_gastos','20_tc','20_derivados','20_inversiones','20_otros','18_fsd','21_venta','21_asociadas','22_interbancarios','17_canje','17_otros','24','26','27','38','39','45','45_dividendos','45_utilidad_aplicada','46'} or mid.startswith('47') or mid in GROUPS or mid in {'10','22','30'}:
            continue
        folder=_folder_for(previous[mid],root,root)
        if folder is None:raise ValueError(f'No se encontró directorio del modelo {mid}.')
        if mid == '16_creditos':
            _credit_income(books,folder,previous,updated,changes)
            continue
        if mid == '28':
            _tax(books,folder,previous,updated,changes)
            continue
        if mid == '32':
            _receivables(books,folder,previous,updated,changes)
            continue
        files = [folder/'Output'/'Pronostico.xlsx',folder/'Input'/'Base_modelo.xlsx',folder/'Consolidado.xlsx']
        found=False
        for path in files:
            if not path.is_file():continue
            try: ok=_write_series(books,path,previous[mid],updated[mid],changes[mid],required=False)
            except ValueError:raise
            found |= ok
        if not found:raise ValueError(f'No existe una columna anual de importes identificable para {mid}')
    # 2. Reconstruir consolidados desde los componentes, sin tocar totales con fórmula.
    external_groups = {}
    for parent,mapping in GROUPS.items():
        if parent=='07':continue
        if not any(mid in changes for mid in mapping):continue
        path=_group_path(parent,root,previous)
        _write_group(books,path,parent,mapping,previous,updated,changes)
    # 3. El Modelo 23 y el P&L se concilian desde sus partidas de origen.
    if any(k in changes for k in ('16','12','18_fsd','20_tc','20_derivados','20_consorcios')):_m23(books,root,previous,updated,changes)
    # Releer los totales físicos, incluido el Output de los consolidados.
    for mid in ('07','08','09','10','12','16','17','18','19','20','21','22','30'):
        if mid not in changes:continue
        folder=_folder_for(previous[mid],root,root)
        if folder is None:continue
        path=folder/'Output'/'Pronostico.xlsx'
        if path.is_file():
            _write_series(books,path,previous[mid],updated[mid],changes[mid],required=False)
    if '30' in changes:
        folder=_folder_for(previous['30'],root,root)
        for file in (folder/'Consolidado.xlsx',folder/'Output/Pronostico.xlsx'):
            indices=_row_for_year(books,file)
            for year in range(2026,2031):
                if year not in indices:raise ValueError(f'M30: falta {year} en {file.name}')
                books.cell(file,'Anual',f'B{indices[year]}',_value(updated['30'],year))
            latest=str(_annual(updated['30']).get(2026,{}).get('sourceMonth',''))[:7]
            if latest:
                books.cell(file,'Trazabilidad','B3',f'Serie anual 2024–2030. SBS {latest}; cierre estacional vigente y proyección por líneas por tarjeta.')
    _m29(books,root,previous,updated,changes)
    _mco_resultados(books,root,previous,updated,changes)
    written=books.export()
    for parent, (path, mapping) in external_groups.items():
        if _write_group_external(path,parent,mapping,previous,updated,changes):
            written+=1
    charts=0
    for mid,years in {**changes, **{k: v for k,v in month_changes.items() if k not in changes}}.items():
        if mid == '29':
            folder=_folder_for(previous[mid],root,root)
        else:folder=_folder_for(previous[mid],root,root)
        if folder is None:continue
        chart=folder/'Output'/'Grafico_pronostico.png'
        if chart.is_file():
            _graph(chart,updated[mid]);charts+=1
    changed_files=sorted(set(books.dirty)|{entry[0] for entry in external_groups.values()}|{_folder_for(previous[mid],root,root)/'Output'/'Grafico_pronostico.png'
                    for mid in set(changes)|set(month_changes) if _folder_for(previous[mid],root,root) is not None and
                    (_folder_for(previous[mid],root,root)/'Output'/'Grafico_pronostico.png').is_file()})
    return {'workbooks':written,'charts':charts,'models':sorted(set(changes)|set(month_changes)),
            'files':[str(file.relative_to(root)) for file in changed_files]}


def _verify_layout(original, generated):
    """La publicación económica conserva estilos y distribución del libro."""
    with zipfile.ZipFile(original) as before, zipfile.ZipFile(generated) as after:
        for part in ('xl/styles.xml', 'xl/theme/theme1.xml'):
            if part in before.namelist() and (part not in after.namelist() or before.read(part) != after.read(part)):
                raise ValueError(f'La actualización altera formatos de {original.name}: {part}')
        ns = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
        for name in before.namelist():
            if not name.startswith('xl/worksheets/sheet') or not name.endswith('.xml'):
                continue
            if name not in after.namelist():
                raise ValueError(f'La actualización elimina una hoja: {original.name}')
            old, new = ET.fromstring(before.read(name)), ET.fromstring(after.read(name))
            def canonical(element):
                # Un cero explícito en el nivel de esquema equivale al valor
                # predeterminado; no representa un cambio visual de Excel.
                attrs = tuple(sorted((key,value) for key,value in element.attrib.items()
                                     if not (key in ('outlineLevelCol','outlineLevelRow') and value=='0')))
                return (element.tag, attrs, (element.text or '').strip(),
                        tuple(canonical(child) for child in element))
            structure = lambda root: [canonical(child) for child in root
                                      if child.tag not in (ns+'sheetData',ns+'dimension')]
            if structure(old) != structure(new):
                raise ValueError(f'La actualización altera la distribución de {original.name}: {name}')
            cells = {cell.get('r'): cell.get('s','0') for cell in new.iter(ns+'c')}
            for cell in old.iter(ns+'c'):
                if cell.get('r') in cells and cell.get('s','0') != cells[cell.get('r')]:
                    raise ValueError(f'La actualización altera el estilo de {original.name}: {cell.get("r")}')
            rows = {row.get('r'):row.attrib for row in new.iter(ns+'row')}
            for row in old.iter(ns+'row'):
                if row.get('r') in rows and row.attrib != rows[row.get('r')]:
                    raise ValueError(f'La actualización altera las filas de {original.name}: {row.get("r")}')


def aplicar_transaccion(source, previous, updated, loader, auditor, verificador, lock,
                        *, observations=None, state_updates=None):
    """Reconstruye, comprueba y publica los libros de una actualización.

    Se valida una copia de la carpeta IASPE. Si un modelo no dispone de ruta
    verificable, no se modifica ningún respaldo original.
    """
    from uuid import uuid4
    import json
    import motor

    source=Path(source)
    originals=source.parent
    with lock:
        with tempfile.TemporaryDirectory(prefix='iaspe_recalculo_') as temporary:
            stage=Path(temporary)/'IASPE'
            # En NTFS se admiten enlaces duros; si no, copia binaria ordinaria.
            def _linked(a,b):
                try:return os.link(a,b)
                except OSError:return shutil.copy2(a,b)
            shutil.copytree(originals,stage,copy_function=_linked)
            staged=stage/'Modelos financieros'
            effective = motor.latest_observations() if observations is None else observations
            summary=generar(staged,previous,updated,effective)
            for item in summary['files']:
                if str(item).lower().endswith('.xlsx'):
                    _verify_layout(source/item, staged/item)
            prior_source=motor.SOURCE
            try:
                motor.SOURCE=staged
                persisted=motor.load_base(refresh=True)[0]
                applied_base={}
                persisted_active,persist_warnings=motor._run(persisted,applied_base,effective)
                if persist_warnings:raise ValueError('Recalculo de respaldo con alertas: '+str(persist_warnings[:8]))
                reconciliation=verificador(staged)
                check=auditor(list(updated.values()),persisted_active)
            finally:
                motor.SOURCE=prior_source
                motor.load_base(refresh=True)
            if not reconciliation['passed'] or not check['passed']:
                details=(reconciliation.get('errors',[])[:8] if not reconciliation['passed'] else [])
                details+=(check.get('details',[])[:8] if not check['passed'] else [])
                raise ValueError('La reconstrucción física no concilia: '+' | '.join(map(str,details)))
            # Todos los libros quedan verificados antes del primer reemplazo.
            # Los originales se conservan en copias independientes para rollback.
            backup=Path(temporary)/'rollback'
            changes=[]
            try:
                for item in summary['files']:
                    rel=Path(item)
                    existing=source/rel
                    generated=staged/rel
                    if not generated.is_file() or not existing.is_file():
                        raise ValueError(f'Archivo de consolidación no localizado: {rel}')
                    safe=backup/rel
                    safe.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(existing,safe)
                    temporary_file=existing.with_name(existing.name+'.recalculando')
                    try:
                        shutil.copy2(generated,temporary_file)
                        os.replace(temporary_file,existing)
                    finally:
                        if temporary_file.exists():temporary_file.unlink()
                    changes.append((existing,safe))
                current=loader()
                current_active,final_warnings=motor._run(current,{},effective)
                if final_warnings:raise ValueError('Recalculo publicado con alertas: '+str(final_warnings[:8]))
                final_check=auditor(list(updated.values()),current_active)
                final_source=verificador(source)
                if not final_check['passed'] or not final_source['passed']:
                    raise ValueError('El escenario publicado difiere de los respaldos validados.')
                if state_updates:
                    states = dict(state_updates)
                    if previous and updated:
                        from historial_actualizacion import prepare
                        old_sources = {'automatic':motor.read_state('fuentes_aplicadas.json', motor.read_state('fuentes_iniciales.json', {})),
                                       'manual':motor.read_state('observaciones_aplicadas.json', {})}
                        new_sources = {'automatic':states.get('fuentes_aplicadas.json', old_sources['automatic']),
                                       'manual':states.get('observaciones_aplicadas.json', old_sources['manual'])}
                        states['historial_pronosticos.json'] = prepare(
                            motor.read_state('historial_pronosticos.json', {}), previous, updated,
                            previous_sources=old_sources, updated_sources=new_sources,
                            macro_base=motor.macro_base_state())
                    motor.write_states(states)
            except Exception:
                for target,backupfile in reversed(changes):
                    saved=target.with_name(target.name+'.restaurando')
                    shutil.copy2(backupfile,saved)
                    os.replace(saved,target)
                loader()
                raise
            summary.update(checks=check['checks'],reconciliations=reconciliation['checks'])
            return summary
