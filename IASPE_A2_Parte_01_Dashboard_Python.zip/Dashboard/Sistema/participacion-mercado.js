/* Participación SBS observada y cociente de los modelos activos 07/48. */
(()=>{
'use strict';
const $=selector=>document.querySelector(selector);
const MONTHS=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
const PEER_COLORS=['#43805a','#a47d51','#7a6d9b','#548397'];
const state={product:'tarjetas_saldo',category:'tarjetas',lastCategory:{},range:'recent',peers:{},allRanking:false,tableOpen:false,marketMethod:'m48',year:2030};
let app,data,pending,request=0;
const finite=value=>typeof value==='number'&&Number.isFinite(value);
const safe=value=>app.escape(String(value??''));
const format=(value,decimals=2)=>finite(value)?new Intl.NumberFormat('es-PE',{minimumFractionDigits:decimals,maximumFractionDigits:decimals}).format(value):'—';
const pct=value=>finite(value)?format(value)+' %':'—';
const pp=value=>finite(value)?(value>0?'+':'')+format(value)+' p.p.':'—';
const month=date=>/^\d{4}-\d{2}$/.test(date||'')?`${MONTHS[Number(date.slice(5))-1]} ${date.slice(0,4)}`:date||'—';
const serial=date=>Number(date.slice(0,4))*12+Number(date.slice(5,7))-1;
const GROUPS={
 consumo:['consumo_comparable','consumo','prestamos_no_revolventes'],
 tarjetas:['tarjetas_saldo','tarjetas_numero'],
 depositos:['depositos_ahorro','depositos_plazo','depositos_vista','depositos_cts','obligaciones_publico']
};
const categoryFor=id=>Object.entries(GROUPS).find(([key,values])=>values.includes(id))?.[0]||'consumo';
const productsForCategory=category=>(GROUPS[category]||[]).map(id=>data.products.find(item=>item.id===id)).filter(Boolean);
const product=()=>data.products.find(item=>item.id===state.product);
const observations=item=>[...(item.rows||[])].filter(row=>/^\d{4}-\d{2}$/.test(row.date)).sort((a,b)=>a.date.localeCompare(b.date));
const latest=item=>observations(item).at(-1)||null;
const decimalPlaces=item=>item.id==='tarjetas_numero'?0:2;
const condition=row=>row.status==='observed'?'Observado':row.status==='assumed'?`${row.date.startsWith('2026')?'Cierre supuesto':'Supuesto'} ${row.date.slice(0,4)}`:row.status==='forecast'?`Pronóstico ${row.date.slice(0,4)}`:'No disponible';
function scenarioLabel(application){
 const id=application.state?.scenarioId;
 const selected=application.state?.scenarios?.find(item=>item.id===id);
 const macroApplied=application.state?.data?.baseMacro?.active===true;
 if(selected?.name)return selected.name+(macroApplied?' · base macro aprobada aplicada':'');
 if(Object.keys(application.state?.changes||{}).length)return 'Escenario modificado'+(macroApplied?' · base macro aprobada aplicada':'');
 return macroApplied?'Escenario activo con base macro aprobada aplicada':'Base IASPE';
}
function modelProjection(item,application){
 if(application.state?.busy||item.universe?.id!=='banca_multiple')return [];
 if(!window.IASPEMercadoRutas)return [];
 return window.IASPEMercadoRutas.series(application,data,item.id,state.marketMethod);
}
function combinedRows(item,application){
 const observed=observations(item),dates=new Set(observed.map(row=>row.date));
 return [...observed,...modelProjection(item,application).filter(row=>!dates.has(row.date))].sort((a,b)=>a.date.localeCompare(b.date));
}
function selectedPeers(item){
 if(!Object.hasOwn(state.peers,item.id))state.peers[item.id]=[];
 return state.peers[item.id];
}
function peerName(item,id){return latest(item)?.ranking?.find(row=>row.id===id)?.name||id;}
function visibleRows(item,rows){
 if(state.range==='all')return rows;
 const date=latest(item)?.date;if(!date)return rows;
 const start=`${Number(date.slice(0,4))-9}-01`;
 return rows.filter(row=>row.date>=start);
}
function peerShare(row,id){return row.status==='observed'?row.ranking?.find(item=>item.id===id)?.share??null:null;}
function linePath(rows,value,x,y,canConnect){
 let path='',previous=null;
 for(const row of rows){const amount=value(row);if(!finite(amount)){previous=null;continue;}
  path+=`${previous&&canConnect(previous,row)?'L':'M'}${x(row).toFixed(2)},${y(amount).toFixed(2)} `;previous=row;
 }
 return path;
}
function chartHTML(item,all){
 const rows=visibleRows(item,all),peers=selectedPeers(item);
 const numbers=rows.flatMap(row=>[row.share,...peers.map(id=>peerShare(row,id))]).filter(finite);
 if(!numbers.length)return '<div class="participation-empty">No hay participaciones comparables para este producto.</div>';
 const compact=typeof window.innerWidth==='number'&&window.innerWidth<760;
 const W=compact?440:960,H=compact?300:370,L=compact?42:60,R=18,T=23,B=42;
 const first=serial(rows[0].date),span=Math.max(1,serial(rows.at(-1).date)-first),low=Math.max(0,Math.min(...numbers)-Math.max(.3,(Math.max(...numbers)-Math.min(...numbers))*.1)),high=Math.max(...numbers)+Math.max(.3,(Math.max(...numbers)-Math.min(...numbers))*.12);
 const x=row=>L+(serial(row.date)-first)*(W-L-R)/span,y=value=>T+(high-value)*(H-T-B)/Math.max(.1,high-low);
 const real=rows.filter(row=>row.status==='observed');
 const grid=Array.from({length:5},(_,index)=>{const value=low+(high-low)*index/4;return `<line x1="${L}" x2="${W-R}" y1="${y(value)}" y2="${y(value)}"/><text x="${L-10}" y="${y(value)+4}" text-anchor="end">${safe(format(value,1))}</text>`;}).join('');
 const tickRows=[...new Map([...Array.from({length:compact?3:4},(_,index)=>rows[Math.round((realCount(rows)-1)*index/Math.max(1,(compact?3:4)-1))]),...rows.filter(row=>row.status!=='observed'&&(compact?['2026','2028','2030'].includes(row.date.slice(0,4)):true))].filter(Boolean).map(row=>[row.date.slice(0,4),row])).values()];
 const ticks=tickRows.map(row=>`<text x="${x(row)}" y="${H-13}" text-anchor="middle">${row.date.slice(0,4)}</text>`).join('');
 const observedPath=linePath(real,row=>row.share,x,y,(a,b)=>serial(b.date)-serial(a.date)===1);
 const competitors=peers.map((id,index)=>`<path class="participation-peer" stroke="${PEER_COLORS[index%PEER_COLORS.length]}" d="${linePath(real,row=>peerShare(row,id),x,y,(a,b)=>serial(b.date)-serial(a.date)===1)}"/>`).join('');
 const future=rows.filter(row=>row.status!=='observed');
 let prior=real.filter(row=>finite(row.share)).at(-1),futurePaths='',markers='';
 for(const row of future){if(!finite(row.share)){prior=null;continue;}
  const adjacent=prior&&(prior.status==='observed'?serial(row.date)-serial(prior.date)>0&&serial(row.date)-serial(prior.date)<=12:Number(row.date.slice(0,4))-Number(prior.date.slice(0,4))===1);
  const type=row.status==='assumed'?'assumed':'forecast';
  if(adjacent)futurePaths+=`<path class="participation-${type}" d="M${x(prior)},${y(prior.share)} L${x(row)},${y(row.share)}"/>`;
  markers+=row.status==='assumed'?`<polygon class="participation-assumed-point" points="${x(row)},${y(row.share)-4} ${x(row)+4},${y(row.share)} ${x(row)},${y(row.share)+4} ${x(row)-4},${y(row.share)}"/>`:`<circle class="participation-forecast-point" cx="${x(row)}" cy="${y(row.share)}" r="3"/>`;prior=row;
 }
 const hits=rows.map((row,index)=>{const left=index?(x(rows[index-1])+x(row))/2:L,right=index<rows.length-1?(x(row)+x(rows[index+1]))/2:W-R;return `<rect class="participation-hit" tabindex="0" data-participation-date="${safe(row.date)}" x="${left}" y="${T}" width="${Math.max(1,right-left)}" height="${H-T-B}"/>`;}).join('');
 const legend=`<span><i class="participation-key-fal"></i>Banco Falabella · observado</span>${peers.map((id,index)=>`<span><i style="background:${PEER_COLORS[index%PEER_COLORS.length]}"></i>${safe(peerName(item,id))}</span>`).join('')}${future.some(row=>row.status==='assumed')?'<span><i class="participation-key-assumed"></i>Cierre supuesto 2026</span>':''}${future.some(row=>row.status==='forecast')?'<span><i class="participation-key-forecast"></i>Pronóstico 2027–2030</span>':''}`;
 return `<div class="participation-legend">${legend}</div><div class="participation-plot"><svg viewBox="0 0 ${W} ${H}" role="group" aria-label="Participación de mercado de Banco Falabella, observada y proyectada"><g class="participation-axes">${grid}${ticks}</g>${competitors}<path class="participation-observed" d="${observedPath}"/>${futurePaths}${markers}${hits}</svg><div class="participation-tooltip" hidden></div></div>`;
}
function realCount(rows){return rows.filter(row=>row.status==='observed').length;}
function rankingHTML(item){
 const current=latest(item),all=[...(current?.ranking||[])].filter(row=>finite(row.share)).sort((a,b)=>b.share-a.share),shown=state.allRanking?all:all.slice(0,6);
 const fal=all.find(row=>row.id==='falabella');if(fal&&!shown.includes(fal))shown.push(fal);
 const maximum=Math.max(1,...all.map(row=>row.share));
 return `<aside class="participation-panel participation-ranking"><div class="participation-panel-heading"><h2>Ranking institucional</h2><small>${safe(month(current?.date))}</small></div><p class="participation-caption">${safe(item.universe?.name||'Banca múltiple')} · ${!current?'No disponible':current.rankingComplete===false?'Información parcial':all.length+' instituciones'}</p>${shown.map(row=>`<button type="button" class="participation-rank ${row.id==='falabella'?'is-fal':''} ${selectedPeers(item).includes(row.id)?'is-selected':''}" data-participation-peer="${safe(row.id)}" ${row.id==='falabella'?'disabled':''} aria-pressed="${selectedPeers(item).includes(row.id)}"><span>${safe(row.name)}</span><strong>${safe(pct(row.share))}</strong><small>${safe(format(row.value,decimalPlaces(item)))} ${safe(item.unit)}</small><i><b style="width:${row.share/maximum*100}%"></b></i></button>`).join('')}<button type="button" class="participation-ranking-toggle" id="participation-ranking-toggle">${state.allRanking?'Mostrar principales':'Ver todas las instituciones'}</button></aside>`;
}
function tableHTML(item,rows){
 return `<details class="participation-panel participation-history" id="participation-history" ${state.tableOpen?'open':''}><summary>Tabla histórica y proyectada <small>${safe(item.unit)} · Participación en %</small></summary><div class="participation-table"><table><thead><tr><th>Período</th><th>Banco Falabella</th><th>Mercado SBS</th><th>Cuota (%)</th><th>Condición</th></tr></thead><tbody>${[...rows].reverse().map(row=>`<tr data-participation-row="${safe(row.date)}"><td>${safe(month(row.date))}</td><td>${safe(format(row.falabella,decimalPlaces(item)))}</td><td>${safe(format(row.market,decimalPlaces(item)))}</td><td>${safe(pct(row.share))}</td><td>${safe(condition(row))}</td></tr>`).join('')}</tbody></table></div></details>`;
}
function methodHTML(item,current){
 const bank=finite(current?.falabella)?format(current.falabella,decimalPlaces(item)):'—';
 const market=finite(current?.market)?format(current.market,decimalPlaces(item)):'—';
 const report=current?.source?.report||item.source?.report||'SBS';
 return `<div class="pm-observed-source"><span><b>Falabella</b> ${safe(bank)}</span><span class="pm-symbol">÷</span><span><b>Mercado</b> ${safe(market)}</span><span class="pm-symbol">=</span><strong>${safe(pct(current?.share))}</strong><small>${safe(report)} · Banca múltiple · ${safe(month(current?.date))}</small></div>`;
}
function latex(tex){
 try {return window.katex?.renderToString?.(tex,{throwOnError:false,trust:false,displayMode:false})||`<code>${safe(tex)}</code>`;}
 catch(_){return `<code>${safe(tex)}</code>`;}
}
const TC_TEX=String.raw`100\Delta\ln(TC_t)=-2.366+2.177\,PBI_{t-1}-1.324\,\Delta U_{t-1}`;
const NR_TEX=String.raw`100\Delta\ln(NR_t)=20.245-1.887\,\Delta U_t-2.174\,TPM_{t-1}`;
function marketRegression(item){
 const id=item.id,methods=[];
 const add=(label,tex,metadata)=>methods.push(`<div class="pm-regression"><div class="pm-regression-head"><b>${label}</b><small>${metadata}</small></div><div class="pm-formula">${latex(tex)}</div></div>`);
 if(id==='consumo_comparable'&&state.marketMethod==='m48'){
  const m=window.IASPEMarketModelMetadata?.['48'];
  add('M48 · Mercado agregado',m?.estimatedEquationTex||String.raw`100\Delta\ln(C_t)=18.3339+1.4648\,PBI_t-4.8661\,\Delta U_{t-1}-3.4639\,TPM_{t-1}`,'MCO anual · PBI, desempleo y tasa de referencia');
  return `<section class="pm-model-method"><div class="pm-method-heading"><h2>Regresión del mercado</h2><span>Modelo vigente · M48</span></div>${methods.join('')}<div class="pm-model-meta"><span>R² ajustado: ${finite(m?.statistics?.adjustedR2)?format(m.statistics.adjustedR2,3):'—'}</span><span>Muestra: ${safe(m?.statistics?.period||'Archivo M48')}</span></div></section>`;
 }
 if(id==='consumo_comparable'&&state.marketMethod==='componentes'||id==='tarjetas_saldo'||id==='prestamos_no_revolventes'){
  if(id!=='prestamos_no_revolventes')add('Tarjetas de consumo · Regresión complementaria',TC_TEX,'PBI real rezagado (+) · Cambio de desempleo rezagado (−)');
  if(id!=='tarjetas_saldo')add('Préstamos no revolventes · Regresión complementaria',NR_TEX,'Cambio de desempleo (−) · TPM rezagada (−)');
  return `<section class="pm-model-method"><div class="pm-method-heading"><h2>Regresión del mercado</h2><span>Alternativa econométrica · Validación preliminar</span></div><div class="pm-regression-grid">${methods.join('')}</div><div class="pm-model-meta"><span>Crecimiento anual del saldo, en logaritmos</span><span>2012–2025 · Supuestos macro del escenario activo</span><span>El cierre 2026 se ancla a SBS y M48</span></div></section>`;
 }
 if(id==='tarjetas_numero'){
  const model=app.model?.('01');
  return `<section class="pm-model-method"><div class="pm-method-heading"><h2>Modelo del mercado</h2><span>M01 · Número de tarjetas</span></div>${model?.equationTex||model?.estimatedEquationTex?`<div class="pm-formula">${latex(model.estimatedEquationTex||model.equationTex)}</div>`:''}<div class="pm-model-meta"><a href="#modelo/01">Consultar regresión, variables y supuestos de M01</a><span>Mercado M01 / Falabella M04</span></div></section>`;
 }
 return `<div class="pm-no-forecast"><b>Serie SBS observada</b><span>${id==='consumo'?'La cartera total SBS no equivale al perímetro proyectado por M48.':'No existe aún una regresión de mercado aprobada para este producto.'}</span></div>`;
}
const sectionNames={consumo:'Consumo',tarjetas:'Tarjetas',depositos:'Depósitos'};
const routeCategory=()=>({tarjetas:'tarjetas',depositos:'depositos'})[(location.hash.match(/^#benchmark\/(tarjetas|depositos)(?:[/?]|$)/)||[])[1]]||null;

function paint(){
 if(!data?.products?.length)return;
 const fromRoute=routeCategory();
 if(fromRoute&&fromRoute!==state.category){state.lastCategory[state.category]=state.product;state.category=fromRoute;state.product=state.lastCategory[fromRoute]||productsForCategory(fromRoute)[0]?.id||state.product;}
 if(!product())state.product=data.products[0].id;
 if(categoryFor(state.product)!==state.category)state.product=productsForCategory(state.category)[0]?.id||state.product;
 const item=product(),current=latest(item),rows=combinedRows(item,app),future=rows.filter(row=>row.status!=='observed'&&finite(row.share));
 const peers=selectedPeers(item),rank=finite(current?.rank)?String(current.rank):'—';
 const sourceLatest=item.availability?.latestSourcePeriod,newerUnavailable=sourceLatest&&(!current||sourceLatest>current.date);
 const availabilityNote=newerUnavailable?`La publicación de ${month(sourceLatest)} no está disponible para este indicador. Se conserva el último dato validado.`:'';
 const pendingModels=!!(app.state?.sbsUpdate?.pending?.pending||app.state?.data?.sourceUpdates?.pending);
 const failedRecalculation=app.state?.data?.lastRecalculation?.ok===false;
 const forecastType=item.id==='consumo_comparable'?(state.marketMethod==='m48'?'M07 / M48 vigente':'M07 / mercado de componentes'):
   item.id==='tarjetas_saldo'?'M05 / tarjetas del mercado':item.id==='prestamos_no_revolventes'?'M06 / préstamos del mercado':
   item.id==='tarjetas_numero'?'M04 / M01':'Solo observado';
 const projectionNote=future.length?`2026: cierre supuesto · 2027–2030: pronósticos. La proyección propia de Falabella no cambia al elegir otro método de mercado.${pendingModels?' Nuevos observados pendientes.':''}${failedRecalculation?' Última versión válida conservada.':''}`:
   item.id==='consumo'?'Consumo SBS total no es igual al consumo comparable de M07/M48.':
   'Sin proyección homogénea disponible para este indicador.';
 const reference=current?.source||item.source||{};
 const nav=`<nav class="market-main-tabs pm-compact-nav"><a href="#benchmark/cartera">Cartera de consumo</a><a href="#benchmark/depositos" ${state.category==='depositos'?'class="active" aria-current="page"':''}>Depósitos</a><a href="#benchmark/tarjetas" ${state.category==='tarjetas'?'class="active" aria-current="page"':''}>Tarjetas</a><a href="#benchmark/oficinas">Oficinas</a></nav>`;
 const forecast=window.IASPEMercadoRutas?.series(app,data,item.id,state.marketMethod)||[];
 const methodChoice=item.id==='consumo_comparable'?`<div class="pm-method-selector"><label for="market-method">Método econométrico del mercado</label><select id="market-method"><option value="m48" ${state.marketMethod==='m48'?'selected':''}>M48 · Regresión del consumo agregado</option><option value="componentes" ${state.marketMethod==='componentes'?'selected':''}>Dos regresiones · Tarjetas + préstamos</option></select></div>`:'';
 const modelFlow=forecast.length?window.IASPEMercadoRutas.yearCards(app,data,item.id,state.marketMethod,state.year):'';
 const available=productsForCategory(state.category);
 const choices=(current?.ranking||[]).filter(row=>row.id!=='falabella').map(row=>`<label><input type="checkbox" value="${safe(row.id)}" ${peers.includes(row.id)?'checked':''}/><span>${safe(row.name)}</span></label>`).join('');
 $('#workspace').innerHTML=`<section class="participation-workspace">${nav}<header class="participation-heading"><div><h1>${safe(sectionNames[state.category])}</h1><p>Banco Falabella · ${safe(item.universe?.name||'Banca múltiple')}</p></div>${window.IASPESourceUpdates.control('participacion',current?.date,false)}</header><div class="participation-controls"><label>Indicador<select id="participation-product">${available.map(entry=>`<option value="${safe(entry.id)}" ${entry.id===state.product?'selected':''}>${safe(entry.name)}</option>`).join('')}</select></label><div class="participation-competitors"><span>Comparar evolución con</span><details id="participation-peers"><summary>${peers.length?peers.length+' instituciones':'Sólo Banco Falabella'}</summary><div class="participation-peer-options">${choices}</div></details></div><span class="participation-latest">Último observado: ${safe(month(current?.date))}</span></div><div class="market-observed-heading"><strong>Observado · SBS</strong><small>${safe(month(current?.date))}</small></div><div class="participation-kpis"><div><small>${newerUnavailable?'Última participación validada':'Participación actual'}</small><strong data-participation-kpi="share">${safe(pct(current?.share))}</strong><span>${safe(month(current?.date))}</span></div><div><small>Variación interanual</small><strong data-participation-kpi="change">${safe(pp(current?.changeYoyPp))}</strong><span>${finite(current?.changeYoyPp)?'Mismo mes del año anterior':'Sin observación interanual comparable'}</span></div><div><small>${item.id==='tarjetas_numero'?'Tarjetas de Falabella':'Saldo de Falabella'}</small><strong data-participation-kpi="amount">${safe(format(current?.falabella,decimalPlaces(item)))}</strong><span>${safe(item.unit)}</span></div><div><small>Posición institucional</small><strong data-participation-kpi="rank">${safe(rank)}</strong><span>${!current?'Sin ranking disponible':current.rankingComplete===false?'Ranking incompleto':'Universo SBS completo'}</span></div></div>${methodHTML(item,current)}${methodChoice}${marketRegression(item)}${modelFlow}${availabilityNote?`<p class="participation-data-note" role="status">${safe(availabilityNote)}</p>`:''}<div class="participation-main"><section class="participation-panel participation-chart-panel"><div class="participation-panel-heading"><h2>Evolución de la participación</h2><div class="participation-range"><button type="button" data-participation-range="recent" class="${state.range==='recent'?'active':''}">Últimos 10 años</button><button type="button" data-participation-range="all" class="${state.range==='all'?'active':''}">Historia completa</button></div></div><p class="participation-caption">${safe(item.name)} · Participación en %</p>${chartHTML(item,rows)}<p class="participation-projection-note">${safe(projectionNote)}</p></section>${rankingHTML(item)}</div>${tableHTML(item,rows)}<footer class="participation-sources"><span>Fuente: SBS · Denominador: ${safe(item.universe?.name||'banca múltiple')} completa, total oficial del producto.</span><details><summary>Definición y fuentes</summary><div><p>${safe(item.definition)}</p><p>${safe(typeof item.source==='string'?item.source:'Reporte '+(reference.report||item.source?.report||'SBS'))}</p>${reference.url&&/^https:\/\//.test(reference.url)?`<a href="${safe(reference.url)}" target="_blank" rel="noopener noreferrer">Consultar fuente SBS</a>`:''}${(item.limitations||[]).map(text=>`<p>${safe(typeof text==='string'?text:text.detail||text.message||'')}</p>`).join('')}</div></details></footer></section>`;
 const methodSelect=$('#market-method');if(methodSelect)methodSelect.onchange=()=>{state.marketMethod=methodSelect.value;paint();};
 const forecastYear=$('#market-routes-year');if(forecastYear)forecastYear.onchange=()=>{state.year=Number(forecastYear.value);paint();};
 $('#participation-product').onchange=event=>{state.product=event.target.value;state.lastCategory[state.category]=state.product;state.allRanking=false;paint();};
 $('#participation-history').ontoggle=event=>{state.tableOpen=event.target.open;};
 $('#participation-ranking-toggle').onclick=()=>{state.allRanking=!state.allRanking;paint();};
 const togglePeer=id=>{if(id==='falabella')return;const values=selectedPeers(item);state.peers[item.id]=values.includes(id)?values.filter(value=>value!==id):[...values,id];paint();};
 document.querySelectorAll('[data-participation-range]').forEach(button=>button.onclick=()=>{state.range=button.dataset.participationRange;paint();});
 document.querySelectorAll('[data-participation-peer]').forEach(button=>button.onclick=()=>togglePeer(button.dataset.participationPeer));
 document.querySelectorAll('.participation-peer-options input').forEach(input=>input.onchange=()=>{togglePeer(input.value);$('#participation-peers').open=true;});
 const plot=$('.participation-plot');if(plot){const tooltip=plot.querySelector('.participation-tooltip');plot.querySelectorAll('[data-participation-date]').forEach(hit=>{
  const show=()=>{const row=rows.find(entry=>entry.date===hit.dataset.participationDate);tooltip.innerHTML=`<strong>${safe(month(row.date))} · ${safe(condition(row))}</strong><span>Banco Falabella <b>${safe(pct(row.share))}</b></span>${peers.filter(id=>finite(peerShare(row,id))).map(id=>`<span>${safe(peerName(item,id))} <b>${safe(pct(peerShare(row,id)))}</b></span>`).join('')}`;const width=plot.getBoundingClientRect().width,view=plot.querySelector('svg').viewBox.baseVal.width;tooltip.style.left=Math.max(4,Math.min(width-224,Number(hit.getAttribute('x'))/view*width))+'px';tooltip.hidden=false;};
  hit.addEventListener('pointerenter',show);hit.addEventListener('focus',show);hit.addEventListener('blur',()=>tooltip.hidden=true);
 });plot.addEventListener('pointerleave',()=>tooltip.hidden=true);}
 window.IASPESourceUpdates.bind(app);
}
async function render(application){
 app=application;await window.IASPESourceUpdates.refresh(app).catch(()=>null);
 if(!routeCategory())return;
 const token=++request;$('#workspace').innerHTML='<div class="empty">Cargando participación de mercado…</div>';
 try{pending||=app.api('/api/benchmark/participacion');const loaded=await pending;if(token!==request||!routeCategory())return;data=loaded;if(!data.ready||!data.products?.length)throw Error(data.message||'No hay datos comparables de participación disponibles.');paint();}
 catch(error){if(token!==request)return;pending=null;if(routeCategory())$('#workspace').innerHTML=`<div class="notice">${safe(error.message)}</div>`;}
}
function invalidate(){request++;data=null;pending=null;}
let resizeTimer;
window.addEventListener('resize',()=>{clearTimeout(resizeTimer);if(data&&routeCategory())resizeTimer=setTimeout(paint,150);});
window.IASPEParticipacionMercado={render,invalidate};
})();
