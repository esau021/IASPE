"""Modelo 47: balance sheets / treasury liquidity reconciliation, SBS anchored."""
from __future__ import annotations
from pathlib import Path
import math,copy
from motor_33_45 import _read_rows,_annual,_make

NAME='Estado de situación financiera'
DEPEND={'07','10','17_caja','17_canje','17_otros','21','22','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46'}
ROWS={'47':19,'47_pasivo':31,'47_patrimonio':39,'47_control':41,'47_disponible':2,'47_bancos':4,
 '47_creditos_netos':9,'47_interbancario_pasivo':23,'47_disponible_previo':43,'47_ajuste_bancos':44,'47_principal_cert':25}
DEFERRED=0.00182079142912201
OTHER=0.0003756945774021294
FONDEO_INTERB=60.0

def provision_plan(path):
    """Stock Base BF BLSBS 2026–2030, cinco inputs contables explícitos."""
    from _m47_excel_reader import extract_value
    yearly={year:float(extract_value(path,'Parametros_Base',f'B{row}'))
            for year,row in ((2026,16),(2027,17),(2028,18),(2029,21),(2030,22))}
    if any(v < 0 for v in yearly.values()):
        raise ValueError('M47: provisiones IASC Base inválidas')
    return yearly

def provision_stock(plan,year,gross=None):
    if year not in plan:
        return None
    return plan[year]

def provision_source(year):
    return ('Input del Banco: Escenario_ - copia.xlsx / BLSBS (saldo 2026–2030; no gasto M25)'
            if year in range(2026,2031) else 'Sin input')

def _source(root):
    p=Path(root)/'Estado de Situacion Financiera'/'47_Conciliacion_balance_general_Falabella'/'Output'/'Pronostico.xlsx'
    if not p.is_file():raise FileNotFoundError(f'M47 no disponible: {p}')
    return p

def build_registry(root):
    p=_source(root)
    annuals=_read_rows(p,'Anual')
    result=[_make('47',NAME,_annual(annuals,'B'),p,sorted(DEPEND),
          'Identidad SBS; Bancos y corresponsales como liquidez residual; fondos interbancarios pasivo exógeno.',True)]
    for mid,row in ROWS.items():
        if mid=='47':continue
        series=[]
        for year,col in zip(range(2025,2031),'BCDEFG'):
            from _m47_excel_reader import extract_value
            value=extract_value(p,'Balance',f'{col}{row}')
            series.append({'year':year,'value':float(value),'status':'observed' if year==2025 else 'assumed' if year==2026 else 'forecast'})
        result.append(_make(mid,dict((k,(str(v))) for k,v in [('47_pasivo','Total pasivo'),('47_patrimonio','Patrimonio'),('47_control','Diferencia de balance'),('47_disponible','Disponible conciliado'),('47_bancos','Bancos y corresponsales conciliados'),('47_creditos_netos','Cartera de créditos neta'),('47_interbancario_pasivo','Fondos interbancarios — pasivo'),('47_disponible_previo','Disponible previo M17'),('47_ajuste_bancos','Cambio en Bancos para conciliación'),('47_principal_cert','Certificados: principal SBS neto de intereses presupuestados')]).get(mid,mid),series,p,sorted(DEPEND),
         'Partida derivada de la identidad contable del M47.',True))
    return result

def recalculate(context,changes=None,observations=None):
    models=context.get('models',{})
    original=context.get('original_models') or models
    required=set(DEPEND)|{'17','17_bancos','47'}
    if not required.issubset(models):return {'models':[]}
    updated=set()
    p=_source(context.get('source_root') or context.get('sourceRoot'))
    from _m47_excel_reader import extract_value
    other=extract_value(p,'Parametros_Base','B2')
    stock_plan=provision_plan(p)
    deferred=extract_value(p,'Parametros_Base','B4')
    interbank=extract_value(p,'Parametros_Base','B5')
    def get(k,y):
        return next((float(row['value']) for row in models[k]['annual'] if row['year']==y),None)
    def get_original(k,y):
        return next((float(row['value']) for row in original[k]['annual'] if row['year']==y),None)
    def setval(k,y,x):
        if k not in models or x is None or not math.isfinite(x):return
        row=next((r for r in models[k]['annual'] if r['year']==y),None)
        if row is None or row.get('status')=='observed':return
        if abs(row['value']-x)<1e-8:return
        row['value']=float(x)
        row['forecast']=float(x) if y>=2027 else None
        row['assumed']=float(x) if y==2026 else None
        row['observed']=None
        models[k]['reestimated']=True
        updated.add(k)
    from escenarios_iasc import plan as iasc_plan
    overrides=(changes or {}).get('__iasc_provisiones_stock__') or {}
    # Sin stock SBS posterior a 2028: NO utilizar Base 2029–2030 como dato de estrés.
    years=range(2026,2029) if overrides else range(2026,2031)
    for year in years:
        # El Base usa los cinco saldos BLSBS; estrés usa exclusivamente los inputs por escenario.
        gross=get('07',year)*(1+other)
        stock=float(overrides.get(str(year),stock_plan[year]))
        net=gross-stock-gross*deferred
        other_assets=sum(get(k,year) for k in ['22','21','31','32','33','34'])
        other_cash=sum(get(k,year) for k in ['17_caja','17_canje','17_otros'])
        # M36 conserva el presupuesto IASC BRUTO de certificados. SBS separa
        # principal (cuenta 28) e intereses por pagar (M38); no duplicar intereses.
        col='BCDEFG'[year-2025]
        certific_interest_base=float(extract_value(p,'Drivers_Base',f'{col}33'))
        original_cert=get_original('36',year)
        current_cert=get('36',year)
        certific_interest=certific_interest_base*(current_cert/original_cert) if original_cert else 0.0
        certific_principal=current_cert-certific_interest
        if certific_principal < 0:raise ValueError(f'{year}: principal certificados negativo')
        liabilities=sum(get(k,year) for k in ['10','35','36','37','38','39','40'])+interbank-certific_interest
        equity=sum(get(k,year) for k in ['41','42','43','44','45','46'])
        banking=liabilities+equity-net-other_assets-other_cash
        if banking<0:raise ValueError(f'{year}: Bancos y corresponsales negativo en conciliación SBS: {banking:.3f} MM')
        available=banking+other_cash
        # Diagnóstico persistente de liquidez antes del cuadre: referencia
        # explícita M47 Drivers_Base!fila 3. NO reutilizar M17_bancos porque
        # tras guardar el motor contiene ya el saldo conciliado y ocasiona
        # diferencias artificiales en reinicios y pruebas de estrés.
        before_bank=float(extract_value(p,'Drivers_Base',f'{col}3'))
        before=before_bank+other_cash
        for key,value in [('17_bancos',banking),('17',available),('47_bancos',banking),('47_disponible',available),
                    ('47_pasivo',liabilities),('47_patrimonio',equity),('47',liabilities+equity),
                    ('47_creditos_netos',net),('47_interbancario_pasivo',interbank),('47_principal_cert',certific_principal),
                    ('47_control',0.0),('47_disponible_previo',before),('47_ajuste_bancos',banking-before_bank)]:
            setval(key,year,value)
    if overrides:
        # Mantener las cuentas generales hasta 2030 solo en Base IASPE.
        for k in ('17_bancos','17',*ROWS.keys()):
            if k in models:
                oldlen=len(models[k].get('annual',[]))
                models[k]['annual']=[r for r in models[k].get('annual',[]) if int(r['year'])<=2028]
                if len(models[k]['annual'])!=oldlen:updated.add(k)
    if updated:
        for k in ('17_bancos','17'):
            if k in models:
                models[k]['method']='Conciliación integral de liquidez: saldo residual de bancos, fuente SBS y demás modelos IASPE.' if k=='17_bancos' else 'Suma de Caja, Bancos y corresponsales (conciliado), Canje y Otros.'
                models[k]['coefficients']=[];models[k]['statistics']={}
        return {'models':[models[k] for k in sorted(updated)]}
    return {'models':[]}
