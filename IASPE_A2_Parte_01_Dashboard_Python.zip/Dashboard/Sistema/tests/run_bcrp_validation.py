"""Run the delivered notebook and regression tests, recording both outcomes.

Usage from Dashboard/Sistema:
    python tests/run_bcrp_validation.py --pdf-dir "C:/path/to/PDFs"
Tests use only local PDFs and an isolated localhost API; they do not download
official-site documents or modify the live IASPE data.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--pdf-dir',type=Path,default=Path.home()/'Downloads')
    parser.add_argument('--output-dir',type=Path,default=None)
    args=parser.parse_args()
    system=Path(__file__).resolve().parents[1]
    output=(args.output_dir or system/'notebooks'/'output').resolve()
    output.mkdir(parents=True,exist_ok=True)
    os.environ['BCRP_PDF_DIR']=str(args.pdf_dir.resolve())
    os.environ['BCRP_OUTPUT_DIR']=str(output)
    result={'executed_at_utc':datetime.now(timezone.utc).isoformat(),
            'pdf_directory':str(args.pdf_dir.resolve()), 'notebook':{},'pytest':{}}
    source_files=[system/'bcrp_documents.py',system/'proyecciones_externas.py',
                  system/'proyecciones-externas.js',
                  *sorted((system/'tests').glob('test_bcrp_*'))]
    source_files=[p for p in source_files if p.is_file()]
    source_hashes={str(p.relative_to(system)).replace('\\','/'):
                   hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    result['source_sha256']=source_hashes
    try:
        import nbformat
        from nbclient import NotebookClient
        path=system/'notebooks'/'Lector_BCRP.ipynb'
        notebook=nbformat.read(path,as_version=4)
        client=NotebookClient(notebook,timeout=240,kernel_name='python3',
                              resources={'metadata':{'path':str(system/'notebooks')}})
        client.execute()
        nbformat.write(notebook,path)
        result['notebook']={'status':'passed','path':str(path)}
    except Exception as exc:
        result['notebook']={'status':'failed','error':f'{type(exc).__name__}: {exc}'}
    test_files=[str(p.relative_to(system)).replace('\\','/')
                for p in sorted((system/'tests').glob('test_bcrp_*.py'))]
    proc=subprocess.run([sys.executable,'-m','pytest','-q',*test_files,
                         '--junitxml='+str(output/'pytest_results.xml')],cwd=system,
                        capture_output=True,text=True,encoding='utf-8',errors='replace')
    (output/'pytest_results.txt').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8')
    result['pytest']={'status':'passed' if proc.returncode==0 else 'failed',
                      'exit_code':proc.returncode,'test_files':test_files,
                      'log':'pytest_results.txt','junit':'pytest_results.xml'}
    junit=output/'pytest_results.xml'
    if junit.is_file():
        suites=ET.parse(junit).getroot().findall('testsuite')
        counts={field:sum(int(s.get(field,'0')) for s in suites)
                for field in ('tests','failures','errors','skipped')}
        result['pytest'].update(counts)
        # A skipped real PDF cannot count as a successful end-to-end validation.
        if counts['skipped']:
            result['pytest']['status']='incomplete'
    result['passed']=(result['notebook']['status']=='passed'
                      and result['pytest']['status']=='passed')
    result['source_files_unchanged_during_test']=all(
        hashlib.sha256((system/name).read_bytes()).hexdigest()==digest
        for name,digest in source_hashes.items())
    result['passed']=result['passed'] and result['source_files_unchanged_during_test']
    (output/'validation_run.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
