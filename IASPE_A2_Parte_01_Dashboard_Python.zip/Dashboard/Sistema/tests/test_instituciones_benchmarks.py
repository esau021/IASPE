"""Clasificación mensual y trazabilidad SBS, sin red ni escritura en bases activas."""
from pathlib import Path
import csv
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import instituciones_sbs as i
import ratios_sbs as r
import personal_sbs as p
import benchmark_eeff as e


class InstitucionesTests(unittest.TestCase):
    def test_unique_ids_and_official_code_are_separate(self):
        entities=i.catalog()
        self.assertEqual(len(entities),17)
        self.assertEqual(len({x['id'] for x in entities}),17)
        c=next(x for x in entities if x['id']==i.CENCOSUD_ID)
        self.assertEqual(c['sbs_code'],'18')
        self.assertNotEqual(c['id'],c['sbs_code'])
        self.assertEqual(c['category'],'Cajas rurales')
        self.assertEqual({x['id'] for x in entities if x['id']!=i.CENCOSUD_ID},{f'{n:02d}' for n in range(1,17)})

    def test_monthly_licence_and_name_transitions(self):
        for identifier,month,category in [('10','2026-09','Empresas financieras'),
            ('15','2026-05','Empresas financieras'),('15','2026-06','Bancos'),
            ('13','2024-12','Empresas financieras'),('13','2025-01','Bancos'),
            ('06','2025-05','Empresas financieras'),('06','2025-06','Bancos'),
            (i.CENCOSUD_ID,'2019-02','Bancos'),(i.CENCOSUD_ID,'2019-03','Cajas rurales')]:
            with self.subTest(identifier=identifier,month=month):
                self.assertEqual(i.category_at(identifier,month),category)
        self.assertEqual(i.match_entity('CRAC Censosud Scotia*'),i.CENCOSUD_ID)
        self.assertEqual(i.match_entity('Financiera Oh!*'),'10')
        self.assertEqual(i.match_entity('B. de Crédito del Perú'),'01')
        self.assertIsNone(i.match_entity('18'))
        self.assertIsNone(i.match_entity('Institución no identificada'))

    def test_rural_ratio_keeps_effective_date_and_source_month(self):
        with tempfile.TemporaryDirectory() as folder:
            file=Path(folder)/'ratios.csv'
            row={'indicador_id':'ratio_capital_global','banco_id':i.CENCOSUD_ID,
                 'reporte':'C-2301','valor':'17.77','fecha_indicador':'2026-08-31',
                 'periodo_fuente':'2026-09','celda_valor':'B8',
                 'url':'https://intranet2.sbs.gob.pe/estadistica/financiera/2026/Setiembre/C-2301-se2026.XLS',
                 'denominacion_sbs':'CRAC Cencosud Scotia'}
            with file.open('w',encoding='utf-8',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=list(row));writer.writeheader();writer.writerow(row)
            result=r._build_from_csv(file)
            self.assertEqual(result['periodo_fin'],'2026-08')
            self.assertEqual(result['periodo_fin_fuente'],'2026-09')
            self.assertEqual(result['series']['ratio_capital_global'][i.CENCOSUD_ID][0][:2],['2026-08',17.77])
            # Una edición posterior puede revisar el mismo mes efectivo.
            revised=dict(row,periodo_fuente='2026-10',valor='17.88')
            with file.open('a',encoding='utf-8',newline='') as stream:
                csv.DictWriter(stream,fieldnames=list(row)).writerow(revised)
            self.assertEqual(r._build_from_csv(file)['series']['ratio_capital_global'][i.CENCOSUD_ID][0][1],17.88)
            with file.open('a',encoding='utf-8',newline='') as stream:
                csv.DictWriter(stream,fieldnames=list(row)).writerow(dict(revised,valor='17.99'))
            with self.assertRaises(ValueError):
                r._build_from_csv(file)

    def test_personal_preserves_sources_and_monthly_categories(self):
        with tempfile.TemporaryDirectory() as folder:
            file=Path(folder)/p.DATA
            fields=['periodo','banco',*p.COLUMNS,'archivo','nombre_sbs','hoja','fila_excel']
            def save(path,rows):
                with path.open('w',encoding='utf-8',newline='') as stream:
                    writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows(rows)
            def row(month,name,total,values):
                return dict(zip(fields,[month,name,total,*values,'oficial.XLS',name,'CR',11]))
            wrong_sector=row('2026-05','Banco Efectiva',999,[1,2,3,993])
            wrong_sector['archivo']='B-2305-my2026.XLS'
            save(file,[wrong_sector,row('2026-06','Banco Efectiva',10,[1,2,3,4])])
            save(file.with_name(p.FINANCE),[row('2026-05','Financiera Efectiva',1582,[31,None,1538,13])])
            save(file.with_name(p.RURAL),[row('2026-09','CRAC Censosud Scotia',567,[9,9,538,11])])
            result=p._parse(str(file),1,1,0,0,1,1,1,1)
            rows=result['registros']
            self.assertEqual(len(rows),3)
            self.assertEqual(len(result['classification_omitted']),1)
            self.assertEqual(next(x['personal_total'] for x in rows if x['periodo']=='2026-05'),1582)
            self.assertIsNone(next(x['funcionarios'] for x in rows if x['periodo']=='2026-05'))
            self.assertEqual(next(x['category'] for x in rows if x['periodo']=='2026-05'),'Empresas financieras')
            c=next(x for x in rows if x['banco']==i.CENCOSUD_ID)
            self.assertEqual(c['personal_total'],567)
            self.assertEqual(c['category'],'Cajas rurales')
            self.assertEqual(c['fila_excel'],'11')

    def test_eeff_aggregates_explicitly_separate_sectors(self):
        account={'id':'balance:test','name':'TOTAL ACTIVO'}
        meta={'banks':[{'id':x} for x in ('05','10',i.CENCOSUD_ID)],
              'accounts':[account],'months':['2026-09'],'last':'2026-09',
              'source_name':'SBS','source_url':'https://www.sbs.gob.pe',
              'unit':'S/ millones','source_note':'Observado','market_note':'Comparables',
              'income_note':'Acumulado','coverage_note':'Sin imputar'}
        data={'meta':meta,'series':{'balance:test':{'05':{'2026-09':100.0},
               '10':{'2026-09':20.0},i.CENCOSUD_ID:{'2026-09':5.0}}}}
        with patch.object(e,'_read',return_value=data):
            result=e.account_data('balance:test')
        self.assertEqual(result['rows'][0]['aggregate'],125.0)
        self.assertEqual(result['rows'][0]['category_aggregates'],
                         {'Bancos':100.0,'Empresas financieras':20.0,'Cajas rurales':5.0})
        self.assertIn('No representa un total oficial sectorial',result['source']['notes'][1])


if __name__=='__main__':
    unittest.main()
