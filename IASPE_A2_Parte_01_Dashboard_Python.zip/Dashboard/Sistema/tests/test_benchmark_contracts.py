"""Contratos de identidad y faltantes; sin descargas ni escrituras activas."""
from __future__ import annotations

import gzip
from contextlib import redirect_stdout
from io import StringIO
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import unicodedata

SYSTEM = Path(__file__).resolve().parents[1]
PROJECT = SYSTEM.parents[1]/'IASPE'
sys.path.insert(0, str(SYSTEM))
import benchmark_eeff
import instituciones_sbs as institutions

FIXTURE = json.loads((Path(__file__).parent/'fixtures/eeff_account_ids_v1918.json').read_text(encoding='utf-8'))


def normalize(value):
    return ' '.join(''.join(char for char in unicodedata.normalize('NFKD',value).lower()
                           if not unicodedata.combining(char)).split())


def identities(accounts):
    return {(entry['section'],normalize(entry['name']),entry.get('occurrence',1)):entry['id']
            for entry in accounts}


class BenchmarkContracts(unittest.TestCase):
    def test_original_account_identifiers_stay_bound_to_same_concept(self):
        with gzip.open(benchmark_eeff.DATA_PATH,'rt',encoding='utf-8') as stream:
            current = json.load(stream)
        expected, actual = identities(FIXTURE['accounts']), identities(current['meta']['accounts'])
        self.assertEqual(len(expected), 221)
        self.assertEqual({key:actual.get(key) for key in expected}, expected)

    def test_generator_adds_institution_without_shifting_existing_account_ids(self):
        path = PROJECT/'Scraper/EEFF_Benchmark/script/construir_panel.py'
        spec = importlib.util.spec_from_file_location('iaspe_panel_identity_test',path)
        generator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(generator)
        with tempfile.TemporaryDirectory(prefix='iaspe_catalog_test_') as temporary:
            root = Path(temporary)/'IASPE'
            output = root/'Scraper/EEFF_Benchmark/output'
            output.mkdir(parents=True)
            for identifier in ('01','05',institutions.CENCOSUD_ID):
                folder = root/'Estados financieros banca/SBS tal cual'/f'{identifier} Fixture'
                folder.mkdir(parents=True)
                (folder/'fixture.xlsx').write_bytes(b'Synthetic workbook placeholder; reader is mocked')
            with gzip.open(output/'panel_eeff_16_bancos.json.gz','wt',encoding='utf-8') as stream:
                json.dump({'meta':{'accounts':FIXTURE['accounts']}},stream)
            def synthetic_book(source):
                result = {}
                rural = source.parent.name.startswith(institutions.CENCOSUD_ID)
                for section, sheet in generator.SHEET_NAMES.items():
                    if rural:
                        labels = [f'CUENTA EXCLUSIVA SINTÉTICA {section}']
                    else:
                        labels = [item['name'] for item in FIXTURE['accounts'] if item['section']==section]
                    result[sheet] = [(6,{1:46265.0})] + [
                        (index,{0:label,1:123000.0}) for index,label in enumerate(labels,7)]
                return result
            with patch.object(generator,'book_sheet_values',side_effect=synthetic_book), redirect_stdout(StringIO()):
                current = generator.build(root,output)
        expected, actual = identities(FIXTURE['accounts']), identities(current['meta']['accounts'])
        self.assertEqual({key:actual.get(key) for key in expected}, expected)
        self.assertEqual(len(current['meta']['accounts']),len(expected)+3)
        self.assertEqual(len({entry['id'] for entry in current['meta']['accounts']}),len(expected)+3)

    def test_missing_institutions_are_absent_not_zero_and_categories_follow_month(self):
        identifiers = ['05','15',institutions.CENCOSUD_ID]
        meta = {'banks':[{'id':identifier} for identifier in identifiers],
                'accounts':[{'id':'balance:000','section':'balance','name':'Fixture'}],
                'months':['2026-04','2026-05','2026-06'], 'last':'2026-06',
                'source_name':'Synthetic fixture','source_url':'https://www.sbs.gob.pe/',
                'unit':'S/ millones','source_note':'Fixture','income_note':'Fixture','coverage_note':'Fixture'}
        panel = {'meta':meta,'series':{'balance:000':{
            '05':{'2026-05':100.0,'2026-06':110.0},
            '15':{'2026-05':10.0,'2026-06':12.0}}}}
        with tempfile.TemporaryDirectory(prefix='iaspe_missing_test_') as temporary:
            path = Path(temporary)/'panel.json.gz'
            with gzip.open(path,'wt',encoding='utf-8') as stream:
                json.dump(panel,stream)
            with patch.object(benchmark_eeff,'DATA_PATH',path):
                result = benchmark_eeff.account_data('balance:000')
        empty, may, june = result['rows']
        self.assertEqual(empty['banks'],{})
        self.assertIsNone(empty['aggregate'])
        self.assertNotIn(institutions.CENCOSUD_ID,may['banks'])
        self.assertEqual(may['categories']['15'],'Empresas financieras')
        self.assertEqual(june['categories']['15'],'Bancos')
        self.assertEqual(may['category_aggregates'],{'Bancos':100.0,'Empresas financieras':10.0})
        self.assertEqual(june['category_aggregates'],{'Bancos':122.0})

    def test_cencosud_identifier_does_not_reuse_internal_bank_or_bcrp_ids(self):
        self.assertEqual(institutions.CENCOSUD_ID,'crac_18')
        self.assertNotIn('18',institutions.BANKS)
        self.assertEqual(len([key for key in institutions.BANKS if key.isdigit()]),16)
        self.assertEqual(institutions.match_entity('Banco Efectiva'),'15')
        self.assertEqual(institutions.match_entity('Financiera Efectiva'),'15')
        self.assertEqual(institutions.match_entity('CRAC Cencosud Scotia'),institutions.CENCOSUD_ID)
        self.assertEqual(institutions.entity_metadata('10','2026-09')['category'],'Empresas financieras')


if __name__ == '__main__':
    unittest.main()
