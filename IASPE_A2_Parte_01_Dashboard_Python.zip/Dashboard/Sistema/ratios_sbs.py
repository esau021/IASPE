"""Benchmark de ratios SBS: entidades comparables y fechas efectivas."""
from __future__ import annotations
import csv
import json
import math
from datetime import date as _system_date
from functools import lru_cache
from pathlib import Path
import os
from instituciones_sbs import BANKS as ENTITY_NAMES, entity_metadata

ROOT = Path(__file__).resolve().parent
CSV_NAME = 'indicadores_16_entidades_principales.csv'

def _find_source():
    # Admite Dashboard junto a IASPE, dentro de IASPE o una ruta explícita.
    override = os.environ.get('IASPE_RATIOS_CSV', '').strip()
    if override and Path(override).is_file():
        return Path(override)
    for parent in (ROOT, *list(ROOT.parents)[:4]):
        for relative in (('Scraper', 'Ratios_financieros_mercado', 'output', CSV_NAME),
                         ('IASPE', 'Scraper', 'Ratios_financieros_mercado', 'output', CSV_NAME)):
            candidate = parent.joinpath(*relative)
            if candidate.is_file():
                return candidate
    return None

SNAPSHOT = ROOT / 'data' / 'ratios_sbs_16_entidades_snapshot.json'

BANKS = list(ENTITY_NAMES.items())
# La denominación visible se mantiene corta; el texto SBS original no se altera.
METRICS = [
 ('ratio_capital_global','Ratio de capital global','Solvencia','%',
  'Patrimonio efectivo entre activos y contingentes ponderados por riesgo. Fecha efectiva del indicador; B-2401 y B-3301 pueden publicarlo con un mes de desfase.'),
 ('capital_nivel_1','Capital de nivel 1 / APR','Solvencia','%',
  'Patrimonio efectivo de nivel 1 sobre activos ponderados por riesgo. Disponible solo en periodos y entidades identificados.'),
 ('cet1','Capital ordinario de nivel 1 / APR','Solvencia','%',
  'Capital ordinario de nivel 1 sobre activos ponderados por riesgo, según el reporte SBS.'),
 ('patrimonio_efectivo_total','Patrimonio efectivo total','Solvencia','S/ miles',
  'Patrimonio efectivo total reportado en los cuadros regulatorios SBS; disponible según formato y periodo.'),
 ('activos_ponderados_riesgo_total','Activos ponderados por riesgo','Solvencia','S/ miles',
  'Activos y contingentes ponderados por riesgo, reportados por la SBS.'),
 ('apalancamiento_pasivo_capital','Pasivo / capital y reservas','Solvencia','veces',
  'Pasivo total entre capital social y reservas.'),
 ('morosidad','Morosidad','Calidad de activos','%',
  'Créditos atrasados (criterio SBS) entre créditos directos.'),
 ('morosidad_90_dias','Créditos con atraso mayor a 90 días','Calidad de activos','%',
  'Créditos atrasados más de 90 días entre créditos directos.'),
 ('creditos_refinanciados','Créditos refinanciados y reestructurados','Calidad de activos','%',
  'Créditos refinanciados y reestructurados entre créditos directos.'),
 ('cobertura_atrasada','Cobertura de cartera atrasada','Calidad de activos','%',
  'Provisiones entre créditos atrasados.'),
 ('cartera_atrasada_ajustada','Cartera atrasada ajustada','Calidad de activos','%',
  'Indicador ajustado publicado por la SBS; solo disponible donde figura en el reporte.'),
 ('cartera_alto_riesgo_ajustada','Cartera de alto riesgo ajustada','Calidad de activos','%',
  'Indicador ajustado publicado por la SBS; solo disponible donde figura en el reporte.'),
 ('morosidad_mn','Morosidad en moneda nacional','Calidad de activos','%',
  'Créditos atrasados MN entre créditos directos MN.'),
 ('morosidad_me','Morosidad en moneda extranjera','Calidad de activos','%',
  'Créditos atrasados ME entre créditos directos ME.'),
 ('eficiencia_operativa','Gastos de operación / margen financiero','Eficiencia y gestión','%',
  'Gastos de operación entre margen financiero total.'),
 ('gastos_administracion_activo','Gastos administrativos / activo productivo','Eficiencia y gestión','%',
  'Gastos de administración anualizados entre activo productivo promedio.'),
 ('ingresos_financieros_sobre_totales','Ingresos financieros / ingresos totales','Eficiencia y gestión','%',
  'Ingresos financieros entre ingresos totales.'),
 ('roe','ROE','Rentabilidad','%',
  'Utilidad neta anualizada entre patrimonio promedio, según la metodología SBS.'),
 ('roa','ROA','Rentabilidad','%',
  'Utilidad neta anualizada entre activo promedio, según la metodología SBS.'),
 ('liquidez_mn','Ratio de liquidez MN','Liquidez','%',
  'Ratio de liquidez en moneda nacional publicado por la SBS.'),
 ('liquidez_me','Ratio de liquidez ME','Liquidez','%',
  'Ratio de liquidez en moneda extranjera publicado por la SBS.'),
]

def _build_from_csv(source: Path):
    metrics={code:{'id':code,'nombre':name,'categoria':cat,'unidad':unit,'descripcion':desc}
             for code,name,cat,unit,desc in METRICS}
    known_banks=dict(BANKS)
    chosen={}
    source_months=set()
    source_urls=set()
    with source.open(encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f):
            code=row['indicador_id'];bank=row['banco_id'];rep=row['reporte']
            if code not in metrics or bank not in known_banks or rep not in ('B-2401','B-2402','B-3301','B-3302','C-2301','C-2257'):
                continue
            try:
                number=float(row['valor'])
            except (TypeError,ValueError):
                continue
            if not math.isfinite(number):continue
            # El capital global se ordena por su fecha regulatoria, no por la del XLS.
            date=(row['fecha_indicador'] if code=='ratio_capital_global' else row['periodo_fuente'])[:7]
            if date<'2016-01' or date>_system_date.today().strftime('%Y-%m'):continue
            key=(code,bank,date)
            priority=2 if rep in ('B-2402','B-3302','C-2257') else 1
            rank=(priority,row['periodo_fuente'][:7])
            previous=chosen.get(key)
            if previous and previous[0]>rank:continue
            if previous and previous[0]==rank and not math.isclose(previous[1][1],number,rel_tol=1e-10,abs_tol=1e-9):
                raise ValueError(f'Ratio SBS ambiguo para {bank}/{code}/{date} en el mismo corte')
            # Una publicación posterior puede revisar el mismo mes efectivo.
            chosen[key]=(rank,[date,number,rep,row['periodo_fuente'],row['celda_valor'],row['url'],row['denominacion_sbs']])
            source_months.add(row['periodo_fuente'][:7])
            source_urls.add(row['url'])
    if not chosen:
        raise ValueError('El CSV no contiene indicadores SBS válidos de las entidades comparables')
    series={m['id']:{b:[] for b,_ in BANKS} for m in metrics.values()}
    for (code,bank,date),(_,entry) in chosen.items():series[code][bank].append(entry)
    for mp in series.values():
        for arr in mp.values():arr.sort(key=lambda x:x[0])
    used=[metrics[m] for m in metrics if any(series[m][b] for b,_ in BANKS)]
    months=set(x[0] for mp in series.values() for arr in mp.values() for x in arr)
    return {'ready':True,'tipo':'oficial','fuente':'Superintendencia de Banca, Seguros y AFP',
            'periodo_inicio':min(months) if months else None,
            'periodo_fin':max(months) if months else None,
            'bancos':[entity_metadata(b, max(months) if months else None) for b,_ in BANKS],
            'indicadores':used,'series':{m['id']:series[m['id']] for m in used},
            'nota_cobertura':'Fuente SBS: B-2401/B-2402 (bancos), B-3301/B-3302 (financieras), C-2301/C-2257 (cajas rurales). Se respeta la fecha efectiva del indicador, que puede diferir del mes del archivo. Las categorías institucionales corresponden al periodo seleccionado. No se imputan periodos sin observación.',
            'periodo_fin_fuente':max(source_months) if source_months else None,
            'origen_datos':'CSV local del scraper IASPE',
            'archivos_sbs_auditados':len(source_urls)}

@lru_cache(maxsize=3)
def _csv_cache(path,mtime_ns,bytes_size):
    return _build_from_csv(Path(path))

@lru_cache(maxsize=2)
def _snapshot(mtime_ns, size):
    return json.loads(SNAPSHOT.read_text(encoding='utf-8'))


def _with_revision(data, stat, *, fallback=False, warning=None):
    result=dict(data)
    result['bancos']=[dict(bank, **entity_metadata(bank['id'], data.get('periodo_fin')))
                     for bank in data.get('bancos', []) if bank['id'] in ENTITY_NAMES]
    result['revision']=f'{stat.st_mtime_ns}:{stat.st_size}'
    result['fallback']=fallback
    if warning:
        result['data_warning']=warning
    return result

def catalog():
    source=_find_source()
    warning=None
    if source is not None:
        try:
            stat=source.stat()
            return _with_revision(_csv_cache(str(source),stat.st_mtime_ns,stat.st_size),stat)
        except (OSError,ValueError,KeyError,UnicodeError) as exc:
            warning='No se pudo leer la base actual; se conserva la copia válida: '+str(exc)[:180]
    if SNAPSHOT.exists():
        try:
            stat=SNAPSHOT.stat()
            return _with_revision(_snapshot(stat.st_mtime_ns,stat.st_size),stat,fallback=True,warning=warning)
        except (OSError,ValueError):pass
    return {'ready':False,'message':'No se encontró el CSV del scraper ni la copia de respaldo del dashboard. Ejecuta el notebook SBS y conserva su carpeta output.'}

if __name__=='__main__':
    import sys
    path=Path(sys.argv[1]) if len(sys.argv)>1 else _find_source()
    if path is None: raise SystemExit('No se encontró el CSV principal del scraper.')
    result=_build_from_csv(path)
    SNAPSHOT.parent.mkdir(parents=True,exist_ok=True)
    SNAPSHOT.write_text(json.dumps(result,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    print(f"Datos oficiales: {len(result['bancos'])} entidades y {len(result['indicadores'])} indicadores; {result['periodo_inicio']}–{result['periodo_fin']}")
