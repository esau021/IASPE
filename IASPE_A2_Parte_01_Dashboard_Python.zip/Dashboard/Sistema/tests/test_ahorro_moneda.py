"""Identidad contable del ahorro del público; no modifica los modelos."""
from __future__ import annotations

import importlib.util
from io import BytesIO
from pathlib import Path
import unittest

SYSTEM=Path(__file__).resolve().parents[1]
PROJECT=SYSTEM.parents[1]/'IASPE'
path=PROJECT/'Scraper/Actualizacion/script/ahorro_moneda_sbs.py'
spec=importlib.util.spec_from_file_location('iaspe_ahorro_moneda_test',path)
ahorro=importlib.util.module_from_spec(spec)
spec.loader.exec_module(ahorro)


def row(label, number, *, indent=0, mn=1000, me=2000):
    return {'statement':'ESF','section':'Pasivo','raw_label':label,
            'leading_spaces':indent,'format_indent':0,'source_row':number,
            'currencies':{key:{'value':value} for key,value in
                          [('MN',mn),('ME',me),('TOTAL',mn+me)]}}


class AhorroMoneda(unittest.TestCase):
    def test_selects_public_savings_even_when_financial_savings_has_same_total(self):
        report={'rows':[row('OBLIGACIONES CON EL PÚBLICO',10),
                        row('Depósitos de Ahorro',11,indent=5),
                        row('DEPÓSITOS DEL SISTEMA FINANCIERO Y ORGANISMOS INTERNACIONALES',20),
                        row('Depósitos de Ahorro',21,indent=4)]}
        self.assertEqual(ahorro.leer_ahorro(report),(1.,2.,11))

    def test_value_match_cannot_select_a_different_account(self):
        report={'rows':[row('OBLIGACIONES CON EL PÚBLICO',10),
                        row('Depósitos de Ahorro',11,indent=5),
                        row('DEPÓSITOS DEL SISTEMA FINANCIERO Y ORGANISMOS INTERNACIONALES',20),
                        row('Depósitos de Ahorro',21,indent=4,mn=1000,me=0)]}
        with self.assertRaises(ValueError):
            ahorro.leer_ahorro(report,total=1.)

    def test_format_indent_identifies_child_without_fixed_excel_row(self):
        public=row('Obligaciones por Cuentas de Ahorro',173)
        public['format_indent']=1
        report={'rows':[row('OBLIGACIONES CON EL PÚBLICO',150),public]}
        self.assertEqual(ahorro.leer_ahorro(report),(1.,2.,173))

    def test_financial_savings_without_public_account_is_rejected(self):
        report={'rows':[row('DEPÓSITOS DEL SISTEMA FINANCIERO Y ORGANISMOS INTERNACIONALES',20),
                        row('Depósitos de Ahorro',21,indent=4)]}
        with self.assertRaises(ValueError):
            ahorro.leer_ahorro(report)

    def test_real_september_2026_matches_original_currency_cells(self):
        source=PROJECT/'Scraper/EEFF_Benchmark/fuentes/B-2201/B-2201-se2026.XLS'
        if not source.exists():
            self.skipTest('Forma A oficial de septiembre2026 no disponible localmente')
        if source.read_bytes().startswith(b'PK'):
            from openpyxl import load_workbook
            book=load_workbook(BytesIO(source.read_bytes()),read_only=True,data_only=True)
            try:
                cells=[book['1'].cell(79,col).value for col in (42,43,44)]
            finally:
                book.close()
        else:
            import xlrd
            book=xlrd.open_workbook(source)
            cells=[book.sheet_by_name('1').cell_value(78,col) for col in (41,42,43)]
        expected=tuple(float(value)/1000 for value in cells[:2])
        _,functions=ahorro.funciones_sbs()
        report=functions['leer_mensual'](source,'2026-09',['Banco Falabella Perú '])
        mn,me,number=ahorro.leer_ahorro(report)
        self.assertEqual((mn,me),expected)
        self.assertEqual(number,79)
        self.assertAlmostEqual(mn+me,float(cells[2])/1000)


if __name__=='__main__':
    unittest.main()
