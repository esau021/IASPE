"""Regressions against manually transcribed cells in the four exact user PDFs.

Set BCRP_PDF_DIR to relocate the source PDFs. Missing PDFs are explicitly
skipped, never silently replaced by a download or synthetic fixture.
"""
from decimal import Decimal
from pathlib import Path
import copy
import hashlib
import json
import os
import sys

import pytest

SYSTEM = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SYSTEM))
from bcrp_documents import current_forecasts, parse_document, validate_document

FIXTURE = json.loads((Path(__file__).parent/'fixtures'/'bcrp_expected.json').read_text(encoding='utf-8'))
PDF_DIR = Path(os.environ.get('BCRP_PDF_DIR', str(Path.home()/'Downloads')))


def exact(value):
    return Decimal(str(value).replace(',', '.'))


def key(row, typ):
    if typ == 'survey':
        return (row['variable'],str(row['year']),row.get('group',''),row.get('survey_date'))
    return (row['variable'],str(row['year']),row.get('revision') or None)


@pytest.fixture(scope='module',params=FIXTURE['documents'],ids=lambda d:d['filename'])
def real_document(request):
    expected=request.param
    path=PDF_DIR/expected['filename']
    if not path.exists():
        pytest.skip(f'Exact source PDF absent: {path}')
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected['sha256'], 'Source bytes differ from exact PDF transcribed'
    parsed=parse_document(path,document_name=path.name)
    return expected,parsed,path


def test_every_published_cell_matches_exactly(real_document):
    expected,parsed,_=real_document
    assert parsed['document']['type']==expected['type']
    assert parsed['document']['edition']==expected['edition']
    validate_document(parsed)
    actual={key(r,expected['type']):r for r in parsed['records']}
    assert len(actual)==len(parsed['records']), 'Duplicated logical cells'
    assert set(actual)=={key(r,expected['type']) for r in expected['expected']}
    for wanted in expected['expected']:
        got=actual[key(wanted,expected['type'])]
        assert exact(got['value'])==exact(wanted['value_text'])
        assert exact(got['value_text'])==exact(wanted['value_text'])
        assert got['page']==wanted['page']


def test_cell_provenance_and_visible_bounds(real_document):
    import pymupdf as fitz
    expected,parsed,path=real_document
    with fitz.open(path) as pdf:
        for row in parsed['records']:
            assert row['source'].startswith('BCRP')
            assert row.get('sha256',row.get('document_hash'))==expected['sha256']
            assert row.get('document',row.get('document_name'))==path.name
            assert row['edition']
            rect=fitz.Rect(row['bbox'])
            assert not rect.is_empty
            assert pdf[row['page']-1].rect.contains(rect), 'Off-page ghost text entered result'
        assert parsed['tables']
        for table in parsed['tables']:
            assert table['page']>=1
            assert pdf[table['page']-1].rect.contains(fitz.Rect(table['bbox']))


def test_current_forecasts_keep_only_latest_column(real_document):
    expected,parsed,_=real_document
    current=current_forecasts(parsed['records'])
    assert len(current)==expected['expected_current_count']
    if expected['type']=='survey':
        assert {r['survey_date'] for r in current}=={'2026-10-30'}
        assert {r['variable'] for r in current}=={'pbi','inflacion','tc_cierre'}
        assert len([r for r in current if r['variable']=='tc_cierre'])==9
    else:
        assert all(r['revision']==expected['edition'] for r in current)
        assert all(r.get('kind')!='historical' for r in current)


def test_integrity_rejects_incomplete_or_ambiguous_result(real_document):
    _,parsed,_=real_document
    incomplete=copy.deepcopy(parsed)
    incomplete['records'].pop()
    with pytest.raises(ValueError):
        validate_document(incomplete)
    duplicate=copy.deepcopy(parsed)
    duplicate['records'].append(copy.deepcopy(duplicate['records'][0]))
    with pytest.raises(ValueError):
        validate_document(duplicate)


def test_integrity_rejects_tampered_provenance_and_offpage_coordinates(real_document):
    _,parsed,_=real_document
    # Values still equal their printed decimals: rejecting these mutations
    # therefore verifies provenance, independently of the numerical tests.
    for field,value in [('source','Otro emisor'),('document','otro.pdf'),
                        ('edition','1999-12'),('document_edition','1999-12')]:
        changed=copy.deepcopy(parsed)
        changed['records'][0][field]=value
        with pytest.raises(ValueError):
            validate_document(changed)
    first=parsed['records'][0]
    width,height=parsed['document']['page_dimensions'][first['page']-1]
    for box in ([-1,10,20,20],[10,10,width+1,20],
                [10,10,20,height+1],[10,10,float('nan'),20]):
        changed=copy.deepcopy(parsed)
        changed['records'][0]['bbox']=box
        with pytest.raises(ValueError):
            validate_document(changed)
    changed=copy.deepcopy(parsed)
    changed['records'][0]['page']=len(changed['document']['page_dimensions'])+1
    with pytest.raises(ValueError):
        validate_document(changed)


def test_september_2026_explicit_revisions():
    expected=next(d for d in FIXTURE['documents'] if d['edition']=='2026-09')
    path=PDF_DIR/expected['filename']
    if not path.exists():
        pytest.skip(f'Exact source PDF absent: {path}')
    parsed=parse_document(path,document_name=path.name)
    lookup={(r['variable'],str(r['year']),r.get('revision')):exact(r['value']) for r in parsed['records']}
    assert lookup['pbi','2026','2026-06']==Decimal('3.4')
    assert lookup['pbi','2026','2026-09']==Decimal('3.2')
    assert lookup['pbi','2027','2026-06']==Decimal('3.2')
    assert lookup['pbi','2027','2026-09']==Decimal('3.0')
    assert lookup['inflacion','2026','2026-06']==Decimal('3.8')
    assert lookup['inflacion','2026','2026-09']==Decimal('4.2')
    assert lookup['inflacion','2027','2026-06']==Decimal('2.0')
    assert lookup['inflacion','2027','2026-09']==Decimal('2.0')


def test_current_revision_per_target_year_and_variable():
    rows=[dict(source='BCRP · Reporte de Inflación',variable='pbi',year='2026',
               edition=revision,document_edition=document,revision=revision,value=value,
               kind='anual',group='')
          for revision,document,value in [('2025-12','2025-12',3.0),('2025-12','2026-09',3.0),
                                           ('2026-06','2026-09',3.4),('2026-09','2026-09',3.2)]]
    rows.append(dict(rows[0],year='2025',value=3.3))
    current=current_forecasts(rows)
    assert len(current)==2
    assert {str(r['year']):r['value'] for r in current}=={'2025':3.3,'2026':3.2}


def test_reproduced_vintage_retains_both_documentary_citations_without_duplication():
    base=dict(source='BCRP · Reporte de Inflación',variable='pbi',year='2026',
              edition='2026-06',revision='2026-06',value=3.4,value_text='3,4',
              kind='anual',group='',page=6,bbox=[100,100,120,110])
    first=dict(base,document='junio.pdf',document_edition='2026-06',sha256='a'*64)
    reproduced=dict(base,document='setiembre.pdf',document_edition='2026-09',sha256='b'*64)
    records=[first,reproduced,copy.deepcopy(reproduced)]
    unchanged=copy.deepcopy(records)
    current=current_forecasts(records)
    assert len(current)==1 and current[0]['value']==3.4
    assert len(current[0]['evidence'])==2
    assert {(e['document'],e['sha256'],e['document_edition']) for e in current[0]['evidence']}=={
        ('junio.pdf','a'*64,'2026-06'),('setiembre.pdf','b'*64,'2026-09')}
    assert records==unchanged, 'Selection must not mutate the original extracted records'


def test_conflicting_reproduction_of_same_vintage_is_rejected():
    base=dict(source='BCRP · Reporte de Inflación',variable='pbi',year='2026',
              edition='2026-06',revision='2026-06',value=3.4,kind='anual',group='')
    with pytest.raises(ValueError):
        current_forecasts([base,dict(base,value=3.5,document_edition='2026-09')])


def test_unknown_or_corrupt_pdf_rejected():
    for body in (b'',b'<html>not a PDF</html>',b'%PDF-1.7\ncorrupt'):
        with pytest.raises(ValueError):
            parse_document(body,document_name='unknown.pdf')
