"""Descarga B-2389 y conserva una base de mercado independiente de la interfaz.
No modifica los JSON activos, el manifiesto existente ni los modelos.
"""
from __future__ import annotations
import csv
import hashlib
import io
import json
import math
import re
import sys
import time
import unicodedata
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
DASHBOARD = HERE.parents[1]
sys.path.insert(0, str(DASHBOARD / 'vendor'))
import xlrd
import openpyxl

CATALOGUE = 'https://www.sbs.gob.pe/app/stats_net/stats/EstadisticaSistemaFinancieroResultados.aspx?c=B-2389'
MONTHS = [('en','Enero'),('fe','Febrero'),('ma','Marzo'),('ab','Abril'),('my','Mayo'),('jn','Junio'),('jl','Julio'),('ag','Agosto'),('se','Setiembre'),('oc','Octubre'),('no','Noviembre'),('di','Diciembre')]
FIRST, LAST = date(2010,10,1), date(2026,8,1)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def norm(value):
    return ' '.join(''.join(c for c in unicodedata.normalize('NFD',str(value or '').lower()) if not unicodedata.combining(c)).replace('*','').split())


def unique(values, label):
    values=list(values)
    if len(values)!=1:
        raise ValueError(f'{label}: se esperaba un resultado, se encontro {values}')
    return values[0]


def col(index):
    text=''
    index+=1
    while index:
        index, r=divmod(index-1,26)
        text=chr(65+r)+text
    return text


def num(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
        raise ValueError(f'Dato no numerico: {value!r}')
    return float(value)


def read_rows(raw):
    if raw[:2]==b'PK':
        book=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=True)
        sheet=book.worksheets[0]
        result=sheet.title,list(sheet.values)
        book.close()
        return result
    if raw[:8]!=bytes.fromhex('D0CF11E0A1B11AE1'):
        raise ValueError('La respuesta no es un archivo Excel real')
    book=xlrd.open_workbook(file_contents=raw)
    sheet=book.sheet_by_index(0)
    return sheet.name,[sheet.row_values(i) for i in range(sheet.nrows)]


def extract(raw, day):
    sheet, rows=read_rows(raw)
    consumption, label_col=unique(((r,c) for r,row in enumerate(rows) for c,x in enumerate(row) if norm(x)=='creditos de consumo'),'consumo')
    labels=[norm(row[label_col]) if len(row)>label_col else '' for row in rows]
    header=unique((r for r,row in enumerate(rows) if any('total banca multiple' in norm(x) for x in row)),'encabezado')
    market_col=unique((c for c,x in enumerate(rows[header]) if 'total banca multiple' in norm(x)),'total banca multiple')
    bank_col=unique((c for c,x in enumerate(rows[header]) if 'falabella' in norm(x)),'Banco Falabella incluido')
    end=next((r for r in range(consumption+1,len(rows)) if labels[r].startswith('creditos ') and not labels[r].startswith('creditos por ')),len(rows))
    find=lambda text: unique((r for r in range(consumption+1,end) if labels[r]==text),text)
    cards, loans, revolving, subtotal = [find(s) for s in ['tarjetas de credito','prestamos no revolventes','prestamos revolventes','prestamos']]
    total=unique((r for r,s in enumerate(labels) if s.startswith('total creditos directos')),'creditos directos')
    if not any('en porcentaje' in s for s in labels[:5]) or 'miles' not in labels[total] or 's/' not in labels[total]:
        raise ValueError('Unidades no verificadas')
    dates=[]
    for row in rows[:5]:
        x=row[label_col]
        if isinstance(x,(datetime,date)):
            dates.append(date(x.year,x.month,1))
        elif isinstance(x,(int,float)) and 40000 <= x <= 50000:
            d=date(1899,12,30)+timedelta(days=int(x))
            dates.append(date(d.year,d.month,1))
        elif isinstance(x,str):
            match=re.fullmatch(r'(?:al\s+)?(\d{1,2})\s+de\s+([a-z]+)\s+de\s+(\d{4})',norm(x))
            if match:
                names={norm(name):i for i,(_,name) in enumerate(MONTHS,1)}
                names['septiembre']=9
                d=date(int(match[3]),names[match[2]],int(match[1]))
                dates.append(date(d.year,d.month,1))
    if unique(dates,'fecha interna')!=day:
        raise ValueError(f'Fecha interna distinta a {day}')
    direct=num(rows[total][market_col])
    cp,lp,rp,sp=[num(rows[r][market_col]) for r in [cards,loans,revolving,subtotal]]
    if not all(0<=p<=100 for p in [cp,lp,rp,sp]) or direct<=0:
        raise ValueError('Porcentajes o total fuera de rango')
    if abs(sp-lp-rp)>1e-10:
        raise ValueError('Prestamos no concilia con revolventes + no revolventes')
    if cp+lp>num(rows[consumption][market_col])+1e-10:
        raise ValueError('Modalidades exceden consumo')
    bank_totals=[num(rows[total][c]) for c in range(label_col+1,market_col) if isinstance(rows[total][c],(int,float))]
    residual=sum(bank_totals)-direct
    tolerance=32*(sum(math.ulp(v) for v in bank_totals)+math.ulp(direct))
    if abs(residual)>tolerance:
        raise ValueError(f'El total de bancos no concilia: {residual}')
    if not label_col<bank_col<market_col:
        raise ValueError('No se comprobo inclusion de Falabella en el agregado')
    cards_mm=cp*direct/100/1000
    loans_mm=lp*direct/100/1000
    cell=lambda r,c: f'{col(c)}{r+1}'
    return {
      'fecha':day.isoformat(),
      'tarjetas_credito_consumo_millones_soles':cards_mm,
      'prestamos_consumo_no_revolventes_millones_soles':loans_mm,
      'cartera_comparable_millones_soles':cards_mm+loans_mm,
      'porcentaje_tarjetas_credito_consumo':cp,
      'porcentaje_prestamos_consumo_no_revolventes':lp,
      'creditos_directos_total_miles_soles':direct,
      'hoja':sheet,
      'celda_tarjetas':cell(cards,market_col),
      'celda_prestamos_no_revolventes':cell(loans,market_col),
      'celda_creditos_directos':cell(total,market_col),
      'columna_falabella':col(bank_col),
      'encabezado_total_banca_multiple':str(rows[header][market_col]),
      'entidades_incluidas':[str(rows[header][c]) for c in range(label_col+1,market_col) if str(rows[header][c]).strip()],
      'residuo_total_bancos_miles_soles':residual,
      'notas_originales':[str(row[label_col]) for row in rows[total+1:] if len(row)>label_col and isinstance(row[label_col],str) and row[label_col].strip()]
    }


def main():
    # Se controla todo archivo previo del dashboard fuera de esta nueva base.
    protected={str(p):sha(p.read_bytes()) for p in DASHBOARD.rglob('*') if p.is_file() and HERE not in p.parents and '__pycache__' not in p.parts}
    manifest=json.loads((DASHBOARD/'fuentes'/'manifest_complementos.json').read_text(encoding='utf-8'))
    existing={x['file']:x for x in manifest['items'] if x['code']=='B-2389' and x.get('status')=='ok'}
    periods=[]
    for year in range(FIRST.year,LAST.year+1):
        for month in range(1,13):
            day=date(year,month,1)
            if FIRST<=day<=LAST:
                periods.append(day)
    raw_dir=HERE/'fuentes'
    raw_dir.mkdir(exist_ok=True)
    def acquire(day):
        code,month_name=MONTHS[day.month-1]
        name=f'B-2389-{code}{day.year}.XLS'
        url=f'https://intranet2.sbs.gob.pe/estadistica/financiera/{day.year}/{month_name}/{name}'
        old=existing.get(name)
        if old:
            path=DASHBOARD/'fuentes'/'SBS_B2389'/name
            raw=path.read_bytes()
            if sha(raw)!=old['sha256']:
                raise ValueError(f'Hash fuente existente distinto: {name}')
            url=old['url']
            origin='Archivo SBS ya descargado; hash verificado'
        else:
            path=raw_dir/name
            if path.exists():
                raw=path.read_bytes()
                origin='Descarga SBS conservada en esta base'
            else:
                for attempt in range(3):
                    try:
                        with urllib.request.urlopen(url,timeout=45) as response:
                            raw=response.read()
                        extract(raw,day)
                        path.write_bytes(raw)
                        break
                    except Exception:
                        if attempt==2: raise
                        time.sleep(attempt+1)
                origin='Descarga directa SBS'
        value=extract(raw,day)
        value.update(url_sbs=url,archivo_original=str(path.resolve()),sha256=sha(raw),bytes=len(raw),origen_archivo=origin)
        return value
    records=[]
    with ThreadPoolExecutor(max_workers=4) as pool:
        for i,value in enumerate(pool.map(acquire,periods),1):
            records.append(value)
            if i%24==0 or i==len(periods):
                print(f'{i}/{len(periods)} meses verificados; ultimo {value["fecha"]}',flush=True)
    if len(records)!=191 or [r['fecha'] for r in records]!=[d.isoformat() for d in periods]:
        raise ValueError('La secuencia mensual no es completa')
    active=json.loads((DASHBOARD/'data'/'cartera_historica.json').read_text(encoding='utf-8'))
    # Control contra la historia utilizada actualmente; no se escribe en ella.
    active_rows=active.get('monthly',[])
    by_date={r['fecha']:r for r in records}
    overlap=0
    for r in active_rows:
        if r.get('date') in by_date:
            d=by_date[r['date']]
            for old_key,new_key in [('marketCards','tarjetas_credito_consumo_millones_soles'),('marketLoans','prestamos_consumo_no_revolventes_millones_soles')]:
                if old_key in r and d[new_key]!=r[old_key]:
                    raise ValueError('La historia existente cambio en '+r['date'])
            overlap+=1
    metadata={
      'titulo':'Cartera de consumo comparable de la banca multiple',
      'catalogo_sbs':CATALOGUE,
      'metodo_enlaces':'Catalogo B-2389 consultado; enlaces de archivos anteriores construidos segun patron mensual oficial y validados por descarga Excel real y fecha interna. Se conservan los enlaces del manifiesto existente para 2016 en adelante.',
      'universo_historico':'Total Banca Multiple tal como publicado cada mes; se conservan los encabezados originales de cada entidad, incluidas sus menciones de sucursales en el exterior. No se fuerza un universo bancario constante.',
      'fecha_extraccion_utc':datetime.now(timezone.utc).isoformat(),
      'periodo_inicial':records[0]['fecha'],'periodo_final':records[-1]['fecha'],'meses':len(records),
      'unidad_saldos':'Millones de soles; moneda total; saldos brutos de creditos directos antes de provisiones',
      'formula_modalidad':'porcentaje de la modalidad x total creditos directos en miles de soles / 100 / 1000',
      'formula_cartera':'Tarjetas de credito del segmento consumo + prestamos de consumo no revolventes',
      'banca_multiple_incluye_falabella':True,
      'otros_prestamos_revolventes_excluidos':True,
      'no_sumar_otra_vez_prestamos_autos':'Es un desglose dentro de prestamos no revolventes, no una partida adicional',
      'enero_septiembre_2010':'No publicados en el catalogo B-2389 consultado; no se imputan',
      'cambio_cobertura_2021':'Desde enero2021 los financiamientos no revolventes independientes de la linea de tarjeta se registran como prestamos. Se conservan los datos publicados, sin empalme artificial; revisar al estimar las modalidades por separado.',
      'solo_observado':True,'interfaz_modificada':False,
      'archivos_existentes_verificados':sum(r['origen_archivo'].startswith('Archivo SBS ya') for r in records),
      'archivos_anteriores_incorporados':sum(not r['origen_archivo'].startswith('Archivo SBS ya') for r in records),
      'meses_coincidentes_con_base_activa':overlap,
      'registros':records
    }
    (HERE/'trazabilidad.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    fields=['fecha','tarjetas_credito_consumo_millones_soles','prestamos_consumo_no_revolventes_millones_soles','cartera_comparable_millones_soles']
    with (HERE/'Cartera_consumo_banca_multiple.csv').open('w',newline='',encoding='utf-8-sig') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore')
        writer.writeheader();writer.writerows(records)
    changed=[path for path,expected in protected.items() if sha(Path(path).read_bytes())!=expected]
    if changed:
        raise ValueError(f'Se modificaron archivos ajenos a la base: {changed}')
    print(json.dumps({'carpeta':str(HERE),'meses':len(records),'primero':records[0],'ultimo':records[-1],'archivos_previos_intactos':len(protected),'meses_coincidentes_base_activa':overlap},ensure_ascii=False),flush=True)

if __name__=='__main__':
    main()

