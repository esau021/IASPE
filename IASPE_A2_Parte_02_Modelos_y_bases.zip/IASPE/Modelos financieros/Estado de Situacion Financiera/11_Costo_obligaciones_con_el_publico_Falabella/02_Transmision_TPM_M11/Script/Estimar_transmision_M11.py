from pathlib import Path
import csv
import json
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
from statsmodels.stats.diagnostic import acorr_ljungbox, breaks_cusumolsresid
from artifact_tool import Workbook, SpreadsheetFile

BASE = Path(__file__).resolve().parents[1]
INPUT = BASE / 'Input' / 'Series_mensuales_M11_BCRP.csv'
OUTPUT = BASE / 'Output'
DASHBOARD = BASE.parents[4] / 'Dashboard' / 'Sistema' / 'data' / 'transmision_tpm_m11.json'

with INPUT.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f))
months = [row['Mes'] for row in rows]
tpm = np.array([float(row['TPM_BCRP_pct']) for row in rows])
costo = np.array([float(row['Costo_pasivo_M11_pct']) for row in rows])
assert len(rows) == 129 and months[0] == '2015-12' and months[-1] == '2026-08'
dx, dy = np.diff(tpm), np.diff(costo)

# Misma especificación DL(5) en todas las ventanas.
def estimar(desde, hasta, q=5):
    indices = [k for k in range(q+1, len(months)) if desde <= months[k] <= hasta]
    X = np.array([[dx[k-1-j] for j in range(q+1)] for k in indices])
    Y = np.array([dy[k-1] for k in indices])
    ols = sm.OLS(Y, sm.add_constant(X, has_constant='add')).fit()
    hac = ols.get_robustcov_results(cov_type='HAC', maxlags=min(6, len(Y)//4))
    restriction = np.r_[0, np.ones(q+1)]
    beta = float(restriction @ hac.params)
    se = float(np.sqrt(restriction @ hac.cov_params() @ restriction))
    return {'desde': months[indices[0]], 'hasta': months[indices[-1]], 'n': len(indices),
            'beta': beta, 'se': se, 'ci_inferior': beta-1.96*se, 'ci_superior': beta+1.96*se,
            'r2_ajustado': float(ols.rsquared_adj), 'bic': float(ols.bic),
            'ljungbox_p': float(acorr_ljungbox(ols.resid, lags=[min(12,len(Y)//4)],return_df=True).lb_pvalue.iloc[0]),
            'cusum_p': float(breaks_cusumolsresid(ols.resid, ddof=q+2)[1]),
            'coeficientes': [float(v) for v in hac.params],
            'errores_hac': [float(v) for v in hac.bse],
            'p_valores_hac': [float(v) for v in hac.pvalues]}

periods = [
 ('Hasta 2019', '2015-12', '2019-12'),
 ('Hasta 2022', '2015-12', '2022-12'),
 ('Hasta 2024', '2015-12', '2024-12'),
 ('Hasta ago. 2026', '2015-12', '2026-08'),
 ('2020–ago. 2026', '2020-01', '2026-08'),
 ('2021–ago. 2026', '2021-01', '2026-08'),
 ('2023–ago. 2026', '2023-01', '2026-08'),
]
windows = [{'periodo': label, **estimar(start, end)} for label, start, end in periods]
full = windows[3]
acc = np.cumsum(full['coeficientes'][1:])
response = [{'mes': i, 'beta_individual': full['coeficientes'][i+1],
             'beta_acumulado': float(acc[i]), 'proporcion_total': float(acc[i]/full['beta']),
             'p_individual': full['p_valores_hac'][i+1]} for i in range(6)]

# Pruebas de cambio de régimen en el vector completo (intercepto y seis betas).
def ruptura(corte):
    ix = list(range(6, len(months)))
    z = np.array([[dx[k-1-j] for j in range(6)] for k in ix])
    grupo = np.array([int(months[k] >= corte) for k in ix])
    M = np.column_stack([np.ones(len(ix)), z, grupo, grupo[:, None]*z])
    fit = sm.OLS(dy[np.array(ix)-1], M).fit().get_robustcov_results(cov_type='HAC', maxlags=6)
    restricciones = np.column_stack([np.zeros((7,7)), np.eye(7)])
    p_conjunto = float(fit.wald_test(restricciones, scalar=True).pvalue)
    vector = np.r_[np.zeros(8), np.ones(6)]
    cambio = float(vector @ fit.params)
    err = float(np.sqrt(vector @ fit.cov_params() @ vector))
    return {'corte': corte, 'p_cambio_vector': p_conjunto, 'cambio_beta': cambio,
            'p_cambio_beta': float(2*norm.sf(abs(cambio/err)))}

breaks = [ruptura('2020-03'), ruptura('2023-01')]
ks = list(range(6, len(months)))
xmat = np.array([[dx[k-1-j] for j in range(6)] for k in ks])
yobs = dy[np.array(ks)-1]
covid = np.array([int('2020-03' <= months[k] <= '2021-07') for k in ks])
with_covid = sm.OLS(yobs, sm.add_constant(np.column_stack([xmat, covid]))).fit()
covid_hac = with_covid.get_robustcov_results(cov_type='HAC', maxlags=6)
covid_beta = float(sum(covid_hac.params[1:7]))

# Evaluación histórica: último mes frente a un coste constante; nunca usa pronósticos.
actual, pred, naive = [], [], []
for k in range(99, len(months)):
    train_x = np.array([[dx[i-1-j] for j in range(6)] for i in range(6, k)])
    train_y = dy[5:k-1]
    regression = sm.OLS(train_y, sm.add_constant(train_x, has_constant='add')).fit()
    forecast = costo[k-1] + float(np.r_[1,[dx[k-1-j] for j in range(6)]]@regression.params)
    pred.append(forecast); actual.append(float(costo[k])); naive.append(float(costo[k-1]))
rmse = lambda a, b: float(np.sqrt(np.mean((np.array(a)-np.array(b))**2)))
metrics = {'rmse_dl5': rmse(actual, pred), 'rmse_naive': rmse(actual, naive),
           'holdout_n': len(actual), 'covid_beta': covid_beta,
           'covid_coef': float(covid_hac.params[-1]), 'covid_p': float(covid_hac.pvalues[-1]),
           'bic_con_covid': float(with_covid.bic)}
assert abs(full['beta'] - 0.5670824465034868) < 1e-9

payload = {'version': '2026-11-13', 'tipo': 'Análisis histórico complementario (no proyecta ni modifica M11)',
           'dependiente': 'Δ costo implícito obligaciones con el público de Banco Falabella, pp',
           'explicativa': 'Δ tasa de referencia del BCRP, pp, rezagos 0–5',
           'fuente': 'Input M11 IASPE y BCRP PD04722MM. Datos observados, dic. 2015–ago. 2026.',
           'full': full, 'periodos': windows, 'respuesta': response,
           'rupturas': breaks, 'metricas': metrics,
           'nota': 'El horizonte de cinco meses es el último rezago incluido; no garantiza que la transmisión económica termine allí. La estabilidad futura del beta no está demostrada.'}

# Excel: datos observados, diferencias y comparación de parámetros.
wb = Workbook.create()
serie = wb.worksheets.add('Datos')
period = wb.worksheets.add('Periodos')
mensual = wb.worksheets.add('Transmision')
pruebas = wb.worksheets.add('Validacion')
serie.get_range('A1:E1').values = [['Mes', 'TPM BCRP (%)', 'Costo M11 (%)', 'Δ TPM (pp)', 'Δ Costo (pp)']]
serie.get_range('A2:C130').values = [[m, float(a), float(b)] for m,a,b in zip(months,tpm,costo)]
serie.get_range('D3:E130').formulas = [[f'=B{r}-B{r-1}',f'=C{r}-C{r-1}'] for r in range(3,131)]
period.get_range('A1:G1').values = [['Periodo', 'Desde', 'Hasta', 'N mensual', 'Beta acumulado', 'IC 95% inf.', 'IC 95% sup.']]
period.get_range('A2:G8').values = [[w['periodo'], w['desde'], w['hasta'], w['n'], w['beta'], w['ci_inferior'], w['ci_superior']] for w in windows]
mensual.get_range('A1:E1').values = [['Mes desde cambio', 'Beta individual (pp)', 'Beta acumulado (pp)', '% del total', 'p-valor HAC']]
mensual.get_range('A2:A7').values = [[r['mes']] for r in response]
mensual.get_range('B2:B7').values = [[r['beta_individual']] for r in response]
mensual.get_range('C2:C7').formulas = [[f'=SUM($B$2:B{r})'] for r in range(2,8)]
mensual.get_range('D2:D7').formulas = [[f'=IFERROR(C{r}/Periodos!$E$5,0)'] for r in range(2,8)]
mensual.get_range('E2:E7').values = [[r['p_individual']] for r in response]
pruebas.get_range('A1:C1').values=[['Prueba / diagnóstico','Valor','Referencia']]
pruebas.get_range('A2:C11').values=[
 ['Beta acumulado',full['beta'],'DL(5), datos observados'],
 ['R² ajustado',full['r2_ajustado'],'En diferencias'],
 ['Ljung–Box p(12)',full['ljungbox_p'],'Residuo, autocorrelación'],
 ['CUSUM p',full['cusum_p'],'Estabilidad, muestra completa'],
 ['RMSE DL(5)',metrics['rmse_dl5'],'Validación creciente, pp'],
 ['RMSE costo previo',metrics['rmse_naive'],'Misma ventana, pp'],
 ['Dummy COVID p',metrics['covid_p'],'Mar. 2020–jul. 2021'],
 ['Beta con COVID',metrics['covid_beta'],'DL(5) + dummy'],
 ['Cambio en vector p (2020-03)',breaks[0]['p_cambio_vector'],'Interacciones / HAC'],
 ['Cambio en vector p (2023-01)',breaks[1]['p_cambio_vector'],'Interacciones / HAC']
]
for sheet, last, columns in [(serie,130,5),(period,8,7),(mensual,7,5),(pruebas,11,3)]:
    rg = sheet.get_range_by_indexes(0,0,last,columns)
    rg.format.font.name = 'Calibri'
    rg.format.font.size = 10
    rg.format.horizontal_alignment = 'justify'
    rg.format.vertical_alignment = 'center'
    rg.format.row_height = 19
    sheet.get_range_by_indexes(0,0,1,columns).format={
        'font':{'name':'Calibri','size':10,'bold':True,'color':'#262626'},
        'fill':'#ECECEC','horizontal_alignment':'justify', 'row_height':23}
    sheet.freeze_panes.freeze_rows(1)
for i,width in enumerate([14,19,20,18,18]): serie.get_range_by_indexes(0,i,130,1).format.column_width=width
for i,width in enumerate([23,15,15,16,21,21,21]): period.get_range_by_indexes(0,i,8,1).format.column_width=width
for i,width in enumerate([21,24,24,18,18]): mensual.get_range_by_indexes(0,i,7,1).format.column_width=width
for i,width in enumerate([33,18,31]): pruebas.get_range_by_indexes(0,i,11,1).format.column_width=width
serie.get_range('B2:E130').set_number_format('0.0000;[Red](0.0000);-')
period.get_range('E2:G8').set_number_format('0.0000;[Red](0.0000);-')
mensual.get_range('B2:C7').set_number_format('0.0000;[Red](0.0000);-')
mensual.get_range('D2:D7').set_number_format('0.0%;[Red](0.0%);-')
mensual.get_range('E2:E7').set_number_format('0.0000;[Red](0.0000);-')
pruebas.get_range('B2:B11').set_number_format('0.0000;[Red](0.0000);-')
OUTPUT.mkdir(exist_ok=True, parents=True)
SpreadsheetFile.export_xlsx(wb).save(str(OUTPUT / 'Transmision_TPM_M11_Falabella.xlsx'))
with (OUTPUT / 'Resultados_periodos.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['Periodo','Inicio','Fin','N','Beta','IC95_inferior','IC95_superior','R2_ajustado'])
    for x in windows: w.writerow([x['periodo'],x['desde'],x['hasta'],x['n'],x['beta'],x['ci_inferior'],x['ci_superior'],x['r2_ajustado']])
with (OUTPUT / 'Respuesta_mensual.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Mes','Beta_individual','Beta_acumulado','Fraccion_beta_total','p_individual_HAC'])
    for x in response:w.writerow([x['mes'],x['beta_individual'],x['beta_acumulado'],x['proporcion_total'],x['p_individual']])
# Datos para la interfaz: información de salida, nunca series de terceros externas.
DASHBOARD.parent.mkdir(parents=True,exist_ok=True)
DASHBOARD.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
print('BETA',full['beta'],'N',full['n'],'RMSE',metrics['rmse_dl5'])
print('Periodos:',[(w['periodo'],round(w['beta'],3)) for w in windows])
print('Pruebas:',breaks)
