"""Depósitos de ahorro por moneda desde la Forma A SBS."""
from __future__ import annotations

import gzip
import json
import math
from pathlib import Path
import unicodedata

ROOT = Path(__file__).resolve().parents[3]
SALIDA = ROOT / 'Scraper' / 'Actualizacion' / 'output' / 'ahorro_moneda_sbs.json'
PANEL = ROOT / 'Scraper' / 'EEFF_Benchmark' / 'output' / 'panel_eeff_16_bancos.json.gz'
MODELO = ROOT / 'Modelos financieros' / 'Estado de Situacion Financiera' / '08_Depositos_ahorro_Falabella'


def normalizar(valor):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(valor or ''))
                   if not unicodedata.combining(c)).strip().upper()


def funciones_sbs():
    carpetas = list((ROOT / 'Estados financieros banca' / 'SBS tal cual').glob('05 Banco Falabella*'))
    if len(carpetas) != 1:
        raise FileNotFoundError('No se encontró la carpeta SBS de Banco Falabella.')
    carpeta = carpetas[0]
    notebooks = list(carpeta.glob('*.ipynb'))
    if len(notebooks) != 1:
        raise FileNotFoundError('No se encontró el notebook SBS de Banco Falabella.')
    notebook = notebooks[0]
    contenido = json.loads(notebook.read_text(encoding='utf-8'))
    codigo = next((''.join(c['source']) for c in contenido['cells']
                   if 'def leer_mensual(' in ''.join(c.get('source', []))), None)
    if codigo is None:
        raise ValueError('El notebook SBS no contiene la lectura mensual.')
    funciones = {'__name__': 'sbs_falabella'}
    exec(compile(codigo, str(notebook), 'exec'), funciones)
    return carpeta, funciones


def leer_ahorro(reporte, total=None):
    """Ahorro del público: no confundirlo con depósitos de otras entidades.

    La Forma A repite el rótulo bajo dos cuentas del pasivo. La jerarquía
    contable identifica la cuenta; el total solo comprueba su conciliación.
    """
    candidatos = []
    grupo = None
    for fila in reporte['rows']:
        if fila['statement'] != 'ESF':
            continue
        if normalizar(fila.get('section')) not in ('PASIVO', 'PASIVO Y PATRIMONIO',
                                                    'PASIVO Y PATRIMONIO NETO'):
            grupo = None
            continue
        raw = str(fila['raw_label'])
        label = normalizar(raw)
        profundidad = max(int(fila.get('leading_spaces') or 0),
                          int(fila.get('format_indent') or 0),
                          len(raw)-len(raw.lstrip()))
        if profundidad == 0:
            grupo = label
        if grupo not in ('OBLIGACIONES CON EL PUBLICO', 'OBLIGACIONES CON PUBLICO'):
            continue
        if label in ('DEPOSITOS DE AHORRO', 'OBLIGACIONES POR CUENTAS DE AHORRO'):
            candidatos.append(fila)
    if len(candidatos) != 1:
        raise ValueError('Forma A: no se identificó una única cuenta de ahorro '
                         f'dentro de obligaciones con el público ({len(candidatos)} coincidencias).')
    fila = candidatos[0]
    valores = []
    for moneda in ('MN', 'ME', 'TOTAL'):
        valor = fila['currencies'][moneda]['value']
        if isinstance(valor, bool) or not isinstance(valor, (int, float)) or not math.isfinite(valor):
            raise ValueError(f'Forma A: ahorro del público sin cifra válida en {moneda}.')
        valores.append(float(valor) / 1000)
    mn, me, suma = valores
    if mn < 0 or me < 0 or abs(mn + me - suma) > 0.01:
        raise ValueError('Forma A: ahorro del público MN + ME no concilia con su total.')
    if total is not None and (not math.isfinite(float(total)) or abs(suma-float(total)) > 0.05):
        raise ValueError('Forma A: ahorro del público MN/ME no concilia con el total SBS.')
    return mn, me, fila['source_row']


def ejecutar(offline=False, latest=None):
    carpeta, funciones = funciones_sbs()
    with gzip.open(PANEL, 'rt', encoding='utf-8') as archivo:
        totales = json.load(archivo)['series']['balance:044']['05']
    referencias = []
    from openpyxl import load_workbook
    for subcarpeta in ('01_Ahorro_MN', '02_Ahorro_ME'):
        libro = load_workbook(MODELO / subcarpeta / 'Input' / 'Base_modelo.xlsx',
                             read_only=True, data_only=True)
        try:
            referencias.append(next(float(fila[1]) for fila in libro['Anual'].values
                                    if fila[0] == 2025))
        finally:
            libro.close()
    config = {'id': 'Falabella', 'name': 'Banco Falabella Perú',
              'folder': carpeta.name, 'code': 'B-2201',
              'aliases': ['Banco Falabella Perú ']}
    if latest:
        year,month=map(int,latest.split('-'))
        periodos=['2025-12']+[f'{y}-{m:02d}' for y in range(2026,year+1) for m in range(1,13)
                                if f'{y}-{m:02d}'<=latest]
    else:
        periodos = ['2025-12'] + sorted(p for p in totales if '2026-01' <= p <= '2030-12')
    series = {'08_mn': {}, '08_me': {}}
    auditoria = {}
    for periodo in periodos:
        ref = funciones['referencia'](config, periodo)
        shared=ROOT/'Scraper/EEFF_Benchmark/fuentes/B-2201'/ref['file']
        legacy=carpeta / '_fuentes' / ref['file']
        ruta = shared if shared.is_file() or not legacy.is_file() else legacy
        if not ruta.exists():
            if offline:
                raise FileNotFoundError(f'Falta la Forma A de {periodo}: {ruta.name}')
            ruta.parent.mkdir(parents=True,exist_ok=True)
            funciones['descargar'](ref['url'], ruta, False)
        reporte = funciones['leer_mensual'](ruta, periodo, config['aliases'])
        mn, me, fila = leer_ahorro(reporte, totales.get(periodo))
        if periodo == '2025-12':
            if any(abs(a - b) > 0.05 for a, b in zip((mn, me), referencias)):
                raise ValueError('Forma A: diciembre de 2025 difiere del Modelo 08.')
        else:
            series['08_mn'][periodo] = mn
            series['08_me'][periodo] = me
            auditoria[periodo] = {'archivo': ruta.name, 'fila': fila,
                                  'mn': mn, 'me': me, 'url': ref['url'],
                                  'sha256': reporte['metadata']['sha256'],
                                  'cuenta': 'Obligaciones con el público / Depósitos de ahorro'}
    if not series['08_mn']:
        raise ValueError('Sin observaciones nuevas de ahorro por moneda.')
    salida = {'series': series, 'auditoria': auditoria,
              'fuente': 'SBS Forma A B-2201', 'ancla': '2025-12'}
    SALIDA.parent.mkdir(parents=True, exist_ok=True)
    temporal = SALIDA.with_suffix('.tmp')
    temporal.write_text(json.dumps(salida, ensure_ascii=False, indent=2), encoding='utf-8')
    temporal.replace(SALIDA)
    return salida


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--solo-cache', action='store_true')
    args = parser.parse_args()
    datos = ejecutar(args.solo_cache)
    print('Ahorro MN/ME:', len(datos['series']['08_mn']), 'meses validados')
