/* Lectura analítica: las cuentas propias, el mercado y la cuota son magnitudes diferentes.
 * Los pronósticos de componentes no forman parte del motor financiero ni sustituyen M48.
 */
(()=>{
'use strict';
const COEFFICIENTS=Object.freeze({
 tarjetas:{constant:-2.366,pbiLag:2.177,unemploymentLag:-1.324},
 prestamos:{constant:20.245,unemploymentChange:-1.887,tpmLag:-2.174}
});
// M48/Input/Base_modelo.xlsx, hoja Anual, año 2025, desempleo (%) publicado.
const UNEMPLOYMENT_2025=5.9;
const can=x=>typeof x==='number'&&Number.isFinite(x);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(x,precision=2)=>can(x)?new Intl.NumberFormat('es-PE',{minimumFractionDigits:precision,maximumFractionDigits:precision}).format(x):'—';
const modelValue=(app,id,year)=>app.model?.(id)?.annual?.find(row=>Number(row.year)===year)?.value;
const macro=(app,id,year)=>{
 const item=(app.state?.data?.macros||[]).find(x=>x.id===id);
 const value=app.state?.changes?.[id]?.[String(year)]??item?.values?.[String(year)];
 return can(value)?value:null;
};
const obs=(catalog,id,period)=>(catalog?.products||[]).find(p=>p.id===id)?.rows?.find(x=>x.date===period);
function components2026(catalog,app){
 const result={};
 for(const [key,id] of [['tarjetas','tarjetas_saldo'],['prestamos','prestamos_no_revolventes']]){
  const series=(catalog?.products||[]).find(p=>p.id===id)?.rows||[];
  const now=[...series].reverse().find(x=>/^2026-(0[1-9]|1[0-2])$/.test(x.date)&&can(x.market));
  if(!now)return null;
  const month=now.date.slice(5),past=obs(catalog,id,`2025-${month}`),dec=obs(catalog,id,'2025-12');
  if(!can(past?.market)||past.market<=0||!can(dec?.market)||dec.market<=0)return null;
  result[key]=dec.market*now.market/past.market;
 }
 const total=modelValue(app,'48',2026);
 if(!can(total)||total<=0)return null;
 const difference=Math.abs(total-result.tarjetas-result.prestamos)/total;
 // No reconciliar artificialmente la serie si proviene de una publicación diferente.
 if(difference>.002)return null;
 return result;
}
function componentSeries(app,catalog){
 const close=components2026(catalog,app);
 if(!close)return null;
 const result={tarjetas:{2026:close.tarjetas},prestamos:{2026:close.prestamos}};
 for(let year=2027;year<=2030;year++){
  const pbiPrior=macro(app,'pbi',year-1),uPrior=macro(app,'desempleo',year-1),u2=year===2027?UNEMPLOYMENT_2025:macro(app,'desempleo',year-2);
  const u=macro(app,'desempleo',year),tpmPrior=macro(app,'tpm',year-1);
  if([pbiPrior,uPrior,u2,u,tpmPrior].some(x=>!can(x)))return null;
  const tc=COEFFICIENTS.tarjetas, nr=COEFFICIENTS.prestamos;
  const growthTC=tc.constant+tc.pbiLag*pbiPrior+tc.unemploymentLag*(uPrior-u2);
  const growthNR=nr.constant+nr.unemploymentChange*(u-uPrior)+nr.tpmLag*tpmPrior;
  result.tarjetas[year]=result.tarjetas[year-1]*Math.exp(growthTC/100);
  result.prestamos[year]=result.prestamos[year-1]*Math.exp(growthNR/100);
  if(!can(result.tarjetas[year])||!can(result.prestamos[year])||result.tarjetas[year]<=0||result.prestamos[year]<=0)return null;
 }
 return result;
}
function series(app,catalog,productId,method='m48'){
 const supported=['consumo_comparable','tarjetas_saldo','prestamos_no_revolventes','tarjetas_numero'];
 if(!supported.includes(productId))return [];
 const comp=productId==='tarjetas_numero'?null:componentSeries(app,catalog);
 if(productId!=='tarjetas_numero'&&(!comp)&&(method==='componentes'||productId!=='consumo_comparable'))return [];
 const modelId={consumo_comparable:'07',tarjetas_saldo:'05',prestamos_no_revolventes:'06',tarjetas_numero:'04'}[productId];
 if(!app.model?.(modelId)||(productId==='tarjetas_numero'&&!app.model('01'))||(productId==='consumo_comparable'&&method==='m48'&&!app.model('48')))return [];
 const result=[];
 for(let year=2026;year<=2030;year++){
  const bank=modelValue(app,modelId,year);
  let market=null;
  if(productId==='consumo_comparable')market=method==='componentes'?comp?.tarjetas?.[year]+comp?.prestamos?.[year]:modelValue(app,'48',year);
  if(productId==='tarjetas_saldo')market=comp?.tarjetas?.[year];
  if(productId==='prestamos_no_revolventes')market=comp?.prestamos?.[year];
  if(productId==='tarjetas_numero')market=modelValue(app,'01',year);
  const valid=can(bank)&&bank>=0&&can(market)&&market>0;
  result.push({date:`${year}-12`,year,status:valid?(year===2026?'assumed':'forecast'):'unavailable',falabella:valid?bank:null,market:valid?market:null,share:valid?100*bank/market:null,
   models:{bank:modelId,market:productId==='consumo_comparable'?(method==='m48'?'48':'componentes'):
     productId==='tarjetas_numero'?'01':'componentes'}});
 }
 return result;
}
function titles(productId,method){
 const bank={consumo_comparable:'M07 · M05 + M06',tarjetas_saldo:'M05',prestamos_no_revolventes:'M06',tarjetas_numero:'M04'}[productId]||'';
 const market=productId==='consumo_comparable'?(method==='componentes'?'2 regresiones · 2 variables c/u':'M48 · modelo vigente'):
     productId==='tarjetas_numero'?'M01 · mercado':'Regresión macro · 2 variables';
 return {bank,market};
}
function yearCards(app,catalog,productId,method='m48',year=2030){
 const rows=series(app,catalog,productId,method),point=rows.find(r=>r.year===year);
 if(!point||!can(point.share))return '';
 const ids=titles(productId,method),unit=productId==='tarjetas_numero'?'tarjetas':'S/ millones';
 return `<section class="market-routes" aria-label="Participación proyectada de mercado">
  <div class="market-routes-top"><div><strong>Proyección 2026–2030</strong><span>Escenario activo</span></div>
    <label>Año <select id="market-routes-year">${[2026,2027,2028,2029,2030].map(y=>`<option value="${y}" ${y===year?'selected':''}>${y}</option>`).join('')}</select></label></div>
  <div class="market-route-flow">
   <article class="market-route-box is-bank"><span class="market-route-overline">01 · FALABELLA</span><strong>${fmt(point.falabella,productId==='tarjetas_numero'?0:2)}</strong><small>${esc(unit)}</small><div class="market-route-model">${ids.bank}</div><em>Modelo de Falabella</em></article>
   <div class="market-route-divider" aria-hidden="true">÷</div>
   <article class="market-route-box is-market"><span class="market-route-overline">02 · MERCADO</span><strong>${fmt(point.market,productId==='tarjetas_numero'?0:2)}</strong><small>${esc(unit)}</small><div class="market-route-model">${ids.market}</div><em>${year===2026?'Cierre supuesto':'Proyección de mercado'}</em></article>
   <div class="market-route-divider" aria-hidden="true">=</div>
   <article class="market-route-box is-share"><span class="market-route-overline">03 · PARTICIPACIÓN</span><strong>${fmt(point.share)} %</strong><small>${year} · cuota implícita</small><div class="market-route-model">Falabella / mercado</div><em>Cuota resultante</em></article>
  </div>
 </section>`;
}
window.IASPEMercadoRutas={series,componentSeries,yearCards,titles};
})();
