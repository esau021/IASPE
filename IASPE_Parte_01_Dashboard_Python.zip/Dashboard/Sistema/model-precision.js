/* Sustentos y explicaciones específicos de las 111 fichas. No modifica los motores. */
(()=>{
'use strict';
window.IASPEPrecision = {
  rationales: {
  "01": "La cantidad de tarjetas del mercado refleja la expansión del acceso al crédito mediante este producto. El crecimiento de la economía permite representar el entorno general en el que los bancos amplían o moderan su oferta de tarjetas y los hogares demandan financiamiento.",
  "02": "Las tarjetas de consumo constituyen una parte específica del mercado de tarjetas de crédito. Su crecimiento se proyecta con la actividad económica porque los cambios en ingresos y consumo agregados suelen acompañar la demanda de nuevos medios de financiamiento.",
  "03": "Las compras con tarjetas representan el valor de las operaciones realizadas por los usuarios, no la deuda pendiente de pago. Para explicar su evolución se consideran la actividad económica, los cambios previos en el empleo y la tasa monetaria, que aportan información sobre la capacidad de gasto y las condiciones del crédito.",
  "04": "El número de tarjetas emitidas por Banco Falabella responde a la evolución de su negocio y no necesariamente crece en la misma proporción que el mercado. La regresión utiliza el comportamiento presente y previo de la economía y la inflación anterior para proyectar su trayectoria particular.",
  "05": "El saldo de crédito revolvente depende de cuánto financiamiento utilizan los clientes y de cuánto amortizan. El crecimiento previo de las compras con tarjetas del mercado aproxima la intensidad de uso del producto, mientras que la actividad económica anterior y el desempleo actual ayudan a representar las condiciones de demanda y capacidad de pago. Las compras del mercado no se confunden con el saldo propio del banco.",
  "06": "Los préstamos no revolventes tienen desembolsos y amortizaciones diferentes de las tarjetas. El modelo explica el cambio anual de su saldo mediante la aceleración económica previa y las compras del mercado, y separa la reclasificación regulatoria de 2021 para no interpretar ese cambio contable como un crecimiento recurrente del negocio.",
  "07": "Las colocaciones brutas de consumo reúnen la cartera revolvente y los préstamos no revolventes. La suma de ambos saldos al mismo cierre permite representar el crédito de consumo completo y evitar que los movimientos de un producto se atribuyan al otro.",
  "08": "El ahorro en moneda nacional y en moneda extranjera no responde necesariamente a los mismos determinantes. Proyectar cada saldo por separado y luego consolidarlos permite conservar la sensibilidad de las captaciones a la actividad, los precios y el tipo de cambio, sin imponer un mismo crecimiento a ambas monedas.",
  "08_mn": "Los depósitos de ahorro en moneda nacional forman parte del fondeo minorista del banco. Su evolución puede acompañar la actividad económica y la inflación porque ambas influyen en la capacidad de ahorro y el valor real de los saldos. El modelo distingue además los años 2024 y 2025 mediante un indicador específico.",
  "08_me": "El ahorro en moneda extranjera incorpora una decisión de tenencia de monedas distinta del ahorro en soles. La variación previa del tipo de cambio permite recoger esa información al proyectar su crecimiento, manteniendo identificada la cartera de depósitos de esta moneda.",
  "09": "Los depósitos a plazo incluyen productos ordinarios y compensación por tiempo de servicios, cuyas dinámicas de permanencia y captación son diferentes. El saldo consolidado se obtiene sumando los dos cierres sin reemplazar sus proyecciones individuales por un crecimiento uniforme.",
  "09_plazo": "Los depósitos a plazo ordinarios representan recursos captados por períodos pactados y su evolución depende de las condiciones económicas y de tasas. La regresión recoge actividad, inflación y cambios de política monetaria, mientras que los ajustes del plan comercial se aplican por separado y no se presentan como coeficientes estimados.",
  "09_cts": "La compensación por tiempo de servicios tiene reglas de depósito y retiro particulares que la diferencian de un depósito a plazo ordinario. Su crecimiento se estima con la trayectoria histórica y un indicador específico de 2021, sin trasladar automáticamente ese episodio al futuro.",
  "10": "Las obligaciones con el público representan una fuente central de financiamiento y abarcan ahorro, depósitos a plazo, depósitos restringidos y otras obligaciones. La composición importa porque una mayor proporción de depósitos a plazo puede modificar el costo financiero incluso si el saldo total no cambia demasiado.",
  "10_restringidos": "Los depósitos restringidos responden a condiciones de disponibilidad diferentes del ahorro ordinario. Para proyectarlos se utiliza primero una comparación interanual de meses observados y, posteriormente, una proporción respecto de ahorro y plazo que conserva su escala dentro del conjunto de captaciones.",
  "10_otras": "Las otras obligaciones con el público completan el fondeo que no se clasifica como ahorro, plazo o depósito restringido. Su proyección mantiene una relación con las captaciones principales después de estimar el cierre de 2026 con meses comparables.",
  "11": "El costo de las obligaciones con el público depende de la tasa que ya pagaba el banco, de las condiciones monetarias y de la mezcla de productos de captación. Los depósitos a plazo suelen tener condiciones de remuneración distintas del ahorro, por lo que su participación ayuda a explicar variaciones del costo medio del fondeo.",
  "12": "Los gastos por intereses proceden de varias fuentes de financiamiento, incluidas las obligaciones con el público, los depósitos de entidades financieras y los adeudos. Se calculan individualmente porque tienen bases y tasas distintas, y luego se suman para obtener el costo financiero anual total.",
  "12_obligaciones": "El gasto por obligaciones con el público se produce por la remuneración de los depósitos que financian al banco. El cálculo relaciona el saldo medio de captaciones con el costo medio implícito y conserva un factor de calibración histórico, por lo que distingue el gasto acumulado del saldo observado al cierre.",
  "12_entidades": "Los depósitos de otras entidades financieras generan intereses con una dinámica distinta de los depósitos de clientes. La tasa monetaria y la inflación ayudan a describir el entorno de remuneración, y el pronóstico se transforma de regreso a unidades monetarias después de estimarse en escala logarítmica.",
  "12_adeudos": "Los adeudos son financiamientos obtenidos de otras instituciones y su gasto depende de las condiciones de tasas. El modelo estima directamente el importe anual con la política monetaria e identifica por separado los años de la pandemia, evitando prolongar ese indicador hacia el horizonte de proyección.",
  "12_otras": "Los intereses de otras fuentes de financiamiento no deben mezclarse con los de las captaciones principales. La tasa de política monetaria rezagada se utiliza como referencia del costo del dinero, y la transformación logarítmica permite modelar gastos de tamaño pequeño sin perder la recuperación del importe anual.",
  "13": "La tasa de tarjetas refleja decisiones de precio crediticio que tienden a ajustarse gradualmente. Se utiliza su nivel del año anterior para captar persistencia y se agregan la tasa monetaria vigente y el crecimiento económico previo para incorporar condiciones de financiamiento y actividad.",
  "14": "Las tasas de préstamos de consumo de mayor plazo suelen mostrar continuidad respecto del año anterior. La tasa de política monetaria aporta una referencia común de las condiciones financieras, mientras que el rezago de la propia tasa recoge esa persistencia.",
  "15": "La tasa pasiva del mercado representa el precio de los depósitos a plazo en el tramo seleccionado. Se relaciona con la tasa de política monetaria y con la inflación del año anterior, que aportan información sobre el entorno de remuneración del ahorro.",
  "16": "Los ingresos por intereses se originan en activos distintos, como créditos, inversiones, disponibilidades y fondos interbancarios. Cada fuente tiene una base de cálculo y rendimiento diferente, de modo que la suma de sus flujos anuales permite explicar mejor los ingresos financieros totales.",
  "16_creditos": "Los intereses de la cartera de créditos dependen tanto del saldo financiado como de su rendimiento. El modelo pronostica ese rendimiento utilizando la tasa de tarjetas del mercado y controles históricos, y posteriormente lo aplica a una base promedio de cartera para obtener ingresos anuales.",
  "16_inversiones": "Los intereses de inversiones dependen de la exposición mantenida y de su rendimiento implícito. El cálculo utiliza inversiones promedio del período y una referencia de rendimiento del cierre de 2026, sin tratarlas como ingresos generados por la cartera de créditos.",
  "16_disponible": "Las disponibilidades pueden generar ingresos cuando los recursos líquidos están remunerados. La actividad económica y la persistencia del ingreso anterior permiten proyectar ese flujo en escala logarítmica, recuperándolo después en unidades monetarias.",
  "16_interbancarios": "Las colocaciones interbancarias generan intereses diferentes de los créditos a clientes. El ingreso anual se estima con su trayectoria histórica y un indicador para los años 2020 y 2021, recuperando después los importes mediante la transformación exponencial.",
  "17": "El disponible reúne efectivo en caja, fondos en bancos y corresponsales, canje y otras posiciones líquidas. La suma distingue los saldos proyectados directamente de los componentes de conciliación que se determinan al cerrar el balance.",
  "17_caja": "La caja representa efectivo disponible para las operaciones. La estimación mensual utiliza el saldo del mes anterior porque el efectivo operativo suele presentar continuidad entre períodos consecutivos, y el saldo anual corresponde a diciembre.",
  "17_bancos": "Los saldos en bancos y corresponsales se utilizan para conciliar el balance proyectado después de determinar los demás activos, pasivos y patrimonio. En esta especificación no deben interpretarse como una estimación independiente de la demanda de liquidez.",
  "17_canje": "El canje representa operaciones en proceso de compensación dentro del disponible. El modelo conserva la última observación para los meses pendientes y la integra como una partida específica, sin extrapolar una regresión no documentada.",
  "17_otros": "Los otros disponibles reúnen recursos líquidos no comprendidos en caja, bancos o canje. Se mantiene la última referencia observada para completar el cierre de 2026 y se incorpora el supuesto posterior previsto para esa partida.",
  "18": "El resultado neto de servicios financieros compara los ingresos cobrados por servicios con sus gastos correspondientes. Al sumar los ingresos y restar los gastos del mismo ejercicio, la cuenta refleja su contribución efectiva al resultado operativo.",
  "18_diversos": "Los ingresos diversos están vinculados tanto al nivel de precios como a la actividad de compras con tarjetas. Se generan dos trayectorias con especificaciones distintas y se combinan sus importes estimados, conservando los pesos definidos en el modelo.",
  "18_otros_ing": "Los otros ingresos por servicios representan comisiones u otros conceptos no incluidos en los ingresos diversos. Se conservan según la fuente financiera original para que el resultado por servicios no omita estas partidas.",
  "18_gastos_div": "Los gastos diversos de servicios acompañan la operación que genera ingresos de la misma categoría. La regla mantiene la proporción entre gasto e ingreso de 2026 y la aplica a los ingresos diversos proyectados, en lugar de estimar una regresión autónoma de gasto.",
  "18_otros_gastos": "Los otros gastos por servicios complementan los gastos diversos. Su incorporación separada permite que el margen de servicios incluya desembolsos que no se determinan por la proporción de gastos diversos sobre ingresos.",
  "18_fsd": "Las primas del Fondo de Seguro de Depósitos corresponden a una obligación asociada a la captación protegida. Se conserva la trayectoria de gasto de la fuente financiera, sin incluirlas erróneamente como ingreso por servicios.",
  "19": "Los gastos administrativos reflejan los recursos necesarios para operar el banco, principalmente personal, directorio, servicios de terceros e impuestos y contribuciones. La consolidación separa partidas con distintos criterios de proyección y conserva la suma contable del ejercicio.",
  "19_personal": "El gasto de personal depende de cuántos trabajadores mantiene el banco, de la remuneración promedio y de la inflación. La dotación se proyecta con la actividad económica y controles históricos; el gasto se actualiza mediante los trabajadores promedio y el ajuste de precios, sin suponer una regresión adicional del importe.",
  "19_directorio": "El gasto de directorio corresponde a la remuneración y otros conceptos previstos para ese órgano. La proyección mantiene el supuesto presupuestario definido, en lugar de vincular artificialmente esta partida con variables macroeconómicas.",
  "19_terceros": "Los servicios de terceros financian actividades contratadas fuera de la nómina. Una trayectoria capta el crecimiento relacionado con la actividad económica y otra incorpora el nivel y la persistencia del gasto; ambas se combinan con los pesos definidos para moderar la dependencia de una sola especificación.",
  "19_impuestos": "Los impuestos y contribuciones operativos forman parte de los gastos administrativos y no deben confundirse con el impuesto a la renta. La proyección actualiza el importe presupuestado de 2026 por la inflación anual prevista.",
  "20": "El resultado de operaciones financieras reúne beneficios y pérdidas procedentes de consorcios, asociadas, inversiones, derivados, diferencia de cambio y otros conceptos financieros. La suma de sus componentes conserva sus signos contables y evita presentar su resultado conjunto como una regresión independiente.",
  "20_consorcios": "Los resultados de consorcios reflejan la participación de estas operaciones en el desempeño financiero. Se mantiene la trayectoria proporcionada por el presupuesto original y se agrega al resultado financiero total con su signo correspondiente.",
  "20_asociadas": "El resultado de subsidiarias y asociadas procede de participaciones en otras entidades, no del otorgamiento de créditos al público. Se utiliza el supuesto financiero propio de esa línea para que su evolución no se confunda con los intereses de cartera.",
  "20_tc": "La diferencia de cambio recoge ganancias o pérdidas relacionadas con movimientos de monedas. La metodología considera conjuntamente la diferencia de cambio y los derivados respecto de las compras del mercado, y después separa el componente de derivados para obtener la diferencia de cambio proyectada.",
  "20_derivados": "Los resultados de derivados de negociación dependen de las posiciones financieras y de su valoración. Se mantiene el presupuesto del componente y se considera su interacción con la diferencia de cambio sin duplicar ambos resultados.",
  "20_inversiones": "El resultado de inversiones incorpora las ganancias o pérdidas financieras diferentes de los intereses que producen esos instrumentos. La proyección conserva el importe presupuestado para no mezclarlo con el rendimiento de inversiones incluido en ingresos por intereses.",
  "20_otros": "Los otros resultados financieros y los asociados a venta de cartera completan el resultado de operaciones financieras. Se incorporan los supuestos originales preservando la clasificación y el signo de cada flujo.",
  "21": "Las inversiones financieras forman parte del activo y pueden responder a decisiones de Tesorería distintas de las de la cartera de créditos. Su saldo reúne instrumentos disponibles para la venta, participaciones en subsidiarias y otras inversiones conforme al plan de cada categoría.",
  "21_venta": "Las inversiones disponibles para la venta se determinan según el plan de Tesorería. Este enfoque refleja decisiones de colocación de recursos en instrumentos financieros y no impone un crecimiento econométrico a posiciones sujetas al presupuesto de inversión.",
  "21_asociadas": "Las inversiones en subsidiarias son participaciones patrimoniales en otras entidades y no ingresos por dichas participaciones. Se mantienen sus saldos previstos y se suman al activo de inversiones, conservando su naturaleza de stock.",
  "21_otras": "Las otras inversiones completan las posiciones financieras no clasificadas como disponibles para la venta ni como participaciones en subsidiarias. El saldo se incorpora conforme al presupuesto y permite que el activo refleje la cartera de inversión completa.",
  "22": "Los fondos interbancarios representan recursos colocados en otras entidades financieras. El modelo conserva el saldo presupuestado de esa posición y lo incorpora al activo sin confundirlo con los fondos interbancarios que el banco recibe como pasivo.",
  "22_interbancarios": "La cuenta de fondos interbancarios del activo refleja una colocación de recursos frente a otras entidades. Su trayectoria parte de los valores presupuestados y se traslada al consolidado de activos sin estimar una regresión no prevista en la fuente.",
  "23": "El margen financiero bruto mide la diferencia entre los ingresos devengados por activos financieros y los gastos pagados por las fuentes de fondeo. Esta identidad permite observar la contribución financiera antes de otras partidas del estado de resultados.",
  "24": "Los otros ingresos y gastos incluyen partidas del resultado no comprendidas en los rubros principales. Se conserva su presupuesto anual para integrar el estado de resultados sin atribuirle una relación macroeconómica que no fue estimada.",
  "25": "Las provisiones para créditos directos reconocen el gasto asociado al deterioro esperado o registrado de la cartera. Al incorporarlas al resultado, la proyección refleja el costo contable del riesgo de crédito además de los intereses que generan las colocaciones.",
  "26": "La depreciación y amortización reconoce en resultados el consumo contable de activos físicos y otros activos amortizables. Su importe se toma del presupuesto de la cuenta y no debe confundirse con la amortización de préstamos otorgados.",
  "27": "Las valuaciones de activos y otras provisiones recogen ajustes por valoración y obligaciones estimadas con impacto en los resultados. Se conservan las cifras presupuestadas para no sustituir partidas contables específicas por supuestos macroeconómicos genéricos.",
  "28": "El impuesto a la renta recoge la obligación tributaria reconocida sobre el desempeño del ejercicio según la fuente financiera. Se utiliza su proyección presupuestaria para cerrar el resultado neto sin introducir una tasa impositiva distinta de la contemplada en el modelo.",
  "29": "El resultado neto se obtiene después de combinar los ingresos financieros, los resultados por servicios y operaciones financieras, los gastos operativos y los demás ajustes del ejercicio. Su coherencia depende de respetar la clasificación y los signos de todas las cuentas del estado de resultados.",
  "30": "Las líneas de crédito no utilizadas constituyen compromisos contingentes que pueden convertirse en desembolsos si los clientes emplean su línea disponible. Se proyectan mediante la cantidad de tarjetas y el promedio reciente de línea disponible por tarjeta, vinculando la exposición con la escala del negocio.",
  "31": "Las cuentas por cobrar netas incluyen derechos de cobro distintos de la cartera crediticia principal. Su crecimiento se proyecta con la actividad real de la economía y se aplica al saldo del cierre anterior, conservando la naturaleza de stock.",
  "32": "Los rendimientos por cobrar representan intereses devengados que aún no han sido cobrados. La variación anual de los ingresos por créditos aporta una referencia para proyectar cómo puede modificarse ese saldo pendiente de cobro.",
  "33": "Los inmuebles, mobiliario y equipo constituyen activos físicos necesarios para la operación bancaria. El saldo neto cambia por inversiones de capital y por depreciación, por lo que su movimiento se mantiene consistente con las partidas presupuestarias de activos fijos.",
  "34": "Los otros activos reúnen partidas que no se clasifican en las categorías principales del balance. Se conservan los supuestos del plan y, cuando corresponde, la relación del activo operativo con la cartera para proyectar los últimos años.",
  "35": "Los depósitos del sistema financiero son una fuente de fondeo distinta de los depósitos del público. Se incorporan según el presupuesto y el saldo contable de referencia para no confundir captaciones interbancarias con ahorro de clientes.",
  "36": "Las obligaciones en circulación no subordinadas son financiamientos emitidos por el banco que generan pasivos de acuerdo con sus condiciones contractuales. Su saldo se mantiene conforme al presupuesto de deuda sin proyectarlo a través de una regresión de depósitos.",
  "37": "Las cuentas por pagar representan obligaciones pendientes con terceros por conceptos distintos de los pasivos financieros principales. La proyección respeta sus supuestos presupuestarios para reconocer esas obligaciones en el balance.",
  "38": "Los intereses y otros gastos por pagar reconocen obligaciones financieras devengadas que todavía no se han desembolsado. Su saldo se relaciona con las cuentas de fondeo correspondientes y con los factores del presupuesto, evitando confundirlo con el gasto anual efectivamente reconocido.",
  "39": "Los otros pasivos reúnen obligaciones que no encajan en las categorías principales. Su saldo se conserva conforme a la trayectoria presupuestada para completar la estructura de financiación del balance.",
  "40": "Las provisiones del pasivo representan compromisos estimados, incluidos los relacionados con créditos indirectos y otros conceptos. Su proyección mantiene la relación presupuestaria con las partidas operativas pertinentes, como el gasto de personal cuando corresponde.",
  "41": "El capital social refleja aportes de los accionistas reconocidos como patrimonio. Su proyección se basa en decisiones de capital presupuestadas, no en un coeficiente macroeconómico.",
  "42": "El capital adicional constituye un componente patrimonial separado del capital social. Su saldo se incorpora conforme a la planificación financiera y a los registros contables previstos.",
  "43": "Las reservas representan recursos del patrimonio retenidos bajo las reglas de asignación correspondientes. Su evolución se utiliza también para conciliar los movimientos desde el resultado del ejercicio hasta los resultados acumulados.",
  "44": "Los ajustes al patrimonio reconocen movimientos patrimoniales distintos de los aportes, reservas y utilidades. Se mantienen sus valores contables previstos para completar el patrimonio proyectado.",
  "45": "Los resultados acumulados representan utilidades de ejercicios anteriores que permanecen en el patrimonio. Su evolución depende de las utilidades aplicables, las transferencias a reservas y los dividendos, por lo que se determina mediante una conciliación de movimientos y no mediante una regresión.",
  "45_dividendos": "Los dividendos son distribuciones de utilidades a los accionistas y reducen los resultados acumulados. La regla utiliza el presupuesto del banco, pero limita la distribución a los resultados disponibles para evitar proyectar un reparto superior a las utilidades aplicables.",
  "45_transferencias_reservas": "Las transferencias a reservas representan movimientos de utilidades hacia otras cuentas patrimoniales. Se toman de la variación presupuestada de reservas y disminuyen la parte de la utilidad que permanece en resultados acumulados.",
  "45_utilidad_aplicada": "La utilidad aplicada procede del resultado neto del ejercicio anterior. Este importe aumenta los resultados disponibles y vincula correctamente el estado de resultados con los movimientos del patrimonio.",
  "46": "El resultado neto del ejercicio integra el patrimonio y debe coincidir con la utilidad neta calculada en el estado de resultados del mismo año. Se traslada esa cifra sin una estimación adicional que pudiera generar diferencias entre ambos estados.",
  "47": "El balance debe cumplir que los activos sean iguales a la suma de pasivos y patrimonio. La conciliación identifica el saldo de bancos y corresponsales necesario para cumplir la identidad una vez determinados los demás componentes proyectados.",
  "47_pasivo": "El total de pasivos representa las obligaciones de la entidad con terceros. La suma de cada partida de fondeo y otros pasivos permite verificar que la estructura de financiación esté completa.",
  "47_patrimonio": "El patrimonio reúne capital, reservas, ajustes y resultados que pertenecen a los accionistas. La agregación de estas partidas permite contrastar las fuentes propias de financiación con los activos proyectados.",
  "47_control": "La diferencia de balance cuantifica cuánto se separan los activos de la suma de pasivos y patrimonio antes o después del ajuste de conciliación. Un valor distinto de cero identifica una inconsistencia de cuadre que debe explicarse.",
  "47_disponible": "El disponible conciliado incorpora los componentes líquidos y el ajuste del saldo en bancos y corresponsales. Se determina al cerrar el balance para evitar dejar una diferencia contable sin asignación.",
  "47_bancos": "Bancos y corresponsales funciona como la partida residual que iguala activos con pasivos más patrimonio. La cifra refleja el mecanismo de cierre del balance y no debe interpretarse como una proyección autónoma de liquidez.",
  "47_creditos_netos": "La cartera neta recoge los créditos después de descontar las provisiones contables aplicables. Mantener separadas las colocaciones brutas y las provisiones permite reflejar el deterioro crediticio en el activo.",
  "47_interbancario_pasivo": "Los fondos interbancarios recibidos son un pasivo por recursos obtenidos de otras entidades financieras. Se distinguen de los fondos interbancarios colocados, que se presentan en el activo.",
  "47_disponible_previo": "El disponible previo es el resultado de proyectar las cuentas líquidas antes de realizar el ajuste residual del balance. Compararlo con el disponible conciliado permite identificar de dónde proviene el ajuste.",
  "47_ajuste_bancos": "El ajuste de bancos y corresponsales mide el cambio requerido entre el saldo líquido inicialmente previsto y el saldo que permite cuadrar el balance. Mantenerlo separado hace visible la magnitud de la conciliación.",
  "47_principal_cert": "El principal de certificados corresponde al monto de deuda excluyendo los intereses devengados clasificados por separado. Esta separación evita duplicar obligaciones al consolidar el pasivo.",
  "48": "La cartera de consumo del conjunto de bancos representa una referencia de mercado para comparar la evolución de Banco Falabella. El modelo utiliza el crecimiento de la economía, el cambio previo del desempleo y la tasa monetaria rezagada para explicar el crecimiento anual de ese mercado.",
  "48_cuota": "La participación de Banco Falabella en el mercado de consumo se calcula comparando su saldo revolvente y no revolvente con el saldo total de consumo de la banca múltiple. La cuota cambia cuando las carteras crecen a ritmos distintos y no se mantiene fija por construcción.",
  "49": "Las amortizaciones representan reducciones del saldo de deuda diferentes de los castigos. Se obtienen conciliando el saldo inicial y final con las compras, disposiciones y desembolsos del año, de manera que cada entrada y salida se contabilice una sola vez.",
  "49_rev": "Las amortizaciones revolventes surgen del repago de tarjetas y otras disposiciones asociadas a esa modalidad. La conciliación separa los pagos de los castigos y utiliza los flujos de compras y RappiCash junto con los saldos de inicio y cierre.",
  "49_nrev": "Las amortizaciones no revolventes reflejan la devolución de préstamos con saldo pendiente. Se obtienen conciliando desembolsos, saldos iniciales y finales y castigos, sin confundir los desembolsos nuevos con repagos.",
  "49_compras": "Las compras de tarjetas de Banco Falabella se relacionan con la cantidad de tarjetas propias y la utilización observada del mercado. El cálculo incorpora una calibración histórica que convierte la actividad del mercado en una referencia de compras del banco.",
  "49_desembolsos": "Los desembolsos no revolventes aumentan el saldo de los préstamos antes de las amortizaciones y castigos. La metodología utiliza una intensidad histórica de desembolsos vinculada con la actividad de esa cartera.",
  "49_disposiciones_rc": "Las disposiciones de RappiCash son utilizaciones de crédito que no corresponden a compras con tarjeta ni a desembolsos de préstamos convencionales. Se proyectan a partir de una relación histórica con el uso de tarjetas para evitar duplicar flujos.",
  "49_tasa_rev": "La tasa de amortización revolvente compara los repagos implícitos con el saldo inicial más las nuevas utilizaciones del año. Ese denominador representa los recursos que estuvieron disponibles para ser amortizados durante el ejercicio.",
  "49_tasa_nrev": "La tasa de amortización no revolvente mide los repagos respecto del saldo inicial y los nuevos préstamos desembolsados. Así distingue la devolución de capital del volumen nuevo de financiamiento otorgado.",
  "49_tc": "Las amortizaciones de tarjetas constituyen la parte de las amortizaciones revolventes que no corresponde a RappiCash. Se distribuye el total con la participación calculada para cada producto, manteniendo el cuadre de los repagos.",
  "49_rc": "Las amortizaciones de RappiCash se identifican asignando una proporción de las amortizaciones revolventes totales a ese producto. El porcentaje se actualiza con la pauta de participación definida en el modelo.",
  "49_pe": "Las amortizaciones de préstamos efectivos equivalen a las amortizaciones no revolventes de la conciliación. Se conserva esta equivalencia para no introducir un segundo cálculo de repagos para el mismo saldo.",
  "49_part_rc": "La participación de RappiCash en las amortizaciones revolventes se obtiene a partir del patrón histórico de salidas de ese producto. Su aplicación permite repartir el total de repagos entre tarjetas y RappiCash sin alterar el importe conciliado."
},
  terms: {
  "22": [
    {
      "label": "Fondos interbancarios colocados",
      "definition": "Se utiliza el saldo de fondos interbancarios del activo registrado en la proyección del componente 22_interbancarios. Para cada ejercicio se incorpora el importe de cierre, no los ingresos por intereses de esas colocaciones.",
      "motivation": "Permite mantener identificados los recursos colocados en otras entidades y sumarlos al activo sin confundirlos con financiamiento interbancario recibido."
    }
  ],
  "24": [
    {
      "label": "Otros ingresos y gastos presupuestados",
      "definition": "Se utiliza el importe neto anual de la cuenta procedente de los resultados originales. La serie conserva el cierre supuesto de 2026 y los valores previstos para los años posteriores sin recalcular coeficientes.",
      "motivation": "Completa el estado de resultados con los conceptos que no forman parte del margen financiero ni de las otras líneas principales."
    }
  ],
  "25": [
    {
      "label": "Provisiones para créditos directos",
      "definition": "Se incorpora el gasto anual de provisiones para incobrabilidad de créditos previsto en la fuente financiera. No se convierte el saldo de provisiones del balance en gasto del ejercicio.",
      "motivation": "Reconoce el efecto del deterioro crediticio sobre la utilidad proyectada y mantiene separado el flujo de gasto de la cobertura acumulada de la cartera."
    }
  ],
  "26": [
    {
      "label": "Depreciación y amortización contable",
      "definition": "Se toma el gasto anual presupuestado por depreciación de activos físicos y amortización de otros activos sujetos a ese reconocimiento. Corresponde a una partida del estado de resultados.",
      "motivation": "Descuenta el consumo contable de activos necesario para obtener la utilidad del ejercicio y evita confundir este gasto con el repago de préstamos."
    }
  ],
  "27": [
    {
      "label": "Valuaciones y otras provisiones",
      "definition": "Se utilizan los importes anuales presupuestados por ajustes de valoración y otras provisiones del estado de resultados, conservando su clasificación y signo.",
      "motivation": "Incluye pérdidas o ajustes contables que afectan la rentabilidad aunque no sean intereses ni gastos administrativos."
    }
  ],
  "28": [
    {
      "label": "Impuesto a la renta del ejercicio",
      "definition": "Se incorpora la cifra anual proyectada de impuesto a la renta registrada en el estado de resultados original, de acuerdo con la base y el tratamiento de la fuente.",
      "motivation": "Permite calcular el resultado después de impuestos sin imponer una tasa tributaria nueva que no esté documentada en la fuente."
    }
  ],
  "29": [
    {
      "label": "Margen financiero bruto",
      "definition": "Se incorpora el margen obtenido al comparar ingresos por intereses y gastos por intereses del mismo año, calculado por el Modelo 23.",
      "motivation": "Traslada la rentabilidad financiera básica al resultado del ejercicio, antes de otros ingresos y gastos."
    },
    {
      "label": "Resultado de servicios financieros",
      "definition": "Se toma el resultado neto de ingresos y gastos por servicios financieros del Modelo 18, con el signo de la cuenta.",
      "motivation": "Incorpora la contribución de comisiones y servicios fuera de los intereses."
    },
    {
      "label": "Resultado de operaciones financieras",
      "definition": "Se incluye el resultado de operaciones financieras del Modelo 20 con sus ganancias o pérdidas netas.",
      "motivation": "Reconoce la contribución de inversiones, tipo de cambio, derivados y otras operaciones financieras al resultado."
    },
    {
      "label": "Gastos administrativos",
      "definition": "Se utiliza el importe de gastos de personal, directorio, servicios de terceros e impuestos y contribuciones del Modelo 19.",
      "motivation": "Refleja los recursos operativos que el banco necesita para desarrollar su actividad y que reducen la utilidad."
    },
    {
      "label": "Otros ingresos y gastos, provisiones, depreciación e impuestos",
      "definition": "Se incorporan las partidas de los Modelos 24, 25, 26, 27 y 28 con su tratamiento contable correspondiente. Los importes se toman de sus proyecciones anuales.",
      "motivation": "Completa los ajustes necesarios para llegar al resultado neto sin omitir gastos por deterioro, depreciación o impuesto a la renta."
    }
  ],
  "33": [
    {
      "label": "Saldo neto de activos fijos",
      "definition": "Se incorpora el saldo de inmuebles, mobiliario y equipo neto según el presupuesto de activos fijos del banco al cierre de cada año.",
      "motivation": "Representa recursos físicos todavía reconocidos como activos después del desgaste contable acumulado."
    },
    {
      "label": "Inversión y depreciación",
      "definition": "Se consideran los movimientos presupuestados por adquisición o mejora de activos y por depreciación, según la relación de la fuente.",
      "motivation": "Explica por qué el saldo neto puede cambiar aun cuando el banco mantenga el mismo nivel de actividad."
    }
  ],
  "34": [
    {
      "label": "Componentes presupuestados de otros activos",
      "definition": "Se utilizan los saldos anuales de partidas que no corresponden a créditos, disponible, inversiones ni activos fijos principales.",
      "motivation": "Permite completar el activo del balance sin asignar estos saldos a categorías incorrectas."
    },
    {
      "label": "Activo operativo vinculado a cartera",
      "definition": "En los ejercicios finales en que la fuente lo establece, el componente operativo acompaña el crecimiento previsto de la cartera.",
      "motivation": "Mantiene la relación presupuestaria del activo operativo con la escala de operaciones, sin inventar parámetros para los demás conceptos."
    }
  ],
  "35": [
    {
      "label": "Saldo de depósitos del sistema financiero",
      "definition": "Se incorpora el saldo presupuestado de captaciones de otras entidades financieras a diciembre, contrastado con la referencia contable utilizada en la fuente.",
      "motivation": "Registra una fuente de financiación institucional distinta de los depósitos de clientes que forman las obligaciones con el público."
    }
  ],
  "36": [
    {
      "label": "Obligaciones emitidas no subordinadas",
      "definition": "Se utiliza el importe de deuda emitida en circulación previsto por el banco para cada cierre anual.",
      "motivation": "Representa financiamiento obtenido mediante instrumentos de deuda sin confundirlo con capital propio ni deuda subordinada."
    }
  ],
  "37": [
    {
      "label": "Obligaciones comerciales y otras cuentas por pagar",
      "definition": "Se incorpora el saldo contable de cuentas por pagar del cierre supuesto y los valores posteriores de la proyección original.",
      "motivation": "Registra compromisos pendientes con terceros distintos de los componentes principales de captación bancaria."
    }
  ],
  "38": [
    {
      "label": "Obligaciones de fondeo e intereses devengados",
      "definition": "La base de cálculo considera las obligaciones financieras relacionadas con el devengo de intereses y otros gastos, utilizando los factores de la hoja de supuestos financieros.",
      "motivation": "Vincula los importes por pagar con la fuente de fondeo que los origina, sin tratarlos como gasto anual ya pagado."
    }
  ],
  "39": [
    {
      "label": "Otros pasivos presupuestados",
      "definition": "Se utiliza el saldo anual de otras obligaciones que figura en el presupuesto del estado de situación financiera.",
      "motivation": "Completa el pasivo con conceptos que no corresponden a depósitos, deudas o cuentas por pagar principales."
    }
  ],
  "40": [
    {
      "label": "Provisiones por créditos indirectos",
      "definition": "Se incorporan las provisiones del pasivo asociadas a compromisos crediticios indirectos según la proyección presupuestaria.",
      "motivation": "Reconoce obligaciones estimadas que se registran como pasivo y no como provisiones deducidas de créditos directos."
    },
    {
      "label": "Otras provisiones relacionadas con gastos operativos",
      "definition": "El componente de otras provisiones mantiene la relación prevista en la fuente con las cuentas operativas, incluido el gasto de personal cuando corresponde.",
      "motivation": "Incorpora compromisos operativos estimados de forma coherente con el presupuesto de gastos del banco."
    }
  ],
  "41": [
    {
      "label": "Capital social presupuestado",
      "definition": "Se mantiene el saldo de capital social de cierre aprobado o supuesto en la planificación, con los movimientos de capital que figuran en la fuente.",
      "motivation": "Reconoce el financiamiento aportado por los accionistas, diferente de utilidades y reservas."
    }
  ],
  "42": [
    {
      "label": "Capital adicional presupuestado",
      "definition": "Se incorpora el saldo anual del rubro capital adicional registrado en la proyección patrimonial original.",
      "motivation": "Mantiene separadas las aportaciones y otras partidas de capital adicional respecto del capital social."
    }
  ],
  "43": [
    {
      "label": "Reservas patrimoniales",
      "definition": "Se utiliza el saldo previsto de reservas para cada cierre y sus cambios entre años, conforme a la fuente.",
      "motivation": "Refleja la parte de utilidades que permanece en el patrimonio bajo esta clasificación y alimenta la conciliación con los resultados acumulados."
    }
  ],
  "44": [
    {
      "label": "Ajustes al patrimonio",
      "definition": "Se incorpora el importe anual de ajustes patrimoniales registrado en la fuente de balance y se conserva su signo.",
      "motivation": "Completa los movimientos del patrimonio que no se reflejan directamente en capital, reservas o resultados."
    }
  ],
  "16_inversiones": [
    {
      "label": "Saldo medio de inversiones disponibles para la venta",
      "definition": "Se utiliza el promedio de los saldos de inicio y cierre de la cartera de inversiones del componente de Tesorería. Se trata de una base de activos y no de un flujo de ingresos.",
      "motivation": "Representa el capital invertido durante el año sobre el cual se generan intereses."
    },
    {
      "label": "Rendimiento de inversiones de referencia",
      "definition": "Se aplica el rendimiento implícito establecido para 2026 a la base promedio de inversiones de los períodos posteriores.",
      "motivation": "Convierte el saldo invertido en una estimación de intereses sin confundirla con ganancias por valorización de instrumentos."
    }
  ],
  "17_bancos": [
    {
      "label": "Pasivo y patrimonio proyectados",
      "definition": "Se agregan las obligaciones y los fondos patrimoniales al cierre del ejercicio para determinar el total que debe estar respaldado por activos.",
      "motivation": "Proporciona el lado de financiación de la identidad contable del balance."
    },
    {
      "label": "Activos distintos de bancos y corresponsales",
      "definition": "Se restan las restantes cuentas de activo ya previstas, como cartera, inversiones, caja y otras disponibilidades, para obtener la diferencia residual.",
      "motivation": "Determina el saldo en bancos necesario para cuadrar el balance sin alterar de manera arbitraria las otras cuentas."
    }
  ],
  "17_canje": [
    {
      "label": "Saldo observado de canje",
      "definition": "Se utiliza el saldo mensual más reciente disponible en 2026 y se mantiene como referencia para los meses pendientes, de acuerdo con el método registrado.",
      "motivation": "Completa el disponible con una cuenta operativa de compensación sin proyectarle una ecuación no estimada."
    }
  ],
  "17_otros": [
    {
      "label": "Saldo observado de otros disponibles",
      "definition": "Se parte de la última observación mensual de 2026 y del valor previsto por la fuente para la continuación anual.",
      "motivation": "Incorpora posiciones líquidas distintas de caja, bancos y canje con su propio supuesto."
    }
  ],
  "18_otros_ing": [
    {
      "label": "Otros ingresos por servicios",
      "definition": "Se toma el importe anual de otros ingresos de servicios previsto en los resultados del modelo financiero.",
      "motivation": "Completa los ingresos por servicios y se agrega a los ingresos diversos sin sustituir ninguna de las dos series."
    }
  ],
  "18_gastos_div": [
    {
      "label": "Gastos diversos de 2026 respecto de ingresos diversos de 2026",
      "definition": "Se calcula la relación entre el gasto diverso y el ingreso diverso del cierre supuesto de 2026. Se conserva como porcentaje de referencia.",
      "motivation": "Establece la intensidad del gasto asociada a esa fuente de ingresos sin estimar otra regresión."
    },
    {
      "label": "Ingresos diversos proyectados",
      "definition": "Se multiplica la proporción anterior por los ingresos diversos anuales de los ejercicios posteriores.",
      "motivation": "Permite que el gasto acompañe la actividad que genera los ingresos utilizados como base."
    }
  ],
  "18_otros_gastos": [
    {
      "label": "Otros gastos por servicios",
      "definition": "Se utiliza la trayectoria anual original de otros gastos por servicios con el signo de gasto correspondiente.",
      "motivation": "Incluye costos distintos de los gastos diversos para obtener el resultado neto de servicios financieros."
    }
  ],
  "18_fsd": [
    {
      "label": "Primas del Fondo de Seguro de Depósitos",
      "definition": "Se incorpora el gasto anual presupuestado por cobertura de depósitos de acuerdo con la clasificación del modelo financiero.",
      "motivation": "Reconoce este costo de captación y evita tratar una prima de protección de depósitos como ingreso."
    }
  ],
  "19_directorio": [
    {
      "label": "Gasto de directorio presupuestado",
      "definition": "Se utiliza el importe del cierre supuesto de 2026 y se mantiene el nivel anual indicado por la fuente para los años siguientes.",
      "motivation": "Refleja una partida administrativa prevista sin asignarle falsamente una sensibilidad macroeconómica."
    }
  ],
  "19_impuestos": [
    {
      "label": "Importe inicial de impuestos y contribuciones",
      "definition": "Se utiliza el gasto administrativo supuesto de 2026, excluyendo el impuesto a la renta del Modelo 28.",
      "motivation": "Define una base clara del gasto operativo no asociado a remuneraciones o servicios contratados."
    },
    {
      "label": "Inflación anual proyectada",
      "definition": "El gasto del ejercicio siguiente se actualiza aplicando la variación de precios esperada a la base del año anterior.",
      "motivation": "Mantiene el poder adquisitivo del presupuesto de esta partida durante el horizonte de proyección."
    }
  ],
  "20_consorcios": [
    {
      "label": "Resultado de consorcios presupuestado",
      "definition": "Se toma el importe anual de la fuente original y se incorpora al resultado de operaciones financieras con su signo.",
      "motivation": "Reconoce ganancias o pérdidas de esta clase de participación sin confundirlas con intereses por préstamos."
    }
  ],
  "20_asociadas": [
    {
      "label": "Resultado de subsidiarias y asociadas",
      "definition": "Se incorpora el resultado anual de las participaciones en entidades vinculadas, según la fuente financiera.",
      "motivation": "Permite reconocer este componente de inversiones societarias por separado de los ingresos por intereses."
    }
  ],
  "20_tc": [
    {
      "label": "Diferencia de cambio y derivados de la base 2026",
      "definition": "Se suma la diferencia de cambio con el resultado de derivados del cierre previsto de 2026. Ese importe se relaciona con el volumen de compras del mercado del mismo año.",
      "motivation": "Fija una referencia conjunta de intensidad financiera antes de proyectar sus componentes separados."
    },
    {
      "label": "Compras de tarjetas del mercado",
      "definition": "La intensidad del año base se aplica a las compras anuales previstas del mercado, obtenidas del Modelo 03.",
      "motivation": "Actualiza la referencia de operaciones financieras siguiendo la escala prevista de la actividad utilizada en la metodología."
    },
    {
      "label": "Resultado de derivados proyectado",
      "definition": "Se resta el resultado de derivados presupuestado para el mismo ejercicio a fin de recuperar la diferencia de cambio por separado.",
      "motivation": "Evita sumar dos veces el resultado de derivados en la consolidación financiera."
    }
  ],
  "20_derivados": [
    {
      "label": "Resultado de derivados de negociación",
      "definition": "Se utiliza el importe anual presupuestado para estas operaciones, incluyendo la trayectoria proyectada de la fuente.",
      "motivation": "Separa las ganancias y pérdidas de derivados de los ingresos por intereses y de la diferencia de cambio."
    }
  ],
  "20_inversiones": [
    {
      "label": "Resultado financiero de inversiones",
      "definition": "Se conserva el flujo anual previsto por valorización o venta de inversiones, diferente de los intereses que estas generan.",
      "motivation": "Evita duplicar las rentas de inversiones al combinar ingresos por intereses y resultados financieros."
    }
  ],
  "20_otros": [
    {
      "label": "Otros resultados y venta de cartera",
      "definition": "Se incorporan los importes anuales presupuestados de otras operaciones financieras y ventas de cartera con sus signos.",
      "motivation": "Completa el resultado de operaciones financieras e identifica los efectos de transacciones distintas del negocio de intereses."
    }
  ],
  "21_venta": [
    {
      "label": "Presupuesto de inversiones de Tesorería",
      "definition": "Se utiliza el saldo anual de inversiones disponibles para la venta establecido por Tesorería para cada cierre.",
      "motivation": "Refleja decisiones de inversión del banco sin imponer una trayectoria derivada de la cartera de créditos."
    }
  ],
  "21_asociadas": [
    {
      "label": "Saldo de inversiones en subsidiarias",
      "definition": "Se toma el saldo de estas participaciones en los valores presupuestados para cada cierre anual.",
      "motivation": "Registra la tenencia de activos patrimoniales de otras entidades y no sus resultados del ejercicio."
    }
  ],
  "21_otras": [
    {
      "label": "Saldo de otras inversiones",
      "definition": "Se utiliza el importe anual de las inversiones no clasificadas en los componentes anteriores, según la fuente financiera.",
      "motivation": "Completa el activo de inversiones manteniendo su categoría contable."
    }
  ],
  "22_interbancarios": [
    {
      "label": "Saldo de fondos interbancarios del activo",
      "definition": "Se incorpora el cierre anual supuesto y la trayectoria prevista de recursos colocados en otras entidades.",
      "motivation": "Permite sumar esta posición de activo y distinguirla del costo del financiamiento interbancario recibido."
    }
  ],
  "45_dividendos": [
    {
      "label": "Dividendo presupuestado",
      "definition": "Se utiliza la distribución de dividendos prevista en el plan del banco para el ejercicio.",
      "motivation": "Recoge la decisión de remuneración al accionista que reduce los resultados acumulados."
    },
    {
      "label": "Resultados disponibles para distribuir",
      "definition": "La distribución se limita a las utilidades disponibles según la conciliación patrimonial del modelo.",
      "motivation": "Evita calcular un reparto de dividendos que supere el resultado aplicable."
    }
  ],
  "45_transferencias_reservas": [
    {
      "label": "Movimiento anual de reservas",
      "definition": "Se identifica la transferencia a reservas del ejercicio a partir del saldo presupuestado de la cuenta de reservas.",
      "motivation": "Permite separar del resultado acumulado la porción reclasificada dentro del patrimonio."
    }
  ],
  "45_utilidad_aplicada": [
    {
      "label": "Utilidad neta del ejercicio anterior",
      "definition": "Se toma el resultado neto del año anterior que corresponde aplicar en el ejercicio actual.",
      "motivation": "Relaciona el cierre del estado de resultados con los movimientos de resultados acumulados del patrimonio."
    }
  ],
  "47_pasivo": [
    {
      "label": "Componentes del pasivo",
      "definition": "Se suman los saldos de depósitos, deudas, cuentas por pagar, intereses y demás obligaciones de un mismo cierre.",
      "motivation": "Mide las obligaciones con terceros que forman el lado de financiación del balance."
    }
  ],
  "47_patrimonio": [
    {
      "label": "Componentes del patrimonio",
      "definition": "Se suman el capital, las reservas, los ajustes y los resultados de un mismo ejercicio.",
      "motivation": "Mide la financiación propia del banco que se añade a sus pasivos para cumplir la identidad contable."
    }
  ],
  "47_control": [
    {
      "label": "Activo total, pasivo total y patrimonio",
      "definition": "Se calcula la diferencia entre los activos y la suma de pasivos y patrimonio del mismo cierre.",
      "motivation": "Permite comprobar si la proyección cumple la igualdad contable o presenta una diferencia pendiente."
    }
  ],
  "47_disponible": [
    {
      "label": "Disponible previo al cuadre",
      "definition": "Se parte de los saldos de caja, bancos, canje y otros disponibles antes de ajustar el balance.",
      "motivation": "Identifica la liquidez que resulta directamente de las proyecciones de sus componentes."
    },
    {
      "label": "Ajuste de bancos y corresponsales",
      "definition": "Se agrega o descuenta la diferencia de conciliación calculada en el balance.",
      "motivation": "Permite que el disponible final refleje el ajuste residual de forma explícita."
    }
  ],
  "47_bancos": [
    {
      "label": "Pasivo y patrimonio",
      "definition": "Se suma la financiación de terceros y los recursos patrimoniales del mismo ejercicio.",
      "motivation": "Determina el volumen total de activos que corresponde respaldar."
    },
    {
      "label": "Activos excepto bancos y corresponsales",
      "definition": "Se restan todos los activos distintos del saldo de bancos y corresponsales.",
      "motivation": "Obtiene por diferencia el saldo de bancos que permite cuadrar el balance."
    }
  ],
  "47_creditos_netos": [
    {
      "label": "Colocaciones brutas",
      "definition": "Se utiliza el saldo total de créditos antes de provisiones del mismo cierre anual.",
      "motivation": "Representa el valor bruto de la financiación otorgada a clientes."
    },
    {
      "label": "Provisiones de cartera",
      "definition": "Se deducen las provisiones contables aplicables a los créditos para obtener su importe neto.",
      "motivation": "Refleja el ajuste por deterioro reconocido en el activo de créditos."
    }
  ],
  "47_interbancario_pasivo": [
    {
      "label": "Fondos interbancarios recibidos",
      "definition": "Se incorpora el saldo previsto de recursos obtenidos de otras entidades como fuente de financiación.",
      "motivation": "Evita mezclar pasivos por fondos recibidos con el activo de fondos colocados."
    }
  ],
  "47_disponible_previo": [
    {
      "label": "Caja, bancos, canje y otros disponibles",
      "definition": "Se suman los saldos proyectados de las partidas líquidas antes de realizar la conciliación patrimonial.",
      "motivation": "Permite distinguir el pronóstico original del ajuste contable aplicado después."
    }
  ],
  "47_ajuste_bancos": [
    {
      "label": "Bancos y corresponsales conciliados",
      "definition": "Se toma el saldo residual de bancos que permite igualar activos con pasivos más patrimonio.",
      "motivation": "Representa la posición de bancos después de la conciliación."
    },
    {
      "label": "Bancos y corresponsales previos",
      "definition": "Se resta el saldo de bancos calculado antes de la conciliación.",
      "motivation": "Mide exclusivamente la corrección requerida en esa cuenta, sin mezclarla con otros movimientos."
    }
  ],
  "47_principal_cert": [
    {
      "label": "Saldo contable de certificados",
      "definition": "Se parte de las obligaciones asociadas a los certificados según el saldo del pasivo de cierre.",
      "motivation": "Representa el importe total reconocido en la categoría correspondiente."
    },
    {
      "label": "Intereses devengados por pagar",
      "definition": "Se separan los intereses presupuestados que ya se presentan en una cuenta específica de gastos por pagar.",
      "motivation": "Evita duplicar intereses como parte del principal cuando se consolida el pasivo."
    }
  ],
  "49_compras": [
    {
      "label": "Tarjetas propias y compras del mercado",
      "definition": "Se combinan la cantidad de tarjetas proyectadas de Falabella y el volumen de compras del mercado obtenido en los modelos correspondientes.",
      "motivation": "Relaciona el tamaño del negocio propio con la utilización observada o prevista del mercado."
    },
    {
      "label": "Factor de calibración histórica",
      "definition": "Se utiliza la relación de referencia de 2025 que ajusta el cálculo de compras del mercado a las compras propias.",
      "motivation": "Evita asumir que las tarjetas del banco realizan exactamente las mismas compras por tarjeta que el mercado agregado."
    }
  ],
  "49_desembolsos": [
    {
      "label": "Intensidad histórica de desembolsos",
      "definition": "Se utiliza el patrón de desembolsos previsto en el modelo a partir de la referencia histórica de los préstamos no revolventes.",
      "motivation": "Permite estimar entradas nuevas a la cartera que no son compras con tarjetas."
    },
    {
      "label": "Saldo o actividad de préstamos no revolventes",
      "definition": "Se aplica la pauta de desembolsos a las magnitudes de la cartera correspondientes a cada ejercicio.",
      "motivation": "Vincula el flujo nuevo de crédito con el tamaño previsto de esta modalidad."
    }
  ],
  "49_disposiciones_rc": [
    {
      "label": "Flujo histórico de RappiCash",
      "definition": "Se parte del importe de disposiciones correspondiente al período base de la fuente.",
      "motivation": "Identifica nuevas utilizaciones revolventes que deben sumarse antes de obtener amortizaciones."
    },
    {
      "label": "Relación histórica de RappiCash con tarjetas",
      "definition": "Se utiliza la proporción media del producto respecto de la actividad de tarjetas de los años de referencia.",
      "motivation": "Actualiza las disposiciones en los años proyectados sin confundirlas con compras comerciales."
    }
  ],
  "49_tc": [
    {
      "label": "Amortización revolvente total",
      "definition": "Se utiliza el flujo de amortización revolvente calculado mediante la conciliación anual de saldos y entradas.",
      "motivation": "Proporciona el total que debe distribuirse entre tarjetas y RappiCash."
    },
    {
      "label": "Participación de RappiCash",
      "definition": "Se descuenta la fracción de amortizaciones correspondiente a RappiCash.",
      "motivation": "Asigna a tarjetas únicamente la parte de repagos que no pertenece al otro producto."
    }
  ],
  "49_rc": [
    {
      "label": "Amortización revolvente total",
      "definition": "Se utiliza el importe de amortizaciones revolventes obtenido a partir de saldos, compras, disposiciones y castigos.",
      "motivation": "Proporciona el flujo total de repagos que se distribuye por producto."
    },
    {
      "label": "Participación de RappiCash",
      "definition": "Se multiplica la amortización total por la proporción estimada para RappiCash.",
      "motivation": "Atribuye al producto su fracción del repago sin modificar el total conciliado."
    }
  ],
  "49_pe": [
    {
      "label": "Amortización no revolvente",
      "definition": "Se traslada el flujo de repagos calculado para préstamos no revolventes mediante la conciliación del año.",
      "motivation": "Mantiene la correspondencia entre la modalidad no revolvente y los préstamos efectivos, sin un segundo cálculo que pudiera duplicar amortizaciones."
    }
  ],
  "49_part_rc": [
    {
      "label": "Participación histórica en salidas revolventes",
      "definition": "Se utiliza la distribución histórica entre RappiCash y tarjetas calculada con los movimientos implícitos del período de referencia.",
      "motivation": "Establece cómo se reparte la amortización revolvente total entre ambos productos."
    },
    {
      "label": "Amortización revolvente proyectada",
      "definition": "La proporción histórica se aplica al flujo total de amortizaciones de cada año de proyección.",
      "motivation": "Permite asignar repagos por producto sin alterar el total de salidas ya conciliado."
    }
  ],
  "48": [
    {
      "label": "Constante",
      "definition": "Es el término independiente de la regresión del crecimiento logarítmico del saldo de consumo del conjunto de bancos. Se suma a la predicción cuando se calculan los demás aportes de la ecuación.",
      "motivation": "Permite ajustar el nivel medio del crecimiento de la cartera agregada sin imponer un paso obligado por cero."
    },
    {
      "label": "Producto bruto interno real del mismo año",
      "definition": "Es la tasa anual de crecimiento real de la actividad económica peruana del ejercicio que se proyecta. Entra en la ecuación en porcentaje, sin otro logaritmo.",
      "motivation": "Incorpora información sobre producción e ingresos agregados relacionada con la demanda de crédito de consumo en el sistema bancario."
    },
    {
      "label": "Variación previa de la tasa de desempleo",
      "definition": "Se obtiene como la tasa de desempleo del año anterior menos la tasa de dos años antes, en puntos porcentuales. Se usa la variación previa y no el nivel del desempleo corriente.",
      "motivation": "Distingue las condiciones laborales que anteceden a la evolución anual de la cartera del mercado."
    },
    {
      "label": "Tasa de política monetaria del año anterior",
      "definition": "Es la tasa de referencia del Banco Central de Reserva del Perú correspondiente al cierre de diciembre del ejercicio anterior. Entra como un porcentaje rezagado un año.",
      "motivation": "Incorpora las condiciones monetarias previas a la expansión del crédito de consumo del conjunto de bancos."
    }
  ],
  "05": [
    {
      "label": "Constante",
      "definition": "Es el término fijo que se suma a la predicción del crecimiento logarítmico anual de las colocaciones revolventes, expresado en puntos porcentuales. Su valor solo representa el resultado previsto cuando las otras regresoras toman valor cero.",
      "motivation": "Permite ajustar el nivel medio de crecimiento observado en la estimación, sin obligar a que la regresión pase por cero."
    },
    {
      "label": "Crecimiento logarítmico de compras del año anterior",
      "definition": "Se calcula como \\(100\\ln\\left(\\frac{C_{t-1}}{C_{t-2}}\\right)\\). La letra C representa el importe anual de compras con tarjetas de crédito de todo el mercado. Se comparan los dos años anteriores al que se desea pronosticar, y el dato procede del modelo de compras del mercado.",
      "motivation": "El uso reciente de tarjetas ofrece información sobre la intensidad del consumo financiado. No se interpreta como el saldo de Banco Falabella, porque las compras son un flujo del mercado y las colocaciones revolventes son deuda pendiente del banco."
    },
    {
      "label": "Producto bruto interno real del año anterior",
      "definition": "Es la variación porcentual real de la producción de la economía peruana en el año inmediatamente anterior al pronóstico. En la ecuación se introduce ese crecimiento rezagado, sin aplicar otro logaritmo.",
      "motivation": "La actividad económica previa aporta una referencia de ingresos y consumo que puede relacionarse con la utilización y el crecimiento posterior del crédito revolvente."
    },
    {
      "label": "Tasa de desempleo del año",
      "definition": "Es la tasa anual de desempleo correspondiente al mismo ejercicio para el cual se estima el crecimiento de la cartera. Se expresa en porcentaje y entra en la ecuación directamente, sin diferencia ni rezago.",
      "motivation": "Las condiciones laborales aportan información sobre los ingresos y la capacidad de sostener gastos o pagos de deuda, por lo que ayudan a explicar la evolución del saldo revolvente."
    }
  ]
}
};
})();
