"""Oficinas se publica de forma aislada; todas las cifras son fixtures temporales."""
from __future__ import annotations

from contextlib import ExitStack
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import actualizador_sbs as a
import motor
import oficinas_sbs as offices
from instituciones_sbs import BANKS, category_at

SYSTEM = Path(__file__).resolve().parents[1]
GEOMETRY = SYSTEM.parents[1] / 'IASPE/Scraper/Oficinas/output/departamentos.geojson'


def dataset(periods=('2026-08',), checked='2026-11-21T00:00:00+00:00'):
    geometry = json.loads(GEOMETRY.read_text(encoding='utf-8'))
    departments = sorted((f['properties']['code'], f['properties']['name']) for f in geometry['features'])
    data = {'schemaVersion':1, 'unit':'oficinas', 'checkedAt':checked, 'updatedAt':checked,
            'departments':[{'code':code,'name':name} for code,name in departments], 'series':{}}
    for position, identifier in enumerate(BANKS, 1):
        data['series'][identifier] = {}
        for month in periods:
            counts = {code:0 for code,_ in departments}
            counts['15'] = position
            counts['07'] = 2
            data['series'][identifier][month] = {'counts':counts, 'total':position+2, 'coverage':2,
                'sourceTotal':position+2, 'outsidePeru':0, 'category':category_at(identifier,month), 'sbsCode':None,
                'source':{'kind':'syntheticFixture','report':'synthetic','sha256':hashlib.sha256(b'synthetic fixture only').hexdigest()}}
    data['latestPeriod'] = max(periods)
    data['valueRevision'] = offices.value_revision(data)
    return data


def write_outputs(project, data):
    output = project/'Scraper/Oficinas/output'
    output.mkdir(parents=True,exist_ok=True)
    (output/'oficinas_historico.json').write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
    with (output/'oficinas_departamentos.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream)
        writer.writerow(['periodo','institucion_id','departamento_codigo','oficinas','total_peru'])
        for identifier,history in data['series'].items():
            for month,row in history.items():
                for code,value in row['counts'].items():writer.writerow([month,identifier,code,value,row['total']])
    (output/'consulta_oficinas.json').write_text(json.dumps({'checkedAt':data['checkedAt'],'status':'unchanged',
        'latestPeriod':data['latestPeriod'],'valueRevision':data['valueRevision']}),encoding='utf-8')
    ledger=project/'Scraper/Actualizacion/output/descarga_oficinas.json'
    ledger.parent.mkdir(parents=True,exist_ok=True)
    ledger.write_text(json.dumps({'status':'ok','source':'oficinas','fixtureOnly':True,'reports':{},'errors':[],
        'checkedAt':data['checkedAt'],'latestProcessed':data['latestPeriod'],'valueRevision':data['valueRevision']}),encoding='utf-8')


class OfficesCentralTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory(prefix='iaspe_offices_central_test_')
        self.root=Path(self.temporary.name)
        self.project=self.root/'IASPE'
        self.system=self.root/'Dashboard/Sistema'
        self.system.mkdir(parents=True)
        (self.system/'actualizador_sbs.py').write_text('# fixture aislada',encoding='utf-8')
        output=self.project/'Scraper/Oficinas/output'
        output.mkdir(parents=True)
        shutil.copy2(GEOMETRY,output/'departamentos.geojson')
        self.script=self.project/'Scraper/Actualizacion/script/ejecutar_sbs.py'
        self.script.parent.mkdir(parents=True)
        self.script.write_text('# no se ejecuta en las pruebas',encoding='utf-8')
        write_outputs(self.project,dataset())
        self.financial={
            self.project/'Modelos financieros/fixture.xlsx':b'financial workbook sentinel',
            self.project/'Scraper/Actualizacion/output/observaciones_modelos.json':b'{"financial":"unchanged"}',
            self.project/'Scraper/Actualizacion/output/vinculacion_modelos.json':b'{"fuentes":{}}',
            self.system/'data/fuentes_aplicadas.json':b'{"financial":"applied"}'}
        for path,body in self.financial.items():
            path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
        self.stack=ExitStack()
        for name,value in [('PROJECT',self.project),('OUTPUT',self.project/'Scraper/Actualizacion/output'),
                           ('LINK_OUTPUT',self.project/'Scraper/Actualizacion/output'),('SCRIPT',self.script),
                           ('__file__',str(self.system/'actualizador_sbs.py'))]:
            self.stack.enter_context(patch.object(a,name,value))
        self.manager=a.Actualizador()

    def tearDown(self):
        self.stack.close()
        self.temporary.cleanup()

    def assert_financial_unchanged(self):
        for path,body in self.financial.items():self.assertEqual(path.read_bytes(),body)

    def execute(self,data):
        def callback(task):
            self.assertEqual(task,'oficinas')
            stage=self.manager._active_project
            self.assertNotEqual(stage,self.project)
            write_outputs(stage,data)
            # Incluso un cambio accidental dentro de staging no debe publicar
            # archivos financieros que están fuera de los candidatos Oficinas.
            (stage/'Scraper/Actualizacion/output/observaciones_modelos.json').write_bytes(b'changed only in staging')
        return callback

    def test_paths_and_source_components_exclude_model_state(self):
        files=a.paths('oficinas',self.project)
        self.assertTrue(files)
        self.assertTrue(all('Scraper/Oficinas' in str(path.relative_to(self.project)).replace('\\','/') for path in files))
        self.assertFalse(any(path.name in ('observaciones_modelos.json','vinculacion_modelos.json') for path in files))
        self.assertNotIn('oficinas',a.SOURCE_COMPONENTS)
        self.assert_financial_unchanged()

    def test_valid_staged_update_publishes_offices_without_linking_or_model_observations(self):
        new=dataset(('2026-08','2026-09'))
        with patch.object(self.manager,'_execute',side_effect=self.execute(new)),patch.object(self.manager,'_subprocess') as subprocess:
            result=self.manager._run_task('oficinas')
        self.assertTrue(result['changed'])
        self.assertTrue(result['metadataChanged'])
        self.assertEqual(result['modelos'],[])
        self.assertEqual(result['observaciones_nuevas'],0)
        self.assertEqual(result['validation']['latestPeriod'],'2026-09')
        self.assertEqual(offices.validation(self.project)['entities'],17)
        subprocess.assert_not_called()
        self.assert_financial_unchanged()

    def test_invalid_sum_preserves_all_active_offices_and_financial_files(self):
        before={path:path.read_bytes() for path in a.paths('oficinas',self.project)}
        bad=dataset(('2026-08','2026-09'))
        bad['series']['05']['2026-09']['total']+=1
        bad['valueRevision']=offices.value_revision(bad)
        with patch.object(self.manager,'_execute',side_effect=self.execute(bad)),patch.object(self.manager,'_subprocess') as subprocess:
            with self.assertRaisesRegex(ValueError,'suma departamental'):
                self.manager._run_task('oficinas')
        for path,body in before.items():self.assertEqual(path.read_bytes(),body)
        subprocess.assert_not_called()
        self.assert_financial_unchanged()

    def test_new_period_cannot_remove_previous_observations(self):
        new=dataset(('2026-09',))
        with patch.object(self.manager,'_execute',side_effect=self.execute(new)),patch.object(self.manager,'_subprocess') as subprocess:
            with self.assertRaisesRegex(ValueError,'omite'):
                self.manager._run_task('oficinas')
        self.assertEqual(offices.validation(self.project)['latestPeriod'],'2026-08')
        subprocess.assert_not_called()
        self.assert_financial_unchanged()

    def test_only_checked_at_changes_is_metadata_without_data_or_model_changes(self):
        new=dataset(checked='2026-11-21T01:00:00+00:00')
        with patch.object(self.manager,'_execute',side_effect=self.execute(new)),patch.object(self.manager,'_subprocess') as subprocess:
            result=self.manager._run_task('oficinas')
        self.assertFalse(result['changed'])
        self.assertTrue(result['metadataChanged'])
        self.assertIn('Sin cambios',result['detalle'])
        self.assertEqual(result['observaciones_nuevas'],0)
        self.assertEqual(offices.validation(self.project)['checkedAt'],new['checkedAt'])
        subprocess.assert_not_called()
        self.assert_financial_unchanged()

    def test_begin_offices_only_never_freezes_or_writes_financial_state(self):
        try:
            with patch.object(motor,'freeze_sources') as freeze,patch.object(motor,'source_observations',return_value={}),\
                 patch.object(motor,'write_state') as write,patch.object(a.threading,'Thread') as worker:
                response=self.manager.begin(['oficinas'])
            self.assertTrue(response['running'])
            self.assertEqual(response['selected'],['oficinas'])
            worker.return_value.start.assert_called_once()
            freeze.assert_not_called();write.assert_not_called()
            self.assert_financial_unchanged()
        finally:
            self.manager.running=False
            if a.operation_status().get('running'):a._release_operation()

    def test_http_offices_start_returns_409_during_recalculation(self):
        import servidor
        server=servidor.Server(('127.0.0.1',0),servidor.Handler)
        worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
        try:
            url=f'http://127.0.0.1:{server.server_address[1]}/api/sbs/start'
            request=Request(url,data=b'{"sources":["oficinas"]}',headers={'Content-Type':'application/json'})
            with patch.object(a,'MANAGER',self.manager),a.operation('recalculation'),patch.object(motor,'freeze_sources') as freeze:
                with self.assertRaises(HTTPError) as caught:urlopen(request,timeout=5)
                self.assertEqual(caught.exception.code,409)
                self.assertEqual(json.loads(caught.exception.read())['operation']['kind'],'recalculation')
            freeze.assert_not_called()
            self.assert_financial_unchanged()
        finally:
            server.shutdown();server.server_close();worker.join(timeout=5)


if __name__=='__main__':unittest.main()
