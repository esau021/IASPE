from __future__ import annotations

from datetime import date, datetime
import hashlib
import json
import math
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[3]
ARCHIVO = ROOT / 'Data bruta' / 'BCRP' / 'series_tasa_tarjetas.json'
SALIDA = ROOT / 'Scraper' / 'Actualizacion' / 'output' / 'tasas_mercado.json'
SERIES = {'13': 'PN07845NM', '14': 'PN07847NM', '15': 'PN07814NM'}
CAMPOS = {'13': 'tasa_tarjetas_pct', '14': 'tasa_consumo_mas360_pct',
          '15': 'tasa_deposito_181_360_pct'}
MESES = {x: i + 1 for i, x in enumerate(
    ('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'))}
REQUESTS = []


def _mes(periodo):
    nombre, anio = periodo.split('.')
    return f'{int(anio):04d}-{MESES[nombre[:3]]:02d}'


def _consulta(codigo):
    fin = date.today()
    url = (f'https://estadisticas.bcrp.gob.pe/estadisticas/series/api/'
           f'{codigo}/json/2026-8/{fin.year}-{fin.month}/esp')
    with urlopen(Request(url, headers={'User-Agent': 'IASPE/1.0','Accept':'application/json'}), timeout=25) as respuesta:
        raw=respuesta.read(5_000_001)
        if len(raw)>5_000_000:raise ValueError('BCRP: respuesta excesiva')
        if not respuesta.geturl().startswith('https://estadisticas.bcrp.gob.pe/'):
            raise ValueError('BCRP: redirección fuera de la fuente oficial')
        datos = json.loads(raw.decode('utf-8'))
        REQUESTS.append({'report':codigo,'url':url,'finalUrl':respuesta.geturl(),
            'httpStatus':respuesta.status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'status':'downloaded'})
        original=SALIDA.parent.parent/'fuentes'/'BCRP'/f'{codigo}.json'
        original.parent.mkdir(parents=True,exist_ok=True)
        temporary=original.with_suffix('.tmp');temporary.write_bytes(raw);temporary.replace(original)
        REQUESTS[-1]['sourceFile']=str(original.relative_to(ROOT))
    if not isinstance(datos.get('periods'), list) or not datos['periods']:
        raise ValueError(f'BCRP: respuesta sin períodos para {codigo}.')
    return datos['periods']


def obtener(solo_cache=False):
    if solo_cache:
        if SALIDA.is_file():return json.loads(SALIDA.read_text(encoding='utf-8'))
        fuente = json.loads(ARCHIVO.read_text(encoding='utf-8'))
        meses = {str(r['fecha'])[:7]: r for r in fuente['observados']}
        return {modelo: {periodo: float(row[CAMPOS[modelo]])
                         for periodo, row in meses.items() if '2026-09' <= periodo <= '2030-12'
                         and isinstance(row.get(CAMPOS[modelo]), (int, float))}
                for modelo in SERIES}
    salida = {}
    for modelo, codigo in SERIES.items():
        puntos = {}
        for row in _consulta(codigo):
            periodo = _mes(row['name'])
            valor = row.get('values', [None])[0]
            if not '2026-09' <= periodo <= '2030-12' or valor in (None, 'n.d.', ''):
                continue
            numero = float(valor)
            if not math.isfinite(numero) or numero < 0 or numero > 200:
                raise ValueError(f'BCRP: tasa inválida en {codigo} / {periodo}.')
            puntos[periodo] = numero
        if not puntos:
            raise ValueError(f'BCRP: no existen observaciones nuevas para {codigo}.')
        salida[modelo] = puntos
    return salida


def ejecutar(solo_cache=False):
    tasas = obtener(solo_cache)
    if SALIDA.is_file():
        previous=json.loads(SALIDA.read_text(encoding='utf-8'))
        tasas={key:{**previous.get(key,{}),**value} for key,value in tasas.items()}
    SALIDA.parent.mkdir(parents=True, exist_ok=True)
    archivo = SALIDA.with_suffix('.tmp')
    archivo.write_text(json.dumps(tasas, ensure_ascii=False, indent=2), encoding='utf-8')
    archivo.replace(SALIDA)
    return tasas


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--solo-cache', action='store_true')
    args = parser.parse_args()
    datos = ejecutar(args.solo_cache)
    print('Tasas de mercado: ' + ', '.join(f'{k}: {len(v)} meses' for k, v in datos.items()))
