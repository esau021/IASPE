@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Sistema\iniciar.ps1"
if errorlevel 1 pause
