"""Regresión de transmisión: conservar reglas y fórmulas aprobadas v18."""
from pathlib import Path
import copy,gzip,json,sys,tempfile,unittest
from unittest.mock import patch
from openpyxl import Workbook,load_workbook

SYSTEM=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(SYSTEM))
sys.path.insert(0,str(SYSTEM.parents[1]/'IASPE/Scraper/Actualizacion/script'))
import cuentas_sbs as c
import motor_actualizacion as m
import motor
import motor_23_29 as pnl
import persistencia_modelos as persistence
from iaspe_excel_portable import SpreadsheetFile,Blob


class ClosingMethods(unittest.TestCase):
    def test_tangible_assets_update_depreciation_driver_and_preserve_capex_formulas(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_tangible_driver_') as temp:
            root=Path(temp);folder=root/'33_Fixture';file=folder/'Output/Pronostico.xlsx';file.parent.mkdir(parents=True)
            book=Workbook();annual=book.active;annual.title='Anual';annual.append(['Año','Saldo',None,None,'CAPEX','Depreciación'])
            annual.append([2026,100.,None,None,None,None])
            source=book.create_sheet('Depreciacion_M26');source.append(['Año',None,None,'M26'])
            calibration=book.create_sheet('Calibracion');calibration['B7']=.5
            for year in range(2027,2031):
                row=year-2024;driver=year-2025
                source.append([year,None,None,20.])
                annual.append([year,f'=B{row-1}+E{row}-F{row}',None,None,5.,f'=Depreciacion_M26!D{driver}*Calibracion!$B$7'])
            book.save(file);book.close()
            before={'33':{'sourceFiles':[str(file)]}}
            updated={'26':{'annual':[{'year':year,'value':40.} for year in range(2027,2031)]},
                '33':{'annual':[{'year':year,'value':100.-15*(year-2026)} for year in range(2027,2031)]}}
            books=persistence._Books(root)
            persistence._sincronizar_driver_m33(books,root,before,updated,{'26':{2027,2028,2029,2030}})
            self.assertEqual(books.sheet(file).get_range('E3:E6').values,[[5.]]*4)
            self.assertEqual(books.sheet(file).get_range('B2').values[0][0],100.)
            self.assertEqual(books.sheet(file).get_range('B3').formulas[0][0],'=B2+E3-F3')
            books.export()
            reloaded=SpreadsheetFile.import_xlsx(Blob.load(file))
            self.assertEqual(reloaded.worksheets.get_item('Anual').get_range('B3:B6').values,[[85.],[70.],[55.],[40.]])
            reloaded.close()

    def test_personnel_forecast_uses_same_expense_and_headcount_after_reload(self):
        data={year:[year,100.,2.+(year%3)*.2,2.,None,None,1000.+20*(year-2016)] for year in range(2016,2031)}
        fresh=copy.deepcopy(data);fresh[2026][6]=1500.
        model={'19_personal':{'annual':[{'year':year,'value':200. if year>=2026 else 100.+year-2016,
            'status':'observed' if year<2026 else 'assumed' if year==2026 else 'forecast'} for year in range(2016,2031)]}}
        first=copy.deepcopy(model);second=copy.deepcopy(model)
        observations={'trabajadores_falabella':{'2026':1500.}}
        with patch.object(m,'_input',return_value=Path('fixture')),patch.object(m,'_data',return_value=data):
            m._personal(first,Path('fixture'),{},observations)
        with patch.object(m,'_input',return_value=Path('fixture')),patch.object(m,'_data',return_value=fresh):
            m._personal(second,Path('fixture'),{},observations)
        self.assertEqual([row['value'] for row in first['19_personal']['annual']],
                         [row['value'] for row in second['19_personal']['annual']])
        self.assertEqual(first['19_personal']['annual'][10]['value'],200.)

    def test_financial_months_replace_assumptions_and_keep_blank_future_for_credits(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_flow_months_') as temp:
            root=Path(temp)/'IASPE/Modelos financieros';root.mkdir(parents=True)
            panel=root.parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz';panel.parent.mkdir(parents=True)
            series={f'2026-{month:02d}':float(month*10) for month in range(1,9)};series['2026-09']=100.
            with gzip.open(panel,'wt',encoding='utf-8') as stream:
                json.dump({'series':{'er_acumulado:112':{'05':series},'er_acumulado:105':{'05':series}}},stream)
            models={'12_obligaciones':{'monthly':[{'date':f'2026-{month:02d}','value':10.,'status':'observed' if month<=8 else 'assumed'} for month in range(1,13)]},
                '16_creditos':{'monthly':[{'date':f'2026-{month:02d}','value':10.,'status':'observed'} for month in range(1,9)]}}
            observations={'sbs_contable':{key:{'2026':{'sourceMonth':'2026-09'}} for key in models}}
            self.assertEqual(m._financial_source_months(models,observations,root),set(models))
            self.assertEqual(models['12_obligaciones']['monthly'][8]['value'],20.)
            self.assertEqual(models['12_obligaciones']['monthly'][8]['status'],'observed')
            self.assertEqual([(r['value'],r['status']) for r in models['12_obligaciones']['monthly'][9:]],[(20.,'assumed')]*3)
            self.assertEqual(len(models['16_creditos']['monthly']),9)
            self.assertEqual(m._financial_source_months(models,observations,root),set())

    def test_december_participations_remain_an_assumed_split_with_observed_aggregate(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_participations_') as temp:
            panel=Path(temp)/'panel.json.gz'
            with gzip.open(panel,'wt',encoding='utf-8') as stream:
                json.dump({'series':{'er_acumulado:107':{'05':{'2025-12':100.,'2026-12':120.}},
                    'er_acumulado:119':{'05':{'2025-12':0.,'2026-12':0.}}}},stream)
            models={'20_consorcios':{'annual':[{'year':2025,'value':95.}]},
                '20_asociadas':{'annual':[{'year':2023,'value':4.},{'year':2024,'value':6.},{'year':2025,'value':5.}]}}
            with patch.object(c,'PANEL',panel),patch.object(c,'ROOT',Path(temp)):
                results,missing=c.construir(models,{'20_consorcios'})
            row=results['20_consorcios']['2026']
            self.assertEqual(missing,[]);self.assertEqual(row['value'],115.)
            self.assertEqual(row['status'],'assumed');self.assertEqual(row['sourceValue'],120.)
            self.assertEqual(row['sourceStatus'],'observed');self.assertEqual(row['sourceMonth'],'2026-12')

    def test_reloaded_consolidated_source_reconciles_even_when_components_are_unchanged(self):
        base={key:{'annual':[{'year':2026,'value':value,'status':'assumed'}]} for key,value in
              [('09',1000.),('09_plazo',800.),('09_cts',200.)]}
        current=copy.deepcopy(base);current['09']['annual'][0]['value']=900.
        current['09']['status']='needs_input'
        observations={'sbs_contable':{'09':{'2026':{'value':900.,'status':'assumed'}}}}
        motor._reconciliar_consolidados_2026(current,base,observations)
        self.assertEqual(current['09']['annual'][0]['value'],1000.)
        self.assertEqual(current['09']['status'],'ok')
        observations['sbs_contable']['09']['2026']['status']='observed'
        with self.assertRaises(ValueError):motor._reconciliar_consolidados_2026(current,base,observations)

    def test_margin_replaces_a_stale_physical_driver_using_the_current_model(self):
        values={'16':100.,'12':9.,'18_fsd':2.,'20_tc':1.,'20_derivados':1.,'20_consorcios':-5.,
                '23':95.,'25':10.,'18':5.,'19':10.,'26':2.,'27':1.,'24':1.,'28':21.06,'29':56.94}
        before={key:{'annual':[{'year':year,'value':value,'status':'assumed' if year==2026 else 'forecast'}
                for year in range(2026,2031)]} for key,value in values.items()}
        after=copy.deepcopy(before)
        # The P&L still contained expense8, although M12 already contains9.
        margin_rows=[[year,100.,10.,110.,8.,2.,5.,15.,95.] for year in range(2026,2031)]
        pnl_rows=[['Cuenta',*range(2026,2031)],['RESULTADO ANTES DE IMPUESTOS',*[78.]*5],
            ['(+/−) Venta de cartera',*[0.]*5],['(−) Impuesto a la renta',*[21.06]*5],
            ['RESULTADO NETO DEL EJERCICIO',*[56.94]*5]]
        with patch.object(pnl,'_folder',return_value=Path('fixture')),patch.object(pnl,'_sheet',side_effect=lambda file,tab:margin_rows if tab=='Anual' else pnl_rows):
            pnl.recalculate({'source_root':Path('fixture'),'models':after,'original_models':before})
        self.assertEqual(after['23']['annual'][0]['value'],94.)
        self.assertAlmostEqual(after['28']['annual'][0]['value'],20.79)
        self.assertAlmostEqual(after['29']['annual'][0]['value'],56.21)
        reloaded=copy.deepcopy(after);provisional=copy.deepcopy(after)
        provisional['23']['annual'][0]['value']=999.;provisional['23']['status']='needs_input'
        fresh_margin=[[year,100.,10.,110.,9.,2.,5.,16.,94.] for year in range(2026,2031)]
        fresh_pnl=[['Cuenta',*range(2026,2031)],['RESULTADO ANTES DE IMPUESTOS',*[77.]*5],
            ['(+/−) Venta de cartera',*[0.]*5],['(−) Impuesto a la renta',*[20.79]*5],
            ['RESULTADO NETO DEL EJERCICIO',*[56.21]*5]]
        with patch.object(pnl,'_folder',return_value=Path('fixture')),patch.object(pnl,'_sheet',side_effect=lambda file,tab:fresh_margin if tab=='Anual' else fresh_pnl):
            pnl.recalculate({'source_root':Path('fixture'),'models':provisional,'original_models':reloaded})
        self.assertEqual(provisional['23']['annual'][0]['value'],94.)
        self.assertEqual(provisional['23']['status'],'ok')

    def test_last_flow_closing_uses_same_account_latest_increment(self):
        panel={'series':{'er_acumulado:105':{'05':{'2026-07':650.,'2026-08':750.,'2026-09':840.}}}}
        self.assertEqual(c._cierre_ultimo_flujo(panel,{'er_acumulado:105':1},2026,9),1110.)
        self.assertIsNone(c._cierre_ultimo_flujo(panel,{'er_acumulado:105':1},2026,6))

    def test_median_closing_uses_all_three_comparable_seasons(self):
        panel={'series':{'er_acumulado:140':{'05':{
            '2023-09':60.,'2023-12':100.,'2024-09':80.,'2024-12':100.,
            '2025-09':90.,'2025-12':100.}}}}
        self.assertEqual(c._factor_mediano(panel,{'er_acumulado:140':1},9,(2023,2024,2025),annual_over_month=False),.8)
        self.assertEqual(c._factor_mediano(panel,{'er_acumulado:140':1},9,(2023,2024,2025)),1.25)

    def test_fixed_projection_window_does_not_absorb_2026_assumption(self):
        models={'x':{'annual':[{'year':2023,'value':4.},{'year':2024,'value':8.},
            {'year':2025,'value':6.},{'year':2026,'value':1000.,'status':'assumed'}]}}
        self.assertEqual(m._fixed_median(models,'x',range(2023,2026)),6.)
        self.assertEqual(m._fixed_median(models,'x',range(2024,2027)),8.)

    def test_portable_recalculates_original_count_index_formula_after_new_month(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_formula_closing_') as temp:
            file=Path(temp)/'Base_modelo.xlsx';book=Workbook();sheet=book.active;sheet.title='Mensual'
            for index in range(1,9):sheet.cell(index,2,10.)
            annual=book.create_sheet('Anual')
            formula='=SUM(Mensual!B1:B12)+(12-COUNT(Mensual!B1:B12))*INDEX(Mensual!B1:B12,COUNT(Mensual!B1:B12))'
            annual['B1']=formula;annual['B2']='=COUNT(Mensual!B10,Mensual!B11)';book.save(file);book.close()
            portable=SpreadsheetFile.import_xlsx(Blob.load(file))
            portable.worksheets.get_item('Mensual').get_range('B9').values=[[20.]]
            self.assertEqual(portable.worksheets.get_item('Anual').get_range('B1').values[0][0],160.)
            # A zero is an observation. An empty future month remains absent.
            portable.worksheets.get_item('Mensual').get_range('B10').values=[[0.]]
            self.assertEqual(portable.worksheets.get_item('Anual').get_range('B1').values[0][0],100.)
            self.assertEqual(portable.worksheets.get_item('Anual').get_range('B2').values[0][0],1)
            result=Path(temp)/'saved.xlsx';SpreadsheetFile.export_xlsx(portable).save(result)
            check=load_workbook(result,read_only=True,data_only=False)
            self.assertEqual(check['Anual']['B1'].value,formula);check.close()
            check=load_workbook(result,read_only=True,data_only=True)
            self.assertEqual(check['Anual']['B1'].value,100.);check.close();portable.close()

    def test_tax_closing_updates_uai_and_preserves_approved_rate_formula(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_tax_closing_') as temp:
            folder=Path(temp)
            for kind,name in [('Input','Base_modelo.xlsx'),('Output','Pronostico.xlsx'),('','Consolidado.xlsx')]:
                file=folder/kind/name;file.parent.mkdir(exist_ok=True)
                book=Workbook();sheet=book.active;sheet.title='Anual'
                sheet.append(['Año','Valor','Tasa','UAI'])
                sheet.append([2026,'=C2*D2' if kind=='Input' else 27.,.27,100.])
                book.save(file);book.close()
            before={'28':{'annual':[{'year':2026,'value':27.,'status':'assumed'}]}}
            after={'28':{'annual':[{'year':2026,'value':54.,'status':'assumed'}]}}
            books=persistence._Books(folder)
            persistence._tax(books,folder,before,after,{'28':{2026}})
            file=folder/'Input/Base_modelo.xlsx'
            self.assertEqual(books.sheet(file).get_range('B2').formulas[0][0],'=C2*D2')
            self.assertEqual(books.sheet(file).get_range('C2').values[0][0],.27)
            self.assertEqual(books.sheet(file).get_range('D2').values[0][0],200.)
            self.assertEqual(books.sheet(file).get_range('B2').values[0][0],54.)

    def test_receivables_replaces_comparable_months_and_keeps_annual_closing_blank(self):
        with tempfile.TemporaryDirectory(prefix='iaspe_receivables_') as temp:
            root=Path(temp)/'IASPE/Modelos financieros';root.mkdir(parents=True)
            file=root/'Base_modelo.xlsx';book=Workbook();sheet=book.active;sheet.title='Anual'
            sheet.append(['Año','Saldo',None,None,None,None,'Saldo agosto'])
            for year in range(2021,2027):sheet.append([year,None,None,None,None,None,999.])
            book.save(file);book.close()
            series={f'{year}-09':10. for year in range(2021,2027)}
            series.update({f'{year}-12':12. for year in range(2021,2026)})
            panel=root.parent/'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz';panel.parent.mkdir(parents=True)
            with gzip.open(panel,'wt',encoding='utf-8') as stream:json.dump({'series':{'balance:032':{'05':series}}},stream)
            books=persistence._Books(root)
            persistence._receivables_source_input(books,file,root,{'annual':[{'year':2026,'value':12.,'sourceMonth':'2026-09'}]})
            self.assertEqual(books.sheet(file).get_range('G2:G7').values,[[10.]]*6)
            self.assertIsNone(books.sheet(file).get_range('B7').values[0][0])
            self.assertIn('09',books.sheet(file).get_range('G1').values[0][0])


if __name__=='__main__':unittest.main()
