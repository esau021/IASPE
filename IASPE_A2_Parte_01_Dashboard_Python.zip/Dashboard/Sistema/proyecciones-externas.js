/* Panel de comparación externa: edición más reciente por fuente, sin alterar modelos IASPE. */
(function(){
'use strict';
let state=null, busy=false, busySource='', sourceErrors={}, tab='pronosticos', selected='pbi', lastError='', updateResult=null, importResult=null, previewData=null, savedNotice='', importSource='BCRP · encuesta anual', importFormat='pdf';
const $=s=>document.querySelector(s);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Solo variables que estas publicaciones efectivamente proyectan por año calendario.
// El FMI publica pronósticos anuales para desempleo y población de Perú;
// no confundirlos con las series históricas SBS/BCRP de los modelos.
const VARIABLES={pbi:'PBI real',inflacion:'Inflación anual',tc_cierre:'Tipo de cambio al cierre',tc_promedio:'Tipo de cambio promedio',desempleo:'Tasa de desempleo',poblacion:'Población total'};
const SOURCE_LABELS={'BCRP · Reporte de Inflación':'BCRP · Reporte de Inflación','BCRP · encuesta anual':'BCRP · Encuesta mensual','MEF · MMM/IAPM':'MEF · Marco Macroeconómico','FMI · WEO':'FMI · World Economic Outlook'};
const SOURCE_URLS={'BCRP · Reporte de Inflación':'https://www.bcrp.gob.pe/publicaciones/reporte-de-inflacion.html','BCRP · encuesta anual':'https://www.bcrp.gob.pe/estadisticas/encuesta-de-expectativas-macroeconomicas.html','MEF · MMM/IAPM':'https://www.mef.gob.pe/es/marco-macroeconomico/marco-macroeconomico-multianualmmm','FMI · WEO':'https://data.imf.org/datasets/WEO'};
const ROWS=[
 {source:'BCRP · Reporte de Inflación',group:'',short:'Proyección oficial'},
 {source:'BCRP · encuesta anual',group:'Analistas económicos',short:'Analistas económicos'},
 {source:'BCRP · encuesta anual',group:'Sistema financiero',short:'Sistema financiero'},
 {source:'BCRP · encuesta anual',group:'Empresas no financieras',short:'Empresas no financieras'},
 {source:'MEF · MMM/IAPM',group:'',short:'MMM / IAPM'}
];
const WEO_ROW={source:'FMI · WEO',group:'',short:'Proyección oficial'};
const YEARS=['2026','2027','2028','2029','2030'];
const ROWS_BY_VARIABLE={
 pbi:[...ROWS,WEO_ROW], inflacion:[...ROWS,WEO_ROW],
 tc_cierre:ROWS.filter(r=>r.source!=='BCRP · Reporte de Inflación'),
 tc_promedio:ROWS.filter(r=>r.source==='MEF · MMM/IAPM'),
 desempleo:[WEO_ROW], poblacion:[WEO_ROW]
};
const fmt=(value,unit)=>value==null?'—':new Intl.NumberFormat('es-PE',{minimumFractionDigits:unit==='S/ por USD'?3:2,maximumFractionDigits:unit==='S/ por USD'?3:2}).format(value)+(unit==='%'?' %':'');
const fmtDate=v=>{if(!v)return 'Sin consultar';const d=new Date(v);return Number.isFinite(d.getTime())?d.toLocaleString('es-PE',{dateStyle:'short',timeStyle:'short',timeZone:'America/Lima'}):String(v)};
const safeUrl=v=>{try{const u=new URL(String(v||''));return u.protocol==='https:'&&['www.bcrp.gob.pe','bcrp.gob.pe','estadisticas.bcrp.gob.pe','www.mef.gob.pe','mef.gob.pe','cdn.www.gob.pe','www.gob.pe','data.imf.org'].includes(u.hostname)&&!u.username&&!u.password?esc(u.href):'';}catch(_){return '';}};
const dateKey=r=>String((r?.source==='BCRP · Reporte de Inflación'&&r?.revision)||r?.published||r?.edition||'');
const documentKey=r=>String(r?.document_hash||r?.document_id||'');
function newest(rows){return rows.slice().sort((a,b)=>dateKey(b).localeCompare(dateKey(a)) || String(b.downloaded_at||b.downloaded||'').localeCompare(String(a.downloaded_at||a.downloaded||'')) || ((b.origin==='official')-(a.origin==='official')))[0]||null;}
function recordsBySeries(){
 const idx=new Map(),available=Array.isArray(state?.current_records)?state.current_records:(state?.records||[]);
 // EEM y MEF conservan su cohorte. RI recibe del servidor la revisión
 // más reciente disponible para cada año, con su propio respaldo documental.
 const cohorts=new Map();
 for(const r of available){if(r.kind!=='anual'||!VARIABLES[r.variable])continue;
  const key=[r.source,r.variable].join('|'),old=cohorts.get(key);
  if(!old||newest([old,r])===r)cohorts.set(key,r);
 }
 for(const r of available){if(r.kind!=='anual'||!VARIABLES[r.variable]||!YEARS.includes(String(r.year)))continue;
  const anchor=cohorts.get([r.source,r.variable].join('|'));
  if(r.source!=='BCRP · Reporte de Inflación'&&(!anchor||r.edition!==anchor.edition||documentKey(r)!==documentKey(anchor)))continue;
  const key=[r.variable,r.source,r.group||'',String(r.year)].join('|');
  idx.set(key,r);
 }
 return idx;
}
function record(idx,varKey,row,year){return idx.get([varKey,row.source,row.group,year].join('|'))||null;}
function seriesEdition(idx,varKey,row){return newest(YEARS.map(y=>record(idx,varKey,row,y)).filter(Boolean));}
function lastSourceCheck(scope){
 const saved=state?.lastChecks?.[scope];
 if(saved)return saved;
 return (state?.checks||[]).slice().reverse().find(x=>x.scope===scope)||null;
}
function checkMessage(check,source){
 if(!check)return '';
 if(check.status==='error'||(check.errors||[]).length)return `La consulta del ${source} no se completó; se conservan los últimos datos válidos.`;
 const ed=Number(check.new_editions||0),rev=Number(check.revisions||0);
 if(ed||rev)return `${source}: ${ed} edición(es) nueva(s) y ${rev} revisión(es) incorporada(s).`;
 if(check.status==='updated')return `${source}: se incorporaron nuevos datos.`;
 return `${source} consultado: no hay nuevas ediciones ni revisiones.`;
}
function updateStatusLines(){
 const rows=[];
 for(const [scope,source] of [['imf','FMI'],['mef','MEF']]){
  const check=lastSourceCheck(scope),error=sourceErrors[scope];
  if(!check&&!error&&busySource!==scope)continue;
  const waiting=busySource===scope;
  const message=waiting?`Consultando ${source}…`:error?`La consulta del ${source} no se completó: ${error}`:checkMessage(check,source);
  const warning=!!error||(!waiting&&(check?.status==='error'||(check?.errors||[]).length));
  const time=check?.date?`Última consulta: ${fmtDate(check.date)}`:'Sin consulta registrada';
  rows.push(`<div class="mex-source-status ${warning?'warn':'ok'}" role="status"><span class="mex-source-message">${esc(message)}</span><span class="mex-source-date">${esc(time)}</span></div>`);
 }
 return rows.length?`<div class="mex-source-statuses">${rows.join('')}</div>`:'';
}
function header(){
 const otherBusy=busy&&busySource!=='';
 return `<div class="mex-page"><header class="mex-head"><h1>Proyecciones macroeconómicas</h1><p>Pronósticos publicados por el BCRP, MEF y FMI, diferenciados por fuente y tipo de encuestado.</p></header>
 ${tab==='pronosticos'?`<div class="mex-actions"><button type="button" class="mex-button" id="mex-update" ${busy?'disabled':''} ${busySource==='imf'?'title="Espera a que termine la consulta del FMI"':''}>${busySource==='mef'?'Consultando…':'Actualizar MEF'}</button><button type="button" class="mex-button" id="mex-update-imf" ${busy?'disabled':''} ${busySource==='mef'?'title="Espera a que termine la consulta del MEF"':''}>${busySource==='imf'?'Consultando…':'Actualizar FMI'}</button></div>${updateStatusLines()}`:''}
 ${tab==='pronosticos'&&lastError?`<p class="mex-feedback warn">${esc(lastError)}</p>`:''}
 ${tab==='pronosticos'&&savedNotice?`<div class="mex-feedback ok" role="status">${esc(savedNotice)}</div>`:''}
 <nav class="mex-tabs"><button type="button" class="${tab==='pronosticos'?'active':''}" data-mex-tab="pronosticos">Pronósticos</button><button type="button" class="${tab==='fuentes'?'active':''}" data-mex-tab="fuentes">Carga de documentos</button></nav>${officialSourceLinks()}`;
}
function variableControl(){return `<div class="mex-controls"><label for="mex-variable">Variable <select id="mex-variable"><option value="all" ${selected==='all'?'selected':''}>Todas las variables</option>${Object.entries(VARIABLES).map(([key,value])=>`<option value="${key}" ${selected===key?'selected':''}>${esc(value)}</option>`).join('')}</select></label><span>Proyecciones por año calendario · 2026–2030</span></div>`;}
function sourceName(row){return SOURCE_LABELS[row.source]||row.source;}
function referenceLabel(row,edition){
 if(!edition)return '—';
 const code=String(edition.edition||'');
 if(row.source==='FMI · WEO'&&/^20\d{2}-(?:04|10)$/.test(code)){const [yy,mm]=code.split('-').map(Number);return new Date(Date.UTC(yy,mm-1,1)).toLocaleDateString('es-PE',{month:'long',year:'numeric',timeZone:'UTC'});}
 if(row.source==='BCRP · encuesta anual'&&/^20\d{2}-(?:0[1-9]|1[0-2])$/.test(code)){
  const [year,month]=code.split('-').map(Number);
  return new Date(Date.UTC(year,month-1,1)).toLocaleDateString('es-PE',{month:'long',year:'numeric',timeZone:'UTC'});
 }
 return code;
}
// Calendario recurrente: no depende de la fecha de apertura ni repite las ediciones de la tabla.
let calendarOpen=false;
function publicationCalendar(keys){
 const active=new Set(keys.flatMap(key=>(ROWS_BY_VARIABLE[key]||ROWS).map(row=>row.source)));
 const cards=[];
 if(active.has('BCRP · encuesta anual'))cards.push(`<section class="mex-calendar-item">
  <div class="mex-calendar-source">BCRP <span>Encuesta de expectativas</span></div>
  <dl><div><dt>Frecuencia</dt><dd>Mensual</dd></div>
  <div><dt>Publicación habitual</dt><dd>Del 3 al 10 de cada mes, con los resultados de la encuesta del mes anterior.</dd></div></dl>
 </section>`);
 if(active.has('BCRP · Reporte de Inflación'))cards.push(`<section class="mex-calendar-item">
  <div class="mex-calendar-source">BCRP <span>Reporte de Inflación</span></div>
  <dl><div><dt>Frecuencia</dt><dd>Trimestral</dd></div>
  <div><dt>Presentación habitual</dt><dd>Entre el 15 y el 22 de marzo, junio, septiembre y diciembre.</dd></div></dl>
 </section>`);
 if(active.has('FMI · WEO'))cards.push(`<section class="mex-calendar-item"><div class="mex-calendar-source">FMI <span>World Economic Outlook</span></div><dl><div><dt>Frecuencia</dt><dd>Dos ediciones completas al año</dd></div><div><dt>Publicación habitual</dt><dd>Abril y octubre</dd></div></dl></section>`);
 if(active.has('MEF · MMM/IAPM'))cards.push(`<section class="mex-calendar-item">
  <div class="mex-calendar-source">MEF <span>Marco Macroeconómico Multianual</span></div>
  <dl><div><dt>Actualización IAPM</dt><dd>Última semana de abril (aprox. del 25 al 30).</dd></div>
  <div><dt>Nuevo MMM</dt><dd>Segunda quincena de agosto (aprox. del 20 al 31).</dd></div></dl>
 </section>`);
 return `<details id="mex-publication-calendar" class="mex-calendar" ${calendarOpen?'open':''}>
  <summary><span class="mex-calendar-header"><strong>Calendario de publicaciones</strong><small>Fechas habituales por institución</small></span><span class="mex-calendar-arrow" aria-hidden="true"></span></summary>
  <div class="mex-calendar-grid">${cards.join('')}</div>
 </details>`;
}
// Estadísticas descriptivas de las fuentes mostradas en la tabla.
// Cada año usa únicamente los pronósticos publicados para ese mismo año;
// no se calcula una media de una sola fuente.
function summaryStats(records){
 const values=records.filter(r=>r&&Number.isFinite(r.value));
 if(values.length<2 || values.some(r=>r.unit!==values[0].unit))return null;
 const sorted=values.map(r=>Number(r.value)).sort((a,b)=>a-b);
 const n=sorted.length, middle=Math.floor(n/2);
 return {mean:sorted.reduce((sum,v)=>sum+v,0)/n,
         median:n%2?sorted[middle]:(sorted[middle-1]+sorted[middle])/2,
         unit:values[0].unit};
}
function tableForVariable(key,idx){
 const rows=(ROWS_BY_VARIABLE[key]||ROWS).map(row=>({row,edition:seriesEdition(idx,key,row)}));
 const displayed=rows.map(({row,edition})=>({row,edition,byYear:YEARS.map(y=>{
  const found=record(idx,key,row,y);
  return found&&(row.source==='BCRP · Reporte de Inflación'||
    (found.edition===edition?.edition&&documentKey(found)===documentKey(edition)))?found:null;
 })}));
 const hasAnyData=displayed.some(item=>item.byYear.some(Boolean));
 const rowHtml=displayed.map(({row,edition,byYear})=>`<tr><td class="mex-source">${esc(sourceName(row))}</td><td>${esc(row.short)}</td><td class="mex-edition">${esc(referenceLabel(row,edition))}</td>${byYear.map((r,i)=>`<td class="numeric ${r?'mex-value':'mex-blank'}" title="${r?esc(`Edición: ${r.edition} · Año: ${YEARS[i]} · ${r.unit}`):'No publicado para el año indicado'}">${r?fmt(r.value,r.unit):'—'}</td>`).join('')}</tr>`).join('');
 const summaries=YEARS.map((_,i)=>summaryStats(displayed.map(row=>row.byYear[i])));
 const hasSummary=summaries.some(Boolean);
 const summaryCells=metric=>summaries.map(item=>`<td class="numeric ${item?'mex-value':'mex-blank'}">${item?fmt(item[metric],item.unit):'—'}</td>`).join('');
 const summaryHtml=hasSummary?`<tr class="mex-derived-row mex-derived-first"><td colspan="3" class="mex-derived-label">Media</td>${summaryCells('mean')}</tr>
 <tr class="mex-derived-row mex-derived-last"><td colspan="3" class="mex-derived-label">Mediana</td>${summaryCells('median')}</tr>`:'';
 return `<section class="mex-series"><div class="mex-subtitle"><h2>${esc(VARIABLES[key])}</h2><span>${key==='poblacion'?'Millones de personas':key.startsWith('tc_')?'S/ por USD':'Porcentaje anual'}</span></div>${!hasAnyData?`<div class="mex-empty-note">No hay pronósticos anuales disponibles para esta variable en las publicaciones cargadas.</div>`:''}
 <div class="mex-table-wrap"><table class="mex-table"><thead><tr><th>Fuente</th><th>Encuestado / tipo</th><th>Referencia del dato</th>${YEARS.map(y=>`<th class="numeric">${y}</th>`).join('')}</tr></thead><tbody>${rowHtml}${summaryHtml}</tbody></table></div></section>`;
}
function officialSourceLinks(){return `<div class="mex-official-links"><span>Fuentes oficiales</span><a href="${SOURCE_URLS['BCRP · encuesta anual']}" target="_blank" rel="noopener noreferrer">Encuesta BCRP ↗</a><a href="${SOURCE_URLS['BCRP · Reporte de Inflación']}" target="_blank" rel="noopener noreferrer">Reporte de Inflación ↗</a><a href="${SOURCE_URLS['MEF · MMM/IAPM']}" target="_blank" rel="noopener noreferrer">MEF · MMM ↗</a><a href="${SOURCE_URLS['FMI · WEO']}" target="_blank" rel="noopener noreferrer">FMI · WEO ↗</a></div>`;}
function forecasts(){
 const idx=recordsBySeries(),keys=selected==='all'?Object.keys(VARIABLES):[selected];
 const riYears=YEARS.filter(y=>keys.some(k=>['pbi','inflacion'].includes(k)&&!!record(idx,k,ROWS[0],y)));
 const note=riYears.length?`<p class="mex-definition-note"><strong>Reporte de Inflación:</strong> la referencia indica el mes de publicación del reporte; las columnas corresponden a los años proyectados (${riYears.join(', ')} en la edición cargada). El PBI es crecimiento real anual y la inflación corresponde a la variación de precios a diciembre. Los años sin cifra no forman parte de ese horizonte.</p>`:'';
 return `${variableControl()}${keys.map(k=>tableForVariable(k,idx)).join('')}${note}${publicationCalendar(keys)}`;
}
// Resultados de carga manual exclusivamente. Los errores del conector automático
// permanecen fuera de este formulario y no se presentan como errores del archivo del usuario.
function importFeedback(){
 if(!importResult)return '';
 const heading=importResult.ok?'Cambios confirmados':'No se incorporó el documento';
 return `<div class="mex-upload-feedback ${importResult.ok?'ok':'warn'}" role="${importResult.ok?'status':'alert'}"><strong>${heading}.</strong> ${importResult.filename?`<strong>${esc(importResult.filename)}</strong> · `:''}${importResult.stage&&!importResult.ok?`Etapa: ${esc(importResult.stage)}. `:''}${esc(importResult.message)}</div>`;
}
function showImportResult(ok,stage,message,filename=''){
 importResult={ok,stage,message,filename:String(filename||'').slice(0,120)};
 const el=$('#mex-import-feedback');if(el)el.innerHTML=importFeedback();
}
function clearImportFeedback(){importResult=null;previewData=null;const el=$('#mex-import-feedback');if(el)el.innerHTML='';const block=$('#mex-import-preview');if(block)block.innerHTML='';}
const VAR_PREVIEW_ORDER=['pbi','inflacion','tc_cierre','tc_promedio'];
const PREVIEW_STATUS={nuevo:'Nuevo',cambio:'Cambia',igual:'Sin variación',anterior:'Edición anterior'};
function previewTables(p){
 const records=p.records||[],variables=VAR_PREVIEW_ORDER.filter(v=>records.some(r=>r.variable===v));
 return variables.map(variable=>{
  const items=records.filter(r=>r.variable===variable);
  const years=[...new Set(items.map(r=>String(r.year)))].sort();
  const groups=[...new Set(items.map(r=>r.group||'Proyección oficial'))];
  const unit=items[0]?.unit||'%';
  return `<section class="mex-preview-series"><h3>${esc(VARIABLES[variable]||variable)} <small>${esc(unit)}</small></h3>
   <div class="mex-table-wrap"><table class="mex-table mex-preview-table"><thead><tr><th>Encuestado / tipo</th>${years.map(y=>`<th class="numeric">${esc(y)}</th>`).join('')}</tr></thead>
   <tbody>${groups.map(group=>`<tr><td class="mex-source">${esc(group)}</td>${years.map(y=>{
     const r=items.find(x=>String(x.year)===y&&(x.group||'Proyección oficial')===group);
     if(!r)return '<td class="numeric mex-blank">—</td>';
     const before=r.before==null?'—':fmt(r.before,unit),after=fmt(r.after,unit);
     const difference=r.status==='cambio' && r.before!=null;
     return `<td class="numeric mex-preview-cell ${r.status==='anterior'?'mex-preview-old':''}">
       ${difference?`<span class="mex-preview-before">${before} →</span>`:''}<strong>${after}</strong>
       ${r.status==='nuevo'?'<span class="mex-preview-tag">Nuevo</span>':''}
       ${r.status==='anterior'?'<span class="mex-preview-tag">Anterior</span>':''}</td>`;
    }).join('')}</tr>`).join('')}</tbody></table></div></section>`;
 }).join('');
}
function previewPanel(){
 if(!previewData)return '';
 const p=previewData,doc=p.document||{};
 return `<section class="mex-preview" aria-label="Previsualización de cambios">
  <div class="mex-preview-head"><div><h2>Previsualización · ${esc(doc.edition||'Publicación identificada')}</h2>
  <p>${esc(doc.source||'')} · ${esc(doc.title||'Documento')} · ${Number(p.records?.length||0)} pronósticos · ${Number(p.changes||0)} registros por actualizar</p></div></div>
  ${previewTables(p)}
  <div class="mex-preview-actions"><span>Revisa las cifras antes de incorporarlas. Los valores anteriores se conservan en el historial.</span>
   <button type="button" id="mex-preview-cancel" class="mex-button secondary" ${busy?'disabled':''}>Cancelar</button>
   <button type="button" id="mex-preview-confirm" class="mex-button" ${busy?'disabled':''}>${busy?'Guardando…':'Confirmar cambios'}</button></div>
 </section>`;
}
function sources(){return `<section class="mex-import-panel"><div class="mex-import-heading"><h2>Carga de publicaciones oficiales</h2></div>
 <div class="mex-import-line mex-simple-upload">
 <label>Publicación<select id="mex-import-source"><option value="BCRP · encuesta anual" ${importSource==='BCRP · encuesta anual'?'selected':''}>Encuesta BCRP</option><option value="BCRP · Reporte de Inflación" ${importSource==='BCRP · Reporte de Inflación'?'selected':''}>Reporte de Inflación</option><option value="MEF · MMM/IAPM" ${importSource==='MEF · MMM/IAPM'?'selected':''}>MEF · MMM / IAPM</option></select></label>
 <label>Formato<select id="mex-import-format"><option value="pdf" ${importFormat==='pdf'?'selected':''}>PDF (.pdf)</option><option value="xlsx" ${importFormat==='xlsx'?'selected':''}>Excel (.xlsx)</option></select></label>
 <label>Archivo<input type="file" id="mex-import-file" accept=".pdf"></label>
 <button class="mex-button secondary" type="button" id="mex-import" ${busy?'disabled':''}>${busy?'Analizando…':'Previsualizar'}</button>
 </div><div id="mex-import-feedback">${importFeedback()}</div><div id="mex-import-preview">${previewPanel()}</div></section>`;}
function syncImportUI(){
 const source=$('#mex-import-source'),format=$('#mex-import-format'),file=$('#mex-import-file');if(!source||!format)return;
 const allowed=source.value==='BCRP · Reporte de Inflación'?['pdf']:source.value==='MEF · MMM/IAPM'?['xlsx']:['pdf','xlsx'];
 if(!allowed.includes(format.value))format.value=allowed[0];
 importSource=source.value;importFormat=format.value;
 [...format.options].forEach(o=>{o.disabled=!allowed.includes(o.value)});
 if(file){file.accept='.'+format.value;if(file.files?.length&&!file.files[0].name.toLowerCase().endsWith('.'+format.value))file.value='';}
}
function render(){const root=$('#workspace');if(!root)return;root.innerHTML=header()+`<div class="mex-content">${tab==='pronosticos'?forecasts():sources()}</div></div>`;
 root.querySelector('#mex-update')?.addEventListener('click',()=>update('mef'));
 root.querySelector('#mex-update-imf')?.addEventListener('click',()=>update('imf'));
 root.querySelectorAll('[data-mex-tab]').forEach(b=>b.addEventListener('click',()=>{tab=b.dataset.mexTab;render()}));
 root.querySelector('#mex-variable')?.addEventListener('change',e=>{selected=e.target.value;render()});
 root.querySelector('#mex-publication-calendar')?.addEventListener('toggle',e=>{calendarOpen=e.target.open});
 root.querySelector('#mex-import')?.addEventListener('click',previewFile);
 root.querySelector('#mex-preview-confirm')?.addEventListener('click',confirmFile);
 root.querySelector('#mex-preview-cancel')?.addEventListener('click',()=>{previewData=null;const el=$('#mex-import-preview');if(el)el.innerHTML='';});
 root.querySelector('#mex-import-format')?.addEventListener('change',()=>{clearImportFeedback();syncImportUI()});
 root.querySelector('#mex-import-source')?.addEventListener('change',()=>{clearImportFeedback();syncImportUI()});
 root.querySelector('#mex-import-file')?.addEventListener('change',clearImportFeedback);
 if(tab==='fuentes')syncImportUI();
}
async function load(){try{const r=await fetch('/api/macro-external/status',{cache:'no-store'});if(!r.ok)throw Error('No se pudieron obtener las fuentes');state=await r.json();updateResult=null;lastError='';}catch(e){lastError=e.message;if(!state)state={records:[],editions:[],checks:[],lastCheck:null}}}
async function update(source='mef'){
 if(busy)return;
 busy=true;busySource=source;lastError='';delete sourceErrors[source];savedNotice='';render();
 try{
  const r=await fetch('/api/macro-external/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({scope:source})});
  const obj=await r.json();
  if(!r.ok)throw Error(obj.error||'No se pudo actualizar');
  state=obj;updateResult=obj.updateResult||{};
 }catch(e){sourceErrors[source]=e.message||'Error de conexión';}
 finally{busy=false;busySource='';render();}
}
async function previewFile(){
 if(busy)return;
 const file=$('#mex-import-file')?.files?.[0],format=$('#mex-import-format')?.value,source=$('#mex-import-source')?.value;
 const filename=file?.name||'';importResult=null;previewData=null;
 if(!file){showImportResult(false,'Selección','Selecciona el archivo que deseas revisar.');return;}
 const extension=file.name.split('.').pop()?.toLowerCase();
 if(extension!==format || !['pdf','xlsx'].includes(format)){showImportResult(false,'Formato','El archivo no coincide con el formato seleccionado.',filename);return;}
 if(file.size>11_000_000){showImportResult(false,'Tamaño','El archivo supera los 11 MB admitidos.',filename);return;}
 let stage='Lectura del archivo';busy=true;
 const button=$('#mex-import');if(button){button.disabled=true;button.textContent='Analizando…';}
 try{
  const content=await new Promise((ok,fail)=>{const fr=new FileReader();fr.onload=()=>ok(String(fr.result).split(',')[1]);fr.onerror=()=>fail(Error('No se pudo leer el archivo local.'));fr.readAsDataURL(file)});
  stage='Validación y extracción';
  // La extracción puede tardar; el botón debe recuperarse incluso si el servidor no responde.
  const controller=new AbortController(), timeout=setTimeout(()=>controller.abort(),45000);
  let r,obj;
  try{
   r=await fetch('/api/macro-external/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source,filename:file.name,content}),signal:controller.signal});
   obj=await r.json();
  }finally{clearTimeout(timeout)}
  if(!r.ok)throw Error(obj?.error||`Error HTTP ${r.status} al analizar el documento.`);
  previewData=obj;importResult=null;
  // Mantener disponible la confirmación durante la actualización de la vista.
  busy=false;
  render();
 }catch(e){showImportResult(false,stage,e?.name==='AbortError'?'La previsualización no respondió en el tiempo previsto. Intenta nuevamente.':(e?.message||'No se pudo procesar el archivo.'),filename);}
 finally{busy=false;const b=$('#mex-import');if(b){b.disabled=false;b.textContent='Previsualizar';}}
}
async function confirmFile(){
 if(busy||!previewData?.token)return;
 const pending=previewData;busy=true;const button=$('#mex-preview-confirm');if(button){button.disabled=true;button.textContent='Guardando…';}
 const cancel=$('#mex-preview-cancel');if(cancel)cancel.disabled=true;
 try{
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),30000);
  let r, obj;
  try{
   r=await fetch('/api/macro-external/confirm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:pending.token}),signal:controller.signal});
   obj=await r.json();
  }finally{clearTimeout(timeout)}
  if(!r.ok)throw Error(obj?.error||`Error HTTP ${r.status} al confirmar.`);
  state=obj.state;previewData=null;importResult=null;updateResult=null;lastError='';
  const vars=[...new Set((pending.records||[]).map(row=>row.variable))];selected=vars.length===1?vars[0]:'all';
  savedNotice=`Documento confirmado: ${obj.document?.edition||''}. ${Number(obj.document?.rows||0)} pronósticos verificados; ${Number(obj.added||0)} registros históricos añadidos.`;
  tab='pronosticos';render();
 }catch(e){
  const message=e?.name==='AbortError'?'La confirmación tardó demasiado y no se pudo verificar el resultado. Recarga Pronósticos antes de volver a intentar la carga.':(e?.message||'No se pudo guardar. Vuelve a previsualizar.');
  let saved=false;
  try{
   const check=await fetch('/api/macro-external/status',{cache:'no-store',signal:AbortSignal.timeout(8000)});
   if(check.ok){const current=await check.json();state=current;
    saved=!!(pending.document?.hash&&current.editions?.some(d=>d.hash===pending.document.hash&&d.file));}
  }catch(_){/* El estado puede consultarse al volver a abrir la página. */}
  previewData=null;
  if(saved){
   savedNotice='Documento incorporado. Se verificó el guardado con el historial local.';
   importResult=null;tab='pronosticos';render();
  }else{importResult={ok:false,stage:'Confirmación',message,filename:pending.document?.title||''};render();}
 }
 finally{busy=false;const b=$('#mex-preview-confirm');if(b){b.disabled=false;b.textContent='Confirmar cambios';}const c=$('#mex-preview-cancel');if(c)c.disabled=false;}
}
window.IASPEMacroExternas={render:async function(){if(!busy)await load();if(location.hash.startsWith('#datos/proyecciones'))render()}};
})();
