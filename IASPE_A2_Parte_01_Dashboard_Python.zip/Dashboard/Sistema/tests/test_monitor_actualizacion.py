"""Estados sintéticos y lectura de mecanismo existente; ninguna estimación activa."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import monitor_actualizacion as monitor


def model(identifier='01', monthly=True):
    return {'id': identifier, 'name': 'Fixture sintética '+identifier, 'status': 'ok', 'unit': 'unidades de fixture',
            'frequency': 'annual', 'dependencies': [], 'method': 'Método registrado de fixture',
            'closingRule': 'Regla de cierre de fixture, sin estimar nuevos valores',
            'annual': [{'year': 2025, 'date': '2025-12-31', 'value': 90, 'status': 'observed'},
                       {'year': 2026, 'date': '2026-12-31', 'value': 100, 'status': 'assumed'}],
            'monthly': [{'date': '2026-01-31', 'value': 1, 'status': 'observed'},
                        {'date': '2026-02-28', 'value': 2, 'status': 'assumed'},
                        {'date': '2026-03-31', 'value': 3, 'status': 'forecast'}] if monthly else []}


def inputs(models=None):
    return dict(models=models or {'01': model()}, update_status={'sources': {}},
                published_status={'checkedAt': '2026-11-01T00:00:00Z', 'sources': []}, ledgers={},
                downloaded={}, applied={}, manual={}, manual_applied={}, last_recalculation=None,
                source_names={'tarjetas': 'Número de tarjetas'}, source_components={'tarjetas': ['01']})


class UpdateMonitorTests(unittest.TestCase):
    def test_all_models_and_components_including_48_and_49_are_retained(self):
        models = {f'{i:02}': model(f'{i:02}', monthly=False) for i in range(1, 50)}
        models['17_caja'] = model('17_caja')
        result = monitor.assemble(**inputs(models))
        self.assertEqual(result['summary']['modelCount'], 49)
        self.assertEqual(result['summary']['seriesCount'], 50)
        self.assertEqual({m['id'] for m in result['models']}, set(models))
        self.assertTrue(next(m for m in result['models'] if m['id']=='17_caja')['isComponent'])

    def test_historical_reference_for_m01_uses_persisted_same_model(self):
        m = model('01')
        m['monthly'] += [
            {'date': '2025-10-01', 'value': 100, 'status': 'observed'},
            {'date': '2025-11-01', 'value': 110, 'status': 'observed'},
            {'date': '2025-12-01', 'value': 120, 'status': 'observed'},
        ]
        r = monitor.assemble(**inputs({'01': m}))['models'][0]
        self.assertEqual(len(r['monthly2025']), 3)
        self.assertEqual([x['value'] for x in r['monthly2025']], [100, 110, 120])
        self.assertEqual(r['monthly2025'][0]['period'], '2025-10')

    def test_downloaded_observation_does_not_replace_persisted_estimate_before_apply(self):
        args = inputs()
        args['applied'] = {'01': {'2026-01': 0}}
        args['downloaded'] = {'01': {'2026-01': 0, '2026-02': 99}}
        result = monitor.assemble(**args)
        entry = result['models'][0]
        self.assertEqual(len(entry['monthly2026']), 12)
        january, february, march, april = entry['monthly2026'][:4]
        self.assertEqual((january['status'], january['value']), ('observed', 0))
        self.assertEqual((february['status'], february['value']), ('estimated', 2))
        self.assertTrue(february['pending'])
        self.assertEqual(february['pendingObservations'][0]['current'], 99)
        self.assertEqual(march['status'], 'estimated')
        self.assertEqual((april['status'], april['value']), ('missing', None))
        self.assertEqual(entry['status'], 'pending')

    def test_annual_models_never_receive_an_invented_monthly_distribution(self):
        args = inputs({'02': model('02', monthly=False)})
        args['applied'] = {'02': {'2026-09': 88}}
        result = monitor.assemble(**args)['models'][0]
        self.assertEqual(result['frequency'], 'annual')
        self.assertIsNone(result['monthly2026'])
        self.assertEqual(result['annual2026']['status'], 'estimated')
        self.assertEqual(result['annual2026']['value'], 100)
        self.assertEqual(result['lastIncorporatedPeriod'], '2026-09')

    def test_applied_snapshot_moves_only_the_actual_month_and_clears_pending(self):
        args = inputs()
        args['applied'] = args['downloaded'] = {'01': {'2026-02': 99}}
        result = monitor.assemble(**args)
        self.assertFalse(result['pending']['pending'])
        self.assertEqual(result['models'][0]['monthly2026'][1]['status'], 'observed')
        self.assertEqual(result['models'][0]['monthly2026'][1]['value'], 99)
        self.assertEqual(result['models'][0]['monthly2026'][2]['status'], 'estimated')

    def test_pending_state_follows_existing_dependencies_without_recalculating_values(self):
        m48, m49 = model('48', False), model('49', False)
        m48['dependencies'] = ['01'];m49['dependencies'] = ['48']
        args = inputs({'01': model(), '48': m48, '49': m49})
        args['downloaded'] = {'01': {'2026-02': 99}}
        result = monitor.assemble(**args)
        self.assertEqual(result['pending']['models'], ['01', '48', '49'])
        self.assertEqual(next(m for m in result['models'] if m['id']=='49')['annual2026']['value'], 100)

    def test_failed_download_keeps_previous_periods_and_error_without_marking_current(self):
        args = inputs()
        args['applied'] = args['downloaded'] = {'01': {'2026-09': 80}}
        args['update_status'] = {'sources': {'tarjetas': {'status': 'error', 'latestPeriod': '2026-09',
            'detail': 'Fixture de descarga fallida', 'download': {'status': 'error', 'errors': ['HTTP fixture'],
            'reports': {'B-2363': {'latestPublished': '2026-09', 'latestProcessed': '2026-09'}}}}}}
        source = monitor.assemble(**args)['sources'][0]
        self.assertEqual(source['status'], 'error')
        self.assertEqual(source['downloadedPeriod'], '2026-09')
        self.assertEqual(source['appliedPeriod'], '2026-09')
        self.assertEqual(source['reports'][0]['verification'], 'last_verified')
        self.assertIn('HTTP fixture', source['notes'])

    def test_unverified_official_source_does_not_become_official_from_a_local_file(self):
        args = inputs()
        args['published_status']['sources'] = [{'id': 'tarjetas', 'status': 'no_verificado', 'reports': [
            {'code': 'B-2363', 'localPeriod': '2026-09', 'remotePeriod': None, 'status': 'no_verificado'}]}]
        source = monitor.assemble(**args)['sources'][0]
        self.assertIsNone(source['officialPeriod'])
        self.assertEqual(source['reports'][0]['verification'], 'not_verified')

    def test_failed_recalculation_is_not_a_successful_date_and_retains_previous_version(self):
        args = inputs()
        args['last_recalculation'] = {'generatedAt': '2026-11-02T00:00:00Z', 'ok': False, 'status': 'pendiente'}
        result = monitor.assemble(**args)
        self.assertIsNone(result['summary']['lastSuccessfulRecalculation'])
        self.assertEqual(result['models'][0]['status'], 'valid_previous')
        args['history'] = {'versions': [{'kind': 'previous', 'publishedAt': '2026-11-02T00:00:00Z'}],
                           'publications': [{'publishedAt': '2026-11-01T00:00:00Z', 'ok': True, 'status': 'published'}]}
        result = monitor.assemble(**args)
        self.assertEqual(result['summary']['lastSuccessfulRecalculation'], '2026-11-01T00:00:00Z')
        args['history']['publications'] += [{'publishedAt': '2026-11-03T00:00:00Z'},
            {'publishedAt': '2026-11-04T00:00:00Z', 'ok': False, 'status': 'published'},
            {'publishedAt': '2026-11-05T00:00:00Z', 'ok': True, 'status': 'pending'}]
        self.assertEqual(monitor.assemble(**args)['summary']['lastSuccessfulRecalculation'], '2026-11-01T00:00:00Z')

    def test_closing_method_uses_applied_metadata_and_preserves_estimated_status(self):
        args = inputs()
        args['applied'] = {'sbs_contable': {'01': {'2026': {'value': 105, 'status': 'assumed',
            'sourceMonth': '2026-09', 'method': 'Método de cierre aprobado de fixture'}}}}
        result = monitor.assemble(**args)['models'][0]['closing2026']
        self.assertEqual(result['method'], 'Método de cierre aprobado de fixture')
        self.assertEqual(result['sourceMonth'], '2026-09')
        self.assertEqual(result['status'], 'estimated')
        self.assertEqual(result['value'], 100)

    def test_first_failed_recalculation_keeps_saved_success_without_forecast_journal(self):
        args = inputs()
        args['last_recalculation'] = {'generatedAt': '2026-11-21T00:00:00Z', 'ok': False, 'status': 'pendiente'}
        args['last_successful_recalculation'] = {'generatedAt': '2026-11-20T23:43:55Z', 'ok': True, 'status': 'completo'}
        result = monitor.assemble(**args)
        self.assertEqual(result['summary']['lastSuccessfulRecalculation'], '2026-11-20T23:43:55Z')
        self.assertEqual(result['lastSuccessfulRecalculation']['basis'], 'ultimo_recalculo_exitoso')
        self.assertEqual(result['models'][0]['status'], 'valid_previous')

    def test_latest_confirmed_success_wins_between_attempt_saved_and_journal(self):
        args = inputs()
        args['last_recalculation'] = {'generatedAt': '2026-11-22T00:00:00Z', 'ok': True, 'status': 'completo'}
        args['last_successful_recalculation'] = {'generatedAt': '2026-11-23T00:00:00Z', 'ok': True, 'status': 'completo'}
        args['history'] = {'publications': [{'publishedAt': '2026-11-21T00:00:00Z', 'ok': True, 'status': 'published'}]}
        result = monitor.assemble(**args)
        self.assertEqual(result['summary']['lastSuccessfulRecalculation'], '2026-11-23T00:00:00Z')
        args['last_successful_recalculation'].update(ok=False, generatedAt='2026-11-24T00:00:00Z')
        self.assertEqual(monitor.assemble(**args)['summary']['lastSuccessfulRecalculation'], '2026-11-22T00:00:00Z')

    def test_residual_close_is_not_mislabeled_as_the_underlying_sbs_stock_proxy(self):
        fixture = model('17_bancos', False)
        fixture['method'] = 'Saldo residual de liquidez, conciliación SBS M47'
        args = inputs({'17_bancos': fixture})
        args['applied'] = {'sbs_contable': {'17_bancos': {'2026': {'method': 'Último stock SBS', 'sourceMonth': '2026-09'}}}}
        result = monitor.assemble(**args)['models'][0]['closing2026']
        self.assertEqual(result['method'], fixture['method'])
        self.assertEqual(result['sourceMethod'], 'Último stock SBS')

    def test_savings_applied_metadata_outside_sbs_contable_is_recognized(self):
        args = inputs({'08': model('08', False)})
        args['source_names'] = {'ahorro_moneda': 'Ahorro de fixture'}
        args['source_components'] = {'ahorro_moneda': ['08']}
        args['applied'] = args['downloaded'] = {'08': {'2026': {'value': 100, 'status': 'assumed',
            'sourceMonth': '2026-09', 'method': 'Último stock SBS de fixture'}}}
        result = monitor.assemble(**args)
        self.assertEqual(result['sources'][0]['appliedPeriod'], '2026-09')
        self.assertEqual(result['models'][0]['closing2026']['method'], 'Último stock SBS de fixture')
        self.assertEqual(result['models'][0]['annual2026']['status'], 'estimated')

    def test_actual_staff_link_is_auxiliary_and_does_not_make_finance_or_rural_feed_models(self):
        args = inputs({'19_personal': model('19_personal', False)})
        args['source_names'] = {'personal_banca': 'Personal banca', 'personal_financieras': 'Personal financieras', 'personal_rurales': 'Personal rurales'}
        args['source_components'] = {}
        args['applied'] = args['downloaded'] = {'trabajadores_falabella': {'2026': 11.5}}
        args['link_status'] = {'fuentes': {'personal_banca': {'modelos': ['19_personal'], 'derivados': ['19', '28', '29'],
            'trazabilidad': {'mes_ultimo': '2026-09', 'cierre': 11.5, 'estado_cierre': 'estimado'}},
            'personal_financieras': {'estado': 'solo_comparativo', 'modelos': []},
            'personal_rurales': {'estado': 'solo_comparativo', 'modelos': []}}}
        result = monitor.assemble(**args)
        sources = {s['id']: s for s in result['sources']}
        self.assertEqual(sources['personal_banca']['directModelIds'], ['19_personal'])
        self.assertEqual(sources['personal_banca']['appliedPeriod'], '2026-09')
        self.assertEqual(sources['personal_banca']['auxiliaryInputs'][0]['unit'], 'personas')
        self.assertEqual(sources['personal_banca']['auxiliaryInputs'][0]['annualStatus'], 'estimated')
        self.assertFalse(sources['personal_financieras']['feedsModels'])
        self.assertFalse(sources['personal_rurales']['feedsModels'])
        self.assertEqual(result['models'][0]['annual2026']['value'], 100)

    def test_pending_staff_routes_to_real_models_without_marking_new_month_as_applied(self):
        models = {key: model(key, False) for key in ('19_personal', '19', '28', '29')}
        args = inputs(models)
        args['source_names'] = {'personal_banca': 'Personal banca', 'estados_financieros': 'EEFF'}
        args['source_components'] = {'estados_financieros': ['19_personal']}
        args['applied'] = {'trabajadores_falabella': {'2026': 11.5}}
        args['downloaded'] = {'trabajadores_falabella': {'2026': 13.5}}
        args['link_status'] = {'fuentes': {'personal_banca': {'modelos': ['19_personal'], 'derivados': ['19', '28', '29'],
            'trazabilidad': {'mes_ultimo': '2026-10', 'cierre': 13.5, 'estado_cierre': 'estimado'}}}}
        result = monitor.assemble(**args)
        self.assertEqual(result['pending']['models'], ['19', '19_personal', '28', '29'])
        sources = {s['id']: s for s in result['sources']}
        self.assertIsNone(sources['personal_banca']['appliedPeriod'])
        self.assertEqual(sources['personal_banca']['pendingObservations'], 1)
        self.assertEqual(sources['estados_financieros']['pendingObservations'], 0)
        detail = next(m for m in result['models'] if m['id']=='19_personal')['pendingDetails'][0]
        self.assertEqual(detail['inputName'], 'trabajadores_falabella')
        self.assertEqual(detail['inputUnit'], 'personas')
        self.assertEqual(next(m for m in result['models'] if m['id']=='19_personal')['annual2026']['value'], 100)

    def test_assembler_is_pure_and_revision_changes_only_with_state(self):
        args = inputs();before = deepcopy(args)
        first = monitor.assemble(**args);second = monitor.assemble(**args)
        self.assertEqual(args, before)
        self.assertEqual(first['revision'], second['revision'])
        args['downloaded'] = {'01': {'2026-02': 99}}
        self.assertNotEqual(first['revision'], monitor.assemble(**args)['revision'])

    def test_snapshot_never_refreshes_portals_estimates_or_takes_manager_lock(self):
        import actualizador_sbs
        import monitor_fuentes
        import motor
        with tempfile.TemporaryDirectory(prefix='iaspe_monitor_readonly_') as temporary:
            root = Path(temporary)
            output = root/'Scraper/Actualizacion/output';output.mkdir(parents=True)
            (output/'ultima_ejecucion.json').write_text('{"sources":{}}', encoding='utf-8')
            before = (output/'ultima_ejecucion.json').read_bytes()
            with patch.object(monitor, 'ROOT', root), patch.object(motor, 'load_base', return_value=({'01': model()}, [])), \
                 patch.object(motor, 'read_state', side_effect=lambda name, default: deepcopy(default)), \
                 patch.object(motor, 'calculate', side_effect=AssertionError('No estimar')), \
                 patch.object(motor, 'recalculate_sources', side_effect=AssertionError('No recalcular')), \
                 patch.object(actualizador_sbs.MANAGER, 'snapshot', side_effect=AssertionError('No invertir locks')), \
                 patch.object(monitor_fuentes.MANAGER, 'snapshot', return_value={'sources': []}) as publication:
                result = monitor.snapshot()
            self.assertTrue(result['readOnly'])
            publication.assert_called_once_with(refresh=False)
            self.assertEqual(before, (output/'ultima_ejecucion.json').read_bytes())
            self.assertEqual(len(list(root.rglob('*'))), 4)


if __name__ == '__main__':
    unittest.main()
