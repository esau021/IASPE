/* Ejecuta las funciones reales de selección del Dashboard sin cambiar su diseño. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
let source = fs.readFileSync(path.join(__dirname, '..', 'proyecciones-externas.js'), 'utf8');
assert(source.includes('window.IASPEMacroExternas='));
source = source.replace('window.IASPEMacroExternas=',
  'globalThis.probe={setState:s=>{state=s},recordsBySeries,tableForVariable,ROWS};window.IASPEMacroExternas=');
const context = {window: {}, document: {querySelector: () => null}, location: {hash: ''},
  Intl, URL, Date, Map, Set, console};
vm.createContext(context);
vm.runInContext(source, context);
const {probe} = context;
const ri = 'BCRP · Reporte de Inflación';
const row = (year, edition, value, document) => ({source: ri, variable: 'pbi', year,
  edition, revision: edition, published: edition, value, kind: 'anual', unit: '%', group: '', document_hash: document});
// Dos años cuyos últimos pronósticos proceden de distintas ediciones/documentos.
probe.setState({current_records: [row('2026', '2026-09', 3.2, 'september'),
                                row('2028', '2026-12', 3.1, 'december')]});
let index = probe.recordsBySeries();
assert.equal(index.size, 2);
assert.equal(index.get(['pbi', ri, '', '2026'].join('|')).value, 3.2);
assert.equal(index.get(['pbi', ri, '', '2028'].join('|')).value, 3.1);
const html = probe.tableForVariable('pbi', index);
assert(html.includes('Edición: 2026-09 · Año: 2026'));
assert(html.includes('Edición: 2026-12 · Año: 2028'));
assert.equal((html.match(/class="numeric mex-value"/g) || []).length, 2);
// EEM conserva la restricción de una cohorte por variable; no rellena grupos antiguos.
const survey = 'BCRP · encuesta anual';
const current = {source: survey, variable: 'pbi', year: '2026', edition: '2026-10', published: '2026-11-06',
  group: 'Analistas económicos', value: 3.2, kind: 'anual', document_hash: 'new'};
probe.setState({current_records: [current, {...current, year: '2027', edition: '2026-09',
  published: '2026-10-06', document_hash: 'old'}]});
index = probe.recordsBySeries();
assert.equal(index.size, 1);
assert.equal(index.get(['pbi', survey, 'Analistas económicos', '2026'].join('|')).value, 3.2);
assert.equal(index.has(['pbi', survey, 'Analistas económicos', '2027'].join('|')), false);
console.log('Dashboard forecast selection: passed');
