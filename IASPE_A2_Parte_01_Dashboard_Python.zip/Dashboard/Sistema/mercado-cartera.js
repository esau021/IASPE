/* Cartera SBS: comparaciones históricas por entidad y pronóstico agregado IASPE. */
(()=>{
'use strict';
const $=q=>document.querySelector(q),$$=q=>Array.from(document.querySelectorAll(q));
const MONTHS=['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
const COLORS=['#36865c','#b17a40','#8965a7','#467da2','#b66c62','#789444','#27878e','#ad5889','#98713e','#4b9169','#776db8','#9b6958','#3d9aa0','#8c6295','#6d8d4f','#c07140','#4687b5','#8a8570','#bd657b','#5f7eaa','#8d9a3f','#3a8872','#8868a9','#a87c50'];
const MODES=[['saldo','Saldos'],['indice','Base 100'],['participacion','Participación'],['yoy','Variación anual']];
const CATEGORIES=[['cartera','Cartera total de consumo'],['tarjetas','Tarjetas de crédito de consumo'],['prestamos','Préstamos no revolventes de consumo']];
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const month=s=>s?`${MONTHS[Number(s.slice(5))-1]} ${s.slice(0,4)}`:'—';
const serial=s=>+s.slice(0,4)*12+ +s.slice(5,7)-1;
const pct=(app,v,d=2)=>finite(v)?app.fmt(v,d)+'%':'—';
const fmt=(app,v,d=2)=>finite(v)?app.fmt(v,d):'—';
let data=null,pending=null,request=0;
const state={component:'cartera',compare:'market',peers:['interbank'],frequency:'annual',mode:'participacion',panel:'chart',range:'recent'};
function bankName(id){return data.banks.find(b=>b.id===id)?.name||id;}
function amount(r,id){return id==='mercado'?r?.mercado?.[state.component]:r?.bancos?.[id]?.[state.component];}
function chosen(){return state.compare==='market'?['falabella','mercado']:['falabella',...state.peers.filter(id=>id!=='falabella'&&data.banks.some(b=>b.id===id))];}
function name(id){return id==='mercado'?'Banca múltiple':bankName(id);}
function fcolor(id,index){return id==='falabella'?'#245a77':id==='mercado'?'#2f9860':COLORS[(data.banks.findIndex(b=>b.id===id)+COLORS.length)%COLORS.length];}
function annualProjection(app,id){
  const model=app.model(id==='mercado'?'48':'07');
  return (model?.annual||[]).filter(r=>+r.year>=2026&&+r.year<=2030&&finite(r.value));
}
function projectionPossible(app){return state.compare==='market'&&state.component==='cartera'&&annualProjection(app,'falabella').length>0&&annualProjection(app,'mercado').length>0;}
function observations(){return data.rows.filter(r=>state.frequency==='monthly'||r.date.endsWith('-12'));}
function rowsFor(app){
  const out=observations().map(r=>({date:r.date,status:'Observado',values:Object.fromEntries(chosen().map(id=>[id,amount(r,id)])),raw:r}));
  if(projectionPossible(app)){
    const fa=annualProjection(app,'falabella'),ma=annualProjection(app,'mercado');
    const marketMap=new Map(ma.map(r=>[Number(r.year),r]));
    for(const f of fa){
      const m=marketMap.get(Number(f.year));if(!m)continue;
      const date=`${f.year}-12`;
      if(out.some(r=>r.date===date))continue;
      out.push({date,status:f.year===2026?'Cierre estimado':'Pronóstico',values:{falabella:f.value,mercado:m.value}});
    }
  }
  return out.sort((a,b)=>a.date.localeCompare(b.date));
}
function startIndex(rows){return state.range==='all'?0:Math.max(0,rows.length-(state.frequency==='monthly'?43:10));}
function transformed(all, display){
  const ids=chosen(), lookup=new Map(all.map(r=>[r.date,r]));
  const base=display.find(r=>ids.every(id=>finite(r.values[id])&&r.values[id]>0))||display.find(r=>finite(r.values.falabella)&&r.values.falabella>0);
  const fn=(r,id)=>{
    const v=r.values[id];if(!finite(v))return null;
    if(state.mode==='saldo')return v;
    if(state.mode==='indice')return base&&finite(base.values[id])&&base.values[id]>0?100*v/base.values[id]:null;
    if(state.mode==='participacion'){
      const market=finite(r.values.mercado)?r.values.mercado:amount(data.rows.find(x=>x.date===r.date),'mercado');
      return finite(market)&&market>0?100*v/market:null;
    }
    const last=lookup.get(`${+r.date.slice(0,4)-1}${r.date.slice(4)}`);
    const previous=last?.values[id];
    return finite(previous)&&previous!==0?100*(v/previous-1):null;
  };
  return {fn,base};
}
function seriesLabels(){
  const justShare=state.compare==='market'&&state.mode==='participacion';
  return (justShare?['falabella']:chosen()).map((id,i)=>({id,label:justShare?'Participación Falabella':name(id),color:fcolor(id,i)}));
}
function plot(app,all,display){
  if(display.length<2)return '<div class="cartera-empty">No hay información para el período elegido.</div>';
  const series=seriesLabels(),{fn}=transformed(all,display);
  const points=display.flatMap(r=>series.map(s=>fn(r,s.id))).filter(finite);
  if(!points.length)return '<div class="cartera-empty">No hay valores comparables para esta vista.</div>';
  const W=1050,H=340,L=76,R=25,T=23,B=40;
  const start=serial(display[0].date),span=Math.max(1,serial(display.at(-1).date)-start);
  const x=r=>L+(serial(r.date)-start)*(W-L-R)/span;
  let bottom=Math.min(...points),top=Math.max(...points),range=top-bottom;
  if(state.mode==='saldo')bottom=Math.max(0,bottom-Math.max(range*.13,top*.03));
  else if(state.mode==='participacion'&&state.compare==='market')bottom=Math.max(0,bottom-Math.max(.25,range*.24));
  else bottom-=Math.max(range*.15,.5);
  top+=Math.max(range*.15,state.mode==='participacion'?.25:state.mode==='indice'?3:1);
  if(top<=bottom)top=bottom+1;
  const y=v=>T+(top-v)*(H-T-B)/(top-bottom);
  const step=state.frequency==='monthly'?1:12;
  function path(s,forecast){
    let d='',last=null;
    for(const r of display){
      const value=fn(r,s.id),isFuture=r.status!=='Observado';
      if(!finite(value)){last=null;continue;}
      if(isFuture!==forecast){if(forecast&&last&&last.status==='Observado'){}else{last=null;continue;}}
      const connected=last&&(serial(r.date)-serial(last.date)===step || (forecast&&r.status!=='Observado'));
      d+=`${connected?'L':'M'}${x(r).toFixed(1)},${y(value).toFixed(1)} `;
      last=r;
    }
    return d;
  }
  const pathObserved=s=>{
    let d='',last=null;
    for(const r of display){if(r.status!=='Observado')break;const v=fn(r,s.id);if(!finite(v)){last=null;continue;}
      d+=`${last&&serial(r.date)-serial(last.date)===step?'L':'M'}${x(r).toFixed(1)},${y(v).toFixed(1)} `;last=r;}
    return d;
  };
  const pathFuture=s=>{
    if(!projectionPossible(app)||!['falabella','mercado'].includes(s.id))return '';
    const forecasts=display.filter(r=>r.status!=='Observado');if(!forecasts.length)return '';
    const prior=[...display].reverse().find(r=>r.status==='Observado'&&finite(fn(r,s.id)));
    const pts=prior?[prior,...forecasts]:forecasts;
    return pts.map((r,i)=>{const v=fn(r,s.id);return finite(v)?`${i?'L':'M'}${x(r).toFixed(1)},${y(v).toFixed(1)} `:'';}).join('');
  };
  const ticks=[0,1,2,3,4].map(i=>{const v=bottom+(top-bottom)*i/4,yy=y(v);return `<line x1="${L}" x2="${W-R}" y1="${yy}" y2="${yy}" class="cartera-grid-line"/><text x="${L-12}" y="${yy+4}" text-anchor="end">${esc(fmt(app,v,state.mode==='saldo'?0:2))}</text>`;}).join('');
  const positions=[...new Set(Array.from({length:Math.min(7,display.length)},(_,i)=>Math.round((display.length-1)*i/Math.max(1,Math.min(7,display.length)-1))))];
  const horizontals=positions.map(i=>`<text x="${x(display[i])}" y="${H-12}" text-anchor="middle">${display[i].date.slice(0,4)}</text>`).join('');
  const stroke=series.map(s=>`<path fill="none" stroke="${s.color}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round" d="${pathObserved(s)}"/><path fill="none" stroke="${s.color}" stroke-width="2.7" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="7 6" d="${pathFuture(s)}"/>`).join('');
  const hits=display.map((r,i)=>{
    const curr=x(r),left=i?(x(display[i-1])+curr)/2:L,right=i<display.length-1?(curr+x(display[i+1]))/2:W-R;
    const vals=series.map(s=>({name:s.label,color:s.color,value:fn(r,s.id)})).filter(s=>finite(s.value));
    return `<rect class="cartera-hit" x="${left}" y="${T}" width="${Math.max(1,right-left)}" height="${H-T-B}" data-date="${r.date}" data-kind="${r.status}" data-x="${curr}" data-values="${esc(JSON.stringify(vals))}" fill="transparent"/>`;
  }).join('');
  const legend=series.map(s=>`<span><i style="background:${s.color}"></i>${esc(s.label)}</span>`).join('');
  return `<div class="cartera-legend">${legend}${projectionPossible(app)?'<small>Línea continua: observado · Discontinua: estimado/proyectado</small>':''}</div><div class="cartera-plot"><svg viewBox="0 0 ${W} ${H}" role="img" class="cartera-svg" aria-label="Cartera de consumo observada y proyectada">${ticks}${horizontals}${stroke}<line class="cartera-cursor" x1="0" x2="0" y1="${T}" y2="${H-B}" visibility="hidden"/>${hits}</svg><div class="cartera-tooltip" hidden></div></div>`;
}
function historyTable(app,all,display){
  const series=seriesLabels(),{fn}=transformed(all,display);
  const header=series.map(s=>`<th class="num">${esc(s.label)}</th>`).join('');
  const unit=state.mode==='saldo'?'S/ millones':state.mode==='indice'?'Índice':state.mode==='yoy'?'% interanual':'%';
  const tbody=[...display].reverse().map(r=>`<tr><td>${month(r.date)}</td>${series.map(s=>`<td class="num">${fmt(app,fn(r,s.id),2)}${state.mode==='participacion'||state.mode==='yoy'?'%':''}</td>`).join('')}<td>${r.status}</td></tr>`).join('');
  return `<div class="cartera-table-wrap cartera-history-table"><table><thead><tr><th>Período</th>${header}<th>Condición</th></tr></thead><tbody>${tbody}</tbody></table></div><p class="cartera-unit">${unit}</p>`;
}
function metrics(app,all){
  const lastObserved=[...all].reverse().find(r=>r.status==='Observado'),market=lastObserved?.values.mercado??amount(data.rows.at(-1),'mercado');
  const fal=lastObserved?.values.falabella;
  const share=finite(fal)&&finite(market)&&market>0?100*fal/market:null;
  const forecast=all.find(r=>r.date==='2030-12');
  const projected=forecast&&forecast.values.mercado>0?100*forecast.values.falabella/forecast.values.mercado:null;
  const component=CATEGORIES.find(c=>c[0]===state.component)?.[1]||'Cartera';
  if(projectionPossible(app)){
    const base2025=all.find(r=>r.date==='2025-12');
    const sh2025=base2025?.values.mercado>0?100*base2025.values.falabella/base2025.values.mercado:null;
    const delta=finite(sh2025)&&finite(projected)?projected-sh2025:null;
    return `<div class="cartera-metrics cartera-metrics-compact"><div class="cartera-kpi"><small>Participación observada · ${month(lastObserved.date)}</small><strong>${pct(app,share)}</strong></div><div class="cartera-kpi accent-peer"><small>Participación proyectada · 2030</small><strong>${pct(app,projected)}</strong><span>${finite(delta)?(delta>=0?'+':'')+fmt(app,delta)+' pp frente a 2025':''}</span></div></div>`;
  }
  const other=state.compare==='peer'?state.peers.length===1?name(state.peers[0]):`${state.peers.length} entidades`:'Banca múltiple';
  return `<div class="cartera-metrics cartera-metrics-compact"><div class="cartera-kpi"><small>Banco Falabella · ${month(lastObserved.date)}</small><strong>${fmt(app,fal)}</strong><span>S/ millones</span></div><div class="cartera-kpi accent-peer"><small>${esc(other)}</small><strong>${state.compare==='market'?fmt(app,market):state.peers.length===1?fmt(app,lastObserved.values[state.peers[0]]):String(state.peers.length)}</strong><span>${state.peers.length===1||state.compare==='market'?'S/ millones':'Entidades seleccionadas'}</span></div></div>`;
}
function options(){
  const chosenSet=new Set(state.peers);
  return window.IASPEInstitutionGroups.html(data.banks.filter(b=>b.id!=='falabella'),observations().at(-1)?.date||data.rows.at(-1)?.date,b=>{const title=b.historical_only&&b.last?`${b.name} · historia bancaria hasta ${month(b.last)}`:b.name;return `<label class="cartera-bank-option" data-search="${esc(title.toLowerCase())}"><input type="checkbox" value="${esc(b.id)}" ${chosenSet.has(b.id)?'checked':''}/><span>${esc(title)}</span></label>`;});
}
function csv(app,all,display){
  const series=seriesLabels(),{fn}=transformed(all,display);
  const head=['Periodo',...series.map(s=>s.label),'Condición'];
  const lines=[head,...display.map(r=>[r.date,...series.map(s=>{const v=fn(r,s.id);return finite(v)?v.toFixed(6):'';}),r.status])];
  const csv='\ufeff'+lines.map(row=>row.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(';')).join('\r\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');
  a.href=url;a.download=`IASPE_cartera_${state.component}_${state.mode}_${state.range}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1200);
}
function renderPage(app){
  const all=rowsFor(app),historical=all.filter(r=>r.status==='Observado');
  const display=all.slice(state.range==='all'?0:startIndex(all));
  const nav='<nav class="market-main-tabs"><a class="active" href="#benchmark/cartera" aria-current="page">Cartera de consumo</a><a href="#benchmark/oficinas">Oficinas</a><a href="#benchmark/eeff">Estados financieros</a><a href="#benchmark/ratios">Indicadores financieros</a><a href="#benchmark/personal">Personal</a></nav>';
  const label=CATEGORIES.find(c=>c[0]===state.component)?.[1]||'Cartera';
  return `<section class="cartera-workspace">${nav}<header class="cartera-heading"><div><h1>Cartera de consumo</h1></div>${window.IASPESourceUpdates.control('cartera',data.rows.at(-1)?.date,false)}</header>
   <div class="cartera-filters"><label>Modalidad<select id="cartera-component">${CATEGORIES.map(([id,title])=>`<option value="${id}" ${id===state.component?'selected':''}>${title}</option>`).join('')}</select></label><label>Comparar con<select id="cartera-target"><option value="market" ${state.compare==='market'?'selected':''}>Banca múltiple</option><option value="peer" ${state.compare==='peer'?'selected':''}>Entidades seleccionadas</option></select></label>${state.compare==='peer'?`<div class="cartera-bank-picker"><span>Entidades</span><details id="cartera-bank-details"><summary>${state.peers.length===1?esc(name(state.peers[0])):state.peers.length?state.peers.length+' entidades seleccionadas':'Seleccionar entidades'}</summary><div class="cartera-bank-menu"><input type="search" id="cartera-bank-search" placeholder="Buscar entidad…" aria-label="Buscar entidad"/><div class="cartera-bank-list">${options()}</div><div class="cartera-bank-footer"><small>Selección inmediata · sin límite de entidades</small></div></div></details></div>`:''}<label>Frecuencia<select id="cartera-frequency"><option value="annual" ${state.frequency==='annual'?'selected':''}>Diciembre anual</option><option value="monthly" ${state.frequency==='monthly'?'selected':''}>Mensual</option></select></label></div>
   ${metrics(app,all)}
   <section class="cartera-panel"><div class="cartera-panel-head"><div><h2>${esc(label)}</h2>${projectionPossible(app)?'<p>Histórico SBS y proyección IASPE · hasta 2030</p>':''}</div><div class="cartera-panel-actions"><div class="segmented">${MODES.map(([v,title])=>`<button type="button" data-car-mode="${v}" class="${state.mode===v?'active':''}">${title}</button>`).join('')}</div><div class="segmented"><button type="button" data-car-panel="chart" class="${state.panel==='chart'?'active':''}">Gráfico</button><button type="button" data-car-panel="table" class="${state.panel==='table'?'active':''}">Tabla</button></div><details class="cartera-more"><summary>Más opciones</summary><div><button type="button" data-car-range="${state.range==='all'?'recent':'all'}">${state.range==='all'?'Ver reciente':'Histórico completo'}</button><button type="button" id="cartera-download">Exportar CSV</button></div></details></div></div>${state.panel==='chart'?plot(app,all,display):historyTable(app,all,display)}${projectionPossible(app)?`<div class="cartera-model-actions"><button type="button" data-car-model="07">Modelo Falabella</button><button type="button" data-car-model="48">Modelo banca múltiple</button></div>`:''}</section>
  </section>`;
}
function bind(app){
  window.IASPESourceUpdates.bind(app);
  $('#cartera-component').onchange=e=>{state.component=e.target.value;app.render();};
  $('#cartera-target').onchange=e=>{state.compare=e.target.value;state.mode=state.compare==='market'?'participacion':'saldo';app.render();};
  $('#cartera-frequency').onchange=e=>{state.frequency=e.target.value;app.render();};
  $$('[data-car-mode]').forEach(b=>b.onclick=()=>{state.mode=b.dataset.carMode;app.render();});
  $$('[data-car-panel]').forEach(b=>b.onclick=()=>{state.panel=b.dataset.carPanel;app.render();});
  $$('[data-car-range]').forEach(b=>b.onclick=()=>{state.range=b.dataset.carRange;app.render();});
  $$('[data-car-model]').forEach(b=>b.onclick=()=>window.IASPESpec?.open?.(app,b.dataset.carModel));
  const down=$('#cartera-download');if(down)down.onclick=()=>{const all=rowsFor(app);csv(app,all,all.slice(startIndex(all)));};
  if($('#cartera-bank-details')){
    $('#cartera-bank-search').oninput=e=>window.IASPEInstitutionGroups.filter($('.cartera-bank-list'),'.cartera-bank-option',e.target.value);
    $$('.cartera-bank-option input').forEach(checkbox=>checkbox.onchange=()=>{
      const next=$$('.cartera-bank-option input:checked').map(x=>x.value);
      const search=$('#cartera-bank-search').value;
      const scroll=$('.cartera-bank-list').scrollTop;
      state.peers=next;
      $('#workspace').innerHTML=renderPage(app);
      bind(app);
      const details=$('#cartera-bank-details');
      if(details){details.open=true;$('#cartera-bank-search').value=search;$('#cartera-bank-search').dispatchEvent(new Event('input'));$('.cartera-bank-list').scrollTop=scroll;}
    });
  }
  const plotEl=$('.cartera-plot');
  if(plotEl){
    const tooltip=plotEl.querySelector('.cartera-tooltip'),cursor=plotEl.querySelector('.cartera-cursor');
    plotEl.querySelectorAll('.cartera-hit').forEach(hit=>{
      const show=()=>{
        const vals=JSON.parse(hit.dataset.values).sort((a,b)=>b.value-a.value);
        const x=+hit.dataset.x,width=plotEl.querySelector('svg').viewBox.baseVal.width;
        tooltip.innerHTML=`<strong>${esc(month(hit.dataset.date))} · ${esc(hit.dataset.kind)}</strong>${vals.map(v=>`<span><i style="background:${v.color}"></i>${esc(v.name)}<b>${fmt(app,v.value,2)}${['participacion','yoy'].includes(state.mode)?'%':''}</b></span>`).join('')}`;
        tooltip.style.left=Math.max(15,Math.min(80,x/width*100))+'%';tooltip.hidden=false;
        cursor.setAttribute('x1',x);cursor.setAttribute('x2',x);cursor.setAttribute('visibility','visible');
      };
      hit.addEventListener('pointerenter',show);hit.addEventListener('pointermove',show);hit.addEventListener('focus',show);
    });
    plotEl.addEventListener('pointerleave',()=>{tooltip.hidden=true;cursor.setAttribute('visibility','hidden');});
  }
}
async function render(app){
  await window.IASPESourceUpdates.refresh(app).catch(()=>null);
  if(!/^#benchmark\/(cartera|tarjetas|prestamos)(?:[/?]|$)/.test(location.hash))return;
  const token=++request;
  if(!data){
    $('#workspace').innerHTML='<div class="cartera-loading">Cargando información SBS…</div>';
    try{pending ||=app.api('/api/benchmark/cartera-bancos');const loaded=await pending;if(token!==request)return;data=loaded;}
    catch(error){if(token===request){pending=null;$('#workspace').innerHTML=`<div class="cartera-empty">${esc(error.message)}</div>`;}return;}
  }
  if(token!==request||!/^#benchmark\/(cartera|tarjetas|prestamos)(?:[/?]|$)/.test(location.hash))return;
  const route=location.hash.split('/')[1]?.split('?')[0];
  if(route==='tarjetas'||route==='prestamos')state.component=route;
  $('#workspace').innerHTML=renderPage(app);bind(app);
}
function invalidate(){request++;data=null;pending=null;}
window.IASPECarteraConsumo={render,invalidate};
})();
