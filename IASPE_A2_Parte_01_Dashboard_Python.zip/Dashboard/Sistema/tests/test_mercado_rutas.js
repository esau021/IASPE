'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.join(__dirname,'..');const context={window:{},Math,Number,Object,Intl,Map,Set};vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'mercado-rutas.js'),'utf8'),context);
const api=context.window.IASPEMercadoRutas;
assert(api,'API de rutas ausente');
const row=(date,market,share=4.6)=>({date,market,falabella:market*share/100,share});
const make=(id,obs)=>({id,rows:obs});
const base=[row('2025-09',76748.9061563),row('2025-12',78566.00475763),row('2026-09',89790.83665141)];
const tc=[row('2025-09',18231.4432245),row('2025-12',18873.1948807),row('2026-09',20782.56627141)];
const nr=[row('2025-09',58517.4629318),row('2025-12',59692.80987693),row('2026-09',69008.27038)];
const catalog={products:[make('consumo_comparable',base),make('tarjetas_saldo',tc),make('prestamos_no_revolventes',nr)]};
const byYear=(base,end)=>Array.from({length:5},(_,i)=>({year:i+2026,value:base+(end-base)*i/4,status:i?'forecast':'assumed'}));
const models={
 '05':{annual:byYear(1992.789,2248)},'06':{annual:byYear(2106.562,2914.11)},'07':{annual:byYear(4099.351,5162.11)},
 '48':{annual:byYear(91908.44758014359,121638.24)},'01':{annual:byYear(7497814,8471000)},'04':{annual:byYear(1488008,1600000)}
};
const macros={pbi:{'2026':2.7,'2027':2.3,'2028':2.9,'2029':3.1,'2030':3.1},desempleo:{'2026':5.8,'2027':5.8,'2028':5.8,'2029':5.7,'2030':5.7},tpm:{'2026':4.5,'2027':4.5,'2028':4.5,'2029':4.75,'2030':4.75}};
const app={state:{data:{macros:Object.entries(macros).map(([id,values])=>({id,values}))},changes:{}},model:id=>models[id]};
const original=JSON.stringify({models,macros});
const comp=api.componentSeries(app,catalog);
assert(comp&&comp.tarjetas&&comp.prestamos,'Falta senda macro de componentes');
assert(Math.abs(comp.tarjetas[2026]+comp.prestamos[2026]-91908.44758014359)<.02,'El cierre de componentes no concilia con M48');
for(let y=2027;y<=2030;y++)assert(comp.tarjetas[y]>comp.tarjetas[y-1]&&comp.prestamos[y]>comp.prestamos[y-1]);
const basePath=api.series(app,catalog,'consumo_comparable','m48');
const altPath=api.series(app,catalog,'consumo_comparable','componentes');
const cardPath=api.series(app,catalog,'tarjetas_saldo');
const nrPath=api.series(app,catalog,'prestamos_no_revolventes');
const cardsNumber=api.series(app,catalog,'tarjetas_numero');
for(const rows of [basePath,altPath,cardPath,nrPath,cardsNumber])assert.equal(rows.length,5);
assert.equal(basePath[4].market,121638.24,'Mercado M48 debe permanecer igual');
assert.equal(basePath[4].falabella,altPath[4].falabella,'Banco Falabella no cambia con la elección de mercado');
assert.notEqual(basePath[4].market,altPath[4].market,'El mercado alternativo debe producir otro valor');
assert(Math.abs(altPath[4].market-cardPath[4].market-nrPath[4].market)<1e-7,'Mercado total debe igualar la suma de componentes');
assert.equal(JSON.stringify({models,macros}),original,'No modificar modelos ni supuestos');
const design=api.yearCards(app,catalog,'consumo_comparable','componentes',2030);
for(const phrase of ['01 · FALABELLA','02 · MERCADO','03 · PARTICIPACIÓN','2 regresiones'])assert(design.includes(phrase),phrase);
assert(!design.includes('Ruta alternativa')&&!design.includes('RUTA A')&&!design.includes('RUTA B'),'No incluir rutas duplicadas en Participación');
assert.equal(typeof api.forCartera,'undefined','La ficha independiente de rutas debe desaparecer');
// Solo modificar macro no cambia ni M07 ni M48: altera únicamente mercado alternativo.
const change={...app,state:{...app.state,changes:{pbi:{'2026':4.2}}}};
assert.notEqual(api.series(change,catalog,'consumo_comparable','componentes')[1].market,altPath[1].market);
assert.equal(api.series(change,catalog,'consumo_comparable','m48')[1].market,basePath[1].market);
// Supuestos ausentes o cierre incompatible bloquean la alternativa, no inventan un mercado.
const missing={...app,state:{...app.state,data:{macros:[]},changes:{}}};
assert.equal(api.series(missing,catalog,'consumo_comparable','componentes').length,0);
const badModels={...models,'48':{annual:byYear(100000,121638.24)}};
const bad={...app,model:id=>badModels[id]};
assert.equal(api.series(bad,catalog,'consumo_comparable','componentes').length,0);
assert.equal(api.series(bad,catalog,'consumo_comparable','m48').length,5);
assert.equal(api.series(app,catalog,'depositos_ahorro').length,0,'No inventar proyecciones de depósitos');
console.log('Mercado: dos regresores, cierre SBS conciliado, mercado alternativo, escenario macro, sin rutas duplicadas, salvaguardas y ausencia de mutaciones: OK');
