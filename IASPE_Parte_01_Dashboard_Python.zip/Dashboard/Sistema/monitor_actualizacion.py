"""Ensambla estados persistidos; no consulta portales, estima ni publica datos."""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1] / 'IASPE'
MONTH = re.compile(r'^\d{4}-(?:0[1-9]|1[0-2])$')
YEAR = re.compile(r'^\d{4}$')
MONTH_NAMES = ('Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
               'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre')
REPORT_MODELS = {'B-2363': ('01', '02', '04'), 'B-2389': ('05', '06'),
                 'PN09406SM': ('03',), 'PN07845NM': ('13',),
                 'PN07847NM': ('14',), 'PN07814NM': ('15',)}


def _number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _period(value):
    text = str(value or '')
    return text[:7] if MONTH.fullmatch(text[:7]) else text if YEAR.fullmatch(text) else None


def _latest(values):
    return max((value for value in values if value), default=None)


def _state(row):
    if not isinstance(row, dict) or not _number(row.get('value')):
        return 'missing'
    return 'observed' if row.get('status') == 'observed' else 'estimated' if row.get('status') in ('assumed', 'forecast') else 'missing'


def _flat(data):
    result = {}
    for identifier, periods in (data or {}).items():
        if identifier == 'sbs_contable':
            for model, years in periods.items():
                for period, detail in years.items():
                    result[(model, str(period))] = detail
        elif isinstance(periods, dict):
            for period, detail in periods.items():
                result[(identifier, str(period))] = detail
    return result


def _combined(automatic, manual):
    # Mismo criterio del motor: una observación manual prevalece sobre SBS.
    result = deepcopy(automatic or {})
    for identifier, periods in (manual or {}).items():
        if isinstance(periods, dict):
            result.setdefault(identifier, {}).update(periods)
    return result


def _observed_periods(model, applied):
    result = []
    for frequency in ('monthly', 'annual'):
        for row in model.get(frequency, []):
            if _state(row) == 'observed':
                period = _period(row.get('date')) if frequency == 'monthly' else _period(row.get('year'))
                if period:
                    result.append(period)
    for period, value in applied.get(model['id'], {}).items():
        if _number(value) and _period(period):
            result.append(_period(period))
        elif isinstance(value, dict) and _period(value.get('sourceMonth')):
            result.append(_period(value['sourceMonth']))
    raw = applied.get('sbs_contable', {}).get(model['id'], {})
    for detail in raw.values():
        if isinstance(detail, dict) and _period(detail.get('sourceMonth')):
            result.append(_period(detail['sourceMonth']))
    return result


def _successful(report):
    return bool(isinstance(report, dict) and report.get('ok') is True
                and report.get('status') in ('completo', 'success', 'published'))


def _last_success(attempt, history, saved_success=None):
    candidates = []
    if _successful(attempt) and attempt.get('generatedAt'):
        candidates.append(dict(attempt, date=attempt['generatedAt'], basis='ultimo_recalculo'))
    if _successful(saved_success) and saved_success.get('generatedAt'):
        candidates.append(dict(saved_success, date=saved_success['generatedAt'], basis='ultimo_recalculo_exitoso'))
    for publication in history.get('publications', []):
        if (not isinstance(publication, dict) or publication.get('ok') is not True
                or publication.get('status') != 'published'):
            continue
        timestamp = publication.get('publishedAt')
        if timestamp:
            candidates.append({'date': timestamp, 'generatedAt': timestamp,
                               'basis': 'historial_pronosticos.publications', **publication})
    return max(candidates, key=lambda item: item['date'], default=None)


def _closing(model, applied):
    row = next((r for r in model.get('annual', []) if str(r.get('year')) == '2026'), None)
    raw = applied.get('sbs_contable', {}).get(model['id'], {}).get('2026',
                  applied.get(model['id'], {}).get('2026', {}))
    raw = raw if isinstance(raw, dict) else {}
    residual = model['id'] == '17_bancos' and ('residual' in model.get('method', '').lower()
                                              or 'conciliación' in model.get('method', '').lower())
    if residual:
        method, origin = model['method'], 'model.method'
    elif row and row.get('method'):
        method, origin = row['method'], 'annual2026.method'
    elif raw.get('method'):
        method, origin = raw['method'], 'fuentes_aplicadas.sbs_contable'
    elif model.get('closingRule'):
        method, origin = model['closingRule'], 'model.closingRule'
    else:
        method, origin = model.get('method'), 'model.method' if model.get('method') else None
    notes = []
    if origin == 'model.method':
        notes.append('Método registrado del modelo; no hay una regla de cierre separada en los metadatos.')
    if row and row.get('conditionSource'):
        notes.append(str(row['conditionSource']))
    return {'year': 2026, 'status': _state(row), 'underlyingStatus': row.get('status') if row else None,
            'value': row.get('value') if row and _number(row.get('value')) else None,
            'method': method, 'methodSource': origin, 'sourceMonth': raw.get('sourceMonth') or (row or {}).get('sourceMonth'),
            'sourceMethod': raw.get('method'), 'modelMethod': model.get('method'),
            'updateRule': model.get('updateRule'), 'notes': notes}


def _model_entry(model, applied, changes, pending_ids, failed_attempt, catalogue=None):
    identifier = model['id']
    monthly = model.get('monthly') or []
    notes = list(model.get('issues') or []) + list(model.get('warnings') or [])
    slots = None
    if monthly:
        existing = {}
        for row in monthly:
            month = _period(row.get('date'))
            if month and MONTH.fullmatch(month):
                existing[month] = row
        slots = []
        for number, name in enumerate(MONTH_NAMES, 1):
            month = f'2026-{number:02d}'
            row = deepcopy(existing.get(month, {}))
            active = applied.get(identifier, {}).get(month)
            if _number(active):
                row = {'value': active, 'status': 'observed', 'basis': 'appliedObservation'}
            state = _state(row)
            pending = [change for change in changes if change['model'] == identifier and change['period'] == month]
            slots.append({'period': month, 'name': name, 'status': state,
                          'underlyingStatus': row.get('status'),
                          'value': row.get('value') if state != 'missing' else None,
                          'basis': row.get('basis', 'persistedModel' if row else None),
                          'pending': bool(pending), 'pendingObservations': pending})
    direct = [change for change in changes if change['model'] == identifier]
    dependencies = [str(value.get('id')) if isinstance(value, dict) else str(value)
                    for value in model.get('dependencies', [])]
    waiting = [value for value in dependencies if value in pending_ids]
    status = ('error' if model.get('status') in ('error', 'needs_input') else
              'pending' if identifier in pending_ids else 'valid_previous' if failed_attempt else 'current')
    if failed_attempt:
        notes.append('El último intento no publicó resultados; se muestra la versión persistida.')
    closing = _closing(model, applied)
    # Referencias históricas de todos los modelos monitorizados. La vista de
    # ejemplo usa exactamente el mismo snapshot que el motor y no otra API.
    monthly2025 = None
    if monthly:
        monthly2025 = [
            {'period': f'2025-{month:02d}', 'value': row.get('value'), 'status': _state(row)}
            for month in range(1, 13)
            for row in monthly
            if _period(row.get('date')) == f'2025-{month:02d}'
        ]
    annual2025 = next((row for row in model.get('annual', []) if str(row.get('year')) == '2025'), None)
    components2026 = []
    for dependency in dependencies:
        source = (catalogue or {}).get(dependency)
        if not source:
            continue
        row = next((item for item in source.get('annual', []) if str(item.get('year')) == '2026'), None)
        if row and _number(row.get('value')):
            sign = -1 if identifier == '18' and dependency in ('18_gastos_div', '18_otros_gastos') else 1
            components2026.append({'id': dependency, 'name': source.get('name', dependency),
                                   'value': row['value'], 'sign': sign})
    return {'id': identifier, 'name': model.get('name', identifier), 'unit': model.get('unit'),
            'parentId': identifier.split('_', 1)[0] if '_' in identifier else None,
            'isComponent': '_' in identifier, 'group': model.get('group'), 'role': model.get('role'),
            'frequency': 'monthly' if monthly else 'annual', 'registryFrequency': model.get('frequency'),
            'status': status, 'engineStatus': model.get('status'),
            'lastObservedPeriod': _latest(_observed_periods(model, {})),
            'lastIncorporatedPeriod': _latest(_observed_periods(model, applied)),
            'pendingObservations': len(direct), 'pendingDetails': direct, 'pendingDependencies': waiting,
            'monthly2026': slots, 'monthly2025': monthly2025,
            'annual2025': {'value': annual2025.get('value'), 'status': _state(annual2025)} if annual2025 else None,
            'components2026': components2026,
            'annual2026': {key: closing[key] for key in ('year', 'status', 'underlyingStatus', 'value')},
            'closing2026': closing, 'dependencies': dependencies,
            'sourceFiles': model.get('sourceFiles', []), 'notes': notes}


def _report_entry(source_id, code, cached, ledger, downloaded_fallback, applied_period, checked_at, failed):
    verified = cached.get('status') in ('al_dia', 'nuevo')
    cached_official = cached.get('remotePeriod') or (cached.get('localPeriod') if cached.get('status') == 'al_dia' else None)
    official = _latest([_period(ledger.get('latestPublished')), _period(cached_official) if verified else None])
    downloaded = _period(ledger.get('latestProcessed')) or _period(cached.get('localPeriod')) or downloaded_fallback
    notes = []
    if not official:
        notes.append('No hay un período oficial verificado en los registros consultables.')
    if failed:
        notes.append('Última consulta fallida; los períodos corresponden a la última base válida o verificación conservada.')
    return {'code': code, 'name': cached.get('name', code), 'officialPeriod': official,
            'downloadedPeriod': downloaded, 'appliedPeriod': applied_period,
            'verification': 'last_verified' if official and failed else 'verified' if official else 'not_verified',
            'checkedAt': checked_at, 'status': 'error' if failed else cached.get('status', 'verified' if official else 'no_verificado'),
            'url': ledger.get('url'), 'details': ledger.get('discovery'), 'notes': notes}


def assemble(models, *, update_status, published_status, ledgers, downloaded, applied,
             manual=None, manual_applied=None, last_recalculation=None, last_successful_recalculation=None, history=None,
             source_names=None, source_components=None, link_status=None, operation=None, notes=None):
    """Función pura: permite comprobar estados incrementales sin tocar el sistema."""
    models = {str(k): dict(value, id=str(k)) for k, value in models.items()}
    history = history or {}
    source_components = deepcopy(source_components or {})
    source_names = source_names or {}
    links = (link_status or {}).get('fuentes', {})
    for source_id, link in links.items():
        direct = [key for key in link.get('modelos', []) if key in models]
        source_components[source_id] = list(dict.fromkeys([*source_components.get(source_id, ()), *direct]))
    before = _flat(_combined(applied, manual_applied))
    after = _flat(_combined(downloaded, manual))
    changes = [{'model': key[0], 'period': key[1], 'previous': before.get(key), 'current': value}
               for key, value in after.items() if before.get(key) != value]
    personnel_link = links.get('personal_banca', {})
    personnel_enabled = '19_personal' in personnel_link.get('modelos', []) and '19_personal' in models
    if personnel_enabled:
        for change in changes:
            if change['model'] == 'trabajadores_falabella':
                change.update(model='19_personal', inputName='trabajadores_falabella',
                              inputUnit='personas', inputKind='auxiliary', sourceId='personal_banca')
    changes.sort(key=lambda item: (item['model'], item['period']))
    active = _combined(applied, manual_applied)
    pending_ids = {entry['model'] for entry in changes}
    for source_id, link in links.items():
        if set(source_components.get(source_id, ())) & pending_ids:
            pending_ids.update(key for key in link.get('derivados', []) if key in models)
    # Dependencias ya registradas: sólo propaga el estado pendiente, nunca valores.
    for _ in models:
        affected = {key for key, model in models.items()
                    if any((value.get('id') if isinstance(value, dict) else value) in pending_ids
                           for value in model.get('dependencies', []))}
        if affected <= pending_ids:
            break
        pending_ids |= affected
    failed_attempt = bool(last_recalculation and not _successful(last_recalculation))
    entries = [_model_entry(models[key], active, changes, pending_ids, failed_attempt, catalogue=models) for key in sorted(models)]
    observed_by_id = {entry['id']: entry['lastIncorporatedPeriod'] for entry in entries}
    cached_sources = {source['id']: source for source in published_status.get('sources', [])}
    saved_sources = update_status.get('sources', {})
    identifiers = list(dict.fromkeys([*source_names, *cached_sources, *saved_sources, *ledgers, *links]))
    sources = []
    for identifier in identifiers:
        cached = cached_sources.get(identifier, {})
        saved = saved_sources.get(identifier, {})
        ledger = ledgers.get(identifier, {})
        download = saved.get('download') or ledger
        failed = saved.get('status') == 'error' or download.get('status') == 'error' or download.get('estado') == 'error'
        direct = [key for key in source_components.get(identifier, ()) if key in models]
        related = set(direct)
        related.update(key for key in links.get(identifier, {}).get('derivados', []) if key in models)
        for _ in models:
            children = {key for key, model in models.items()
                        if any((value.get('id') if isinstance(value, dict) else value) in related
                               for value in model.get('dependencies', []))}
            if children <= related:
                break
            related |= children
        applied_period = _latest(observed_by_id.get(key) for key in direct) if direct else None
        trace = links.get(identifier, {}).get('trazabilidad')
        auxiliary = []
        if identifier == 'personal_banca' and personnel_enabled:
            trace = trace if isinstance(trace, dict) else {}
            year = str(trace.get('mes_ultimo', ''))[:4]
            staff = active.get('trabajadores_falabella', {}).get(year)
            traced_close = trace.get('cierre')
            matched = _number(staff) and _number(traced_close) and abs(staff-traced_close) <= 1e-9
            applied_period = _period(trace.get('mes_ultimo')) if matched else None
            auxiliary = [{'id': 'trabajadores_falabella', 'modelId': '19_personal', 'unit': 'personas',
                          'valueApplied': staff if _number(staff) else None,
                          'sourcePeriodApplied': applied_period,
                          'annualStatus': 'observed' if trace.get('estado_cierre') == 'observado' and matched else 'estimated',
                          'definition': 'Insumo auxiliar de trabajadores; no es el gasto de personal.'}]
        pending = sum(change.get('sourceId') == identifier if change.get('sourceId') else
                      change['model'] in direct and identifier != 'personal_banca' for change in changes)
        fallback = _period(saved.get('validation', {}).get('latestPeriod') or saved.get('latestPeriod'))
        cached_reports = {item['code']: item for item in cached.get('reports', [])}
        downloaded_reports = download.get('reports', {})
        reports = []
        for code in dict.fromkeys([*cached_reports, *downloaded_reports]):
            report_models = REPORT_MODELS.get(code, direct if code == 'B-2201' else ())
            report_applied = _latest(observed_by_id.get(key) for key in report_models) if report_models else None
            if identifier == 'personal_banca' and code == 'B-2305':
                report_applied = applied_period
            reports.append(_report_entry(identifier, code, cached_reports.get(code, {}), downloaded_reports.get(code, {}),
                                         fallback, report_applied, download.get('checkedAt') or published_status.get('checkedAt'), failed))
        source_notes = list(download.get('errors') or []) + list(download.get('limitations') or [])
        if not direct:
            source_notes.append('Fuente de comparación: no tiene observaciones vinculadas directamente a los modelos.')
        if not reports:
            source_notes.append('No hay una verificación oficial por reporte disponible.')
        if auxiliary:
            source_notes.append('Personal banca aporta trabajadores como insumo auxiliar a M19; no se equipara su cantidad con gastos de personal.')
            if applied_period is None:
                source_notes.append('El mes de personal aplicado no puede acreditarse con la traza actual; no se atribuye el corte recién descargado.')
        official_period = _latest(item['officialPeriod'] for item in reports)
        downloaded_period = _latest([fallback, *[item['downloadedPeriod'] for item in reports]])
        sources.append({'id': identifier, 'name': source_names.get(identifier, cached.get('name', identifier)),
                        'status': 'error' if failed else saved.get('status', cached.get('status', 'no_verificado')),
                        'checkedAt': saved.get('checkedAt') or download.get('checkedAt') or published_status.get('checkedAt'),
                        'officialPeriod': official_period, 'downloadedPeriod': downloaded_period,
                        'downloadedPeriodBasis': 'Última base local validada o período conservado por el monitor existente',
                        'appliedPeriod': applied_period, 'feedsModels': bool(direct), 'directModelIds': direct,
                        'modelIds': sorted(related), 'pendingObservations': pending, 'reports': reports,
                        'auxiliaryInputs': auxiliary, 'linkTrace': trace,
                        'mixedOfficialPeriods': len({r['officialPeriod'] for r in reports if r['officialPeriod']}) > 1,
                        'detail': saved.get('detail') or download.get('detail'), 'notes': source_notes})
    successful = _last_success(last_recalculation, history, last_successful_recalculation)
    result = {'readOnly': True, 'schemaVersion': 1, 'operation': operation or update_status.get('operation', {'running': False}),
              'sources': sources, 'models': entries,
              'summary': {'modelCount': sum(not entry['isComponent'] for entry in entries), 'seriesCount': len(entries),
                          'pendingObservations': len(changes), 'pendingModels': len(set(models) & pending_ids),
                          'lastSuccessfulRecalculation': successful['date'] if successful else None},
              'pending': {'pending': bool(changes), 'observations': len(changes), 'models': sorted(set(models) & pending_ids), 'details': changes},
              'lastRecalculation': last_recalculation, 'lastSuccessfulRecalculation': successful,
              'history': {'versionsCount': len(history.get('versions', [])), 'publicationsCount': len(history.get('publications', []))},
              'notes': list(notes or []),
              'actions': {'observationsRoute': '#datos', 'sourceUpdate': 'existingSbsUpdater', 'recalculation': 'existingModelsRecalculation'}}
    if failed_attempt:
        result['notes'].append('El último intento de recálculo no fue publicado; permanecen vigentes los resultados persistidos.')
    if not successful:
        result['notes'].append('No hay una fecha de recálculo exitoso documentada en los registros disponibles.')
    canonical = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    result['revision'] = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
    result['generatedAt'] = datetime.now(timezone.utc).isoformat()
    return result



def _attach_readonly_closing_traces(result):
    """Enriquece el Monitor con operandos SBS sin recalcular modelos.

    La fuente es el mismo panel de EEFF que utiliza el actualizador.
    Solo se muestra una traza numérica si concilia con el cierre publicado.
    """
    import gzip
    import statistics
    try:
        panel_path = ROOT / 'Scraper/EEFF_Benchmark/output/panel_eeff_16_bancos.json.gz'
        with gzip.open(panel_path, 'rt', encoding='utf-8') as stream:
            series = json.load(stream)['series']
    except (OSError, ValueError, KeyError):
        return
    accounts = {
        '12': [f'er_acumulado:{v}' for v in (112, 113, 114, 115, 116, 117)],
        '16': [f'er_acumulado:{v}' for v in (102, 103, 104, 105)],
        '24': ['er_acumulado:153'],
        '30': ['balance:090'],
        '32': ['balance:032'],
    }
    def amount(key, period):
        vals = [series.get(code, {}).get('05', {}).get(period) for code in accounts[key]]
        return sum(vals) if vals and all(_number(v) for v in vals) else None
    for model in result.get('models', []):
        key = model.get('id')
        if key not in accounts:
            continue
        close = model.get('closing2026', {})
        period = close.get('sourceMonth')
        if not isinstance(period, str) or not MONTH.fullmatch(period) or not period.startswith('2026-'):
            continue
        month = int(period[-2:])
        current = amount(key, period)
        if current is None or month >= 12:
            continue
        trace = {'sourceMonth': period, 'current': current}
        if key in ('12', '16'):
            previous = amount(key, f'2026-{month-1:02d}') if month>1 else 0
            if previous is None:
                continue
            delta = current-previous
            calculated = current+(12-month)*delta
            trace.update(kind='last_flow', previous=previous, monthlyFlow=delta,
                         remaining=12-month, adjustment=(12-month)*delta)
        elif key=='24':
            samples=[]
            for year in range(2022,2026):
                comparable = amount(key,f'{year}-{month:02d}')
                december = amount(key,f'{year}-12')
                if comparable is None or december is None or abs(comparable)<1e-10:
                    samples=[];break
                samples.append({'year':year,'comparable':comparable,'december':december,
                                'stat':december/comparable})
            if len(samples)!=4:
                continue
            statistic = statistics.median(x['stat'] for x in samples)
            calculated = current*statistic
            trace.update(kind='median_factor',history=samples,statistic=statistic)
        else:
            samples=[]
            for year in range(2021,2026):
                comparable=amount(key,f'{year}-{month:02d}')
                december=amount(key,f'{year}-12')
                if comparable is None or december is None:
                    samples=[];break
                samples.append({'year':year,'comparable':comparable,'december':december,
                                'stat':december-comparable})
            if len(samples)!=5:
                continue
            statistic = statistics.mean(x['stat'] for x in samples) if key=='30' else statistics.median(x['stat'] for x in samples)
            calculated = current+statistic
            trace.update(kind='mean_difference' if key=='30' else 'median_difference',
                         history=samples, statistic=statistic)
        stored=close.get('value')
        # Las trazas solo se publican si usan exactamente la misma fecha y regla
        # del cierre persistido. Nunca se sustituye el valor del motor.
        if _number(stored) and math.isclose(calculated, stored, rel_tol=0, abs_tol=0.02):
            trace['calculated']=calculated
            model['closingTrace']=trace


def snapshot(*, update_status=None, models=None):
    """Lee el estado del proceso existente. Nunca usar refresh=True en este GET.

    El servidor toma MANAGER.snapshot() antes de motor.LOCK/DATA_LOCK y lo pasa
    como argumento para conservar el orden de bloqueo del actualizador.
    """
    import actualizador_sbs
    import monitor_fuentes
    import motor
    notes = []
    def read(path, default):
        try:
            return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else deepcopy(default)
        except (OSError, ValueError):
            notes.append(f'No se pudo leer el estado persistido {path.name}.')
            return deepcopy(default)
    output = ROOT / 'Scraper/Actualizacion/output'
    if update_status is None:
        update_status = read(output / 'ultima_ejecucion.json', {})
    if models is None:
        models, _ = motor.load_base()
    names = dict(actualizador_sbs.SOURCES)
    ledger_paths = sorted(output.glob('descarga_*.json'))
    ledgers = {path.stem.removeprefix('descarga_'): read(path, {}) for path in ledger_paths}
    published = monitor_fuentes.MANAGER.snapshot(refresh=False)
    result = assemble(models, update_status=update_status, published_status=published, ledgers=ledgers,
                    downloaded=read(output / 'observaciones_modelos.json', {}),
                    applied=motor.read_state('fuentes_aplicadas.json', motor.read_state('fuentes_iniciales.json', {})),
                    manual=motor.read_state('observaciones.json', {}),
                    manual_applied=motor.read_state('observaciones_aplicadas.json', motor.read_state('observaciones.json', {})),
                    last_recalculation=motor.read_state('ultimo_recalculo.json', None),
                    last_successful_recalculation=motor.read_state('ultimo_recalculo_exitoso.json', None),
                    history=motor.read_state('historial_pronosticos.json', {}),
                    source_names=names, source_components=actualizador_sbs.SOURCE_COMPONENTS,
                    link_status=read(output / 'vinculacion_modelos.json', {}),
                    operation=actualizador_sbs.operation_status(), notes=notes)
    _attach_readonly_closing_traces(result)
    # El token de revisión incluye también la nueva trazabilidad de visualización.
    canonical = {key: value for key, value in result.items() if key not in ('revision', 'generatedAt')}
    result['revision'] = hashlib.sha256(json.dumps(canonical, ensure_ascii=False, sort_keys=True,
                           separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()
    return result
