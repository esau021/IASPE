"""API real / importación aislada. No ejecuta funciones financieras ni accede a red oficial."""
from __future__ import annotations
import base64
import copy
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
from pathlib import Path
import sys
import threading
import types
import zipfile
from urllib.request import Request, urlopen
from urllib.error import HTTPError

import pytest

SYSTEM = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SYSTEM))
import proyecciones_externas as external

FILENAMES = [
    'nota-de-estudios-77-2026.pdf',
    'reporte-de-inflacion-diciembre-2024-sintesis.pdf',
    'reporte-de-inflacion-diciembre-2025-sintesis.pdf',
    'reporte-de-inflacion-setiembre-2026-sintesis (1).pdf',
]


def pdf_path(filename):
    roots = [Path(os.environ['BCRP_PDF_DIR'])] if os.environ.get('BCRP_PDF_DIR') else []
    roots += [SYSTEM / 'tests' / 'pdfs', Path.home() / 'Downloads']
    for root in roots:
        if (root / filename).is_file():
            return root / filename
    raise AssertionError(f'Falta el PDF real requerido: {filename}. Configure BCRP_PDF_DIR.')


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    for name, value in {
        'DIR': tmp_path, 'STATE': tmp_path / 'historial.json',
        'DOCS': tmp_path / 'documentos', 'HTTP_CACHE': tmp_path / 'http_cache.json',
        'BASE_REVISIONS': tmp_path / 'referencias_ausentes.json',
    }.items():
        monkeypatch.setattr(external, name, value)
    return external


def import_pdf(api, filename):
    raw = pdf_path(filename).read_bytes()
    return api.import_document('auto', filename=filename, encoded=base64.b64encode(raw).decode('ascii'))


@pytest.mark.parametrize('filename', FILENAMES)
def test_exact_real_pdf_saved_and_visible_immediately(isolated, filename):
    result = import_pdf(isolated, filename)
    assert result['added'] > 0
    assert result['document']['extractor_verified'] is True
    assert result['state']['current_records']
    stored, _ = isolated.get_document(result['document']['id'])
    assert stored == pdf_path(filename).read_bytes()
    assert hashlib.sha256(stored).hexdigest() == result['document']['hash']
    snapshot = isolated.snapshot()
    assert snapshot['current_records'] == result['state']['current_records']
    for row in snapshot['current_records']:
        assert row['document_hash'] == result['document']['hash']
        assert row['page'] >= 1 and len(row['bbox']) == 4
    count = len(snapshot['records'])
    repeated = import_pdf(isolated, filename)
    assert repeated['added'] == 0
    assert len(repeated['state']['records']) == count
    assert len(list(isolated.DOCS.glob('*.pdf'))) == 1


def test_survey_latest_columns_are_only_october_30(isolated):
    result = import_pdf(isolated, FILENAMES[0])
    rows = result['state']['current_records']
    assert len(rows) == 27
    assert {r['survey_date'] for r in rows} == {'2026-10-30'}
    assert {r['group'] for r in rows} == {'Analistas económicos', 'Sistema financiero', 'Empresas no financieras'}
    assert {r['variable'] for r in rows} == {'pbi', 'inflacion', 'tc_cierre'}
    assert len(result['state']['survey_history']) == 81


def test_report_latest_values_and_june_revisions_are_distinct(isolated):
    result = import_pdf(isolated, FILENAMES[3])
    current = {(r['variable'], r['year']): r['value'] for r in result['state']['current_records']}
    assert current == {('pbi', '2026'): 3.2, ('pbi', '2027'): 3.0,
                       ('inflacion', '2026'): 4.2, ('inflacion', '2027'): 2.0}
    history = {(r.get('revision'), r['variable'], r['year']): r['value']
               for r in result['state']['records'] if r.get('kind') == 'anual'}
    assert history[('2026-06', 'pbi', '2026')] == 3.4
    assert history[('2026-06', 'pbi', '2027')] == 3.2
    assert history[('2026-06', 'inflacion', '2026')] == 3.8
    assert history[('2026-06', 'inflacion', '2027')] == 2.0
    assert all(r.get('revision') == '2026-09' for r in result['state']['current_records'])
    assert all(r['year'] != '2025' for r in result['state']['current_records'])


def test_old_report_import_does_not_replace_new_current(isolated):
    import_pdf(isolated, FILENAMES[3])
    result = import_pdf(isolated, FILENAMES[2])
    current = [r for r in result['state']['current_records'] if r['year'] in {'2026', '2027'}]
    assert len(current) == 4
    assert all(r['revision'] == '2026-09' for r in current)
    assert len({_record_identity(r) for r in result['state']['records']}) == len(result['state']['records'])


def _record_identity(row):
    return (row['source'], row['edition'], row['variable'], row['year'], row.get('group', ''))


def test_reproduced_review_is_one_figure_with_multiple_citations(isolated):
    row = {'source': 'BCRP · Reporte de Inflación', 'edition': '2026-06', 'revision': '2026-06',
           'document_edition': '2026-06', 'variable': 'pbi', 'year': '2027', 'value': 3.2,
           'kind': 'anual', 'group': '', 'document_id': 'june', 'document_hash': 'june-hash', 'page': 6}
    state = copy.deepcopy(isolated.DEFAULT)
    assert isolated._merge(state, [row], []) == 1
    reproduced = dict(row, document_id='september', document_hash='september-hash', document_edition='2026-09')
    assert isolated._merge(state, [reproduced], []) == 0
    assert len(state['records']) == 1
    assert {e['document_id'] for e in state['records'][0]['evidence']} == {'june', 'september'}
    with pytest.raises(ValueError, match='misma revisión'):
        isolated._merge(state, [dict(reproduced, value=3.3)], [])


@pytest.mark.parametrize('after_write', [False, True])
def test_commit_failure_rolls_back_records_and_document(isolated, monkeypatch, after_write):
    import_pdf(isolated, FILENAMES[3])
    before = {p.relative_to(isolated.DIR): p.read_bytes() for p in isolated.DIR.rglob('*') if p.is_file()}
    save = isolated._save
    def broken(state):
        if after_write:
            save(state)
        raise OSError('Fallo de escritura inyectado')
    monkeypatch.setattr(isolated, '_save', broken)
    with pytest.raises(OSError, match='inyectado'):
        import_pdf(isolated, FILENAMES[0])
    after = {p.relative_to(isolated.DIR): p.read_bytes() for p in isolated.DIR.rglob('*') if p.is_file()}
    assert after == before


def test_failed_first_import_leaves_no_partial_records_or_pdf(isolated, monkeypatch):
    def broken(state):
        raise OSError('Sin espacio')
    monkeypatch.setattr(isolated, '_save', broken)
    with pytest.raises(OSError):
        import_pdf(isolated, FILENAMES[3])
    assert not isolated.STATE.exists()
    assert not list(isolated.DOCS.glob('*'))


def test_invalid_pdf_and_wrong_source_leave_state_unchanged(isolated):
    import_pdf(isolated, FILENAMES[3])
    before = isolated.STATE.read_bytes()
    for raw, source in [(b'%PDF-incompleto', 'auto'),
                        (pdf_path(FILENAMES[0]).read_bytes(), 'MEF · MMM/IAPM')]:
        with pytest.raises(ValueError):
            isolated.import_document(source, filename='documento.pdf', encoded=base64.b64encode(raw).decode())
        assert isolated.STATE.read_bytes() == before
    assert len(list(isolated.DOCS.glob('*.pdf'))) == 1


@pytest.fixture
def http_api(isolated, monkeypatch):
    # El Handler y la ruta son los reales. Se aíslan las dependencias financieras
    # ajenas a esta API para demostrar que ninguna participa en una importación.
    names = ['motor', 'benchmark', 'benchmark_eeff', 'cartera_consumo_bancos', 'ratios_sbs',
             'control_iaspe', 'personal_sbs', 'actualizador_sbs', 'monitor_fuentes', 'normativa_sbs']
    for name in names:
        module = types.ModuleType(name)
        if name == 'motor':
            module.clean = lambda data: data
        monkeypatch.setitem(sys.modules, name, module)
    spec = importlib.util.spec_from_file_location('servidor_bcrp_api_test', SYSTEM / 'servidor.py')
    server_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(server_module)
    server = server_module.Server(('127.0.0.1', 0), server_module.Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f'http://127.0.0.1:{server.server_address[1]}'
    server.shutdown()
    server.server_close()
    thread.join(timeout=3)


def test_http_import_updates_forecasts_and_serves_saved_document(http_api, isolated):
    filename = FILENAMES[3]
    raw = pdf_path(filename).read_bytes()
    data = {'source': 'auto', 'filename': filename, 'content': base64.b64encode(raw).decode()}
    request = Request(http_api + '/api/macro-external/preview', data=json.dumps(data).encode(),
                      headers={'Content-Type': 'application/json'}, method='POST')
    with urlopen(request, timeout=30) as response:
        assert response.status == 200
        preview = json.load(response)
    assert preview['records'] and preview['changes'] > 0
    assert not isolated.STATE.exists()  # El análisis nunca modifica el historial.
    request = Request(http_api + '/api/macro-external/confirm',
                      data=json.dumps({'token': preview['token']}).encode(),
                      headers={'Content-Type': 'application/json'}, method='POST')
    with urlopen(request, timeout=30) as response:
        assert response.status == 200
        result = json.load(response)
    with urlopen(http_api + '/api/macro-external/status', timeout=10) as response:
        status = json.load(response)
    assert status['current_records'] == result['state']['current_records']
    assert len(status['current_records']) == 4
    with urlopen(http_api + '/api/macro-external/file?id=' + result['document']['id']) as response:
        assert response.read() == raw
    script = (SYSTEM / 'proyecciones-externas.js').read_text(encoding='utf8')
    assert 'state=obj.state' in script
    assert '/api/macro-external/preview' in script and '/api/macro-external/confirm' in script


def test_http_failed_import_is_transactional(http_api, isolated):
    data = {'source': 'auto', 'filename': 'incompleto.pdf',
            'content': base64.b64encode(b'%PDF-incompleto').decode()}
    request = Request(http_api + '/api/macro-external/preview', data=json.dumps(data).encode(),
                      headers={'Content-Type': 'application/json'}, method='POST')
    with pytest.raises(HTTPError) as error:
        urlopen(request, timeout=10)
    assert error.value.code == 422
    assert not isolated.STATE.exists()
    assert not list(isolated.DOCS.glob('*'))


def test_http_direct_import_requires_preview(http_api):
    request = Request(http_api + '/api/macro-external/import', data=b'{}',
                      headers={'Content-Type': 'application/json'}, method='POST')
    with pytest.raises(HTTPError) as error:
        urlopen(request, timeout=10)
    assert error.value.code == 409


def test_imports_against_actual_v195_history_preserve_existing_sources(isolated):
    # Copias temporales de la base exacta incluida en el ZIP; jamás se edita la base entregada.
    archive = Path(os.environ.get('BCRP_V195_ZIP', str(Path.home() / 'Downloads' / 'IASPE_Dashboard_Completo_20261119_v1.9.5.zip')))
    assert archive.is_file(), 'Falta el ZIP v1.9.5 original; configure BCRP_V195_ZIP'
    prefix = 'Dashboard/Sistema/data/proyecciones_externas/'
    with zipfile.ZipFile(archive) as bundle:
        isolated.STATE.write_bytes(bundle.read(prefix + 'historial.json'))
        isolated.BASE_REVISIONS.write_bytes(bundle.read(prefix + 'revisiones_bcrp_base.json'))
        isolated.DOCS.mkdir()
        for entry in bundle.infolist():
            if entry.filename.startswith(prefix + 'documentos/') and not entry.is_dir():
                (isolated.DOCS / Path(entry.filename).name).write_bytes(bundle.read(entry))
    initial = isolated._load()
    other_sources = [r for r in initial['records'] if not r['source'].startswith('BCRP')]
    existing_file = next(e['file'] for e in initial['editions'] if e.get('source') == 'BCRP · Reporte de Inflación' and e.get('file'))
    baseline_file_count = len(list(isolated.DOCS.glob('*.pdf')))
    september = import_pdf(isolated, FILENAMES[3])
    assert september['document']['file'] == existing_file
    assert len(list(isolated.DOCS.glob('*.pdf'))) == baseline_file_count
    for filename in FILENAMES[:3]:
        import_pdf(isolated, filename)
    state = isolated.snapshot()
    assert [r for r in state['records'] if not r['source'].startswith('BCRP')] == other_sources
    ri = [r for r in state['records'] if r['source'] == 'BCRP · Reporte de Inflación']
    assert len({isolated._record_key(r) for r in ri}) == len(ri)
    current = {(r['variable'], r['year']): r['value'] for r in state['current_records']
               if r['source'] == 'BCRP · Reporte de Inflación' and r['year'] in {'2026', '2027'}}
    assert current == {('pbi', '2026'): 3.2, ('pbi', '2027'): 3.0,
                       ('inflacion', '2026'): 4.2, ('inflacion', '2027'): 2.0}
    survey = [r for r in state['current_records'] if r['source'] == 'BCRP · encuesta anual']
    assert len(survey) == 27
    assert all(r['survey_date'] == '2026-10-30' for r in survey)


def test_dashboard_selection_keeps_latest_report_per_year():
    executable = shutil.which('node') or os.environ.get('NODE_EXE')
    assert executable, 'Node.js requerido para comprobar la selección de datos del Dashboard'
    result = subprocess.run([executable, str(SYSTEM / 'tests' / 'test_bcrp_forecast_selection.js')],
                            text=True, capture_output=True, check=False)
    assert result.returncode == 0, result.stdout + result.stderr
