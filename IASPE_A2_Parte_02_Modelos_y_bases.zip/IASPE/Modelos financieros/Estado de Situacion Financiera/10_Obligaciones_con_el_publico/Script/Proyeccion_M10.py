"""Cierre interanual 2026 y saldos proporcionales M10. Ejecutar desde cualquier carpeta."""
from pathlib import Path
import sys
import os

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parents[3] / "Dashboard" / "Sistema"))
from iaspe_excel_portable import Blob, SpreadsheetFile

CUENTAS = ("01_Depositos_restringidos", "02_Otras_obligaciones")

def abrir(path):
    return SpreadsheetFile.import_xlsx(Blob.load(str(path)))

def guardar(libro, path):
    temporal=path.with_name(path.stem+".actualizando.xlsx")
    SpreadsheetFile.export_xlsx(libro).save(str(temporal))
    os.replace(temporal,path)

def proyectar():
    consolidado = ROOT / "03_Consolidacion_obligaciones/Obligaciones_con_el_publico.xlsx"
    libro = abrir(consolidado)
    hoja = libro.worksheets.get_item("Anual")
    datos = hoja.get_range("A2:H16").values
    fondeo = {int(f[0]): float(f[1]) + float(f[2]) for f in datos if isinstance(f[0], (int, float))}
    cierre = {}

    for cuenta in CUENTAS:
        entrada = ROOT / cuenta / "Input/Base_modelo.xlsx"
        salida = ROOT / cuenta / "Output/Pronostico.xlsx"
        base = abrir(entrada).worksheets.get_item("Mensual").get_range("A2:B200").values
        historico = {str(f[0])[:7]:float(f[1]) for f in base if f[0] is not None and isinstance(f[1], (int,float))}
        ultimos = sorted(k for k in historico if k.startswith("2026-"))
        ultimo = ultimos[-1]
        mes = int(ultimo[-2:])
        if mes < 3:
            raise ValueError("M10 necesita al menos tres meses observados de 2026")
        meses_26 = [f"2026-{m:02d}" for m in range(mes-2,mes+1)]
        meses_25 = [f"2025-{m:02d}" for m in range(mes-2,mes+1)]
        if any(k not in historico for k in meses_25 + meses_26 + ["2025-12"]):
            raise ValueError(f"Falta información interanual de {cuenta}")
        if mes == 12:
            saldo_26 = historico[ultimo]
        else:
            saldo_26 = historico["2025-12"] * sum(historico[m] for m in meses_26) / sum(historico[m] for m in meses_25)
        cierre[cuenta] = {y:saldo_26 * fondeo[y] / fondeo[2026] for y in range(2026,2031)}
        libro_cuenta = abrir(salida)
        mensual = libro_cuenta.worksheets.get_item("Mensual")
        anual = libro_cuenta.worksheets.get_item("Anual")
        anual.get_range("D1:E1").values = [["Ahorro + plazo (S/ MM)","Participación sobre fondeo (%)"]]
        # Los históricos de Input pasan a Output sin alterar los datos SBS.
        for k in ultimos:
            fila = 3 + 10*12 + int(k[-2:])-1
            mensual.get_range(f"B{fila}:C{fila}").values = [[historico[k],"Observado SBS"]]
        if mes == 12:
            formula = f"=Mensual!B{3+10*12+11}"
        else:
            inicio = 3+10*12+(mes-3)
            fin = 3+10*12+(mes-1)
            inicio_ant = inicio-12
            fin_ant = fin-12
            formula = f"=Mensual!B122*AVERAGE(Mensual!B{inicio}:B{fin})/AVERAGE(Mensual!B{inicio_ant}:B{fin_ant})"
        anual.get_range("B12").formulas = [[formula]]
        anual.get_range("C12").values = [["Observado SBS" if mes==12 else "Cierre supuesto: interanual 3 meses"]]
        for y in range(2026,2031):
            fila = y-2026+12
            anual.get_range(f"D{fila}").values = [[fondeo[y]]]
            anual.get_range(f"E{fila}").formulas = [[f"=IFERROR(B{fila}/D{fila}*100,0)"]]
            if y>2026:
                anual.get_range(f"B{fila}").formulas = [[f"=$B$12*D{fila}/$D$12"]]
                anual.get_range(f"C{fila}").values = [["Proyección proporcional M08 + M09"]]
        for m in range(mes+1,13):
            fila = 3+10*12+m-1
            mensual.get_range(f"B{fila}").formulas = [[f"=$B${3+10*12+mes-1}+(Anual!$B$12-$B${3+10*12+mes-1})*{m-mes}/{12-mes}"]]
            mensual.get_range(f"C{fila}").values = [["Cierre supuesto: interanual 3 meses"]]
        for y in range(2027,2031):
            fila_a = y-2026+12
            for m in range(1,13):
                fila = 3+(y-2016)*12+m-1
                mensual.get_range(f"B{fila}").formulas = [[f"=Anual!B{fila_a-1}+(Anual!B{fila_a}-Anual!B{fila_a-1})*{m}/12"]]
                mensual.get_range(f"C{fila}").values = [["Proyección proporcional M08 + M09"]]
        guardar(libro_cuenta,salida)
        # Gráfico actualizado: histórico SBS y senda derivada de M08 + M09.
        from datetime import datetime
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            plt = None
        if plt is not None:
            filas=libro_cuenta.worksheets.get_item("Mensual").get_range("A2:C182").values
            observado=[];proyectado=[]
            for fecha,valor,estado in filas:
                if not fecha or not isinstance(valor,(int,float)):continue
                instante=datetime.strptime(str(fecha)[:7],"%Y-%m")
                (observado if str(fecha)[:7]<=ultimo else proyectado).append((instante,float(valor)))
            fig,ax=plt.subplots(figsize=(9.2,3.6))
            ax.plot(*zip(*observado),label="Observado",linewidth=1.5)
            ax.plot(*zip(*([observado[-1]]+proyectado)),label="Estimado / proyectado",linewidth=1.5)
            ax.set_title("Depósitos restringidos" if cuenta==CUENTAS[0] else "Otras obligaciones con el público",fontsize=11)
            ax.set_ylabel("S/ millones",fontsize=9)
            ax.grid(alpha=.2);ax.legend(loc="upper left",frameon=False,fontsize=8)
            fig.tight_layout()
            fig.savefig(ROOT/cuenta/"Output/Grafico_pronostico.png",dpi=140)
            plt.close(fig)

    # M10 = Ahorro + Plazo + Restringidos + Otras obligaciones.
    for y in range(2026,2031):
        fila = y-2016+2
        hoja.get_range(f"D{fila}:E{fila}").values = [[cierre[CUENTAS[0]][y],cierre[CUENTAS[1]][y]]]
    guardar(libro,consolidado)

    # Los coeficientes aprobados de M11 permanecen inalterados.
    import motor
    motor.load_base(refresh=True)
    modelos,_=motor.load_base()
    beta=[float(c["value"]) for c in modelos["11"]["coefficients"]]
    if len(beta)!=4:raise ValueError("M11 necesita cuatro coeficientes")
    saldo10={f["year"]:f["value"] for f in modelos["10"]["annual"]}
    saldo09={f["year"]:f["value"] for f in modelos["09"]["annual"]}
    p11=ROOT.parent / "11_Costo_obligaciones_con_el_publico_Falabella"
    pron=p11/"Output/Pronostico.xlsx"
    libro11=abrir(pron); s11=libro11.worksheets.get_item("Anual")
    tabla=s11.get_range("A2:E17").values
    tpm={int(f[0]):float(f[2]) for f in tabla if isinstance(f[0],(int,float)) and isinstance(f[2],(int,float))}
    costo={int(f[0]):float(f[1]) for f in tabla if isinstance(f[0],(int,float)) and isinstance(f[1],(int,float))}
    for y in range(2026,2031):
        fila=y-2015+2
        share=100*saldo09[y]/saldo10[y]
        s11.get_range(f"D{fila}").values=[[share]]
        if y>2026:
            costo[y]=beta[0]+beta[1]*costo[y-1]+beta[2]*tpm[y]+beta[3]*share
            s11.get_range(f"B{fila}").values=[[costo[y]]]
    guardar(libro11,pron)
    input11=p11/"Input/Base_modelo.xlsx"
    libro11=abrir(input11);s11=libro11.worksheets.get_item("Anual")
    for y in range(2026,2031):
        s11.get_range(f"D{y-2015+2}").values=[[100*saldo09[y]/saldo10[y]]]
    guardar(libro11,input11)

    p12=ROOT.parents[1] / "Estado de Resultados/12_Gastos_por_intereses_Falabella"
    detalle=p12/"01_Obligaciones_publico"
    for tipo in ("Input","Output"):
        f=detalle/tipo/("Base_modelo.xlsx" if tipo=="Input" else "Pronostico.xlsx")
        w=abrir(f);s=w.worksheets.get_item("Anual")
        for y in range(2026,2031):
            s.get_range(f"B{y-2014+2}:C{y-2014+2}").values=[[saldo10[y],costo[y]]]
        guardar(w,f)
    w=abrir(detalle/"Output/Pronostico.xlsx");s=w.worksheets.get_item("Anual")
    suma=p12/"Consolidado.xlsx";t=abrir(suma);a=t.worksheets.get_item("Anual")
    for y in range(2027,2031):
        amort=s.get_range(f"G{y-2014+2}").values[0][0]
        a.get_range(f"B{y-2016+2}").values=[[amort]]
    guardar(t,suma)

if __name__=="__main__":
    proyectar()
