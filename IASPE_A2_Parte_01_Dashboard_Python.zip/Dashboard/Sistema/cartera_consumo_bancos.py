"""Comparativo histórico SBS B-2389 de cartera de consumo por entidad."""
from functools import lru_cache
import json
from pathlib import Path

PANEL = Path(__file__).resolve().parent / 'data' / 'cartera_consumo_bancos.json'

@lru_cache(maxsize=2)
def _load(mtime_ns, size):
    with PANEL.open('r', encoding='utf-8') as source:
        return json.load(source)

def historical():
    stat = PANEL.stat()
    return _load(stat.st_mtime_ns, stat.st_size)
