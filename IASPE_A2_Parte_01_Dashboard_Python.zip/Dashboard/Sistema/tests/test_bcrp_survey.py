"""Exact original Nota77 and adversarial geometric-reader checks.

The fixture is a manual transcription checked against page images 1, 3 and 4;
it is intentionally independent of the parser's output.
"""
import os
from pathlib import Path

import pymupdf as fitz
import pytest

try:
    from bcrp_documents import parse_survey_pdf
except ImportError:
    from bcrp_survey_tables import parse_survey_pdf


PDF = Path(os.environ.get("BCRP_PDF_DIR", str(Path.home() / "Downloads"))) / "nota-de-estudios-77-2026.pdf"
GROUPS = ("Analistas económicos", "Sistema financiero", "Empresas no financieras")
DATES = ("2026-08-31", "2026-09-30", "2026-10-30")
EXPECTED = {
    "inflacion": [
        [[4.00, 4.20, 4.40], [2.60, 3.00, 2.75], [2.35, 2.20, 2.45]],
        [[4.00, 4.00, 4.50], [2.55, 2.50, 2.80], [2.45, 2.50, 2.50]],
        [[3.00, 3.48, 3.52], [2.50, 2.70, 3.00], [2.50, 2.50, 2.50]],
    ],
    "pbi": [
        [[3.2, 3.2, 3.1], [3.3, 3.3, 3.1], [3.5, 4.0, 4.0]],
        [[3.2, 3.2, 3.2], [3.2, 3.0, 3.0], [3.5, 3.1, 3.5]],
        [[3.2, 3.2, 3.2], [3.4, 3.4, 3.3], [3.5, 3.5, 3.5]],
    ],
    "tc_cierre": [
        [[3.39, 3.37, 3.38], [3.40, 3.42, 3.40], [3.45, 3.45, 3.45]],
        [[3.35, 3.35, 3.40], [3.40, 3.40, 3.40], [3.40, 3.40, 3.40]],
        [[3.40, 3.40, 3.40], [3.45, 3.45, 3.45], [3.47, 3.47, 3.47]],
    ],
}


@pytest.fixture(scope="module")
def body():
    assert PDF.exists(), f"Required real PDF missing: {PDF}"
    return PDF.read_bytes()


@pytest.fixture(scope="module")
def parsed(body):
    return parse_survey_pdf(body, PDF.name)


def test_exact_original_all_81_cells(parsed):
    identity = parsed["document"]
    assert identity["sha256"] == "5f5b86be0b39da85a742b89c43c4e719182c6413f4c3c240b188b74fe6ea027c"
    assert identity["edition"] == "2026-10"
    assert identity["survey_date"] == "2026-10-30"
    assert identity["published"] == "2026-11-06"
    rows = parsed["records"]
    assert len(rows) == 81
    actual = {(r["variable"], r["group"], r["year"], r["survey_date"]): r["value"] for r in rows}
    expected = {(variable, group, str(2026+yi), survey_date): EXPECTED[variable][gi][yi][di]
                for variable in EXPECTED for gi, group in enumerate(GROUPS)
                for yi in range(3) for di, survey_date in enumerate(DATES)}
    assert actual == expected
    assert len({(r["variable"],r["group"],r["year"],r["survey_date"]) for r in rows}) == 81
    assert {(t["variable"],t["page"]) for t in parsed["tables"]} == {("inflacion",1),("pbi",3),("tc_cierre",4)}


def test_latest_column_is_october_only(parsed):
    current = [r for r in parsed["records"] if r["is_current_column"]]
    assert len(current) == 27
    assert {r["survey_date"] for r in current} == {"2026-10-30"}
    assert next(r["value"] for r in current if r["variable"] == "tc_cierre" and
                r["group"] == GROUPS[0] and r["year"] == "2026") == 3.38
    assert all(r["bbox"] and r["crosscheck_bbox"] and r["value_text"] and r["sha256"] for r in current)


def _redact_records(body, rows):
    with fitz.open(stream=body, filetype="pdf") as pdf:
        for row in rows:
            # Cross-engine bbox already includes the full PyMuPDF glyph height.
            pdf[row["page"]-1].add_redact_annot(fitz.Rect(row["crosscheck_bbox"]), fill=(1,1,1))
        for page in pdf:
            page.apply_redactions()
        return pdf.tobytes()


def test_incomplete_cell_is_rejected(body, parsed):
    row = next(r for r in parsed["records"] if r["variable"] == "tc_cierre" and
               r["group"] == GROUPS[0] and r["year"] == "2026" and r["is_current_column"])
    damaged = _redact_records(body, [row])
    with pytest.raises(ValueError, match="incompleta"):
        parse_survey_pdf(damaged, "missing-cell.pdf")


def test_missing_group_is_rejected(body):
    with fitz.open(stream=body,filetype="pdf") as pdf:
        # Only the group label in the actual annual TC table, not body text.
        page = pdf[3]
        for rect in page.search_for("SISTEMA FINANCIERO"):
            page.add_redact_annot(rect, fill=(1,1,1))
        page.apply_redactions()
        damaged = pdf.tobytes()
    with pytest.raises(ValueError, match="tres grupos"):
        parse_survey_pdf(damaged, "missing-group.pdf")


def test_page_coordinate_translation_preserves_values(body, parsed):
    with fitz.open(stream=body, filetype="pdf") as original, fitz.open() as shifted:
        for i, page in enumerate(original):
            new = shifted.new_page(width=page.rect.width+70,height=page.rect.height+90)
            new.show_pdf_page(fitz.Rect(37,43,37+page.rect.width,43+page.rect.height), original, i)
        translated = shifted.tobytes()
    result = parse_survey_pdf(translated, "translated.pdf")
    key = lambda r: (r["variable"],r["group"],r["year"],r["survey_date"],r["value"])
    assert sorted(map(key,result["records"])) == sorted(map(key,parsed["records"]))


def test_two_date_columns_not_fixed_three(body, parsed):
    with fitz.open(stream=body,filetype="pdf") as pdf:
        for row in parsed["records"]:
            if row["survey_date"] == DATES[0]:
                pdf[row["page"]-1].add_redact_annot(fitz.Rect(row["crosscheck_bbox"]),fill=(1,1,1))
        for table in parsed["tables"]:
            page = pdf[table["page"]-1]
            header_box = fitz.Rect(table["columns"][0]["bbox"])
            # Remove the three header words using their independent-engine bounds.
            for word in page.get_text("words"):
                if header_box.x0-1 <= (word[0]+word[2])/2 <= header_box.x1+1 and abs((word[1]+word[3])/2-(header_box.y0+header_box.y1)/2)<6:
                    page.add_redact_annot(fitz.Rect(word[:4]),fill=(1,1,1))
        for page in pdf:
            page.apply_redactions()
        two_columns = pdf.tobytes()
    result = parse_survey_pdf(two_columns,"two-survey-columns.pdf")
    assert len(result["records"]) == 54
    assert len([r for r in result["records"] if r["is_current_column"]]) == 27
    assert {r["survey_date"] for r in result["records"]} == set(DATES[1:])


def test_unreadable_input_rejected():
    with pytest.raises(ValueError, match="no es un PDF"):
        parse_survey_pdf(b"<html>not a document</html>")
