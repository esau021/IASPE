'use strict';
/* Vista ejecutiva IASPE: composición contable SBS y ratios sobre el escenario ACTIVO.
 * No interpola datos faltantes ni supone partidas regulatorias no entregadas.
 * Reutiliza los 47 modelos de la respuesta /api/calculate; no reestima coeficientes.
 */
window.IASPEExecutive = (() => {
 const SOURCE='/api/executive/financial-base';
 const SPLIT_SOURCE='/api/executive/revolving-split';
 const IASC_BASE = {"2026": {"activos": 5615.54525243, "consumo_total": 4333.718417849999, "inversiones": 352.90873799, "obligaciones": 3869.6508664099997, "pasivos": 4609.42725241, "patrimonio": 1006.11800002, "utilidad": 236.01242492}, "2027": {"activos": 6230.58251545, "consumo_total": 4897.41278856, "inversiones": 430.123421, "obligaciones": 4356.10528891, "pasivos": 5110.6570983599995, "patrimonio": 1119.9254170899999, "utilidad": 255.32820197}, "2028": {"activos": 6861.65969596, "consumo_total": 5423.48781082, "inversiones": 462.67464031000003, "obligaciones": 4831.7744417700005, "pasivos": 5632.9221231, "patrimonio": 1228.73757287, "utilidad": 313.26727769999997}};
 let iascYear = 2028;

 let source=null, split=null, pending=null;
 const el=(id)=>document.getElementById(id);
 const num=(v,dec=2)=>v===null||v===undefined||!Number.isFinite(Number(v))?'—':new Intl.NumberFormat('es-PE',{minimumFractionDigits:dec,maximumFractionDigits:dec}).format(Math.abs(Number(v))<0.5*Math.pow(10,-dec)?0:Number(v));
 const percent=(v)=>v===null||v===undefined||!Number.isFinite(Number(v))?'—':num(100*v,2)+'%';
 const val=(m,y)=>{
   if(!m)return null;
   const r=(m.annual||[]).find(x=>Number(x.year)===Number(y));
   return r&&r.value!==null&&Number.isFinite(Number(r.value))?Number(r.value):null;
 };
 const sum=(...parts)=>parts.every(x=>x!==null&&x!==undefined&&Number.isFinite(x))?parts.reduce((s,n)=>s+n,0):null;
 const diff=(a,b)=>a==null||b==null?null:a-b;
 const ratio=(a,b)=>a==null||b==null||Math.abs(b)<1e-10?null:a/b;
 const sourceVal=(year,label)=>(source?.years?.[String(year)]||{})[label]??null;
 const original=(id,y)=>source?.modelOriginals?.[id]?.[String(y)]??null;
 const yearValues=(App,year)=>{
   const models=new Map(App.state.data.models.map(m=>[m.id,m]));
   const get=(id)=>val(models.get(id),year);
   const baseline=sourceVal(year,'INGRESOS FINANCIEROS');
   const delta16=diff(get('16'),original('16',year));
   const deltaTc=diff(get('20_tc'),original('20_tc',year));
   const deltaDer=diff(get('20_derivados'),original('20_derivados',year));
   // Ingreso financiero original + variaciones de ingresos financieros recalculadas.
   // El gasto financiero residual es exactamente la diferencia frente al M23.
   const finIncome=sum(baseline,delta16,deltaTc,deltaDer);
   const creditIncome=get('16_creditos');
   const share=split?.shares?.[String(year)];
   const revIncome=get('16_rev');
   const nonRevIncome=get('16_nrev');
   const grossMargin=get('23');
   const financialCosts=diff(finIncome,grossMargin);
   const provisions=get('25');
   const netMargin=diff(grossMargin,provisions);
   const prevRetained=year===2025?null:val(models.get('45'),year-1);
   const serviceIncome=sum(get('18_diversos'),get('18_otros_ing'));
   const serviceCosts=sum(get('18_gastos_div'),get('18_otros_gastos'));
   const services=get('18');
   const sale=sourceVal(year,'(+/−) Venta de cartera');
   const operatingMargin=sum(netMargin,services,sale);
   const administrative=get('19');
   const operatingNet=diff(operatingMargin,administrative);
   const beforeTax=sum(operatingNet,-(get('26')??NaN),-(get('27')??NaN),get('24'));
   const taxes=get('28'),profit=get('29');
   const finConsistent=grossMargin==null||finIncome==null||financialCosts==null?false:Math.abs(finIncome-financialCosts-grossMargin)<0.001;
   return {get,prevRetained,assets:get('47'),equity:get('47_patrimonio'),grossLoans:get('07'),netLoans:get('47_creditos_netos'),finIncome,creditIncome,revIncome,nonRevIncome,financialCosts,grossMargin,provisions,netMargin,serviceIncome,serviceCosts,services,sale,
     operatingMargin,administrative,operatingNet,beforeTax,taxes,profit,finConsistent,
     pnlGap:beforeTax==null||taxes==null||profit==null?null:beforeTax-taxes-profit};
 };
 const statements = {
  pnl:[
   ['INGRESOS FINANCIEROS',v=>v.finIncome,'ej_ingresos_financieros','regular'],
   ['  Ingresos por intereses',v=>v.get('16'),'16','detail'],
   ['    Ingresos por créditos',v=>v.creditIncome,'16_creditos','detail'],
   ['      Consumo revolvente · estimado',v=>v.revIncome,'16_rev','detail'],
   ['      Consumo no revolvente · estimado',v=>v.nonRevIncome,'16_nrev','detail'],
   ['(−) Gastos financieros',v=>v.financialCosts,'ej_gastos_financieros','regular'],
   ['MARGEN FINANCIERO BRUTO',v=>v.grossMargin,'23','total'],
   ['(−) Provisiones para créditos directos',v=>v.provisions,'25','regular'],
   ['MARGEN FINANCIERO NETO',v=>v.netMargin,'ej_margen_financiero_neto','subtotal'],
   ['(+) Ingresos por servicios financieros',v=>v.serviceIncome,'ej_ingresos_servicios','regular'],
   ['(−) Gastos por servicios financieros',v=>v.serviceCosts,'ej_gastos_servicios','regular'],
   ['(+/−) Venta de cartera',v=>v.sale,'ej_venta_cartera','regular'],
   ['MARGEN OPERACIONAL',v=>v.operatingMargin,'ej_margen_operacional','subtotal'],
   ['(−) Gastos de administración',v=>v.administrative,'19','regular'],
   ['MARGEN OPERACIONAL NETO',v=>v.operatingNet,'ej_margen_operacional_neto','subtotal'],
   ['(−) Depreciación y amortización',v=>v.get('26'),'26','regular'],
   ['(−) Valuación de activos y otras provisiones',v=>v.get('27'),'27','regular'],
   ['(+/−) Otros ingresos y gastos',v=>v.get('24'),'24','regular'],
   ['RESULTADO ANTES DE IMPUESTOS',v=>v.beforeTax,'ej_resultado_antes_impuestos','subtotal'],
   ['(−) Impuesto a la renta',v=>v.taxes,'28','regular'],
   ['RESULTADO NETO DEL EJERCICIO',v=>v.profit,'29','highlight'],
  ],
  operaciones:[
   ['Amortizaciones de consumo',v=>v.get('49'),'49','total'],
   ['  Revolvente',v=>v.get('49_rev'),'49_rev','regular'],
   ['    Tarjetas de crédito · estimado',v=>v.get('49_tc'),'49_tc','detail'],
   ['    RappiCash · estimado',v=>v.get('49_rc'),'49_rc','detail'],
   ['  Préstamos efectivos (no revolvente)',v=>v.get('49_pe'),'49_pe','regular'],
   ['Participación RC en salidas (%)',v=>v.get('49_part_rc'),'49_part_rc','detail'],
  ],
  balance:[
   ['ACTIVO',null,null,'heading'],
   ['Liquidez e inversiones',null,null,'group'],
   ['Disponible',v=>v.get('17'),'17','regular'],
   ['Fondos interbancarios (activo)',v=>v.get('22'),'22','regular'],
   ['Inversiones financieras',v=>v.get('21'),'21','regular'],
   ['Cartera y otros activos',null,null,'group'],
   ['Colocaciones brutas - consumo total',v=>v.grossLoans,'07','detail'],
   ['Cartera de créditos neta',v=>v.netLoans,'47_creditos_netos','regular'],
   ['Cuentas por cobrar netas',v=>v.get('31'),'31','regular'],
   ['Rendimientos por cobrar',v=>v.get('32'),'32','regular'],
   ['Inmuebles, mobiliario y equipo',v=>v.get('33'),'33','regular'],
   ['Otros activos',v=>v.get('34'),'34','regular'],
   ['TOTAL ACTIVO',v=>v.get('47'),'47','highlight'],
   ['PASIVO',null,null,'heading'],
   ['Captaciones y financiamiento',null,null,'group'],
   ['Obligaciones con el público',v=>v.get('10'),'10','regular'],
   ['Depósitos del sistema financiero',v=>v.get('35'),'35','regular'],
   ['Fondos interbancarios (pasivo)',v=>v.get('47_interbancario_pasivo'),'47','regular'],
   ['Obligaciones en circulación — principal',v=>v.get('47_principal_cert'),'36','regular'],
   ['Otras obligaciones',null,null,'group'],
   ['Cuentas por pagar',v=>v.get('37'),'37','regular'],
   ['Intereses y otros gastos por pagar',v=>v.get('38'),'38','regular'],
   ['Otros pasivos',v=>v.get('39'),'39','regular'],
   ['Provisiones del pasivo',v=>v.get('40'),'40','regular'],
   ['TOTAL PASIVO',v=>v.get('47_pasivo'),'47','total'],
   ['PATRIMONIO',null,null,'heading'],
   ['Capital social',v=>v.get('41'),'41','regular'],
   ['Capital adicional',v=>v.get('42'),'42','regular'],
   ['Reservas',v=>v.get('43'),'43','regular'],
   ['Ajustes patrimoniales',v=>v.get('44'),'44','regular'],
   ['Resultados acumulados',v=>v.get('45'),'45','regular'],
   ['Resultado neto del ejercicio',v=>v.get('46'),'46','regular'],
   ['TOTAL PATRIMONIO',v=>v.get('47_patrimonio'),'47','total'],
  ] };
 // Desglose jerárquico. Los importes reutilizan los mismos modelos del escenario activo.
 // Los residuos se muestran de forma explícita y nunca se interpretan como subcuentas estimadas.
 const N=(key,label,formula,mid,type='detail',children=[])=>({key,label,formula,mid,type,children});
 const K=(id)=>v=>v.get(id);
 const negate=(fn)=>v=>fn(v)==null?null:-fn(v);
 const sub=(a,b)=>v=>diff(a(v),b(v));
 // Fichas de cuentas de la visión ejecutiva: identidades, NO regresiones nuevas.
 // Sus series se calculan con la misma función yearValues usada para imprimir la tabla.
 const EXEC_ACCOUNTS = [
   {id:'ej_ingresos_financieros',key:'finIncome',name:'Ingresos financieros',anchor:'16',tex:String.raw`I_t^{fin}=I_t^{intereses}+I_t^{otros\,fin}`,why:'Los ingresos financieros incluyen los ingresos por intereses y otras partidas financieras. La diferencia frente al Modelo 16 se muestra como un residual contable, sin atribuirle una regresión inexistente.',parts:[['Ingresos por intereses','16',d=>d.get('16')],['Otros ingresos financieros y diferencias de conciliación',null,d=>diff(d.finIncome,d.get('16'))]]},
   {id:'ej_gastos_financieros',key:'financialCosts',name:'Gastos financieros',anchor:'12',tex:String.raw`G_t^{fin}=I_t^{fin}-M_t^{fin\,bruto}`,why:'El gasto financiero ejecutivo se obtiene de la identidad del margen financiero bruto. Comprende intereses y otras partidas de gasto o conciliación. No equivale únicamente a los gastos por intereses del Modelo 12.',parts:[['Gastos por intereses','12',d=>d.get('12')],['Primas del Fondo de Seguro de Depósitos','18_fsd',d=>d.get('18_fsd')],['Otros gastos financieros y diferencias de conciliación',null,d=>diff(d.financialCosts,sum(d.get('12'),d.get('18_fsd')))]]},
   {id:'ej_margen_financiero_neto',key:'netMargin',name:'Margen financiero neto',anchor:'23',tex:String.raw`M_t^{fin\,neto}=M_t^{fin\,bruto}-Provisiones_t`,why:'El margen neto descuenta las provisiones para créditos directos del margen financiero bruto. Las provisiones son los inputs financieros originales, no se reestiman para construir esta ficha.',parts:[['Margen financiero bruto','23',d=>d.grossMargin],['(−) Provisiones para créditos directos','25',d=>-d.provisions]]},
   {id:'ej_ingresos_servicios',key:'serviceIncome',name:'Ingresos por servicios financieros',anchor:'18',tex:String.raw`I_t^{serv}=I_t^{diversos}+I_t^{otros}`,why:'Se suman los ingresos diversos por servicios y los otros ingresos por servicios del Modelo 18, antes de deducir sus gastos. No se confunden con el resultado neto de servicios.',parts:[['Ingresos diversos por servicios','18_diversos',d=>d.get('18_diversos')],['Otros ingresos por servicios','18_otros_ing',d=>d.get('18_otros_ing')]]},
   {id:'ej_gastos_servicios',key:'serviceCosts',name:'Gastos por servicios financieros',anchor:'18',tex:String.raw`G_t^{serv}=G_t^{diversos}+G_t^{otros}`,why:'Se suman los gastos diversos y otros gastos por servicios. La cifra mostrada es el gasto bruto positivo, que se resta al obtener el resultado neto de servicios.',parts:[['Gastos diversos por servicios','18_gastos_div',d=>d.get('18_gastos_div')],['Otros gastos por servicios','18_otros_gastos',d=>d.get('18_otros_gastos')]]},
   {id:'ej_venta_cartera',key:'sale',name:'Venta de cartera',anchor:'24',tex:String.raw`V_t^{cartera}=V_t^{fuente\,contable}`,why:'Partida de venta de cartera tomada del archivo de composición contable del estado de resultados. No existe una estimación econométrica propia. Se conserva su signo original y el importe del escenario base.',parts:[['Venta de cartera según base financiera',null,d=>d.sale]]},
   {id:'ej_margen_operacional',key:'operatingMargin',name:'Margen operacional',anchor:'18',tex:String.raw`M_t^{oper}=M_t^{fin\,neto}+R_t^{servicios}+V_t^{cartera}`,why:'Suma el margen financiero neto, el resultado neto de servicios financieros (ingresos menos gastos) y la venta de cartera con su signo contable. No es igual al Modelo 18 por sí solo.',parts:[['Margen financiero neto','ej_margen_financiero_neto',d=>d.netMargin],['Resultado neto de servicios','18',d=>d.services],['Venta de cartera','ej_venta_cartera',d=>d.sale]]},
   {id:'ej_margen_operacional_neto',key:'operatingNet',name:'Margen operacional neto',anchor:'19',tex:String.raw`M_t^{oper\,neto}=M_t^{oper}-G_t^{administracion}`,why:'Al margen operacional se le descuentan todos los gastos de administración del Modelo 19. No es igual al gasto administrativo mostrado por la ficha M19.',parts:[['Margen operacional','ej_margen_operacional',d=>d.operatingMargin],['(−) Gastos de administración','19',d=>-d.administrative]]},
   {id:'ej_resultado_antes_impuestos',key:'beforeTax',name:'Resultado antes de impuestos',anchor:'29',tex:String.raw`RAI_t=M_t^{oper\,neto}-G_t^{deprec}-G_t^{valuacion}+R_t^{otros}`,why:'Se parte del margen operacional neto y se incorporan depreciaciones, valuaciones y otros ingresos o gastos. El impuesto aún no se descuenta y por eso este resultado no es la utilidad neta M29.',parts:[['Margen operacional neto','ej_margen_operacional_neto',d=>d.operatingNet],['(−) Depreciación y amortización','26',d=>-d.get('26')],['(−) Valuación y otras provisiones','27',d=>-d.get('27')],['(+/−) Otros ingresos y gastos','24',d=>d.get('24')]]}
 ];
 const executiveAccountIDs=EXEC_ACCOUNTS.map(x=>x.id);
 function accountDefinition(id){return EXEC_ACCOUNTS.find(x=>x.id===id)||null;}
 function accountModel(App,id,baseline=false){
   const def=accountDefinition(id);
   if(!def||!source||!App?.state?.data)return null;
   const actual=App.state.data;
   const scoped=baseline?{state:{data:{...actual,models:actual.baseline}}}:App;
   const annual=[2025,2026,2027,2028,2029,2030].map(year=>{
     const d=yearValues(scoped,year),v=d[def.key];
     if(v==null||!Number.isFinite(Number(v)))return null;
     const status=year<=2025?'observed':year===2026?'assumed':'forecast';
     return {year,date:year+'-12-01',status,value:Number(v),observed:status==='observed'?Number(v):null,assumed:status==='assumed'?Number(v):null,forecast:status==='forecast'?Number(v):null};
   }).filter(Boolean);
   return {id,name:def.name,unit:'S/ millones',group:'resultados',role:'Identidad contable del Estado de Resultados',method:'Cálculo contable a partir de componentes del escenario activo',kind:'derived',derivedExecutive:true,scenarioSupport:true,scenarioModel:def.anchor,frequency:'annual',annual,monthly:[],status:'ok',estimatedEquationTex:def.tex,economicRationale:def.why,coefficients:[],statistics:{},dependencies:def.parts.map(p=>p[1]).filter(Boolean),inputs:[],sourceFiles:['data/eeff_sbs_base_2025_2030.json'],reestimated:false};
 }
 function accountDetail(App,id){
   const def=accountDefinition(id);if(!def||!source)return '';
   const fmt=App.fmt,esc=App.escape;
   const ys=[2025,2026,2027,2028,2029,2030], data=ys.map(y=>yearValues(App,y));
   const terms=def.parts;
   const headers=ys.map(y=>`<th>${y}</th>`).join('');
   const body=terms.map(([name,mid,fn])=>`<tr><td>${mid&&App.model(mid)?`<a href="#modelo/${esc(mid)}">${esc(name)}</a>`:esc(name)}</td>${data.map(d=>`<td>${fmt(fn(d))}</td>`).join('')}</tr>`).join('');
   const current=App.model(id), sample=yearValues(App,2027);
   const parts=terms.map(([name,mid,fn])=>`${esc(name)}: <strong>${fmt(fn(sample))}</strong>`).join(' · ');
   return `<div class="model-bottom"><div class="fold"><div class="section-label">Cómo se calcula exactamente esta cuenta</div><p><strong>No es una regresión adicional.</strong> Se utiliza la misma identidad contable y la misma serie del Estado de Resultados ejecutivo. Los componentes enlazan a sus fichas originales.</p><p>${esc(def.why)}</p><div class="table-scroll panel"><table class="data-table"><thead><tr><th>Componente · S/ millones</th>${headers}</tr></thead><tbody>${body}<tr><td><strong>${esc(def.name)}</strong></td>${ys.map(y=>`<td><strong>${fmt(App.last(current,y))}</strong></td>`).join('')}</tr></tbody></table></div><p><strong>Ejemplo 2027.</strong> ${parts}. <strong>Resultado = S/ ${fmt(App.last(current,2027))} millones.</strong></p><p><strong>Fuente:</strong> estados financieros base SBS/IASPE y componentes originales del motor. Los importes del cierre 2026 son supuestos, y las cifras posteriores siguen las proyecciones del motor. Ningún coeficiente o input se modifica para esta ficha.</p></div></div>`;
 }
 const T={
   pnl:[
     N('income','INGRESOS FINANCIEROS',v=>v.finIncome,'ej_ingresos_financieros','regular',[
       N('interest','Ingresos por intereses',K('16'),'16','detail',[
         N('loaninterest','Ingresos por créditos',v=>v.creditIncome,'16_creditos','detail',[
           N('revolvinginterest','Ingresos por créditos de consumo revolvente',v=>v.revIncome,'16_rev'),
           N('nonrevolvinginterest','Ingresos por créditos de consumo no revolvente',v=>v.nonRevIncome,'16_nrev')]),
         N('investmentinterest','Ingresos por inversiones',K('16_inversiones'),'16_inversiones'),
         N('availableinterest','Ingresos por disponibilidades',K('16_disponible'),'16_disponible'),
         N('interbankinterest','Ingresos por fondos interbancarios',K('16_interbancarios'),'16_interbancarios')]),
       N('otherfinancialincome','Otros ingresos financieros y diferencias de conciliación',v=>diff(v.finIncome,v.get('16')),null)]),
     N('financialcost','(−) Gastos financieros',v=>v.financialCosts,'ej_gastos_financieros','regular',[
       N('interestcost','Gastos por intereses',K('12'),'12','detail',[
         N('savinginterest','Intereses por obligaciones con el público',K('12_obligaciones'),'12_obligaciones'),
         N('entityinterest','Intereses por depósitos de entidades financieras',K('12_entidades'),'12_entidades'),
         N('debtsinterest','Intereses por adeudos',K('12_adeudos'),'12_adeudos'),
         N('otherinterest','Intereses por otras fuentes de financiamiento',K('12_otras'),'12_otras')]),
       N('fsdcost','Primas del Fondo de Seguro de Depósitos',K('18_fsd'),'18_fsd'),
       N('financialcostremaining','Otros gastos financieros y diferencias de conciliación',v=>diff(v.financialCosts,sum(v.get('12'),v.get('18_fsd'))),null)]),
     N('grossmargin','MARGEN FINANCIERO BRUTO',v=>v.grossMargin,'23','total'),
     N('provisions','(−) Provisiones para créditos directos',v=>v.provisions,'25','regular'),
     N('netmargin','MARGEN FINANCIERO NETO',v=>v.netMargin,'ej_margen_financiero_neto','subtotal'),
     N('serviceincome','(+) Ingresos por servicios financieros',v=>v.serviceIncome,'ej_ingresos_servicios','regular',[
       N('servicevariedincome','Ingresos diversos por servicios financieros',K('18_diversos'),'18_diversos'),
       N('serviceotherincome','Otros ingresos por servicios financieros',K('18_otros_ing'),'18_otros_ing')]),
     N('servicecost','(−) Gastos por servicios financieros',v=>v.serviceCosts,'ej_gastos_servicios','regular',[
       N('servicediversecost','Gastos diversos por servicios financieros',K('18_gastos_div'),'18_gastos_div'),
       N('serviceothercost','Otros gastos por servicios financieros',K('18_otros_gastos'),'18_otros_gastos')]),
     N('sale','(+/−) Venta de cartera',v=>v.sale,'ej_venta_cartera','regular'),
     N('operatingmargin','MARGEN OPERACIONAL',v=>v.operatingMargin,'ej_margen_operacional','subtotal'),
     N('admin','(−) Gastos de administración',v=>v.administrative,'19','regular',[
       N('personnel','Gastos de personal',K('19_personal'),'19_personal'),
       N('services3p','Servicios de terceros',K('19_terceros'),'19_terceros'),
       N('board','Gastos del directorio',K('19_directorio'),'19_directorio'),
       N('admincontributions','Impuestos y contribuciones',K('19_impuestos'),'19_impuestos')]),
     N('netoperating','MARGEN OPERACIONAL NETO',v=>v.operatingNet,'ej_margen_operacional_neto','subtotal'),
     N('depreciation','(−) Depreciación y amortización',K('26'),'26','regular'),
     N('assetvaluation','(−) Valuación de activos y otras provisiones',K('27'),'27','regular'),
     N('otherincomeexpense','(+/−) Otros ingresos y gastos',K('24'),'24','regular'),
     N('beforetax','RESULTADO ANTES DE IMPUESTOS',v=>v.beforeTax,'ej_resultado_antes_impuestos','subtotal'),
     N('taxes','(−) Impuesto a la renta',v=>v.taxes,'28','regular'),
     N('profit','RESULTADO NETO DEL EJERCICIO',v=>v.profit,'29','highlight')
   ],
   balance:[
     N('headingassets','ACTIVO',null,null,'heading'),
     N('groupcash','Liquidez e inversiones',null,null,'group'),
     N('available','Disponible',K('17'),'17','regular',[
       N('cash','Caja',K('17_caja'),'17_caja'),
       N('banks','Bancos y corresponsales conciliados',K('17_bancos'),'17_bancos'),
       N('clearing','Canje',K('17_canje'),'17_canje'),
       N('othercash','Otros disponibles',K('17_otros'),'17_otros')]),
     N('interbankassets','Fondos interbancarios (activo)',K('22'),'22','regular'),
     N('investments','Inversiones financieras',K('21'),'21','regular',[
       N('availableforsale','Inversiones disponibles para la venta',K('21_venta'),'21_venta'),
       N('subsidiaryinvestments','Inversiones en subsidiarias y asociadas',K('21_asociadas'),'21_asociadas'),
       N('otherinvestments','Otras inversiones',K('21_otras'),'21_otras')]),
     N('groupassets','Cartera y otros activos',null,null,'group'),
     N('grossloans','Colocaciones brutas de consumo',v=>v.grossLoans,'07','regular',[
       N('revolvingloans','Créditos de consumo revolvente',K('05'),'05'),
       N('nonrevolvingloans','Créditos de consumo no revolvente',K('06'),'06')]),
     N('netloans','Cartera de créditos neta',v=>v.netLoans,'47_creditos_netos','regular',[
       N('grossconsumerloans','Colocaciones brutas de consumo',v=>v.grossLoans,'07'),
       N('adjustmentloans','Otros créditos, provisiones acumuladas y ajustes netos de cartera',v=>diff(v.netLoans,v.grossLoans),null)]),
     N('receivables','Cuentas por cobrar netas',K('31'),'31','regular'),
     N('accruals','Rendimientos por cobrar',K('32'),'32','regular'),
     N('property','Inmuebles, mobiliario y equipo',K('33'),'33','regular'),
     N('otherassets','Otros activos',K('34'),'34','regular'),
     N('totalassets','TOTAL ACTIVO',K('47'),'47','highlight',[
       N('at_cash','Disponible',K('17'),'17'),
       N('at_ib','Fondos interbancarios',K('22'),'22'),
       N('at_inv','Inversiones financieras',K('21'),'21'),
       N('at_net','Cartera de créditos neta',v=>v.netLoans,'47_creditos_netos'),
       N('at_receiv','Cuentas por cobrar netas',K('31'),'31'),
       N('at_interests','Rendimientos por cobrar',K('32'),'32'),
       N('at_fixed','Inmuebles, mobiliario y equipo',K('33'),'33'),
       N('at_other','Otros activos',K('34'),'34')]),
     N('headingliabilities','PASIVO',null,null,'heading'),
     N('groupliabilities','Captaciones y financiamiento',null,null,'group'),
     N('publicdeposits','Obligaciones con el público',K('10'),'10','regular',[
       N('savings','Depósitos de ahorro',K('08'),'08','detail',[
         N('savingmn','Ahorro en moneda nacional',K('08_mn'),'08_mn'),
         N('savingfx','Ahorro en moneda extranjera',K('08_me'),'08_me')]),
       N('termdeposits','Depósitos a plazo',K('09'),'09','detail',[
         N('ordinaryterm','Depósitos a plazo ordinarios',K('09_plazo'),'09_plazo'),
         N('ctsdeposits','Depósitos de compensación por tiempo de servicios',K('09_cts'),'09_cts')]),
       N('restricted','Depósitos restringidos',K('10_restringidos'),'10_restringidos'),
       N('otherpublic','Otras obligaciones con el público',K('10_otras'),'10_otras')]),
     N('bankdeposits','Depósitos del sistema financiero',K('35'),'35','regular'),
     N('interbankliabilities','Fondos interbancarios (pasivo)',K('47_interbancario_pasivo'),'47_interbancario_pasivo','regular'),
     N('certificates','Obligaciones en circulación — principal',K('47_principal_cert'),'47_principal_cert','regular',[
       N('certgross','Obligaciones en circulación antes de reclasificar intereses',K('36'),'36'),
       N('certreclassified','(−) Intereses reclasificados a cuentas por pagar',v=>diff(v.get('47_principal_cert'),v.get('36')),null)]),
     N('otherliabilitiesgroup','Otras obligaciones',null,null,'group'),
     N('payables','Cuentas por pagar',K('37'),'37','regular'),
     N('interestpayables','Intereses y otros gastos por pagar',K('38'),'38','regular'),
     N('otherliabilities','Otros pasivos',K('39'),'39','regular'),
     N('liabilityprovisions','Provisiones del pasivo',K('40'),'40','regular'),
     N('totalliabilities','TOTAL PASIVO',K('47_pasivo'),'47_pasivo','total',[
       N('lt_pub','Obligaciones con el público',K('10'),'10'),
       N('lt_bank','Depósitos del sistema financiero',K('35'),'35'),
       N('lt_ib','Fondos interbancarios (pasivo)',K('47_interbancario_pasivo'),'47_interbancario_pasivo'),
       N('lt_cert','Obligaciones en circulación — principal',K('47_principal_cert'),'47_principal_cert'),
       N('lt_acc','Cuentas por pagar',K('37'),'37'),
       N('lt_inter','Intereses y otros gastos por pagar',K('38'),'38'),
       N('lt_other','Otros pasivos',K('39'),'39'),
       N('lt_prov','Provisiones del pasivo',K('40'),'40')]),
     N('headingequity','PATRIMONIO',null,null,'heading'),
     N('capital','Capital social',K('41'),'41','regular'),
     N('extracapital','Capital adicional',K('42'),'42','regular'),
     N('reserves','Reservas',K('43'),'43','regular'),
     N('capitaladjustment','Ajustes patrimoniales',K('44'),'44','regular'),
     N('retained','Resultados acumulados',K('45'),'45','regular',[
       N('retainedprev','Resultados acumulados del ejercicio anterior',v=>v.prevRetained,null),
       N('priorprofitapplied','Utilidad del ejercicio anterior aplicada',K('45_utilidad_aplicada'),'45_utilidad_aplicada'),
       N('transfersreserves','(−) Transferencias a reservas',negate(K('45_transferencias_reservas')),'45_transferencias_reservas'),
       N('dividendpaid','(−) Dividendos distribuidos',negate(K('45_dividendos')),'45_dividendos')]),
     N('currentprofit','Resultado neto del ejercicio',K('46'),'46','regular'),
     N('totalequity','TOTAL PATRIMONIO',K('47_patrimonio'),'47_patrimonio','total',[
       N('eq_cap','Capital social',K('41'),'41'),
       N('eq_extra','Capital adicional',K('42'),'42'),
       N('eq_res','Reservas',K('43'),'43'),
       N('eq_adj','Ajustes patrimoniales',K('44'),'44'),
       N('eq_retained','Resultados acumulados',K('45'),'45'),
       N('eq_profit','Resultado neto del ejercicio',K('46'),'46')])
   ]
 };
 const openExecutiveRows=new Set();
 const treeIndex={};
 for(const [mode,roots] of Object.entries(T)){
   treeIndex[mode]=new Map();
   const descend=(rows)=>rows.forEach(row=>{treeIndex[mode].set(row.key,row);descend(row.children||[])});
   descend(roots);
 }
 const valueOf=(node,d)=>typeof node.formula==='function'?node.formula(d):null;
 // La diferencia de conciliación no se redistribuye artificialmente entre cuentas.
 function normalizedChildren(node,data,mode){
   const items=[...(node.children||[])];
   if(!items.length)return items;
   const diffs=data.map(d=>{
     const parent=valueOf(node,d);
     if(parent==null)return null;
     const parts=items.map(r=>valueOf(r,d));
     if(parts.some(v=>v===null||!Number.isFinite(Number(v))))return null;
     return parent-parts.reduce((acc,v)=>acc+Number(v),0);
   });
   if(diffs.some(d=>d!==null&&Math.abs(d)>0.005)){
     items.push(N(node.key+'_residual','Diferencia de conciliación no desagregada',
       d=>{const parent=valueOf(node,d);const parts=items.slice(0,-1).map(r=>valueOf(r,d));return parent==null||parts.some(x=>x==null)?null:parent-parts.reduce((a,b)=>a+b,0)},null,'detail'));
   }
   return items;
 }
 function table(App,years,items,mode){
   const data=years.map(y=>yearValues(App,y));
   const header=`<thead><tr><th class="executive-concept">Concepto · S/ millones</th>${years.map(y=>`<th class="num">${y}</th>`).join('')}</tr></thead>`;
   const esc=s=>App.escape(String(s??''));
   const output=[];
   function write(node,depth=0,ancestors=[]){
     const grouped=node.type==='heading'||node.type==='group';
     const children=normalizedChildren(node,data,mode);
     const expandable=children.length>0;
     const domKey=mode+'_'+node.key;
     const currentOpen=openExecutiveRows.has(domKey);
     const hidden=ancestors.some(p=>!openExecutiveRows.has(p))?' hidden':'';
     const classes=['executive-row-'+node.type,'executive-tree-depth-'+Math.min(4,depth)];
     if(expandable)classes.push('executive-tree-parent');
     const cells=grouped?years.map(()=>'<td></td>'):
       data.map((d,i)=>{
         const v=valueOf(node,d),display=num(v);
         const click=node.mid&&App.model(node.mid);
         const value=click?`<button type="button" class="executive-value-link" data-exec-account="${esc(node.mid)}" data-exec-label="${esc(node.label)}" data-exec-node="${esc(node.key)}" data-exec-mode="${mode}" data-exec-year="${years[i]}" aria-label="Consultar ${esc(node.label)} en ${years[i]}">${display}</button>`:display;
         return `<td class="num">${value}</td>`;
       });
     const hasModel=node.mid&&App.model(node.mid);
     // El nombre conduce directamente al modelo. El botón contiguo gestiona exclusivamente el desglose.
     const label=hasModel?`<a class="executive-account-link" href="#modelo/${encodeURIComponent(node.mid)}" title="Abrir ficha del modelo ${esc(node.mid)}">${esc(node.label)} <span aria-hidden="true">⌁</span></a>`:esc(node.label);
     const toggle=expandable?`<button type="button" class="executive-expand-toggle" data-exec-tree="${esc(domKey)}" aria-expanded="${String(currentOpen)}" aria-label="${currentOpen?'Ocultar':'Desglosar'} ${esc(node.label)}" title="${currentOpen?'Ocultar':'Desglosar'} componentes"><span aria-hidden="true">${currentOpen?'−':'+'}</span></button>`:'';
     output.push(`<tr class="${classes.join(' ')}" data-exec-row="${esc(domKey)}" data-exec-parent="${esc(ancestors.at(-1)||'')}"${hidden}><td><div class="executive-tree-label" style="--executive-depth:${depth}">${toggle}${label}</div></td>${cells.join('')}</tr>`);
     children.forEach(c=>write(c,depth+1,[...ancestors,domKey]));
   }
   (T[mode]||[]).forEach(n=>write(n));
   return `<div class="executive-table-scroll"><table class="executive-table executive-tree-table" data-exec-table="${mode}">${header}<tbody>${output.join('')}</tbody></table></div>`;
 }
 function bindTree(){
   document.querySelectorAll('[data-exec-tree]').forEach(btn=>btn.addEventListener('click',()=>{
     const id=btn.dataset.execTree;
     if(openExecutiveRows.has(id))openExecutiveRows.delete(id);else openExecutiveRows.add(id);
     // Mantener la posición y el estado de los demás desgloses. No regenerar los modelos.
     for(const toggle of document.querySelectorAll('[data-exec-tree]')){
       const expanded=openExecutiveRows.has(toggle.dataset.execTree);
       toggle.setAttribute('aria-expanded',String(expanded));
       toggle.setAttribute('aria-label',(expanded?'Ocultar':'Desglosar')+' '+(toggle.closest('tr')?.querySelector('.executive-account-link')?.textContent||''));
       toggle.title=expanded?'Ocultar componentes':'Desglosar componentes';
       toggle.querySelector('span').textContent=expanded?'−':'+';
     }
     for(const row of document.querySelectorAll('[data-exec-row]')){
       let parent=row.dataset.execParent,visible=true;
       while(parent){if(!openExecutiveRows.has(parent)){visible=false;break}
         parent=document.querySelector(`[data-exec-row="${parent}"]`)?.dataset.execParent||'';
       }
       row.hidden=!visible;
     }
   }));
 }
 function openDetail(App,mid,label,mode,year,nodeKey){
   const panel=el('executive-account-detail');if(!panel)return;
   const m=App.model(mid)||App.model(mid.startsWith('47_')?'47':mid);
   const statement=statements[mode]||statements.balance;
   const node=treeIndex[mode]?.get(nodeKey||'');
   const row=node?[node.label,node.formula,node.mid]:statement.find(x=>x[0]===label&&x[2]===mid);
   const years=[2025,2026,2027,2028,2029,2030];
   const values=row?years.map(y=>row[1](yearValues(App,y))):years.map(y=>val(m,y));
   const displayed=years.findIndex(y=>y===year);
   const value=displayed<0?null:values[displayed];
   const method=String(m?.method||m?.role||'Detalle contable calculado a partir de los modelos IASPE.');
   const modelId=m?.id||mid;
   const hasSeries=values.filter(x=>x!==null&&Number.isFinite(x)).length>1;
   // Use an account-specific, exact series; no invented values or interpolation.
   const W=610,H=160,L=42,R=16,T=14,B=26;
   const ok=values.map((v,i)=>v==null?null:{x:i,v}).filter(Boolean);
   const max=Math.max(...ok.map(p=>p.v),0),min=Math.min(...ok.map(p=>p.v),0);
   const fy=v=>T+(max-v)*(H-T-B)/(max-min||1),fx=i=>L+i*(W-L-R)/Math.max(years.length-1,1);
   const d=ok.map((p,i)=>`${i?'L':'M'}${fx(p.x)} ${fy(p.v)}`).join(' ');
   const svg=hasSeries?`<svg class="executive-detail-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución de ${App.escape(label)}"><line x1="${L}" x2="${W-R}" y1="${fy(0)}" y2="${fy(0)}" stroke="#dce8dd"/><path d="${d}" fill="none" stroke="#247c51" stroke-width="2.8"/>${ok.map(p=>`<circle cx="${fx(p.x)}" cy="${fy(p.v)}" r="4" fill="${years[p.x]===year?'#d38c45':'#247c51'}"><title>${years[p.x]}: ${num(p.v)} MM</title></circle>`).join('')}${years.map((y,i)=>`<text x="${fx(i)}" y="${H-4}" text-anchor="middle">${y}</text>`).join('')}</svg>`:'';
   const status=(mid==='16_creditos'&&year===2025)?'Ingresos por créditos observados':(label.includes('revolvente')&&year===2025)?'Apertura vinculada al IASC 2025':label.includes('estimado')||['49_tc','49_rc','49_pe'].includes(mid)?'Apertura estimada':year<=2025?'Dato histórico':'Pronóstico';
   panel.hidden=false;
   panel.innerHTML=`<div class="executive-detail-head"><div><span class="executive-detail-eyebrow">DETALLE DE CUENTA · ${year}</span><h3>${App.escape(label)}</h3><p>${App.escape(status)} · S/ millones</p></div><button type="button" class="executive-detail-close" aria-label="Cerrar detalle">×</button></div><div class="executive-detail-value">${num(value)}</div>${svg}<div class="executive-detail-meta"><div><strong>Modelo de origen</strong><span>${App.escape(m?.name||'Modelo '+mid)}</span></div><div><strong>Metodología</strong><span>${App.escape(method)}</span></div></div><div class="executive-detail-actions"><a href="#modelo/${App.escape(modelId)}">Abrir modelo y sus datos</a><a href="#mapa">Ver relaciones entre modelos</a></div>`;
   panel.querySelector('.executive-detail-close').onclick=()=>{panel.hidden=true};
   panel.scrollIntoView({behavior:'smooth',block:'nearest'});
 }
 function bindDetails(App){
   bindTree();
   document.querySelectorAll('[data-exec-account]').forEach(btn=>btn.addEventListener('click',()=>openDetail(App,btn.dataset.execAccount,btn.dataset.execLabel,btn.dataset.execMode,Number(btn.dataset.execYear),btn.dataset.execNode)));
   document.querySelectorAll('[data-exec-kpi]').forEach(btn=>btn.addEventListener('click',()=>openDetail(App,btn.dataset.execKpi,btn.dataset.execLabel,btn.dataset.execMode,Number(btn.dataset.execYear),btn.dataset.execNode)));
 }

 function chart(App,title,years,series){
   const colors=['#176b40','#416c82'];
   const lines=series.map(([label,field],i)=>({label,values:years.map(year=>yearValues(App,year)[field]),color:colors[i%colors.length]}));
   const values=lines.flatMap(l=>l.values).filter(v=>v!==null&&Number.isFinite(v));
   if(values.length<2)return `<div class="executive-empty">Datos insuficientes para mostrar la evolución de ${App.escape(title)}.</div>`;
   const W=720,H=228,L=65,R=20,T=20,B=40;
   const low=Math.min(0,...values),high=Math.max(...values)*1.16||1;
   const x=i=>L+i*(W-L-R)/Math.max(1,years.length-1);
   const y=v=>T+(high-v)*(H-T-B)/(high-low||1);
   const ticks=[0,.25,.5,.75,1].map(q=>{const n=low+q*(high-low);return `<line x1="${L}" x2="${W-R}" y1="${y(n)}" y2="${y(n)}" stroke="#e5ebe5"/><text x="${L-8}" y="${y(n)+4}" text-anchor="end">${num(n,0)}</text>`}).join('');
   const paths=lines.map(l=>{
     let d='',inPath=false;
     l.values.forEach((v,i)=>{
       if(v===null){inPath=false;return}
       d+=(inPath?'L':'M')+x(i).toFixed(1)+' '+y(v).toFixed(1)+' ';inPath=true;
     });
     return `<path d="${d}" fill="none" stroke="${l.color}" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>${l.values.map((v,i)=>v===null?'':`<circle cx="${x(i)}" cy="${y(v)}" r="3.5" fill="${l.color}"><title>${years[i]}: ${num(v)}</title></circle>`).join('')}`;
   }).join('');
   return `<div class="executive-chart"><div class="executive-chart-title">${App.escape(title)}</div><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${App.escape(title)}. Serie histórica y proyectada en millones de soles.">${ticks}${paths}${years.map((year,i)=>`<text x="${x(i)}" y="${H-13}" text-anchor="middle">${year}</text>`).join('')}</svg><div class="executive-chart-key">${lines.map(l=>`<span><i style="background:${l.color}"></i>${App.escape(l.label)}</span>`).join('')}</div></div>`;
 }
 function ratios(App,years){
   const records=years.map(y=>({y,d:yearValues(App,y),prior:yearValues(App,y-1)}));
   const rows=[
     ['ROA · resultado / activos promedio',r=>ratio(r.d.get('29'),sum(r.prior.get('47'),r.d.get('47'))/2),'Calculado','SBS · rentabilidad'],
     ['ROE · resultado / patrimonio promedio',r=>ratio(r.d.get('29'),sum(r.prior.get('47_patrimonio'),r.d.get('47_patrimonio'))/2),'Calculado','SBS · rentabilidad'],
     ['Cartera atrasada / colocaciones brutas',_=>null,'Pendiente','Requiere atrasada de ambos productos (1405+1406)'],
     ['Cartera alto riesgo / colocaciones brutas',_=>null,'Pendiente','Requiere refinanciados y reestructurados (1403+1404)'],
     ['Provisiones acumuladas / cartera atrasada',_=>null,'Pendiente','Requiere apertura de cartera atrasada'],
     ['Provisiones acumuladas / cartera de alto riesgo',_=>null,'Pendiente','Requiere apertura de cartera de alto riesgo'],
     ['Gasto por incobrabilidad 4302 / colocaciones brutas',_=>null,'Pendiente','El gasto por provisiones del modelo es neto; no sustituye automáticamente al 4302 bruto SBS'],
     ['GER / patrimonio efectivo',_=>null,'Pendiente','Insumo de Riesgo Financiero / ALM'],
     ['VPR / patrimonio efectivo',_=>null,'Pendiente','Insumo de Riesgo Financiero / ALM'],
     ['Ratio de capital global',_=>null,'Pendiente','Requiere APR y patrimonio efectivo regulatorio'],
     ['Colocaciones consumo / activo total',r=>ratio(r.d.get('07'),r.d.get('47')),'Calculado','Indicador complementario'],
     ['Disponible / activo total',r=>ratio(r.d.get('17'),r.d.get('47')),'Calculado','Indicador complementario'],
     ['Provisiones netas / cartera consumo',r=>ratio(r.d.get('25'),r.d.get('07')),'Calculado','Indicador complementario; no es el 4302 bruto SBS'],
   ];
   return `<div class="executive-table-scroll"><table class="executive-table executive-ratios"><thead><tr><th class="executive-concept">Ratio</th>${years.map(y=>`<th>${y}</th>`).join('')}<th>Estado / fuente</th></tr></thead><tbody>${rows.map(([label,fn,status,note])=>`<tr><td>${App.escape(label)}</td>${records.map(r=>`<td class="num">${percent(fn(r))}</td>`).join('')}<td class="executive-ratio-note"><strong class="${status==='Pendiente'?'executive-pending':''}">${status}</strong><small>${App.escape(note)}</small></td></tr>`).join('')}</tbody></table></div>`;
 }
 function comparisonIASC(App){
   const entries=[
     ['Activos totales',v=>v.get('47'),'activos','47','balance','TOTAL ACTIVO'],
     ['Pasivos totales',v=>v.get('47_pasivo'),'pasivos','47','balance','TOTAL PASIVO'],
     ['Patrimonio neto',v=>v.get('47_patrimonio'),'patrimonio','47','balance','TOTAL PATRIMONIO'],
     ['Obligaciones con el público',v=>v.get('10'),'obligaciones','10','balance','Obligaciones con el público'],
     ['Colocaciones brutas de consumo',v=>v.grossLoans,'consumo_total','07','balance','Colocaciones brutas - consumo total'],
     ['Inversiones financieras',v=>v.get('21'),'inversiones','21','balance','Inversiones financieras'],
     ['Resultado neto del ejercicio',v=>v.profit,'utilidad','29','pnl','RESULTADO NETO DEL EJERCICIO'],
     ['Intereses por créditos',v=>v.creditIncome,'creditos','16_creditos','pnl','    Ingresos por créditos'],
     ['  Consumo revolvente',v=>v.revIncome,'revolving','16_rev','pnl','      Consumo revolvente · estimado'],
     ['  Consumo no revolvente',v=>v.nonRevIncome,'no_revolving','16_nrev','pnl','      Consumo no revolvente · estimado'],
     ['  Otros créditos (IASC)',v=>null,'otros',null,null,null]
   ];
   const selected={...(IASC_BASE[String(iascYear)]||{}),...(iascYear===2025?split?.iasc_2025||{}:{}),...(split?.iasc?.[String(iascYear)]||{})};
   const datum=yearValues(App,iascYear);
   const body=entries.map(([name,fn,field,id,mode,detailLabel])=>{
     const ours=fn(datum),reference=selected[field];
     const d=ours==null||reference==null?null:ours-reference;
     const title=id?`<button type="button" class="executive-account-link" data-exec-account="${App.escape(id)}" data-exec-label="${App.escape(detailLabel)}" data-exec-mode="${mode}" data-exec-year="${iascYear}">${App.escape(name)} <span aria-hidden="true">⌁</span></button>`:App.escape(name);
     return `<tr><td>${title}</td><td class="num">${num(ours)}</td><td class="num">${num(reference)}</td><td class="num ${d===null?'':d>0?'iasc-above':d<0?'iasc-below':''}">${d===null?'—':(d>0?'+':'')+num(d)}</td></tr>`;
   }).join('');
   const choices=[2025,2026,2027,2028].map(y=>`<button type="button" class="iasc-year-btn ${y===iascYear?'active':''}" data-iasc-year="${y}" aria-pressed="${String(y===iascYear)}">${y}</button>`).join('');
   return `<section class="executive-section executive-iasc" id="executive-iasc"><div class="executive-section-heading"><h2>Comparativo Base IASPE vs. IASC</h2><div class="iasc-year-buttons" aria-label="Año del comparativo">${choices}</div></div><div class="executive-table-scroll"><table class="executive-table"><thead><tr><th class="executive-concept">Cuenta · S/ millones</th><th>IASPE</th><th>IASC</th><th>Variación</th></tr></thead><tbody>${body}</tbody></table></div></section>`;
 }
 function loadSource(){if(source&&split)return Promise.resolve();if(!pending)pending=Promise.all([fetch(SOURCE,{cache:'no-cache'}),fetch(SPLIT_SOURCE,{cache:'no-cache'})]).then(async responses=>{if(responses.some(r=>!r.ok))throw Error('No se pudieron leer las fuentes de la visión ejecutiva.');[source,split]=await Promise.all(responses.map(r=>r.json()));}).finally(()=>{pending=null});return pending;}
 function render(App){
   const root=el('workspace');if(!root)return;
   if(!source||!split){root.innerHTML='<div class="executive-loading">Abriendo estados financieros del modelo…</div>';loadSource().then(()=>{if(location.hash.startsWith('#resumen'))render(App)}).catch(e=>{root.innerHTML=`<div class="executive-loading">${App.escape(e.message)}</div>`});return;}
   const state=App.state, data=state.data||{},horizon=Math.min(2030,Number(data.horizon)||2030);
   const profitYears=[2025,2026,2027,2028,2029,2030].filter(y=>y<=horizon&&yearValues(App,y).profit!==null);
   const balanceYears=[2025,2026,2027,2028,2029,2030].filter(y=>y<=horizon&&yearValues(App,y).get('47')!==null);
   const ratioYears=balanceYears.filter(y=>y>=2026);
   const scenario='Base';
   const lastIncome=profitYears.at(-1),lastBalance=balanceYears.at(-1);
   const vprofit=yearValues(App,lastIncome),vbalance=yearValues(App,lastBalance);
   const recon=balanceYears.every(y=>Math.abs(yearValues(App,y).get('47_control')||0)<.001);
   const edges=Number(data.graph?.edges?.length)||0;
   const pnlGaps=profitYears.filter(y=>Math.abs(yearValues(App,y).pnlGap??0)>.1);
   root.innerHTML=`<div class="executive-view">
      <div class="executive-heading"><div class="eyebrow">Modelos y resultados</div><h1>Visión ejecutiva</h1><p>Banco Falabella · <strong>Base IASPE</strong> · Importes en S/ millones</p></div>
      <div class="executive-toolbar"><span>Selecciona el nombre de una cuenta para ir a su modelo. Utiliza + para desplegar componentes y selecciona una cifra para ver su evolución.</span><div class="executive-nav"><a href="#catalogo">Todos los modelos</a><a href="#mapa">Relaciones entre modelos (${edges})</a></div></div>
      <section class="executive-kpis" aria-label="Resultados principales">
        <button class="executive-kpi executive-kpi-action" data-exec-kpi="29" data-exec-label="RESULTADO NETO DEL EJERCICIO" data-exec-mode="pnl" data-exec-year="${lastIncome}"><span>Utilidad neta · ${lastIncome}</span><strong>${num(vprofit.profit)}</strong><small>Ver resultado del ejercicio</small></button>
        <button class="executive-kpi executive-kpi-action" data-exec-kpi="47" data-exec-label="TOTAL ACTIVO" data-exec-mode="balance" data-exec-year="${lastBalance}"><span>Activos totales · ${lastBalance}</span><strong>${num(vbalance.get('47'))}</strong><small>Ver composición del activo</small></button>
        <button class="executive-kpi executive-kpi-action" data-exec-kpi="47_pasivo" data-exec-label="TOTAL PASIVO" data-exec-mode="balance" data-exec-year="${lastBalance}"><span>Pasivos totales · ${lastBalance}</span><strong>${num(vbalance.get('47_pasivo'))}</strong><small>Ver obligaciones</small></button>
        <button class="executive-kpi executive-kpi-action" data-exec-kpi="47_patrimonio" data-exec-label="TOTAL PATRIMONIO" data-exec-mode="balance" data-exec-year="${lastBalance}"><span>Patrimonio · ${lastBalance}</span><strong>${num(vbalance.get('47_patrimonio'))}</strong><small>Ver composición patrimonial</small></button>
        <button class="executive-kpi executive-kpi-action" data-exec-kpi="07" data-exec-label="Colocaciones brutas - consumo total" data-exec-mode="balance" data-exec-year="${lastBalance}"><span>Colocaciones brutas - consumo · ${lastBalance}</span><strong>${num(vbalance.grossLoans)}</strong><small>Ver cartera de consumo</small></button>
        <button class="executive-kpi executive-kpi-action" data-exec-kpi="47_creditos_netos" data-exec-label="Cartera de créditos neta" data-exec-mode="balance" data-exec-year="${lastBalance}"><span>Cartera de créditos neta · ${lastBalance}</span><strong>${num(vbalance.netLoans)}</strong><small>Ver saldo neto del balance</small></button>
      </section>
      <div class="executive-charts">${chart(App,'Resultado neto del ejercicio',profitYears,[['Utilidad neta','profit']])}${chart(App,'Activos y patrimonio',balanceYears,[['Activo total','assets'],['Patrimonio','equity']])}${chart(App,'Colocaciones de consumo y cartera neta',balanceYears,[['Colocaciones brutas de consumo','grossLoans'],['Cartera de créditos neta','netLoans']])}</div>
      ${comparisonIASC(App)}
      <section class="executive-detail-panel" id="executive-account-detail" aria-live="polite" hidden></section>
      <section class="executive-section" id="executive-pnl"><div class="executive-section-heading"><h2>Estado de Resultados</h2><span>Proyección disponible hasta ${lastIncome}</span></div>${table(App,profitYears,statements.pnl,'pnl')}</section>
      <p class="executive-footnote">La apertura de los ingresos por créditos entre consumo revolvente y no revolvente es estimada, salvo la participación observada en el IASC de 2025. Las líneas de conciliación son diferencias aritméticas para explicar cómo se llega al total y no constituyen nuevas proyecciones independientes.</p>
      <section class="executive-section" id="executive-balance"><div class="executive-section-heading"><h2>Estado de Situación Financiera</h2><span>Cuentas disponibles hasta ${lastBalance}</span></div>${table(App,balanceYears,statements.balance,'balance')}<p class="executive-footnote">Las colocaciones brutas de consumo comprenden cartera revolvente y no revolvente. La cartera neta incorpora además otros créditos, provisiones acumuladas y ajustes del balance. Los importes de ajuste o diferencias de conciliación no se interpretan como cuentas nuevas ni como estimaciones autónomas.</p></section>
      <section class="executive-section" id="executive-ratios"><div class="executive-section-heading"><h2>Indicadores financieros SBS</h2><span>Calculados o pendientes por disponibilidad de datos</span></div>${ratios(App,ratioYears)}</section>
      ${pnlGaps.length?`<p class="executive-footnote executive-alert">Diferencia de P&L detectada: ${pnlGaps.join(', ')}. Revisar la cuenta de resultado neto del ejercicio.</p>`:''}
     </div>`;
   bindDetails(App);
   document.querySelectorAll('[data-iasc-year]').forEach(btn=>btn.addEventListener('click',()=>{iascYear=Number(btn.dataset.iascYear);render(App)}));
 }
 return {render,yearValues,ensureSource:loadSource,accountModel,accountDetail,executiveAccountIDs,accountDefinition};
})();
