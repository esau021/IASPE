/* Modelos complementarios IASPE: dinámica de amortizaciones y transmisión de TPM.
 * Las series se consultan del motor y la fuente estadística. No se modifica ningún pronóstico. */
window.IASPEComplementarios = (() => {
  'use strict';
  const URI='/api/executive/transmision-monetaria';
  let study=null,pending=null;
  const fnum=(app,n,d=3)=>typeof n==='number'&&Number.isFinite(n)?app.fmt(n,d):'—';
  const safe=(app,v)=>app.escape(String(v??''));
  const nval=(model,year)=>{
    const row=model?.annual?.find(row=>Number(row.year)===year);
    return row&&typeof row.value==='number'&&Number.isFinite(row.value)?row.value:null;
  };
  function amortizationTable(app){
    const years=[2025,2026,2027,2028,2029,2030].filter(y=>nval(app.model('49'),y)!==null);
    if(!years.length)return '';
    const items=[
      {name:'Total amortizaciones de consumo',id:'49',cls:'total'},
      {name:'Consumo revolvente',id:'49_rev'},
      {name:'No revolvente',id:'49_nrev'},
      {name:'Tarjetas de crédito',id:'49_tc',cls:'nested'},
      {name:'RappiCash',id:'49_rc',cls:'nested'},
      {name:'Préstamos efectivos (no revolvente)',id:'49_pe'}
    ];
    return `<section class="complement-amort panel"><header class="complement-section-title"><div><h2>Amortizaciones por producto</h2><p>Apertura estimada · S/ millones</p></div></header>
      <div class="complement-table-scroll"><table class="complement-table"><thead><tr><th>Cuenta</th>${years.map(y=>`<th>${y}</th>`).join('')}</tr></thead>
      <tbody>${items.map(item=>`<tr class="${item.cls||''}"><td>${app.model(item.id)?`<a href="#modelo/${safe(app,item.id)}">${safe(app,item.name)}</a>`:safe(app,item.name)}</td>${years.map(y=>`<td>${fnum(app,nval(app.model(item.id),y),2)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
      <details class="complement-fold"><summary>Metodología de la apertura</summary><p>El total proviene del modelo de amortizaciones. La distribución entre tarjetas, RappiCash y préstamos es estimada a partir de patrones históricos; no equivale a amortizaciones individuales observadas por producto.</p></details>
    </section>`;
  }
  // Las doce fichas M49 siguen la misma estructura documental de las demás.
  // Aquí solo se describe la identidad vigente. No se reestima ni modifica el motor.
  const amortizationDefinitions = {
    '49':{
      rationale:'Las amortizaciones de consumo se obtienen conciliando el saldo inicial con las nuevas utilizaciones de crédito, el saldo final y los castigos. No se estiman mediante una regresión independiente.',
      terms:[
        ['Saldo inicial total','Suma de los saldos revolventes y no revolventes del cierre anterior.','Es la deuda con la que comienza el ejercicio.',['05','06']],
        ['Compras con tarjetas','Flujo anual de compras de tarjetas calculado para Falabella.','Aumenta las utilizaciones de crédito revolvente.',['49_compras']],
        ['Disposiciones de RappiCash','Flujo anual de disposiciones de efectivo de RappiCash.','Registra otra forma de utilización de la cartera revolvente.',['49_disposiciones_rc']],
        ['Desembolsos de préstamos','Monto anual desembolsado de préstamos efectivos.','Aumenta la cartera no revolvente.',['49_desembolsos']],
        ['Saldo final total','Suma de los saldos de ambas carteras al cierre del ejercicio.','Se descuenta porque continúa pendiente de pago.',['05','06']],
        ['Castigos totales','Importe de castigos de consumo que se conserva del supuesto de Riesgos.','Se resta para no confundir una baja por castigo con una amortización.']
      ],
      note:'El cálculo correspondiente a 2026 parte de los saldos de cierre de 2025 y utiliza los flujos calculados para 2026, los saldos proyectados de ambas carteras y los castigos de consumo suministrados por Riesgos. El resultado de 2026 es un cierre supuesto y no un flujo anual completamente observado. Desde 2027 se repite la misma identidad con los componentes previstos en cada ejercicio.'
    },
    '49_rev':{
      rationale:'La amortización revolvente es la reducción del capital que no se explica por castigos. Se obtiene usando el movimiento del saldo revolvente y sus dos clases de nuevas utilizaciones.',
      terms:[
        ['Saldo revolvente inicial','Saldo de tarjetas y operaciones revolventes al cierre del año anterior.','Identifica el capital pendiente al comienzo del año.',['05']],
        ['Compras con tarjetas','Flujo anual de compras de tarjetas.','Incrementa las utilizaciones revolventes.',['49_compras']],
        ['Disposiciones de RappiCash','Flujo anual de efectivo dispuesto.','También incrementa la cartera revolvente.',['49_disposiciones_rc']],
        ['Saldo revolvente final','Saldo proyectado al cierre del año actual.','Se resta por continuar pendiente de amortización.',['05']],
        ['Castigos revolventes','Castigos totales de consumo multiplicados por el peso del saldo revolvente sobre el saldo total al cierre.','Distingue bajas por castigos de repagos y conserva la suma de castigos entre carteras.',['49_nrev']]
      ],
      note:'Para 2026 se utilizan el saldo de diciembre de 2025, los flujos de compras y disposiciones calculados para 2026, el saldo revolvente previsto al cierre de 2026 y la parte de los castigos de Riesgos asignada según los saldos. El resultado de 2026 es supuesto. Desde 2027 se actualizan las mismas entradas en cada ejercicio.'
    },
    '49_nrev':{
      rationale:'La amortización no revolvente se despeja de la evolución de los préstamos efectivos. Los nuevos desembolsos aumentan la deuda y las amortizaciones y castigos la reducen.',
      terms:[
        ['Saldo no revolvente inicial','Saldo de préstamos al cierre del ejercicio anterior.','Es el capital que estaba pendiente antes de los nuevos desembolsos.',['06']],
        ['Desembolsos de préstamos','Nuevos préstamos efectivos otorgados durante el año.','Incrementan la cartera no revolvente.',['49_desembolsos']],
        ['Saldo no revolvente final','Saldo pendiente de préstamos al cierre del ejercicio actual.','Se resta para identificar las salidas del capital.',['06']],
        ['Castigos no revolventes','Castigos totales de consumo menos los castigos asignados a la cartera revolvente.','Evita contar los castigos como amortización y garantiza que las dos partes sumen el total.',['49_rev']]
      ],
      note:'En 2026 se parte del saldo de préstamos de diciembre de 2025 y se utilizan los desembolsos calculados para 2026, el saldo no revolvente previsto al cierre y los castigos distribuidos a esta modalidad. El resultado es supuesto. Desde 2027 se aplica la misma conciliación con los valores de cada año.'
    },
    '49_tc':{
      rationale:'Las amortizaciones de tarjetas son la parte de la amortización revolvente que no corresponde a RappiCash. No se estiman castigos específicos para tarjetas ni una regresión independiente.',
      terms:[
        ['Amortización revolvente','Amortización obtenida mediante la identidad de movimientos de la cartera revolvente.','Es el total que debe repartirse entre tarjetas y RappiCash.',['49_rev']],
        ['Participación de RappiCash','Peso calculado de RappiCash en las salidas implícitas de ambos productos.','Permite asignar una parte de la amortización revolvente a RappiCash.',['49_part_rc']],
        ['Porción de tarjetas','Uno menos la participación de RappiCash.','Asegura que ambas amortizaciones por producto sumen la amortización revolvente.',['49_rc']]
      ],
      note:'En 2026 se aplica a la amortización revolvente calculada para ese cierre la participación de tarjetas complementaria a la de RappiCash. La participación de 2026 procede de una prolongación de su pauta histórica y no de información observada de todo el ejercicio. Desde 2027 se repite la distribución con la participación prevista para cada año.'
    },
    '49_rc':{
      rationale:'La amortización atribuida a RappiCash es una porción de la amortización revolvente total. Se distribuye mediante la participación de las salidas históricas del producto, sin suponer castigos individuales observados.',
      terms:[
        ['Amortización revolvente','Amortización total obtenida al conciliar saldo inicial, compras, disposiciones, saldo final y castigos.','Es la base común para la apertura por producto.',['49_rev']],
        ['Participación de RappiCash','Proporción de las salidas implícitas conjuntas atribuible a RappiCash.','Determina cuánto de la amortización revolvente se asigna a este producto.',['49_part_rc']]
      ],
      note:'Para el cierre supuesto de 2026 se utiliza la amortización revolvente prevista y la participación de RappiCash prolongada desde su histórico. Los años posteriores conservan el mismo procedimiento de distribución. La participación no representa una tasa de castigo ni una amortización observada directamente.'
    },
    '49_pe':{
      rationale:'En la apertura utilizada, los préstamos efectivos constituyen la cartera de consumo no revolvente. Por ello, su amortización coincide con la de esa modalidad sin aplicar un porcentaje adicional.',
      terms:[
        ['Amortización no revolvente','Importe derivado del saldo inicial de préstamos, desembolsos, saldo final y castigos no revolventes.','Es la misma partida que corresponde a los préstamos efectivos en esta apertura.',['49_nrev']]
      ],
      note:'La amortización de préstamos efectivos de 2026 se toma de la amortización no revolvente calculada para el cierre supuesto de ese año. Desde 2027 mantiene la correspondencia directa con la amortización no revolvente de cada ejercicio.'
    },
    '49_part_rc':{
      rationale:'Para separar tarjetas y RappiCash se comparan sus salidas implícitas. Estas salidas se obtienen mediante movimientos de saldos y flujos y pueden incluir castigos u otros ajustes, por lo que se usan como proporción de reparto y no como amortizaciones puras.',
      terms:[
        ['Salidas de tarjetas','Saldo inicial de tarjetas más compras del año menos saldo final de tarjetas.','Aproxima el movimiento de salida atribuible a tarjetas.'],
        ['Salidas de RappiCash','Saldo inicial de RappiCash más disposiciones del año menos saldo final de RappiCash.','Aproxima el movimiento de salida atribuible a RappiCash.'],
        ['Participación histórica','Salidas de RappiCash divididas entre la suma de salidas de tarjetas y RappiCash.','Mide el peso relativo de RappiCash para distribuir la amortización revolvente.'],
        ['Variación anual proyectada','Variación promedio anual de la participación entre 2022 y 2025, calculada como la diferencia entre ambos extremos dividida entre tres.','Permite prolongar la participación de manera gradual sin una regresión adicional.']
      ],
      note:'La participación de 2026 se estima añadiendo a la de 2025 la variación anual media calculada con los valores históricos de 2022 y 2025. Es un cierre supuesto y no una participación observada para 2026. Para cada año desde 2027 hasta 2030 se vuelve a añadir la misma variación media. No se recalculan salidas futuras a partir de saldos específicos por producto.'
    },
    '49_compras':{
      rationale:'Las compras propias se aproximan combinando las compras del mercado con la participación del banco en el número de tarjetas. Un factor fijado con la información observada de 2025 ajusta la escala de esa aproximación.',
      terms:[
        ['Compras del mercado','Flujo anual de compras con tarjetas del mercado.','Representa la actividad total a distribuir.',['03']],
        ['Tarjetas Falabella','Número de tarjetas del banco en el año.','Permite calcular su presencia en el mercado de tarjetas.',['04']],
        ['Tarjetas del mercado','Número total de tarjetas del mercado.','Es el denominador de la participación de tarjetas de Falabella.',['01']],
        ['Factor de calibración de 2025','Compras observadas de Falabella en 2025 divididas entre la aproximación de mercado para ese mismo año.','Evita equiparar directamente participación en número de tarjetas con participación en el importe de compras.']
      ],
      note:'El cierre supuesto de compras de 2026 utiliza las proyecciones de compras y tarjetas de ese ejercicio y mantiene fijo el factor calibrado con las observaciones de 2025. Desde 2027 se reemplazan los valores anuales de los modelos relacionados y se conserva el mismo factor.'
    },
    '49_desembolsos':{
      rationale:'Los desembolsos de préstamos efectivos se obtienen aplicando al saldo previsto de préstamos la relación desembolsos sobre saldo observada en 2025. Es una regla de intensidad de flujo y no una segunda regresión.',
      terms:[
        ['Saldo no revolvente actual','Saldo de préstamos efectivos al cierre del año proyectado.','Determina la escala de la cartera que origina desembolsos.',['06']],
        ['Intensidad de desembolsos de 2025','Desembolsos observados en 2025 divididos entre el saldo no revolvente de diciembre de 2025.','Mantiene una proporción histórica fija entre desembolsos y tamaño de la cartera.']
      ],
      note:'Los desembolsos de 2026 se calculan con el saldo no revolvente previsto para ese cierre y la intensidad observada en 2025. No son desembolsos anuales completamente observados. Desde 2027 se actualiza el saldo previsto y se mantiene el mismo cociente histórico.'
    },
    '49_disposiciones_rc':{
      rationale:'Para proyectar el efectivo dispuesto mediante RappiCash se conserva la relación promedio histórica entre disposiciones de RappiCash y compras de tarjetas, calculada para 2024 y 2025.',
      terms:[
        ['Compras de tarjetas Falabella','Flujo anual de compras calculado para el ejercicio.','Es la base de actividad a la que se aplica la proporción de RappiCash.',['49_compras']],
        ['Proporción histórica de RappiCash','Promedio simple de los cocientes entre disposiciones de RappiCash y compras con tarjeta de 2024 y 2025.','Recoge una intensidad observada sin estimar una regresión adicional.']
      ],
      note:'El flujo de disposiciones de RappiCash de 2026 se calcula multiplicando las compras previstas de ese año por la relación histórica promedio de 2024 y 2025. No corresponde a un flujo anual observado. Desde 2027 se mantiene la proporción y se actualizan las compras previstas para cada ejercicio.'
    },
    '49_tasa_rev':{
      rationale:'Este indicador mide qué proporción del capital revolvente disponible durante el ejercicio se reconoce como amortización. No es una tasa de interés ni una tasa econométrica estimada.',
      terms:[
        ['Amortización revolvente','Amortización resultante de la conciliación del movimiento de cartera.','Constituye el numerador del indicador.',['49_rev']],
        ['Saldo revolvente inicial','Deuda revolvente pendiente al comenzar el año.','Forma parte del capital disponible para ser amortizado.',['05']],
        ['Compras de tarjetas','Nuevas utilizaciones por compras en el año.','Amplían el capital que puede amortizarse.',['49_compras']],
        ['Disposiciones RappiCash','Nuevas utilizaciones de efectivo en el año.','También amplían el capital que puede amortizarse.',['49_disposiciones_rc']]
      ],
      note:'La tasa de amortización revolvente de 2026 se calcula con la amortización, el saldo inicial y los flujos previstos para ese año. Es una tasa del cierre supuesto y no un parámetro estimado con una regresión. Desde 2027 se vuelve a calcular con los importes propios de cada ejercicio.'
    },
    '49_tasa_nrev':{
      rationale:'Este indicador mide la proporción del capital no revolvente disponible que corresponde a amortizaciones. No es una tasa de interés ni una regresión independiente.',
      terms:[
        ['Amortización no revolvente','Amortización obtenida de la conciliación de préstamos.','Constituye el numerador del indicador.',['49_nrev']],
        ['Saldo no revolvente inicial','Deuda de préstamos al comienzo del año.','Forma parte del capital disponible para amortizarse.',['06']],
        ['Desembolsos de préstamos','Créditos no revolventes nuevos desembolsados durante el año.','Amplían el capital que puede amortizarse.',['49_desembolsos']]
      ],
      note:'La tasa de amortización no revolvente de 2026 se calcula a partir de la amortización y de la suma del saldo inicial y los desembolsos previstos para ese ejercicio. Desde 2027 se actualiza cada año utilizando los respectivos saldos y flujos proyectados.'
    }
  };
  const isAmortization=id=>Boolean(amortizationDefinitions[String(id)]);
  const amortizationDetail=()=>''; // Misma presentación que las demás fichas y sin duplicar la explicación bajo el gráfico.
  function amortizationSpec(app,model){
    const id=String(model?.id||'');
    const doc=amortizationDefinitions[id];
    if(!doc)return '';
    const e=app.escape;
    const equation=String(model.estimatedEquationTex || model.equationTex || '');
    const equations=equation.split(/;\\quad\s*/).filter(Boolean);
    const formula=`<section class="iaspe-spec-formula" aria-label="Ecuación del cálculo">${equations.map((tex,i)=>`<div class="iaspe-spec-math ${i?'iaspe-spec-math-secondary':''}" data-spec-tex="${e(tex.trim())}"></div>`).join('')}</section>`;
    const rows=doc.terms.map(([name,meaning,motivation,refs])=>{
      const label=(refs||[]).length===1?`<button type="button" class="iaspe-term-source-name" data-spec-source-model="${e(refs[0])}" title="Ver el cálculo relacionado">${e(name)} <span aria-hidden="true">↗</span></button>`:e(name);
      const other=(refs||[]).length>1?`<span class="iaspe-term-sources">${refs.map(ref=>`<button type="button" class="iaspe-model-source-link" data-spec-source-model="${e(ref)}">Ver modelo ${e(ref)} ↗</button>`).join('')}</span>`:'';
      return `<tr><th scope="row">${label}${other}</th><td>${e(meaning)}</td><td>${e(motivation)}</td></tr>`;
    }).join('');
    return `${formula}
      <section class="iaspe-spec-rationale"><h3>Sustento</h3><p>${e(doc.rationale)}</p></section>
      <details class="iaspe-spec-fold iaspe-explanations-fold" data-spec-variables>
        <summary>Variables y justificación</summary><div class="iaspe-explanations">
          <p class="iaspe-explanation-dependent"><strong>Qué se calcula</strong> ${e(model.name||'Amortizaciones de consumo')} mediante una identidad o regla de distribución sin regresión adicional.</p>
          <div class="iaspe-spec-table-wrap"><table class="iaspe-explanation-table"><thead><tr><th>Variable o componente</th><th>Cómo interviene en el cálculo</th><th>Por qué se incluye</th></tr></thead><tbody>${rows}</tbody></table></div>
        </div>
      </details>
      <details class="iaspe-spec-fold iaspe-spec-note-fold" data-spec-closure><summary>Nota sobre el cierre de 2026 y la proyección posterior</summary><div class="iaspe-spec-closing"><p>${e(doc.note)}</p></div></details>`;
  }
  function lineChart(app, observations){
    const valid=(observations||[]).filter(r=>Number.isFinite(r.beta_individual)&&Number.isFinite(r.beta_acumulado));
    if(!valid.length)return '';
    const W=960,H=284,L=66,R=26,T=31,B=45;
    const values=[0,...valid.flatMap(r=>[r.beta_individual,r.beta_acumulado])];
    const min=Math.min(...values),max=Math.max(...values);
    const pad=(max-min)*.14||.1;
    const lo=min-pad,hi=max+pad;
    const xx=i=>L+(W-L-R)*(i+.5)/valid.length;
    const yy=v=>T+(hi-v)*(H-T-B)/(hi-lo);
    const baseline=yy(0),barWidth=Math.min(39,(W-L-R)/valid.length*.34);
    const path=valid.map((r,i)=>`${i?'L':'M'}${xx(i).toFixed(1)} ${yy(r.beta_acumulado).toFixed(1)}`).join(' ');
    const grid=Array.from({length:5},(_,i)=>{
      const v=lo+(hi-lo)*i/4,y=yy(v);
      return `<line x1="${L}" x2="${W-R}" y1="${y}" y2="${y}" class="complement-grid"/><text x="${L-12}" y="${y+4}" text-anchor="end">${fnum(app,v,2)}</text>`;
    }).join('');
    const bars=valid.map((r,i)=>{
      const x=xx(i)-barWidth/2,y=yy(r.beta_individual);
      return `<rect x="${x}" y="${Math.min(y,baseline)}" height="${Math.max(1,Math.abs(y-baseline))}" width="${barWidth}" rx="4" class="${r.beta_individual<0?'complement-bar-negative':'complement-bar-positive'}"><title>Mes ${r.mes}: impacto individual ${fnum(app,r.beta_individual,4)} pp</title></rect>`;
    }).join('');
    const dots=valid.map((r,i)=>`<circle cx="${xx(i)}" cy="${yy(r.beta_acumulado)}" r="5" class="complement-cumulative-dot"><title>Mes ${r.mes}: impacto acumulado ${fnum(app,r.beta_acumulado,4)} pp</title></circle>`).join('');
    return `<div class="complement-plot" role="img" aria-label="Respuesta de impacto individual y acumulado a una variación de un punto porcentual de la tasa BCRP">
        <svg viewBox="0 0 ${W} ${H}" class="complement-svg">${grid}<line x1="${L}" x2="${W-R}" y1="${baseline}" y2="${baseline}" class="complement-zero"/>${bars}<path d="${path}" class="complement-cumulative"/>${dots}${valid.map((r,i)=>`<text x="${xx(i)}" y="${H-16}" text-anchor="middle">Mes ${r.mes}</text>`).join('')}</svg>
        <div class="complement-legend"><span><i class="comp-key-bar"></i>Impacto individual</span><span><i class="comp-key-line"></i>Impacto acumulado</span><small>Impactos en pp sobre el costo del pasivo</small></div>
      </div>`;
  }
  function technical(app,data){
    const f=data.full||{},windows=data.periodos||[], metrics=data.metricas||{};
    const coef=(f.coeficientes||[]), se=(f.errores_hac||[]),pval=(f.p_valores_hac||[]);
    const names=['Constante','Cambio TPM contemporáneo',...Array.from({length:5},(_,i)=>`Cambio TPM rezago ${i+1}`)];
    return `<details class="complement-fold complement-tech"><summary>Ver detalle técnico y estabilidad de parámetros</summary>
       <div class="complement-stats"><div><small>Observaciones efectivas</small><strong>${f.n??'—'}</strong></div><div><small>R² ajustado</small><strong>${fnum(app,f.r2_ajustado)}</strong></div><div><small>Ljung–Box · p</small><strong>${fnum(app,f.ljungbox_p)}</strong></div><div><small>CUSUM · p</small><strong>${fnum(app,f.cusum_p)}</strong></div><div><small>Control COVID · p</small><strong>${fnum(app,metrics.covid_p)}</strong></div></div>
       <h3>Coeficientes de la regresión</h3><div class="complement-table-scroll"><table class="complement-table"><thead><tr><th>Variable</th><th>Coeficiente</th><th>Error estándar HAC</th><th>p-valor HAC</th><th>IC 95%</th></tr></thead><tbody>${coef.map((b,i)=>`<tr><td>${safe(app,names[i]||`Coeficiente ${i}`)}</td><td>${fnum(app,b,4)}</td><td>${fnum(app,se[i],4)}</td><td>${fnum(app,pval[i],4)}</td><td>${Number.isFinite(b)&&Number.isFinite(se[i])?`${fnum(app,b-1.96*se[i],4)} a ${fnum(app,b+1.96*se[i],4)}`:'—'}</td></tr>`).join('')}</tbody></table></div>
       <h3>Estabilidad por ventana de estimación</h3><div class="complement-table-scroll"><table class="complement-table"><thead><tr><th>Ventana histórica</th><th>Meses</th><th>Beta acumulado</th><th>IC 95%</th></tr></thead><tbody>${windows.map(w=>`<tr><td>${safe(app,w.periodo)}</td><td>${w.n}</td><td>${fnum(app,w.beta)}</td><td>${fnum(app,w.ci_inferior)} a ${fnum(app,w.ci_superior)}</td></tr>`).join('')}</tbody></table></div>
       <p class="complement-method-note">Los coeficientes proceden de estimaciones históricas; no constituyen pronósticos anuales de los betas futuros.</p>
     </details>`;
  }
  function renderStudy(app){
    const root=document.getElementById('workspace');if(!root)return;
    const f=study.full||{},series=study.respuesta||[];
    const table=series.map(r=>`<tr><td>Mes ${r.mes}</td><td>${fnum(app,r.beta_individual,4)}</td><td>${fnum(app,r.beta_acumulado,4)}</td><td>${fnum(app,r.proporcion_total*100,1)}%</td><td>${fnum(app,r.p_individual,3)}</td></tr>`).join('');
    root.innerHTML=`<div class="complement-page">
       <div class="page-heading model-heading"><div><div class="eyebrow">Modelos / Modelos complementarios</div><h1>Transmisión monetaria al costo del pasivo</h1><p>Respuesta histórica del costo implícito de obligaciones con el público ante variaciones de la tasa de referencia del BCRP</p></div></div>
       <div class="complement-metrics"><article><small>Beta acumulado</small><strong>${fnum(app,f.beta)}</strong><span>pp de costo por 1 pp de TPM</span></article><article><small>Último rezago del modelo</small><strong>Mes 5</strong><span>Incluye la respuesta contemporánea</span></article><article><small>IC 95% · beta</small><strong>${fnum(app,f.ci_inferior)}–${fnum(app,f.ci_superior)}</strong><span>Errores HAC Newey–West</span></article></div>
       <section class="complement-primary panel"><div class="complement-section-title"><h2>Respuesta a un cambio de 1 pp en la tasa BCRP</h2><span>Estimación mensual · ${safe(app,f.desde)} a ${safe(app,f.hasta)}</span></div>${lineChart(app,series)}
       <div class="complement-equation"><div class="complement-eq-label">Ecuación del modelo DL(5)</div><div data-tex="\\Delta c_t=\\alpha+\\sum_{k=0}^{5}\\beta_k\\Delta TPM_{t-k}+\\varepsilon_t" class="complement-eq-render">Δcₜ = α + ∑ₖ₌₀⁵ βₖ ΔTPMₜ₋ₖ + εₜ</div></div>
       <details class="complement-fold"><summary>Ver respuesta mensual en tabla</summary><div class="complement-table-scroll"><table class="complement-table"><thead><tr><th>Mes</th><th>Impacto individual</th><th>Impacto acumulado</th><th>% del total</th><th>p-valor HAC</th></tr></thead><tbody>${table}</tbody></table></div></details>
       ${technical(app,study)}</section><p class="complement-bottom-note">Modelo complementario de sensibilidad y velocidad de ajuste. No se suma a la proyección del costo del pasivo, que ya incorpora la tasa de referencia.</p>
      </div>`;
    const formula=root.querySelector('[data-tex]');
    if(formula&&window.katex){const fallback=formula.textContent;try{formula.textContent='';window.katex.render(formula.dataset.tex,formula,{displayMode:true,throwOnError:false,trust:false})}catch(_){formula.textContent=fallback;}}
  }
  function renderTransmission(app){
    const root=document.getElementById('workspace');
    if(!root)return;
    if(study){renderStudy(app);return;}
    root.innerHTML='<div class="complement-loading">Cargando la estimación de transmisión monetaria…</div>';
    if(!pending)pending=app.api(URI).then(payload=>{study=payload;}).finally(()=>{pending=null});
    pending.then(()=>{if(location.hash.startsWith('#modelo/transmision'))renderStudy(app)}).catch(error=>{if(location.hash.startsWith('#modelo/transmision'))root.innerHTML=`<div class="complement-loading">${safe(app,error.message||'No se pudo abrir la estimación.')}</div>`});
  }
  return {renderTransmission,amortizationTable,amortizationDetail,amortizationSpec,isAmortization};
})();
