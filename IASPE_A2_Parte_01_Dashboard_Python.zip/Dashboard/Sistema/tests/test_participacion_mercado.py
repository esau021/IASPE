"""Denominadores oficiales y regresiones de originales locales, sin red ni motor."""
from copy import deepcopy
from datetime import datetime
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from xml.etree import ElementTree as ET
from zipfile import ZipFile,ZIP_DEFLATED

import participacion_mercado as market


class MarketParticipationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog=market.catalog()
        cls.products={item['id']:item for item in cls.catalog['products']}

    def latest(self,identifier):return self.products[identifier]['rows'][-1]

    def test_all_ten_products_have_real_latest_complete_banking_universe(self):
        self.assertEqual(set(self.products),{'consumo','consumo_comparable','tarjetas_saldo','prestamos_no_revolventes','tarjetas_numero','obligaciones_publico','depositos_vista','depositos_ahorro','depositos_plazo','depositos_cts'})
        for item in self.products.values():
            self.assertEqual(item['latestPeriod'],'2026-09')
            self.assertFalse(item['availability']['unavailablePeriods'])
            last=item['rows'][-1]
            self.assertEqual(last['rankingCoverage'],{'known':20,'expected':20})
            self.assertTrue(last['rankingComplete'])
            self.assertEqual(last['status'],'observed')
            self.assertTrue(any(row['id']=='bci' for row in last['ranking']))
            self.assertEqual(item['universe']['denominator'],'official_sbs_sector_total')

    def test_consumption_components_and_official_denominators(self):
        total,cards,loans=(self.latest(key) for key in ('consumo_comparable','tarjetas_saldo','prestamos_no_revolventes'))
        self.assertAlmostEqual(total['falabella'],3958.62353581,places=8)
        self.assertAlmostEqual(total['market'],89790.83665141,places=8)
        self.assertAlmostEqual(cards['falabella'],1851.81202361,places=8)
        self.assertAlmostEqual(cards['market'],20782.56627141,places=8)
        self.assertAlmostEqual(loans['falabella'],2106.8115122,places=8)
        self.assertAlmostEqual(cards['falabella']+loans['falabella'],total['falabella'],places=7)
        self.assertAlmostEqual(cards['market']+loans['market'],total['market'],places=7)
        self.assertAlmostEqual(total['share'],4.408716616795036,places=10)
        self.assertEqual((total['rank'],cards['rank'],loans['rank']),(5,5,7))

    def test_yoy_is_percentage_points_and_uses_exact_prior_month(self):
        product=self.products['consumo'];previous=next(row for row in product['rows'] if row['date']=='2025-09')
        self.assertAlmostEqual(self.latest('consumo')['changeYoyPp'],self.latest('consumo')['share']-previous['share'],places=12)
        self.assertAlmostEqual(self.latest('consumo')['changeYoyPp'],-0.26171370859609056,places=10)
        self.assertIsNone(self.latest('obligaciones_publico')['changeYoyPp'])
        self.assertIn('2025-09',self.products['obligaciones_publico']['availability']['missingPeriods'])

    def test_total_card_count_is_separate_from_consumer_count_or_balance(self):
        row=self.latest('tarjetas_numero')
        self.assertEqual(row['falabella'],1456220)
        self.assertEqual(row['market'],7440085)
        self.assertAlmostEqual(row['share'],19.57262585037671,places=10)
        self.assertEqual(row['rank'],2)
        self.assertEqual(self.products['tarjetas_numero']['unit'],'tarjetas')
        self.assertNotEqual(row['market'],self.latest('tarjetas_saldo')['market'])

    def test_old_cards_choose_current_credit_year_not_debit_or_prior_year(self):
        row=self.products['tarjetas_numero']['rows'][0]
        self.assertEqual(row['date'],'2008-06')
        self.assertEqual((row['falabella'],row['market']),(1095292,5744370))
        self.assertEqual(row['source']['institutionCells']['falabella'],'F19')
        self.assertEqual(len(self.products['tarjetas_numero']['rows']),220)

    def test_obligations_use_principal_liability_and_domestic_sector_once(self):
        row=self.latest('obligaciones_publico')
        self.assertAlmostEqual(row['falabella'],3384.450315,places=8)
        self.assertAlmostEqual(row['market'],431449.676892,places=8)
        self.assertNotAlmostEqual(row['market'],433193.938259,places=3)
        self.assertEqual(len(row['ranking']),20)
        self.assertEqual(row['source']['institutionCells']['falabella'],'AR76')
        self.assertEqual(row['source']['marketCell'],'CF76')
        self.assertEqual(row['rank'],13)
        self.assertEqual(len(self.products['obligaciones_publico']['rows']),48)

    def test_deposit_variants_use_exact_b2201_subaccounts_without_double_counting_cts(self):
        savings=self.latest('depositos_ahorro')
        term=self.latest('depositos_plazo')
        sight=self.latest('depositos_vista')
        cts=self.latest('depositos_cts')
        obligations=self.latest('obligaciones_publico')
        self.assertAlmostEqual(savings['falabella'],1500.626105,places=6)
        self.assertAlmostEqual(term['falabella'],1847.518736,places=6)
        self.assertEqual(sight['falabella'],0)
        self.assertAlmostEqual(cts['falabella'],167.52958,places=5)
        self.assertAlmostEqual(savings['market'],148731.209773,places=5)
        self.assertAlmostEqual(term['market'],132534.803839,places=5)
        self.assertAlmostEqual(cts['market'],6279.049383,places=5)
        self.assertLessEqual(cts['falabella'],term['falabella'])
        self.assertLessEqual(cts['market'],term['market'])
        self.assertLessEqual(savings['falabella']+term['falabella']+sight['falabella'],obligations['falabella'])
        self.assertLessEqual(savings['market']+term['market']+sight['market'],obligations['market'])
        self.assertEqual(savings['source']['institutionCells']['falabella'],'AR79')
        self.assertEqual(cts['source']['marketCell'],'CF83')
        self.assertEqual(self.products['depositos_cts']['universe']['denominator'],'official_sbs_sector_total')

    def test_missing_is_not_zero_and_incomplete_ranking_is_disclosed(self):
        row=market.observed_row('2026-09',{'falabella':4,'bcp':None,'ripley':0},10,{}, {})
        self.assertEqual(row['share'],40)
        self.assertFalse(row['rankingComplete'])
        self.assertIsNone(row['rank'])
        byid={item['id']:item for item in row['ranking']}
        self.assertIsNone(byid['bcp']['value'])
        self.assertIsNone(byid['bcp']['share'])
        self.assertEqual(byid['ripley']['value'],0)
        self.assertEqual(byid['ripley']['share'],0)
        self.assertEqual(market.observed_row('2026-09',{'falabella':0},0,{}, {})['share'],None)

    def test_parser_rejects_mixed_period_and_unreconciled_market(self):
        path=market.CARDS/'B-2363_2026_09.xls';body=path.read_bytes()
        with self.assertRaisesRegex(ValueError,'fecha interna'):market.parse_cards(body,'2026-08')
        sheet,rows=market.first_sheet(body)
        target=next(row for row in rows if row and market.norm(row[0]).startswith('total banca multiple'))
        target[7]+=1
        with patch.object(market,'first_sheet',return_value=(sheet,rows)):
            with self.assertRaisesRegex(ValueError,'no concilian'):market.parse_cards(body,'2026-09')

    def test_projection_is_delegated_to_active_models_without_estimation(self):
        for item in self.products.values():self.assertFalse(item['projection']['available'])
        self.assertEqual(self.products['consumo_comparable']['projection']['modelIds'],['07','48'])
        self.assertTrue(all(not item['projection']['modelIds'] for item in self.products.values() if item['id']!='consumo_comparable'))

    def test_full_sbs_consumption_includes_other_modalities_without_double_counting_auto(self):
        row=self.latest('consumo');parts=row['components']['market']
        self.assertAlmostEqual(row['market'],91031.28910641,places=8)
        self.assertAlmostEqual(row['share'],4.348640533017842,places=10)
        self.assertAlmostEqual(parts['otras_modalidades'],1240.452455,places=8)
        self.assertAlmostEqual(parts['prestamos_revolventes'],46.95423362,places=8)
        self.assertAlmostEqual(parts['otros'],1193.49822138,places=8)
        self.assertAlmostEqual(row['market'],parts['tarjetas']+parts['prestamos_no_revolventes']+parts['otras_modalidades'],places=7)
        self.assertNotEqual(self.products['consumo']['universe']['productCoverage'],self.products['consumo_comparable']['universe']['productCoverage'])
        self.assertEqual(len(self.products['consumo']['rows']),192)
        self.assertTrue(all(row['components']['market']['reconciled'] for row in self.products['consumo']['rows']))

    def test_published_signed_historical_adjustments_are_kept_without_truncation(self):
        adjustments=[item for row in self.products['consumo']['rows']
                     for item in row['source']['modalities']['signedPublishedComponents']]
        self.assertEqual(len(adjustments),14)
        self.assertTrue(all(item['value']<0 for item in adjustments))
        self.assertTrue(any(row['date']=='2012-04' for row in self.products['consumo']['rows']))

    def test_cache_refreshes_from_changed_raw_in_an_isolated_fixture(self):
        original=market.CARDS/'B-2363_2026_09.xls'
        with tempfile.TemporaryDirectory() as temporary:
            base=Path(temporary);cards=base/'cards';balances=base/'balances';cards.mkdir();balances.mkdir()
            copy=cards/original.name;copy.write_bytes(original.read_bytes())
            # Solo bytes de la copia temporal: total Falabella y agregado +1.
            changed=io.BytesIO()
            with ZipFile(io.BytesIO(original.read_bytes())) as source,ZipFile(changed,'w',ZIP_DEFLATED) as target:
                for info in source.infolist():
                    body=source.read(info.filename)
                    if info.filename=='xl/worksheets/sheet1.xml':
                        tree=ET.fromstring(body)
                        for address in ('H17','H27'):
                            item=tree.find(f"m:sheetData/m:row/m:c[@r='{address}']/m:v",market.NS)
                            self.assertIsNotNone(item);item.text=str(float(item.text)+1)
                        body=ET.tostring(tree,encoding='utf-8',xml_declaration=True)
                    target.writestr(info,body)
            with patch.object(market,'CARDS',cards),patch.object(market,'BALANCES',balances),patch.object(market,'ROOT',base.parent):
                # Las rutas de proveniencia deben seguir siendo relativas al
                # proyecto; el fixture usa la raíz temporal solo para el raw.
                with patch.object(market,'provenance',side_effect=lambda path,body,sheet,period,report,**extra:{'report':report,'sha256':market.hashlib.sha256(body).hexdigest(),**extra}):
                    # El panel real de consumo no se mueve ni se modifica.
                    with patch.object(market,'CONSUMPTION',base/'empty'),patch.object(market,'build',wraps=market.build):
                        before=market.signature();raw1=market.read_original(str(copy),copy.stat().st_mtime_ns,copy.stat().st_size,'B-2363','2026-09')
                        copy.write_bytes(changed.getvalue())
                        after=market.signature();raw2=market.read_original(str(copy),copy.stat().st_mtime_ns,copy.stat().st_size,'B-2363','2026-09')
                    self.assertNotEqual(before,after)
                    self.assertEqual(raw2['values']['falabella'],raw1['values']['falabella']+1)
                    self.assertEqual(raw2['market'],raw1['market']+1)


if __name__=='__main__':unittest.main()
